/**
 * CollaborationRoomView renderer states (design §13.2, §16.4).
 *
 * RED until Phase 3 implementation lands.
 *
 * Invariants:
 *   - the view renders distinct, locale-driven states for loading, empty,
 *     error, archived and broker-degraded snapshots.
 *   - durable room state is never persisted to localStorage by the view.
 *   - no hardcoded user-visible strings in the component source — all copy
 *     comes from the zh/en locale contract.
 */
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';

const { mockGetRoom, mockListRooms, mockSend, mockMarkSeen, mockArchive, mockUpdateMembers, mockCreateProject, mockProxyGetText, mockKbListCollections, mockKbAddSource, mockOnRoomEvent, roomEventHarness } = vi.hoisted(() => ({
  mockGetRoom: vi.fn(),
  mockListRooms: vi.fn(),
  mockSend: vi.fn(),
  mockMarkSeen: vi.fn(),
  mockArchive: vi.fn(),
  mockUpdateMembers: vi.fn(),
  mockCreateProject: vi.fn(),
  mockProxyGetText: vi.fn(),
  mockKbListCollections: vi.fn(),
  mockKbAddSource: vi.fn(),
  mockOnRoomEvent: vi.fn(),
  roomEventHarness: { listener: null as null | ((event: Record<string, unknown>) => void) },
}));

vi.mock('../../renderer/src/lib/desktop', () => ({
  desktop: {
    listCollaborationRooms: mockListRooms,
    getCollaborationRoom: mockGetRoom,
    sendCollaborationRoomMessage: mockSend,
    markCollaborationRoomSeen: mockMarkSeen,
    archiveCollaborationRoom: mockArchive,
    updateCollaborationRoomMembers: mockUpdateMembers,
    createProjectFromRoom: mockCreateProject,
    onCollaborationRoomEvent: mockOnRoomEvent,
  },
}));

vi.mock('../../renderer/src/api', () => ({
  api: {
    listSkills: vi.fn().mockResolvedValue([]),
    onSkillsChanged: vi.fn(() => () => {}),
    selectMaterials: vi.fn(),
  },
}));

vi.mock('../../renderer/src/components/ChatModelPicker', () => ({
  ChatModelPicker: () => <button type="button">model</button>,
}));

vi.mock('../../renderer/src/shared/desktop', () => ({
  getDesktopApi: () => ({
    kswarmProxyGetText: mockProxyGetText,
    kbListCollections: mockKbListCollections,
    kbAddSource: mockKbAddSource,
  }),
}));

import { CollaborationRoomView } from '../../renderer/src/components/collaboration/CollaborationRoomView';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';
import { createCollaborationRoomService } from '../../electron/collaboration-room-service';
import { ROOM_SEMANTIC_OUTPUT_SCHEMAS } from '../../shared/collaboration-room-ipc-contract';

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
  window.localStorage.clear();
  roomEventHarness.listener = null;
});

function renderView(props = {}) {
  return render(
    <MemoryRouter>
      <LocaleProvider>
        <CollaborationRoomView roomId="room-1" {...props} />
      </LocaleProvider>
    </MemoryRouter>
  );
}

it('edits a room-local alias and uses its readable name for mentions and senders', async () => {
  mockGetRoom.mockResolvedValue({ ...activeSnapshot, members: activeSnapshot.members.map(m => m.subject.kind === 'agent' ? { ...m, alias: '研究员', displayName: '研究员' } : m), messages: [{ messageId: 'alias-msg', kind: 'text', text: 'result', sender: { kind: 'agent', logicalAgentId: 'agent-a' } }] });
  mockUpdateMembers.mockResolvedValue({ ok: true });
  renderView({ availableAgents: [{ id: 'agent-a', name: 'Agent A' }] });
  expect(await screen.findByText('研究员')).toBeVisible();
  fireEvent.click(screen.getByRole('button', { name: '参与智能体' }));
  fireEvent.change(screen.getByLabelText('Agent A 的空间别名'), { target: { value: '评审员' } });
  fireEvent.click(screen.getByRole('button', { name: '保存成员' }));
  await waitFor(() => expect(mockUpdateMembers).toHaveBeenCalledWith(expect.objectContaining({ aliasChanges: [{ logicalAgentId: 'agent-a', alias: '评审员' }] })));
});

const activeSnapshot = {
  ok: true,
  room: { roomId: 'room-1', title: '项目讨论', status: 'active', revision: 3 },
  members: [
    { subject: { kind: 'user', userId: 'user.local' }, role: 'owner', status: 'active' },
    { subject: { kind: 'agent', logicalAgentId: 'agent-a' }, role: 'member', status: 'active' },
  ],
  messages: [
    { messageId: 'msg-1', kind: 'text', text: 'hello', sender: { kind: 'user', userId: 'user.local' } },
  ],
  projects: [],
};

describe('CollaborationRoomView states', () => {
  it('shows authoritative execution modes and unknown observers in the existing member panel', async () => {
    mockGetRoom.mockResolvedValue({ ...activeSnapshot, executionCapabilities: [
      { logicalAgentId: 'a', mode: 'workspace_worker' }, { logicalAgentId: 'b', mode: 'discussion_only', runtime: 'qoder' },
      { logicalAgentId: 'c', mode: 'discussion_unavailable', reason: 'unsupported_protocol' },
    ] });
    renderView({ availableAgents: ['a','b','c','d'].map(id => ({ id, name: `Agent ${id}` })) });
    fireEvent.click(await screen.findByRole('button', { name: '参与智能体' }));
    expect(screen.getByText('工作区执行')).toBeVisible(); expect(screen.getByText('仅讨论')).toBeVisible();
    expect(screen.getByText('不支持讨论协议')).toBeVisible(); expect(screen.getByText('能力未确认')).toBeVisible();
    expect(screen.getByText('能力未确认').closest('label')?.querySelector('input')).not.toBeDisabled();
    expect(screen.getByText('不支持讨论协议').closest('label')?.querySelector('input')).not.toBeDisabled();
    expect(screen.getByText('不可用或能力未确认的成员可作为观察者加入，但不会回复。')).toBeVisible();
    expect(screen.getByText('Agent c: 当前执行器不支持讨论协议')).toBeVisible();
    mockGetRoom.mockResolvedValue({ ...activeSnapshot, executionCapabilities: [{ logicalAgentId: 'b', mode: 'discussion_unavailable', reason: 'probe_failed' }] });
    fireEvent.click(screen.getByRole('button', { name: '刷新' }));
    await waitFor(() => expect(screen.queryByText('仅讨论')).toBeNull());
    expect(await screen.findByText('Agent b: 能力检查未通过，请检查执行器后刷新')).toBeVisible();
  });
  it('explains unavailable recipients without counting them as pending replies', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    mockSend.mockResolvedValue({ ok: true, wake: { status: 'unavailable', roomMessageId: 'm', logicalAgentIds: [], unavailable: [{ logicalAgentId: 'agent-a', reason: 'unsupported_protocol' }] } });
    renderView({ availableAgents: [{ id: 'agent-a', name: 'Kiro' }] });
    const composer = await screen.findByRole('textbox', { name: '输入消息，@ 智能体协作，不 @ 默认与小 K 对话' });
    fireEvent.change(composer, { target: { value: '@agent-a discuss' } }); fireEvent.click(screen.getByRole('button', { name: '发送' }));
    expect(await screen.findByText('以下成员当前无法回复：Kiro。可在成员面板查看原因。')).toBeVisible();
  });
  it('renders workspace projection notifications instead of blank system bubbles', async () => {
    mockGetRoom.mockResolvedValue({ ...activeSnapshot, messages: [
      { messageId: 'workspace-registered', kind: 'workspace_event', sender: { kind: 'system', service: 'intent-broker' }, sourceRef: { eventKind: 'artifact.registered' } },
      { messageId: 'workspace-confirmed', kind: 'workspace_event', sender: { kind: 'system', service: 'intent-broker' }, sourceRef: { eventKind: 'artifact.confirmed' } },
    ] }); renderView();
    expect(await screen.findByText('成果已登记，可在文件页查看获授权的内容')).toBeVisible();
    expect(screen.getByText('成果版本已确认')).toBeVisible();
  });
  it('workspace notifications do not enter discussion settlement or reload the message owner', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot); renderView();
    await screen.findByTestId('room-view-messages');
    const count = mockGetRoom.mock.calls.length;
    expect(() => roomEventHarness.listener?.({ type: 'workspace_changed', kind: 'workspace_changed', roomId: 'room-1' })).not.toThrow();
    expect(mockGetRoom.mock.calls.length).toBe(count);
  });
  mockOnRoomEvent.mockImplementation((listener: (event: Record<string, unknown>) => void) => {
    roomEventHarness.listener = listener;
    return () => { if (roomEventHarness.listener === listener) roomEventHarness.listener = null; };
  });

  it('renders a loading state while the snapshot is in flight', async () => {
    mockGetRoom.mockImplementation(() => new Promise(() => {}));
    renderView();

    expect(screen.getByTestId('room-view-loading')).toBeDefined();
  });

  it('renders an empty state for a room with no messages', async () => {
    mockGetRoom.mockResolvedValue({ ...activeSnapshot, messages: [] });
    renderView();

    await waitFor(() => {
      expect(screen.getByTestId('room-view-empty')).toBeDefined();
    });
  });

  it('renders an error state with a retry affordance when the fetch fails', async () => {
    mockGetRoom.mockResolvedValue({ ok: false, code: 'broker_unavailable' });
    renderView();

    await waitFor(() => {
      expect(screen.getByTestId('room-view-error')).toBeDefined();
    });
  });

  it('renders an archived banner for archived rooms', async () => {
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      room: { ...activeSnapshot.room, status: 'archived' },
    });
    renderView();

    await waitFor(() => {
      expect(screen.getByTestId('room-view-archived')).toBeDefined();
    });
  });

  it('renders a degraded banner when the broker is unavailable but projects stay visible', async () => {
    mockGetRoom.mockResolvedValue({ ok: false, code: 'broker_unavailable', degraded: true });
    renderView({ degradedProjects: [{ id: 'proj-1', name: '仍可只读' }] });

    await waitFor(() => {
      expect(screen.getByTestId('room-view-degraded')).toBeDefined();
    });
  });

  it('renders messages and the composer for an active room', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    renderView();

    await waitFor(() => {
      expect(screen.getByText('hello')).toBeDefined();
    });
    expect(screen.getByTestId('room-composer')).toBeDefined();
  });

  it('keeps the room composer visually continuous with the timeline', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    renderView();

    await screen.findByText('hello');
    const composerFooter = screen.getByTestId('room-composer');
    expect(composerFooter.className.split(/\s+/)).not.toContain('border-t');
    expect(composerFooter.className.split(/\s+/)).not.toContain('border-[var(--c-border)]');

    const composerInput = screen.getByRole('textbox', {
      name: '输入消息，@ 智能体协作，不 @ 默认与小 K 对话',
    });
    const inputFrame = composerInput.closest('[role="presentation"]') as HTMLElement | null;
    expect(inputFrame?.style.borderStyle).toBe('solid');
    expect(inputFrame?.style.borderWidth).toBe('0.5px');
    expect(inputFrame?.style.borderColor).not.toBe('');
  });

  it('moves project selection into a lightweight message footer action bar', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    renderView();

    await screen.findByText('hello');
    expect(screen.queryByRole('checkbox', { name: '选为项目背景' })).toBeNull();
    const actionBar = screen.getByTestId('room-message-actions-msg-1');
    expect(actionBar.className).toContain('group-hover:opacity-100');
    expect(actionBar.className).toContain('group-focus-within:opacity-100');

    const selectButton = screen.getByRole('button', { name: '选入项目背景' });
    expect(selectButton.getAttribute('aria-pressed')).toBe('false');
    fireEvent.click(selectButton);
    expect(screen.getByRole('button', { name: '移出项目背景' }).getAttribute('aria-pressed')).toBe('true');
    expect(screen.getByRole('button', { name: '基于已选内容创建项目' })).toBeDefined();
  });

  it('copies the raw room message text and reports success', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } });
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'msg-copy',
        kind: 'text',
        sender: { kind: 'agent', logicalAgentId: 'agent-a' },
        text: '**原始 Markdown**',
      }],
    });
    renderView();

    fireEvent.click(await screen.findByRole('button', { name: '复制消息' }));

    await waitFor(() => expect(writeText).toHaveBeenCalledWith('**原始 Markdown**'));
    expect(screen.getByRole('button', { name: '已复制' })).toBeDefined();
  });

  it('saves a room message to the first knowledge collection with truthful feedback', async () => {
    mockKbListCollections.mockResolvedValue([{ id: 'kb-default', name: '我的知识库' }]);
    mockKbAddSource.mockResolvedValue({ id: 'source-1' });
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'msg-kb',
        kind: 'text',
        sender: { kind: 'agent', logicalAgentId: 'agent-a' },
        text: '# 值得收藏\n\n完整正文',
      }],
    });
    renderView();

    fireEvent.click(await screen.findByRole('button', { name: '收藏到知识库' }));

    await waitFor(() => expect(mockKbAddSource).toHaveBeenCalledWith(expect.objectContaining({
      collectionId: 'kb-default',
      kind: 'paste',
      text: '# 值得收藏\n\n完整正文',
    })));
    expect(screen.getByRole('button', { name: '已收藏到知识库' })).toBeDefined();
  });

  it('does not claim a knowledge save when no collection exists', async () => {
    mockKbListCollections.mockResolvedValue([]);
    mockGetRoom.mockResolvedValue(activeSnapshot);
    renderView();

    fireEvent.click(await screen.findByRole('button', { name: '收藏到知识库' }));

    await waitFor(() => expect(screen.getByText('请先在知识库中创建集合')).toBeDefined());
    expect(mockKbAddSource).not.toHaveBeenCalled();
    expect(screen.queryByRole('button', { name: '已收藏到知识库' })).toBeNull();
  });

  it('does not add generic message actions to project events', async () => {
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'msg-event',
        kind: 'project_event',
        sender: { kind: 'system', service: 'kswarm' },
        text: 'project updated',
      }],
    });
    renderView();

    await screen.findByText('project updated');
    expect(screen.queryByTestId('room-message-actions-msg-event')).toBeNull();
  });

  it('uses the shared task composer and removes the legacy response-policy selector', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    renderView({ availableAgents: [{ id: 'agent-a', name: 'Agent A' }] });

    await screen.findByText('hello');
    expect(screen.queryByLabelText('全员讨论一次')).toBeNull();
    expect(screen.getByRole('button', { name: '添加附件' })).toBeDefined();

    const composer = screen.getByRole('textbox', { name: '输入消息，@ 智能体协作，不 @ 默认与小 K 对话' });
    fireEvent.change(composer, { target: { value: '@' } });
    expect(await screen.findByRole('button', { name: /@all/ })).toBeDefined();
    expect(screen.getByRole('button', { name: /@Agent A/ })).toBeDefined();
  });

  it('submits raw text and attachment paths without renderer-owned response policy', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    mockSend.mockResolvedValue({ ok: true, wake: { status: 'queued', roomMessageId: 'msg-new', logicalAgentIds: ['agent-a'] } });
    renderView({ availableAgents: [{ id: 'agent-a', name: 'Agent A' }] });

    const composer = await screen.findByRole('textbox', { name: '输入消息，@ 智能体协作，不 @ 默认与小 K 对话' });
    fireEvent.change(composer, { target: { value: '@agent-a 请检查' } });
    fireEvent.click(screen.getByRole('button', { name: '发送' }));

    await waitFor(() => expect(mockSend).toHaveBeenCalledTimes(1));
    expect(mockSend.mock.calls[0][0]).toEqual(expect.objectContaining({
      roomId: 'room-1',
      text: '@agent-a 请检查',
      filePaths: [],
    }));
    expect(mockSend.mock.calls[0][0]).not.toHaveProperty('responsePolicy');
    expect(mockSend.mock.calls[0][0]).not.toHaveProperty('mentions');
  });

  it('renders GFM room messages as semantic content instead of raw markers', async () => {
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'msg-markdown',
        kind: 'text',
        sender: { kind: 'agent', logicalAgentId: 'agent-a' },
        text: [
          '# 核查结论',
          '',
          '- A 已复核',
          '- B 待补证',
          '',
          '| Claim | Status |',
          '| --- | --- |',
          '| A | Pass |',
          '',
          '`FINAL-MEMO-0830`',
          '',
          '[来源](https://example.com/source)',
        ].join('\n'),
      }],
    });

    const { container } = renderView();

    expect(await screen.findByRole('heading', { name: '核查结论', level: 1 })).toBeDefined();
    expect(screen.getAllByRole('listitem')).toHaveLength(2);
    const table = screen.getByRole('table');
    expect(table.parentElement?.className).toContain('overflow-x-auto');
    expect(container.querySelector('code')?.textContent).toBe('FINAL-MEMO-0830');
    const sourceLink = screen.getByRole('link', { name: '来源' });
    expect(sourceLink.getAttribute('href')).toBe('https://example.com/source');
    expect(sourceLink.getAttribute('target')).toBe('_blank');
    expect(sourceLink.getAttribute('rel')).toBe('noopener noreferrer');
    expect(screen.queryByText('# 核查结论')).toBeNull();
  });

  it('keeps raw HTML and dangerous links inert and does not linkify local paths', async () => {
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'msg-untrusted',
        kind: 'text',
        sender: { kind: 'agent', logicalAgentId: 'agent-a' },
        text: [
          '## 安全检查',
          '',
          '<img src=x onerror="window.__roomPwned=1">',
          '',
          '[危险链接](javascript:alert(1))',
          '',
          '/workspace/user/private.txt',
        ].join('\n'),
      }],
    });

    const { container } = renderView();

    expect(await screen.findByRole('heading', { name: '安全检查', level: 2 })).toBeDefined();
    expect(container.querySelector('img')).toBeNull();
    expect(container.textContent).toContain('<img');
    const dangerousLink = Array.from(container.querySelectorAll('a'))
      .find((element) => element.textContent === '危险链接');
    expect(dangerousLink?.getAttribute('href') ?? '').toBe('');
    expect(screen.queryByRole('link', { name: '/workspace/user/private.txt' })).toBeNull();
    expect(screen.getByText('/workspace/user/private.txt')).toBeDefined();
    expect((window as unknown as { __roomPwned?: unknown }).__roomPwned).toBeUndefined();
  });

  it('renders a trusted project artifact card and opens the shared HTML preview', async () => {
    mockProxyGetText.mockResolvedValue('<!doctype html><html><body><h1>Room artifact proof</h1></body></html>');
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'msg-artifact',
        kind: 'project_event',
        sender: { kind: 'system', service: 'kswarm' },
        text: 'Artifact report.html registered',
        sourceRef: {
          projectId: 'project-1',
          eventType: 'artifact.registered',
          taskId: 'task-report',
          artifactId: 'artifact-report-html',
          artifact: {
            projectId: 'project-1',
            filename: 'report.html',
            kind: 'html',
            mimeType: 'text/html',
          },
        },
      }],
    });

    renderView();

    const artifactCard = await screen.findByTestId('room-artifact-report.html');
    expect(artifactCard.textContent).toContain('report.html');
    expect(artifactCard.textContent).toContain('text/html');
    fireEvent.click(artifactCard);

    await waitFor(() => {
      expect(mockProxyGetText).toHaveBeenCalledWith('/projects/project-1/artifacts/report.html');
    });
    expect(await screen.findByTitle('report.html')).toBeDefined();
  });

  it('opens a migrated Markdown artifact using the production composed room snapshot', async () => {
    const service = createCollaborationRoomService({
      brokerClient: { getRoomSnapshot: async () => ({ ...activeSnapshot, projects: ['project-1'], messages: [{
        messageId: 'migrated-artifact', kind: 'project_event', sender: { kind: 'system', service: 'kswarm' },
        sourceRef: { projectId: 'project-1', taskId: 'task-1', eventType: 'artifact.registered',
          artifactId: 'task-1:report.md', artifact: { filename: 'report.md', mimeType: null } },
      }] }) } as never,
      kswarmClient: { request: async path => ({ ok: true, json: async () => path === '/agents' ? { agents: [] }
        : { project: { id: 'project-1', name: 'Fixture' }, tasks: [{ id: 'task-1', result: {
          artifacts: [{ filename: 'run-fixture/report.md', mimeType: 'text/markdown' }],
        } }] } }) },
    });
    mockGetRoom.mockResolvedValue(ROOM_SEMANTIC_OUTPUT_SCHEMAS.getRoom.parse(await service.getRoom('room-1')));
    mockProxyGetText.mockImplementation(async path => path === '/projects/project-1/artifacts/run-fixture/report.md'
      ? '# Migrated artifact proof' : null);
    renderView();
    fireEvent.click(await screen.findByTestId('room-artifact-run-fixture/report.md'));
    expect(await screen.findByRole('heading', { name: 'Migrated artifact proof' })).toBeVisible();
    expect(mockProxyGetText).toHaveBeenCalledWith('/projects/project-1/artifacts/run-fixture/report.md');
    expect(screen.queryByText(/fetch failed/)).toBeNull();
  });

  it('keeps historical artifact cards with nullable metadata and previews by filename', async () => {
    mockProxyGetText.mockResolvedValue('<!doctype html><html><body>Historical artifact</body></html>');
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [{
        messageId: 'historical-artifact', kind: 'project_event',
        sender: { kind: 'system', service: 'kswarm' },
        sourceRef: {
          projectId: 'project-1', eventType: 'artifact.registered', artifactId: 'historical-report',
          artifact: { filename: 'report.html', kind: null, mimeType: null },
        },
      }],
    });
    renderView();
    fireEvent.click(await screen.findByTestId('room-artifact-report.html'));
    await waitFor(() => expect(mockProxyGetText).toHaveBeenCalledWith('/projects/project-1/artifacts/report.html'));
    expect(await screen.findByTitle('report.html')).toBeDefined();
  });

  it('does not turn incomplete or non-project file references into artifact cards', async () => {
    mockGetRoom.mockResolvedValue({
      ...activeSnapshot,
      messages: [
        {
          messageId: 'msg-user-path',
          kind: 'text',
          sender: { kind: 'user', userId: 'user.local' },
          text: '/workspace/user/private/report.html',
          sourceRef: {
            projectId: 'project-1',
            artifactId: 'forged-artifact',
            artifact: { filename: 'report.html', mimeType: 'text/html' },
          },
        },
        {
          messageId: 'msg-incomplete-event',
          kind: 'project_event',
          sender: { kind: 'system', service: 'kswarm' },
          text: 'Artifact metadata incomplete',
          sourceRef: {
            projectId: 'project-1',
            eventType: 'artifact.registered',
            artifactId: 'missing-filename',
          },
        },
      ],
    });

    renderView();

    await screen.findByText('/workspace/user/private/report.html');
    expect(screen.queryByTestId('room-artifact-report.html')).toBeNull();
  });

  it('persists the raw @agent text while main owns mention routing', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    mockSend.mockResolvedValue({ ok: true });
    renderView({ availableAgents: [{ id: 'agent-a', name: 'Agent A' }] });

    const composer = await screen.findByLabelText('输入消息，@ 智能体协作，不 @ 默认与小 K 对话');
    fireEvent.change(composer, { target: { value: '@agent-a 请检查跨层风险' } });
    fireEvent.click(screen.getByLabelText('发送'));

    await waitFor(() => expect(mockSend).toHaveBeenCalledTimes(1));
    expect(mockSend.mock.calls[0][0]).toMatchObject({
      roomId: 'room-1',
      text: '@agent-a 请检查跨层风险',
      filePaths: [],
    });
    expect(mockSend.mock.calls[0][0]).not.toHaveProperty('mentions');
    expect(mockSend.mock.calls[0][0]).not.toHaveProperty('responsePolicy');
    await waitFor(() => expect(mockGetRoom.mock.calls.length).toBeGreaterThan(1));
  });

  it('clears the composer and restores the send button as soon as the persisted message is queued', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    mockSend.mockResolvedValue({
      ok: true,
      wake: {
        status: 'queued',
        roomMessageId: 'msg-user-2',
        logicalAgentIds: ['agent-a'],
      },
    });
    renderView({ availableAgents: [{ id: 'agent-a', name: 'Agent A' }] });

    const composer = await screen.findByLabelText('输入消息，@ 智能体协作，不 @ 默认与小 K 对话');
    fireEvent.change(composer, { target: { value: '@agent-a 请复盘' } });
    const sendButton = screen.getByLabelText('发送') as HTMLButtonElement;
    fireEvent.click(sendButton);

    await waitFor(() => expect((composer as HTMLTextAreaElement).value).toBe(''));
    fireEvent.change(composer, { target: { value: '下一条消息' } });
    expect(sendButton.disabled).toBe(false);
    expect(screen.getByTestId('room-discussion-pending').textContent).toContain('1');
  });

  it('refreshes only for the current room and clears the matching pending discussion on settlement', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    mockSend.mockResolvedValue({
      ok: true,
      wake: {
        status: 'queued',
        roomMessageId: 'msg-user-3',
        logicalAgentIds: ['agent-a'],
      },
    });
    renderView({ availableAgents: [{ id: 'agent-a', name: 'Agent A' }] });

    const composer = await screen.findByLabelText('输入消息，@ 智能体协作，不 @ 默认与小 K 对话');
    fireEvent.change(composer, { target: { value: '@agent-a 请复盘' } });
    fireEvent.click(screen.getByLabelText('发送'));
    await screen.findByTestId('room-discussion-pending');
    const callsAfterSend = mockGetRoom.mock.calls.length;

    roomEventHarness.listener?.({
      type: 'wake_settled',
      roomId: 'room-other',
      roomMessageId: 'msg-user-3',
      logicalAgentId: 'agent-a',
      outcome: 'completed',
      remaining: 0,
    });
    await Promise.resolve();
    expect(mockGetRoom.mock.calls.length).toBe(callsAfterSend);

    roomEventHarness.listener?.({
      type: 'wake_settled',
      roomId: 'room-1',
      roomMessageId: 'msg-user-3',
      logicalAgentId: 'agent-a',
      outcome: 'completed',
      remaining: 0,
    });
    await waitFor(() => expect(mockGetRoom.mock.calls.length).toBeGreaterThan(callsAfterSend));

    roomEventHarness.listener?.({
      type: 'discussion_settled',
      roomId: 'room-1',
      roomMessageId: 'msg-user-3',
      completed: ['agent-a'],
      failed: [],
    });
    await waitFor(() => expect(screen.queryByTestId('room-discussion-pending')).toBeNull());
  });

  it('never persists durable room state to localStorage', async () => {
    mockGetRoom.mockResolvedValue(activeSnapshot);
    renderView();

    await waitFor(() => {
      expect(screen.getByText('hello')).toBeDefined();
    });
    const keys = Object.keys(window.localStorage);
    expect(keys.filter((key) => key.toLowerCase().includes('room'))).toEqual([]);
  });
});

it('folds scheduled instructions and historical replies while preserving ordinary messages', async () => {
  mockGetRoom.mockResolvedValue({ ...activeSnapshot, messages: [
    { messageId: 'tick', kind: 'text', text: '定时指令全文', sender: { kind: 'system' }, sourceRef: { kind: 'scheduled_task' } },
    { messageId: 'report', kind: 'text', text: '本轮发现新的业务产物\n完整执行记录', sender: { kind: 'agent', logicalAgentId: 'agent-a' }, idempotencyKey: 'wake:tick|agent-a|0|2026-09-11' },
    { messageId: 'notice', kind: 'workspace_event', sender: { kind: 'system' }, sourceRef: { eventKind: 'artifact.registered' } },
    { messageId: 'normal', kind: 'text', text: '正常业务讨论', sender: { kind: 'agent', logicalAgentId: 'agent-a' } },
    { messageId: 'user', kind: 'text', text: '用户追问', sender: { kind: 'user' }, replyToMessageId: 'tick' },
    { messageId: 'missing', kind: 'text', text: '无法确定来源的回复', sender: { kind: 'agent' }, idempotencyKey: 'wake:missing-source|agent-a|0|date' },
  ] });
  renderView();
  await screen.findByText('正常业务讨论');
  const cards = screen.getAllByTestId('room-message');
  for (const index of [0, 1, 2]) expect(cards[index].querySelector('details')).not.toBeNull();
  for (const index of [0, 1, 2]) expect(cards[index].querySelector('details')).not.toHaveAttribute('open');
  for (const index of [3, 4, 5]) expect(cards[index].querySelector('details')).toBeNull();
  expect(cards[1].querySelector('summary')).toHaveTextContent('本轮发现新的业务产物');
  fireEvent.click(cards[1].querySelector('summary')!);
  expect(cards[1].querySelector('details')).toHaveAttribute('open');
  expect(screen.getByText(/完整执行记录/)).toBeVisible();
  expect(screen.getByTestId('room-message-actions-report')).toBeInTheDocument();
});


it('shows explicit projection_unavailable through the actual Room view without cursor writes', async () => {
  mockGetRoom.mockResolvedValue({ok:false,code:'room_projection_unavailable'});
  renderView();
  expect(await screen.findByTestId('room-view-error')).toBeVisible();
  expect(mockGetRoom).toHaveBeenCalledTimes(1);
  expect(mockMarkSeen).not.toHaveBeenCalled();
});
it('shows operation_unknown after archive once and retains the current snapshot without mutation retry', async () => {
  mockGetRoom.mockResolvedValue(activeSnapshot);
  mockArchive.mockResolvedValue({ok:false,code:'room_operation_unknown'});
  renderView();
  fireEvent.click(await screen.findByRole('button',{name:'归档'}));
  expect(await screen.findByText('操作失败，请重试')).toBeVisible();
  expect(screen.getByText('hello')).toBeVisible();
  expect(mockArchive).toHaveBeenCalledTimes(1);
  expect(mockGetRoom).toHaveBeenCalledTimes(1);
  expect(screen.queryByTestId('room-view-archived')).toBeNull();
});
it('keeps selected project data/dialog after operation_unknown with no navigation or retry', async () => {
  mockGetRoom.mockResolvedValue(activeSnapshot);
  mockCreateProject.mockResolvedValue({ok:false,code:'room_operation_unknown'});
  function CurrentLocation(){return <output data-testid="unknown-room-location">{useLocation().pathname}</output>;}
  render(<MemoryRouter><LocaleProvider><CollaborationRoomView roomId="room-1" availableAgents={[{id:'agent-a',name:'Agent A'}]}/><CurrentLocation/></LocaleProvider></MemoryRouter>);
  fireEvent.click(await screen.findByRole('button',{name:'选入项目背景'}));
  fireEvent.click(screen.getByRole('button',{name:'基于已选内容创建项目'}));
  const dialog=screen.getByRole('dialog',{name:'基于已选内容创建项目'});
  fireEvent.change(within(dialog).getByLabelText('项目名称'),{target:{value:'Retained'}});
  fireEvent.change(within(dialog).getByLabelText('项目目标'),{target:{value:'Retained goal'}});
  fireEvent.click(within(dialog).getByRole('button',{name:'基于已选内容创建项目'}));
  expect(await screen.findByText('操作失败，请重试')).toBeVisible();
  expect(screen.getByRole('dialog',{name:'基于已选内容创建项目'})).toBeVisible();
  expect(within(dialog).getByLabelText('项目名称')).toHaveValue('Retained');
  expect(screen.getByRole('button',{name:'移出项目背景'})).toBeVisible();
  expect(screen.getByTestId('unknown-room-location')).toHaveTextContent('/');
  expect(mockCreateProject).toHaveBeenCalledTimes(1);
  expect(mockGetRoom).toHaveBeenCalledTimes(1);
});
