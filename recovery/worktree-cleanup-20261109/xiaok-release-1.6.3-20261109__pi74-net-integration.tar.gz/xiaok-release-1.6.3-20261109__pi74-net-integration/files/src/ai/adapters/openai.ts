import {createOriginalModelSdkAttemptTransport,finishOriginalModelSdkAttempt} from '../runtime/original-model-sdk-attempt.js';
import type {Stream as OriginalOpenAiStream} from 'openai/core/streaming';
import { associateModelFailure, createModelProviderError, getModelFailure, type ModelFailureProvider } from '../runtime/model-failure.js';
import { isStrictKimiK3ProfileId } from '../providers/kimi-models.js';
import { getDefaultModelReasoningEffort, getSupportedModelReasoningEfforts } from '../providers/model-reasoning-effort.js';
import { resolveObservationProviderDisclosure } from '../../runtime/sol-pi/observation-execution-scope.js';
import { resolveSemanticSummaryAttempt } from '../../runtime/sol-pi/semantic-summary-attempt.js';
import { createProviderDisclosureFetch, getProviderDisclosureSignal, assertProviderDisclosureActive, disposeProviderDisclosureContext } from '../../runtime/sol-pi/provider-disclosure.js';
import OpenAI from 'openai';
import type {
  ModelAdapter,
  Message,
  ToolDefinition,
  StreamChunk,
  UsageStats,
} from '../../types.js';
import { createLogger } from '../../utils/logger.js';
import { isAbortError } from '../runtime/abort-utils.js';
import { createKimiReasoningAdmissionError, isKimiReasoningAdmissionError, KIMI_REASONING_ADMISSION_CODE } from '../runtime/kimi-reasoning-admission.js';
import { createKimiTerminalBoundaryError, isKimiTerminalBoundaryError, getKimiTerminalBoundaryDiagnostic } from '../runtime/kimi-terminal-boundary.js';
import { createOpenAIStreamError } from '../runtime/openai-stream-error.js';
import { createKimiProviderRequestError, getKimiProviderRequestDiagnostic } from '../runtime/provider-request-error.js';
import type { ModelCapabilities, StreamOptions } from '../runtime/model-capabilities.js';
import { CompactionResponseError } from '../runtime/compaction-response.js';
import { estimateTokens } from '../runtime/usage.js';
import { resolveModelRuntimeOptions } from '../providers/model-runtime-options.js';
import {
  buildOpenAIHarnessContext,
  isOwnedStrictOpenAIHarnessContext,
  observeReasoningDialect,
  type KimiUsageDiagnostic,
  type KimiUsageDiagnosticSink,
  type OpenAIAdapterInit,
  type AdapterBindingIdentity,
  type ReasoningDialectState,
} from '../providers/model-harness-profile.js';
import {
  KIMI_SCHEMA_LIMITS,
  KimiToolSchemaError,
  type KimiSchemaLimitKind,
} from '../providers/kimi-tool-schema.js';
import { getProviderProfile, resolveProviderModelVariant } from '../providers/registry.js';
import type { ModelReasoningEffort } from '../providers/types.js';
import {
  consumeProviderConversationAuthorization,
  reserveProviderConversationAuthorization,
  verifyConsumedProviderConversationAuthorizationForRetry,
  type ProviderConversationAuthorizationReservation,
} from '../runtime/provider-conversation-authorization.js';
import { assertKimiTransportAllowed } from '../runtime/kimi-rollback-policy.js';
import { applyExperimentalToolOrder, parseExperimentalToolOrder } from '../providers/experimental-tool-order.js';

const MAX_RETRIES = 3;
const STREAM_IDLE_TIMEOUT_MS = 5 * 60_000;
const RETRYABLE_STATUS = new Set([429, 500, 502, 503, 529]);
const usageLogger = createLogger('ai:openai-adapter:usage');
const ownedHarnessProfiles = new WeakMap<
  object,
  OpenAIAdapterInit['harnessContext']['profile']['id']
>();

function recordUsageDiagnostic(diagnostic: KimiUsageDiagnostic): void {
  usageLogger.info('kimiUsageDiagnostic', diagnostic);
}

function isRetryableError(error: unknown): boolean {
  if (isAbortError(error)) return false;
  if (error instanceof Error) {
    if (error.name === 'TimeoutError') return true;
    const record = error as unknown as Record<string, unknown>;
    if (record.retryable === false) return false;
    if (record.retryable === true) return true;
    const status = record.status;
    if (typeof status === 'number' && RETRYABLE_STATUS.has(status)) return true;
    const code = typeof record.code === 'string' ? record.code : '';
    if (/ERR_STREAM_PREMATURE_CLOSE|ECONNRESET|ETIMEDOUT|EPIPE|UND_ERR/i.test(code)) return true;
    if (/overload|502|503|timeout|ECONNRESET|ETIMEDOUT|EPIPE|Bad gateway|Premature close|terminated|socket hang up|network|fetch failed/i.test(error.message)) return true;
  }
  return false;
}

function abortReason(signal: AbortSignal): unknown {
  return signal.reason ?? new DOMException('The operation was aborted', 'AbortError');
}

function throwIfCallerAborted(signal?: AbortSignal): void {
  if (signal?.aborted) {
    throw abortReason(signal);
  }
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) {
    return Promise.reject(abortReason(signal));
  }

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
      reject(signal ? abortReason(signal) : new DOMException('The operation was aborted', 'AbortError'));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}
const RAW_THINK_OPEN_TAG = '<think>';
const RAW_THINK_CLOSE_TAG = '</think>';
const MAX_OPENAI_STREAM_TEXT_CHARS = 2 * 1024 * 1024;
const MAX_OPENAI_STREAM_TOOL_ARGUMENT_CHARS = 2 * 1024 * 1024;

interface ReasoningEffortRequestExtension {
  reasoning_effort: ModelReasoningEffort;
}

interface StreamAttemptState {
  latestProviderUsage?: UsageStats;
  outputChars: number;
}

interface BufferedToolCall {
  previewClosed?: boolean;
  id: string;
  name: string;
  argsBuffer: string;
  googleThoughtSignature?: import('../runtime/blocks.js').GoogleThoughtSignature;
}

/** Only the official Google transport may receive its opaque continuation state. */
function supportsGoogleThoughtSignatures(identity: AdapterBindingIdentity): boolean {
  if (identity.providerId !== 'gemini' || identity.providerType !== 'first_party'
    || identity.protocol !== 'openai_legacy' || !/^gemini-3[.-]/.test(identity.wireModel)) return false;
  try {
    const endpoint = new URL(identity.canonicalBaseUrl ?? '');
    return endpoint.origin === 'https://generativelanguage.googleapis.com'
      && endpoint.pathname.replace(/\/$/, '') === '/v1beta/openai'
      && !endpoint.username && !endpoint.password && !endpoint.search && !endpoint.hash;
  } catch { return false; }
}

function isGoogleSignature(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0 && value.length <= MAX_OPENAI_STREAM_TEXT_CHARS;
}

function openAIStreamLimitError(
  code: 'OPENAI_STREAM_TEXT_LIMIT_EXCEEDED' | 'OPENAI_STREAM_TOOL_ARGUMENT_LIMIT_EXCEEDED',
): Error & { code: string } {
  return Object.assign(new Error(code), { code });
}

function drainBufferedToolCalls(
  toolBuffers: Map<number, BufferedToolCall>,
  strictKimiK3: boolean,
): Array<Extract<StreamChunk, { type: 'tool_use' }>> {
  const calls: Array<Extract<StreamChunk, { type: 'tool_use' }>> = [];
  for (const buffer of toolBuffers.values()) {
    let input: Record<string, unknown>;
    try {
      const parsed = JSON.parse(buffer.argsBuffer || '{}') as unknown;
      if (
        strictKimiK3
        && (
          typeof parsed !== 'object'
          || parsed === null
          || Array.isArray(parsed)
          || !buffer.id
          || !buffer.name
        )
      ) {
        throw new Error('invalid strict Kimi tool call');
      }
      input = parsed as Record<string, unknown>;
    } catch {
      if (strictKimiK3) {
        throw createKimiTerminalBoundaryError({ boundaryKind: 'invalid_tool_call', sawOfficialReasoning: true, toolCallCount: toolBuffers.size });
      }
      input = { _raw: buffer.argsBuffer };
    }
    calls.push({ type: 'tool_use', id: buffer.id, name: buffer.name, input,
      ...(buffer.googleThoughtSignature ? { googleThoughtSignature: buffer.googleThoughtSignature } : {}),
    });
  }
  toolBuffers.clear();
  return calls;
}

function createStrictKimiNoRedirectFetch(): typeof globalThis.fetch {
  const fetchImpl = globalThis.fetch.bind(globalThis);
  const fetchWithoutRedirect: typeof fetch = async (input, init) => {
    const response = await fetchImpl(input, {
      ...init,
      redirect: 'manual',
    });
    if (response.status >= 300 && response.status < 400) {
      throw new Error('KIMI_K3_REDIRECT_FORBIDDEN');
    }
    return response;
  };
  return fetchWithoutRedirect;
}

function collectReasoningText(blocks: Message['content']): string | undefined {
  const reasoning = blocks
    .filter((block): block is Extract<Message['content'][number], { type: 'thinking' }> => block.type === 'thinking')
    .map((block) => block.thinking.trim())
    .filter(Boolean)
    .join('\n\n');

  return reasoning || undefined;
}

function estimateStreamUsage(
  messages: Message[],
  systemPrompt: string,
  outputChars: number,
): UsageStats {
  const allInputMessages = [
    { role: 'user' as const, content: [{ type: 'text' as const, text: systemPrompt }] },
    ...messages.map(m => ({
      role: m.role,
      content: m.content.map(b => {
        if (b.type === 'text') return { type: 'text' as const, text: b.text };
        if (b.type === 'tool_use') return { type: 'text' as const, text: JSON.stringify(b.input) };
        if (b.type === 'tool_result') return { type: 'text' as const, text: b.content };
        if (b.type === 'image') return { type: 'text' as const, text: '[image]' };
        return { type: 'text' as const, text: '' };
      }),
    })),
  ];
  return {
    inputTokens: estimateTokens(allInputMessages as unknown as Message[]),
    outputTokens: Math.ceil(outputChars / 4),
  };
}

function hasHarnessCapability(
  capabilities: readonly string[],
  expected: string,
): boolean {
  return capabilities.some(
    (capability) => capability.toLowerCase() === expected,
  );
}

function extractReasoningDeltas(
  delta: Record<string, unknown>,
  strictKimiK3 = false,
): StreamChunk[] {
  if (strictKimiK3) {
    if (
      Object.prototype.hasOwnProperty.call(delta, 'reasoning_content')
      && typeof delta.reasoning_content === 'string'
    ) {
      return [{
        type: 'thinking',
        delta: delta.reasoning_content,
        signature: 'reasoning_content',
        reasoningProvenance: {
          captureVersion: 1,
          source: 'reasoning_content',
          fieldPresence: 'present',
        },
      }];
    }
    return [];
  }

  const chunks: StreamChunk[] = [];
  const reasoningDetails = delta.reasoning_details;
  let usedReasoningDetails = false;

  if (Array.isArray(reasoningDetails)) {
    for (const item of reasoningDetails) {
      const detail = item as { type?: unknown; text?: unknown };
      if (detail.type === 'reasoning.text' && typeof detail.text === 'string' && detail.text.length > 0) {
        chunks.push({
          type: 'thinking',
          signature: 'reasoning_details',
          delta: detail.text,
        });
        usedReasoningDetails = true;
      }
    }
  }

  if (!usedReasoningDetails) {
    for (const field of ['reasoning_content', 'reasoning', 'reasoning_text', 'thinking', 'thought'] as const) {
      const value = delta[field];
      if (typeof value === 'string' && value.length > 0) {
        chunks.push({ type: 'thinking', signature: field, delta: value });
        break;
      }
    }
  }

  return chunks;
}

function wrapKimiSchemaError(
  error: KimiToolSchemaError,
  toolName: string,
): KimiToolSchemaError {
  return new KimiToolSchemaError(error.code, {
    limitKind: error.limitKind,
    toolName,
    message: error.message,
  });
}

function requestLimitError(
  limitKind: KimiSchemaLimitKind,
  toolName?: string,
): KimiToolSchemaError {
  return new KimiToolSchemaError('KIMI_SCHEMA_LIMIT_EXCEEDED', {
    limitKind,
    toolName,
    message: `Kimi tool request exceeded ${limitKind}`,
  });
}

async function runProviderOperation<T>(
  strictKimiK3: boolean,
  operation: () => Promise<T>,
  provider?: ModelFailureProvider,
): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    if (!strictKimiK3) {
      if (provider && error instanceof OpenAI.APIError && !isAbortError(error)) throw createModelProviderError(error, provider);
      // SDK SSE errors have no HTTP failure status. Exclude transport/abort
      // subclasses, preserving their original cancellation and cause semantics.
      if (error instanceof OpenAI.APIError && error.constructor === OpenAI.APIError && error.status === undefined) {
        throw createOpenAIStreamError(error);
      }
      throw error;
    }
    const sanitized = createKimiProviderRequestError(error, isRetryableError(error), error instanceof OpenAI.APIError);
    usageLogger.info('kimiProviderRequestFailed', { ...getKimiProviderRequestDiagnostic(sanitized), failure: getModelFailure(sanitized) });
    throw sanitized;
  }
}

type RawThinkParserState = {
  active: boolean;
  mode: 'outside' | 'inside';
  buffer: string;
};

type ParsedContentSegment =
  | { type: 'thinking'; delta: string; signature: 'raw_think_tag' }
  | { type: 'text'; delta: string };

function getTrailingTagPrefixLength(value: string, tag: string): number {
  const maxLength = Math.min(value.length, tag.length - 1);
  for (let length = maxLength; length > 0; length -= 1) {
    if (tag.startsWith(value.slice(-length))) {
      return length;
    }
  }
  return 0;
}

function drainLeadingRawThinkSegments(
  state: RawThinkParserState,
  chunk: string,
  force = false,
): ParsedContentSegment[] {
  state.buffer += chunk;
  const segments: ParsedContentSegment[] = [];

  while (state.buffer.length > 0) {
    if (!state.active) {
      segments.push({ type: 'text', delta: state.buffer });
      state.buffer = '';
      break;
    }

    if (state.mode === 'inside') {
      const closeIndex = state.buffer.indexOf(RAW_THINK_CLOSE_TAG);
      if (closeIndex >= 0) {
        const reasoning = state.buffer.slice(0, closeIndex);
        if (reasoning.length > 0) {
          segments.push({ type: 'thinking', delta: reasoning, signature: 'raw_think_tag' });
        }
        state.buffer = state.buffer.slice(closeIndex + RAW_THINK_CLOSE_TAG.length);
        state.mode = 'outside';
        continue;
      }

      if (force) {
        segments.push({ type: 'text', delta: `${RAW_THINK_OPEN_TAG}${state.buffer}` });
        state.buffer = '';
        state.mode = 'outside';
        state.active = false;
        break;
      }

      const carryLength = getTrailingTagPrefixLength(state.buffer, RAW_THINK_CLOSE_TAG);
      const stableReasoning = state.buffer.slice(0, state.buffer.length - carryLength);
      if (stableReasoning.length > 0) {
        segments.push({ type: 'thinking', delta: stableReasoning, signature: 'raw_think_tag' });
        state.buffer = state.buffer.slice(state.buffer.length - carryLength);
      }
      break;
    }

    const leadingWhitespace = state.buffer.match(/^\s+/)?.[0] ?? '';
    if (leadingWhitespace.length > 0) {
      state.buffer = state.buffer.slice(leadingWhitespace.length);
      if (state.buffer.length === 0) {
        break;
      }
      continue;
    }

    if (state.buffer.startsWith(RAW_THINK_OPEN_TAG)) {
      state.buffer = state.buffer.slice(RAW_THINK_OPEN_TAG.length);
      state.mode = 'inside';
      continue;
    }

    if (!force && RAW_THINK_OPEN_TAG.startsWith(state.buffer)) {
      break;
    }

    state.active = false;
    segments.push({ type: 'text', delta: state.buffer });
    state.buffer = '';
    break;
  }

  return segments;
}

export class OpenAIAdapter implements ModelAdapter {
  private clientInstance?: OpenAI;
  private createClient!: () => OpenAI;
  get client(): OpenAI { return this.clientInstance ??= this.createClient(); }
  set client(value: OpenAI) { this.clientInstance = value; }
  private readonly credentialResolver?: OpenAIAdapterInit['credentialResolver'];
  private readonly apiKey: string;
  private readonly resolvedHeaders?: Readonly<Record<string, string | null>>;
  private readonly kimiCodingHeadersApplied: boolean;
  private readonly onUsageDiagnostic: KimiUsageDiagnosticSink;
  readonly harnessContext: OpenAIAdapterInit['harnessContext'];
  private readonly experimentalToolOrder: ReturnType<typeof parseExperimentalToolOrder>;
  private reasoningDialectState: ReasoningDialectState = {
    current: 'reasoning_content',
    learned: false,
  };

  constructor(
    init: OpenAIAdapterInit,
    experimentalToolOrder = parseExperimentalToolOrder(process.env.XIAOK_EXPERIMENTAL_TOOL_ORDER),
  ) {
    assertKimiTransportAllowed(init.harnessContext.identity);
    const strictKimiK3 = init.harnessContext.profile.id !== 'generic-openai';
    if (
      strictKimiK3
      && !isOwnedStrictOpenAIHarnessContext(init.harnessContext)
    ) {
      throw new Error('KIMI_K3_PROFILE_CAPABILITY_REQUIRED');
    }
    this.apiKey = init.apiKey;
    this.credentialResolver = init.credentialResolver;
    this.resolvedHeaders = init.resolvedHeaders;
    this.kimiCodingHeadersApplied = init.kimiCodingHeadersApplied;
    this.onUsageDiagnostic = init.onUsageDiagnostic ?? recordUsageDiagnostic;
    this.harnessContext = init.harnessContext;
    this.experimentalToolOrder = experimentalToolOrder;
    ownedHarnessProfiles.set(this, init.harnessContext.profile.id);
    this.createClient = () => {
      const credentials = init.credentialResolver?.();
      return new OpenAI({
      apiKey: credentials?.apiKey ?? init.apiKey,
      baseURL: init.harnessContext.identity.canonicalBaseUrl,
      maxRetries: strictKimiK3 || init.harnessContext.identity.providerType === 'first_party' && ['glm', 'kimi'].includes(init.harnessContext.identity.providerId) ? 0 : MAX_RETRIES,
      defaultHeaders: credentials?.headers ?? init.resolvedHeaders,
      ...(strictKimiK3
        ? { fetch: createStrictKimiNoRedirectFetch() }
        : {}),
    });
    };
    if (!init.credentialResolver) this.client = this.createClient();
  }

  getModelName(): string {
    return this.harnessContext.identity.wireModel;
  }

  getHarnessProfileId(): string {
    return this.harnessContext.profile.id;
  }

  /**
   * Read-only identity view. Authorization ownership is established by the
   * concrete adapter instance, never by a caller-provided string or registrar.
   */
  getOwnedHarnessProfileId(): OpenAIAdapterInit['harnessContext']['profile']['id'] | undefined {
    return ownedHarnessProfiles.get(this);
  }

  getCapabilities(): Readonly<ModelCapabilities> {
    return this.harnessContext.runtimeCapabilities;
  }

  dispose(): void {
    // OpenAI SDK v7 uses the platform fetch transport and owns its connection
    // pooling. There is no per-client Agent handle to destroy.
  }

  cloneWithModel(newWireModel: string): OpenAIAdapter {
    const currentIdentity = this.harnessContext.identity;
    const providerProfile = currentIdentity.providerType === 'first_party'
      ? getProviderProfile(currentIdentity.providerId)
      : undefined;
    const catalogVariant = providerProfile
      ? resolveProviderModelVariant(providerProfile, newWireModel)
      : undefined;
    const runtimeOptions = newWireModel === currentIdentity.wireModel
      ? this.harnessContext.runtimeOptions
      : resolveModelRuntimeOptions({
          protocol: currentIdentity.protocol,
          baseUrl: currentIdentity.canonicalBaseUrl,
          wireModel: newWireModel,
          catalogOptions: catalogVariant?.runtimeOptions,
          catalogConstraints: catalogVariant?.runtimeConstraints,
          reasoningEfforts: getSupportedModelReasoningEfforts({ ...currentIdentity, wireModel: newWireModel, baseUrl: currentIdentity.canonicalBaseUrl }),
        }).runtimeOptions;
    const nextIdentity = {
      ...currentIdentity,
      wireModel: newWireModel,
      capabilities: catalogVariant?.capabilities
        ? [...catalogVariant.capabilities]
        : [...currentIdentity.capabilities],
    };
    const capabilityOverrides = catalogVariant
      ? undefined
      : {
          supportsPromptCaching: this.harnessContext.runtimeCapabilities.supportsPromptCaching,
          supportsImageInput: this.harnessContext.runtimeCapabilities.supportsImageInput,
        };
    const clone = new OpenAIAdapter({
      apiKey: this.apiKey,
      credentialResolver: this.credentialResolver,
      resolvedHeaders: this.resolvedHeaders,
      kimiCodingHeadersApplied: this.kimiCodingHeadersApplied,
      onUsageDiagnostic: this.onUsageDiagnostic,
      harnessContext: buildOpenAIHarnessContext({
        identity: nextIdentity,
        flags: this.harnessContext.flags,
        runtimeOptions,
        capabilityOverrides,
      }),
    }, this.experimentalToolOrder);
    if (
      clone.harnessContext.identityFingerprint
      === this.harnessContext.identityFingerprint
    ) {
      clone.reasoningDialectState = { ...this.reasoningDialectState };
    }
    return clone;
  }

  async *stream(
    messages: Message[],
    tools: ToolDefinition[],
    systemPrompt: string,
    options?: StreamOptions,
  ): AsyncIterable<StreamChunk> {
    options?.signal?.throwIfAborted();
    this.credentialResolver?.();
    const disclosure = resolveObservationProviderDisclosure(options?.providerDisclosure);
    if (disclosure !== undefined) {
      assertProviderDisclosureActive(disclosure);
      const disclosureSignal = getProviderDisclosureSignal(disclosure);
      options = { ...options, providerDisclosure: disclosure, signal: options?.signal ? AbortSignal.any([options.signal, disclosureSignal]) : disclosureSignal };
    }
    try {
    assertKimiTransportAllowed(this.harnessContext.identity);
    const profileId = this.getOwnedHarnessProfileId();
    const strictProfile = isStrictKimiK3ProfileId(profileId)
      ? profileId
      : undefined;
    if (!strictProfile && options?.providerConversationAuthorization) {
      throw new Error('KIMI_K3_AUTHORIZATION_PROFILE_MISMATCH');
    }
    const authorizationReservation: ProviderConversationAuthorizationReservation | undefined =
      strictProfile
        ? reserveProviderConversationAuthorization({
            authorization: options?.providerConversationAuthorization,
            adapter: this,
            messages,
          })
        : undefined;
    let authorizationConsumed = false;
    const authorizeDispatch = authorizationReservation
      ? () => {
          if (!authorizationConsumed) {
            consumeProviderConversationAuthorization({
              reservation: authorizationReservation,
              adapter: this,
              messages,
            });
            authorizationConsumed = true;
            return;
          }
          verifyConsumedProviderConversationAuthorizationForRetry({
            reservation: authorizationReservation,
            adapter: this,
            messages,
          });
        }
      : undefined;
    const bufferedUsage = (
      this.harnessContext.flags.normalizeUsage
      && this.harnessContext.profile.extractUsage !== undefined
    );
    let usageSourceEmitted = false;
    const reportUsageSource = (
      usageSource: Extract<KimiUsageDiagnostic, { type: 'usage_source' }>['usageSource'],
    ): void => {
      if (usageSourceEmitted) {
        return;
      }
      usageSourceEmitted = true;
      this.onUsageDiagnostic({
        type: 'usage_source',
        harnessProfileId: 'kimi-k3-coding-openai',
        usageSource,
      });
    };
    let attempt = 0;
    let admissionRetries = 0;
    while (true) {
      throwIfCallerAborted(options?.signal);
      const controller = new AbortController();
      const signal = options?.signal
        ? AbortSignal.any([controller.signal, options.signal])
        : controller.signal;
      let receivedTerminalBoundary = false;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const armIdleTimeout = () => {
        clearTimeout(timer);
        if (signal.aborted) return;
        timer = setTimeout(() => controller.abort(Object.assign(new Error('model stream idle timeout'), {
          name: 'TimeoutError', code: 'OPENAI_STREAM_IDLE_TIMEOUT', retryable: !receivedTerminalBoundary,
        })), STREAM_IDLE_TIMEOUT_MS);
      };
      armIdleTimeout();
      let emittedAny = false;
      let emittedOutput = false;
      let emittedBufferedUsage = false;
      const attemptState: StreamAttemptState = { outputChars: 0 };
      try {
        for await (const chunk of this.streamOnce(
          messages,
          tools,
          systemPrompt,
          options,
          signal,
          bufferedUsage ? attemptState : undefined,
          authorizeDispatch,
          armIdleTimeout,
          () => { receivedTerminalBoundary = true; },
        )) {
          emittedAny = true;
          if (chunk.type !== 'usage') emittedOutput = true;
          yield chunk;
        }
        if (options?.signal?.aborted) {
          throw abortReason(options.signal);
        }
        if (bufferedUsage) {
          const providerUsage = attemptState.latestProviderUsage;
          reportUsageSource(providerUsage ? 'provider' : 'estimate');
          emittedBufferedUsage = true;
          yield {
            type: 'usage',
            usage: providerUsage
              ?? estimateStreamUsage(messages, systemPrompt, attemptState.outputChars),
          };
          throwIfCallerAborted(options?.signal);
          yield { type: 'done' };
        }
        return;
      } catch (error) {
        if (disclosure !== undefined) assertProviderDisclosureActive(disclosure);
        clearTimeout(timer);
        const terminalError = options?.signal?.aborted
          ? (options.signal.reason ?? error)
          : controller.signal.aborted ? (controller.signal.reason ?? error) : error;
        const boundaryDiagnostic = getKimiTerminalBoundaryDiagnostic(terminalError);
        if (boundaryDiagnostic) usageLogger.warn('kimiTerminalBoundaryRejected', boundaryDiagnostic);
        // Only this uncommitted protocol response gets one local retry. The
        // terminal error stays non-retryable to every outer recovery owner.
        if (strictProfile && !options?.signal?.aborted && !options?.semanticSummaryAttempt
          && !emittedOutput && isKimiReasoningAdmissionError(error) && admissionRetries === 0) {
          admissionRetries += 1;
          usageLogger.warn('kimiReasoningAdmissionRetry', { code: KIMI_REASONING_ADMISSION_CODE, attempt: admissionRetries });
          if (bufferedUsage && attemptState.latestProviderUsage) {
            reportUsageSource('provider');
            yield { type: 'usage', usage: attemptState.latestProviderUsage };
          }
          continue;
        }
        // 已产出 chunk 后重试会重复输出，必须放弃重试
        if (
          options?.signal?.aborted
          || controller.signal.aborted
          || isKimiTerminalBoundaryError(error)
          || options?.semanticSummaryAttempt !== undefined
          || emittedAny
          || (getModelFailure(error)?.retryAfterMs ?? 0) > 0
          || getModelFailure(error)?.retryAfterTooLong === true
          || !isRetryableError(error)
          || attempt >= MAX_RETRIES
        ) {
          if (bufferedUsage) {
            if (attemptState.latestProviderUsage && !emittedBufferedUsage) {
              reportUsageSource('provider');
              emittedBufferedUsage = true;
              yield {
                type: 'usage',
                usage: attemptState.latestProviderUsage,
              };
              throwIfCallerAborted(options?.signal);
            } else if (!attemptState.latestProviderUsage && !emittedBufferedUsage) {
              reportUsageSource('missing_on_error');
            }
          }
          throw terminalError;
        }
        const delayMs = Math.min(1000 * 2 ** attempt, 16000);
        try {
          await sleep(delayMs, options?.signal);
        } catch (backoffError) {
          const backoffTerminalError = options?.signal?.aborted
            ? (options.signal.reason ?? backoffError)
            : backoffError;
          if (bufferedUsage) {
            if (attemptState.latestProviderUsage && !emittedBufferedUsage) {
              reportUsageSource('provider');
              emittedBufferedUsage = true;
              yield {
                type: 'usage',
                usage: attemptState.latestProviderUsage,
              };
            } else if (!attemptState.latestProviderUsage && !emittedBufferedUsage) {
              reportUsageSource('missing_on_error');
            }
          }
          throw backoffTerminalError;
        }
        attempt += 1;
      } finally {
        clearTimeout(timer);
        // Every attempt owns its transport, including successful completion.
        controller.abort();
      }
    }
    } finally { if (disclosure !== undefined) disposeProviderDisclosureContext(disclosure); }
  }

  /** Host request planning only. Strict signed transcripts have no preview path. */
  getObservationRequestPreview(
    messages: Message[], tools: ToolDefinition[], systemPrompt: string, options?: StreamOptions,
  ): { serializedBody: string; destination: string } | undefined {
    if (this.harnessContext.profile.id !== 'generic-openai' || this.harnessContext.identity.protocol !== 'openai_legacy') return undefined;
    return { serializedBody: JSON.stringify(this.buildChatRequest(messages, tools, systemPrompt, options)),
      destination: `${this.client.baseURL.replace(/\/+$/, '')}/chat/completions` };
  }

  private buildChatRequest(
    messages: Message[], tools: ToolDefinition[], systemPrompt: string, options?: StreamOptions,
  ): OpenAI.ChatCompletionCreateParamsStreaming {
    const normalizeToolSchema = this.harnessContext.profile.normalizeToolSchema;
    const shouldNormalizeToolSchemas = (
      this.harnessContext.flags.normalizeToolSchema
      && normalizeToolSchema !== undefined
      && this.harnessContext.identity.capabilities.some(
        (capability) => capability.toLowerCase() === 'tools',
      )
    );
    let openaiTools: OpenAI.ChatCompletionTool[];

    if (!shouldNormalizeToolSchemas) {
      openaiTools = tools.map((tool) => ({
        type: 'function' as const,
        function: {
          name: tool.name,
          description: tool.description,
          parameters: tool.inputSchema as Record<string, unknown>,
        },
      }));
    } else {
      if (tools.length > KIMI_SCHEMA_LIMITS.maxRequestToolCount) {
        throw requestLimitError('request_tool_count');
      }

      openaiTools = [];
      let requestInputNodes = 0;
      let requestOutputNodes = 0;
      let requestToolBytes = 0;
      for (const tool of tools) {
        let normalized;
        try {
          normalized = normalizeToolSchema(tool.inputSchema);
        } catch (error) {
          if (error instanceof KimiToolSchemaError) {
            throw wrapKimiSchemaError(error, tool.name);
          }
          throw error;
        }

        requestInputNodes += normalized.inputNodes;
        if (requestInputNodes > KIMI_SCHEMA_LIMITS.maxRequestInputNodes) {
          throw requestLimitError('request_input_nodes', tool.name);
        }
        requestOutputNodes += normalized.outputNodes;
        if (requestOutputNodes > KIMI_SCHEMA_LIMITS.maxRequestOutputNodes) {
          throw requestLimitError('request_output_nodes', tool.name);
        }
        requestToolBytes += normalized.outputBytes;
        if (requestToolBytes > KIMI_SCHEMA_LIMITS.maxRequestToolBytes) {
          throw requestLimitError('request_tool_bytes', tool.name);
        }

        openaiTools.push({
          type: 'function' as const,
          function: {
            name: tool.name,
            description: tool.description,
            parameters: normalized.schema,
          },
        });
      }
    }

    const openaiMessages: OpenAI.ChatCompletionMessageParam[] = [
      { role: 'system', content: systemPrompt },
    ];

    for (const m of messages) {
      if (m.role === 'assistant') {
        const textBlocks = m.content.filter((block) => block.type === 'text');
        const toolUseBlocks = m.content.filter((block) => block.type === 'tool_use');
        const text = textBlocks.map((block) => block.text).join('');
        const shouldOmitContent = (
          this.harnessContext.flags.omitEmptyAssistantContent
          && this.harnessContext.profile.shouldOmitAssistantContent !== undefined
          && hasHarnessCapability(
            this.harnessContext.identity.capabilities,
            'tools',
          )
          && this.harnessContext.profile.shouldOmitAssistantContent({
            hasToolCalls: toolUseBlocks.length > 0,
            text,
          })
        );

        const msg: OpenAI.ChatCompletionAssistantMessageParam & {
          reasoning_content?: string;
          reasoning?: string;
        } = {
          role: 'assistant',
        };
        if (!shouldOmitContent) {
          msg.content = textBlocks.length > 0
            ? text
            : (toolUseBlocks.length > 0 ? null : '');
        }

        if (toolUseBlocks.length > 0) {
          msg.tool_calls = toolUseBlocks.map((block) => ({
            id: block.id,
            type: 'function' as const,
            function: {
              name: block.name,
              arguments: JSON.stringify(block.input),
            },
            ...(supportsGoogleThoughtSignatures(this.harnessContext.identity)
              && block.googleThoughtSignature?.model === this.harnessContext.identity.wireModel
              && isGoogleSignature(block.googleThoughtSignature.signature)
              ? { extra_content: { google: { thought_signature: block.googleThoughtSignature.signature } } }
              : {}),
          }));
        }

        const serializeReasoning = this.harnessContext.profile.serializeReasoning;
        if (serializeReasoning) {
          const preservedThinkingEnabled = (
            this.harnessContext.profile.id !== 'generic-openai'
            || (
              this.harnessContext.flags.preservedThinking
              && hasHarnessCapability(
                this.harnessContext.identity.capabilities,
                'thinking',
              )
            )
          );
          if (preservedThinkingEnabled) {
            const serialized = serializeReasoning(
              m.content,
              this.reasoningDialectState.current,
              true,
            );
            if (serialized) {
              msg[serialized.field] = serialized.value;
            }
          }
        } else {
          const reasoningContent = collectReasoningText(m.content);
          if (reasoningContent) {
            msg.reasoning_content = reasoningContent;
          }
        }

        openaiMessages.push(msg);
        continue;
      }

      const toolResults = m.content.filter((block) => block.type === 'tool_result');
      const previousMessage = openaiMessages[openaiMessages.length - 1];
      const pendingToolCallIds = previousMessage?.role === 'assistant'
        ? new Set(previousMessage.tool_calls?.map((call) => call.id) ?? [])
        : new Set<string>();
      const orphanToolResults = [];
      for (const item of toolResults) {
        if (pendingToolCallIds.has(item.tool_use_id)) {
          openaiMessages.push({
            role: 'tool' as const,
            tool_call_id: item.tool_use_id,
            content: item.content,
          });
          pendingToolCallIds.delete(item.tool_use_id);
        } else {
          orphanToolResults.push(item);
        }
      }

      const textBlocks = [
        ...m.content.filter((block) => block.type === 'text'),
        ...orphanToolResults.map((item) => ({
          type: 'text' as const,
          text: `[historical orphan tool result: ${item.tool_use_id}]\n${item.content}`,
        })),
      ];
      const imageBlocks = m.content.filter((block) => block.type === 'image');
      if (imageBlocks.length > 0 && this.getCapabilities().supportsImageInput) {
        const contentParts = [
          ...textBlocks.map((block) => ({
            type: 'text' as const,
            text: block.text,
          })),
          ...imageBlocks.map((block) => ({
            type: 'image_url' as const,
            image_url: {
              url: `data:${block.source.media_type};base64,${block.source.data}`,
            },
          })),
        ];

        openaiMessages.push({
          role: 'user',
          content: contentParts,
        } as OpenAI.ChatCompletionUserMessageParam);
      } else if (textBlocks.length > 0 || imageBlocks.length > 0) {
        openaiMessages.push({
          role: 'user',
          content: [
            ...textBlocks.map((block) => block.text),
            ...imageBlocks.map((block) => `\n[Image omitted from this request (${block.source.media_type}): current model does not support image input. Original image retained in session history.]\n`),
          ].join(''),
        });
      }

    }

    const request: OpenAI.ChatCompletionCreateParamsStreaming = {
      model: this.harnessContext.identity.wireModel,
      messages: openaiMessages,
      tools: openaiTools.length > 0
        ? applyExperimentalToolOrder(openaiTools, this.experimentalToolOrder, this.harnessContext, this.client.baseURL)
        : undefined,
      stream: true,
      stream_options: { include_usage: true },
    };
    if (options?.semanticSummaryOutputTokens !== undefined) {
      const maximum = options.semanticSummaryOutputTokens;
      if (!Number.isSafeInteger(maximum) || maximum < 1 || maximum > 8192 || tools.length
        || this.harnessContext.profile.id !== 'generic-openai'
        || this.harnessContext.identity.wireModel !== 'deepseek-flash'
        || !['https://api.deepseek.com', 'https://api.deepseek.com/v1'].includes(this.client.baseURL.replace(/\/+$/, ''))) {
        throw new Error('SEMANTIC_SUMMARY_OUTPUT_LIMIT_INVALID');
      }
      request.max_tokens = maximum;
    }

    if (options?.maxOutputTokens !== undefined) {
      const official = new URL(this.harnessContext.identity.canonicalBaseUrl ?? 'https://api.openai.com/v1').hostname === 'api.openai.com';
      Object.assign(request, official ? { max_completion_tokens: options.maxOutputTokens } : { max_tokens: options.maxOutputTokens });
    }
    const endpoint = new URL(this.harnessContext.identity.canonicalBaseUrl ?? 'https://api.openai.com/v1');
    const memoryThinkingDisabled = options?.reasoningMode === 'disabled'
      && this.harnessContext.profile.id === 'generic-openai'
      && endpoint.protocol === 'https:' && endpoint.hostname === 'api.deepseek.com';
    if (memoryThinkingDisabled) Object.assign(request, { thinking: { type: 'disabled' } });
    const cacheKey = options?.cacheKey;
    if (
      this.harnessContext.flags.promptCacheKey
      && this.harnessContext.profile.encodeCacheKey
      && typeof cacheKey === 'string'
      && /^pc1_[0-9a-f]{64}$/.test(cacheKey)
    ) {
      Object.assign(
        request,
        this.harnessContext.profile.encodeCacheKey(cacheKey),
      );
    }

    const identity = this.harnessContext.identity;
    const supportedEfforts = getSupportedModelReasoningEfforts({ ...identity, baseUrl: identity.canonicalBaseUrl });
    const selectedEffort = this.harnessContext.runtimeOptions?.reasoningEffort
      ?? getDefaultModelReasoningEffort(supportedEfforts);
    if (!memoryThinkingDisabled && selectedEffort && supportedEfforts.includes(selectedEffort)) {
      Object.assign(request, { reasoning_effort: selectedEffort } satisfies ReasoningEffortRequestExtension);
    }

    return request;
  }

  private async *streamOnce(
    messages: Message[],
    tools: ToolDefinition[],
    systemPrompt: string,
    options?: StreamOptions,
    signal?: AbortSignal,
    attemptState?: StreamAttemptState,
    authorizeDispatch?: () => void,
    onProgress?: () => void,
    onTerminalBoundary?: () => void,
  ): AsyncIterable<StreamChunk> {
    const request = this.buildChatRequest(messages, tools, systemPrompt, options);

    const strictKimiK3 = this.harnessContext.profile.id !== 'generic-openai';
    const semantic = options?.semanticSummaryAttempt === undefined ? undefined : resolveSemanticSummaryAttempt(options.semanticSummaryAttempt);
    if ((options?.semanticSummaryOutputTokens !== undefined && !semantic)
      || semantic && (strictKimiK3 || request.max_tokens !== semantic.maxOutputTokens || tools.length)) {
      throw new Error('SEMANTIC_SUMMARY_ATTEMPT_REQUIRED');
    }
    const modelPhysical=createOriginalModelSdkAttemptTransport(signal,options?.providerDisclosure,undefined,semantic?.modelTransport);
    let originalFailure:{raw:unknown}|undefined;
    try {
    const transport = modelPhysical?.fetch ?? semantic?.fetch ?? globalThis.fetch.bind(globalThis);
    const guardedFetch = options?.providerDisclosure ? createProviderDisclosureFetch(options.providerDisclosure, transport) : transport;
    const client = semantic || modelPhysical ? this.client.withOptions({ fetch: guardedFetch, maxRetries: 0 })
      : options?.providerDisclosure ? this.client.withOptions({ fetch: guardedFetch }) : this.client;
    authorizeDispatch?.();
    const identity = this.harnessContext.identity;
    const diagnosticProvider: ModelFailureProvider | undefined = identity.providerType === 'first_party' && (identity.providerId === 'glm' || identity.providerId === 'kimi') ? identity.providerId : undefined;
    const stream = await runProviderOperation(
      strictKimiK3,
      () => {
        return modelPhysical
          ? modelPhysical.createOpenAI(client,request) as Promise<OriginalOpenAiStream<OpenAI.Chat.Completions.ChatCompletionChunk>>
          : client.chat.completions.create(request, { signal });
      },
      diagnosticProvider,
    );

    const toolBuffers = new Map<number, BufferedToolCall>();
    const rawThinkParser: RawThinkParserState = {
      active: true,
      mode: 'outside',
      buffer: '',
    };
    let emittedDone = false;
    let incompleteSummary = false;
    let terminalDiagnostic: Error | undefined, terminalSummaryFailure: CompactionResponseError | undefined;
    let threwTerminalSummary = false;
    let outputChars = 0;
    let streamTextChars = 0;
    let usageReceived = false;
    let officialReasoningSeen = false;
    let pendingAdmissionText = '';
    let lastToolProgressAt = Date.now();
    const extractBufferedUsage = attemptState
      ? this.harnessContext.profile.extractUsage
      : undefined;

    const streamIterator = stream[Symbol.asyncIterator]();
    try {
      while (true) {
        signal?.throwIfAborted();
        const iteration = await runProviderOperation(
          strictKimiK3,
          () => streamIterator.next(),
          diagnosticProvider,
        );
        // The SDK can turn its own transport abort into EOF. Do not drain an
        // interrupted argument buffer or report successful completion from it.
        signal?.throwIfAborted();
        if (iteration.done) {
          break;
        }
        const chunk = iteration.value;
        if (extractBufferedUsage && attemptState) {
          const usage = extractBufferedUsage(
            chunk as unknown as Record<string, unknown>,
            this.onUsageDiagnostic,
          );
          if (usage) {
            attemptState.latestProviderUsage = usage;
          }
        } else if (chunk.usage) {
          // Generic baseline keeps inline usage emission.
          usageReceived = true;
          yield {
            type: 'usage',
            usage: {
              inputTokens: chunk.usage.prompt_tokens ?? 0,
              outputTokens: chunk.usage.completion_tokens ?? 0,
            },
          };
          throwIfCallerAborted(options?.signal);
        }

        if ((attemptState || options?.requireCompleteResponse) && emittedDone) {
          if (options?.requireCompleteResponse && chunk.choices.some(choice => choice.finish_reason != null
            || Object.values(choice.delta ?? {}).some(value => value != null && value !== '' && !(Array.isArray(value) && value.length === 0)))) incompleteSummary = true;
          continue;
        }

        const choice = chunk.choices[0];
        if (!choice) continue;
        // Some compatible providers omit delta on the metadata-only finish frame.
        const delta = choice.delta ?? {};
        if (
          strictKimiK3
          && Object.prototype.hasOwnProperty.call(delta, 'reasoning_content')
          && typeof (delta as Record<string, unknown>).reasoning_content === 'string'
        ) {
          officialReasoningSeen = true;
        }

        if (this.harnessContext.profile.serializeReasoning) {
          const observation = observeReasoningDialect(
            this.reasoningDialectState,
            delta as Record<string, unknown>,
          );
          if (observation.conflict) {
            console.warn('reasoningDialectConflict', observation.conflict);
          }
        }

        for (const reasoning of extractReasoningDeltas(
          delta as Record<string, unknown>,
          strictKimiK3,
        )) {
          if (reasoning.type !== 'thinking') {
            continue;
          }
          if (reasoning.delta.length > 0) onProgress?.();
          streamTextChars += reasoning.delta.length;
          if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
            await streamIterator.return?.();
            throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
          }
          yield reasoning;
        }

        if (strictKimiK3 && !officialReasoningSeen) {
          // Never publish possible private reasoning from an invalid dialect.
          if (delta.content) {
            onProgress?.();
            if (pendingAdmissionText.length + delta.content.length > MAX_OPENAI_STREAM_TEXT_CHARS) {
              throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
            }
            pendingAdmissionText += delta.content;
          }
        } else if (delta.content || pendingAdmissionText) {
          if (delta.content) onProgress?.();
          const content = pendingAdmissionText + (delta.content ?? '');
          pendingAdmissionText = '';
          for (const segment of drainLeadingRawThinkSegments(rawThinkParser, content)) {
            if (segment.type === 'thinking') {
              streamTextChars += segment.delta.length;
              if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
                await streamIterator.return?.();
                throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
              }
              if (!strictKimiK3) {
                yield segment;
              }
              continue;
            }
            streamTextChars += segment.delta.length;
            if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
              await streamIterator.return?.();
              throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
            }
            outputChars += segment.delta.length;
            if (attemptState) {
              attemptState.outputChars = outputChars;
            }
            yield segment;
          }
        }

        if (delta.tool_calls) {
          for (const tc of delta.tool_calls) {
            const current: BufferedToolCall = toolBuffers.get(tc.index) ?? { id: '', name: '', argsBuffer: '' };
            if (supportsGoogleThoughtSignatures(this.harnessContext.identity)) {
              const signature = (tc as unknown as { extra_content?: { google?: { thought_signature?: unknown } } })
                .extra_content?.google?.thought_signature;
              if (isGoogleSignature(signature)) current.googleThoughtSignature = {
                model: this.harnessContext.identity.wireModel, signature,
              };
            }
            if (tc.id) current.id = tc.id;
            if (tc.function?.name) current.name = tc.function.name;
            if (tc.function?.arguments) {
              onProgress?.();
              if (
                current.argsBuffer.length + tc.function.arguments.length
                > MAX_OPENAI_STREAM_TOOL_ARGUMENT_CHARS
              ) {
                await streamIterator.return?.();
                throw openAIStreamLimitError('OPENAI_STREAM_TOOL_ARGUMENT_LIMIT_EXCEEDED');
              }
              current.argsBuffer += tc.function.arguments;
            }
            toolBuffers.set(tc.index, current);
            if (current.name === 'render_ui' && tools.some(tool=>tool.name==='render_ui') && current.id && !current.previewClosed && current.argsBuffer.length > 1_000_000 && (!strictKimiK3 || officialReasoningSeen)) {
              current.previewClosed = true; yield {type:'ui_preview',id:current.id,input:'',invalid:true};
            }
            if (current.name === 'render_ui' && tools.some(tool=>tool.name==='render_ui') && current.id && !current.previewClosed && current.argsBuffer.length <= 1_000_000
              && tc.function?.arguments?.includes('}') && (!strictKimiK3 || officialReasoningSeen)) {
              yield { type: 'ui_preview', id: current.id, input: current.argsBuffer };
            }
            if (tc.function?.arguments && (!strictKimiK3 || officialReasoningSeen)
              && Date.now() - lastToolProgressAt >= 1000) {
              lastToolProgressAt = Date.now();
              yield { type: 'tool_input_progress' };
            }
          }
        }

        if (choice?.finish_reason) {
          const finish = String(choice.finish_reason);
          if (finish === 'content_filter' || diagnosticProvider === 'glm' && ['sensitive', 'network_error'].includes(finish)) {
            const failure = createModelProviderError({ error: { code: finish === 'network_error' ? '1234' : diagnosticProvider === 'glm' ? '1301' : 'content_filter' } }, diagnosticProvider ?? 'other');
            if (!options?.requireCompleteResponse) throw failure;
            terminalDiagnostic ??= failure;
            emittedDone = true;
            continue;
          }
          if (!options?.requireCompleteResponse && options?.maxOutputTokens !== undefined && choice.finish_reason === 'length') {
            await streamIterator.return?.();
            throw new Error('memory_output_incomplete');
          }
          if (strictKimiK3 && !officialReasoningSeen) {
            throw createKimiReasoningAdmissionError({ sawContent: pendingAdmissionText.length > 0, sawTools: toolBuffers.size > 0, terminal: 'finish' });
          }
          for (const segment of drainLeadingRawThinkSegments(rawThinkParser, '', true)) {
            if (segment.type === 'thinking') {
              streamTextChars += segment.delta.length;
              if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
                await streamIterator.return?.();
                throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
              }
              if (!strictKimiK3) {
                yield segment;
              }
              continue;
            }
            streamTextChars += segment.delta.length;
            if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
              await streamIterator.return?.();
              throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
            }
            outputChars += segment.delta.length;
            if (attemptState) {
              attemptState.outputChars = outputChars;
            }
            yield segment;
          }

          const completedCalls = drainBufferedToolCalls(toolBuffers, strictKimiK3);
          onTerminalBoundary?.();
          for (const toolCall of completedCalls) {
            yield toolCall;
          }

          if (options?.requireCompleteResponse) {
            incompleteSummary = choice.finish_reason !== 'stop';
            emittedDone = true;
            continue;
          }
          if (attemptState) {
            emittedDone = true;
            continue;
          }

          // If the API didn't return usage, estimate locally
          if (!usageReceived) {
            yield {
              type: 'usage',
              usage: estimateStreamUsage(messages, systemPrompt, outputChars),
            };
            throwIfCallerAborted(options?.signal);
          }

          emittedDone = true;
          yield { type: 'done' };
          return;
        }
      }

      if (options?.requireCompleteResponse) {
        if (terminalDiagnostic) {
          terminalSummaryFailure = new CompactionResponseError('provider_incomplete', { cause: terminalDiagnostic });
          const diagnostic = getModelFailure(terminalDiagnostic);
          if (diagnostic) associateModelFailure(terminalSummaryFailure, diagnostic);
          threwTerminalSummary = true;
          throw terminalSummaryFailure;
        }
        if (!emittedDone || incompleteSummary) throw new CompactionResponseError('provider_incomplete');
        if (!attemptState) {
          if (!usageReceived) yield { type: 'usage', usage: estimateStreamUsage(messages, systemPrompt, outputChars) };
          throwIfCallerAborted(options.signal);
          yield { type: 'done' };
        }
        return;
      }
      if (!emittedDone) {
        if (strictKimiK3) {
          if (toolBuffers.size === 0) {
            throw createKimiTerminalBoundaryError({ boundaryKind: 'missing_finish', sawOfficialReasoning: officialReasoningSeen, toolCallCount: 0 });
          }
          if (!officialReasoningSeen) {
            throw createKimiReasoningAdmissionError({ sawContent: pendingAdmissionText.length > 0, sawTools: toolBuffers.size > 0, terminal: 'eof' });
          }
          for (const toolCall of drainBufferedToolCalls(toolBuffers, true)) {
            yield toolCall;
          }
          if (attemptState) {
            return;
          }
          if (!usageReceived) {
            yield {
              type: 'usage',
              usage: estimateStreamUsage(messages, systemPrompt, outputChars),
            };
            throwIfCallerAborted(options?.signal);
          }
          yield { type: 'done' };
          return;
        }
        for (const segment of drainLeadingRawThinkSegments(rawThinkParser, '', true)) {
          if (segment.type === 'thinking') {
            streamTextChars += segment.delta.length;
            if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
              await streamIterator.return?.();
              throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
            }
            yield segment;
            continue;
          }
          streamTextChars += segment.delta.length;
          if (streamTextChars > MAX_OPENAI_STREAM_TEXT_CHARS) {
            await streamIterator.return?.();
            throw openAIStreamLimitError('OPENAI_STREAM_TEXT_LIMIT_EXCEEDED');
          }
          outputChars += segment.delta.length;
          if (attemptState) {
            attemptState.outputChars = outputChars;
          }
          yield segment;
        }

        if (!usageReceived) {
          yield {
            type: 'usage',
            usage: estimateStreamUsage(messages, systemPrompt, outputChars),
          };
          throwIfCallerAborted(options?.signal);
        }

        // EOF is not a provider terminal boundary. In particular, never dispatch
        // buffered tools from a response the provider did not finish committing.
        throw Object.assign(new Error('OpenAI stream ended before finish_reason'), {
          code: 'ERR_STREAM_PREMATURE_CLOSE',
        });
      }
    } catch (error) {
      if (terminalDiagnostic && !threwTerminalSummary) {
        const failure = new CompactionResponseError('provider_incomplete', { cause:
          new AggregateError([terminalDiagnostic, error], 'compaction_provider_and_late_failure', { cause: terminalDiagnostic }) });
        const diagnostic = getModelFailure(terminalDiagnostic);
        if (diagnostic) associateModelFailure(failure, diagnostic);
        throw failure;
      }
      throw error;
    } finally {
      // finish_reason is a semantic boundary, not HTTP EOF. A suspended SDK
      // iterator retains the Response, request body and abort listener.
      stream.controller?.abort();
      try { await streamIterator.return?.(); }
      catch { /* Cleanup must not replace the provider/consumer outcome. */ }
    }
    } catch(raw) {originalFailure={raw};throw raw;}
    finally {await finishOriginalModelSdkAttempt(modelPhysical,originalFailure);}
  }
}
