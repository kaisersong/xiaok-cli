import type { SkillMeta } from '../ai/skills/loader.js';
import { CHAT_REMINDER_SLASH_COMMANDS } from './chat-reminder.js';
import { getDisplayWidth } from '../ui/text-metrics.js';

export interface ChatCommandMetadata {
  id: string;
  cmd: string;
  slashDesc: string;
  helpLine: string;
  showInSlash: boolean;
  showInHelp: boolean;
}

const BASE_CHAT_COMMANDS: ChatCommandMetadata[] = [
  {
    id: 'version', cmd: '/version', slashDesc: '查看版本与详细构建信息',
    helpLine: '  /version - 查看版本、构建信息与实际入口', showInSlash: true, showInHelp: true,
  },
  {
    id: 'statusline', cmd: '/statusline', slashDesc: '打开状态栏菜单，勾选字段、排序和预览',
    helpLine: '  /statusline - 菜单配置底部状态栏', showInSlash: true, showInHelp: true,
  },
  {
    id: 'exit',
    cmd: '/exit',
    slashDesc: '退出当前对话',
    helpLine: '  /exit    - 退出',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'clear',
    cmd: '/clear',
    slashDesc: '清屏并重新显示欢迎页',
    helpLine: '  /clear   - 清屏',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'compact',
    cmd: '/compact',
    slashDesc: '压缩较早对话，减少上下文占用',
    helpLine: '  /compact - 压缩上下文',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'goal',
    cmd: '/goal',
    slashDesc: '创建、查看、暂停、恢复、取消或替换当前 Goal',
    helpLine: '  /goal <objective>|status|pause|resume|cancel|replace - 管理持续执行 Goal',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'context',
    cmd: '/context',
    slashDesc: '查看当前自动加载的仓库上下文',
    helpLine: '  /context - 查看当前仓库上下文',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'models',
    cmd: '/models',
    slashDesc: '打开模型选择器',
    helpLine: '  /models  - 切换模型',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'mode',
    cmd: '/mode',
    slashDesc: '设置权限模式',
    helpLine: '  /mode    - 选择并切换权限模式',
    showInSlash: true,
    showInHelp: true,
  },
  ...CHAT_REMINDER_SLASH_COMMANDS.map((command): ChatCommandMetadata => ({
    id: command.cmd.slice(1),
    cmd: command.cmd,
    slashDesc: command.desc,
    helpLine: command.helpLine,
    showInSlash: true,
    showInHelp: true,
  })),
  {
    id: 'settings',
    cmd: '/settings',
    slashDesc: '查看当前生效配置',
    helpLine: '  /settings - 查看当前生效配置',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'skills-reload',
    cmd: '/skills-reload',
    slashDesc: '强制刷新 skill 目录（通常不需要，默认会自动热更新）',
    helpLine: '  /skills-reload - 强制刷新 skill 目录（通常不需要，默认会自动热更新）',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'skill-debug',
    cmd: '/skill-debug',
    slashDesc: '切换 stage 执行调试输出（显示 intent 分析、context 检查、耗时）',
    helpLine: '  /skill-debug [on|off] - 切换 stage 执行调试输出',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'yzjchannel',
    cmd: '/yzjchannel',
    slashDesc: '连接嵌入式云之家 channel',
    helpLine: '  /yzjchannel - 连接云之家 channel（嵌入式，关闭 chat 即断开）',
    showInSlash: true,
    showInHelp: true,
  },
  {
    id: 'help',
    cmd: '/help',
    slashDesc: '查看可用命令和 skills',
    helpLine: '  /help    - 显示帮助',
    showInSlash: true,
    showInHelp: true,
  },
];

export function listChatCommandMetadata(): ChatCommandMetadata[] {
  return [...BASE_CHAT_COMMANDS];
}

export function getChatSlashCommands(): Array<{ cmd: string; desc: string }> {
  return listChatCommandMetadata()
    .filter((command) => command.showInSlash)
    .map((command) => ({ cmd: command.cmd, desc: command.slashDesc }));
}

export function getChatHelpLines(): string[] {
  return listChatCommandMetadata()
    .filter((command) => command.showInHelp)
    .map((command) => command.helpLine);
}

export function buildChatHelpText(skills: SkillMeta[]): string {
  const lines = ['', '可用命令：'];
  const commands = getChatHelpLines();
  const width = process.stdout.columns ?? 80;
  const columnWidth = Math.floor((width - 4) / 2);
  for (let index = 0; index < commands.length; index++) {
    const line = commands[index];
    const next = commands[index + 1];
    const padding = ' '.repeat(Math.max(0, columnWidth - getDisplayWidth(line)));
    const pair = next ? `${line}${padding}    ${next.trim()}` : line;
    if (next && getDisplayWidth(line) <= columnWidth && getDisplayWidth(pair) <= width - 2) {
      lines.push(pair);
      index++;
    } else {
      lines.push(line);
    }
  }
  if (skills.length > 0) {
    lines.push('', '可用 skills：');
    for (const skill of skills) {
      lines.push(`  /${skill.name} - ${skill.description}`);
    }
  }
  return lines.join('\n');
}
