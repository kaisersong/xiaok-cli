/**
 * AskUserQuestion tool — CC-compatible interactive multi-choice prompt.
 * The AI calls this tool to present the user with a structured question
 * and get back their selection.
 */

import type { Tool } from '../../types.js';
import { askQuestion, type AskQuestionParams } from '../../ui/ask-question.js';

export interface AskUserQuestionToolOptions {
  interactive?: boolean;
  onEnterInteractive?: () => void;
  onExitInteractive?: () => void;
  renderFrame?: (lines: string[]) => boolean | void;
  clearFrame?: () => void;
  readText?: AskQuestionParams['readText'];
  writeTranscript?: AskQuestionParams['writeTranscript'];
}

export function createAskUserQuestionTool(options: AskUserQuestionToolOptions = {}): Tool {
  return {
    permission: 'safe',
    executionPolicy: { waitsForUser: true },
    definition: {
      name: 'AskUserQuestion',
      description: `${options.interactive === false ? 'Unavailable in this non-interactive CLI: no user answer can be collected. Do the work without optional delegation or report the missing decision.\n\n' : ''}Use this tool when you need to ask the user questions during execution. This allows you to:
1. Gather user preferences or requirements
2. Clarify ambiguous instructions
3. Get decisions on implementation choices as you work
4. Offer choices to the user about what direction to take.

Usage notes:
- Users will always be able to select "Other" to provide custom text input
- Use multiSelect: true to allow multiple answers to be selected for a question
- If you recommend a specific option, make that the first option in the list and add "(Recommended)" at the end of the label

IMPORTANT: Ask before execution when a material scope or cost tradeoff needs the user's decision, or when the user explicitly requested ask-first behavior. Do not ask for routine delegation of clear independent tasks. Never batch the question with the proposed delegation; wait for a real answer. Empty answers and cancellation are not approval. For friction or minor obstacles, investigate and try reasonable approaches before asking.`,
      inputSchema: {
        type: 'object',
        properties: {
          questions: {
            type: 'array',
            description: 'List of questions to ask (1-4)',
            items: {
              type: 'object',
              properties: {
                header:      { type: 'string', description: 'Short chip label (max 12 chars)' },
                question:    { type: 'string', description: 'The question text' },
                multiSelect: { type: 'boolean', description: 'Allow multiple selections' },
                options: {
                  type: 'array',
                  description: '2-4 options',
                  items: {
                    type: 'object',
                    properties: {
                      label:       { type: 'string' },
                      description: { type: 'string' },
                      preview:     { type: 'string', description: 'Optional preview content (markdown/code)' },
                    },
                    required: ['label'],
                  },
                },
              },
              required: ['question', 'options'],
            },
          },
        },
        required: ['questions'],
      },
    },
    async execute(input, context) {
      if (options.interactive === false) {
        return 'Error: AskUserQuestion requires an interactive terminal; no answer was provided. Continue without optional delegation, or report the missing user decision.';
      }
      const questions = input.questions as Array<{
        header?: string;
        question: string;
        multiSelect?: boolean;
        options: Array<{ label: string; description?: string; preview?: string }>;
      }>;

      if (!Array.isArray(questions) || questions.length === 0) {
        return 'Error: questions 不能为空';
      }

      const answers: Record<string, string> = {};

      for (const q of questions.slice(0, 4)) {
        if (!q.question || !Array.isArray(q.options) || q.options.length < 2) continue;

        options.onEnterInteractive?.();
        let result: Awaited<ReturnType<typeof askQuestion>>;
        try {
          result = await askQuestion({
            header: q.header,
            question: q.question,
            options: q.options,
            multiSelect: q.multiSelect ?? false,
            renderFrame: options.renderFrame,
            clearFrame: options.clearFrame,
            readText: options.readText,
            writeTranscript: options.writeTranscript,
            signal: context?.signal,
          });
        } finally {
          options.onExitInteractive?.();
        }

        const answerText = [...result.labels, result.otherText]
          .filter((value): value is string => Boolean(value))
          .join(', ');

        answers[q.question] = answerText;
      }

      return JSON.stringify({ answers });
    },
  };
}
