/**
 * Interactive question prompt — CC-style AskUserQuestion for the terminal.
 *
 * Renders:
 *   - Header chip + question text
 *   - Numbered option list with ❯ highlight (left column)
 *   - Optional preview panel (right column, shown when focused option has preview)
 *   - Multi-select support (Space to toggle, Enter to confirm)
 *   - "Other" free-text input option appended unless the caller supplied one
 *
 * Usage:
 *   const answer = await askQuestion({
 *     header: 'Auth method',
 *     question: 'Which auth method?',
 *     options: [
 *       { label: 'JWT', description: 'Stateless tokens', preview: '```ts\njwt.sign()\n```' },
 *       { label: 'Session', description: 'Server-side sessions' },
 *     ],
 *     multiSelect: false,
 *   });
 */

import { boldCyan, dim, bold, cyan } from './render.js';
import { getDisplayWidth } from './display-width.js';
import { MarkdownRenderer } from './markdown.js';
import { sliceByDisplayColumns, stripAnsi } from './text-metrics.js';
import { InputReader } from './input.js';
import { pauseInputForHandoff } from './input-mode.js';

export interface AskOption {
  label: string;
  description?: string;
  preview?: string;
}

export interface AskQuestionParams {
  header?: string;
  question: string;
  options: AskOption[];
  multiSelect?: boolean;
  renderFrame?: (lines: string[]) => boolean | void;
  clearFrame?: () => void;
  readText?: (question: string, signal?: AbortSignal) => Promise<string | null>;
  writeTranscript?: (text: string) => void;
  signal?: AbortSignal;
}

export interface AskQuestionResult {
  selected: number[];       // indices into options (not including "Other")
  labels: string[];         // label strings of selected options
  otherText?: string;       // filled if user chose "Other"
}

// ─── ANSI helpers ────────────────────────────────────────────────────────────

const RESET   = '\x1b[0m';
const BG_SEL  = '\x1b[48;5;238m';   // selected row background
const FG_DIM  = '\x1b[2m';
const FG_BOLD_CYAN = '\x1b[1;36m';
const FG_RESET = '\x1b[22;39m';

function chip(text: string): string {
  return `\x1b[48;5;238m\x1b[1;37m □ ${text} ${RESET}`;
}

function truncatePlainLine(text: string, width: number): string {
  if (getDisplayWidth(text) <= width) {
    return text;
  }
  return `${sliceByDisplayColumns(text, 0, Math.max(0, width - 1))}…`;
}

function isOtherOption(option: AskOption): boolean {
  return /^(?:other|其他|其它)(?:\b|[（(]|$)/iu.test(option.label.trim());
}

function withFallbackOther(options: AskOption[]): { allOptions: AskOption[]; otherIdx: number } {
  const explicitOtherIdx = options.findIndex(isOtherOption);
  if (explicitOtherIdx >= 0) {
    return { allOptions: [...options], otherIdx: explicitOtherIdx };
  }
  return {
    allOptions: [...options, { label: 'Other', description: 'Enter custom text' }],
    otherIdx: options.length,
  };
}

// ─── Renderer ────────────────────────────────────────────────────────────────

function renderFrame(
  params: AskQuestionParams,
  selectedIdx: number,
  checked: Set<number>,
  cols: number,
  numberInput = '',
): string[] {
  const { allOptions } = withFallbackOther(params.options);
  const hasPreview = allOptions.some((o) => o.preview);
  const leftWidth = hasPreview ? Math.floor(cols * 0.45) : cols - 2;
  const rightWidth = hasPreview ? cols - leftWidth - 3 : 0;

  const lines: string[] = [];

  // Header chip (no blank spacer so short terminals keep the options visible)
  if (params.header) {
    lines.push(chip(params.header));
  }

  // Question (indent to align with the option list)
  lines.push(`  ${bold(params.question)}`);

  // If has preview, add boxTop as a separate line above options
  if (hasPreview) {
    const innerWidth = rightWidth - 2;
    const boxTop = `┌${'─'.repeat(innerWidth)}┐`;
    lines.push(' '.repeat(leftWidth + 3) + dim(boxTop));
  }

  // Build option lines and preview content lines
  const innerWidth = rightWidth - 2;
  const previewText = hasPreview ? (allOptions[selectedIdx]?.preview ?? '') : '';
  const previewLines = previewText
    ? MarkdownRenderer.renderToLines(previewText).filter((l) => l !== '')
    : [];

  for (let i = 0; i < allOptions.length; i++) {
    const opt = allOptions[i];
    const isSelected = i === selectedIdx;
    const isChecked = checked.has(i);
    const prefix = isSelected ? `${FG_BOLD_CYAN}❯${FG_RESET}` : ' ';
    const num = dim(`${i + 1}.`);
    const checkMark = params.multiSelect ? (isChecked ? `${FG_BOLD_CYAN}✓${FG_RESET} ` : '  ') : '';
    const labelStr = isSelected ? `${FG_BOLD_CYAN}${opt.label}${RESET}` : opt.label;
    const descStr = opt.description ? `  ${FG_DIM}${opt.description}${RESET}` : '';
    const checkText = params.multiSelect ? (isChecked ? '✓ ' : '  ') : '';
    const plainLeftContent = `  ${isSelected ? '❯' : ' '} ${i + 1}. ${checkText}${opt.label}${opt.description ? `  ${opt.description}` : ''}`;

    // Left side: option
    let leftContent = `  ${prefix} ${num} ${checkMark}${labelStr}${descStr}`;
    const leftVisible = `  ${isSelected ? '❯' : ' '} ${i + 1}. ${checkMark.replace(/\x1b\[[^m]*m/g, '')}${opt.label}${opt.description ? '  ' + opt.description : ''}`;
    const leftPad = Math.max(0, leftWidth - getDisplayWidth(leftVisible));

    if (isSelected && hasPreview) {
      leftContent = `${BG_SEL}${leftContent}${' '.repeat(leftPad)}${RESET}`;
    } else {
      leftContent = leftContent + ' '.repeat(leftPad);
    }

    if (!hasPreview) {
      lines.push(truncatePlainLine(plainLeftContent, leftWidth));
    } else {
      // Right side: preview content (or empty)
      const pl = previewLines[i] ?? '';
      const visibleWidth = getDisplayWidth(stripAnsi(pl));
      let rightContent = pl;
      if (visibleWidth > innerWidth) {
        // Truncate
        let w = 0;
        let cut = 0;
        for (const ch of stripAnsi(pl)) {
          const cw = getDisplayWidth(ch);
          if (w + cw > innerWidth - 1) break;
          w += cw;
          cut++;
        }
        rightContent = stripAnsi(pl).slice(0, cut) + dim('…');
      }
      const rightPad = Math.max(0, innerWidth - getDisplayWidth(stripAnsi(rightContent)));
      lines.push(`${leftContent}   ${dim('│')}${rightContent}${' '.repeat(rightPad)}${dim('│')}`);
    }
  }

  // If has preview, add boxBottom as a separate line below options
  if (hasPreview) {
    const boxBottom = `└${'─'.repeat(innerWidth)}┘`;
    lines.push(' '.repeat(leftWidth + 3) + dim(boxBottom));
  }

  // Footer hint
  const numberHint = allOptions.length <= 9
    ? `1-${allOptions.length} ${params.multiSelect ? 'toggle' : 'select'}`
    : `Number + Enter ${params.multiSelect ? 'toggle' : 'select'}${numberInput ? ` (${numberInput})` : ''}`;
  if (params.multiSelect) {
    lines.push(dim(`  ${numberHint}   ↑↓   Space   Enter confirm`));
  } else {
    lines.push(dim(`  ${numberHint}   ↑↓   Enter`));
  }

  return lines;
}

function countRenderedTerminalRows(lines: string[], cols: number): number {
  const safeCols = Math.max(1, cols);
  return lines.reduce((total, line) => (
    total + Math.max(1, Math.ceil(getDisplayWidth(stripAnsi(line)) / safeCols))
  ), 0);
}

// ─── Main function ────────────────────────────────────────────────────────────

export async function askQuestion(params: AskQuestionParams): Promise<AskQuestionResult> {
  params.signal?.throwIfAborted();
  const { allOptions, otherIdx } = withFallbackOther(params.options);
  let directPromptStarted = false;

  const selection = await new Promise<{selected: number[]; wantsOther: boolean} | null>((resolve, reject) => {
    const stdout = process.stdout;
    const cols = stdout.columns ?? 80;
    let selectedIdx = 0;
    let numberInput = '';
    const checked = new Set<number>();
    let renderedRowCount = 0;
    let externallyRendered = false;
    let settled = false;

    function clearFrame() {
      if (externallyRendered) {
        params.clearFrame?.();
        externallyRendered = false;
        renderedRowCount = 0;
        return;
      }
      if (renderedRowCount > 0) {
        if (renderedRowCount > 1) {
          stdout.write(`\x1b[${renderedRowCount - 1}A`);
        }
        stdout.write('\r');
        for (let i = 0; i < renderedRowCount; i++) {
          stdout.write('\x1b[2K');
          if (i < renderedRowCount - 1) {
            stdout.write('\x1b[1B\r');
          }
        }
        if (renderedRowCount > 1) {
          stdout.write(`\x1b[${renderedRowCount - 1}A`);
        }
        stdout.write('\r');
      }
    }

    function draw() {
      clearFrame();
      const terminalCols = stdout.columns ?? cols;
      const frameLines = renderFrame(params, selectedIdx, checked, terminalCols, numberInput);
      renderedRowCount = countRenderedTerminalRows(frameLines, terminalCols);
      if (params.renderFrame) {
        const handled = params.renderFrame(frameLines);
        if (handled !== false) {
          externallyRendered = true;
          return;
        }
      }
      externallyRendered = false;
      if (!directPromptStarted) {
        stdout.write('\n');
        directPromptStarted = true;
      }
      // Write lines without trailing newline — cursor stays on last line
      stdout.write(frameLines.join('\n'));
    }

    function cleanup() {
      process.stdin.removeListener('data', onKey);
      process.stdin.removeListener('end', onEnd);
      params.signal?.removeEventListener('abort', onAbort);
      pauseInputForHandoff();
      clearFrame();
    }

    function finish(result: {selected: number[]; wantsOther: boolean} | null, error?: unknown) {
      if (settled) return;
      settled = true;
      try {
        cleanup();
        if (error !== undefined) reject(error);
        else resolve(result);
      } catch (cleanupError) {
        reject(error ?? cleanupError);
      }
    }

    function onAbort() {
      finish(null, params.signal?.reason ?? new DOMException('Aborted', 'AbortError'));
    }

    function onEnd() { finish(null); }

    function confirmSelection() {
      if (params.multiSelect && checked.size === 0) checked.add(selectedIdx);
      const wantsOther = params.multiSelect ? checked.has(otherIdx) : selectedIdx === otherIdx;
      const selected = params.multiSelect ? [...checked].filter(i => i !== otherIdx) : (wantsOther ? [] : [selectedIdx]);
      finish({selected, wantsOther});
    }

    function chooseIndex(index: number) {
      selectedIdx = index;
      numberInput = '';
      if (params.multiSelect) {
        if (checked.has(index)) checked.delete(index);
        else checked.add(index);
        draw();
      } else confirmSelection();
    }

    function onKey(data: string | Buffer) {
      if (settled) return;
      const raw = typeof data === 'string' ? data : data.toString('utf8');
      // stdin may coalesce numeric choices, arrows and Enter. Keep escape
      // parameters and CRLF atomic, and preserve buffered-number validation.
      const keys = raw.match(/\x1b(?:\[[0-?]*[ -/]*(?:[@-~]|$)|O[0-?]*[ -/]*(?:[@-~]|$))|\r\n|\d+|[ \r\n\x1b\x03\x7f\x08]/g) ?? [];
      if (keys.join('') !== raw) return;
      const UP    = '\x1b[A';
      const DOWN  = '\x1b[B';
      const ENTER = '\r';
      const SPACE = ' ';
      const CTRL_C = '\x03';
      const ESC   = '\x1b';

      for (const key of keys) {
        if (settled) break;
        if (key === CTRL_C || key === ESC) {
          finish(null);
          return;
        }

        try {
          if (key === UP) {
            numberInput = '';
            selectedIdx = (selectedIdx - 1 + allOptions.length) % allOptions.length;
            draw();
          } else if (key === DOWN) {
            numberInput = '';
            selectedIdx = (selectedIdx + 1) % allOptions.length;
            draw();
          } else if (key === SPACE && params.multiSelect) {
            chooseIndex(selectedIdx);
          } else if (allOptions.length > 9 && (key === '\x7f' || key === '\x08')) {
            numberInput = numberInput.slice(0, -1);
            draw();
          } else if (/^\d+$/.test(key)) {
            if (allOptions.length <= 9) {
              for (const digit of key) {
                const number = Number(digit);
                if (number > 0 && number <= allOptions.length) chooseIndex(number - 1);
                if (settled) break;
              }
            } else {
              const candidate = numberInput + key;
              if (!candidate.startsWith('0') && candidate.length <= String(allOptions.length).length) {
                numberInput = candidate;
                draw();
              }
            }
          } else if (key === ENTER || key === '\n' || key === '\r\n') {
            if (numberInput) {
              const index = Number(numberInput) - 1;
              if (index >= 0 && index < allOptions.length) chooseIndex(index);
            } else {
              confirmSelection();
            }
          }
        } catch (error) { finish(null, error); }
      }
    }

    process.stdin.on('data', onKey);
    process.stdin.on('end', onEnd);
    params.signal?.addEventListener('abort', onAbort, {once:true});
    try {
      process.stdin.setRawMode?.(true);
      process.stdin.resume();
      if (!settled) draw();
    } catch (error) { finish(null, error); }
  });
  params.signal?.throwIfAborted();
  if (!selection) return {selected:[],labels:[]};

  const {selected, wantsOther} = selection;
  const labels = selected.map(i => allOptions[i]!.label);
  const writeTranscript = params.writeTranscript ?? ((text: string) => { process.stdout.write(text); });
  // A direct menu already reserved its leading gap before the first draw.
  // Footer overlays do not write into history, so reserve the gap on commit.
  const questionText = `${directPromptStarted ? '' : '\n'}${boldCyan('❯')} ${bold(params.question)}\n`;
  if (wantsOther) {
    writeTranscript(questionText);
    const text = await (params.readText
      ? params.readText(params.question, params.signal)
      : new InputReader().read('Enter your answer: ', {signal:params.signal}));
    params.signal?.throwIfAborted();
    if (text === null) return {selected:[],labels:[]};
    writeTranscript('\n');
    return {selected,labels,otherText:text};
  }
  writeTranscript(questionText + labels.map(label => `  ${dim('·')} ${cyan(label)}\n`).join('') + '\n');
  return {selected,labels};
}
