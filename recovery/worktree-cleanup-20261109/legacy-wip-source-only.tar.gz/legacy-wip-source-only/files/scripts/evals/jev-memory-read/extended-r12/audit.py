"""Free read-only audit. Does not import a provider, config, or real memory store."""
import collections, hashlib, json, pathlib, math
base=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def require(ok,label):
    if not ok: raise AssertionError(label)
    checks.append(label)
runs=[]
for d in sorted((base/'results').iterdir()):
    if not (d/'freeze.json').exists(): continue
    f=json.loads((d/'freeze.json').read_text());r=json.loads((d/'results.json').read_text())
    for name,digest in f['sources'].items():require(sha((d/'source-snapshot'/name).read_bytes())==digest,str(d.name)+':snapshot:'+name)
    corpus=json.loads((d/'corpus.json').read_text());gold=json.loads((d/'gold.json').read_text());ids={c['id'] for c in corpus}
    require(len(ids)==len(corpus),d.name+':unique_task_ids')
    require(ids=={g['id'] for g in gold},d.name+':gold_ids_match')
    for c in corpus:
        require(all(k not in c for k in ['gold','expected','requiredIds']),d.name+':public_corpus_no_gold:'+c['id'])
        require(all(e['id'] in {x['id'] for x in c['records']} for e in c['events']),d.name+':source_event_records:'+c['id'])
    calls=[call for row in r['rows'] for call in row['calls']]
    require(len(calls)==r['paidAttempts'],d.name+':attempt_count')
    if f['mode']=='offline':require(len(calls)==0,d.name+':zero_remote_calls')
    runs.append({'name':d.name,'mode':f['mode'],'status':r['status'],'tasks':len(corpus),'preflight':len(r['preflight']),'attempts':len(calls),'answers':sum(x.get('kind')=='answer' and x.get('status')=='ok' for x in calls),'unknownUsage':sum(x.get('inputTokens') is None or x.get('outputTokens') is None for x in calls),'freezeSHA':sha((d/'freeze.json').read_bytes()),'resultsSHA':sha((d/'results.json').read_bytes())})
d=base/'results/offline-validation-v3';f=json.loads((d/'freeze.json').read_text());r=json.loads((d/'results.json').read_text());corpus=json.loads((d/'corpus.json').read_text());
require(len(corpus)==60,'validation_60_tasks');require(len({x['family'] for x in corpus})==6,'validation_6_families')
require(set(x['family'] for x in corpus).isdisjoint(set(x['family'] for x in json.loads((base/'results/offline-dev-v2/corpus.json').read_text()))),'dev_scene_profile_disjoint_not_grammar_disjoint')
by=collections.defaultdict(list)
for x in r['preflight']:by[x['bucket']].append(x)
require(len(by)==10 and all(len(v)==6 for v in by.values()),'ten_buckets_six_each')
require(all(not x['initialMetrics']['allEvidenceCovered'] for x in by['multihop']),'all_multihop_initial_missing_link')
require(all(x['ruleMetrics']['allEvidenceCovered'] and x['ruleDepth']>=2 for x in by['multihop']),'actual_rule_graph_depth_ge2_and_coverage')
require(all(x['ruleMetrics']['allEvidenceCovered'] and x['allReachableMetrics']['allEvidenceCovered'] for x in r['preflight']),'B_G_60_source_coverage_only')
require(sum(x['poolChars']>1600 for x in r['preflight'])==12,'twelve_total_candidate_pool_over_budget')
pos={a:[0]*5 for a in ['V','B','G','C','D']};cd=collections.Counter()
for s in f['schedule']:
    for i,a in enumerate(s['arms']):pos[a][i]+=1
    cd['C_first' if s['arms'].index('C')<s['arms'].index('D') else 'D_first']+=1
require(all(v==[12]*5 for v in pos.values()),'each_arm_position_twelve')
require(cd=={'C_first':30,'D_first':30},'C_D_pair_order_30_each')
for start in range(0,60,10):
    window=f['schedule'][start:start+10]
    for arm in pos:
        require([sum(s['arms'][i]==arm for s in window) for i in range(5)]==[2]*5,f'window_{start}_{arm}_positions')
    require(sum(s['arms'].index('C')<s['arms'].index('D') for s in window)==5,f'window_{start}_pair_order')
main={x['caseId']:x for x in r['preflight']}
require(sum(len(s['ablations']) for s in f['schedule'])==24,'24_predefined_fixed_depth_ablation_rows')
m=json.loads((base/'clarification-v4/task-family-grammar-map.json').read_text());require(len(m['tasks'])==70,'all_70_tasks_hierarchy_mapped')
for task in m['tasks']:
    require(task['structuralGrammarFamily']=='r12-event-v2/'+task['bucket'] and task['sharedEventGrammarWithDevelopment'] and task['seed']['kind']=='deterministic_no_rng','map_shared_grammar_deterministic:'+task['taskId'])
source_by_scene={}
for fam in sorted({x['family'] for x in r['preflight']}):
    group=[x for x in r['preflight'] if x['family']==fam]
    source_by_scene[fam]={'taskInstances':len(group),'initialSourceCoverage':sum(x['initialMetrics']['allEvidenceCovered'] for x in group),'VSourceCoverage':sum(x['productionBudgetMetrics']['allEvidenceCovered'] for x in group),'BSourceCoverage':sum(x['ruleMetrics']['allEvidenceCovered'] for x in group),'GSourceCoverage':sum(x['allReachableMetrics']['allEvidenceCovered'] for x in group),'modelQuality':'not_evaluated','modelTimeUSD':'not_evaluated'}
out={'scope':'free_audit_only_no_new_quality_or_performance','checksPassed':len(checks),'runs':runs,'validation':{'taskInstances':60,'sceneProfiles':6,'eventGrammarFamilies':10,'developmentSharesAll10EventGrammars':True,'buckets':{b:{'n':len(v),'initialFullCoverage':sum(x['initialMetrics']['allEvidenceCovered'] for x in v),'VFullCoverage':sum(x['productionBudgetMetrics']['allEvidenceCovered'] for x in v),'BFullCoverage':sum(x['ruleMetrics']['allEvidenceCovered'] for x in v),'GFullCoverage':sum(x['allReachableMetrics']['allEvidenceCovered'] for x in v),'graphRuleDepths':[x['ruleDepth'] for x in v],'totalPoolOverBudget':sum(x['poolChars']>1600 for x in v),'initialJudgmentPoolOverBudget':sum(x['initialChars']>1600 for x in v)} for b,v in by.items()},'armPositions':pos,'C_DOrder':dict(cd),'bySceneProfile':source_by_scene,'leaveOneSceneProfileOutSourceCoverageOnly':{fam:{'remainingTaskInstances':sum(x['family']!=fam for x in r['preflight']),'BSourceCoverage':sum(x['family']!=fam and x['ruleMetrics']['allEvidenceCovered'] for x in r['preflight']),'GSourceCoverage':sum(x['family']!=fam and x['allReachableMetrics']['allEvidenceCovered'] for x in r['preflight']),'modelQualityTimeUSD':'not_evaluated'} for fam in source_by_scene},'independenceCaveat':'same-grammar new tasks; crossed 6 scene profiles/10 bucket grammars shared with development; no 0/60 production binomial inference'},'modelQualityVerified':False,'providerCostsVerified':False,'remoteCallsFromAudit':0,'productionEditsFromAudit':0,'checks':checks}
print(json.dumps(out,ensure_ascii=False,indent=2))
