"""Offline audit of existing synthetic traces; no provider calls or memory access."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "diagnostic-r8"
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wire_bytes(value):
    return len(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode())


rounds = {}
unknown = []
attempts = 0
totals = dict(input=0, output=0, deepseekHit=0, deepseekMiss=0,
              deepseekOutput=0, jevInput=0, jevOutput=0, knownFeeLowUSD=0., knownFeeHighUSD=0.)
source_hashes = {}
for path in sorted((ROOT / "results").glob("*/results.json")):
    data = json.loads(path.read_text())
    source_hashes[str(path.relative_to(ROOT))] = sha(path)
    if not data.get("rows"):
        continue
    arms = {}
    for row in data["rows"]:
        a = arms.setdefault(row["arm"], dict(rows=0, originalPass=0, wallMs=0.,
            inputKnown=0, outputKnown=0, usageUnknownCalls=0, retrievalMs=0.,
            selectorMs=0., answerMs=0., stages={}, knownFeeLowUSD=0., knownFeeHighUSD=0.))
        a["rows"] += 1
        a["originalPass"] += bool(row.get("evaluation", {}).get("pass"))
        a["wallMs"] += row.get("wallMs", 0)
        for field in ["retrievalMs", "selectorMs", "answerMs"]:
            a[field] += row.get(field, 0)
        for call in row.get("calls", []):
            attempts += 1
            stage = a["stages"].setdefault(call["kind"], dict(wallMs=0., inputKnown=0, outputKnown=0, unknown=0))
            stage["wallMs"] += call["wallMs"]
            if call.get("inputTokens") is None or call.get("outputTokens") is None:
                a["usageUnknownCalls"] += 1
                stage["unknown"] += 1
                unknown.append(dict(round=path.parent.name, rowId=row["id"],
                    provider=call["provider"], kind=call["kind"], status=call["status"],
                    wallMs=call["wallMs"], requestBytes=wire_bytes(call["request"]),
                    maxOutputRequested=call["request"].get("max_tokens"),
                    feeUSD=None, usage=None))
                continue
            inp, out = call["inputTokens"], call["outputTokens"]
            a["inputKnown"] += inp
            a["outputKnown"] += out
            stage["inputKnown"] += inp
            stage["outputKnown"] += out
            totals["input"] += inp
            totals["output"] += out
            if call["provider"] == "jev":
                totals["jevInput"] += inp
                totals["jevOutput"] += out
                low = high = inp * .042 / 1_000_000
            else:
                hit = call["usage"].get("prompt_cache_hit_tokens")
                miss = call["usage"].get("prompt_cache_miss_tokens")
                assert isinstance(hit, int) and isinstance(miss, int) and hit + miss == inp
                totals["deepseekHit"] += hit
                totals["deepseekMiss"] += miss
                totals["deepseekOutput"] += out
                low = (hit * .022 + miss * .66 + out * 1.98) / 1_000_000
                high = 2 * low
            a["knownFeeLowUSD"] += low
            a["knownFeeHighUSD"] += high
            totals["knownFeeLowUSD"] += low
            totals["knownFeeHighUSD"] += high
    rounds[path.parent.name] = arms

r7_path = ROOT / "results/live-holdout-r7/results.json"
r7 = json.loads(r7_path.read_text())
diagnoses = []
for row in r7["rows"]:
    if row["arm"] != "D":
        continue
    call = next(c for c in row["calls"] if c["provider"] == "jev")
    candidates = call["request"]["state"]["candidates"]
    mapping = []
    for key, question in call["request"]["questions"].items():
        match = re.search(r"candidates\[(\d+)\]", question["instructions"])
        assert match
        index = int(match.group(1))
        assert candidates[index]["id"] == key
        mapping.append(dict(id=key, index=index, instructions=question["instructions"],
            text=candidates[index]["text"], probability=call["response"]["answers"][key]["noul"]))
    assert row["finalInput"]["evidence"] == [c for key in row["selectedIds"] for c in candidates if c["id"] == key]
    diagnoses.append(dict(rowId=row["id"], status=row["status"], mappingValid=True,
        candidateMetrics=row["candidateMetrics"], selectedIds=row["selectedIds"],
        selectedMetrics=row["selectedMetrics"], threshold=.4, fallback=row["fallback"],
        selectionBudget=dict(maxEntries=6, maxChars=2400, truncation=False),
        mapping=mapping, request=call["request"], actualResponse=call["response"],
        stateBytes=wire_bytes(call["request"]["state"]), questionsBytes=wire_bytes(call["request"]["questions"]),
        selectorInput=call["inputTokens"], selectorOutput=call["outputTokens"],
        finalInput=row["finalInput"], finalAnswer=row["answer"], evaluation=row["evaluation"]))

status = subprocess.check_output(["git", "status", "--porcelain=v1", "-z"], cwd=ROOT).decode()
external = Path("/tmp/jev-mem-memory-audit")
external_hashes = {str(p.relative_to(external)): sha(p) for p in sorted(external.rglob("*")) if p.is_file()}
result = dict(kind="offline_contract_diagnostic_not_holdout_benefit", additionalPaidRequests=0,
    head=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
    statusSHA256=hashlib.sha256(status.encode()).hexdigest(), originalSourceHashes=source_hashes,
    externalCommit="7ab0c73c6d8f4f611ad252c1e6ba8083f8df0e44", externalReadOnlyFileHashes=external_hashes,
    rounds=rounds, totals=totals, attempts=attempts, knownUsageCalls=attempts-len(unknown),
    unknownUsageCalls=unknown, diagnoses=diagnoses,
    positionEffect="not_causally_tested", pricing=dict(currency="USD", unit="per million tokens",
        deepseekCacheHitRange=[.022,.044], deepseekCacheMissRange=[.66,1.32],
        deepseekOutputRange=[1.98,3.96], jevInput=.042, jevOutput=0,
        note="Official peak/off-peak scenario estimates, not invoice. Unknown attempts add an unknown nonnegative fee; no verified finite upper bound."),
    currentConclusion="The frozen all-candidate hard-filter fails quality and token gates; not a reproduction or rejection of Jev-Mem.")
dest = OUT / "analysis.json"
dest.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
lines = ["|轮次|组|原判通过/已跑|完整 wall 秒|input 已知|output 已知|total 已知|未知 usage 次数|已知费用区间 USD|",
         "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
for name, arms in rounds.items():
    for arm, a in sorted(arms.items()):
        suffix = '+未知' if a['usageUnknownCalls'] else ''
        lines.append(f"|{name}|{arm}|{a['originalPass']}/{a['rows']}|{a['wallMs']/1000:.3f}|{a['inputKnown']}{suffix}|{a['outputKnown']}{suffix}|{a['inputKnown']+a['outputKnown']}{suffix}|{a['usageUnknownCalls']}|{a['knownFeeLowUSD']:.8f}–{a['knownFeeHighUSD']:.8f}{suffix}|")
(OUT / "ledger.md").write_text("\n".join(lines) + "\n")
print(json.dumps({k:result[k] for k in ["attempts","knownUsageCalls","unknownUsageCalls","totals","additionalPaidRequests"]},ensure_ascii=False,indent=2))
