"""Render existing synthetic experiment evidence; never contacts any service."""
import json, pathlib, statistics, random, argparse
p=argparse.ArgumentParser();p.add_argument('directories',nargs='+');p.add_argument('--output',required=True);a=p.parse_args()
lines=['# notebook_read 中文隔离实验：验证结果','', '本报告仅关于合成记忆的检索→筛选→结构化最终回答路径，不是完整 agent 工具循环，也不证明真实用户语料收益。用户记忆与生产配置未读取/修改。', '', 'A：原 notebook 逻辑，单关键词检索、默认10条，无筛选；B：共同候选架构+规则；C：共同候选架构+DeepSeek；D：共同候选架构+Jev。正式四臂共同本地BGE、warm query条件，A0另为默认缺MiniLM的免费参考。候选改善、正文恢复、去重、scope权限、预算全部是B/C/D共同架构，不能归于Jev。评测器为确定性gold校验，0远程judge调用与费用；计时在final响应解析后截止，gold校验耗时单列。', '']
for directory in a.directories:
 dpath=pathlib.Path(directory);d=json.loads((dpath/'results.json').read_text());f=json.loads((dpath/'freeze.json').read_text());rows=d['rows'];pre=d['preflight']
 lines += [f'## {dpath.name}', '',f"状态：`{d['status']}`；冻结 `{f['fingerprint']}`；HEAD `{f['head']}`；{f['split']} {f['caseCount']}题×{f['repeats']}重复。停止原因：{d.get('stopReason','无')}。",'',f"预检：{len(pre)}题，B/C/D候选完整覆盖 {sum(x['BCD_candidates']['allEvidenceCovered'] for x in pre)}/{len(pre)}；B规则完整覆盖 {sum(x['B']['allEvidenceCovered'] for x in pre)}/{len(pre)}；B/C/D候选scope泄露 {sum(len(x['BCD_candidates']['scopeLeaks']) for x in pre)}。原始结果与冻结在同名evidence子目录，包含全部候选、实际注入、API request/response、供应商usage、失败与回退。",'']
 if not rows:lines += ['本轮没有远程模型调用；无法评价模型质量、任务时间或token收益。',''];continue
 lines += ['|组|完成/通过|平均完整任务秒|总input|总output|总token|回退|选中gold完整覆盖|scope泄露|','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
 for arm in 'ABCD':
  rs=[r for r in rows if r['arm']==arm];known=all(r.get('tokens',{}).get('total') is not None for r in rs)
  totals=[sum(r['tokens'][k] for r in rs) if known else None for k in ['input','output','total']];times=[r['wallMs']/1000 for r in rs if 'wallMs' in r]
  lines.append(f"|{arm}|{len(rs)}/{sum(r.get('evaluation',{}).get('pass',False) for r in rs)}|{statistics.mean(times):.3f}"+''.join(f'|{v}' for v in totals)+f"|{sum(r.get('fallback',False) for r in rs)}|{sum(r.get('selectedMetrics',{}).get('allEvidenceCovered',False) for r in rs)}/{len(rs)}|{sum(len(r.get('selectedMetrics',{}).get('scopeLeaks',[])) for r in rs)}|") if times else None
 lines+=['','### 全部失败与回退','']
 failures=[r for r in rows if r['status']!='pass' or r.get('fallback')]
 for r in failures:lines.append(f"- `{r['id']}`：{r['status']}；fallback={r.get('fallback',False)}；reason={r.get('fallbackReason','无')}；gold判定={json.dumps(r.get('evaluation'),ensure_ascii=False)}。")
 if not failures:lines.append('无。')
 recheck=dpath/'development-evaluation-recheck.json'
 if recheck.exists():
  rc=json.loads(recheck.read_text());lines += ['','### 开发评测器事后复核（原判定保留）','', '旧exact-value格式误拒绝了带主语/动词的原文事实。新规则在holdout前冻结；本复核只针对既存开发响应，无新增模型调用。']
  for arm in 'ABCD':
   rr=[r for r in rc['rows'] if r['arm']==arm];lines.append(f"- {arm}：原判定 {sum(r['original']['pass'] for r in rr)}/{len(rr)}；grounded-span复核 {sum(r['rechecked']['pass'] for r in rr)}/{len(rr)}。")
 lines+=['','### 配对结果','']
 for base in ['A','B','C']:
  by={(r['caseId'],r['rep'],r['arm']):r for r in rows};pairs=[]
  for r in rows:
   b=by.get((r['caseId'],r['rep'],base))
   if r['arm']=='D' and b and r.get('tokens',{}).get('total') is not None and b.get('tokens',{}).get('total') is not None:pairs.append((r,b))
  if not pairs:continue
  for key in ['wallMs','input','output','total']:
   val=lambda r:r[key] if key=='wallMs' else r['tokens'][key]
   dv=sum(val(r) for r,b in pairs);bv=sum(val(b) for r,b in pairs);delta=(dv/bv-1)*100 if bv else 0
   groups={}
   for r,b in pairs:groups.setdefault(r['caseId'],[]).append((val(r),val(b)))
   rng=random.Random(20261005);ids=list(groups);boot=[]
   if len(ids)>1:
    for _ in range(2000):
     picked=[groups[rng.choice(ids)] for x in ids];ds=sum(x for g in picked for x,y in g);bs=sum(y for g in picked for x,y in g);boot.append((ds/bs-1)*100 if bs else 0)
    boot.sort();ci=f'；95%按题cluster bootstrap区间 [{boot[int(len(boot)*.025)]:.2f}%, {boot[int(len(boot)*.975)]:.2f}%]'
   else:ci='；题数不足，无区间'
   lines.append(f'- D 相对 {base} `{key}`：{delta:+.2f}%（{len(pairs)}配对）{ci}。')
  lines.append(f"- D/{base}配对质量：D {sum(r.get('evaluation',{}).get('pass',False) for r,b in pairs)}/{len(pairs)}，{base} {sum(b.get('evaluation',{}).get('pass',False) for r,b in pairs)}/{len(pairs)}。")
 lines+=['','### 单任务证据','', '|任务|状态|完整秒|input/output|gold覆盖|fallback|','|---|---|---:|---:|---|---|']
 for r in rows:lines.append(f"|{r['id']}|{r['status']}|{r.get('wallMs',0)/1000:.3f}|{r.get('tokens',{}).get('input')}/{r.get('tokens',{}).get('output')}|{r.get('selectedMetrics',{}).get('allEvidenceCovered')}|{r.get('fallback',False)}|")
 lines+=['']
lines+=['## 验收与未验证','', '本轮采用固定停止条件；已见开发案例修订不作为未见证据。仅当未见质量保持、D相对B/C完整时间和总token均至少下降5%，且配对区间支持，才考虑进入真实脱敏语料阶段。合成样本无论结果如何都不能称生产release ready。真实用户语料、自由生成任务、完整agent工具重试链、冷启动、其它供应商/版本均未验证。既存hygiene失败不更新baseline。']
pathlib.Path(a.output).write_text('\n'.join(lines)+'\n')
