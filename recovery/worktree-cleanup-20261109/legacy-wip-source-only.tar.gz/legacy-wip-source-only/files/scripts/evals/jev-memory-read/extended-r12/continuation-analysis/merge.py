"""Combine immutable r12 traces after continuation exits. No model calls."""
import collections, copy, hashlib, json, pathlib, subprocess, sys

base = pathlib.Path(__file__).resolve().parents[1]
old_dir = base / 'results/live-validation-v4'
new_dir = base / 'results/continuation-live-v1'
out_dir = base / 'results/continuation-aggregate-v1'
load = lambda p: json.loads(p.read_text())
old, new = load(old_dir/'results.json'), load(new_dir/'results.json')
new_freeze = load(new_dir/'freeze.json')
assert new['status'] == 'live_complete', 'runner has not completed'
assert new['completedRows'] == 84 and new['pendingIntent'] is None
for name, digest in new_freeze['originalHashes'].items():
    assert hashlib.sha256((old_dir/name).read_bytes()).hexdigest() == digest
key = lambda r: (r['caseId'], r['arm'])
assert not {key(r) for r in old['rows']} & {key(r) for r in new['rows']}
assert [key(r) for r in new['rows']] == [key(j) for j in new_freeze['plan']['jobs']]
rows = [{**copy.deepcopy(r), 'phase':'original'} for r in old['rows']] + copy.deepcopy(new['rows'])
assert len(rows) == 324 and len({key(r) for r in rows}) == 324
corpus = load(old_dir/'corpus.json')
main = ['V','B','G','C','D']
complete = [c['id'] for c in corpus if all(any(r['caseId']==c['id'] and r['arm']==arm and r['status']!='started' for r in rows) for arm in main)]
interruption = {
    'originalRunnerLost':True,
    'interruptedRows':[{'caseId':r['caseId'],'arm':r['arm'],'knownReturnedCalls':len(r['calls']), 'outcome':'unknown', 'possibleUnrecordedCallAndFee':'unknown'} for r in rows if r['status']=='started'],
    'unknownOutcomeIsNotQualityFailure':True,
    'allKnownUsageFeesAreLowerBoundsIncludingPossibleUnrecordedCall':True,
    'noOriginalStartedRowReissued':True,
}
out_dir.mkdir(exist_ok=False)
write = lambda p,x: p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
result = {**copy.deepcopy(old), 'status':'continuation_complete_with_original_interruption',
          'scope':'r12 original 60-task plan; never-started continuation complete; one original C unknown',
          'rows':rows,'completedCaseIds':complete,
          'unexecutedCaseIds':[c['id'] for c in corpus if c['id'] not in complete],
          'paidAttempts':old['paidAttempts']+new['returnedAttempts'],
          'executionInterruption':interruption}
write(out_dir/'results.json',result)
for name in ['freeze.json','corpus.json','gold.json']:
    (out_dir/name).write_bytes((old_dir/name).read_bytes())
write(out_dir/'provenance.json',{'kind':'derived aggregate; source files never modified','originalHashes':new_freeze['originalHashes'],
      'continuationHashes':{n:hashlib.sha256((new_dir/n).read_bytes()).hexdigest() for n in ['results.json','freeze.json','corpus.json','gold.json']},
      'executionInterruption':interruption, 'completeFiveArmTasks':len(complete), 'allPlannedTasks':len(corpus)})
subprocess.run([sys.executable,str(base/'analyze.py'),str(out_dir),'--output',str(out_dir/'analysis.json')],check=True)
analysis=load(out_dir/'analysis.json')
analysis['executionInterruption']=interruption
analysis['completedTasksMeaning']='59 fully finalized five-arm cases; original interrupted C task remains in planned population'
# Preserve unknown outcomes in every quality view. Do not classify unknown as a loss.
def repair_quality(contrasts, selected_rows):
    for label, contrast in contrasts.items():
        left,right=label.split('/')
        lm={r['caseId']:r for r in selected_rows if r['arm']==left}; rm={r['caseId']:r for r in selected_rows if r['arm']==right}
        pairs=[(lm[k],rm[k]) for k in lm.keys() & rm.keys()]
        known=[(l,r) for l,r in pairs if l['status']!='started' and r['status']!='started']
        b=sum(l['status']=='pass' and r['status']!='pass' for l,r in known)
        c=sum(r['status']=='pass' and l['status']!='pass' for l,r in known)
        contrast['qualityPairsKnown']=len(known); contrast['qualityPairsUnknown']=len(pairs)-len(known)
        contrast['qualityLeftOnlyPass']=b; contrast['qualityRightOnlyPass']=c
        contrast.pop('mcnemarExactIIDReferenceOnly',None)
        contrast['qualityInference']='descriptive paired counts; unknown excluded; shared grammar; no equivalence claim'
repair_quality(analysis['comparisons'],rows)
for family,contrasts in analysis['leaveOneSceneFamilyOut'].items():
    repair_quality(contrasts,[r for r in rows if r['family']!=family])
for bucket,contrasts in analysis['leaveOneGrammarBucketOut'].items():
    repair_quality(contrasts,[r for r in rows if r['bucket']!=bucket])
def repair_summary(s):
    if s.get('notFinalized'):
        s['wilsonITT_IIDReferenceOnly']=None
        s['unknownOutcomeIsNotQualityFailure']=True
for s in analysis['byArm'].values():repair_summary(s)
for arms in analysis['byBucket'].values():
    for s in arms.values():repair_summary(s)
for family in analysis['bySceneFamily'].values():
    for s in family['byArm'].values():repair_summary(s)
write(out_dir/'analysis.json',analysis)

def tokens(r):
    if r['status']=='started' or any(c.get('inputTokens') is None or c.get('outputTokens') is None for c in r['calls']):return None
    i=sum(c['inputTokens'] for c in r['calls']); o=sum(c['outputTokens'] for c in r['calls'])
    return {'input':i,'output':o,'total':i+o}
def summary(rs):
    ts=[tokens(r) for r in rs]; known=[t for t in ts if t is not None]
    return {'rows':len(rs),'pass':sum(r['status']=='pass' for r in rs),
            'qualityFailures':sum(r['status']=='quality_failure' for r in rs),
            'unknownOutcome':sum(r['status']=='started' for r in rs),
            'tokenCompleteRows':len(known),'tokens':{k:sum(t[k] for t in known) for k in ['input','output','total']},
            'wallCompleteRows':sum('wallMs' in r for r in rs), 'wallMs':sum(r.get('wallMs',0) for r in rs)}
def comparison(left,right,rs):
    lm={r['caseId']:r for r in rs if r['arm']==left}; rm={r['caseId']:r for r in rs if r['arm']==right}
    pairs=[(lm[k],rm[k]) for k in sorted(lm.keys() & rm.keys()) if tokens(lm[k]) is not None and tokens(rm[k]) is not None]
    def metric(ps):
        if not ps:return {'n':0}
        ls,rs=zip(*ps); sl,sr=summary(ls),summary(rs)
        return {'n':len(ps),'left':sl,'right':sr,'wallRatio':sl['wallMs']/sr['wallMs'],
                'tokenRatio':sl['tokens']['total']/sr['tokens']['total'],
                'inputRatio':sl['tokens']['input']/sr['tokens']['input'],
                'outputRatio':sl['tokens']['output']/sr['tokens']['output']}
    return {'allFinalized':metric(pairs),'commonSuccess':metric([(l,r) for l,r in pairs if l['status']==r['status']=='pass']),
            'samePhase':{p:metric([(l,r) for l,r in pairs if l['phase']==r['phase']==p]) for p in ['original','continuation']},
            'crossPhase':metric([(l,r) for l,r in pairs if l['phase']!=r['phase']])}
contrasts=[('D','C'),('D','B'),('D','G'),('D','V'),('C','C_fixed'),('D','D_fixed')]
supp={'plannedTasks':60,'mainRows':300,'finalizedMainRows':299,'originalUnknownMainRows':1,
      'completeFiveArmTasks':59,'continuationRows':len(new['rows']),
      'knownReturnedCalls':result['paidAttempts'],'continuationReturnedCalls':new['returnedAttempts'],
      'byArm':{arm:summary([r for r in rows if r['arm']==arm]) for arm in sorted({r['arm'] for r in rows})},
      'byPhase':{p:{arm:summary([r for r in rows if r['arm']==arm and r['phase']==p]) for arm in main} for p in ['original','continuation']},
      'paired':{l+'/'+r:comparison(l,r,rows) for l,r in contrasts},
      'byOriginalArmPosition':{str(pos):{arm:summary([r for r in rows if r['arm']==arm and r.get('order')==pos]) for arm in main} for pos in range(5)},
      'failures':[{'caseId':r['caseId'],'arm':r['arm'],'phase':r['phase'],'evaluation':r.get('evaluation'),
                   'selectedMetrics':r.get('selectedMetrics'),'stopReason':r.get('stopReason'),'depth':r.get('depth')} for r in rows if r['status']!='pass'],
      'executionInterruption':interruption,'inference':'synthetic same-grammar exploration; no production quality/equivalence claim'}
cache=collections.defaultdict(lambda:{'calls':0,'input':0,'output':0,'hit':0,'miss':0,'wallMs':0})
for r in rows:
    for c in r['calls']:
        u=c.get('usage') or {}; i=c.get('inputTokens'); hit=u.get('prompt_cache_hit_tokens')
        frac=hit/i if i and isinstance(hit,int) and c['provider']=='deepseek' else None
        group='jev' if c['provider']=='jev' else 'unknown' if frac is None else 'low' if frac<=.1 else 'high' if frac>=.8 else 'mixed'
        k='|'.join([r['phase'],r['arm'],str(r.get('order')),c['kind'],group]); v=cache[k]
        v['calls']+=1; v['input']+=i or 0; v['output']+=c.get('outputTokens') or 0
        v['hit']+=u.get('prompt_cache_hit_tokens',0);v['miss']+=u.get('prompt_cache_miss_tokens',0);v['wallMs']+=c['wallMs']
supp['cacheByPhaseArmPositionKindHitStratum']=dict(cache)
write(out_dir/'supplement.json',supp)
print(json.dumps({'status':result['status'],'completeFiveArmTasks':59,'continuationRows':84,
                  'knownReturnedCalls':result['paidAttempts'],'unknownOriginalC':1,'output':str(out_dir)},ensure_ascii=False))
