"""Read existing traces only. Public-price scenarios are not invoices."""
import argparse,collections,hashlib,json,math,pathlib,random,statistics
p=argparse.ArgumentParser();p.add_argument('directory');p.add_argument('--output',required=True);a=p.parse_args();d=pathlib.Path(a.directory)
r=json.loads((d/'results.json').read_text());f=json.loads((d/'freeze.json').read_text());rows=r['rows']
def callcost(c,cache='observed',peak=False):
    i,o=c.get('inputTokens'),c.get('outputTokens')
    if i is None or o is None:return None
    if c['provider']=='jev':return i*.042/1e6
    hit=c.get('usage',{}).get('prompt_cache_hit_tokens') if c.get('usage') else None
    miss=c.get('usage',{}).get('prompt_cache_miss_tokens') if c.get('usage') else None
    if cache=='all_miss':hit,miss=0,i
    elif cache=='uniform_50pct_hit':hit,miss=i/2,i/2
    elif not isinstance(hit,(int,float)) or not isinstance(miss,(int,float)) or hit+miss!=i:return None
    return (hit*.022+miss*.66+o*1.98)*(2 if peak else 1)/1e6
def rowcost(x,cache='observed',peak=False):
    v=[callcost(c,cache,peak) for c in x['calls']]
    return sum(v) if all(y is not None for y in v) else None
def wilson(k,n):
    if not n:return None
    z=1.959963984540054;p=k/n;den=1+z*z/n;c=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [max(0,c-half),min(1,c+half)]
def stats(v):
    if not v:return None
    s=sorted(v);return {'sum':sum(v),'mean':statistics.mean(v),'median':statistics.median(v),'p90':s[math.ceil(.9*len(s))-1]}
def summarize(xs):
    calls=[c for x in xs for c in x['calls']];known=[c for c in calls if c.get('inputTokens') is not None and c.get('outputTokens') is not None]
    providers={}
    for name in ['deepseek','jev']:
        cs=[c for c in calls if c['provider']==name];ks=[c for c in cs if c in known];hit=sum((c.get('usage') or {}).get('prompt_cache_hit_tokens',0) for c in cs);miss=sum((c.get('usage') or {}).get('prompt_cache_miss_tokens',0) for c in cs)
        providers[name]={'attempts':len(cs),'knownUsage':len(ks),'unknownUsage':len(cs)-len(ks),'input':sum(c['inputTokens'] for c in ks),'output':sum(c['outputTokens'] for c in ks),'hit':hit if name=='deepseek' else None,'miss':miss if name=='deepseek' else None,'actualModels':sorted({c['actualModel'] for c in cs if c.get('actualModel')}),'callWallMs':stats([c['wallMs'] for c in cs])}
    fees={}
    for mode in ['observed','all_miss','uniform_50pct_hit']:
        for peak in [False,True]:
            vals=[callcost(c,mode,peak) for c in calls];fees[mode+('_peak' if peak else '_offpeak')]={'knownUSD':sum(v for v in vals if v is not None),'unknownCalls':sum(v is None for v in vals),'classification':'public_price_estimate_actual_usage_cache' if mode=='observed' else 'counterfactual_sensitivity_not_measured'}
    passed=sum(x.get('status')=='pass' for x in xs)
    return {'attemptedTaskRows':len(xs),'passed':passed,'qualityFailures':sum(x.get('status')=='quality_failure' for x in xs),'serviceFailures':sum(x.get('status')=='service_failure' or any(c['status']!='ok' for c in x['calls']) for x in xs),'notFinalized':sum(x.get('status')=='started' for x in xs),'wilsonITT':wilson(passed,len(xs)),'wallMsAllAttemptedRows':stats([x['wallMs'] for x in xs if 'wallMs' in x]),'wallMsSuccessfulTasks':stats([x['wallMs'] for x in xs if x.get('status')=='pass']),'providers':providers,'fees':fees,'unknownUsageNeverFilledZero':True}
def exact_mcnemar(b,c):
    n=b+c
    return min(1,2*sum(math.comb(n,k) for k in range(min(b,c)+1))/2**n) if n else 1
def comparison(left,right):
    ls={x['caseId']:x for x in rows if x['arm']==left};rs={x['caseId']:x for x in rows if x['arm']==right};pairs=[(ls[k],rs[k]) for k in ls.keys()&rs.keys()];pairs.sort(key=lambda x:x[0]['caseId'])
    b=sum(x.get('status')=='pass' and y.get('status')!='pass' for x,y in pairs);c=sum(y.get('status')=='pass' and x.get('status')!='pass' for x,y in pairs)
    out={'pairedAttemptedTasks':len(pairs),'qualityLeftOnlyPass':b,'qualityRightOnlyPass':c,'mcnemarExactTwoSided':exact_mcnemar(b,c),'notEquivalentBecauseNonSignificant':True,'commonSuccessfulTasks':sum(x.get('status')==y.get('status')=='pass' for x,y in pairs),'metrics':{}}
    for metric,fn in [('wallMs_all',lambda x:x.get('wallMs')),('observed_offpeak_USD_all',rowcost),('wallMs_common_success',lambda x:x.get('wallMs') if x.get('status')=='pass' else None),('observed_offpeak_USD_common_success',lambda x:rowcost(x) if x.get('status')=='pass' else None)]:
        valid=[(x,y,fn(x),fn(y)) for x,y in pairs if fn(x) is not None and fn(y) is not None]
        if not valid:out['metrics'][metric]={'n':0,'ratio':None};continue
        ratio=sum(v[2] for v in valid)/sum(v[3] for v in valid);bybucket=collections.defaultdict(list);byfamily=collections.defaultdict(list)
        for v in valid:bybucket[v[0]['bucket']].append(v);byfamily[v[0]['family']].append(v)
        intervals={};rng=random.Random(120610)
        for unit,groups in [('task_stratified_by_bucket',bybucket),('scene_family_cluster',byfamily)]:
            values=[]
            for _ in range(10000):
                if unit=='task_stratified_by_bucket':draw=[rng.choice(group) for group in groups.values() for _ in group]
                else:
                    keys=list(groups);draw=[v for _ in keys for v in groups[rng.choice(keys)]]
                denom=sum(v[3] for v in draw)
                if denom:values.append(sum(v[2] for v in draw)/denom)
            values.sort();intervals[unit]=[values[int(.025*len(values))],values[min(len(values)-1,int(.975*len(values)))]] if values else None
        out['metrics'][metric]={'n':len(valid),'pooledRatioLeftOverRight':ratio,'bootstrap95':intervals,'interpretation':'diagnostic_only_if_quality_not_preserved_or_small_sample'}
    return out
cache=[]
for x in rows:
    for c in x['calls']:
        i=c.get('inputTokens');hit=(c.get('usage') or {}).get('prompt_cache_hit_tokens');fraction=hit/i if c['provider']=='deepseek' and i and isinstance(hit,int) else None
        cache.append({'caseId':x['caseId'],'arm':x['arm'],'order':x.get('order'),'kind':c['kind'],'startedAt':c['startedAt'],'actualModel':c.get('actualModel'),'input':i,'output':c.get('outputTokens'),'cacheHit':hit,'cacheMiss':(c.get('usage') or {}).get('prompt_cache_miss_tokens'),'hitFraction':fraction,'observedGroup':'not_applicable_jev' if c['provider']=='jev' else 'unknown' if fraction is None else 'low' if fraction<=.1 else 'high' if fraction>=.8 else 'mixed','sameExactRequestSeenBefore':c.get('sameRequestSeenBefore'),'requestSHA':c.get('requestSHA')})
arms=sorted({x['arm'] for x in rows})
out={'scope':r['scope'],'status':r['status'],'plannedTasks':len(f['schedule']),'completedTasks':len(r['completedCaseIds']),'unexecutedCaseIds':r['unexecutedCaseIds'],'byArm':{arm:summarize([x for x in rows if x['arm']==arm]) for arm in arms},'byBucket':{b:{arm:summarize([x for x in rows if x['arm']==arm and x['bucket']==b]) for arm in arms} for b in sorted({x['bucket'] for x in rows})},'comparisons':{left+'/'+right:comparison(left,right) for left,right in [('D','C'),('D','B'),('D','G'),('D','V'),('C','C_fixed'),('D','D_fixed')]},'cacheObservations':cache,'priceClassification':'scenarios only; per-call UTC preserved; actual billing period/holiday/contract not verified','allAttemptsKnownUsage':sum(c.get('inputTokens') is not None and c.get('outputTokens') is not None for x in rows for c in x['calls']),'unknownUsage':sum(c.get('inputTokens') is None or c.get('outputTokens') is None for x in rows for c in x['calls']),'countsDoNotTreatArmRowsAsIndependentTasks':True,'sourceHashes':{'freeze':hashlib.sha256((d/'freeze.json').read_bytes()).hexdigest(),'results':hashlib.sha256((d/'results.json').read_bytes()).hexdigest()}}
pathlib.Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
