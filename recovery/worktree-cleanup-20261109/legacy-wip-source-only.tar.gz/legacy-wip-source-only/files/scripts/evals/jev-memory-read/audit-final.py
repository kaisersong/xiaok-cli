"""Read-only final audit of frozen results, source evidence and docs links. No auth/network."""
from pathlib import Path
from hashlib import sha256
import json
import re
import subprocess

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]
DOCS=(REPO/'docs').resolve()/'design'
EXT=Path('/tmp/jev-mem-memory-audit')
PREFIX='2026-10-05-jev-memory-'
def read(p):return json.loads(p.read_text())
def digest(p):return sha256(p.read_bytes()).hexdigest()
summary=read(HERE/(PREFIX+'final-summary.json'))
reference_count=0
for r in summary['references']:
    p=(REPO if r['kind']=='xiaok' else EXT)/r['path']
    assert digest(p)==r['SHA256'],r['path']
    assert r['contains'] in p.read_text().splitlines()[r['line']-1],r
    reference_count+=1
calls=[]; frozen_count=0; current_drift=[]; unverified_frozen_sources=[]
for name,meta in summary['rounds'].items():
    folder=HERE/meta['path'];freeze=read(folder/'freeze.json');data=read(folder/'results.json')
    assert digest(folder/'results.json')==meta['resultSHA256']
    assert digest(folder/'freeze.json')==meta['freezeSHA256']
    for path,h in freeze.get('sourceHashes',{}).items():
        local=name in ['r10','r11b']
        current=folder.parent/path if local else REPO/path
        snap=folder/'source-snapshot'/path
        candidate=snap if snap.exists() else current
        matches=candidate.exists() and digest(candidate)==h
        if snap.exists():assert matches,(name,path,'frozen evidence mismatch')
        if matches:frozen_count+=1
        else:unverified_frozen_sources.append({'round':name,'path':path,'expectedSHA':h,'reason':'no archived per-round snapshot; current source differs'})
        if current.exists() and digest(current)!=h:current_drift.append({'round':name,'path':path,'frozenSHA':h,'currentSHA':digest(current)})
    rows=data.get('rows',[])+data.get('writeRows',[])+data.get('graphRows',[])
    calls += [c for r in rows for c in r.get('calls',[])+([r['call']] if 'call' in r else [])]
known=[c for c in calls if c.get('inputTokens') is not None and c.get('outputTokens') is not None]
assert len(calls)==155 and len(known)==153
assert sum(c['inputTokens'] for c in known)==151642
assert sum(c['outputTokens'] for c in known)==17883
assert all(c['status']=='ok' for c in known)
assert len(summary['r10PairedRequests'])==9
for a in summary['r10PairedRequests']:
    assert a['inputEach'][0]==a['inputEach'][1] and a['outputEach']==[282,282]
    assert len(a['candidateIds'])==16 and a['candidateIds'][a['targetIndex']]==a['target']
assert summary['r11Graph']['G']['totalKnown']==581
assert abs(summary['r11Graph']['G']['fullTaskWallMsSum']-2714.079999)<1e-6
assert summary['r11Graph']['C']['totalKnown']==7653 and summary['r11Graph']['D']['totalKnown']==9175
assert len(summary['unexecuted']['r9NewCaseIds'])==6
links=0;external_links=set()
for suffix in ['final-report.md','source-matrix.md','index.md']:
    p=HERE/(PREFIX+suffix)
    assert digest(p)==digest(DOCS/p.name),(p.name,'archive copy mismatch')
    for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
        if target.startswith('https://'):
            external_links.add(target)
            if 'github.com/libingzheren/Jev-Mem/blob/' in target:
                assert summary['externalCommit'] in target
                tail=target.split(summary['externalCommit']+'/')[1];path,n=tail.split('#L')
                assert 1<=int(n)<=len((EXT/path).read_text().splitlines())
            continue
        target=target.strip('<>');line=None
        if target.startswith('/'):
            if re.search(r':\d+$',target):target,line=target.rsplit(':',1)
            resolved=Path(target)
        else:resolved=DOCS/target.split('#',1)[0]
        assert resolved.exists(),(p.name,target)
        if line:assert 1<=int(line)<=len(resolved.read_text().splitlines())
        links+=1
for path,h in summary['externalSourceHashes'].items():assert digest(EXT/path)==h
print(json.dumps({'status':'passed_existing_evidence_final_audit_with_explicit_historical_source_gaps','referencesChecked':reference_count,'frozenSourceEntriesChecked':frozen_count,'unverifiedHistoricalFrozenSources':unverified_frozen_sources,'knownCalls':len(known),'attempts':len(calls),'totalKnown':169525,'localDocAndSourceLinksChecked':links,'externalLinksFixedOrPreviouslyRead':len(external_links),'currentSourceDrift':current_drift,'currentHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),'reportHead':summary['head'],'experimentHead':summary['experimentHead'],'remoteCalls':0,'writes':0},ensure_ascii=False,indent=2))
