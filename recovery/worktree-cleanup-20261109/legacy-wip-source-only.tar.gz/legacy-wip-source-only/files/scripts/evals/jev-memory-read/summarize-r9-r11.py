"""Build checkpoint evidence from existing traces only. No paid calls."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
specs = {
    'r9-development': ROOT/'module-r9/results/live-dev-r9/results.json',
    'r9-new': ROOT/'module-r9/results/live-new-r9/results.json',
    'r10-control': ROOT/'diagnostic-r10/live/results.json',
    'r11-modules': ROOT/'semantic-r11/live/results.json',
    'r11b-all-neighbors': ROOT/'semantic-r11/all-neighbors/results.json',
}


def rows(data):
    return data.get('rows', []) + data.get('writeRows', []) + data.get('graphRows', [])


def calls(data):
    return [call for row in rows(data) for call in (row.get('calls', []) + ([row['call']] if 'call' in row else []))]


def ledger(data):
    cs = calls(data)
    known = [c for c in cs if c.get('inputTokens') is not None and c.get('outputTokens') is not None]
    low = high = 0.
    for c in known:
        if c['provider'] == 'jev':
            lo = hi = c['inputTokens'] * .042 / 1_000_000
        else:
            hit, miss = c['usage']['prompt_cache_hit_tokens'], c['usage']['prompt_cache_miss_tokens']
            assert hit + miss == c['inputTokens']
            lo = (hit*.022 + miss*.66 + c['outputTokens']*1.98)/1_000_000
            hi = 2*lo
        low += lo
        high += hi
    return dict(attempts=len(cs), known=len(known), unknown=len(cs)-len(known),
                inputKnown=sum(c['inputTokens'] for c in known), outputKnown=sum(c['outputTokens'] for c in known),
                callWallMs=sum(c['wallMs'] for c in cs), estimatedFeeLowUSD=low, estimatedFeeHighUSD=high)


data = {name: json.loads(path.read_text()) for name, path in specs.items()}
old = [json.loads(p.read_text()) for p in (ROOT/'results').glob('*/results.json')]
audit = {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
    'scope':'checkpoint; synthetic only; production untouched',
    'rounds': {name: {'path':str(specs[name]),'SHA256':hashlib.sha256(specs[name].read_bytes()).hexdigest(),
        'status':d['status'],'cost':ledger(d)} for name,d in data.items()},
    'overall': ledger({'rows':[r for d in [*old,*data.values()] for r in rows(d)]}),
    'coldWarm':json.loads((ROOT/'module-r9/cold-warm-results.json').read_text()),
    'notVerified':['real memory workload/scale/quality noninferiority','language vs index-path vs attention mechanism',
        'same_name write case stopped by prior quality gate','r9 six later new buckets not executed',
        'full graph lifecycle/admission/temporal graph builder/multi-depth traversal','actual invoice for two old unknown usage attempts']}


def arm_table(rs, arm_field='arm'):
    lines=['|组|答案通过/已跑|完整任务秒|input|output|total|','|---|---:|---:|---:|---:|---:|']
    for a in sorted({r[arm_field] for r in rs}):
        subset=[r for r in rs if r[arm_field]==a]
        inp=sum(c['inputTokens'] for r in subset for c in r.get('calls',[]) if c.get('inputTokens') is not None)
        out=sum(c['outputTokens'] for r in subset for c in r.get('calls',[]) if c.get('outputTokens') is not None)
        passed=sum(r.get('evaluation',{}).get('pass',r.get('pass',False)) for r in subset)
        lines.append(f"|{a}|{passed}/{len(subset)}|{sum(r.get('wallMs',0) for r in subset)/1000:.4f}|{inp}|{out}|{inp+out}|")
    return '\n'.join(lines)


r9 = '''# r9 相关性模块与冷暖检索阶段报告

这是部分模块消融，不是完整 Jev-Mem。原r7硬过滤被以下共同架构替换：生产语义query先取2 anchors并绝对保留、RRF扩展池最多4、仅扩展排序取2、完整4条/1000字符；C/D同原relevance Noul命题及显式字段。原版anchor只入visited、最终top_k仍可淘汰，本轮永久保留为安全适配。多项一起改变，不能据新版通过归因某项或Jev。

4项免费契约测试通过，覆盖字段/ID、低p保留纠正否定anchors、实际改变扩展和真实store正文/scope。开发2题真实E/B/C/D都通过、12请求；新8题免费预检anchors均已覆盖全部gold（无答案为vacuous coverage，不等于有答案）。随后冻结新题，执行前2题四组12请求，D selector1614 tokens已≥C完整1566，按预定预算停。剩余时效/同名/scope/低重叠/多证据/无答案6题未执行，未挑掉它们，不能声称8桶未见答案通过。

开发：
'''+arm_table(data['r9-development']['rows'])+'''

全新两题：
'''+arm_table(data['r9-new']['rows'])+'''

新题D相对C完整wall -9.52%、total +40.87%；相对B wall +61.94%、total +272.64%。两题E已答对，D与B/C扩展选择完全相同，新增gold=0；Jev没有有效质量增量。开发更正只改变了噪声扩展，不是答案能力增量。当前相关性变体收束，不接入。

冷暖为免费真实生产search：8题新SQLite，fresh ONNX engine/首次query（query cache先断言0）24.19–29.81ms；内存命中.39–.70ms；重开store读取SQLite query embedding .37–.60ms，正文/顺序一致；未清OS page cache，不是电脑冷启动。首次全对象相等检查因生产search.updatedAt=Date.now失败，原日志保留，修订只排除这个派生时间字段再测；没有改生产。cache为共享架构，不能归Jev或从几十ms推完整任务5%收益。

复现（重新调用是收费，不应为了看结果重跑）：`node --import tsx scripts/evals/jev-memory-read/module-r9/run.mts --mode offline --split new --output /tmp/r9-new-unique-dir`；契约 `node --import tsx --test scripts/evals/jev-memory-read/module-r9/harness.test.mts`。查看freeze/source-snapshot/results即可离线审计。每次新输出目录，旧freeze拒绝覆盖。
'''
(ROOT/'module-r9/REPORT.md').write_text(r9)

r10='''# r10 原失败单因素诊断报告

旧3题开发诊断，18次真实Jev请求全部成功且usage完整，没有final；不算未见/完整任务收益。O原请求、F仅显式反引号字段、P仅交换目标位置并同步下标，question-map键顺序/内容/ID/criteria固定，各2重复。原题内容、原16候选没有删改。免费18个请求规格与每项ID映射断言通过。

|题|O原位置及概率2次|F原位置显式字段概率2次|P换序位置及概率2次|
|---|---|---|---|
|更正|14：.08/.05|14：.03/.11|0：.94/.94|
|否定|15：.04/.04|15：.64/.66|0：.97/.97|
|时效成功控制|1：.97/.97|1：.95/.97|15：.07/.06|

相同内容换序稳定改变概率，是该版本/16候选请求对目标位置/路径索引敏感的因果证据；下标随ID变化是保持语义所必需，**不能分清数组尾部注意力与多位数字索引解析**。F是显式字段引用组合因子，不能分清backticks与.text各自贡献；它只稳定改善否定，没有修好更正。不支持泛称中文能力差、Jev-Mem失效或所有长度相同问题。未换英语、不调阈值，不追加到成功。

免费回放旧实际概率：hard≥.4选空；同预算概率排序去cutoff，更正前2=m1/m0，否定前2=m1/m0，gold都进入前6；同预算原retrieval排序前6仍噪声。证明hard cutoff造成证据删除，即使绝对低概率相对排序有信息；没有重跑final，不能据覆盖假称最终答对。原r7结果保留。

本轮input51402/output5076，远程请求墙时合计7.3024秒；只是selector诊断，不是任务时间。free/live目录各freeze/results保留body、hash与完整actual response。离线规格复现：`node --import tsx scripts/evals/jev-memory-read/diagnostic-r10/run.mts`（默认free，但原目录拒绝覆盖；使用新目录副本审计）；`--live`真实付费，不为复核结果自动重跑。
'''
(ROOT/'diagnostic-r10/REPORT.md').write_text(r10)

r11='''# r11 原写入命题、真实来源关系闭环与公平预算控制

原7ab0c73的19条consolidation/routing/stopping/traversal问题通过白名单literal AST提取为questions.json，保留MIT许可，不执行外部代码。3项typed/edge/weight/stop免费测试通过；真实store免费预检，两题anchor不含gold、3个原文明示ID邻居包含gold。原state/query/节点content/时间/实体与relation/source_id/target_id完整给C/D，同Noul/Choice契约；模型路由/stop/traversal/final均计完整任务。最大32请求，实际核心30+必要all-neighbors基线2=32，全部usage完整。

写入6请求：转述重复与明确更新，两模型均符合冻结判据；同时间冲突两模型均失败，按规则停同名题（未执行）。C contradiction=.95正确，却obsolete=.90把“未注明修改或替换”误判为明确替换；D obsolete=.10正确，但contradiction=.80未过沿原config的.85门槛。两者representation均keep_separate，selected probability均.89/.90，safeMergeEligible=false，原文全部保留。不能等价为安全性破坏，也不能把修改阈值到.8冒称修复。更新题Jev Choice merge概率.61/confidence.48，LLM .8/.8，虽choice=merge但都未达.85整合门槛；不是自动合并。重复题Jev merge=.89可交LLM整合，但当前仅判断，没调用摘要或写store，无生成整合任务收益结论。xiaok当前没有这一独立前台dedup/conflict LLM，因此接入是新增成本，不是直接替换原产品已有调用。

图来源是合成原文[m1]/[m2]/[m3]明示引用，代码只连已存在合法scope ID并保留source_text；无伪造语义边。两题退款资料与身份→权限，E初始缺所问事实并正确弃答；B固定词覆盖/原权重默认信号选1邻居，分别错选m3/m2，不能回答；C/D原四命题排名选m1并答对。这是真实相关性机制改变扩展，不是只换噪声，但初始anchor1/最终扩展1为本实验预算适配，不表示原30 anchors/beam10/top40也会失败。

'''+arm_table(data['r11-modules']['graphRows'])+'''

D对C graph完整wall变化见下面从原trace计算的精确比率；input +34.13%、output -31.14%、total +19.89%，不通过双降目标。route均保留全部3条entity边；两题before-stop正确判缺证据。after-stop：C两题都充分，D身份充分但退款sufficient=.92、continue=.19，沿.95/.15规则未停止，是本实验depth1上限终止。不能降低门槛宣布停止准确，也不能声称这轮stopping减少了轮次。所有源节点同日期，遗漏原recency归一项不会改变本轮相对排名；它仍是与完整原实现的差异，不能称完整复现。缓存30个已有request/typed response离线exact hash replay通过，0新增remote；两provider同等给缓存，没测真实服务cache命中或持久跨版本缓存。

充分性自审补r11b：3邻居全量＋anchor仅100/127字符，全部能装共同1000字符/4条预算，原beam/top_k也会接收它们。原1扩展限制会人为制造模型判别优势，故新增独立冻结的全明示邻居G控制2请求，真实生产search展开相同源关系，最终均通过：

'''+arm_table(data['r11b-all-neighbors']['rows'])+'''

G总581 tokens/2.7141秒，两题均答对，低于C7653/D9175。因此在这两个小图上**直接展开所有原文明示关系已经足够**，不能将C/D相较错误B的质量增益包装成必须接入Jev；四项判断只在邻居规模超过预算、边需推断/多轮选择时可能有空间，这些未实测。

graph free/preflight、typed traces、原命题、freeze与source-snapshot全部保留。`node --import tsx --test scripts/evals/jev-memory-read/semantic-r11/harness.test.mts`可免费核验；runner默认offline，已有输出拒绝覆盖；live与all-neighbors命令真实收费，不为审计重复执行。没有真实四图写入/全图生命周期/多深度无限遍历/生成摘要集成，不将模块证据称整体复现或生产性能。
'''
cwall=sum(r['wallMs'] for r in data['r11-modules']['graphRows'] if r['arm']=='C')
dwall=sum(r['wallMs'] for r in data['r11-modules']['graphRows'] if r['arm']=='D')
r11+=f'\n原trace精确计算：D/C完整wall {((dwall/cwall)-1)*100:+.4f}%。\n'
(ROOT/'semantic-r11/REPORT.md').write_text(r11)
for name,path in specs.items():
    freeze_path=path.parent/'freeze.json'
    audit['rounds'][name]['freezeSHA256']=hashlib.sha256(freeze_path.read_bytes()).hexdigest()
audit_path=ROOT/'CHECKPOINT-r11.json';audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:audit[k] for k in ['head','overall']},ensure_ascii=False,indent=2))
