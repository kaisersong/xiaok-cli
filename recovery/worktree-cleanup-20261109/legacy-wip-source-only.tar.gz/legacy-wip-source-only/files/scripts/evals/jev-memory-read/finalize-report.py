"""Finalize existing synthetic evidence; no network, auth, production writes or reruns."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
EXT = Path('/tmp/jev-mem-memory-audit')
PREFIX = '2026-10-05-jev-memory-'
COMMIT = '7ab0c73c6d8f4f611ad252c1e6ba8083f8df0e44'
def read(p): return json.loads(p.read_text())
def digest(p): return sha256(p.read_bytes()).hexdigest()
def rowset(d): return d.get('rows', []) + d.get('writeRows', []) + d.get('graphRows', [])
def callset(d): return [c for r in rowset(d) for c in r.get('calls', []) + ([r['call']] if 'call' in r else [])]
def ledger(d):
    cs=callset(d); known=[c for c in cs if c.get('inputTokens') is not None and c.get('outputTokens') is not None]
    lo=hi=0
    for c in known:
        if c['provider']=='jev': l=h=c['inputTokens']*.042/1e6
        else:
            hit=c['usage']['prompt_cache_hit_tokens']; miss=c['usage']['prompt_cache_miss_tokens']
            assert hit+miss==c['inputTokens']
            l=(hit*.022+miss*.66+c['outputTokens']*1.98)/1e6; h=2*l
        lo+=l;hi+=h
    return dict(attempts=len(cs),known=len(known),unknown=len(cs)-len(known),inputKnown=sum(c['inputTokens'] for c in known),outputKnown=sum(c['outputTokens'] for c in known),callWallMs=sum(c['wallMs'] for c in cs),feeScenarioLowUSD=lo,feeScenarioHighUSD=hi)

specs={
 'r1':'results/offline-r1','r2':'results/offline-r2','r3':'results/live-pilot-r3',
 'r4':'results/live-pilot-r4','r5':'results/live-pilot-r5','r6':'results/live-development-r6','r7':'results/live-holdout-r7',
 'r9-dev':'module-r9/results/live-dev-r9','r9-new':'module-r9/results/live-new-r9',
 'r10':'diagnostic-r10/live','r11':'semantic-r11/live','r11b':'semantic-r11/all-neighbors'}
data={k:read(HERE/v/'results.json') for k,v in specs.items()}
total=ledger({'rows':[r for d in data.values() for r in rowset(d)]})
assert (total['attempts'],total['known'],total['unknown'],total['inputKnown'],total['outputKnown'])==(155,153,2,151642,17883)
checkpoint=read(HERE/'CHECKPOINT-r11.json')['overall']
for key in ['attempts','known','unknown','inputKnown','outputKnown','callWallMs']: assert abs(total[key]-checkpoint[key])<1e-6
assert abs(total['feeScenarioLowUSD']-checkpoint['estimatedFeeLowUSD'])<1e-12
assert abs(total['feeScenarioHighUSD']-checkpoint['estimatedFeeHighUSD'])<1e-12

# Each reference is checked against the current file and an identifying source token.
refs=[]
def local(p,n,token):
    lines=(REPO/p).read_text().splitlines(); assert 1<=n<=len(lines) and token in lines[n-1],(p,n,token)
    refs.append(dict(kind='xiaok',path=p,line=n,contains=token,SHA256=digest(REPO/p)))
    return f'[{p}:{n}]({REPO/p}:{n})'
def original(p,n,token):
    lines=(EXT/p).read_text().splitlines(); assert 1<=n<=len(lines) and token in lines[n-1],(p,n,token)
    refs.append(dict(kind='Jev-Mem',path=p,line=n,contains=token,SHA256=digest(EXT/p)))
    return f'[{p}:{n}](https://github.com/libingzheren/Jev-Mem/blob/{COMMIT}/{p}#L{n})'
nbw=local('src/ai/tools/notebook.ts',66,'execute'); nbr=local('src/ai/tools/notebook.ts',92,'execute')
save=local('src/ai/memory/layered-store.ts',122,'save'); embasync=local('src/ai/memory/layered-store.ts',139,'embedAndStore')
scope=local('src/ai/memory/layered-store.ts',144,'listRelevant'); search=local('src/ai/memory/layered-store.ts',156,'search')
body=local('src/ai/memory/layered-store.ts',161,'getById'); raw=local('src/ai/memory/layered-store.ts',186,'writeRawMessage')
lc=local('src/ai/memory/layered-store.ts',194,'compact'); off=local('src/ai/memory/layered-store.ts',46,'autoCompact')
retrieval=local('src/ai/memory/retrieval.ts',41,'hybridSearch'); vectors=local('src/ai/memory/retrieval.ts',203,'vectorSearch')
cache=local('src/ai/memory/embedding.ts',29,'createHash'); embed=local('src/ai/memory/embedding.ts',119,'callEmbedApi')
extract=local('src/ai/memory/compaction.ts',84,'await llm'); scenario=local('src/ai/memory/compaction.ts',144,'await llm')
persona=local('src/ai/memory/compaction.ts',197,'await llm'); exact=local('src/ai/memory/compaction.ts',203,'trait =')
schema=local('src/ai/memory/migrations.ts',32,'memory_l0_raw'); owner=local('desktop/electron/desktop-services.ts',283,'getDesktopMemoryStore')
register=local('desktop/electron/desktop-services.ts',7526,'createNotebookTools'); disabled=local('desktop/electron/desktop-services.ts',7758,'enabled: false')
promotion=local('desktop/electron/assistant-controller.ts',151,'ensureMemory'); inject=local('src/ai/prompts/builder.ts',23,'memoryStore.search')
restore=local('src/ai/runtime/agent-runtime.ts',792,'memoryRefs'); session=local('src/ai/runtime/agent-runtime.ts',303,'executePortableCompaction')
desktopcompact=local('desktop/electron/context-manager.ts',128,'streamDesktopTaskProviderConversation')
eq=original('memory/jev_questions.py',19,'admission_questions'); tq=original('memory/jev_questions.py',44,'type_questions')
rq=original('memory/jev_questions.py',66,'relation_questions'); cq=original('memory/jev_questions.py',86,'consolidation_questions')
routeq=original('memory/jev_questions.py',112,'routing_questions'); stopq=original('memory/jev_questions.py',129,'stopping_questions')
traverseq=original('memory/jev_questions.py',146,'traversal_questions'); build=original('memory/memory_builder.py',119,'build')
consolidate=original('memory/memory_builder.py',228,'consolidate'); entity=original('memory/memory_builder.py',293,'_simple_entity_extraction')
candidates=original('memory/jev_mem_policies.py',69,'find_candidates'); state=original('memory/jev_mem_policies.py',50,'node_state')
allocate=original('memory/jev_mem_policies.py',161,'allocate_graph_budgets'); anchors=original('memory/jev_mem_retrieval.py',59,'anchors')
stopcontroller=original('memory/jev_mem_retrieval.py',84,'sufficiency'); traversal=original('memory/jev_mem_retrieval.py',153,'evaluate')
ranking=original('memory/jev_mem_retrieval.py',170,'score ='); output=original('memory/jev_mem_retrieval.py',190,'selected =')
client=original('memory/jev_client.py',140,'evaluate'); fallback=original('memory/jev_client.py',295,'_failure')
evalref=original('docs/evaluation.md',17,'')
r9code=local('scripts/evals/jev-memory-read/module-r9/core.mts',7,'prepare')
r10code=local('scripts/evals/jev-memory-read/diagnostic-r10/run.mts',19,"condition==='F'")
r11write=local('scripts/evals/jev-memory-read/semantic-r11/run.mts',31,'safeMergeEligible')
r11route=local('scripts/evals/jev-memory-read/semantic-r11/run.mts',36,"'routing'")
r11walk=local('scripts/evals/jev-memory-read/semantic-r11/run.mts',37,'routedCandidateIds')
r11stop=local('scripts/evals/jev-memory-read/semantic-r11/run.mts',38,'stopAfter')
r11edge=local('scripts/evals/jev-memory-read/semantic-r11/core.mts',2,'groundedEdges')
r11weights=local('scripts/evals/jev-memory-read/semantic-r11/core.mts',4,'transition')
r11cache=local('scripts/evals/jev-memory-read/semantic-r11/run.mts',42,'cache=new Map')
r11direct=local('scripts/evals/jev-memory-read/semantic-r11/all-neighbors.mts',17,'selected=')

matrix=[
 ('事实来源/入口',owner+'；'+register,'main 创建SQLite store、注册 notebook；非renderer durable state',build,'没有搬原图owner；保留既有main权威'),
 ('写入/admission',nbw+'；'+save,'主任务LLM生成工具参数；工具内是规则+SQLite，没有独立LLM admission',eq+'；'+build,'原 admission 默认关闭；未测筛掉用户笔记。新增Jev是新增前台延迟，不能算替换收益'),
 ('type/实体/建边',schema, 'L0/L1/L2/L3 schema；没有四图节点/边。notebook type 固定user',tq+'；'+rq+'；'+entity,'未复用原builder。英文实体正则不是中文身份系统；r11仅显式引用，不能报语义/因果建边成功'),
 ('原始会话记录',raw,'规则insert；runtime后台触发，不等于已完成长期摘要',build,'不可把raw日志当自动提炼、或用合成写入推断实际频率'),
 ('长期提取/场景/人格',extract+'；'+scenario+'；'+persona+'；'+lc,'三个生成式LLM阶段，有数量闸门；compact需setLLMFn。'+off+' 默认off',consolidate,'Jev只能做有限选择/判断，仍要LLM生成；这些生成阶段本轮未实测优化'),
 ('去重',save+'；'+exact,'同ID REPLACE/trait字符串完全相等；不等于语义重复判断',cq+'；'+consolidate,r11write+'：原5命题复用，3对判断；未生成/写库、未执行原非破坏整合算法'),
 ('冲突/更新',save+'；'+promotion,'无通用semantic conflict service；候选晋升已有稳定ID/匹配/持久验证',cq+'；'+consolidate,'r11两模型同时间冲突判据均失败，但keep_separate，实际无覆盖/删除；不能外推自动覆盖安全'),
 ('写索引',embasync+'；'+embed,'异步embedding；本地ONNX或显式HTTP embedding，不是生成式LLM。工具save不等就绪',build,'索引等待/失败诊断是共同架构；实验全部等索引，不算Jev收益'),
 ('query embedding缓存',cache+'；'+retrieval,'hash/内存/SQLite query cache已存在；query embedding需await',client,'已有等价缓存不重复建设。r9冷暖真实search；r11决策Map回放非生产cache'),
 ('召回/向量',retrieval+'；'+vectors,'FTS/LIKE+cosine/RRF；SQLite向量最多5000后JS扫描，没有LLM rerank',candidates+'；'+anchors,'原find_candidates也有全nodes扫描排序；不能假定图方案必然降低复杂度'),
 ('scope/正文/source去重',scope+'；'+search+'；'+body,'listRelevant先top20再scope；search无scope参数；RRF键layer:id可能同源跨层重复。getById已恢复L0正文',state+'；'+anchors,r9code+'：共享source去重/正文恢复；scope在合成入库前限制，未修生产scope路径'),
 ('平坦重排/anchor',nbr+'；'+retrieval,'规则排序即返回，read await检索，无独立LLM判断可替换',traverseq+'；'+ranking,'r4–r7自建全候选硬筛；r9仅原relevance语义+少扩展，永久anchor为自建安全改造，不能称原算法'),
 ('关系扩展',schema+'；'+body,'当前没有memory图遍历；可以读稳定ID，有明示关系时可确定性展开',rq+'；'+traversal,r11edge+'；'+r11direct+'：3条源文引用解析，不读gold建边；不是原写入构图或真实图生命周期'),
 ('routing/预算',retrieval,'当前平坦RRF无图budget routing',routeq+'；'+allocate,r11route+'：命题/state query复用；没有原allocate/depth算法；输出参与评分，但池未减少（全3条保留）'),
 ('traversal排序',retrieval,'当前没有四命题排序器',traverseq+'；'+traversal+'；'+ranking,r11walk+'；'+r11weights+'：原问题/state形状/权重TS改写；实际选m1，depth1一次，非原Python控制器/beam循环'),
 ('stopping',nbr,'read一次返回，没有多轮证据充分性控制',stopq+'；'+stopcontroller,r11stop+'：before有真实分支但本次均不跳；after仅reason，固定depth1无后续可取消，不报节省轮次'),
 ('批处理/cache/fallback',retrieval,'向量失败退词法；没有独立semantic selector远程cache/retry层',client+'；'+fallback,'r11原Noul/Choice契约复用，raw TS transport无自动retry；非法/网络停。未复用LRU1024、全局15秒/16call预算及Magma fallback'),
 ('证据注入',nbr+'；'+inject+'；'+restore,'工具返回完整record文本；CLI自动注入按cwd查询前10，memoryRefs用于恢复。desktop当前memoryRefs为空',output,'实验生成式final读取实际选择正文；不是自由agent全任务。小池能全装时直接注入优于新增判断'),
 ('会话compact边界',session+'；'+desktopcompact+'；'+disabled,'会话摘要是LLM生成，启用时await可阻塞当前任务；普通desktop策略off，不能假称默认已支付该成本',consolidate,'会话compact与长期memory compact不同；未测替代，Jev不生成等价会话摘要'),
 ('所有权/生命周期',promotion+'；'+owner,'已有目标ID和持久校验，后续mutation需requestSource/default deny及同权限兄弟入口审查',build+'；'+consolidate,'模型概率不授权修改scope、owner、删除或覆写；原文保留是代码政策，不是模型更准确的证据')]

status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=REPO)
tracked=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=REPO)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()
experiment_head='9eaf1aa8ef5e72012da51cc8ee299b7194aaec92'
assert subprocess.check_output(['git','diff',experiment_head,'HEAD','--',*sorted({r['path'] for r in refs if r['kind']=='xiaok' and not r['path'].startswith('scripts/evals/')})],cwd=REPO)==b''
legacy=read(HERE/'diagnostic-r8/analysis.json')
for p,h in legacy['externalReadOnlyFileHashes'].items(): assert digest(EXT/p)==h
for p,h in legacy['originalSourceHashes'].items(): assert digest(HERE/p)==h
source_files=sorted({r['path'] for r in refs if r['kind']=='xiaok'})
source_hashes={p:digest(REPO/p) for p in source_files}
memory_files=[p for p in source_files if p.startswith('src/ai/memory/') or p=='src/ai/tools/notebook.ts']
assert subprocess.check_output(['git','diff','HEAD','--',*memory_files],cwd=REPO)==b''

def arm(rs,a):
    xs=[r for r in rs if r['arm']==a];cs=[c for r in xs for c in r['calls']]
    known=[c for c in cs if c.get('inputTokens') is not None and c.get('outputTokens') is not None]
    i=sum(c['inputTokens'] for c in known);o=sum(c['outputTokens'] for c in known);wall=sum(r['wallMs'] for r in xs)
    return dict(n=len(xs),passCount=sum(r.get('evaluation',{}).get('pass',False) for r in xs),fullTaskWallMsSum=wall,fullTaskWallMsMean=wall/len(xs),inputKnown=i,outputKnown=o,totalKnown=i+o,totalMean=(i+o)/len(xs),unknownCalls=len(cs)-len(known),deepseekCacheHit=sum(c['usage'].get('prompt_cache_hit_tokens',0) for c in known if c['provider']=='deepseek'),deepseekCacheMiss=sum(c['usage'].get('prompt_cache_miss_tokens',0) for c in known if c['provider']=='deepseek'))
graph={a:arm(data['r11']['graphRows'],a) for a in ['E','B','C','D']};graph['G']=arm(data['r11b']['rows'],'G_all_neighbors')
def arm_table(values):
    out=['|组|题/通过|wall总秒 / 均秒|input / output / total总|total均|DeepSeek hit / miss|','|---|---:|---:|---:|---:|---:|']
    for a,v in values.items():out.append(f"|{a}|{v['n']} / {v['passCount']}|{v['fullTaskWallMsSum']/1000:.6f} / {v['fullTaskWallMsMean']/1000:.6f}|{v['inputKnown']} / {v['outputKnown']} / {v['totalKnown']}|{v['totalMean']:.1f}|{v['deepseekCacheHit']} / {v['deepseekCacheMiss']}|")
    return '\n'.join(out)

r10_details=[]
for case in dict.fromkeys(r['caseId'] for r in data['r10']['rows']):
    for cond in ['O','F','P']:
        xs=[r for r in data['r10']['rows'] if r['caseId']==case and r['condition']==cond];x=xs[0];b=x['body']
        assert len(xs)==2 and xs[0]['payloadSHA']==xs[1]['payloadSHA']
        r10_details.append(dict(caseId=case,condition=cond,target=x['target'],targetIndex=x['targetPosition'],candidateIds=[v['id'] for v in b['state']['candidates']],payloadUTF8=len(json.dumps(b,ensure_ascii=False,separators=(',',':')).encode()),inputEach=[r['call']['inputTokens'] for r in xs],outputEach=[r['call']['outputTokens'] for r in xs],probabilities=[r['targetProbability'] for r in xs],payloadSHA=x['payloadSHA']))
unknown=[]
for k,d in data.items():
    for r in rowset(d):
        for c in r.get('calls',[]):
            if c.get('inputTokens') is None or c.get('outputTokens') is None:unknown.append(dict(round=k,caseId=r.get('caseId'),arm=r.get('arm'),kind=c['kind'],status=c['status'],callWallMs=c['wallMs'],fullTaskWallMs=r.get('wallMs'),actualModel=c.get('actualModel'),inputTokens=c.get('inputTokens'),outputTokens=c.get('outputTokens')))
summary={'createdAt':datetime.now(timezone.utc).isoformat(),'head':head,'experimentHead':experiment_head,'HEADAdvancedByOtherWork':head!=experiment_head,'workspace':{'statusZ_SHA256':sha256(status).hexdigest(),'statusEntries':len([x for x in status.split(b'\0') if x]),'statusCodes':dict(Counter(x[:2].decode() for x in status.split(b'\0') if x)),'trackedDiffHEAD_SHA256':sha256(tracked).hexdigest(),'initialStatusSHA256':'24d6d5c096b576f6b4c507f3019957dcc73df190148088490c89f20c8dd29919','initialStatusEntries':2169,'initialTrackedDiffSHA256':'1ade28c93b094dbe4d93352d8f1eb1ef3a64eb113df027e46ceac1926b8b90dc','memorySourceDiffToHEAD':'clean; runtime/desktop files include others task edits'},'externalCommit':COMMIT,'references':refs,'currentSourceHashes':source_hashes,'externalSourceHashes':legacy['externalReadOnlyFileHashes'],'rounds':{k:{'path':specs[k], 'status':d['status'],'resultSHA256':digest(HERE/specs[k]/'results.json'),'freezeSHA256':digest(HERE/specs[k]/'freeze.json'),'ledger':ledger(d)} for k,d in data.items()},'overall':total,'unknownAttempts':unknown,'r9New':{a:arm(data['r9-new']['rows'],a) for a in ['E','B','C','D']},'r10PairedRequests':r10_details,'r11Graph':graph,'unexecuted':{'r7TaskRows':180,'r9NewCaseIds':data['r9-new']['unexecutedCaseIds'],'r11WriteIds':data['r11']['unexecutedWriteIds']},'decision':'已测接法不支持生产；真实规模/中文语料、超预算图、多深度、完整生命周期为未验证，不记失败','remoteCallsThisFinalization':0,'noProductionConfigurationOrUserMemoryChanges':True}

matrix_text='# Jev-Mem → xiaok 最终源码与执行接入矩阵\n\n实验冻结HEAD `'+experiment_head+'`；收尾当前HEAD `'+head+'`（他任务推进，引用生产文件在两提交间无diff），公开源码 `'+COMMIT+'`。xiaok链接指本次工作区：核心memory与HEAD一致，runtime/desktop含他任务改动；精确文件SHA与行号token在[机器摘要]('+PREFIX+'final-summary.json)。原代码仅只读，未安装、未执行；原命题复用与原算法/调度复用分列。\n\n|环节|xiaok入口|现有事实 / LLM / 前台边界|Jev-Mem固定源码|实际适配与结论|\n|---|---|---|---|---|\n'+'\n'.join('|'+ '|'.join(row)+'|' for row in matrix)+'\n\n'
matrix_text+='''r11 细分复用判定（本次只有两个4节点/3邻居图、一次depth1扩展）：

|模块|原命题|state复用程度|原算法/调度|输出实际改变执行|
|---|---|---|---|---|
|写入|5条字面量Noul/Choice|new_memory/candidates的id/content/timestamp/entities；合成显式日期，无原temporal parser|仅移植.85分类/merge资格闸门；未运行builder/consolidate/写图/LLM summarizer|只记录资格与pass；未变更store，不报写入吞吐或摘要收益|
|routing|6条字面量Noul|同query|自建entity≥.1池过滤＋原need权重；没有largest-remainder图预算或按multi_hop_need调depth|need参与排序；实测全3条保留，没有减少候选/预算；multi_hop_need/recency未控制深度|
|traversal|每邻居4条字面量，3邻居一次共12条|query/evidence/candidates；节点id/content/timestamp/entities，relation/graph/source_id/target_id；另加scope；没有temporal_references|TS移植五分量权重；edge p固定1；漏recency项，因全同日期不改本题排名；自建top1，非beam10/top40|实际把B错选m3/m2改为m1，final答对；G全部注入同样答对，故非必需模型收益|
|before-stop|4条字面量|query/实际anchor evidence/depth0|TS沿正式.95/.15布尔门槛；若满足真跳过traversal|本次均不满足，没有请求被跳过；无stopping减少执行证据|
|after-stop|同4条|query/最终anchor+邻居/depth1|同门槛；不实现原while后续迭代|只写reason；C两题/ D身份满足，D退款不满足，仍因depth1终止；没有实际取消下一轮|
|cache/fallback|同typed返回验证|hash(provider,request)Map复制|未复用原LRU、operation/backend/model完整key、全局deadline/预算、排队并发、SDK或fallback|仅30条既有响应离线回放；不是线上命中或cache节省任务时间|

原routing调用与anchors先后、图预算、轮间visited/frontier/top_k、调用deadline与队列owner并未搬入xiaok。本实验一跳关系来源是源文显式[m1]/[m2]/[m3]，与gold判定独立；4节点内容人为给定，代码再按ID/存在/scope生成3条边。不是从真实用户写入推断四图，不是深度≥2的多跳链，不是完整Jev-Mem复现。原anchors参与最终全节点top_k仍可被淘汰；本实验anchor永久保留，这个安全策略是共有架构差异。
'''

report=f'''# Jev-Mem 优化 xiaok memory：r1–r11 阶段适配结论

2026-10-05。**已测接法尚不满足“质量保持＋完整任务时间下降＋总input/output token下降”，不建议生产接入。** 这是一份足以收束已测变体、定位下一研究条件的阶段报告；复杂多跳、超预算候选、长期生命周期和真实中文语料仍未验证，不能写成失败或否定整个Jev-Mem。另一项已收束的CUA混合实验不作为本结论证据。

读者从[入口索引]({PREFIX}index.md)进入各轮设计、freeze、请求/响应、usage、失败及未运行项；逐入口见[源码矩阵]({PREFIX}source-matrix.md)，精确汇总/行号/hash见[机器摘要]({PREFIX}final-summary.json)。本轮整理新增远程请求0，不重跑付费结果、不改旧报告。生产代码/配置/真实memory均未改，无commit/push；公开Jev-Mem仅只读，未装或执行外部软件。

## 当前结构和可接入位置

desktop main 的 {owner} 创建memory.db并注册 {register}。{nbw} 把主LLM给出的文本经规则写L0/L1，异步embedding；没有独立LLM去重/冲突判断。{nbr} 阻塞等待词法/向量检索，结果格式化返回，没有LLM rerank。向量query需await本地ONNX（配置时也可HTTP embedding），embedding不是文本生成LLM；写索引异步，读已就绪是否成立不能由save成功推出。

生成式LLM实际在 {extract}、{scenario}、{persona} 提取摘要、场景、人格，但 {lc} 需已配置llmFn；desktop默认autoCompact关闭且此构造未setLLMFn，不能说已有三段前台LLM可由Jev直接替换。TUI在src/commands/chat.ts:399/4374配置llmFn，与desktop入口分开。trait完全同字符串才合并证据（{exact}），不是通用语义去重。SQLite按同ID REPLACE不等于冲突理解。

{session} 和 {desktopcompact} 是压缩会话历史、由LLM生成摘要的另一条路径；启用时await可能阻塞当前轮，普通desktop策略 {disabled} 关闭。长期memory compact保存跨会话事实，会话compact维持当前任务上下文，不能混为一个可替代生成步骤。CLI {inject} 用cwd作搜索输入，并非用户语义问题；desktop本分支memoryRefs=[]，不是已验证每轮自动注入长期memory。具体路径、LLM/规则与前台边界逐项见矩阵。

## 证据链与停止历史

所有题为人工合成中文。开发题/诊断重复、同题多arm、冷暖重复不能当独立质量题数；没有统计推断或真实适用比例。A旧生产notebook基线，B规则，C同状态精简LLM，D Jev+同final LLM，E anchor-only，G全部明示邻居。同一阶段共有候选/正文/scope/预算/embedding改变同时给各组，不归Jev。

|轮次|实际 / 尝试 / usage未知|发现、失败与未运行|
|---|---|---|
|r1|6免费preflight，0远程|低重叠gold漏召，candidate_coverage阻塞；没跑完8题|
|r2|8免费preflight，0远程|双query共享候选改善覆盖，规则7/8；架构修订非Jev增益|
|r3|0远程|main_binding_missing在调用前阻塞；不能算模型失败或计费|
|r4|3任务行，3尝试，1未知|A/B首题通过；C selector HTTP400（JSON system提示缺失）；D及剩余题未跑|
|r5|2题×4组，12尝试，全部已知|8答案通过；D两次自建不确定性整组fallback；开发后取消，非原repo政策|
|r6|8开发题×4组，48尝试，已知|原A/B/C/D通过5/6/7/6；另存grounded-span复核6/7/8/8，不覆盖旧值。D/C wall -35.81%、total +163.43%|
|r7|计划192任务行，实跑12，18尝试，1未知|A/B/C/D通过1/1/3/1；B含1质量失败+1服务失败。D两题gold已召回却被hard≥.4删空。B final约30s transport_or_json_error，未知usage/actual model，停止；180任务行未跑|
|r8|免费源审计/契约/账本，0新远程|分清自建硬筛与原图排序、旧评测误判与真实漏选。质量非旧即时stop条件，旧冻结允许质量失败继续；不能事后改停止理由|
|r9 dev/new|旧2题与新前2题各4组，各12尝试，全部已知|新两题全组通过；E已答对，无新增gold。D selector1614≥C完整1566触发预定stop；6新桶未执行|
|r10|3旧题×O/F/P×2重复=18Jev判断，全部已知|仅selector诊断，没有final；位置/下标敏感但原因不可分；旧概率无hard排序能保留gold不等于final通过|
|r11 写入|3对×C/D=6判断，全部已知|重复/明确更新判据通过；同时间冲突两模型均失败，止后续同名主体对；非破坏性判断，无摘要或写库|
|r11 图|2图×E/B/C/D，24尝试，全部已知|C/D四阶段判断+final答对；routing不减池，stopping没取消轮次，depth1。D/C wall -61.85%、total +19.89%|
|r11b 公平补控|同2图G，2 final尝试，全部已知|全3邻居＋anchor能装共同1000字符/4条；2/2通过，仅581 tokens/2.714秒，比C/D更省|

r9 未执行：时效、同名、scope、低重叠、多证据、无答案，共6题；免费8题anchor覆盖无答案为vacuous coverage，不代表8题最终答案通过。r11同名不同主体pair未执行。r7未完成全部重复/24题，不能称holdout完成。原文件静态保存，r6复核另文件；r1调用前阻塞、r4请求错误、r7服务错误和harness免费首轮失败都保留。原DESIGN允许质量继续与后续新增quality/futility闸门有明确版本边界。

## r9 绝对指标与冷暖边界

{arm_table(summary['r9New'])}

上述为新前两题合计及均值。D完整2206相对C完整1566是+40.87%；**1614仅Dselector**，与C完整1566作理论token下限stop依据，不是D完整值。D wall比C少9.52%，比B多61.94%，不能用后者便宜/少调用替代联合目标。两题延迟单次不同，不给显著性或生产承诺。

8个免费真实search冷暖记录：fresh engine/query且cache断言先0后1，24.19–29.81ms；内存cache .39–.70ms；重开store持久cache .37–.60ms。未清OS页缓存，不是机器冷启动或完整agent冷任务；每题同内容三次是cache诊断，不新增质量题。第一次全对象assert因生产updatedAt=Date.now失败，修订只排除派生时间字段，原失败log保留，没有改生产。embedding/cache现已存在，缓存收益归共有架构。

## r10 配对诊断的可解释范围

入口 {r10code}：每题两次O/F/P按(ci+rep)轮转顺序，18请求串行，没有本地decision cache、没有自动retry。每条件重复同一payload SHA；真实Jev usage只有input/output字段，不能确认服务端cache命中/缓存状态或保证独立抽样。未改变中文内容/ID集/criterion/true-false、question-map key顺序，未删候选、未换语言或追调阈值。

|题/目标ID|O与F位置|P目标位置|O / F / P payload UTF8字节|每次input O/F/P；output|目标p：O / F / P各两次|
|---|---:|---:|---:|---|---|
|更正 m1|14|0|6936 / 7192 / 6936|2788 / 2948 / 2788；282|.08/.05；.03/.11；.94/.94|
|否定 m0|15|0|7011 / 7267 / 7011|2838 / 2998 / 2838；282|.04/.04；.64/.66；.97/.97|
|时效 m1|1|15|6932 / 7188 / 6932|2781 / 2941 / 2781；282|.97/.97；.95/.97；.07/.06|

F state/candidate顺序完全不变，但所有问题instructions同时加backticks及`.text`等显式引用，较O各+256 UTF8字节/+160 input tokens，不能分出引用样式与增加字段细节贡献。P是**取出目标并插到首/尾，其他项整体顺移**，并非仅交换两个候选；所有ID对应的问题数字下标同步更新、问句基本文字保持O形式。数组元素位置和路径数字下标同时变化，只能称这个组合对概率敏感，无法区分尾部attention与数字下标解析。O/P总体payload长度、实际input/output相等，可排除本组总长度改变；不能排除顺序/路径/内容相互作用或推广到其他长度。每条件全候选ID顺序、payloadSHA和真实返回保存在机器摘要与freeze。

总input51402/output5076，7.302439秒是18个selector请求wall和，不是任务时间。去hard cutoff的旧实际概率回放只能证明注入覆盖可能改善，未跑final。外部文档要求named state/backticked nested paths、ID只作代码标识（[API](https://docs.typesafe.ai/api)）；不能因本地ID断言通过就说模型一定正确读了自然语言路径。

## r11 原语义复用、执行及公平控制

从固定原源码用白名单AST字面量提取19问题：consolidation5、routing6、stopping4、traversal4，保留MIT。只解析常量/声明占位值/字符串组合/受限Noul与Choice调用节点，没有运行外部Python。**字面量复用不是原算法/调用调度复现**：自己的TS raw endpoints、fixture构图、一次depth1、1anchor永久保留/1扩展；没有原MAGMA builder、largest-remainder budgets、按needs调深度、beam循环、15秒global deadline、16call队列、LRU/fallback。逐模块四项判定见矩阵。

只有2个图题，源文本预置m0提到[m1]/[m2]/[m3]，{r11edge} 解析存在且合法scope ID并保留source_text，gold只给验收，不给构边或模型。共有BGE真实生产search/getById，4节点/3邻居一次扩展，一跳到必要事实；身份字段需跨记录查，退款两事实同在m1，**不是深度≥2的连续graph traversal**。固定合成引用图不是从真实写入推断语义/因果/时间四图，后者的维护/删除/恢复/版本owner未测。

routing原6命题/query state被消费进need评分和自建entity≥.1池过滤；本次C/D全保留m1,m2,m3，不减少候选或预算，multi_hop_need不改变固定depth。before-stop的代码可跳过traversal，但实际两题四组均未跳；after-stop只记录reason，固定depth1没有下一轮可取消。C两题充分，D身份.96/.09达门槛；D退款sufficient=.92、continue=.19未达.95/.15，因max_depth_1终止，不能报停止准确或节省轮次。

图任务绝对值：

{arm_table(graph)}

每组n=2，wall均值为两题wall和/2；token也给sum/mean，均无未知。D/C完整wall -61.8498%、input +34.13%、output -31.14%、total +19.8876%，联合门槛不通过。G逐题：退款100字符，241/40/281 tokens，1.518480秒；身份127字符，262/38/300 tokens，1.195600秒。**所有邻居本就能全装预算，原beam10/top40也不需淘汰这些节点**；自建top1约束放大模型相对弱B的选择优势，G排除“小图必须Jev”解释。只推荐有限规模确定性展开的研究，不能外推超预算大图。

时间统一为预热后retrieval开始到实际final返回及当时本地处理；包含C/D实际routing、stop、traversal、final请求和阶段审计persist/typed验证，G没有判断阶段。fixture建库/索引等待/预热setup另记、不计；终局evaluateAnswer在wall捕获后，不计；不是用户完整自由agent的最终交付时间。所有调用串行、内部Jev独立命题batch，未控制两服务硬件/负载/缓存；主服务cache-hit/miss已列，不能声称cache状态等同或小样本延迟稳定。C/D相同final模型/格式/输入证据预算，但调用形状不同。实际input含cached tokens，服务总input/output相加是用户指定指标，tokenizer不同，不等于同硬件工作量。

缓存30个成功请求只做hash(provider,request)→Map clone离线回放。没有实测生产LRU/淘汰/跨版本/并发/inflight共享，没有观察远端命中或重新计费；给C/D同样政策且0新remote，不能归Jev专属收益。

写入概率→.85门槛→representation→实际状态链：

|pair/provider|关键Noul p / 分类|Choice / selected p / confidence|merge资格|实际状态|
|---|---|---|---|---|
|转述 C/D|redundant .95/.94≥.85，contradiction 0/.04|merge .90/.89；confidence .90/.86|两者true|只记资格；未调用LLM摘要、未写store，原文未动|
|明确更新 C/D|obsolete 1.0/.96≥.85；contradiction 0/.19|merge .80/.61；confidence .80/.48|两者false（selected p<.85）|分类符合expected，不等于合并发生或完整写入通过|
|同时间冲突 C|contradiction .95≥.85正确；obsolete .90≥.85错|keep_separate .90；confidence .90|false|判据fail，但无删除/覆盖，不能叫数据损坏|
|同时间冲突 D|contradiction .80<.85漏检；obsolete .10正确|keep_separate .89；confidence .85|false|判据fail，不能称成功识别冲突；仍无store变更|

conflict不是“新记录更近就自动替换”，原命题明确同主体同时间不兼容 vs explicit supersede。Choice与各Noul独立，不借前一个答案。rawPreserved=true是harness不写库的事实及政策，不能归模型更准；也没有执行原代码link/attributes持久化。两个模型都不能凭此获得自动覆盖安全资格。非破坏建议而后LLM整合仍是可行接点，但要真实基线证明新增判断/生成净收益，当前xiaok无独立前台dedup LLM可省。

## 累计usage、失败与审计范围

155次尝试，153次known、2次旧unknown。**整体usage不完整**：已知input151642/output17883/total169525只是下界，不能把未知加0或声称完整总量。r4 Cselector HTTP400与r7 Bfinal transport_or_json_error未知：r4不能作完整C/D对比；r7 B整体token不能参与完整token胜负，1/3pass不意味着两次质量失败。r6 C/D、r7 C/D已执行子集和r9–r11比较usage完整，但r7 C/D质量不同，不给质量非劣性能胜利。失败时长计入对应任务，未知服务端是否完成/计费/actual model；不推测具体网络原因。

call wall累加262.251102秒为155请求占用wall和，**不是实验总耗时/用户总任务时间**。已知收费按官方峰/非峰与cache拆分情景USD0.043105926–0.081778626＋两次未知非负费用；非账单、未确认账号合同、无法给未知可证有限上界。费用低不能替代time/token目标。Jev output虽定价free，仍计output tokens。[Jev官方模型](https://docs.typesafe.ai/models)、[DeepSeek定价](https://api-docs.deepseek.com/quick_start/pricing)为取价来源。

冻结当时的免费audit已有结果通过51源码hash、74新增调用usage/状态、382嵌套映射、8冷暖记录。这些是完整性检查计数，不是独立质量样本、统计可靠性或架构覆盖率。新增最终整理检查每个行号关键词、公开源码hash、旧结果hash、round账本合计、doc链接。收尾期间其他任务推进HEAD并改package.json/lockfile，当前package.json已不同于r7/r9冻结快照（HEAD的package-lock改动与当前工作区是否匹配分开检查）；旧audit-existing.mts直接比当前源码不再作为收尾可通过命令，改用audit-final.py核验冻结快照并单列当前漂移。此前合同测试是在原冻结环境通过，未在新依赖状态重跑；不称当前51文件仍一致。harness原6+r9 4+r11 3契约通过；冷暖首轮派生时间assert和auditor根package路径首轮失败已保留，修正只改本任务harness。

开工hygiene现存dirty worktrees/关联repo新鲜度未确认；governance缺node_modules/oxlint/package.json；architecture changed扫描999文件、152诊断、10新诊断在本实验外已有desktop改动。未更新baseline、未装依赖、不宣称全检查通过。未做production构建/Windows生产分支验证，因为没有production改动。工作区庞大脏状态未清理；实验HEAD冻结9eaf1aa8，收尾HEAD为{head}（他任务推进）；引用的生产文件两提交间无diff，核心memory与HEAD无diff，runtime/desktop工作区事实按本次SHA快照解释，不能把全仓库说clean。

## 建议与下一轮最小公平验证

1. **优先量现有结构，再决定改代码**：真实query输入、scope在topK前限定、跨层稳定source ID去重、利用已存在getById恢复正文/provenance、索引就绪/失败可观测、能装预算时直接展开明示关系。它们是共同架构候选；cache/getById已有等价项不重复建设。此次不能据合成收益宣布值得立即实施，需真实任务收益≥5%，不得计到Jev。
2. **不建议当前接法**：每次read新增远程全候选硬筛；小池四命题route/stop fanout；用概率自动删除/覆盖冲突；用Jev替代生成会话或L0/L1/L2摘要。r9已有anchor足够、r11全部候选装得下，新增判断有开销且无Jev必需质量空间。
3. **保留有条件机会**：共同架构已做到位、真实规模超过注入预算时，只让Jev判断少量难分残余候选/真实有来源边，或后台非破坏consolidation对；LLM继续生成摘要/整合。先证明该额外判断能降低完整任务时间和总tokens，而非只是selector更快。没有现成图owner/schema时，不为省一调用引入完整四图生命周期。
4. **下一轮不再扩192矩阵**：先另授权取得去标识真实中文语料和真实查询/失败例，冻结噪声比例、零/部分/高重叠、更新/否定/同名/scope/多证据/无答案分桶；量Hit@K/MRR/NDCG及无答案误召、最终引用/任务验收。先做无模型同预算规则/直接展开；确有难分超过预算问题才冻结小量E/B/C/D。所有组同精简上下文、同scope/source/候选/预算/缓存；C用同窄命题LLM、D用Jev，final同模型，先测冷/暖完整agent交付时间及所有input/output（含失败、fallback、额外摘要）。如果Dselector下限超过C完整或无质量增量/无双降，停止；不换桶/阈值追成功。可用已有trace检验合同，无需恢复旧付费结果。
5. 真实语料内容、真实应用频率/长期规模、复杂深度≥2/超预算图、owner/migration/恢复/更新生命周期、实际自动写入安全、中文时间/主体对齐、账单与Windows运行均需新数据/授权或专项验证；本阶段缺测如实记未知。没有这些证据不给生产接入资格，不把“缺测”当模型失败。

来源除逐行源码矩阵外：{evalref} 明确smoke非完整论文复现、默认best-of-3 reference-aware及LongMemEval lenient，结果须匹配embedding/cache/timing；不能直接搬作xiaok预期。官方[Noul](https://docs.typesafe.ai/primitives/noul)与[reranking cookbook](https://docs.typesafe.ai/cookbooks/rerank_typesafe)支持“code组合有限判断、LLM继续生成”，示例阈值不是本产品验证结果。
'''

index=f'''# xiaok memory / Jev-Mem 持续优化研究入口

2026-10-05，r1–r11阶段收束。**已测接法不获生产接入资格，完整Jev-Mem/真实中文/复杂超预算多跳尚未验证。** 本页只索引已有合成实验，不触碰真实memory。路径基准为仓库docs/design（docs symlink实际 ../mydocs/xiaok-cli/design）；本任务新增文件不替换旧轮结果。

- [整体适配报告]({PREFIX}final-report.md)：现状、全证据链、指标边界、推荐/不推荐与下一轮授权条件。
- [源码/语义/执行矩阵]({PREFIX}source-matrix.md)：固定原repo与xiaok函数行号，原命题、state、算法、执行分别判定。
- [最终机器摘要]({PREFIX}final-summary.json)：HEAD/工作区指纹、源码SHA、round freeze/result SHA、153known/155、unknown、r10全ID次序与数值、各组sum/mean。
- [阶段计划及充分性边界]({PREFIX}read-program.md)；[r11检查点]({PREFIX}read-r11-checkpoint.md)仅阶段快照，当前最终澄清以上述新报告为准。

|阶段|设计/报告|冻结与原请求结果|
|---|---|---|
|r1–r7|[原设计]({PREFIX}read-r1-design.md)、[原报告]({PREFIX}read-r1-report.md)、[原summary]({PREFIX}read-r1-summary.json)|[{PREFIX}read-r1-evidence/]({PREFIX}read-r1-evidence/)中offline-r1、offline-r2、live-pilot-r3/r4/r5、live-development-r6、offline-holdout-r7、live-holdout-r7；每目录freeze/results/corpus/gold，r7 source-snapshot；r6复核另文件|
|r8|[诊断]({PREFIX}read-r8-diagnostic.md)、[机器账本]({PREFIX}read-r8-diagnostic.json)、[审计脚本]({PREFIX}read-r8-audit.py)|固定公开源SHA、r7原请求/映射、旧79known/81尝试与未知账本|
|r9|[报告]({PREFIX}read-r9-report.md)、[设计]({PREFIX}read-r9-r11-evidence/module-r9/DESIGN.md)|[live新题freeze]({PREFIX}read-r9-r11-evidence/module-r9/results/live-new-r9/freeze.json)、[results]({PREFIX}read-r9-r11-evidence/module-r9/results/live-new-r9/results.json)、development及offline、[冷暖]({PREFIX}read-r9-r11-evidence/module-r9/cold-warm-results.json)|
|r10|[报告]({PREFIX}read-r10-report.md)、[设计]({PREFIX}read-r9-r11-evidence/diagnostic-r10/DESIGN.md)|[live freeze]({PREFIX}read-r9-r11-evidence/diagnostic-r10/live/freeze.json)、[results]({PREFIX}read-r9-r11-evidence/diagnostic-r10/live/results.json)、offline；原16候选未减|
|r11|[报告]({PREFIX}read-r11-report.md)、[设计]({PREFIX}read-r9-r11-evidence/semantic-r11/DESIGN.md)|[原19命题]({PREFIX}read-r9-r11-evidence/semantic-r11/questions.json)、[MIT]({PREFIX}read-r9-r11-evidence/semantic-r11/SOURCE-LICENSE)、[freeze]({PREFIX}read-r9-r11-evidence/semantic-r11/live/freeze.json)、[results]({PREFIX}read-r9-r11-evidence/semantic-r11/live/results.json)、offline/source-snapshot|
|r11b|[公平补控设计]({PREFIX}read-r9-r11-evidence/semantic-r11/ALL-NEIGHBORS-DESIGN.md)|[freeze]({PREFIX}read-r9-r11-evidence/semantic-r11/all-neighbors/freeze.json)、[results]({PREFIX}read-r9-r11-evidence/semantic-r11/all-neighbors/results.json)|

冻结参数对应入口（按freeze和代码重建，不冒称原shell历史逐字记录）：原run.mts的r1/r2为--mode offline --split development；r3/r4/r5为--mode live --split development --limit 2；r6 --mode live --split development；r7 --mode live --split holdout --repeats 2。r9 module-r9/run.mts --mode offline/live --split development/new --output 新目录；r10 diagnostic-r10/run.mts默认offline，--live真实调用；r11 semantic-r11/run.mts默认offline，--live真实调用；semantic-r11/all-neighbors.mts总是live。原r7计划192，仅完成12，不能为看报告重跑。所有写freeze的入口拒绝覆盖原目录；live须未来另冻结和授权。

免费复核命令（当前只用已有结果，零远程/不加载auth；最终审计同时核验冻结快照和当前文件）：

```sh
python3 scripts/evals/jev-memory-read/audit-final.py
```

源码harness合同（已通过，本轮不需要再跑）：原harness.test.mts 6项、module-r9/harness.test.mts 4项、semantic-r11/harness.test.mts 3项。本阶段完整性数量不是独立样本数/可靠性证明。日志在r9-r11-evidence中的logs；hygiene/oxlint/architecture既存阻塞另列，未update baseline。下一轮先指出未排除解释及决策价值，再要去标识真实语料授权；没有授权继续保持不读用户memory。
'''
for name,value in [(PREFIX+'final-summary.json',json.dumps(summary,ensure_ascii=False,indent=2)+'\n'),(PREFIX+'source-matrix.md',matrix_text),(PREFIX+'final-report.md',report),(PREFIX+'index.md',index)]:
    with (HERE/name).open('x') as f:f.write(value)
print(json.dumps({'head':head,'referencesChecked':len(refs),'known':total['known'],'attempts':total['attempts'],'remoteCalls':0,'newFiles':4},ensure_ascii=False))
