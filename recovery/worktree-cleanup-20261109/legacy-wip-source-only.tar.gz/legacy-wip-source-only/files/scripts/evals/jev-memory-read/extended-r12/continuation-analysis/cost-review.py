"""Final r12 cost review. Read existing traces; never call providers."""
import collections, datetime, hashlib, json, math, pathlib, statistics, zoneinfo
base=pathlib.Path(__file__).resolve().parents[1]
out=base/'continuation-analysis'
load=lambda p:json.loads(p.read_text())
result=load(base/'results/continuation-aggregate-v1/results.json')
rows=result['rows'];dev=load(base/'results/live-development-v3/results.json')['rows']
arms=['V','B','G','C','D']; contrasts=[('D','C'),('D','B'),('D','G'),('D','V'),('C','C_fixed'),('D','D_fixed')]
def fee(c,cache='observed',price='holiday_offpeak'):
    i,o=c.get('inputTokens'),c.get('outputTokens')
    if i is None or o is None:return None
    if c['provider']=='jev':return i*.042/1e6
    u=c.get('usage') or {};h,m=u.get('prompt_cache_hit_tokens'),u.get('prompt_cache_miss_tokens')
    if cache=='all_miss':h,m=0,i
    elif cache=='uniform_half_hit':h,m=i/2,i/2
    if not isinstance(h,(int,float)) or not isinstance(m,(int,float)) or h+m!=i:return None
    t=datetime.datetime.fromisoformat(c['startedAt'].replace('Z','+00:00'))
    hour=t.hour+t.minute/60+t.second/3600
    peak=price=='all_peak' or price=='weekday_without_holiday' and t.weekday()<5 and (1<=hour<4 or 6<=hour<10)
    return (h*.022+m*.66+o*1.98)*(2 if peak else 1)/1e6
def rf(r,cache='observed',price='holiday_offpeak'):
    if r['status']=='started':return None
    fs=[fee(c,cache,price) for c in r['calls']]
    return sum(fs) if fs and all(x is not None for x in fs) else None
def dist(vals):
    v=sorted(vals)
    return {'n':len(v),'sum':sum(v),'mean':statistics.mean(v),'median':statistics.median(v),'p95NearestRank':v[math.ceil(.95*len(v))-1]} if v else None
def summarize(rs):
    calls=[c for r in rs for c in r['calls']];final=[r for r in rs if r['status']!='started']
    providers={}
    for p in ['deepseek','jev']:
        cs=[c for c in calls if c['provider']==p];known=[c for c in cs if fee(c) is not None]
        providers[p]={'knownCalls':len(known),'recordedUnknownUsage':len(cs)-len(known),
          'input':sum(c['inputTokens'] for c in known),'output':sum(c['outputTokens'] for c in known),
          'cacheHit':sum((c.get('usage') or {}).get('prompt_cache_hit_tokens',0) for c in known) if p=='deepseek' else None,
          'cacheMiss':sum((c.get('usage') or {}).get('prompt_cache_miss_tokens',0) for c in known) if p=='deepseek' else None,
          'knownUSD':sum(fee(c) for c in known),'models':sorted({c.get('actualModel') for c in cs if c.get('actualModel')})}
    q=collections.Counter(r['status'] for r in rs)
    return {'plannedRows':len(rs),'finalizedRows':len(final),'pass':q['pass'],'qualityFailure':q['quality_failure'],
            'serviceFailure':q['service_failure'],'unknownOutcome':q['started'],
            'wallSecondsFinalized':dist([r['wallMs']/1000 for r in final]),
            'USDFinalizedTasks':dist([rf(r) for r in final if rf(r) is not None]),
            'knownUSDAllRecordedCalls':sum(fee(c) for c in calls if fee(c) is not None),
            'knownUSDPartialUnknownRows':sum(fee(c) for r in rs if r['status']=='started' for c in r['calls'] if fee(c) is not None),
            'providers':providers,
            'byOutcome':{k:{'rows':sum(r['status']==k for r in rs),'knownUSD':sum(fee(c) for r in rs if r['status']==k for c in r['calls'] if fee(c) is not None),
                           'wallKnownRows':sum(r['status']==k and 'wallMs' in r for r in rs),
                           'wallSecondsKnown':sum(r['wallMs']/1000 for r in rs if r['status']==k and 'wallMs' in r) if any(r['status']==k and 'wallMs' in r for r in rs) else None} for k in ['pass','quality_failure','started','service_failure']}}
def paired(left,right,rs,cache='observed',price='holiday_offpeak'):
    lm={r['caseId']:r for r in rs if r['arm']==left};rm={r['caseId']:r for r in rs if r['arm']==right}
    ps=[(lm[k],rm[k]) for k in sorted(lm.keys()&rm.keys()) if rf(lm[k],cache,price) is not None and rf(rm[k],cache,price) is not None]
    if not ps:return {'n':0}
    lc,rc=[rf(l,cache,price) for l,r in ps],[rf(r,cache,price) for l,r in ps]
    lt,rt=[l['wallMs']/1000 for l,r in ps],[r['wallMs']/1000 for l,r in ps]
    return {'n':len(ps),'leftPass':sum(l['status']=='pass' for l,r in ps),'rightPass':sum(r['status']=='pass' for l,r in ps),
            'leftUSD':dist(lc),'rightUSD':dist(rc),'USDDeltaLeftMinusRight':sum(lc)-sum(rc),
            'USDRatio':sum(lc)/sum(rc),'leftSeconds':dist(lt),'rightSeconds':dist(rt),
            'secondsDeltaLeftMinusRight':sum(lt)-sum(rt),'timeRatio':sum(lt)/sum(rt),
            'pairedTaskDeltaUSD':dist([l-r for l,r in zip(lc,rc)]),'pairedTaskDeltaSeconds':dist([l-r for l,r in zip(lt,rt)])}
def mechanism(arm):
    rs=[r for r in rows if r['arm']==arm and r['status']!='started']; ts=[(r,t) for r in rs for t in r.get('trace',[])]
    early=[(r,t) for r,t in ts if t.get('actualEarlyStop')]
    filters=[(r,t) for r,t in ts if t.get('routingSkippedIds') and not t.get('routeEmptySharedFallback')]
    fallback=[(r,t) for r,t in ts if t.get('routeEmptySharedFallback')]
    bm={r['caseId']:r for r in rows if r['arm']=='B'}
    ranking=[]
    for r in rs:
        if not r.get('trace') or not bm[r['caseId']].get('trace'):continue
        t=r['trace'][0];b=bm[r['caseId']]['trace'][0]
        if not t.get('actualEarlyStop') and t['candidateIds']==b['candidateIds'] and t['evidenceIds']==b['evidenceIds']:
            ranking.append({'caseId':r['caseId'],'modelAdded':t.get('addedIds'),'ruleAdded':b.get('addedIds'),
                            'changed':t.get('addedIds')!=b.get('addedIds')})
    return {'finalizedTasks':len(rs),'judgeIterations':len(ts),'stopReasons':dict(collections.Counter(r['stopReason'] for r in rs)),
            'depths':dict(collections.Counter(str(r['depth']) for r in rs)),
            'earlyStopTasks':len(early),'earlyStopSkippedCandidates':sum(len(t.get('skippedCandidateIds',[])) for r,t in early),
            'actualNonemptyRouteFilterIterations':len(filters),'routeFilteredCandidateOccurrences':sum(len(t['routingSkippedIds']) for r,t in filters),
            'actualRouteFilterTasks':len({r['caseId'] for r,t in filters}),'emptyRouteFallbackIterations':len(fallback),
            'routeFilterEvidence':[{'caseId':r['caseId'],'depth':t['depth'],'excludedIds':t['routingSkippedIds'],'addedIds':t.get('addedIds')} for r,t in filters],
            'sameInitialStateRankingComparisons':ranking,'firstStepAdditionsDifferFromB':sum(t['changed'] for t in ranking),
            'interpretation':'actual filtering/stopping/additions observed; semantic necessity not established; fallback exclusions not counted as applied'}
review={'mainObjective':'quality + complete benchmark read time + USD public-price estimate; tokens diagnostic',
    'historicalAcceptance':'previous frozen quality/time/total-input-output-token reduction criterion retained as historical; not passed',
    'priceBasis':{'primary':'observed cache; Oct6 China public holiday => offpeak; not invoice or verified account contract',
      'deepseekUSDPerMillion':{'hit':.022,'miss':.66,'output':1.98,'peakMultiplier':2},'jevUSDPerMillion':{'input':.042,'output':0},
      'weekdayPeakUTCWindows':['01:00-04:00','06:00-10:00'],'holidayDates':['2026-10-01','2026-10-07'],
      'sources':['https://api-docs.deepseek.com/quick_start/pricing/','https://docs.typesafe.ai/models','https://www.scio.gov.cn/zdgz/jj/202511/t20251110_938367.html']},
    'scope':{'plannedTasks':60,'mainRows':300,'ablationRows':24,'finalizedMainRows':299,'unknownOriginalC':1,'completeFiveArmPairs':59,
      'knownValidationCalls':635,'knownDevelopmentCalls':92,'newCallsThisReview':0,'notIndependent':'10 shared event grammars crossed with six scene profiles; development shares all grammars'},
    'byArm':{a:summarize([r for r in rows if r['arm']==a]) for a in arms+['C_fixed','D_fixed']},
    'developmentByArm':{a:summarize([r for r in dev if r['arm']==a]) for a in arms},
    'contrasts':{l+'/'+r:paired(l,r,rows) for l,r in contrasts},
    'commonSuccessDiagnostic':{l+'/'+r:paired(l,r,[x for x in rows if x['status']=='pass']) for l,r in contrasts},
    'sensitivity':{cache+'/'+price:{l+'/'+r:paired(l,r,rows,cache,price) for l,r in contrasts} for cache in ['observed','all_miss','uniform_half_hit'] for price in ['holiday_offpeak','all_peak','weekday_without_holiday']},
    'byPhase':{p:{a:summarize([r for r in rows if r['arm']==a and r['phase']==p]) for a in arms+['C_fixed','D_fixed']} for p in ['original','continuation']},
    'samePhaseContrasts':{p:{l+'/'+r:paired(l,r,[x for x in rows if x['phase']==p]) for l,r in contrasts} for p in ['original','continuation']},
    'byStartingOrder':{str(k):{a:summarize([r for r in rows if r['arm']==a and r.get('order')==k]) for a in arms} for k in range(5)},
    'byBucket':{b:{a:summarize([r for r in rows if r['arm']==a and r['bucket']==b]) for a in arms} for b in sorted({r['bucket'] for r in rows})},
    'byProfile':{f:{a:summarize([r for r in rows if r['arm']==a and r['family']==f]) for a in arms} for f in sorted({r['family'] for r in rows})},
    'leaveOneProfileOut':{f:{l+'/'+r:paired(l,r,[x for x in rows if x['family']!=f]) for l,r in contrasts} for f in sorted({r['family'] for r in rows})},
    'mechanism':{a:mechanism(a) for a in ['C','D','C_fixed','D_fixed']},
    'failuresAndUnknown':[{'caseId':r['caseId'],'arm':r['arm'],'phase':r['phase'],'status':r['status'],'evaluation':r.get('evaluation'),
                         'knownUSD':sum(fee(c) for c in r['calls'] if fee(c) is not None),'wallSeconds':r.get('wallMs',None)/1000 if r.get('wallMs') is not None else None} for r in rows if r['status']!='pass'],
    'unknowns':{'originalC':'one started row, one known returned judgment; possibly unrecorded final request/outcome/fee unknown; never retried',
                'failedDevelopmentDNS':'three earlier transport attempts, no response/usage; fees unknown; not counted as zero or model quality failure'},
    'metrics':'wall total and per-task mean/median/p95 nearest rank over finalized tasks, retaining quality failures; cost-all-calls additionally includes known interrupted judgment; tokens per-provider usage',
    'sourceHashes':{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base/'results/continuation-aggregate-v1/results.json',base/'results/live-validation-v4/results.json',base/'results/continuation-live-v1/results.json',base/'results/live-development-v3/results.json']}}
review['knownFeeLedger']={'validationMain':sum(review['byArm'][a]['knownUSDAllRecordedCalls'] for a in arms),
                         'validationAblations':sum(review['byArm'][a]['knownUSDAllRecordedCalls'] for a in ['C_fixed','D_fixed']),
                         'development':sum(review['developmentByArm'][a]['knownUSDAllRecordedCalls'] for a in arms)}
review['knownFeeLedger']['allKnown']=sum(review['knownFeeLedger'].values())
review['knownFeeLedger']['actualTotal']='allKnown + unknown original possible final + three unknown failed-development attempts; no finite verified upper bound'
review['scenarioFeeLedgers']={}
for cache in ['observed','all_miss','uniform_half_hit']:
    for price in ['holiday_offpeak','all_peak','weekday_without_holiday']:
        group=lambda rs:sum(fee(c,cache,price) for r in rs for c in r['calls'] if fee(c,cache,price) is not None)
        parts={'main':group([r for r in rows if r['arm'] in arms]),'ablation':group([r for r in rows if r['arm'].endswith('_fixed')]),'development':group(dev)}
        review['scenarioFeeLedgers'][cache+'/'+price]={**parts,'allKnown':sum(parts.values()),'unknownNotFilledZero':True}
review['ablationActualDifferences']={}
for a in ['C','D']:
    am={r['caseId']:r for r in rows if r['arm']==a};fm={r['caseId']:r for r in rows if r['arm']==a+'_fixed'}
    review['ablationActualDifferences'][a]=[{'caseId':k,'mainDepth':am[k]['depth'],'fixedDepth':fm[k]['depth'],
       'mainJudgeIterations':len(am[k]['trace']),'fixedJudgeIterations':len(fm[k]['trace']),
       'selectedIdsDifferent':am[k]['selectedIds']!=fm[k]['selectedIds'],'mainSelectedIds':am[k]['selectedIds'],'fixedSelectedIds':fm[k]['selectedIds'],
       'mainStatus':am[k]['status'],'fixedStatus':fm[k]['status']} for k in sorted(fm)]
review['byCallKind']={}
for a in arms+['C_fixed','D_fixed']:
    rs=[r for r in rows if r['arm']==a]; kinds={}
    for kind in ['judgment','answer']:
        cs=[c for r in rs for c in r['calls'] if (c['kind']=='answer')==(kind=='answer')]
        kinds[kind]={'calls':len(cs),'input':sum(c['inputTokens'] for c in cs),'output':sum(c['outputTokens'] for c in cs),
                     'providers':sorted({c['provider'] for c in cs}),
                     'cacheHit':sum((c.get('usage') or {}).get('prompt_cache_hit_tokens',0) for c in cs) if any(c['provider']=='deepseek' for c in cs) else None,
                     'cacheMiss':sum((c.get('usage') or {}).get('prompt_cache_miss_tokens',0) for c in cs) if any(c['provider']=='deepseek' for c in cs) else None,
                     'knownUSD':sum(fee(c) for c in cs),'callSeconds':sum(c['wallMs']/1000 for c in cs)}
    review['byCallKind'][a]=kinds
review['ablationMainRows']={a:summarize([r for r in rows if r['arm']==a and r['caseId'] in {x['caseId'] for x in review['ablationActualDifferences'][a]}]) for a in ['C','D']}
path=out/'final-cost-review.json';path.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(path),'ledger':review['knownFeeLedger'],'contrasts':{k:{'n':v['n'],'USDLeft':v['leftUSD']['sum'],'USDRight':v['rightUSD']['sum'],'USDChangePct':(v['USDRatio']-1)*100,'timeChangePct':(v['timeRatio']-1)*100} for k,v in review['contrasts'].items()},'mechanism':{k:{p:v[p] for p in ['earlyStopTasks','actualNonemptyRouteFilterIterations','actualRouteFilterTasks','emptyRouteFallbackIterations','firstStepAdditionsDifferFromB']} for k,v in review['mechanism'].items()}},ensure_ascii=False))
