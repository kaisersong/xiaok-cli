import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { JevMemoryTrial } from '../../../desktop/electron/jev-memory-trial-service.js';
import { FileMemoryStore, type MemoryRecord } from '../../../src/ai/memory/store.js';
import { fixtures, fixtureRecords, EVAL_FREEZE, type Fixture } from './fixtures.js';
import { unknownUsage } from '../../../desktop/electron/jev-memory-trial-metrics.js';
import type { DecisionSelection } from '../../../src/ai/decision/types.js';
import type { TrialUsage } from '../../../desktop/shared/jev-memory-trial-types.js';
export interface AnswerResult {
    text: string;
    usage: TrialUsage;
    provider: string;
    model: string;
    costUsd: number | null;
    priceVersion: string;
}
export interface LiveEval {
    credentials: ConstructorParameters<typeof JevMemoryTrial>[1];
    answer: (query: string, records: MemoryRecord[]) => Promise<AnswerResult>;
}
export interface EvalRow {
    fixture: string;
    bucket: string;
    arm: string;
    quality: 'pass' | 'fail' | 'unknown';
    coverage: number | null;
    hitAtK: number | null;
    mrr: number | null;
    ndcg: number | null;
    falseRecall: number | null;
    readMs: number;
    taskMs: number;
    usage: TrialUsage;
    selectorUsage: TrialUsage;
    costUsd: number | null;
    selectorCostUsd: number | null;
    reason: string;
    finalModel: string;
    finalProvider: string;
    priceVersion: string;
    decisionProvider: string;
    decisionModel: string | null;
    decisionVersion: string;
    confidenceProfile: string;
    selectorEstimatedUsage: TrialUsage;
    localComputeUsd: number | null;
}
// Offline answers are a tiny synthetic grammar interpreter, shared across all arms; not an efficacy result.
function offlineAnswer(f: Fixture, rows: MemoryRecord[]): AnswerResult { return { text: JSON.stringify({ answer: f.answerable && rows.some(r => r.id === 'evidence') ? f.expected : 'UNKNOWN' }), usage: unknownUsage(), provider: 'offline', model: 'synthetic-final-v1', costUsd: null, priceVersion: 'offline-unknown' }; }
export async function runSyntheticEval(live?: LiveEval, selection: DecisionSelection = {provider:'typesafe-jev'}) {
    const dir = mkdtempSync(join(tmpdir(), 'xiaok-jev-eval-'));
    const rows: EvalRow[] = [];
    try {
        for (const [index, f] of fixtures.entries()) {
            const store = new FileMemoryStore(join(dir, f.id, 'memory'));
            for (const r of fixtureRecords(f))
                await store.save(r);
            const startRetrieval = performance.now();
            const candidates = (await store.listRelevant({ cwd: 'fixture-project', query: f.query })).slice(0, EVAL_FREEZE.candidateLimit);
            const retrievalMs = performance.now() - startRetrieval;
            const order = ['original', 'rules', 'decision'];
            for (const arm of [...order.slice(index % 3), ...order.slice(0, index % 3)]) {
                const scripted: typeof fetch = async (_url, init) => { const body = JSON.parse(String(init?.body)); return new Response(JSON.stringify({ model: 'offline-script', answers: Object.fromEntries(body.state.candidates.map((r: {
                        text: string;
                    }, i: number) => [`m${i}`, { type: 'noul', noul: 'allLow' in f ? 0 : r.text === f.fact && f.answerable ? .99 : .01 }])) })); };
                const trial = new JevMemoryTrial(join(dir, f.id, arm), live?.credentials ?? (async () => ({ apiKey: 'synthetic-only', model: 'offline-script', baseUrl: 'https://api.typesafe.ai' })), live ? fetch : scripted);
                trial.configure({ enabled: arm === 'decision', decision: selection }, { requestSource: 'user' });
                const start = performance.now();
                let quality: EvalRow['quality'] = 'unknown';
                let selected: MemoryRecord[] = [];
                let answer: AnswerResult = { text: '', usage: unknownUsage(), provider: live ? 'unknown' : 'offline', model: 'unknown', costUsd: null, priceVersion: 'unknown' };
                await trial.runTask({ taskId: `fixture-${f.id}`, sessionId: 'synthetic-eval', model: 'unknown' }, async () => {
                    selected = await trial.read({ query: f.query, cwd: 'fixture-project', candidates, retrievalMs });
                    try {
                        answer = live ? await live.answer(f.query, selected) : offlineAnswer(f, selected);
                        const parsed = JSON.parse(answer.text);
                        quality = parsed.answer === f.expected ? 'pass' : 'fail';
                    }
                    catch { /* protocol/network unknown, preserved */ }
                });
                const event = trial.snapshot().reads[0];
                const rank = selected.findIndex(r => r.id === 'evidence') + 1;
                rows.push({ fixture: f.id, bucket: f.bucket, arm, quality, coverage: f.answerable ? Number(rank > 0) : null, hitAtK: f.answerable ? Number(rank > 0) : null, mrr: f.answerable ? (rank > 0 ? 1 / rank : 0) : null, ndcg: f.answerable ? (rank > 0 ? 1 / Math.log2(rank + 1) : 0) : null, falseRecall: f.answerable ? null : Number(selected.length > 0), readMs: event.readWallMs, taskMs: performance.now() - start + retrievalMs, usage: answer.usage, selectorUsage: event.usage, costUsd: answer.costUsd !== null && event.costUsd !== null ? answer.costUsd + event.costUsd : null, selectorCostUsd: event.costUsd, reason: event.reason, finalModel: answer.model, finalProvider: answer.provider, priceVersion: answer.priceVersion, decisionProvider:selection.provider, decisionModel:event.model, decisionVersion:event.decisionVersion??'legacy-v1', confidenceProfile:event.confidenceProfile??'unknown', selectorEstimatedUsage:event.decision?.estimatedUsage??unknownUsage(), localComputeUsd:event.decision?.localComputeUsd??null });
            }
        }
    }
    finally {
        rmSync(dir, { recursive: true, force: true, maxRetries: 3 });
    }
    return { schema: 1, mode: live ? 'live' : 'offline', freeze: EVAL_FREEZE, limitations: ['synthetic fixtures only', 'decision arm identifies explicit provider; no automatic provider switch', 'rules arm is existing retrieval rules, same as original', 'offline uses scripted selector and deterministic final mock; quality is not service efficacy', 'no-answer false recall reports retained anchor', 'fixture task boundary: retrieval + selector + final answer, not full agent runtime'], rows };
}
