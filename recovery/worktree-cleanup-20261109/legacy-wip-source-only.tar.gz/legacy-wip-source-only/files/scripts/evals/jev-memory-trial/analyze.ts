import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { JevTrialMetrics } from '../../../desktop/electron/jev-memory-trial-metrics.js';
const args = process.argv.slice(2);
const option = (name: string) => { const i = args.indexOf(name); return i < 0 ? undefined : args[i + 1]; };
const file = option('--metrics-file');
if (!file)
    throw new Error('Provide --metrics-file for a content-free metrics file or exported JSON. This command never loads memories.');
const date = (name: string) => { const value = option(name); if (value === undefined)
    return undefined; const parsed = Date.parse(value); if (!Number.isFinite(parsed))
    throw new Error('invalid_date'); return parsed; };
const enabled = option('--enabled');
if (enabled !== undefined && !['true', 'false'].includes(enabled))
    throw new Error('invalid_enabled_filter');
const metrics = new JevTrialMetrics(resolve(file), false);
const groups = metrics.aggregate({ from: date('--from'), to: date('--to'), enabled: enabled === undefined ? undefined : enabled === 'true', implementation: option('--implementation'), model: option('--model'), provider: option('--provider'), decisionVersion: option('--decision-version'), finalModel: option('--final-model'), finalProvider: option('--final-provider') });
const report = { schema: 1, retention: metrics.snapshot().retention, interpretation: 'observational before/after, not randomized causal evidence; unreviewed is unknown; costUsd covers selector only; complete task price may remain unknown', groups };
const json = JSON.stringify(report, null, 2);
const output = option('--json');
if (output)
    writeFileSync(resolve(output), json);
else
    console.log(json);
const csv = option('--csv');
if (csv) {
    const keys = groups.length ? Object.keys(groups[0]) : [];
    writeFileSync(resolve(csv), [keys.join(','), ...groups.map(g => keys.map(k => { const v = g[k as keyof typeof g]; return v == null ? '' : '"' + (typeof v === 'object' ? JSON.stringify(v) : String(v)).replace(/"/g, '""') + '"'; }).join(','))].join('\n'));
}
