/**
 * KSwarm Service Manager
 *
 * Manages the kswarm server as a child process from Electron's main process.
 * - Spawns `node <kswarm>/src/server/index.js` on app ready
 * - Health checks via GET http://localhost:4400/health
 * - Auto-restart on crash (with backoff)
 * - Graceful shutdown on app quit
 */

import { createLocalSourceWriterLifetime } from '../../src/runtime/verification/local-source-writer-lifetime.js';
import { createOwnedServiceChildCloseTracker } from './owned-service-child-close.js';
import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { assertRoomWorkspaceSidecarProtocol, assertRoomWorkspaceStartupProtocol } from './room-workspace-protocol.js';
import { createHash, randomBytes } from 'node:crypto';
import { homedir } from 'node:os';
import { dirname, join, posix, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { app } from 'electron';
import {
  buildSeedAgentReconciliationPlan,
  createXiaokPoSeed,
  createXiaokWorkerSeed,
} from '../shared/kswarm-seed-contract.js';
import {
  getDevelopmentBrokerLaunchSpec,
  getDevelopmentServiceCandidates,
  type ServiceLaunchSpec,
} from './kswarm-service-paths.js';
import { loadConfig } from '../../src/utils/config.js';
import { buildManagedXiaokAgentPayload, buildManagedXiaokAgentSemanticPayload, diffManagedXiaokAgentPatch } from './managed-xiaok-agent.js';
import type { KSwarmHealthDiagnosticInput } from './kswarm-service-diagnostics.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const KSWARM_PORT = 4400;
const BROKER_PORT = 4318;
export const KSWARM_REQUEST_BASE_URLS = uniqueServiceUrls([
  `http://127.0.0.1:${KSWARM_PORT}`,
  `http://localhost:${KSWARM_PORT}`,
]);
const KSWARM_HEALTH_URLS = uniqueServiceUrls(KSWARM_REQUEST_BASE_URLS.map(url => `${url}/health`));
const BROKER_HEALTH_URLS = uniqueServiceUrls([
  `http://127.0.0.1:${BROKER_PORT}/health`,
  `http://localhost:${BROKER_PORT}/health`,
]);
const HEALTH_INTERVAL_MS = 10_000;
const HEALTH_CHECK_TIMEOUT_MS = 2_000;
const HEALTH_FAILURE_RESTART_THRESHOLD = 3;
const RESTART_BASE_DELAY_MS = 2_000;
const MAX_RESTART_DELAY_MS = 30_000;
const MAX_RESTART_ATTEMPTS = 10;
const MAX_PERSISTENCE_FAIL_STOP_RESTARTS = 3;
const REQUEST_TIMEOUT_MS = 30_000;
const DYNAMIC_WORKFLOW_FEATURE = 'dynamic_workflows';
const WORKFLOW_PATTERN_SCHEMA_VERSION = 'kswarm_workflow_patterns_v1';
const LEGACY_KSWARM_LOG_ROOT = join(homedir(), '.kswarm', 'logs');

/**
 * Resolve service paths:
 * - Production (app.isPackaged): <resourcesPath>/services/<name>/...
 * - Development: sibling repo at ../../<name>/ (relative to electron/ dir)
 *   or override via env KSWARM_SERVER_PATH / BROKER_SERVER_PATH
 */
function resolveServicePath(name: 'kswarm' | 'intent-broker', entryRelative: string): string | null {
  const envKey = name === 'kswarm' ? 'KSWARM_SERVER_PATH' : 'BROKER_SERVER_PATH';
  const envPath = process.env[envKey];
  if (envPath && existsSync(envPath)) return envPath;

  if (app.isPackaged) {
    // Production: bundled in resources/services/
    const bundled = join(process.resourcesPath, 'services', name, entryRelative);
    if (existsSync(bundled)) return bundled;
  }

  for (const p of getDevelopmentServiceCandidates(__dirname, name, entryRelative)) {
    if (existsSync(p)) return p;
  }
  return null;
}

/** Thrown when KSwarm service is not available (failed to start or crashed). */
export class KSwarmUnavailableError extends Error {
  constructor(reason: string) {
    super(`KSwarm service unavailable: ${reason}`);
    this.name = 'KSwarmUnavailableError';
  }
}

export function uniqueServiceUrls(urls: string[]): string[] {
  return Array.from(new Set(urls));
}

export function nextHealthFailureCount(current: number, ok: boolean): number {
  return ok ? 0 : current + 1;
}

export function shouldRestartAfterHealthFailures(
  failureCount: number,
  threshold = HEALTH_FAILURE_RESTART_THRESHOLD,
): boolean {
  return failureCount >= threshold;
}

// KSwarm durable-state fail-stop exit codes (see kswarm src/core/sqlite-persistence.js).
export const KSWARM_EXIT_SAVE_FAILED = 75; // durable commit failed -> limited restart from last revision
export const KSWARM_EXIT_LOAD_UNRECOVERABLE = 78; // corrupt/unrecoverable load -> terminal degraded, no auto-restart

export type KSwarmExitDecision =
  | { action: 'restart' }
  | { action: 'limited_restart'; reason: 'persistence_commit_failed' }
  | { action: 'terminal_degraded'; reason: 'persistence_unrecoverable' };

/**
 * Classify a KSwarm server exit code into a restart decision.
 * - 78: unrecoverable durable-state load/corruption -> terminal degraded (do NOT
 *   auto-restart; the same corrupt state would loop forever).
 * - 75: durable commit failure fail-stop -> limited restart from the last durable
 *   revision (still bounded by MAX_RESTART_ATTEMPTS).
 * - anything else (crash, signal, code 0): normal restart handling.
 */
export function classifyKSwarmExit(code: number | null | undefined): KSwarmExitDecision {
  if (code === KSWARM_EXIT_LOAD_UNRECOVERABLE) {
    return { action: 'terminal_degraded', reason: 'persistence_unrecoverable' };
  }
  if (code === KSWARM_EXIT_SAVE_FAILED) {
    return { action: 'limited_restart', reason: 'persistence_commit_failed' };
  }
  return { action: 'restart' };
}

export function transitionKSwarmTerminalDegraded(
  current: boolean,
  event: 'unrecoverable_exit' | 'ready',
): boolean {
  if (event === 'unrecoverable_exit') return true;
  if (event === 'ready') return false;
  return current;
}

export function shouldStopAfterPersistenceFailStops(
  count: number,
  maximum = MAX_PERSISTENCE_FAIL_STOP_RESTARTS,
): boolean {
  return count >= maximum;
}

export async function requestWithFallbackBaseUrls(options: {
  baseUrls: string[];
  path: string;
  init?: RequestInit;
  fetchImpl?: (input: string, init?: RequestInit) => Promise<Response>;
  timeoutMs?: number;
}): Promise<Response> {
  const fetchImpl = options.fetchImpl ?? fetch;
  const timeoutMs = options.timeoutMs ?? REQUEST_TIMEOUT_MS;
  const path = options.path.startsWith('/') ? options.path : `/${options.path}`;
  const urls = uniqueServiceUrls(options.baseUrls).map(baseUrl => `${baseUrl}${path}`);
  let lastError: Error | null = null;

  for (const url of urls) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      return await fetchImpl(url, { ...options.init, signal: controller.signal });
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        lastError = new Error(`KSwarm request timed out (${timeoutMs}ms): ${url}`);
      } else {
        lastError = error instanceof Error ? error : new Error('request failed');
      }
    } finally {
      clearTimeout(timer);
    }
  }

  throw new KSwarmUnavailableError(lastError?.message ?? 'all service endpoints failed');
}

export function resolveIntentBrokerRuntimeRoot(userDataPath: string): string {
  return joinServicePath(userDataPath, 'services', 'intent-broker');
}

export function resolveKSwarmServiceLogRoot(userDataPath?: string): string {
  if (userDataPath) return joinServicePath(userDataPath, 'logs');
  try {
    return join(app.getPath('userData'), 'logs');
  } catch {
    return LEGACY_KSWARM_LOG_ROOT;
  }
}

function joinServicePath(basePath: string, ...segments: string[]): string {
  if (basePath.startsWith('/') && !basePath.includes('\\')) {
    return posix.join(basePath, ...segments);
  }
  return join(basePath, ...segments);
}

/**
 * Shared auth secrets between the desktop main process and its long-lived
 * children (kswarm server, intent-broker).
 *
 * These were previously generated fresh per app launch. That is the root of a
 * token desync bug: the broker is a persistent process holding the token it was
 * first spawned with, so a later desktop launch that merely *reuses* the healthy
 * broker (see ensureBroker) was silently authenticated with a brand-new token the
 * broker does not know → all room calls returned `room_authentication_required`.
 *
 * Persisting the secrets makes them stable across launches, so a reused broker and
 * a restarted desktop always agree. If the file is absent (first run after upgrade
 * or migration) we regenerate and write it; persist failure is treated as
 * non-fatal and falls back to session-scoped secrets (matching prior behaviour)
 * so tests and unusual environments still work.
 */
interface RoomAuthSecrets {
  desktopRoomToken: string;
  kswarmRoomToken: string;
  desktopMutationToken: string;
}

const ROOM_SECRETS_FILE_NAME = 'room-auth-secrets.json';

function appUserDataPath(): string | null {
  try {
    return app.getPath('userData');
  } catch {
    return null;
  }
}

function generateRoomSecrets(): RoomAuthSecrets {
  return {
    desktopRoomToken: `xiaok-room-user-${randomBytes(32).toString('base64url')}`,
    kswarmRoomToken: `xiaok-room-system-${randomBytes(32).toString('base64url')}`,
    desktopMutationToken: `xiaok-desktop-${randomBytes(32).toString('base64url')}`,
  };
}

export function loadOrCreateRoomSecrets(explicitUserDataPath?: string): RoomAuthSecrets {
  const userDataPath = explicitUserDataPath ?? appUserDataPath();
  if (!userDataPath) return generateRoomSecrets();

  const secretsPath = join(userDataPath, ROOM_SECRETS_FILE_NAME);
  try {
    const raw = readFileSync(secretsPath, 'utf8');
    const parsed = JSON.parse(raw) as Partial<RoomAuthSecrets>;
    const secrets: RoomAuthSecrets = {
      desktopRoomToken: nonEmptyString(parsed.desktopRoomToken) ?? '',
      kswarmRoomToken: nonEmptyString(parsed.kswarmRoomToken) ?? '',
      desktopMutationToken: nonEmptyString(parsed.desktopMutationToken) ?? '',
    };
    if (secrets.desktopRoomToken && secrets.kswarmRoomToken && secrets.desktopMutationToken) {
      return secrets;
    }
  } catch {
    // missing/corrupt file → regenerate below
  }

  const secrets = generateRoomSecrets();
  try {
    writeFileSync(secretsPath, `${JSON.stringify(secrets, null, 2)}\n`, { mode: 0o600 });
  } catch {
    // non-fatal: session-scoped secrets keep things working
  }
  return secrets;
}

function nonEmptyString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : null;
}

export function buildIntentBrokerServiceEnv(options: {
  baseEnv?: NodeJS.ProcessEnv;
  cwd: string;
  port: number;
  repoRoot?: string;
  desktopRoomToken?: string;
  kswarmRoomToken?: string;
}): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { ...(options.baseEnv ?? process.env), PORT: String(options.port) };
  if (options.desktopRoomToken) env.INTENT_BROKER_DESKTOP_TOKEN = options.desktopRoomToken;
  if (options.kswarmRoomToken) env.INTENT_BROKER_KSWARM_TOKEN = options.kswarmRoomToken;
  const repoRoot = options.repoRoot || options.cwd;

  if (repoRoot !== options.cwd) {
    env.INTENT_BROKER_REPO_ROOT ||= repoRoot;
    env.INTENT_BROKER_CONFIG ||= joinServicePath(repoRoot, 'intent-broker.config.json');
    env.INTENT_BROKER_LOCAL_CONFIG ||= joinServicePath(options.cwd, 'intent-broker.local.json');
    env.INTENT_BROKER_DB ||= joinServicePath(options.cwd, '.tmp', 'intent-broker.db');
    env.INTENT_BROKER_HEARTBEAT_PATH ||= joinServicePath(options.cwd, '.tmp', 'broker.heartbeat.json');
  }

  return env;
}

function resolveBrokerLaunchSpec(): ServiceLaunchSpec | null {
  const envPath = process.env.BROKER_SERVER_PATH;
  if (envPath && existsSync(envPath)) {
    return {
      cwd: dirname(dirname(envPath)),
      entryPath: envPath,
      nodeArgs: ['--experimental-sqlite', envPath],
    };
  }

  if (app.isPackaged) {
    const repoRoot = join(process.resourcesPath, 'services', 'intent-broker');
    const entryPath = join(repoRoot, 'src', 'cli.js');
    if (existsSync(entryPath)) {
      return {
        cwd: resolveIntentBrokerRuntimeRoot(app.getPath('userData')),
        repoRoot,
        entryPath,
        nodeArgs: ['--experimental-sqlite', entryPath],
      };
    }
  }

  return getDevelopmentBrokerLaunchSpec(__dirname);
}

export interface KSwarmServiceStatus {
  running: boolean;
  port: number;
  pid: number | null;
  restartCount: number;
  lastError: string | null;
  terminalDegraded?: boolean;
  persistenceFailStopCount?: number;
  lastPersistenceFailStop?: string | null;
}

interface HealthJsonResult {
  ok: boolean;
  body: Record<string, unknown> | null;
  error: string | null;
  status?: number;
}

export function buildKSwarmHealthDiagnosticInput(options: {
  expectedEntryPath: string | null;
  expectedSourceHash?: string | null;
  health: HealthJsonResult;
  broker: HealthJsonResult;
  status: KSwarmServiceStatus;
  lastExit?: { code?: number | null; signal?: string | null; stderr?: string | null } | null;
}): KSwarmHealthDiagnosticInput {
  const listening = options.health.ok || typeof options.health.status === 'number';
  return {
    expectedEntryPath: options.expectedEntryPath,
    expectedSourceHash: options.expectedSourceHash ?? null,
    spawnEntryExists: Boolean(options.expectedEntryPath),
    managerRunning: options.status.running,
    port: {
      listening,
      pid: options.status.pid,
      command: options.status.pid ? 'desktop-owned kswarm service' : null,
    },
    health: {
      ok: options.health.ok,
      status: options.health.status,
      body: options.health.body,
      error: options.health.error,
    },
    broker: {
      ok: options.broker.ok,
      error: options.broker.error,
    },
    lastExit: options.lastExit ?? null,
  };
}

export type DesktopRelatedServiceId = 'kswarm' | 'intent-broker' | 'runtime-bridge';

export interface DesktopRelatedServiceStatus {
  id: DesktopRelatedServiceId;
  label: string;
  running: boolean;
  reachable: boolean;
  port: number;
  pid: number | null;
  restartCount?: number;
  lastError: string | null;
  detail?: string;
}

export interface DesktopServiceStatusSnapshot {
  checkedAt: number;
  services: DesktopRelatedServiceStatus[];
}

export function buildBackgroundNodeSpawnOptions(options: {
  env?: NodeJS.ProcessEnv;
  cwd?: string;
  platform?: NodeJS.Platform;
}): {
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  stdio: ['ignore', 'pipe', 'pipe'];
  windowsHide?: boolean;
} {
  const platform = options.platform ?? process.platform;
  return {
    cwd: options.cwd,
    env: options.env,
    stdio: ['ignore', 'pipe', 'pipe'],
    ...(platform === 'win32' ? { windowsHide: true } : {}),
  };
}

export function resolveBackgroundNodeRuntime(options: {
  env?: NodeJS.ProcessEnv;
  execPath?: string;
  electronVersion?: string;
} = {}): {
  command: string;
  env: NodeJS.ProcessEnv;
} {
  const env = { ...(options.env ?? process.env) };
  const explicitNode = env.XIAOK_NODE_CMD?.trim();
  if (explicitNode) {
    return { command: explicitNode, env };
  }

  const command = options.execPath ?? process.execPath;
  const electronVersion = options.electronVersion ?? process.versions.electron;
  if (electronVersion) {
    env.ELECTRON_RUN_AS_NODE = '1';
  }
  return { command, env };
}

export function hasDynamicWorkflowSupport(body: Record<string, unknown> | null): boolean {
  const features = body?.features;
  return Array.isArray(features)
    && features.includes(DYNAMIC_WORKFLOW_FEATURE)
    && hasWorkflowPatternCapabilities(body);
}

export function hasWorkflowPatternCapabilities(body: Record<string, unknown> | null): boolean {
  const capabilities = body?.workflowCapabilities;
  if (!capabilities || typeof capabilities !== 'object' || Array.isArray(capabilities)) return false;
  const schemaVersion = (capabilities as Record<string, unknown>).schemaVersion;
  const compiledContract = (capabilities as Record<string, unknown>).compiledContract;
  const patternPublicView = (capabilities as Record<string, unknown>).patternPublicView;
  return schemaVersion === WORKFLOW_PATTERN_SCHEMA_VERSION
    && compiledContract === true
    && patternPublicView === true;
}

export function getKSwarmHealthServiceEntryPath(body: Record<string, unknown> | null): string | null {
  const service = body?.service;
  if (!service || typeof service !== 'object' || Array.isArray(service)) return null;
  const entryPath = (service as Record<string, unknown>).entryPath;
  return typeof entryPath === 'string' && entryPath.length > 0 ? entryPath : null;
}

export function getKSwarmHealthServiceSourceHash(body: Record<string, unknown> | null): string | null {
  const service = body?.service;
  if (!service || typeof service !== 'object' || Array.isArray(service)) return null;
  const sourceHash = (service as Record<string, unknown>).sourceHash;
  return typeof sourceHash === 'string' && sourceHash.length > 0 ? sourceHash : null;
}

export type KSwarmServiceIdentityWarning = 'source_hash_missing';
export type KSwarmServiceIdentityReason = 'service_identity_missing' | 'entry_path_mismatch' | 'source_hash_mismatch';

export interface KSwarmServiceIdentityCheck {
  compatible: boolean;
  reason: KSwarmServiceIdentityReason | null;
  warning: KSwarmServiceIdentityWarning | null;
  actualEntryPath: string | null;
  expectedEntryPath: string | null;
  actualSourceHash: string | null;
  expectedSourceHash: string | null;
}

export function computeKSwarmServiceSourceHash(entryPath: string | null): string | null {
  if (!entryPath) return null;
  const sourceRoot = dirname(dirname(resolve(entryPath)));
  try {
    const hash = createHash('sha256');
    const visit = (dir: string) => {
      const entries = readdirSync(dir, { withFileTypes: true })
        .sort((a, b) => a.name.localeCompare(b.name));
      for (const entry of entries) {
        const path = join(dir, entry.name);
        if (entry.isDirectory()) {
          visit(path);
          continue;
        }
        if (!entry.isFile() || !/\.(js|json)$/.test(entry.name)) continue;
        hash.update(relative(sourceRoot, path));
        hash.update('\0');
        hash.update(readFileSync(path));
        hash.update('\0');
      }
    };
    visit(sourceRoot);
    return hash.digest('hex');
  } catch {
    return null;
  }
}

export function doesKSwarmHealthMatchExpectedService(
  body: Record<string, unknown> | null,
  expectedEntryPath: string | null,
  expectedSourceHash: string | null = null,
): boolean {
  return checkKSwarmHealthServiceIdentity(body, expectedEntryPath, expectedSourceHash).compatible;
}

export function checkKSwarmHealthServiceIdentity(
  body: Record<string, unknown> | null,
  expectedEntryPath: string | null,
  expectedSourceHash: string | null = null,
): KSwarmServiceIdentityCheck {
  const actualEntryPath = getKSwarmHealthServiceEntryPath(body);
  const actualSourceHash = getKSwarmHealthServiceSourceHash(body);
  const base = {
    actualEntryPath,
    expectedEntryPath,
    actualSourceHash,
    expectedSourceHash,
  };
  if (!expectedEntryPath) {
    return { ...base, compatible: true, reason: null, warning: null };
  }
  if (!actualEntryPath) {
    return { ...base, compatible: false, reason: 'service_identity_missing', warning: null };
  }
  if (resolve(actualEntryPath) !== resolve(expectedEntryPath)) {
    return { ...base, compatible: false, reason: 'entry_path_mismatch', warning: null };
  }
  if (expectedSourceHash && !actualSourceHash) {
    return { ...base, compatible: true, reason: null, warning: 'source_hash_missing' };
  }
  if (expectedSourceHash && actualSourceHash !== expectedSourceHash) {
    return { ...base, compatible: false, reason: 'source_hash_mismatch', warning: null };
  }
  return { ...base, compatible: true, reason: null, warning: null };
}

export function appendKSwarmServiceLogLine(options: {
  logRoot?: string;
  serviceName: 'server' | 'broker';
  stream: 'stdout' | 'stderr' | 'lifecycle';
  message: string;
  now?: () => Date;
}): void {
  const lines = options.message
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean);
  if (lines.length === 0) return;
  const logRoot = options.logRoot ?? resolveKSwarmServiceLogRoot();
  try {
    mkdirSync(logRoot, { recursive: true });
    const ts = (options.now?.() ?? new Date()).toISOString();
    const payload = lines.map(line => `${ts} [${options.stream}] ${line}`).join('\n');
    appendFileSync(join(logRoot, `${options.serviceName}.log`), `${payload}\n`);
  } catch {
    // Logging must never prevent service startup.
  }
}

function logKSwarmServiceLine(
  serviceName: 'server' | 'broker',
  stream: 'stdout' | 'stderr' | 'lifecycle',
  message: string,
): void {
  appendKSwarmServiceLogLine({ serviceName, stream, message });
}

function formatServiceIdentityWarning(check: KSwarmServiceIdentityCheck): string {
  return [
    `source identity warning: ${check.warning}`,
    `expectedEntryPath=${check.expectedEntryPath ?? 'unknown'}`,
    `actualEntryPath=${check.actualEntryPath ?? 'unknown'}`,
    `expectedSourceHash=${check.expectedSourceHash ?? 'unknown'}`,
    `actualSourceHash=${check.actualSourceHash ?? 'unknown'}`,
  ].join(' ');
}

function formatServiceIdentityBlock(check: KSwarmServiceIdentityCheck): string {
  return [
    `existing kswarm service on port ${KSWARM_PORT} is not the bundled service`,
    `reason=${check.reason ?? 'unknown'}`,
    `expectedEntryPath=${check.expectedEntryPath ?? 'unknown'}`,
    `actualEntryPath=${check.actualEntryPath ?? 'unknown'}`,
    `expectedSourceHash=${check.expectedSourceHash ?? 'unknown'}`,
    `actualSourceHash=${check.actualSourceHash ?? 'unknown'}`,
  ].join('; ');
}

export function shouldAdoptExistingKSwarmService(input: {
  hasOwnedChild: boolean;
  healthOk: boolean;
  brokerReady?: boolean;
  dynamicWorkflowReady?: boolean;
  serviceIdentityMatches?: boolean;
}): boolean {
  return input.healthOk
    && input.brokerReady !== false
    && input.dynamicWorkflowReady !== false
    && input.serviceIdentityMatches !== false
    && !input.hasOwnedChild;
}

export interface KSwarmService {
  start(): Promise<void>;
  stop(): Promise<void>;
  restart(): Promise<void>;
  getStatus(): KSwarmServiceStatus;
  getServiceStatus(): Promise<DesktopServiceStatusSnapshot>;
  getHealthDiagnosticInput(): Promise<KSwarmHealthDiagnosticInput>;
  restartRelatedService(serviceId: DesktopRelatedServiceId): Promise<void>;
  onStatusChange(cb: (status: KSwarmServiceStatus) => void): () => void;
  getDesktopMutationToken(): string;
  getIntentBrokerRoomToken(): string;
  /** Make an HTTP request to the KSwarm service. Auto-starts if not running. */
  request(path: string, init?: RequestInit): Promise<Response>;
}

export interface CreateKSwarmServiceOptions {
  spawnProcess?: typeof spawn;
  findPortOwner?: typeof findPidOnPort;
  killStalePortOwner?: typeof killStaleServiceOnPort;
}

export type StalePortTermination = 'stopped' | 'aborted' | 'owner_changed' | 'not_found' | 'failed';

export async function terminateStalePortOwner(port: number, expectedPid: number, signal: AbortSignal, io: { findOwner(port: number): Promise<number | null>; signalProcess: typeof process.kill } = { findOwner: findPidOnPort, signalProcess: process.kill.bind(process) }): Promise<StalePortTermination> {
  if (signal.aborted) return 'aborted';
  const pid = await io.findOwner(port);
  if (signal.aborted) return 'aborted';
  if (pid == null || pid === process.pid) return 'not_found';
  if (pid !== expectedPid) return 'owner_changed';
  try {
    if (signal.aborted) return 'aborted';
    io.signalProcess(pid, 'SIGTERM');
  } catch { return 'failed'; }
  const deadline = Date.now() + 3_000;
  while (Date.now() < deadline) {
    await new Promise(resolve => setTimeout(resolve, 200));
    if (signal.aborted) return 'aborted';
    try { io.signalProcess(pid, 0); }
    catch (error) {
      return (error as NodeJS.ErrnoException).code === 'ESRCH' ? 'stopped' : 'failed';
    }
  }
  if (signal.aborted) return 'aborted';
  const currentPid = await io.findOwner(port);
  if (signal.aborted) return 'aborted';
  if (currentPid == null) return 'stopped';
  if (currentPid !== expectedPid) return 'owner_changed';
  try { io.signalProcess(pid, 'SIGKILL'); }
  catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ESRCH') return 'failed'; }
  // This is the legacy stale-listener recovery operation, not close/custody proof.
  await new Promise(resolve => setTimeout(resolve, 200));
  return signal.aborted ? 'aborted' : 'stopped';
}

export async function killStaleServiceOnPort(port: number, context?: { expectedPid: number; signal: AbortSignal }): Promise<boolean> {
  const pid = context?.expectedPid ?? await findPidOnPort(port);
  if (pid == null || pid === process.pid) return false;
  return await terminateStalePortOwner(port, pid, context?.signal ?? new AbortController().signal) === 'stopped';
}

export function findPidOnPort(port: number): Promise<number | null> {
  return new Promise(resolve => {
    if (process.platform === 'win32') {
      execFile('netstat', ['-ano', '-p', 'TCP'], (err, stdout) => {
        if (err) return resolve(null);
        for (const line of stdout.split('\n')) {
          if (line.includes(`:${port}`) && /LISTENING/i.test(line)) {
            const parts = line.trim().split(/\s+/);
            const pid = parseInt(parts[parts.length - 1], 10);
            if (pid > 0) return resolve(pid);
          }
        }
        resolve(null);
      });
    } else {
      // Filter to the LISTENING socket only. `lsof -ti :port` also returns every
      // process that merely *connects* to that port (clients), so taking the first
      // line can target a client instead of the real listener and miss the kill.
      // NOTE: `-iTCP:port` must be a single argument; splitting it into `-iTCP`
      // and `:port` makes lsof 4.x reject `:port` and exit with a usage error.
      execFile('lsof', ['-nP', `-iTCP:${port}`, '-sTCP:LISTEN', '-t'], (err, stdout) => {
        if (err) return resolve(null);
        const pid = parseInt(stdout.trim().split('\n')[0], 10);
        resolve(pid > 0 ? pid : null);
      });
    }
  });
}

/** Authentication failure never proves that an external listener is ours. */
export async function recoverOwnedBrokerAuthentication(options: {
  ownedPid: number | null;
  findOwner: () => Promise<number | null>;
  stopOwned: () => Promise<void>;
}): Promise<'external' | 'stopped'> {
  if (!Number.isSafeInteger(options.ownedPid) || !options.ownedPid || options.ownedPid <= 0) return 'external';
  const owner = await options.findOwner().catch(() => null);
  if (owner !== options.ownedPid) return 'external';
  await options.stopOwned();
  return 'stopped';
}

const instanceClosers = new WeakMap<KSwarmService, () => Promise<void>>();

/** Permanently closes this Main instance and observes its direct children close.
 * External services, descendants and remote work are not covered by this API. */
export function sealAndDrainKSwarmServiceInstance(service: KSwarmService): Promise<void> {
  const close = instanceClosers.get(service);
  if (!close) throw Error('kswarm_service_instance_unknown');
  return close();
}

export function createKSwarmService(options: CreateKSwarmServiceOptions = {}): KSwarmService {
  assertRoomWorkspaceStartupProtocol();
  const ingress = createLocalSourceWriterLifetime('kswarm_service');
  const background = createLocalSourceWriterLifetime('kswarm_service_background');
  const ownedChildren = createOwnedServiceChildCloseTracker();
  const closeAbort = new AbortController();
  let permanentlySealed = false;
  let closing: Promise<void> | undefined;
  const spawnProcess = options.spawnProcess ?? spawn;
  const findPortOwner = options.findPortOwner ?? findPidOnPort;
  const killStalePortOwner = options.killStalePortOwner ?? killStaleServiceOnPort;
  let child: ChildProcess | null = null;
  let brokerChild: ChildProcess | null = null;
  let running = false;
  let restartCount = 0;
  let lastError: string | null = null;
  let healthTimer: ReturnType<typeof setInterval> | null = null;
  let restartTimer: ReturnType<typeof setTimeout> | null = null;
  let stopping = false;
  let startingPromise: Promise<void> | null = null;
  let stopPromise: Promise<void> | null = null;
  let healthFailureCount = 0;
  let terminalDegraded = false;
  let persistenceFailStopCount = 0;
  let lastPersistenceFailStop: string | null = null;
  const suppressedServerExits = new WeakSet<ChildProcess>();
  const roomSecrets = loadOrCreateRoomSecrets();
  const desktopMutationToken = roomSecrets.desktopMutationToken;
  const desktopRoomToken = roomSecrets.desktopRoomToken;
  const kswarmRoomToken = roomSecrets.kswarmRoomToken;
  const listeners = new Set<(status: KSwarmServiceStatus) => void>();

  function getStatus(): KSwarmServiceStatus {
    return {
      running,
      port: KSWARM_PORT,
      pid: child?.pid ?? null,
      restartCount,
      lastError,
      terminalDegraded,
      persistenceFailStopCount,
      lastPersistenceFailStop,
    };
  }

  function notifyListeners() {
    const status = getStatus();
    for (const cb of listeners) {
      try { cb(status); } catch {}
    }
  }

  function onStatusChange(cb: (status: KSwarmServiceStatus) => void): () => void {
    listeners.add(cb);
    return () => { listeners.delete(cb); };
  }

  async function healthCheck(): Promise<boolean> {
    const result = await fetchHealthJsonFromUrls(KSWARM_HEALTH_URLS);
    return result.ok;
  }

  async function fetchHealthJson(url: string): Promise<HealthJsonResult> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), HEALTH_CHECK_TIMEOUT_MS);

    try {
      const res = await fetch(url, { signal: controller.signal });
      let body: Record<string, unknown> | null = null;
      let parseError: string | null = null;
      try {
        const parsed = await res.json();
        if (parsed && typeof parsed === 'object') {
          body = parsed as Record<string, unknown>;
        } else {
          parseError = 'health response JSON is not an object';
        }
      } catch (error) {
        parseError = error instanceof Error ? error.message : 'health response is not valid JSON';
      }
      if (res.ok && parseError) {
        return {
          ok: false,
          status: res.status,
          body: null,
          error: `invalid health JSON: ${parseError}`,
        };
      }
      return {
        ok: res.ok,
        status: res.status,
        body,
        error: res.ok ? null : `HTTP ${res.status}`,
      };
    } catch (error) {
      return {
        ok: false,
        body: null,
        error: error instanceof Error && error.name === 'AbortError'
          ? `health check timed out (${HEALTH_CHECK_TIMEOUT_MS}ms): ${url}`
          : error instanceof Error ? error.message : 'health check failed',
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async function fetchKSwarm(path: string, init?: RequestInit): Promise<Response> {
    const headers = new Headers(init?.headers);
    if ((init?.method ?? 'GET').toUpperCase() !== 'GET') {
      headers.set('x-kswarm-mutation-token', desktopMutationToken);
    }
    return requestWithFallbackBaseUrls({
      baseUrls: KSWARM_REQUEST_BASE_URLS,
      path,
      init: { ...init, headers },
      timeoutMs: REQUEST_TIMEOUT_MS,
    });
  }

  async function fetchHealthJsonFromUrls(urls: string[]): Promise<HealthJsonResult> {
    let lastResult: HealthJsonResult | null = null;
    for (const url of uniqueServiceUrls(urls)) {
      const result = await fetchHealthJson(url);
      if (result.ok) {
        return result;
      }
      lastResult = result;
    }
    return lastResult ?? {
      ok: false,
      body: null,
      error: 'no health endpoints configured',
    };
  }

  async function brokerHealthCheck(): Promise<boolean> {
    const result = await fetchHealthJsonFromUrls(BROKER_HEALTH_URLS);
    return result.ok;
  }

  /**
   * Probe an authenticated room endpoint to confirm the desktop token is
   * accepted by the running broker. A healthy broker that was spawned by an
   * older desktop session holds a different token; probing here lets
   * ensureBroker detect the stale-token state and respawn the broker under the
   * current (persisted) token instead of silently returning `room_authentication_required`.
   *
   * Returns false only on an explicit 401 (stale token). Any other reachable
   * status is treated as "token fine" so transient broker errors do not trigger
   * a live-respawn loop; unreachable brokers are left to the health check.
   */
  async function brokerDesktopTokenAccepted(): Promise<boolean> {
    const baseUrls = uniqueServiceUrls(BROKER_HEALTH_URLS.map(url => url.replace(/\/health$/, '')));
    for (const baseUrl of baseUrls) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), HEALTH_CHECK_TIMEOUT_MS);
      try {
        const res = await fetch(`${baseUrl}/rooms`, {
          signal: controller.signal,
          headers: { 'x-intent-broker-room-token': desktopRoomToken },
        });
        if (res.status === 401) return false;
        return true;
      } catch {
        // fall through to next base URL; unreachable is handled by the health check
      } finally { clearTimeout(timer); }
    }
    return true;
  }

  function startHealthCheck() {
    stopHealthCheck();
    if (permanentlySealed) return;
    healthTimer = setInterval(() => {
      if (permanentlySealed) return;
      void background.runAsync(async () => {
      if (!running || stopping) return;
      const ok = await healthCheck();
      healthFailureCount = nextHealthFailureCount(healthFailureCount, ok);
      if (!ok && !shouldRestartAfterHealthFailures(healthFailureCount)) {
        console.warn(`[kswarm-service] Health check failed (${healthFailureCount}/${HEALTH_FAILURE_RESTART_THRESHOLD}), will retry before restart`);
        return;
      }
      if (!ok && running && !stopping) {
        console.log('[kswarm-service] Health check failed repeatedly, attempting restart...');
        running = false;
        healthFailureCount = 0;
        stopHealthCheck();
        notifyListeners();
        await killOwnedServer();
        if (!stopping) scheduleRestart();
      }
      }).catch(error => { console.error('[kswarm-service] Health loop failed:', error); });
    }, HEALTH_INTERVAL_MS);
  }

  function stopHealthCheck() {
    if (healthTimer) {
      clearInterval(healthTimer);
      healthTimer = null;
    }
  }

  function clearRestartTimer() {
    if (restartTimer) {
      clearTimeout(restartTimer);
      restartTimer = null;
    }
  }

  async function reconcileSeedAgents(): Promise<void> {
    try {
      const res = await fetchKSwarm('/agents');
      if (!res.ok) return;
      const payload = await res.json() as { agents?: Array<Record<string, unknown>> };
      const agents = Array.isArray(payload.agents) ? payload.agents : [];
      const plan = buildSeedAgentReconciliationPlan(agents as never);
      const config = await loadConfig();
      const desiredSeeds = [
        buildManagedXiaokAgentPayload(createXiaokPoSeed(), config),
        buildManagedXiaokAgentPayload(createXiaokWorkerSeed(), config),
      ];
      let liveness: Record<string, { online: boolean }> = {};
      try {
        const livenessRes = await fetchKSwarm('/agents/liveness');
        if (livenessRes.ok) {
          const livenessPayload = await livenessRes.json() as { liveness?: Record<string, { online: boolean }> };
          liveness = livenessPayload.liveness ?? {};
        }
      } catch {
        liveness = {};
      }

      for (const desired of desiredSeeds) {
        if (!desired.id) {
          continue;
        }
        const existing = agents.find((agent) => agent.id === desired.id);
        if (!existing) {
          const createRes = await fetchKSwarm('/agents', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(buildManagedXiaokAgentSemanticPayload(desired)),
          });
          if (!createRes.ok && createRes.status !== 409) {
            console.warn(`[kswarm-service] Failed to create seed agent ${desired.id}: ${createRes.status}`);
          }
          continue;
        }

        const detailRes = await fetchKSwarm(`/agents/${desired.id}`);
        const detailPayload = detailRes.ok ? await detailRes.json() as { agent?: Record<string, unknown> } : null;
        const currentAgent = detailPayload?.agent ?? existing;
        const rawPatch = diffManagedXiaokAgentPatch(currentAgent, desired);
        const semanticPatch = rawPatch ? buildManagedXiaokAgentSemanticPayload(rawPatch, { update: true }) : {};
        const patch = Object.keys(semanticPatch).length > 0 ? semanticPatch : null;
        if (patch) {
          const updateRes = await fetchKSwarm(`/agents/${desired.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(patch),
          });
          if (!updateRes.ok) {
            console.warn(`[kswarm-service] Failed to update seed agent ${desired.id}: ${updateRes.status}`);
          }
        }

        const status = String(existing.status ?? 'offline');
        const isGhostOnline = status !== 'offline' && liveness[desired.id]?.online === false;
        if ((patch && status !== 'offline') || isGhostOnline) {
          const restartRes = await fetchKSwarm(`/agents/${desired.id}/restart`, {
            method: 'POST',
          });
          if (!restartRes.ok) {
            console.warn(`[kswarm-service] Failed to restart seed agent ${desired.id}: ${restartRes.status}`);
          }
        }
      }

      for (const agentId of plan.archive) {
        const archiveRes = await fetchKSwarm(`/agents/${agentId}`, {
          method: 'DELETE',
        });
        if (!archiveRes.ok && archiveRes.status !== 404) {
          console.warn(`[kswarm-service] Failed to archive legacy seed ${agentId}: ${archiveRes.status}`);
        }
      }
    } catch (error) {
      console.warn('[kswarm-service] Seed agent reconciliation failed:', (error as Error).message);
    }
  }

  function scheduleRestart() {
    if (permanentlySealed) return;
    if (terminalDegraded) {
      console.warn('[kswarm-service] Terminal degraded (unrecoverable durable state); skipping restart');
      return;
    }
    if (stopping || restartCount >= MAX_RESTART_ATTEMPTS) {
      if (restartCount >= MAX_RESTART_ATTEMPTS) {
        lastError = `Max restart attempts (${MAX_RESTART_ATTEMPTS}) reached`;
        notifyListeners();
      }
      return;
    }
    if (restartTimer) return;
    const delay = Math.min(RESTART_BASE_DELAY_MS * Math.pow(2, restartCount), MAX_RESTART_DELAY_MS);
    console.log(`[kswarm-service] Scheduling restart in ${delay}ms (attempt ${restartCount + 1})`);
    restartTimer = setTimeout(() => {
      restartTimer = null;
      if (permanentlySealed) return;
      void background.runAsync(async () => {
      if (!stopping && !running && !child) {
        restartCount++;
        try {
          await spawnServerOnce();
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          running = false;
          lastError = `KSwarm restart failed: ${message}`;
          console.error(`[kswarm-service] ${lastError}`);
          logKSwarmServiceLine('server', 'lifecycle', lastError);
          notifyListeners();
          if (!stopping) scheduleRestart();
        }
      }
      }).catch(error => { console.error('[kswarm-service] Restart loop failed:', error); });
    }, delay);
  }

  async function spawnServerOnce(): Promise<void> {
    if (startingPromise) {
      await startingPromise;
      return;
    }
    startingPromise = spawnServer().finally(() => {
      startingPromise = null;
    });
    await startingPromise;
  }

  async function ensureBroker(): Promise<boolean> {
    // Check if broker is already running
    if (await brokerHealthCheck()) {
      // A stale token can belong to an external installation. Authentication
      // failure is not permission to kill the listener or take over its data.
      if (stopping) return false;
      let brokerLaunch: ServiceLaunchSpec | null;
      try {
        brokerLaunch = resolveBrokerLaunchSpec();
      } catch {
        // Cannot determine whether we own/provision this broker (e.g. headless
        // test env where `app` is unavailable) — treat it as externally managed
        // rather than force a respawn.
        brokerLaunch = null;
      }
      if (!brokerLaunch) {
        // Externally-managed broker — assume it is configured correctly.
        return true;
      }
      if (await brokerDesktopTokenAccepted()) return true;
      const recovery = await recoverOwnedBrokerAuthentication({
        ownedPid: brokerChild?.pid ?? null,
        findOwner: () => findPortOwner(BROKER_PORT),
        stopOwned: stopOwnedBroker,
      });
      if (stopping) return false;
      if (recovery === 'external') {
        logKSwarmServiceLine('broker', 'lifecycle', 'unowned broker rejects desktop authentication; preserving listener, workspace unavailable');
        return true;
      }
      logKSwarmServiceLine('broker', 'lifecycle', 'owned broker stopped after stale authentication; restarting with persisted token');
    } else if (stopping) {
      return false;
    }

    const brokerLaunch = resolveBrokerLaunchSpec();
    if (!brokerLaunch) {
      console.log('[kswarm-service] Broker entry not found, assuming external broker');
      return true; // May be running externally
    }

    const brokerEnv = buildIntentBrokerServiceEnv({
      baseEnv: process.env,
      cwd: brokerLaunch.cwd,
      port: BROKER_PORT,
      repoRoot: brokerLaunch.repoRoot,
      desktopRoomToken,
      kswarmRoomToken,
    });
    const nodeRuntime = resolveBackgroundNodeRuntime({ env: brokerEnv });
    console.log(`[kswarm-service] Spawning broker: ${brokerLaunch.entryPath}`);
    logKSwarmServiceLine(
      'broker',
      'lifecycle',
      `spawn command=${nodeRuntime.command} entryPath=${brokerLaunch.entryPath} cwd=${brokerLaunch.cwd}`,
    );
    mkdirSync(brokerLaunch.cwd, { recursive: true });
    assertRoomWorkspaceSidecarProtocol(brokerLaunch.entryPath, 'intent-broker');
    const spawnedBroker = spawnProcess(nodeRuntime.command, brokerLaunch.nodeArgs, buildBackgroundNodeSpawnOptions({
      cwd: brokerLaunch.cwd,
      env: nodeRuntime.env,
    }));
    ownedChildren.track(spawnedBroker, 3_000);
    brokerChild = spawnedBroker;
    spawnedBroker.stdout?.on('data', (d: Buffer) => {
      const msg = d.toString().trim();
      if (msg) {
        console.log(`[broker] ${msg}`);
        logKSwarmServiceLine('broker', 'stdout', msg);
      }
    });
    spawnedBroker.stderr?.on('data', (d: Buffer) => {
      const msg = d.toString().trim();
      if (msg) {
        console.error(`[broker:err] ${msg}`);
        logKSwarmServiceLine('broker', 'stderr', msg);
      }
    });
    spawnedBroker.on('error', (error) => {
      logKSwarmServiceLine('broker', 'lifecycle', `Spawn error: ${error.message}`);
      if (brokerChild !== spawnedBroker) return;
      brokerChild = null;
      lastError = `Broker spawn failed: ${error.message}`;
      notifyListeners();
    });
    spawnedBroker.on('exit', (code) => {
      const message = `Broker exited: code=${code}`;
      console.log(`[kswarm-service] ${message}`);
      logKSwarmServiceLine('broker', 'lifecycle', message);
      if (brokerChild === spawnedBroker) brokerChild = null;
    });

    // Wait briefly for broker to be ready
    for (let i = 0; i < 10; i++) {
      await new Promise(r => setTimeout(r, 300));
      if (stopping) return false;
      if (await brokerHealthCheck()) return true;
    }
    return false;
  }

  async function replaceStalePortOwner(expectedPid?: number): Promise<boolean> {
    const pid = expectedPid ?? await findPortOwner(KSWARM_PORT);
    if (permanentlySealed || pid == null || pid === process.pid) return false;
    return killStalePortOwner(KSWARM_PORT, { expectedPid: pid, signal: closeAbort.signal });
  }

  async function spawnServer(): Promise<void> {
    if (child) return;
    const existingHealth = await fetchHealthJsonFromUrls(KSWARM_HEALTH_URLS);
    if (stopping) return;
    const existingHealthy = existingHealth.ok;
    const dynamicWorkflowReady = hasDynamicWorkflowSupport(existingHealth.body);
    const serverPath = resolveServicePath('kswarm', 'src/server/index.js');
    const expectedSourceHash = computeKSwarmServiceSourceHash(serverPath);
    const serviceIdentity = checkKSwarmHealthServiceIdentity(existingHealth.body, serverPath, expectedSourceHash);
    const serviceIdentityMatches = serviceIdentity.compatible;
    let killedStale = false;
    if (!existingHealthy && !child) {
      const portOwner = await findPortOwner(KSWARM_PORT);
      if (stopping) return;
      if (portOwner !== null && portOwner !== process.pid) {
        logKSwarmServiceLine(
          'server',
          'lifecycle',
          `replacing unhealthy orphan service pid=${portOwner} port=${KSWARM_PORT}`,
        );
        const killed = await replaceStalePortOwner(portOwner);
        if (permanentlySealed || stopping) return;
        if (!killed) {
          lastError = `failed to kill unhealthy orphan kswarm service on port ${KSWARM_PORT}`;
          running = false;
          notifyListeners();
          return;
        }
        killedStale = true;
      }
    }

    let brokerReady = await brokerHealthCheck();
    if (stopping) return;
    if (existingHealthy && serviceIdentity.warning) {
      const warning = formatServiceIdentityWarning(serviceIdentity);
      console.warn(`[kswarm-service] ${warning}`);
      logKSwarmServiceLine('server', 'lifecycle', warning);
    }
    if (existingHealthy && serverPath && !serviceIdentityMatches && !child) {
      const reason = formatServiceIdentityBlock(serviceIdentity);
      console.warn(`[kswarm-service] ${reason}`);
      logKSwarmServiceLine('server', 'lifecycle', `replacing stale service: ${reason}`);
      const killed = await replaceStalePortOwner();
      if (permanentlySealed || stopping) return;
      if (!killed) {
        lastError = `failed to kill stale kswarm service on port ${KSWARM_PORT}: ${reason}`;
        console.error(`[kswarm-service] ${lastError}`);
        logKSwarmServiceLine('server', 'lifecycle', lastError);
        running = false;
        notifyListeners();
        return;
      }
      killedStale = true;
      logKSwarmServiceLine('server', 'lifecycle', `stale service killed, proceeding with spawn`);
    }
    if (shouldAdoptExistingKSwarmService({
      hasOwnedChild: Boolean(child),
      healthOk: existingHealthy,
      brokerReady,
      dynamicWorkflowReady,
      serviceIdentityMatches,
    })) {
      console.log(`[kswarm-service] Adopting existing healthy kswarm service on port ${KSWARM_PORT}`);
      await reconcileSeedAgents();
      if (stopping) return;
      running = true;
      lastError = null;
      restartCount = 0;
      healthFailureCount = 0;
      startHealthCheck();
      notifyListeners();
      return;
    }

    if (existingHealthy && !dynamicWorkflowReady && !killedStale && !child) {
      const reason = `existing kswarm service on port ${KSWARM_PORT} does not support dynamic workflows`;
      console.warn(`[kswarm-service] ${reason}`);
      logKSwarmServiceLine('server', 'lifecycle', `replacing incompatible service: ${reason}`);
      const killed = await replaceStalePortOwner();
      if (permanentlySealed || stopping) return;
      if (!killed) {
        lastError = `failed to kill incompatible kswarm service on port ${KSWARM_PORT}`;
        console.error(`[kswarm-service] ${lastError}`);
        logKSwarmServiceLine('server', 'lifecycle', lastError);
        running = false;
        notifyListeners();
        return;
      }
      killedStale = true;
      logKSwarmServiceLine('server', 'lifecycle', `incompatible service killed, proceeding with spawn`);
    }

    if (existingHealthy && !killedStale && !child) {
      brokerReady = await ensureBroker();
      if (stopping) return;
      console.log(`[kswarm-service] Adopting existing kswarm service on port ${KSWARM_PORT}${brokerReady ? '' : ' (broker degraded)'}`);
      await reconcileSeedAgents();
      if (stopping) return;
      running = true;
      lastError = brokerReady ? null : 'intent-broker health check failed';
      restartCount = 0;
      healthFailureCount = 0;
      startHealthCheck();
      notifyListeners();
      return;
    }

    if (!serverPath) {
      lastError = 'kswarm server entry not found';
      console.error('[kswarm-service]', lastError);
      notifyListeners();
      return;
    }

    // Ensure broker is up first
    brokerReady = await ensureBroker();
    if (!brokerReady) {
      console.warn('[kswarm-service] Broker not ready after bootstrap attempt; starting kswarm in degraded mode');
    }

    const nodeRuntime = resolveBackgroundNodeRuntime({
      env: {
        ...process.env,
        KSWARM_PORT: String(KSWARM_PORT),
        BROKER_URL: `http://127.0.0.1:${BROKER_PORT}`,
        KSWARM_DESKTOP_MUTATION_TOKEN: desktopMutationToken,
        INTENT_BROKER_KSWARM_TOKEN: kswarmRoomToken,
        ...(await (async () => {
          try {
            const cfg = await loadConfig();
            const raw = cfg.kswarm?.maxConcurrentTasks;
            if (raw != null) {
              return { KSWARM_MAX_WORKER_INSTANCES: String(Math.max(1, Math.min(10, raw))) };
            }
          } catch {}
          return {};
        })()),
      },
    });
    if (stopping || child) return;
    console.log(`[kswarm-service] Spawning kswarm server: ${serverPath}`);
    logKSwarmServiceLine(
      'server',
      'lifecycle',
      `spawn command=${nodeRuntime.command} entryPath=${serverPath}`,
    );
    assertRoomWorkspaceSidecarProtocol(serverPath, 'kswarm');
    const serverChild = spawnProcess(nodeRuntime.command, [serverPath], buildBackgroundNodeSpawnOptions({
      env: nodeRuntime.env,
    }));
    ownedChildren.track(serverChild, 5_000);
    child = serverChild;

    serverChild.stdout?.on('data', (data: Buffer) => {
      const msg = data.toString().trim();
      if (msg) {
        console.log(`[kswarm] ${msg}`);
        logKSwarmServiceLine('server', 'stdout', msg);
      }
    });

    serverChild.stderr?.on('data', (data: Buffer) => {
      const msg = data.toString().trim();
      if (msg) {
        console.error(`[kswarm:err] ${msg}`);
        logKSwarmServiceLine('server', 'stderr', msg);
      }
    });

    serverChild.on('exit', (code, signal) => {
      const message = `Process exited: code=${code} signal=${signal}`;
      console.log(`[kswarm-service] ${message}`);
      logKSwarmServiceLine('server', 'lifecycle', message);
      if (child !== serverChild) return;
      child = null;
      running = false;
      if (!stopping && !suppressedServerExits.has(serverChild)) {
        const decision = classifyKSwarmExit(code);
        if (decision.action === 'terminal_degraded') {
          // Unrecoverable durable-state corruption: do NOT auto-restart, the same
          // state would loop forever. Enter a stable degraded state for diagnostics.
          terminalDegraded = transitionKSwarmTerminalDegraded(terminalDegraded, 'unrecoverable_exit');
          lastError = `KSwarm entered terminal degraded state (exit ${code}: ${decision.reason}); auto-restart disabled`;
          console.error(`[kswarm-service] ${lastError}`);
          logKSwarmServiceLine('server', 'lifecycle', lastError);
          notifyListeners();
          return;
        }
        if (decision.action === 'limited_restart') {
          persistenceFailStopCount += 1;
          lastPersistenceFailStop = `KSwarm fail-stop (exit ${code}: ${decision.reason})`;
          lastError = `${lastPersistenceFailStop}; restarting from last durable revision`;
          logKSwarmServiceLine('server', 'lifecycle', lastError);
          if (shouldStopAfterPersistenceFailStops(persistenceFailStopCount)) {
            lastError = `${lastPersistenceFailStop}; maximum limited restarts (${MAX_PERSISTENCE_FAIL_STOP_RESTARTS}) reached`;
            notifyListeners();
            return;
          }
        } else {
          lastError = `Process exited with code ${code}`;
        }
        notifyListeners();
        scheduleRestart();
      }
    });

    serverChild.on('error', (err) => {
      console.error('[kswarm-service] Spawn error:', err.message);
      logKSwarmServiceLine('server', 'lifecycle', `Spawn error: ${err.message}`);
      lastError = err.message;
      if (child !== serverChild) return;
      child = null;
      running = false;
      notifyListeners();
      if (!stopping) scheduleRestart();
    });

    // Wait for health check to confirm server is ready
    const ready = await waitForReady(8_000);
    if (ready && !stopping && child === serverChild) {
      await reconcileSeedAgents();
      if (stopping || child !== serverChild) return;
      running = true;
      lastError = null;
      restartCount = 0; // Reset on successful start
      healthFailureCount = 0;
      terminalDegraded = transitionKSwarmTerminalDegraded(terminalDegraded, 'ready');
      console.log(`[kswarm-service] Server ready on port ${KSWARM_PORT}`);
      logKSwarmServiceLine('server', 'lifecycle', `Server ready on port ${KSWARM_PORT}`);
      startHealthCheck();
      notifyListeners();
    } else if (!stopping) {
      console.log('[kswarm-service] Server did not become ready in time');
      logKSwarmServiceLine('server', 'lifecycle', 'Server did not become ready in time');
      lastError = 'Server startup timeout';
      running = false;
      notifyListeners();
      await killOwnedServer();
      if (!stopping) scheduleRestart();
    }
  }

  async function waitForReady(timeoutMs: number): Promise<boolean> {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (stopping) return false;
      const ok = await healthCheck();
      if (ok) return true;
      await new Promise(r => setTimeout(r, 500));
    }
    return false;
  }

  async function ensureReady(): Promise<void> {
    if (running) return;
    await start();
  }

  async function request(path: string, init?: RequestInit): Promise<Response> {
    await ensureReady();

    if (!running) {
      throw new KSwarmUnavailableError(lastError || 'KSwarm service failed to start');
    }

    return requestWithFallbackBaseUrls({
      baseUrls: KSWARM_REQUEST_BASE_URLS,
      path,
      init,
      timeoutMs: REQUEST_TIMEOUT_MS,
    });
  }

  function getDesktopMutationToken(): string {
    return desktopMutationToken;
  }

  function getIntentBrokerRoomToken(): string {
    return desktopRoomToken;
  }

  async function start(): Promise<void> {
    const requestedWhileStopping = stopping;
    const inFlightStop = stopPromise;
    if (inFlightStop) {
      await inFlightStop;
    }
    clearRestartTimer();
    if (running) return;
    const inFlightStart = startingPromise;
    if (inFlightStart) {
      await inFlightStart.catch(() => undefined);
      if (running || child) return;
      if (stopping && !requestedWhileStopping) return;
    }
    if (child) return;
    if (terminalDegraded || shouldStopAfterPersistenceFailStops(persistenceFailStopCount)) {
      throw new KSwarmUnavailableError(lastError || 'KSwarm automatic restart is blocked pending manual recovery');
    }
    if (stopping && !requestedWhileStopping) return;
    stopping = false;
    restartCount = 0;
    healthFailureCount = 0;
    lastError = null;
    await spawnServerOnce();
  }

  async function stop(): Promise<void> {
    if (stopPromise) {
      await stopPromise;
      return;
    }
    stopping = true;
    stopPromise = (async () => {
      stopHealthCheck();
      clearRestartTimer();
      await killOwnedServer();
      await stopOwnedBroker();
      running = false;
      healthFailureCount = 0;
      notifyListeners();
    })().finally(() => {
      stopPromise = null;
    });
    await stopPromise;
  }

  async function killOwnedServer(): Promise<void> {
    const ownedChild = child;
    if (!ownedChild) return;
    suppressedServerExits.add(ownedChild);
    let onExit!: () => void;
    let timer!: ReturnType<typeof setTimeout>;
    const exitPromise = new Promise<void>(resolve => {
      onExit = resolve;
      ownedChild.once('exit', onExit);
      timer = setTimeout(resolve, 5_000);
    });
    try {
      ownedChild.kill('SIGTERM');
      await exitPromise;
      if (child === ownedChild) { ownedChild.kill('SIGKILL'); child = null; }
    } finally {
      clearTimeout(timer);
      ownedChild.removeListener('exit', onExit);
    }
  }

  async function restart(): Promise<void> {
    await stop();
    const inFlightStart = startingPromise;
    if (inFlightStart) {
      await inFlightStart.catch(() => undefined);
    }
    stopping = false;
    restartCount = 0;
    persistenceFailStopCount = 0;
    lastPersistenceFailStop = null;
    terminalDegraded = false;
    await spawnServerOnce();
  }

  async function stopOwnedBroker(): Promise<void> {
    if (!brokerChild) return;
    const ownedBroker = brokerChild;
    let onExit!: () => void;
    let timer!: ReturnType<typeof setTimeout>;
    const exitPromise = new Promise<void>(resolve => {
      onExit = resolve;
      ownedBroker.once('exit', onExit);
      timer = setTimeout(resolve, 3_000);
    });
    try {
      ownedBroker.kill('SIGTERM');
      await exitPromise;
      if (brokerChild === ownedBroker) { ownedBroker.kill('SIGKILL'); brokerChild = null; }
    } finally {
      clearTimeout(timer);
      ownedBroker.removeListener('exit', onExit);
    }
  }

  async function getServiceStatus(): Promise<DesktopServiceStatusSnapshot> {
    const [kswarmHealth, brokerHealth] = await Promise.all([
      fetchHealthJsonFromUrls(KSWARM_HEALTH_URLS),
      fetchHealthJsonFromUrls(BROKER_HEALTH_URLS),
    ]);
    const brokerConnected = kswarmHealth.body?.brokerConnected;
    const kswarmDetail = kswarmHealth.ok
      ? brokerConnected === false
        ? 'broker disconnected'
        : brokerConnected === true
          ? 'broker connected'
          : 'health ok'
      : 'health check failed';
    return {
      checkedAt: Date.now(),
      services: [
        {
          id: 'kswarm',
          label: 'KSwarm',
          running: running || kswarmHealth.ok,
          reachable: kswarmHealth.ok,
          port: KSWARM_PORT,
          pid: child?.pid ?? null,
          restartCount,
          lastError: kswarmHealth.ok ? lastError : (lastError || kswarmHealth.error),
          detail: kswarmDetail,
        },
        {
          id: 'intent-broker',
          label: 'Intent Broker',
          running: Boolean(brokerChild) || brokerHealth.ok,
          reachable: brokerHealth.ok,
          port: BROKER_PORT,
          pid: brokerChild?.pid ?? null,
          restartCount: 0,
          lastError: brokerHealth.ok ? null : brokerHealth.error,
          detail: brokerHealth.ok ? 'health ok' : 'health check failed',
        },
      ],
    };
  }

  async function getHealthDiagnosticInput(): Promise<KSwarmHealthDiagnosticInput> {
    const serverPath = resolveServicePath('kswarm', 'src/server/index.js');
    const expectedSourceHash = computeKSwarmServiceSourceHash(serverPath);
    const [kswarmHealth, brokerHealth] = await Promise.all([
      fetchHealthJsonFromUrls(KSWARM_HEALTH_URLS),
      fetchHealthJsonFromUrls(BROKER_HEALTH_URLS),
    ]);
    return buildKSwarmHealthDiagnosticInput({
      expectedEntryPath: serverPath,
      expectedSourceHash,
      health: kswarmHealth,
      broker: brokerHealth,
      status: getStatus(),
    });
  }

  async function restartRelatedService(serviceId: DesktopRelatedServiceId): Promise<void> {
    if (serviceId === 'kswarm') {
      await restart();
      return;
    }
    await stopOwnedBroker();
    const ok = await ensureBroker();
    if (!ok) {
      throw new Error('intent_broker_restart_failed');
    }
    notifyListeners();
  }

  function sealAndDrain(): Promise<void> {
    if (closing) return closing;
    permanentlySealed = true;
    const drains = [ingress.close(), background.close()];
    closing = Promise.allSettled(drains).then(async outcomes => {
      const errors = outcomes.flatMap(outcome => outcome.status === 'rejected' ? [outcome.reason] : []);
      stopping = true;
      try { await ownedChildren.closeAll(); } catch (error) { errors.push(error); }
      running = false;
      healthFailureCount = 0;
      notifyListeners();
      if (errors.length) throw new AggregateError(errors, 'kswarm_service_close_unconfirmed');
    });
    // Publish the cached Promise before abort listeners can reenter.
    closeAbort.abort();
    stopHealthCheck();
    clearRestartTimer();
    return closing;
  }
  const service: KSwarmService = {
    start: async () => ingress.runAsync(start),
    stop: async () => ingress.runAsync(stop),
    restart: async () => ingress.runAsync(restart),
    request: async (path, init) => ingress.runAsync(() => request(path, init)),
    restartRelatedService: async id => ingress.runAsync(() => restartRelatedService(id)),
    getServiceStatus: async () => ingress.runAsync(getServiceStatus),
    getHealthDiagnosticInput: async () => ingress.runAsync(getHealthDiagnosticInput),
    getDesktopMutationToken: () => ingress.runSync(getDesktopMutationToken),
    getIntentBrokerRoomToken: () => ingress.runSync(getIntentBrokerRoomToken),
    getStatus, onStatusChange,
  };
  instanceClosers.set(service, sealAndDrain);
  return service;
}
