import type { Config } from '../../src/types.js';
import type { MemoryStore } from '../../src/ai/memory/store.js';
import { isCompactionModel, normalizeMemoryConfiguration, memorySettingsSnapshot, type MemoryCompactionResult } from '../../src/ai/memory/configuration.js';
import { MODEL_REGISTRY, isModelDownloaded, downloadModel, deleteEmbeddingModelFiles } from '../../src/ai/memory/model-registry.js';
import { createAdapterFromBinding } from '../../src/ai/models.js';
import { resolveRuntimeModelBinding, MissingProviderApiKeyError } from '../../src/ai/providers/control-plane.js';

type Source = { requestSource: 'user' | 'agent' | 'scheduler' };
type LLM = (prompt: string, signal?: AbortSignal) => Promise<string>;
interface Dependencies {
  load(): Promise<Config>;
  save(config: Config): Promise<void>;
  update?(mutate: (config: Config) => Config): Promise<Config>;
  store: MemoryStore;
  createLLM?(config: Config, id: string): LLM;
  isDownloaded?(id: string): boolean;
  timeoutMs?: number;
}

/** Main owns settings, the running compaction, and the existing store's consumers. */
export class MemorySettingsService {
  private running?: AbortController;
  private writes: Promise<unknown> = Promise.resolve();
  constructor(private readonly deps: Dependencies) {}
  private authorize(source: Source): void {
    if (source?.requestSource !== 'user') throw new Error('memory_settings_user_only');
  }
  private write<T>(action: () => Promise<T>): Promise<T> {
    const pending = this.writes.then(action);
    this.writes = pending.catch(() => {});
    return pending;
  }
  private async persist(mutate: (config: Config) => Config): Promise<Config> {
    if (this.deps.update) return this.deps.update(mutate);
    const next = mutate(await this.deps.load());
    await this.deps.save(next);
    return next;
  }
  async settings(source: Source) {
    this.authorize(source);
    return this.write(async () => {
      let config = await this.deps.load();
      const memory = normalizeMemoryConfiguration(config);
      if (JSON.stringify(memory) !== JSON.stringify(config.memory)) config = await this.persist(current => ({ ...current, memory: normalizeMemoryConfiguration(current) }));
      return memorySettingsSnapshot(config);
    });
  }
  async setCompactionModel(id: string | null, source: Source): Promise<boolean> {
    this.authorize(source);
    return this.write(async () => {
      await this.persist(config => {
        if ((id !== null && typeof id !== 'string') || !isCompactionModel(config, id ?? config.defaultModelId)) throw new Error('invalid_compaction_model');
        this.running?.abort();
        const memory = normalizeMemoryConfiguration(config);
        memory.compaction = { ...memory.compaction, modelId: id };
        memory.legacyModelUnresolved = false;
        return { ...config, memory };
      });
      return true;
    });
  }
  async setEmbeddingModel(id: string, source: Source): Promise<void> {
    this.authorize(source);
    return this.write(async () => {
      const model = MODEL_REGISTRY.find(m => m.id === id);
      if (!model) throw new Error('invalid_embedding_model');
      if (!(this.deps.isDownloaded ?? isModelDownloaded)(id)) throw new Error('embedding_model_not_downloaded');
      if (!this.deps.store.configureEmbedding) throw new Error('embedding_backend_unavailable');
      const embedding = { provider: 'local' as const, model: id, dimensions: model.dims };
      const previous: { embedding?: NonNullable<Config['memory']>['embedding'] } = {};
      await this.persist(config => {
        const memory = normalizeMemoryConfiguration(config); previous.embedding = memory.embedding;
        return { ...config, memory: { ...memory, embedding } };
      });
      if (previous.embedding?.provider === 'local' && previous.embedding.model === id && previous.embedding.dimensions === model.dims) return;
      try { this.deps.store.configureEmbedding({ ...embedding, apiUrl: 'http://localhost:11434/v1' }); }
      catch (error) {
        // Refresh before rollback, preserving unrelated settings written in the meantime.
        await this.persist(latest => JSON.stringify(latest.memory?.embedding) === JSON.stringify(embedding)
          ? { ...latest, memory: { ...latest.memory, embedding: previous.embedding } } : latest);
        throw error;
      }
    });
  }
  async downloadEmbeddingModel(id: string, source: Source): Promise<void> {
    this.authorize(source);
    return this.write(() => downloadModel(id));
  }
  async deleteEmbeddingModel(id: string, source: Source): Promise<void> {
    this.authorize(source);
    return this.write(async () => {
      if (!MODEL_REGISTRY.some(model => model.id === id)) throw new Error('invalid_embedding_model');
      const memory = normalizeMemoryConfiguration(await this.deps.load());
      if ((memory.embedding?.model ?? 'all-MiniLM-L6-v2') === id || this.deps.store.getEmbeddingModelId?.() === id) {
        throw new Error('embedding_model_active');
      }
      await deleteEmbeddingModelFiles(id, source);
    });
  }
  cancel(source: Source): boolean {
    this.authorize(source);
    if (!this.running) return false;
    this.running.abort(); return true;
  }
  async compact(source: Source): Promise<MemoryCompactionResult> {
    this.authorize(source);
    const empty = { processed: 0, extracted: 0, scenarios: 0, traits: 0 };
    if (this.running) return { ...empty, status: 'busy' };
    const controller = new AbortController(); this.running = controller;
    const timeout = setTimeout(() => controller.abort(new DOMException('timeout', 'TimeoutError')), this.deps.timeoutMs ?? 60000);
    try {
      await this.writes;
      const config = await this.deps.load();
      const memory = normalizeMemoryConfiguration(config);
      if (memory.legacyModelUnresolved) return { ...empty, status: 'skipped', reason: 'invalid_model' };
      const id = memory.compaction?.modelId ?? config.defaultModelId;
      if (!isCompactionModel(config, id)) return { ...empty, status: 'skipped', reason: config.models[id] ? 'invalid_model' : 'no_model' };
      if (!this.deps.store.compact || !this.deps.store.setLLMFn) return { ...empty, status: 'skipped', reason: 'unavailable' };
      controller.signal.throwIfAborted();
      const llm = this.deps.createLLM?.(config, id) ?? (await import('../../src/ai/memory/layered-store.js')).createLLMFromAdapter(createAdapterFromBinding(resolveRuntimeModelBinding(config, id)));
      const providerId = config.models[id].provider;
      const wireModel = config.models[id].model;
      const protocol = config.providers[providerId]?.protocol;
      const baseUrl = config.providers[providerId]?.baseUrl;
      // The store can retain this function for automatic compaction. Recheck each
      // call so a later settings/model metadata change cannot reuse a stale adapter.
      this.deps.store.setLLMFn(async (prompt, signal) => {
        signal?.throwIfAborted();
        const latest = await this.deps.load();
        const current = normalizeMemoryConfiguration(latest);
        if (current.legacyModelUnresolved || (current.compaction?.modelId ?? latest.defaultModelId) !== id
          || !isCompactionModel(latest, id) || latest.models[id].provider !== providerId
          || latest.models[id].model !== wireModel || latest.providers[providerId]?.protocol !== protocol
          || latest.providers[providerId]?.baseUrl !== baseUrl) throw new Error('invalid_compaction_model');
        signal?.throwIfAborted();
        return llm(prompt, signal);
      });
      return await this.deps.store.compact({ signal: controller.signal });
    } catch (error) {
      return { ...empty, status: controller.signal.aborted ? 'cancelled' : 'failed',
        reason: controller.signal.aborted ? controller.signal.reason?.name === 'TimeoutError' ? 'timeout' : undefined
          : error instanceof MissingProviderApiKeyError ? 'missing_credentials' : 'model_error' };
    } finally {
      clearTimeout(timeout);
      if (this.running === controller) this.running = undefined;
    }
  }
}
