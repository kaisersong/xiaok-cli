import { decisionRuntimeObservation } from '../../src/ai/decision/runtime-metadata.js';
import { readFileSync, statSync } from 'node:fs';
import { writeFileAtomicallySync } from '../../src/utils/atomic-file.js';
import type { TrialReadEvent, TrialAggregate, TrialUsage, TrialRetention, TrialDecisionMetric } from '../shared/jev-memory-trial-types.js';
export const unknownUsage = (): TrialUsage => ({ input: null, output: null, cacheRead: null, cacheWrite: null });
export function metricNumber(value: unknown): number | null { return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null; }
export function technicalName(value: unknown): string | null { return typeof value === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,95}$/.test(value) ? value : null; }
const reasons = new Set(['disabled', 'selected', 'all_low_probability', 'missing_key', 'empty_query', 'empty_candidates', 'sensitive_query', 'budget', 'concurrency', 'timeout', 'error', 'protocol', 'cancelled', 'disabled_in_flight', 'permission_boundary', 'untrusted_endpoint', 'unavailable', 'unsupported_capability']);
const uuid = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v);
const ref = (v: unknown): string | null => typeof v === 'string' && /^[0-9a-f]{64}$/.test(v) ? v : null;
function usage(value: unknown): TrialUsage { const v = value as Partial<TrialUsage> | undefined; return { input: metricNumber(v?.input), output: metricNumber(v?.output), cacheRead: metricNumber(v?.cacheRead), cacheWrite: metricNumber(v?.cacheWrite) }; }
function decision(value: unknown): TrialDecisionMetric | undefined {
    const v=value as TrialDecisionMetric | undefined, m=v?.metadata;
    if (!m || m.schemaVersion!==1 || !['typesafe-jev','local-systemone'].includes(m.provider) || !technicalName(m.adapterVersion) || !technicalName(m.requestedModel) || !technicalName(m.returnedModel)) return undefined;
    return {
        metadata: {schemaVersion:1,adapterVersion:m.adapterVersion,provider:m.provider,requestedModel:m.requestedModel,returnedModel:m.returnedModel,
            runtimeRevision:technicalName(m.runtimeRevision),templateRevision:technicalName(m.templateRevision),temperature:typeof m.temperature==='number' && m.temperature>=0 && m.temperature<=2?m.temperature:null,
            confidenceDeclaration:['official-contract','user-configured'].includes(m.confidenceDeclaration)?m.confidenceDeclaration:'unknown',
            runtime:decisionRuntimeObservation(m.runtime),confidenceProfile:technicalName(m.confidenceProfile)??'unknown',questionIndependence:['independent','joint'].includes(m.questionIndependence)?m.questionIndependence:'unknown',capabilitySource:'adapter-contract',
            capabilities:{modalities:['text'],questions:['choice','score','noul'],maxChoiceOptions:m.confidenceProfile==='laya-entropy-v1'?20:255,maxScoreLevels:10}},
        estimatedUsage:usage(v!.estimatedUsage),usageSource:['reported','estimated'].includes(v!.usageSource)?v!.usageSource:'unknown',
        apiCostUsd:metricNumber(v!.apiCostUsd),apiCostSource:['price-estimate','local-api-zero'].includes(v!.apiCostSource)?v!.apiCostSource:'unknown',localComputeUsd:metricNumber(v!.localComputeUsd),totalCostUsd:metricNumber(v!.totalCostUsd),thresholdPolicy:technicalName(v!.thresholdPolicy)??'unknown',
    };
}
// A whitelist also applies when loading local files; corrupted/extra content cannot reach exports.
function sanitize(value: unknown): TrialReadEvent | null {
    const v = value as TrialReadEvent;
    if (!v || v.schema !== 1 || !uuid(v.id) || !uuid(v.runId) || !uuid(v.generation) || !reasons.has(v.reason) || typeof v.enabled !== 'boolean' || metricNumber(v.at) === null || v.at > Date.now() + 86400000)
        return null;
    return { schema: 1, implementation: technicalName(v.implementation) ?? 'unknown', configVersion: 1, priceVersion: technicalName(v.priceVersion) ?? 'unknown', id: v.id, runId: v.runId, taskRef: ref(v.taskRef), sessionRef: ref(v.sessionRef), at: v.at, enabled: v.enabled, generation: v.generation, group: v.enabled ? 'experiment' : 'baseline', candidateCount: metricNumber(v.candidateCount) ?? 0, eligibleCount: metricNumber(v.eligibleCount) ?? 0, judgedCount: metricNumber(v.judgedCount) ?? 0, keptCount: metricNumber(v.keptCount) ?? 0, retrievalMs: metricNumber(v.retrievalMs) ?? 0, selectorMs: metricNumber(v.selectorMs) ?? 0, readWallMs: metricNumber(v.readWallMs) ?? 0, taskWallMs: metricNumber(v.taskWallMs), provider: v.provider === 'local-systemone' ? 'local-systemone' : 'typesafe', ...(decision(v.decision) ? {decision:decision(v.decision)} : {}), decisionVersion:technicalName(v.decisionVersion)??'legacy-v1', runtimeRevision:technicalName(v.runtimeRevision), confidenceProfile:technicalName(v.confidenceProfile)??'legacy-unknown', model: technicalName(v.model), usage: usage(v.usage), costUsd: metricNumber(v.costUsd), finalProvider: technicalName(v.finalProvider), finalModel: technicalName(v.finalModel), finalUsage: usage(v.finalUsage), finalNormalizedUsage: usage(v.finalNormalizedUsage), finalUsageSource: ['reported', 'adapter_normalized', 'mixed'].includes(v.finalUsageSource) ? v.finalUsageSource : 'unknown', finalProviderUsage: Array.isArray(v.finalProviderUsage) ? v.finalProviderUsage.slice(0, 64).filter(g => g && typeof g === 'object').map(g => ({provider: technicalName(g.provider), model: technicalName(g.model), usage: usage(g.usage), attempts: metricNumber(g.attempts) ?? 0})) : [], finalRequests: Array.isArray(v.finalRequests) ? v.finalRequests.slice(0, 128).filter(r => r && ref(r.requestRef)).map(r => ({requestRef: r.requestRef, provider: technicalName(r.provider), model: technicalName(r.model), usage: usage(r.usage), ...(r.normalizedUsage ? {normalizedUsage: usage(r.normalizedUsage)} : {})})) : [], selectorRequestId: uuid(v.selectorRequestId) ? v.selectorRequestId : null, finalAttempts: metricNumber(v.finalAttempts) ?? 0, taskCostUsd: metricNumber(v.taskCostUsd), taskStatus: ['completed', 'error', 'cancelled'].includes(v.taskStatus ?? '') ? v.taskStatus : null, judgments: Array.isArray(v.judgments) ? v.judgments.slice(0, 12).filter(j => ref(j.recordRef) !== null && metricNumber(j.probability) !== null && j.probability <= 1).map(j => ({ recordRef: j.recordRef, probability: j.probability })) : [], reason: v.reason, dispatched: v.dispatched === true, attempts: v.dispatched === true ? 1 : 0, feedback: v.feedback === 'helpful' || v.feedback === 'correction' ? v.feedback : null };
}
export class JevTrialMetrics {
    private reads: TrialReadEvent[] = [];
    private expiredDropped = 0;
    private capacityDropped = 0;
    constructor(private readonly file: string, private readonly persistRetention = true) { try {
        if (statSync(file).size <= 5000000) {
            const raw = JSON.parse(readFileSync(file, 'utf8'));
            if (raw.schema === 1 && Array.isArray(raw.reads)) {
                this.reads = raw.reads.map(sanitize).filter((v: TrialReadEvent | null): v is TrialReadEvent => !!v);
                this.expiredDropped = metricNumber(raw.retention?.expiredDropped) ?? 0;
                this.capacityDropped = metricNumber(raw.retention?.capacityDropped) ?? 0;
            }
        }
    }
    catch { /* absent or invalid metrics */ } const previous = this.reads.length; this.trim(); if (previous !== this.reads.length && this.persistRetention) this.save(); }
    private trim() {
        const before = this.reads.length;
        this.reads = this.reads.filter(e => e.at >= Date.now() - 90 * 86400000);
        this.expiredDropped += before - this.reads.length;
        const sizes = this.reads.map(e => Buffer.byteLength(JSON.stringify(e), 'utf8') + 1);
        let bytes = sizes.reduce((n, size) => n + size, 2), drop = 0;
        while (this.reads.length - drop > 2000 || bytes > 4000000 - 4096) { bytes -= sizes[drop]; drop++; }
        if (drop) { this.capacityDropped += drop; this.reads = this.reads.slice(drop); }
    }
    private retention(): TrialRetention {
        return { maxReads: 2000, maxAgeDays: 90, maxBytes: 4000000, oldestAt: this.reads.length ? Math.min(...this.reads.map(r => r.at)) : null, newestAt: this.reads.length ? Math.max(...this.reads.map(r => r.at)) : null, droppedCount: this.expiredDropped + this.capacityDropped, expiredDropped: this.expiredDropped, capacityDropped: this.capacityDropped, truncated: this.expiredDropped + this.capacityDropped > 0 };
    }
    save() { this.trim(); if (!this.persistRetention) return; try {
        writeFileAtomicallySync(this.file, JSON.stringify({ schema: 1, retention: this.retention(), reads: this.reads }));
    }
    catch { /* metrics cannot break reads */ } }
    add(event: TrialReadEvent) { const safe = sanitize(event); if (safe)
        this.reads.push(safe); this.save(); }
    snapshot() { const previous = this.reads.length; this.trim(); if (previous !== this.reads.length && this.persistRetention) this.save(); return { schema: 1 as const, reads: structuredClone(this.reads), retention: this.retention() }; }
    finish(runId: string, patch: Pick<TrialReadEvent, 'taskWallMs' | 'finalUsage' | 'finalNormalizedUsage' | 'finalUsageSource' | 'finalProviderUsage' | 'finalRequests' | 'taskStatus' | 'finalProvider' | 'finalModel' | 'finalAttempts'>) { for (const e of this.reads)
        if (e.runId === runId)
            Object.assign(e, patch); this.save(); }
    feedback(id: string, value: 'helpful' | 'correction') { const e = this.reads.find(e => e.id === id); if (!e)
        throw new Error('trial_event_not_found'); e.feedback = value; this.save(); }
    clear() { this.reads = []; this.expiredDropped = 0; this.capacityDropped = 0; this.save(); }
    aggregate(filter: {
        from?: number;
        to?: number;
        enabled?: boolean;
        implementation?: string;
        model?: string;
        provider?: string;
        decisionVersion?: string;
        finalModel?: string;
        finalProvider?: string;
    } = {}): TrialAggregate[] {
        this.trim();
        const groups = new Map<string, TrialReadEvent[]>();
        for (const e of this.reads) {
            if (filter.provider !== undefined && e.provider !== filter.provider || filter.decisionVersion !== undefined && (e.decisionVersion ?? 'legacy-v1') !== filter.decisionVersion || filter.from !== undefined && e.at < filter.from || filter.to !== undefined && e.at > filter.to || filter.enabled !== undefined && e.enabled !== filter.enabled || filter.implementation !== undefined && e.implementation !== filter.implementation || filter.model !== undefined && e.model !== filter.model || filter.finalModel !== undefined && e.finalModel !== filter.finalModel || filter.finalProvider !== undefined && e.finalProvider !== filter.finalProvider)
                continue;
            const key = JSON.stringify([new Date(e.at).toISOString().slice(0, 10), e.group, e.implementation, e.configVersion, e.model, e.generation, e.finalModel, e.finalProvider, e.priceVersion, e.provider, e.decisionVersion ?? 'legacy-v1', e.runtimeRevision ?? null, e.confidenceProfile ?? 'legacy-unknown']);
            groups.set(key, [...(groups.get(key) ?? []), e]);
        }
        return [...groups.values()].map(rows => { const e = rows[0]; const tasks = [...new Map(rows.filter(r => r.taskWallMs !== null).map(r => [r.runId, r])).values()]; const reviewed = rows.filter(r => r.feedback !== null).length; const known = rows.filter(r => r.costUsd !== null); return { day: new Date(e.at).toISOString().slice(0, 10), group: e.group, provider:e.provider, decisionVersion:e.decisionVersion??'legacy-v1', runtimeRevision:e.runtimeRevision??null, confidenceProfile:e.confidenceProfile??'legacy-unknown', implementation: e.implementation, configVersion: e.configVersion, model: e.model, finalModel: e.finalModel, finalProvider: e.finalProvider, priceVersion: e.priceVersion, generation: e.generation, reads: rows.length, eligibleReads: rows.filter(r => r.eligibleCount > 0).length, dispatchedReads: rows.filter(r => r.dispatched).length, selectedReads: rows.filter(r => r.reason === 'selected').length, skippedReads: rows.filter(r => r.enabled && !r.dispatched).length, baselineReads: rows.filter(r => !r.enabled).length, eligibleCandidates: rows.reduce((n,r) => n+r.eligibleCount,0), judgedCandidates: rows.reduce((n,r) => n+r.judgedCount,0), retainedCandidates: rows.reduce((n,r) => n+r.keptCount,0), skipReasons: Object.fromEntries([...new Set(rows.filter(r => r.enabled && !r.dispatched).map(r => r.reason))].map(reason => [reason, rows.filter(r => r.enabled && !r.dispatched && r.reason === reason).length])), incompleteTasks: new Set(rows.filter(r => r.taskStatus !== 'completed').map(r => r.runId)).size, tasks: new Set(rows.map(r => r.runId)).size, fallback: rows.filter(r => !['selected', 'disabled', 'empty_query', 'empty_candidates'].includes(r.reason)).length, cancelled: rows.filter(r => r.reason === 'cancelled').length, helpful: rows.filter(r => r.feedback === 'helpful').length, correction: rows.filter(r => r.feedback === 'correction').length, unreviewed: rows.length - reviewed, feedbackRate: reviewed / rows.length, unreviewedRate: (rows.length - reviewed) / rows.length, unknownCost: rows.length - known.length, costCoverage: known.length / rows.length, knownCostUsd: known.length ? known.reduce((n, r) => n + r.costUsd!, 0) : null, meanReadMs: rows.reduce((n, r) => n + r.readWallMs, 0) / rows.length, meanSelectorMs: rows.reduce((n, r) => n + r.selectorMs, 0) / rows.length, meanTaskMs: tasks.length ? tasks.reduce((n, r) => n + r.taskWallMs!, 0) / tasks.length : null }; });
    }
    export(format: 'json' | 'csv'): string { if (format === 'json')
        return JSON.stringify({ ...this.snapshot(), tasks: [...new Map(this.reads.map(e => [e.runId, { runId: e.runId, taskRef: e.taskRef, sessionRef: e.sessionRef, wallMs: e.taskWallMs, status: e.taskStatus, provider: e.finalProvider, model: e.finalModel, usage: e.finalUsage, normalizedUsage: e.finalNormalizedUsage, usageSource: e.finalUsageSource, requests: e.finalRequests, requestMetricsTruncated: e.finalRequests.length < e.finalAttempts, incomplete: e.taskStatus !== 'completed', providerUsage: e.finalProviderUsage, attempts: e.finalAttempts, costUsd: e.taskCostUsd, readCount: this.reads.filter(r => r.runId === e.runId).length }])).values()], aggregate: this.aggregate() }, null, 2); const seen = new Set<string>(); const rows = this.snapshot().reads.map(e => { const first = !seen.has(e.runId); seen.add(e.runId); return { ...e, decision:JSON.stringify(e.decision??null), taskWallMs: first ? e.taskWallMs : null, finalAttempts: first ? e.finalAttempts : null, finalProvider: first ? e.finalProvider : null, finalModel: first ? e.finalModel : null, usage: JSON.stringify(e.usage), finalUsage: first ? JSON.stringify(e.finalUsage) : null, finalNormalizedUsage: first ? JSON.stringify(e.finalNormalizedUsage) : null, finalUsageSource: first ? e.finalUsageSource : null, finalProviderUsage: first ? JSON.stringify(e.finalProviderUsage) : null, finalRequests: first ? JSON.stringify(e.finalRequests) : null, judgments: JSON.stringify(e.judgments) }; }); if (!rows.length)
        return ''; const keys = Object.keys(rows[0]); const cell = (v: unknown) => v === null ? '' : `"${String(v).replace(/"/g, '""')}"`; return [keys.join(','), ...rows.map(row => keys.map(k => cell(row[k as keyof typeof row])).join(','))].join('\n'); }
}
