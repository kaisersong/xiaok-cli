import { createHash } from 'node:crypto';
import { createReadStream, constants } from 'node:fs';
import { open,rm } from 'node:fs/promises';
import type { DecisionModelFile } from '../shared/decision-model-types.js';
export async function verifyDecisionFile(path:string, file:DecisionModelFile):Promise<boolean> {
 const handle=await open(path,constants.O_RDONLY|constants.O_NOFOLLOW);try{
  const stat=await handle.stat();if(!stat.isFile()||stat.nlink!==1||stat.size!==file.size)return false;
  const hash=createHash(file.algorithm==='sha256'?'sha256':'sha1');if(file.algorithm==='git-blob-sha1')hash.update(`blob ${file.size}\0`);
  for await(const part of createReadStream(path,{fd:handle.fd,autoClose:false}))hash.update(part);
  return hash.digest('hex')===file.hash;
 }finally{await handle.close();}
}
function trustedDownload(url:string){const u=new URL(url);if(u.protocol!=='https:'||u.username||u.password||u.port&&u.port!=='443'||!(u.hostname==='huggingface.co'||u.hostname==='cas-bridge.xethub.hf.co'||u.hostname.endsWith('.hf.co')||u.hostname==='cdn-lfs.huggingface.co'))throw Error('download_host');return u.href;}
/** No credentials, bounded redirects, streamed disk/hash, cooperative cancellation. */
export async function downloadDecisionFile(url:string,path:string,file:DecisionModelFile,signal:AbortSignal,progress:(bytes:number)=>void,fetcher:typeof fetch=fetch){
 let response:Response|undefined;let next=trustedDownload(url);
 for(let redirects=0;redirects<=5;redirects++){
  if(signal.aborted)throw Error('cancelled');response=await fetcher(next,{signal,redirect:'manual'});
  if(response.status>=300&&response.status<400){const location=response.headers.get('location');void response.body?.cancel().catch(()=>{});if(!location||redirects===5)throw Error('download_redirect');next=trustedDownload(new URL(location,next).href);continue;}break;
 }
 if(!response?.ok||!response.body)throw Error('network');
 await rm(path,{force:true});const writer=await open(path,constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY|constants.O_NOFOLLOW,0o600);
 const reader=response.body.getReader();let bytes=0;
 try{while(true){if(signal.aborted)throw Error('cancelled');const part=await reader.read();if(part.done)break;bytes+=part.value.byteLength;if(bytes>file.size)throw Error('size_mismatch');let offset=0;while(offset<part.value.byteLength){const written=await writer.write(part.value,offset,part.value.byteLength-offset);offset+=written.bytesWritten;}progress(bytes);}await writer.sync();}
 finally{void reader.cancel().catch(()=>{});await writer.close();}
 if(signal.aborted)throw Error('cancelled');if(bytes!==file.size)throw Error('size_mismatch');if(!await verifyDecisionFile(path,file))throw Error('hash_mismatch');
}
