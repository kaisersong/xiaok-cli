import { lstatSync, readdirSync, realpathSync } from 'node:fs';
import { basename, join } from 'node:path';
import type { Config } from '../../src/types.js';
import { deriveObservationDestination, parseObservationPolicyInput, PRODUCT_OBSERVATION_ENVIRONMENT_ID, PRODUCT_OBSERVATION_MODEL, type ProductObservationPolicy } from '../../src/runtime/sol-pi/product-bootstrap.js';

const MAX_READ_SCOPES = 128;
const SKIPPED_DIRECTORY_NAMES = new Set(['.git', 'node_modules']);
const deny = (reason: string): never => { throw new Error(`SOL_PI_PRODUCT_${reason}`); };

/**
 * Main-side default policy builder for the Desktop onboarding dialog.
 * Sources come only from a native dialog user gesture; the renderer never supplies policy content.
 */
export function expandObservationReadScopes(selection: readonly string[]): Array<{ filePath: string; startLine: number }> {
  const scopes: Array<{ filePath: string; startLine: number }> = [];
  let directSkips = 0;
  const visit = (entry: string, direct: boolean) => {
    let stat: ReturnType<typeof lstatSync>;
    try { stat = lstatSync(entry); } catch { if (direct) directSkips += 1; return; }
    if (stat.isSymbolicLink()) { if (direct) directSkips += 1; return; }
    if (stat.isFile()) {
      let real: string; try { real = realpathSync(entry); } catch { if (direct) directSkips += 1; return; }
      if (real !== entry) { if (direct) directSkips += 1; return; }
      if (scopes.length >= MAX_READ_SCOPES) deny('TOO_MANY_SOURCES');
      scopes.push({ filePath: entry, startLine: 1 }); return;
    }
    if (stat.isDirectory()) {
      if (SKIPPED_DIRECTORY_NAMES.has(basename(entry))) { if (direct) directSkips += 1; return; }
      let children: string[];
      try { children = readdirSync(entry).sort().map(name => join(entry, name)); } catch { if (direct) directSkips += 1; return; }
      for (const child of children) visit(child, false);
    }
  };
  for (const item of [...selection].sort()) visit(item, true);
  scopes.sort((left, right) => left.filePath < right.filePath ? -1 : left.filePath > right.filePath ? 1 : 0);
  if (!scopes.length && directSkips) deny('INVALID_READ_SCOPE');
  if (!scopes.length) deny('NO_USABLE_SOURCES');
  return scopes;
}

export function buildObservationPolicy(selection: readonly string[], config: Config, now = Date.now()): ProductObservationPolicy {
  const readFileScopes = expandObservationReadScopes(selection);
  return parseObservationPolicyInput({
    version: 1, environmentId: PRODUCT_OBSERVATION_ENVIRONMENT_ID, model: PRODUCT_OBSERVATION_MODEL,
    destination: deriveObservationDestination(config),
    localPersistence: true, allowUnclassifiedText: true, allowModelDisclosure: true, allowIncomplete: false,
    expiresAt: now + 7 * 86400000, readFileScopes, bashSources: [],
  });
}

/** Serializable scope facts for the renderer status line; naming stays in the locale layer. */
export function describeObservationPolicyScope(summary: { readFileScopes: ReadonlyArray<{ filePath: string }>; bashSources: ReadonlyArray<unknown> }): { directoryName?: string; fileCount: number; commandCount: number } {
  const files = summary.readFileScopes.length, commands = summary.bashSources.length;
  if (!files) return { fileCount: files, commandCount: commands };
  const paths = summary.readFileScopes.map(scope => scope.filePath);
  const first = paths[0]!;
  let prefix = first.slice(0, first.lastIndexOf('/'));
  if (first.includes('\\')) {
    const back = first.slice(0, first.lastIndexOf('\\'));
    if (back.length > prefix.length || !prefix.includes('/')) prefix = back;
  }
  for (const path of paths.slice(1)) {
    while (prefix && !path.startsWith(`${prefix}/`) && !path.startsWith(`${prefix}\\`)) {
      const cut = Math.max(prefix.lastIndexOf('/'), prefix.lastIndexOf('\\'));
      prefix = cut > 0 ? prefix.slice(0, cut) : '';
    }
    if (!prefix) break;
  }
  if (!prefix) return { fileCount: files, commandCount: commands };
  const base = prefix.slice(Math.max(prefix.lastIndexOf('/'), prefix.lastIndexOf('\\')) + 1);
  return { ...(base ? { directoryName: base } : {}), fileCount: files, commandCount: commands };
}
