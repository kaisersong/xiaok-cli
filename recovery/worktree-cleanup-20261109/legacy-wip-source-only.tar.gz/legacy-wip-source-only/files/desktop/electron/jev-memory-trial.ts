import { getDecisionModelService } from './decision-model-service.js';
import { createDecisionProvider } from '../../src/ai/decision/registry.js';
import { DecisionError } from '../../src/ai/decision/types.js';
import { JevMemoryTrial } from './jev-memory-trial-service.js';
import { loadConfig } from '../../src/utils/config.js';
import { resolveSystemOneConfig } from '../../src/ai/providers/system-one-config.js';
const trials = new Map<string, JevMemoryTrial>();
export function getDesktopJevMemoryTrial(dataRoot: string): JevMemoryTrial {
    let service = trials.get(dataRoot);
    if (!service) {
        service = new JevMemoryTrial(dataRoot, async () => resolveSystemOneConfig(await loadConfig()), fetch, async (selection,signal) => {
            if(signal.aborted)throw new DecisionError('cancelled');
            if(selection.provider==='local-systemone'&&selection.managedModelId){
                try{const runtime=await getDecisionModelService(dataRoot).provider(selection.managedModelId);return createDecisionProvider({...selection,endpoint:runtime.endpoint},async()=>null,runtime.transport);}catch{throw new DecisionError('unavailable');}
            }
            return createDecisionProvider(selection,async()=>resolveSystemOneConfig(await loadConfig()));
        });
        trials.set(dataRoot, service);
    }
    return service;
}
