import type {DecisionRuntimeObservation} from '../../src/ai/decision/types.js';
export interface DecisionModelFile { name:string; size:number; hash:string; algorithm:'sha256'|'git-blob-sha1' }
export interface DecisionRuntimePackage {name:string;version:string;source:string;wheelSha256:string;files:Readonly<Record<string,string>>}
export interface DecisionModelManifest { id:string; repo:string; revision:string; runtime:'clef-mlx'|'laya'; files:readonly DecisionModelFile[];sizeBytes:number;source:string;platforms:readonly string[];codeHash:string|null;runtimePackage?:DecisionRuntimePackage }
export type DecisionModelState='not_installed'|'downloading'|'checking'|'interrupted'|'installed'|'loading'|'ready'|'failed';
export interface DecisionModelView {id:string;source:string;revision:string;sizeBytes:number;sizeLabel:string;supported:boolean;verified:boolean;state:DecisionModelState;reason:string|null;downloadedBytes:number;currentFile:string|null;availableDiskBytes:number|null;codeHash:string|null;runtime:'clef-mlx'|'laya';endpoint:string|null;runtimeSource?:string;runtimeVersion?:string;runtimePid?:number|null;runtimeInfo?:DecisionRuntimeObservation|null}
export interface DecisionModelAction { modelId:string; approveCommunityCode?:boolean }
