export const TRIAL_VERSION = 1;
import type { DecisionSelection, DecisionMetadata, DecisionTokens } from '../../src/ai/decision/types.js';
export type { DecisionSelection } from '../../src/ai/decision/types.js';
export const TRIAL_IMPLEMENTATION = 'bounded-noul-v2';
export interface JevTrialSettings {
    version: 1;
    enabled: boolean;
    generation: string;
    decision?: DecisionSelection;
}
export type JevTrialSettingsPatch = { enabled?: boolean; decision?: DecisionSelection };
export type TrialReason = 'disabled' | 'selected' | 'all_low_probability' | 'missing_key' | 'empty_query' | 'empty_candidates' | 'sensitive_query' | 'budget' | 'concurrency' | 'timeout' | 'error' | 'protocol' | 'cancelled' | 'disabled_in_flight' | 'permission_boundary' | 'untrusted_endpoint' | 'unavailable' | 'unsupported_capability';
export interface TrialDecisionMetric {
    metadata: DecisionMetadata;
    estimatedUsage: DecisionTokens;
    usageSource: 'reported' | 'estimated' | 'unknown';
    apiCostUsd: number | null;
    apiCostSource: 'price-estimate' | 'local-api-zero' | 'unknown';
    localComputeUsd: number | null;
    totalCostUsd: number | null;
    thresholdPolicy: string;
}
export interface TrialUsage {
    input: number | null;
    output: number | null;
    cacheRead: number | null;
    cacheWrite: number | null;
}
export interface TrialRequestMetric {
    requestRef: string;
    provider: string | null;
    model: string | null;
    usage: TrialUsage;
    normalizedUsage?: TrialUsage;
}
export interface TrialRetention {
    maxReads: number;
    maxAgeDays: number;
    maxBytes: number;
    oldestAt: number | null;
    newestAt: number | null;
    droppedCount: number;
    expiredDropped: number;
    capacityDropped: number;
    truncated: boolean;
}
export interface TrialReadEvent {
    schema: 1;
    implementation: string;
    configVersion: 1;
    priceVersion: string;
    id: string;
    runId: string;
    taskRef: string | null;
    sessionRef: string | null;
    at: number;
    enabled: boolean;
    generation: string;
    group: 'baseline' | 'experiment';
    candidateCount: number;
    eligibleCount: number;
    judgedCount: number;
    keptCount: number;
    retrievalMs: number;
    selectorMs: number;
    readWallMs: number;
    taskWallMs: number | null;
    provider: 'typesafe' | 'local-systemone';
    decision?: TrialDecisionMetric;
    decisionVersion?: string;
    runtimeRevision?: string | null;
    confidenceProfile?: string;
    model: string | null;
    usage: TrialUsage;
    costUsd: number | null;
    finalProvider: string | null;
    finalModel: string | null;
    finalUsage: TrialUsage;
    finalNormalizedUsage: TrialUsage;
    finalUsageSource: 'reported' | 'adapter_normalized' | 'mixed' | 'unknown';
    finalProviderUsage: Array<{ provider: string | null; model: string | null; usage: TrialUsage; attempts: number }>;
    finalRequests: TrialRequestMetric[];
    selectorRequestId: string | null;
    finalAttempts: number;
    taskCostUsd: number | null;
    taskStatus: 'completed' | 'error' | 'cancelled' | null;
    judgments: Array<{
        recordRef: string;
        probability: number;
    }>;
    reason: TrialReason;
    dispatched: boolean;
    attempts: number;
    feedback: 'helpful' | 'correction' | null;
}
export interface TrialAggregate {
    day: string;
    group: string;
    provider: string;
    decisionVersion: string;
    runtimeRevision: string | null;
    confidenceProfile: string;
    implementation: string;
    configVersion: number;
    model: string | null;
    finalModel: string | null;
    finalProvider: string | null;
    priceVersion: string;
    generation: string;
    reads: number;
    eligibleReads: number;
    dispatchedReads: number;
    selectedReads: number;
    skippedReads: number;
    baselineReads: number;
    eligibleCandidates: number;
    judgedCandidates: number;
    retainedCandidates: number;
    skipReasons: Record<string, number>;
    tasks: number;
    fallback: number;
    cancelled: number;
    helpful: number;
    correction: number;
    unreviewed: number;
    feedbackRate: number;
    unreviewedRate: number;
    incompleteTasks: number;
    unknownCost: number;
    costCoverage: number;
    knownCostUsd: number | null;
    meanReadMs: number;
    meanSelectorMs: number;
    meanTaskMs: number | null;
}
