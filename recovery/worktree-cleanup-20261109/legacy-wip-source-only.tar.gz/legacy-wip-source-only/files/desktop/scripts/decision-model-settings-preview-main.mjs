// Development-only composition of production services, IPC, preload and renderer.
// No synthetic provider, model manifest, credentials, or community runtime injection.
import {app,BrowserWindow,ipcMain} from 'electron';
import {mkdirSync,writeFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const desktop=join(dirname(fileURLToPath(import.meta.url)),'..');
const root=process.env.XIAOK_DECISION_SETTINGS_PREVIEW_ROOT;
if(!root||!process.env.XIAOK_CONFIG_DIR)throw Error('isolated_preview_paths_required');
const profile=join(root,'profile');mkdirSync(profile,{recursive:true});app.setPath('userData',profile);
app.setName('xiaok Decision Settings Preview');
app.commandLine.appendSwitch('remote-debugging-port','0');app.commandLine.appendSwitch('remote-debugging-address','127.0.0.1');
const compiled=join(desktop,'dist','main','desktop','electron');
const load=name=>import(pathToFileURL(join(compiled,`${name}.js`)).href);
const {createDesktopServices}=await load('desktop-services');
const {registerDesktopIpc}=await load('ipc');
const {buildBrowserWindowOptions,isTrustedDesktopRendererUrl}=await load('security');
const {getDecisionModelService}=await load('decision-model-service');
const {registerKSwarmProxy}=await load('kswarm-ipc-proxy');
const {KSwarmStreamBridge}=await load('kswarm-stream-bridge');
const unavailable=async()=>{throw Error('settings_preview_collaboration_unavailable');};
// Deliberately do not construct the fixed-port service manager: it can replace
// an existing application sidecar. This preview is for settings, not full chat.
const kswarm={start:unavailable,stop:async()=>{},restart:unavailable,onStatusChange:()=>()=>{},
 getStatus:()=>({running:false,port:0,pid:null,restartCount:0,lastError:'settings_preview_collaboration_unavailable'}),
 getDesktopMutationToken:()=>'',getIntentBrokerRoomToken:()=>'',request:unavailable};
let window,services,quitting=false;const disposers=[];
const rendererFile=join(desktop,'dist','renderer','index.html');
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',event=>{
 if(quitting)return;event.preventDefault();quitting=true;
 void (async()=>{await getDecisionModelService(join(root,'data')).dispose();await services?.disposeMultiAgent();for(const dispose of disposers)dispose();})()
  .finally(()=>app.exit(0));
});
export const previewReady=app.whenReady().then(async()=>{
services=createDesktopServices({dataRoot:join(root,'data'),knowledgeDbPath:join(root,'knowledge.sqlite'),workspaceRoot:join(root,'workspace'),pluginRootDir:join(root,'plugins'),pluginDependencies:[],kswarmService:kswarm});
getDecisionModelService(join(root,'data')).setPythonCommandResolver(()=>process.env.XIAOK_DECISION_MODEL_PYTHON);
await services.multiAgent.ready;
window=new BrowserWindow({...buildBrowserWindowOptions(join(compiled,'preload.cjs')),show:true,width:1440,height:980,title:'xiaok · 隔离设置体验'});
window.on('page-title-updated',event=>event.preventDefault());
window.on('closed',()=>{window=undefined;});
const bridge=new KSwarmStreamBridge('ws://127.0.0.1:0/ws');
registerKSwarmProxy(ipcMain,bridge,kswarm);disposers.push(()=>bridge.dispose());
await registerDesktopIpc(ipcMain,window,services,{getMainWindow:()=>window,registerLifetimeDisposer:dispose=>disposers.push(dispose),
 multiAgentAuthorize:event=>window&&!window.isDestroyed()&&event.sender===window.webContents&&event.senderFrame===window.webContents.mainFrame&&isTrustedDesktopRendererUrl(window.webContents.mainFrame.url,{rendererFile})?{actorId:`desktop-user:${services.multiAgent.profileId}`}:null});
ipcMain.handle('desktop:getSkillDebugConfig',()=>services.getSkillDebugConfig());
ipcMain.handle('desktop:getKswarmConfig',()=>services.getKswarmConfig());
await window.loadFile(rendererFile);window.show();window.focus();app.focus({steal:true});
writeFileSync(join(root,'ready.json'),JSON.stringify({pid:process.pid,root,profile,config:process.env.XIAOK_CONFIG_DIR,title:window.getTitle(),visible:window.isVisible(),mode:'isolated-production-settings',fullChat:false},null,2));
return {services,window,root};
});
void previewReady.catch(error=>{console.error('settings_preview_start_failed',error);app.exit(1);});
