import {test,expect,_electron as electron} from '@playwright/test';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {mkdirSync,writeFileSync} from 'node:fs';
const desktop=join(dirname(fileURLToPath(import.meta.url)),'../..');
const root=join(desktop,'..','.artifacts/decision-settings-preview');
test('explicit live real Clef/Laya and synthetic notebook to real configured LLM',async()=>{
 test.skip(process.env.XIAOK_DECISION_LIVE!=='1','explicit live option required');test.setTimeout(600000);
 const evidenceRoot=process.env.XIAOK_DECISION_LIVE_EVIDENCE??'/tmp/xiaok-decision-live';mkdirSync(evidenceRoot,{recursive:true});
 const env={PATH:process.env.PATH,HOME:process.env.HOME,USER:process.env.USER,LANG:process.env.LANG,TMPDIR:process.env.TMPDIR,NODE_ENV:'test',XIAOK_DECISION_LIVE:'1',XIAOK_DISABLE_GLOBAL_PLUGINS:'1',XIAOK_CONFIG_DIR:join(root,'config'),XIAOK_DECISION_SETTINGS_PREVIEW_ROOT:root,XIAOK_DECISION_MODEL_PYTHON:join(root,'python-env/bin/python3')};
 const app=await electron.launch({args:[join(desktop,'tests/e2e/fixtures/decision-model-live-main.mjs')],env,timeout:30000});
 const reports:any[]=[];let page;const memoryIds:string[]=[];
 try{
  page=await app.firstWindow();await page.waitForLoadState('domcontentloaded');await expect.poll(()=>app.evaluate(()=>typeof (globalThis as any).decisionModelLive?.evaluate)).toBe('function');
  await page.locator('aside button').last().click();await page.getByRole('button',{name:'记忆管理',exact:true}).click();
  const leftovers=await page.evaluate(()=>window.xiaokDesktop.listMemories());for(const record of leftovers.filter((m:any)=>m.content?.startsWith('SYNTHETIC_LIVE_076 ')))await page.evaluate(id=>window.xiaokDesktop.deleteMemory(id),record.id);
  const toggle=page.getByRole('checkbox',{name:'启用记忆决策判断'});await expect(toggle).not.toBeChecked();
  expect((await page.evaluate(()=>window.xiaokDesktop.decisionModelsList())).every(m=>m.verified)).toBe(true);const beforeMetrics=await page.evaluate(()=>window.xiaokDesktop.memoryJevSnapshot());
  for(const content of ['周会是星期三下午三点。','周会地点是二号会议室。','午餐喜欢面条。','测试项目使用蓝色图标。','周会参与者为合成团队。','测试笔记不包含真实个人信息。']){
   const memory=await page.evaluate(content=>window.xiaokDesktop.createMemory({content:'SYNTHETIC_LIVE_076 '+content,tags:[]}),content);memoryIds.push((memory as {id:string}).id);
  }
  const baseline=await app.evaluate(()=> (globalThis as any).decisionModelLive.notebook('synthetic-baseline',true));expect(baseline.answer.answer).toMatch(/三/);expect(baseline.answer.answer).toMatch(/(三点|3|15)/);
  const request={state:'SYNTHETIC_LIVE_076：合成用户的周会固定在星期三下午三点。午餐喜欢面条。',questions:{yes:{type:'noul',instructions:'这段状态明确说周会在星期三下午三点吗？'},no:{type:'noul',instructions:'这段状态明确说周会在星期五上午九点吗？'},choice:{type:'choice',instructions:'状态中的周会日期是哪天？',criteria:{wednesday:'星期三',friday:'星期五',monday:'星期一'}},score:{type:'score',instructions:'状态对命题“周会在星期三下午三点”提供多少证据？',criteria:['明确相反','没有证据','明确支持']}}};
  for(const [id,title] of [['clef-flash-mlx-4bit','ClefFlash MLX 4bit（完整决策头）'],['laya-multilingual','Laya multilingual（兼容候选）']]){
   const card=page.getByText(title,{exact:true}).locator('..').locator('..');const start=Date.now();
   // This live run is explicitly authorized for these two audited pins. Native
   // Electron confirm was separately exercised; its dialog is outside CDP.
   await page.evaluate(()=>{window.confirm=message=>['852223c944819a32fad5cf798d9d1dff30419820eaf5ad1f10cb9698afec97d5','a1493cff474c0a5d84861db55c0c5c9b17f1db8561e458764da9a322dc542a88'].some(hash=>message.includes(hash));});
   await card.getByRole('button',{name:'加载模型',exact:true}).click();
   await expect.poll(async()=> (await page!.evaluate(()=>window.xiaokDesktop.decisionModelsList())).find(m=>m.id===id)?.state,{timeout:240000}).toBe('ready');const coldLoadMs=Date.now()-start;
   await card.getByRole('button',{name:'用于记忆判断（保持开关）',exact:true}).click();await expect.poll(async()=> (await page!.evaluate(()=>window.xiaokDesktop.memoryJevGetSettings())).decision?.managedModelId).toBe(id);await expect(toggle).not.toBeChecked();
   const observations=[];for(let i=0;i<13;i++)observations.push(await app.evaluate((_,request)=> (globalThis as any).decisionModelLive.evaluate(request),request));
   const gold=observations[0].result.answers;const quality={yes:gold.yes.probability>=.5,no:gold.no.probability<.5,choice:gold.choice.choice==='wednesday',score:gold.score.score>=1.5};
   const latencies=observations.slice(1).map(o=>o.wallMs).sort((a,b)=>a-b);await toggle.check();
   const notebook=await app.evaluate((_,label)=> (globalThis as any).decisionModelLive.notebook(label,true),'synthetic-'+(id.startsWith('clef')?'clef':'laya'));expect(notebook.evidenceCount).toBeGreaterThan(0);expect(notebook.answer.model).toBe(baseline.answer.model);expect(notebook.answer.answer).toMatch(/三/);
   await toggle.uncheck();await page.getByRole('button',{name:'刷新统计',exact:true}).click();await card.screenshot({path:join(evidenceRoot,id+'.png')});
   const model=(await page.evaluate(()=>window.xiaokDesktop.decisionModelsList())).find(m=>m.id===id);
   reports.push({id,coldLoadMs,runtime:model?.runtimeInfo,quality,passedLabels:Object.values(quality).filter(Boolean).length,totalLabels:4,p50Ms:latencies[Math.floor(latencies.length*.5)],p95Ms:latencies[Math.ceil(latencies.length*.95)-1],observations,notebook,baseline});
   await card.getByRole('button',{name:'停止模型',exact:true}).click();await expect.poll(async()=> (await page!.evaluate(()=>window.xiaokDesktop.decisionModelsList())).find(m=>m.id===id)?.state).toBe('installed');
  }
  const exported=await page.evaluate(()=>window.xiaokDesktop.memoryJevExport('json'));for(const value of ['SYNTHETIC_LIVE_076','周会是','合成用户'])expect(exported).not.toContain(value);
  const allMetrics=JSON.parse(exported);const metrics={tasks:allMetrics.tasks.slice(new Set(beforeMetrics.reads.map(r=>r.runId)).size),reads:allMetrics.reads.slice(beforeMetrics.reads.length)};expect(metrics.tasks).toHaveLength(3);expect(metrics.reads).toHaveLength(3);expect(metrics.reads.filter((r:any)=>r.enabled).every((r:any)=>r.dispatched)).toBe(true);
  const judged=metrics.reads.filter((r:any)=>['selected','all_low_probability'].includes(r.reason));expect(judged).toHaveLength(2);expect(judged.every((r:any)=>r.decision.metadata.runtime?.implementation==='xiaok-local-text-v2'&&r.decision.totalCostUsd===null&&r.taskCostUsd===null)).toBe(true);
  writeFileSync(join(evidenceRoot,'metrics.json'),exported);writeFileSync(join(evidenceRoot,'metrics.csv'),await page.evaluate(()=>window.xiaokDesktop.memoryJevExport('csv')));await page.screenshot({path:join(evidenceRoot,'settings-statistics.png')});
  writeFileSync(join(evidenceRoot,'result.json'),JSON.stringify({passed:true,boundary:'real production notebook + decision + real bound LLM; synthetic-only direct task boundary; full agent loop separately fixture-tested',reports},null,2));
 }finally{
  writeFileSync(join(evidenceRoot,'partial.json'),JSON.stringify(reports,null,2));
  if(page){await page.evaluate(()=>window.xiaokDesktop.memoryJevConfigure({enabled:false})).catch(()=>{});for(const id of memoryIds)await page.evaluate(id=>window.xiaokDesktop.deleteMemory(id),id).catch(()=>{});}
  await app.close();
 }
});
