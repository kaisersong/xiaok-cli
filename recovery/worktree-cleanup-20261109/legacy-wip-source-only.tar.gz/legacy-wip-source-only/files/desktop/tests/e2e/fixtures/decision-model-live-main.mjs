// Explicit live opt-in: frozen real weights, production IPC/notebook/decision,
// synthetic Chinese content only. Existing final-provider credentials stay in memory.
import {join} from 'node:path';
import {homedir} from 'node:os';
import {readFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {pathToFileURL} from 'node:url';
if(process.env.XIAOK_DECISION_LIVE!=='1')throw Error('explicit_live_required');
const {previewReady}=await import('../../../scripts/decision-model-settings-preview-main.mjs');
const load=name=>import(pathToFileURL(join(process.cwd(),'dist/main',name+'.js')).href);
void previewReady.then(async({root})=>{
 const dataRoot=join(root,'data');
 const {getDecisionModelService}=await load('desktop/electron/decision-model-service');
 const {getDesktopMemoryStore}=await load('desktop/electron/desktop-services');
 const {getDesktopJevMemoryTrial}=await load('desktop/electron/jev-memory-trial');
 const {createNotebookTools}=await load('src/ai/tools/notebook');
 const {createDecisionProvider}=await load('src/ai/decision/registry');
 const manager=getDecisionModelService(dataRoot),trial=getDesktopJevMemoryTrial(dataRoot);
 let finalBinding,finalAdapter;
 const final=async evidence=>{
  if(!finalAdapter){
   const {normalizeConfig}=await load('src/ai/providers/normalize');
   const {resolveRuntimeModelBinding}=await load('src/ai/providers/control-plane');
   const {createAdapterFromBinding}=await load('src/ai/models');
   // Read-only existing configuration; never copy keys into the isolated profile,
   // environment, diagnostics or artifacts. Only the production adapter uses them.
   const config=normalizeConfig(JSON.parse(readFileSync(join(homedir(),'.xiaok','config.json'),'utf8')));
   finalBinding=resolveRuntimeModelBinding(config);finalAdapter=createAdapterFromBinding(finalBinding);
  }
  trial.identifyTask(finalAdapter.getModelName(),finalBinding.providerId);
  let answer='';const requestId=randomUUID();const signal=AbortSignal.timeout(60000);
  for await(const chunk of finalAdapter.stream([{role:'user',content:[{type:'text',text:'这是一组合成测试笔记。只根据下面证据回答：SYNTHETIC_LIVE_076 的周会是哪天、几点？只写日期和时间。\n'+evidence}]}],[],'Answer only from the synthetic evidence supplied. Do not infer missing facts.',{signal})){
   if(chunk.type==='text')answer+=chunk.delta;
   if(chunk.type==='usage')trial.observeProviderUsage(requestId,chunk.usage,'adapter_normalized');
  }
  return {answer,model:finalAdapter.getModelName(),provider:finalBinding.providerId};
 };
 globalThis.decisionModelLive={
  async evaluate(request){
   if(!JSON.stringify(request.state).includes('SYNTHETIC_LIVE_076'))throw Error('synthetic_only');
   const selection=trial.settings().decision;if(selection?.provider!=='local-systemone'||!selection.managedModelId)throw Error('managed_selection_required');
   const runtime=await manager.provider(selection.managedModelId);
   const provider=createDecisionProvider({...selection,endpoint:runtime.endpoint},async()=>null,runtime.transport);
   const start=performance.now();const result=await provider.evaluate(request,{timeoutMs:60000});return {wallMs:performance.now()-start,result};
  },
  async notebook(label,generateAnswer){
   if(!/^synthetic-[a-z-]+$/.test(label))throw Error('synthetic_label_required');
   const tool=createNotebookTools(getDesktopMemoryStore(dataRoot),{cwd:join(root,'workspace'),read:input=>trial.read(input)}).find(t=>t.definition.name==='notebook_read');
   return trial.runTask({taskId:label,sessionId:'synthetic-live-session',model:'unknown'},async()=>{
    const evidence=await tool.execute({query:'SYNTHETIC_LIVE_076 周会',limit:10},{taskId:label,session:{cwd:join(root,'workspace')}});
    if(!evidence.includes('SYNTHETIC_LIVE_076'))throw Error('synthetic_evidence_missing');
    const answer=generateAnswer?await final(evidence):null;
    return {evidenceCount:(evidence.match(/SYNTHETIC_LIVE_076/g)||[]).length,answer};
   });
  }
 };
}).catch(()=>{console.error('decision_live_fixture_initialization_failed');process.exitCode=1;});
