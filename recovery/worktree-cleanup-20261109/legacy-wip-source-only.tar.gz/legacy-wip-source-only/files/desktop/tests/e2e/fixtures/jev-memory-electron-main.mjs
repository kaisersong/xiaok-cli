// Isolated composition: real services, IPC registrar, sandbox preload and built renderer.
import { app, session } from 'electron';
import { mkdirSync } from 'node:fs';
const root = process.env.XIAOK_MULTI_AGENT_E2E_ROOT;
const profile = process.env.XIAOK_E2E_USER_DATA;
if (!root || !profile || !process.env.XIAOK_CONFIG_DIR) throw new Error('isolated_e2e_paths_required');
mkdirSync(profile, { recursive: true }); app.setPath('userData', profile);
let blockedExternalRequests = 0;
const local = value => { const url = new URL(String(value)); return ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname); };
const originalFetch = globalThis.fetch;
globalThis.fetch = (input, options) => {
  let url = input instanceof Request ? input.url : input;
  let mapped = false;
  // Test-only transport mapping: production still validates its fixed HTTPS host.
  if (String(url) === 'https://api.typesafe.ai/v1/systemone') {
    const target = new URL(process.env.XIAOK_MULTI_AGENT_E2E_PROVIDER);
    if (!local(target)) throw new Error('isolated_e2e_provider_required');
    target.pathname = '/v1/systemone'; url = target; mapped = true;
  }
  if (!local(url)) { blockedExternalRequests++; return Promise.reject(new Error('isolated_e2e_external_network_blocked')); }
  return originalFetch(mapped ? url : input, options);
};
globalThis.jevMemoryE2E = { blockedExternalRequests: () => blockedExternalRequests };
void app.whenReady().then(() => session.defaultSession.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*'] }, (details, callback) => {
  const cancel = !local(details.url); if (cancel) blockedExternalRequests++; callback({ cancel });
}));
// Test-only injection into the production manager; never download real weights or execute community code.
if(process.env.XIAOK_DECISION_MODEL_E2E_FIXTURE==='1'){
 const {createHash}=await import('node:crypto');const {join}=await import('node:path');const {pathToFileURL}=await import('node:url');
 const compiled=join(process.cwd(),'dist','main','desktop','electron');
 const {DECISION_MODEL_CATALOG}=await import(pathToFileURL(join(compiled,'decision-model-catalog.js')).href);
 const {getDecisionModelService}=await import(pathToFileURL(join(compiled,'decision-model-service.js')).href);
 const bytes=Buffer.from('SYNTHETIC_MODEL_FIXTURE');const target=new URL(process.env.XIAOK_MULTI_AGENT_E2E_PROVIDER);target.pathname='/model-fixture';
 getDecisionModelService(join(root,'data'),{models:DECISION_MODEL_CATALOG.map(m=>({...m,files:[{name:'fixture.weights',size:bytes.length,hash:createHash('sha256').update(bytes).digest('hex'),algorithm:'sha256'}],sizeBytes:bytes.length})),
  fetcher:(_url,options)=>originalFetch(target,options),runtimeStart:async()=>{let alive=true;const endpoint=new URL(process.env.XIAOK_MULTI_AGENT_E2E_PROVIDER);endpoint.pathname='/v1/systemone';return {endpoint:endpoint.href,transport:(url,options)=>originalFetch(url,options),alive:()=>alive,stop:async()=>{alive=false;}};}});
}
await import('./multi-agent-electron-main.mjs');
