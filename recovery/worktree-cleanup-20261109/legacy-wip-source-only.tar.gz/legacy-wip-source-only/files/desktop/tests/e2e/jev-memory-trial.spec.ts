import { expect, test, _electron as electron, type ElectronApplication } from '@playwright/test';
import { createServer, type ServerResponse } from 'node:http';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const desktop = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
test('real Electron IPC persists an opt-in trial and reads synthetic memory safely', async () => {
  test.setTimeout(120000);
  const root = mkdtempSync(join(tmpdir(), 'xiaok-jev-electron-'));
  console.log('JEV_ELECTRON_START', root);
  mkdirSync(join(root, 'config')); mkdirSync(join(root, 'workspace'));
  let jevCalls = 0; let localDecisionCalls = 0; let modelCalls = 0; let hold = false; let held: ServerResponse | undefined;
  const evidenceCounts: number[] = []; const serverErrors: string[] = [];
  const server = createServer(async (request, response) => {
    try {
      const chunks: Buffer[] = []; for await (const chunk of request) chunks.push(Buffer.from(chunk));
      if(request.url==='/model-fixture'){response.end('SYNTHETIC_MODEL_FIXTURE');return;}
      const body = JSON.parse(Buffer.concat(chunks).toString());
      if (request.url === '/v1/systemone') {
        if (request.headers.authorization) jevCalls++; else localDecisionCalls++;
        expect(Object.keys(body.state)).toEqual(['query', 'candidates']);
        expect(body.state.candidates.every((c: object) => Object.keys(c).sort().join(',') === 'scope,text,type')).toBe(true);
        if (hold) { held = response; return; }
        response.setHeader('content-type', 'application/json');
        response.end(JSON.stringify({ model: request.headers.authorization ? 'jev-1.13.0' : 'clef-synthetic-returned', answers: Object.fromEntries(body.state.candidates.map((_: unknown, i: number) => [`m${i}`, { type: 'noul', noul: i===0?.9:0 }])), usage: { input_tokens: 100, output_tokens: 3 } }));
        return;
      }
      modelCalls++;
      response.writeHead(200, { 'content-type': 'text/event-stream' });
      const send = (delta: unknown, finish: string | null = null) => response.write(`data: ${JSON.stringify({ id: 'fixture', object: 'chat.completion.chunk', created: 1, model: 'e2e-model', choices: [{ index: 0, delta, finish_reason: finish }] })}\n\n`);
      const tool = body.messages.findLast((message: { role: string; content?: string }) => message.role === 'tool');
      if (!tool) {
        send({ tool_calls: [{ index: 0, id: 'fixture-read', type: 'function', function: { name: 'notebook_read', arguments: JSON.stringify({ query: 'JEV_SYNTHETIC_QUERY' }) } }] }); send({}, 'tool_calls');
      } else {
        evidenceCounts.push((String(tool.content).match(/SYNTHETIC_EVIDENCE/g) ?? []).length);
        send({ content: 'SYNTHETIC_FINAL_ANSWER' }); send({}, 'stop');
      }
      response.write(`data: ${JSON.stringify({ id: 'fixture', choices: [], usage: { prompt_tokens: 20, completion_tokens: 3, prompt_tokens_details: { cached_tokens: 0 } } })}\n\n`);
      response.end('data: [DONE]\n\n');
    } catch { serverErrors.push('local_fixture_protocol'); if (!response.headersSent) response.writeHead(500); response.end('{}'); }
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  writeFileSync(join(root, 'config', 'config.json'), JSON.stringify({ schemaVersion: 2, defaultProvider: 'e2e-local', defaultModelId: 'fixture', providers: { 'e2e-local': { type: 'first_party', protocol: 'openai_legacy', apiKey: 'synthetic-placeholder', baseUrl: `${baseUrl}/v1` } }, models: { fixture: { provider: 'e2e-local', model: 'e2e-model', label: 'fixture' } }, systemOne: { apiKey: 'synthetic-placeholder', baseUrl: 'https://api.typesafe.ai', model: 'jev-1.13.0' }, defaultMode: 'interactive', contextBudget: 100000, channels: {} }));
  const env = { ...process.env, NODE_ENV: 'test', XIAOK_DECISION_MODEL_E2E_FIXTURE:'1', XIAOK_CONFIG_DIR: join(root, 'config'), XIAOK_E2E_USER_DATA: join(root, 'profile'), XIAOK_MULTI_AGENT_E2E_ROOT: root, XIAOK_MULTI_AGENT_E2E_PROVIDER: `${baseUrl}/v1`, XIAOK_DISABLE_GLOBAL_PLUGINS: '1', ELECTRON_DISABLE_SECURITY_WARNINGS: '1' };
  Reflect.deleteProperty(env, 'ELECTRON_RUN_AS_NODE');
  const launchOptions = { args: [join(desktop, 'tests/e2e/fixtures/jev-memory-electron-main.mjs')], env, timeout: 30000 };
  let app: ElectronApplication | undefined;
  try {
    app = await electron.launch(launchOptions);
    let page = await app.firstWindow(); await page.waitForLoadState('domcontentloaded');
    await expect.poll(() => page.evaluate(() => typeof window.xiaokDesktop?.memoryJevGetSettings)).toBe('function');
    expect((await page.evaluate(() => window.xiaokDesktop.memoryJevGetSettings())).enabled).toBe(false);
    // A sibling renderer cannot turn its IPC calls into authorized user mutations.
    const rejected=await app.evaluate(async({BrowserWindow},preload)=>{
      const primary=BrowserWindow.getAllWindows().find(window=>window.webContents.getURL().includes('/renderer/index.html'))!;
      // Match the actual production window: its require('os') preload is not
      // compatible with a forced sandbox. A missing bridge is not a rejection.
      const other=new BrowserWindow({show:false,webPreferences:{...primary.webContents.getLastWebPreferences(),preload}});
      try{await other.loadURL(primary.webContents.getURL());if(await other.webContents.executeJavaScript(`typeof window.xiaokDesktop?.decisionModelsDownload`)!=='function')throw Error('sibling_production_preload_missing');return await other.webContents.executeJavaScript(`Promise.all([
        ['decisionModelsDownload','clef-flash-mlx-4bit'],['decisionModelsRemove','clef-flash-mlx-4bit'],
        ['decisionModelsCancel','clef-flash-mlx-4bit'],['decisionModelsStop','clef-flash-mlx-4bit'],
        ['decisionModelsStart',{modelId:'clef-flash-mlx-4bit',approveCommunityCode:true}],['decisionModelsUse','clef-flash-mlx-4bit'],
        ['memoryJevConfigure',{enabled:true}],['memoryJevClear'],['memoryJevFeedback','foreign','correction']
      ].map(async([key,...args])=>{try{await window.xiaokDesktop[key](...args);return false}catch(e){return String(e).slice(0,160)}}))`);}finally{other.destroy();}
    },join(desktop,'dist/main/desktop/electron/preload.cjs'));expect(rejected.every((v:unknown)=>String(v).includes('unauthorized_sender'))).toBe(true);
    await page.locator('aside button').last().click();
    await page.getByRole('button', { name: '记忆管理', exact: true }).click();
    const toggle = page.getByRole('checkbox', { name: '启用记忆决策判断' });
    await expect(toggle).not.toBeChecked();
    await expect(page.getByText(/TypeSafe 会接收/)).toBeVisible();
    await expect(page.getByText('本地决策模型',{exact:true})).toBeVisible();
    await expect(page.getByText('ClefFlash MLX 4bit（完整决策头）',{exact:true})).toBeVisible();
    const models=await page.evaluate(()=>window.xiaokDesktop.decisionModelsList());expect(models).toHaveLength(2);expect(models.every(m=>m.state==='not_installed')).toBe(true);
    await page.getByText('本地决策模型',{exact:true}).locator('..').screenshot({path:join(root,'local-models-not-installed.png')});
    await page.screenshot({ path: join(root, 'settings-default.png') });
    await page.evaluate(async () => { for (let i = 0; i < 3; i++) await window.xiaokDesktop.createMemory({ content: `JEV_SYNTHETIC_QUERY SYNTHETIC_EVIDENCE_${i}`, tags: [] }); });
    const run = async (label: string) => {
      const task = await page.evaluate(label => window.xiaokDesktop.createTask({ prompt: `Use notebook_read once: ${label}`, materials: [], context: { threadId: `jev-${label}` } }), label);
      await expect.poll(async () => (await page.evaluate(id => window.xiaokDesktop.recoverTask(id), task.taskId)).snapshot?.status, { timeout: 30000 }).toBe('completed');
      return task.taskId;
    };
    await run('off'); expect(jevCalls).toBe(0);
    let snapshot = await page.evaluate(() => window.xiaokDesktop.memoryJevSnapshot());
    expect(snapshot.reads.at(-1)).toMatchObject({ enabled: false, group: 'baseline', reason: 'disabled', dispatched: false, taskStatus: 'completed' });
    const baselineCount = snapshot.reads.at(-1)!.eligibleCount;
    expect(baselineCount).toBeGreaterThan(0); expect(evidenceCounts.at(-1)).toBe(baselineCount);
    const configure = (enabled: boolean) => page.evaluate(enabled => window.xiaokDesktop.memoryJevConfigure({ enabled }), enabled);
    await toggle.check(); await expect(toggle).toBeChecked();
    await expect.poll(async () => (await page.evaluate(() => window.xiaokDesktop.memoryJevGetSettings())).enabled).toBe(true);
    expect(await app.evaluate(() => (globalThis as any).jevMemoryE2E.blockedExternalRequests())).toBe(0);
    await app.close(); app = await electron.launch(launchOptions); page = await app.firstWindow(); await page.waitForLoadState('domcontentloaded');
    expect((await page.evaluate(() => window.xiaokDesktop.memoryJevGetSettings())).enabled).toBe(true);
    await run('on'); expect(jevCalls).toBe(1); expect(evidenceCounts.at(-1)).toBe(1);
    hold = true;
    const running = run('race'); await expect.poll(() => Boolean(held)).toBe(true);
    await configure(false); await running;
    snapshot = await page.evaluate(() => window.xiaokDesktop.memoryJevSnapshot());
    expect(snapshot.reads.at(-1)).toMatchObject({ reason: 'disabled_in_flight', keptCount: baselineCount, taskStatus: 'completed', costUsd: null });
    expect(evidenceCounts.at(-1)).toBe(baselineCount); held?.destroy(); hold = false;
    const id = snapshot.reads[0].id;
    await page.evaluate(id => window.xiaokDesktop.memoryJevFeedback(id, 'correction'), id);
    const exported = await page.evaluate(() => window.xiaokDesktop.memoryJevExport('json'));
    for (const content of ['JEV_SYNTHETIC_QUERY', 'SYNTHETIC_EVIDENCE', 'synthetic-placeholder', 'Use notebook_read']) expect(exported).not.toContain(content);
    const parsed = JSON.parse(exported); expect(parsed.reads[0].feedback).toBe('correction'); expect(parsed.tasks.length).toBe(3);
    expect(parsed.tasks.every((task: any) => task.usageSource === 'adapter_normalized' && task.usage.input === null && task.normalizedUsage.input !== null)).toBe(true);
    expect(parsed.tasks[0].requests).toHaveLength(2);
    expect(parsed.tasks.every((task: { wallMs: number; costUsd: null }) => task.wallMs >= 0 && task.costUsd === null)).toBe(true);
    const csv = await page.evaluate(() => window.xiaokDesktop.memoryJevExport('csv')); expect(csv).toContain('correction'); expect(csv).not.toContain('JEV_SYNTHETIC_QUERY');
    writeFileSync(join(root, 'metrics-export.json'), exported); writeFileSync(join(root, 'metrics-export.csv'), csv);
    const requestsAfterOff = jevCalls; await run('off-again'); expect(jevCalls).toBe(requestsAfterOff);
    // Actual settings UI persists a loopback provider without enabling it or probing the service.
    await page.locator('aside button').last().click();
    await page.getByRole('button', { name: '记忆管理', exact: true }).click();
    await page.getByRole('combobox', { name: '决策 provider' }).selectOption('local-systemone');
    await page.getByRole('textbox', { name: '本地端点' }).fill(`${baseUrl}/v1/systemone`);
    await page.getByRole('textbox', { name: '部署模型名' }).fill('clef-synthetic');
    await page.getByRole('textbox', { name: '运行时版本（可选技术标识）' }).fill('e2e-mock-v1');
    await page.getByRole('button', { name: '保存 provider 参数' }).click();
    await expect.poll(async () => (await page.evaluate(() => window.xiaokDesktop.memoryJevGetSettings())).decision?.provider).toBe('local-systemone');
    expect(localDecisionCalls).toBe(0);
    await expect(page.getByRole('checkbox', { name: '启用记忆决策判断' })).not.toBeChecked();
    await run('local-off'); expect(localDecisionCalls).toBe(0); expect(jevCalls).toBe(requestsAfterOff);
    await page.getByText('记忆决策判断（试用）', {exact:true}).locator('..').screenshot({ path: join(root, 'settings-local.png') });
    expect(await app.evaluate(() => (globalThis as any).jevMemoryE2E.blockedExternalRequests())).toBe(0);
    await app.close(); app = await electron.launch(launchOptions); page = await app.firstWindow(); await page.waitForLoadState('domcontentloaded');
    expect((await page.evaluate(() => window.xiaokDesktop.memoryJevGetSettings())).enabled).toBe(false);
    expect((await page.evaluate(() => window.xiaokDesktop.memoryJevGetSettings())).decision?.provider).toBe('local-systemone');
    await configure(true); await run('local-on'); expect(localDecisionCalls).toBe(1); expect(jevCalls).toBe(requestsAfterOff);
    snapshot = await page.evaluate(() => window.xiaokDesktop.memoryJevSnapshot());
    expect(snapshot.reads.at(-1)).toMatchObject({provider:'local-systemone',reason:'selected',keptCount:1,costUsd:0,decision:{localComputeUsd:null,totalCostUsd:null,metadata:{runtimeRevision:'e2e-mock-v1',confidenceProfile:'systemone-unknown'}}});
    await configure(false);
    // Lifecycle actions hit real IPC/main service with a tiny synthetic manifest and loopback runtime.
    await page.locator('aside button').last().click();await page.getByRole('button',{name:'记忆管理',exact:true}).click();
    const card=page.getByText('ClefFlash MLX 4bit（完整决策头）',{exact:true}).locator('..').locator('..');
    await card.getByRole('button',{name:'下载模型',exact:true}).click();
    await expect.poll(async()=> (await page.evaluate(()=>window.xiaokDesktop.decisionModelsList()))[0].state).toBe('installed');
    page.once('dialog',dialog=>dialog.accept());await card.getByRole('button',{name:'加载模型',exact:true}).click();
    await expect.poll(async()=> (await page.evaluate(()=>window.xiaokDesktop.decisionModelsList()))[0].state).toBe('ready');
    await card.getByRole('button',{name:'用于记忆判断（保持开关）',exact:true}).click();
    await expect.poll(async()=> (await page.evaluate(()=>window.xiaokDesktop.memoryJevGetSettings())).decision?.managedModelId).toBe('clef-flash-mlx-4bit');
    expect((await page.evaluate(()=>window.xiaokDesktop.memoryJevGetSettings())).enabled).toBe(false);
    await configure(true);await run('managed-local-on');await configure(false);expect(localDecisionCalls).toBe(2);
    page.once('dialog',dialog=>dialog.accept());await card.getByRole('button',{name:'删除模型',exact:true}).click();
    await expect.poll(async()=> (await page.evaluate(()=>window.xiaokDesktop.decisionModelsList()))[0].state).toBe('not_installed');
    writeFileSync(join(root,'decision-metrics-export.json'),await page.evaluate(()=>window.xiaokDesktop.memoryJevExport('json')));
    await page.evaluate(() => window.xiaokDesktop.memoryJevClear()); expect((await page.evaluate(() => window.xiaokDesktop.memoryJevSnapshot())).reads).toHaveLength(0);
    expect(await app.evaluate(() => (globalThis as any).jevMemoryE2E.blockedExternalRequests())).toBe(0);
    expect(serverErrors).toEqual([]);
    writeFileSync(join(root, 'result.json'), JSON.stringify({ passed: true, jevCalls, localDecisionCalls, modelCalls, evidenceCounts, isolated: true, profile: root }, null, 2));
    console.log('JEV_ELECTRON_EVIDENCE', root);
  } catch (error) {
    console.log('JEV_ELECTRON_FAILURE_EVIDENCE', root);
    if (existsSync(join(root, 'electron.log')) && readFileSync(join(root, 'electron.log'), 'utf8').includes('startup failed')) console.log('isolated_electron_startup_failed');
    throw error;
  } finally {
    held?.destroy(); await app?.close(); server.closeAllConnections(); await new Promise<void>(resolve => server.close(() => resolve()));
    // Keep only isolated synthetic evidence for review; never remove a user profile.
    rmSync(join(root, 'profile'), { recursive: true, force: true, maxRetries: 3 });
  }
});
