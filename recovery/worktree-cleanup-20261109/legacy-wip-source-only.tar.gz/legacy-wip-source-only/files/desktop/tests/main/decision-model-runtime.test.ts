// @vitest-environment node
import {describe,it,expect,afterEach} from 'vitest';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,linkSync,symlinkSync,rmSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {startDecisionModelRuntime} from '../../electron/decision-model-runtime.js';
import {DECISION_MODEL_CATALOG} from '../../electron/decision-model-catalog.js';
const roots:string[]=[];afterEach(()=>roots.splice(0).forEach(root=>rmSync(root,{recursive:true,force:true})));
const mac=process.platform==='darwin'&&process.arch==='arm64';
function fixture(){const root=mkdtempSync(join(tmpdir(),'decision-runtime-'));roots.push(root);const modelPath=join(root,'model');mkdirSync(modelPath);return{root,modelPath,model:DECISION_MODEL_CATALOG[0],missingPython:join(root,'no-interpreter')};}
describe('owned decision runtime envelope',()=>{
 it.runIf(mac)('reports missing interpreter without executing community code and never truncates a hardlink',async()=>{const f=fixture();await expect(startDecisionModelRuntime(f.model,f.modelPath,undefined,f.missingPython)).rejects.toThrow('runtime_missing');const runtime=join(f.root,'.runtime');const code=join(runtime,readdirSync(runtime).find(name=>name.endsWith('.py'))!);rmSync(code);const outside=join(f.root,'user-file');writeFileSync(outside,'keep');linkSync(outside,code);await expect(startDecisionModelRuntime(f.model,f.modelPath,undefined,f.missingPython)).rejects.toThrow('runtime_missing');expect(readFileSync(outside,'utf8')).toBe('keep');expect(readFileSync(code,'utf8')).toContain('ThreadingHTTPServer');});
 it.runIf(mac)('serves a token-protected first-party HTTP envelope after a real synthetic forward',async()=>{
  const f=fixture();const source="class Model:\n def systemone(self,request,**kwargs):\n  assert isinstance(request.get('model'),str)\n  return {'model':request['model'],'answers':{k:{'type':'noul','noul':0.9} for k in request['questions']},'usage':{'input_tokens':12,'output_tokens':0}}\ndef load(*args,**kwargs):return Model()\n";
  writeFileSync(join(f.modelPath,'clef_mlx.py'),source);const interpreter=join(f.root,'synthetic-python');
  // Only controlled test Python executes. No real model/dependency installation.
  writeFileSync(interpreter,"#!/usr/bin/env python3\nimport sys,importlib.metadata\nimportlib.metadata.version=lambda name:'0.7.4' if name=='mlx-vlm' else '0.32.3'\nsys.argv=sys.argv[3:]\nexec(compile(open(sys.argv[0]).read(),sys.argv[0],'exec'),{'__name__':'__main__'})\n",{mode:0o700});
  const run=await startDecisionModelRuntime({...f.model,codeHash:createHash('sha256').update(source).digest('hex')},f.modelPath,undefined,interpreter);
  try{expect(run.info?.implementation).toBe('xiaok-local-text-v2');expect((await fetch(run.endpoint,{method:'POST',body:'{}'})).status).toBe(403);const response=await run.transport(run.endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({model:'synthetic-model',state:'synthetic',questions:{q:{type:'noul',instructions:'synthetic question'}}})});expect(response.status).toBe(200);expect((await response.json()).answers.q.noul).toBe(.9);}finally{await run.stop();}expect(run.alive?.()).toBe(false);
 });
 it.runIf(mac)('rejects a symlink runtime directory before any child can start',async()=>{const f=fixture();const outside=join(f.root,'outside');mkdirSync(outside);symlinkSync(outside,join(f.root,'.runtime'));await expect(startDecisionModelRuntime(f.model,f.modelPath,undefined,f.missingPython)).rejects.toThrow('unsafe_path');expect(readdirSync(outside)).toEqual([]);});
 it.runIf(!mac)('gates unsupported platforms before writing runtime files',async()=>{const f=fixture();await expect(startDecisionModelRuntime(f.model,f.modelPath,undefined,f.missingPython)).rejects.toThrow('unsupported_platform');expect(readdirSync(f.root)).toEqual(['model']);});
});
