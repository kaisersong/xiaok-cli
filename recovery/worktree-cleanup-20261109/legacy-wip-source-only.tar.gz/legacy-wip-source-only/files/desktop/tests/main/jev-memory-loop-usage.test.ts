// @vitest-environment node
import { it, expect } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ToolRegistry } from '../../../src/ai/tools/index.js';
import { createNotebookTools } from '../../../src/ai/tools/notebook.js';
import { FileMemoryStore } from '../../../src/ai/memory/store.js';
import { JevMemoryTrial } from '../../electron/jev-memory-trial-service.js';
import { runDesktopToolLoop } from '../../electron/desktop-services.js';

it('joins production model-loop usage and notebook evidence into one trial task', async () => {
  const root = mkdtempSync(join(tmpdir(), 'jev-loop-usage-'));
  const trial = new JevMemoryTrial(root, async () => null);
  const store = new FileMemoryStore(join(root, 'memory'));
  await store.save({ id: 'synthetic-evidence', scope: 'global', title: 'synthetic', summary: 'synthetic evidence for the answer', tags: [], updatedAt: Date.now(), type: 'user' });
  const registry = new ToolRegistry({ autoMode: true }, createNotebookTools(store, { read: input => trial.read(input) }));
  let requests = 0;
  try {
    const result = await trial.runTask({ taskId: 'fixture-task', sessionId: 'fixture-session', model: 'synthetic-final', provider: 'fixture' }, async () => runDesktopToolLoop({
      adapter: { async *stream(messages) {
        requests++;
        yield { type: 'usage' as const, usage: { inputTokens: requests * 10, outputTokens: requests, cacheReadInputTokens: 0 } };
        if (requests === 1) yield { type: 'tool_use' as const, id: 'read-call', name: 'notebook_read', input: { query: 'synthetic' } };
        else {
          expect(JSON.stringify(messages)).toContain('synthetic evidence for the answer');
          yield { type: 'text' as const, delta: 'final answer from the same model' };
        }
        yield { type: 'done' as const };
      } }, registry, allToolDefs: registry.getToolDefinitions(), messages: [{ role: 'user', content: [{ type: 'text', text: 'use synthetic evidence' }] }],
      systemPrompt: '', signal: new AbortController().signal, taskDeadline: Date.now() + 30000,
      sessionId: 'fixture-session', turnId: 'fixture-turn', taskId: 'fixture-task', intentId: 'fixture-intent', stepId: 'fixture-step',
      materials: [], emitRuntimeEvent: async () => {}, skillInvocation: null, skillCatalog: {} as never,
      dataRoot: root, taskStartTime: Date.now(), maxIterations: 2,
      onTrialUsage: (id, usage) => trial.observeProviderUsage(id, usage),
      strategies: { compact: { enabled: false, shouldCompact: () => false, doCompact: async () => {} }, buildApiView: m => m, processToolResult: r => r, trackAutoProgress: false, trackReferenceReads: false, emitSkillArtifactTrace: false },
    }));
    expect(result.reply).toBe('final answer from the same model');
    const event = trial.snapshot().reads[0];
    expect(event.reason).toBe('disabled');
    expect(event.finalAttempts).toBe(2);
    expect(event.finalUsage).toEqual({ input: 30, output: 3, cacheRead: 0, cacheWrite: null });
    expect(event.taskWallMs).toBeGreaterThanOrEqual(event.readWallMs);
    expect(event.taskStatus).toBe('completed');
    expect(JSON.parse(trial.export('json')).tasks).toHaveLength(1);
  } finally {
    registry.dispose();
    rmSync(root, { recursive: true, force: true, maxRetries: 3 });
  }
});
