import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it, expect, vi } from 'vitest';
import { JevMemoryTrial } from '../../electron/jev-memory-trial-service.js';
import { JevTrialMetrics } from '../../electron/jev-memory-trial-metrics.js';
const candidates=[0,1].map(i=>({id:String(i),scope:'global' as const,title:'synthetic',summary:'synthetic evidence',tags:[],updatedAt:1}));
const selection={provider:'local-systemone' as const,endpoint:'http://127.0.0.1:8765/v1/systemone',model:'synthetic-local',runtimeRevision:'mock-v1',profile:'systemone-unknown' as const};
const source={requestSource:'user' as const};
const input={query:'synthetic query',cwd:'',candidates};
const response=()=>new Response(JSON.stringify({model:'local-returned',answers:{m0:{type:'noul',noul:0},m1:{type:'noul',noul:0}},usage:{input_tokens:20},usage_source:'estimated'}));
describe('decision memory configuration and telemetry migration',()=>{
 it('same saved selection is idempotent and does not cancel in-flight work',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'decision-repeat-'));let finish!:(r:Response)=>void;
  try{const transport=vi.fn(()=>new Promise<Response>(r=>{finish=r}));const trial=new JevMemoryTrial(dir,async()=>null,transport);trial.configure({enabled:true,decision:selection},source);
   const initial=trial.settings();const pending=trial.read(input);await vi.waitFor(()=>expect(transport).toHaveBeenCalledTimes(1));
   expect(trial.configure({decision:{...selection}},source)).toEqual(initial);finish(new Response(JSON.stringify({model:'local-returned',answers:{m0:{type:'noul',noul:1},m1:{type:'noul',noul:0}}})));
   expect(await pending).toEqual([candidates[0]]);expect(trial.snapshot().reads[0].reason).toBe('selected');
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
 it('switches local A to B then cloud, rejects late A output and restores only B after restart',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'decision-model-switch-'));let finish!:(r:Response)=>void;
  try{const transport=vi.fn((url)=>String(url).includes(':8765')?new Promise<Response>(r=>{finish=r}):Promise.resolve(new Response(JSON.stringify({model:'returned',answers:{m0:{type:'noul',noul:1},m1:{type:'noul',noul:0}}}))));const credentials=async()=>({apiKey:'synthetic',baseUrl:'https://api.typesafe.ai',model:'cloud-fixture'});const trial=new JevMemoryTrial(dir,credentials,transport);trial.configure({enabled:true,decision:selection},source);
   const pending=trial.read(input);await vi.waitFor(()=>expect(transport).toHaveBeenCalledTimes(1));const b={...selection,model:'model-b',endpoint:'http://127.0.0.1:8766/v1/systemone'};trial.configure({decision:b},source);finish(response());expect(await pending).toEqual(candidates);expect(trial.snapshot().reads[0].reason).toBe('disabled_in_flight');
   const restarted=new JevMemoryTrial(dir,credentials,transport);expect(restarted.settings().decision).toEqual(b);expect(await restarted.read(input)).toEqual([candidates[0]]);expect(String(transport.mock.calls[1][0])).toContain(':8766');
   restarted.configure({decision:{provider:'typesafe-jev'}},source);await restarted.read(input);expect(String(transport.mock.calls[2][0])).toContain('typesafe');expect(restarted.settings().decision).toEqual({provider:'typesafe-jev'});
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
 it('persists selection across restart, remains off without credentials or any transport, never edits cloud config',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'decision-memory-'));
  try{const creds=vi.fn(async()=>null),fetcher=vi.fn(async()=>response());const trial=new JevMemoryTrial(dir,creds,fetcher);
   trial.configure({decision:selection},source);expect(trial.settings().enabled).toBe(false);await trial.read(input);expect(creds).not.toHaveBeenCalled();expect(fetcher).not.toHaveBeenCalled();
   const reopened=new JevMemoryTrial(dir,creds,fetcher);expect(reopened.settings().decision).toEqual(selection);reopened.configure({enabled:true},source);expect(await reopened.read(input)).toHaveLength(2);expect(creds).not.toHaveBeenCalled();
   const event=reopened.snapshot().reads.at(-1)!;expect(event).toMatchObject({provider:'local-systemone',costUsd:0,decision:{apiCostUsd:0,totalCostUsd:null,localComputeUsd:null,usageSource:'estimated',estimatedUsage:{input:20}},usage:{input:null},decisionVersion:'systemone-text-v1'});
   const exported=JSON.parse(reopened.export('json'));expect(exported.aggregate.find((g:any)=>g.group==='experiment')).toMatchObject({provider:'local-systemone',runtimeRevision:'mock-v1',confidenceProfile:'systemone-unknown'});expect(reopened.export('csv')).toContain('estimatedUsage');for(const text of ['synthetic query','synthetic evidence','127.0.0.1'])expect(reopened.export('json')).not.toContain(text);
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
 it('provider switch aborts stale cloud request and new local selection owns next read',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'decision-switch-'));let finish!: (r:Response)=>void;
  try{const fetcher=vi.fn((url)=>String(url).includes('typesafe')?new Promise<Response>(r=>{finish=r}):Promise.resolve(response()));const trial=new JevMemoryTrial(dir,async()=>({apiKey:'synthetic',baseUrl:'https://api.typesafe.ai',model:'m'}),fetcher);trial.configure({enabled:true},source);
   const pending=trial.read(input);await vi.waitFor(()=>expect(fetcher).toHaveBeenCalled());trial.configure({decision:selection},source);finish(response());expect(await pending).toEqual(candidates);expect(trial.snapshot().reads[0].reason).toBe('disabled_in_flight');expect(await trial.read(input)).toHaveLength(2);expect(fetcher.mock.calls[1][1]!.headers).not.toHaveProperty('Authorization');
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
 it('local unavailable/unsupported errors safely fall back; agent cannot choose provider',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'decision-fallback-'));
  try{for(const code of [422,503]){const trial=new JevMemoryTrial(dir,async()=>null,async()=>new Response('private body',{status:code}));trial.configure({enabled:true,decision:selection},source);expect(await trial.read(input)).toEqual(candidates);expect(trial.snapshot().reads.at(-1)!.reason).toBe(code===422?'unsupported_capability':'unavailable');expect(trial.export('json')).not.toContain('private body');}
   const trial=new JevMemoryTrial(dir,async()=>null);expect(()=>trial.configure({decision:selection},{requestSource:'agent'})).toThrow('trial_user_only');
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
 it('reads old three-field settings and old schema without silently reinterpreting runtime semantics',async()=>{
  const dir=mkdtempSync(join(tmpdir(),'decision-legacy-'));
  try{const generation='12345678-1234-1234-1234-123456789012';writeFileSync(join(dir,'memory-jev-settings.json'),JSON.stringify({version:1,enabled:true,generation}));const trial=new JevMemoryTrial(dir,async()=>null);expect(trial.settings()).toEqual({version:1,enabled:true,generation});await trial.read(input);const row=trial.snapshot().reads[0];delete row.decisionVersion;delete row.confidenceProfile;delete row.runtimeRevision;writeFileSync(join(dir,'legacy.json'),JSON.stringify({schema:1,reads:[row]}));const metrics=new JevTrialMetrics(join(dir,'legacy.json'),false);expect(metrics.aggregate()[0]).toMatchObject({provider:'typesafe',decisionVersion:'legacy-v1',confidenceProfile:'legacy-unknown'});
  }finally{rmSync(dir,{recursive:true,force:true});}
 });
});
