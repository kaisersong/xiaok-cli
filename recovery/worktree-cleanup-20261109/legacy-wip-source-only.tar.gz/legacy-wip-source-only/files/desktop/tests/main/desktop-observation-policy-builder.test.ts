// @vitest-environment node
import {afterEach,describe,expect,it} from 'vitest';
import {mkdirSync,mkdtempSync,rmSync,symlinkSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {realpathSync} from 'node:fs';
import {buildObservationPolicy,describeObservationPolicyScope,expandObservationReadScopes} from '../../electron/desktop-observation-policy-builder.js';
import {describeProductObservationPolicy,parseObservationPolicyInput} from '../../../src/runtime/sol-pi/product-bootstrap.js';

const roots:string[]=[];afterEach(()=>{roots.splice(0).forEach(root=>rmSync(root,{recursive:true,force:true}));});
const fresh=()=>{const root=realpathSync(mkdtempSync(join(tmpdir(),'observation-builder-')));roots.push(root);return root;};
const deepseekConfig={schemaVersion:2,defaultModelId:'main',models:{main:{model:'any-model',provider:'deepseek'}},
  providers:{deepseek:{type:'first_party',protocol:'openai_legacy',baseUrl:'https://api.deepseek.com/v1',apiKey:'sk-test'}}};

describe('Desktop observation policy builder',()=>{
 it('expands directories deterministically, skipping .git, node_modules and symlinks',()=>{
  const root=fresh();writeFileSync(join(root,'b.txt'),'b');writeFileSync(join(root,'a.txt'),'a');
  mkdirSync(join(root,'sub'));writeFileSync(join(root,'sub','c.md'),'c');
  mkdirSync(join(root,'.git'));writeFileSync(join(root,'.git','pack'),'x');
  mkdirSync(join(root,'node_modules'));writeFileSync(join(root,'node_modules','dep.js'),'x');
  symlinkSync(join(root,'a.txt'),join(root,'link.txt'));symlinkSync(join(root,'sub'),join(root,'symdir'));
  expect(expandObservationReadScopes([root])).toEqual([
    {filePath:join(root,'a.txt'),startLine:1},
    {filePath:join(root,'b.txt'),startLine:1},
    {filePath:join(root,'sub','c.md'),startLine:1},
  ]);
 });
 it('accepts directly selected regular files and whole-file scopes',()=>{
  const root=fresh();const one=join(root,'one.ts'),two=join(root,'two.ts');writeFileSync(one,'1');writeFileSync(two,'2');
  expect(expandObservationReadScopes([one,two])).toEqual([{filePath:one,startLine:1},{filePath:two,startLine:1}]);
 });
 it('denies selections expanding beyond 128 files and empty selections',()=>{
  const root=fresh();const many=join(root,'many');mkdirSync(many);
  for(let index=0;index<129;index+=1)writeFileSync(join(many,`f${String(index).padStart(3,'0')}.txt`),'x');
  expect(()=>expandObservationReadScopes([many])).toThrow(/TOO_MANY_SOURCES/);
  const empty=join(root,'empty');mkdirSync(empty);
  expect(()=>expandObservationReadScopes([empty])).toThrow(/NO_USABLE_SOURCES/);
 });
 it('reports unusable direct selections instead of silently returning nothing',()=>{
  const root=fresh();const target=join(root,'real.txt');writeFileSync(target,'x');const link=join(root,'link.txt');symlinkSync(target,link);
  expect(()=>expandObservationReadScopes([link])).toThrow(/INVALID_READ_SCOPE/);
 });
 it('builds a policy equivalent to a hand-written consent file, validated by the shared parser',()=>{
  const root=fresh();const file=join(root,'source.py');writeFileSync(file,'print(1)');
  const before=Date.now();const policy=buildObservationPolicy([file],deepseekConfig,before);
  const summary=describeProductObservationPolicy(policy) as any;
  expect(summary.model).toBe('deepseek-flash');
  expect(summary.destination).toEqual({provider:'deepseek',url:'https://api.deepseek.com/v1/chat/completions'});
  expect(summary.expiresAt).toBe(before+7*86400000);
  expect(summary.readFileScopes).toEqual([{filePath:file,startLine:1}]);
  expect(summary.bashSources).toEqual([]);
  expect(summary.localPersistence).toBe(true);expect(summary.allowUnclassifiedText).toBe(true);
  expect(summary.allowModelDisclosure).toBe(true);
  // allowIncomplete=false is enforced at parse time (truthy values are rejected before any draft exists).
  expect(summary.semanticCompaction).toBeUndefined();expect(summary.compoundExecution).toBeUndefined();
  // The generated object passes the same strict validation as a user-authored file.
  expect(parseObservationPolicyInput(JSON.parse(JSON.stringify({
    version:1,environmentId:'deepseek-recipe-0.1.1',model:'deepseek-flash',
    destination:{provider:'deepseek',url:'https://api.deepseek.com/v1/chat/completions'},
    localPersistence:true,allowUnclassifiedText:true,allowModelDisclosure:true,allowIncomplete:false,
    expiresAt:before+7*86400000,readFileScopes:[{filePath:file,startLine:1}],bashSources:[],
  })))).toBeTruthy();
 });
 it('derives the destination only from an official deepseek binding',()=>{
  const root=fresh();const file=join(root,'a.txt');writeFileSync(file,'a');
  expect(()=>buildObservationPolicy([file],{...deepseekConfig,providers:{deepseek:{...deepseekConfig.providers.deepseek,baseUrl:'https://example.com/v1'}}})).toThrow(/DESTINATION_NOT_READY/);
  expect(()=>buildObservationPolicy([file],{...deepseekConfig,defaultModelId:'missing'})).toThrow(/MODEL_NOT_READY/);
 });
 it('names the policy scope by the shared directory, falling back to counts',()=>{
  expect(describeObservationPolicyScope({readFileScopes:[{filePath:'/work/app/src/a.ts'},{filePath:'/work/app/src/b/c.ts'}],bashSources:[]})).toEqual({directoryName:'src',fileCount:2,commandCount:0});
  expect(describeObservationPolicyScope({readFileScopes:[{filePath:'/work/a.ts'},{filePath:'/etc/b.ts'}],bashSources:[]})).toEqual({fileCount:2,commandCount:0});
  expect(describeObservationPolicyScope({readFileScopes:[],bashSources:[{},{}]})).toEqual({fileCount:0,commandCount:2});
 });
});
