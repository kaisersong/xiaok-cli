import { mkdtempSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { JevMemoryTrial, TRIAL_VERSION } from '../../electron/jev-memory-trial-service.js';
import type { MemoryRecord } from '../../../src/ai/memory/store.js';
import { JevTrialMetrics } from '../../electron/jev-memory-trial-metrics.js';
import { createNotebookTools } from '../../../src/ai/tools/notebook.js';
const dirs: string[] = [];
afterEach(() => { dirs.splice(0).forEach(d => rmSync(d, { recursive: true, force: true })); });
const records: MemoryRecord[] = [0,1,2].map(i => ({id:`private-${i}`,scope:'global',title:'',summary:`synthetic evidence ${i}`,tags:[],updatedAt:1}));
function fixture(fetcher = vi.fn(async () => new Response(JSON.stringify({model:'jev-test',answers:{m0:{type:'noul',noul:.1},m1:{type:'noul',noul:.9},m2:{type:'noul',noul:.1}},usage:{input_tokens:100,output_tokens:10}})))) {
 const dir = mkdtempSync(join(tmpdir(),'jev-trial-')); dirs.push(dir);
 const trial = new JevMemoryTrial(dir, async () => ({apiKey:'test-fixture-key',model:'jev-test',baseUrl:'https://api.typesafe.ai'}), fetcher);
 return {dir,trial,fetcher};
}
describe('Jev memory trial production service', () => {
 it('defaults off, rejects invalid/upgraded settings and persists restart', async () => {
  const {dir,trial,fetcher}=fixture(); expect(trial.settings().enabled).toBe(false);
  expect(await trial.read({query:'synthetic query',cwd:'',candidates:records})).toEqual(records);expect(fetcher).not.toHaveBeenCalled();
  trial.configure({enabled:true},{requestSource:'user'});expect(new JevMemoryTrial(dir,async()=>null).settings().enabled).toBe(true);
  for(const bad of [{version:TRIAL_VERSION,enabled:'true'},{version:999,enabled:true}]) {writeFileSync(join(dir,'memory-jev-settings.json'),JSON.stringify(bad));expect(new JevMemoryTrial(dir,async()=>null).settings().enabled).toBe(false);}
 });
 it('refuses credentials to unexpected API hosts, HTTP, credentials, ports or paths',async()=>{
  for(const baseUrl of ['https://other.example','http://api.typesafe.ai','https://api.typesafe.ai.other.example','https://user:pass@api.typesafe.ai','https://api.typesafe.ai:444','https://api.typesafe.ai/other','https://api.typesafe.ai?redirect=other']){
   const {dir}=fixture();const fetcher=vi.fn();const trial=new JevMemoryTrial(dir,async()=>({apiKey:'synthetic-only',model:'jev-test',baseUrl}),fetcher);trial.configure({enabled:true},{requestSource:'user'});expect(await trial.read({query:'q',cwd:'',candidates:records})).toEqual(records);expect(fetcher).not.toHaveBeenCalled();expect(trial.snapshot().reads[0]).toMatchObject({reason:'untrusted_endpoint',dispatched:false,costUsd:null});
  }
 });
 it('keeps HMAC correlations stable on restart while separating real retry IDs',async()=>{
  const {dir,trial}=fixture();await trial.runTask({taskId:'same-task',sessionId:'same-session',model:'m',provider:'p'},async()=>{trial.observeProviderUsage('attempt-1');trial.observeProviderUsage('attempt-1',{inputTokens:1,outputTokens:1});trial.observeProviderUsage('attempt-2');await trial.read({query:'q',cwd:'',candidates:records});});const before=trial.snapshot().reads[0];const reopened=new JevMemoryTrial(dir,async()=>null);await reopened.runTask({taskId:'same-task',sessionId:'same-session',model:'m',provider:'p'},async()=>{reopened.observeProviderUsage('attempt-1');await reopened.read({query:'q',cwd:'',candidates:records});});const after=reopened.snapshot().reads[1];expect(after.taskRef).toBe(before.taskRef);expect(after.sessionRef).toBe(before.sessionRef);expect(after.runId).not.toBe(before.runId);expect(after.finalRequests[0].requestRef).toBe(before.finalRequests[0].requestRef);expect(before.finalAttempts).toBe(2);expect(before.finalRequests[0].requestRef).not.toBe(before.finalRequests[1].requestRef);const salt=JSON.parse(readFileSync(join(dir,'memory-jev-correlation.json'),'utf8')).salt;expect(reopened.export('json')).not.toContain(salt);
 });
 it('denies settings, feedback and clear by agents',()=>{const {trial}=fixture();for(const requestSource of ['agent','scheduler'] as const){expect(()=>trial.configure({enabled:true},{requestSource})).toThrow();expect(()=>trial.clear({requestSource})).toThrow();expect(()=>trial.feedback('bad','helpful',{requestSource})).toThrow();}});
 it('uses bounded named Noul state and keeps anchor with strict response and unknown costs', async()=>{
  const {trial,fetcher}=fixture();trial.configure({enabled:true},{requestSource:'user'});
  expect((await trial.read({query:'synthetic query',cwd:'',candidates:records})).map(r=>r.id)).toEqual(['private-0','private-1']);
  const body=JSON.parse(fetcher.mock.calls[0][1]!.body as string);expect(body.state.candidates[0].text).toBe(records[0].summary);expect(JSON.stringify(body)).not.toContain('private-0');
  const e=trial.snapshot().reads[0];expect(e.usage.input).toBe(100);expect(e.usage.cacheRead).toBeNull();expect(e.costUsd).toBeNull();expect(e.taskWallMs).toBeNull();
 });
 it('valid all-low decisions retain the complete baseline and record a fallback, including later useful evidence',async()=>{const {trial}=fixture(vi.fn(async()=>new Response(JSON.stringify({model:'jev-test',answers:{m0:{type:'noul',noul:.4},m1:{type:'noul',noul:.42},m2:{type:'noul',noul:.39}},usage:{input_tokens:99,output_tokens:0}}))));trial.configure({enabled:true},{requestSource:'user'});expect(await trial.read({query:'q',cwd:'',candidates:records})).toEqual(records);expect(trial.snapshot().reads[0]).toMatchObject({reason:'all_low_probability',keptCount:3,judgedCount:3,dispatched:true,usage:{input:99}});expect(trial.aggregate()[0]).toMatchObject({fallback:1,selectedReads:0});expect(JSON.parse(trial.export('json')).reads[0].reason).toBe('all_low_probability');});
 it('all-low cannot clear evidence, no-key/error/protocol safely fall back',async()=>{
  for(const response of [{answers:{m0:{type:'noul',noul:0},m1:{type:'noul',noul:0},m2:{type:'noul',noul:0}}},{answers:{m0:{noul:2}}}]){
   const {trial}=fixture(vi.fn(async()=>new Response(JSON.stringify(response))));trial.configure({enabled:true},{requestSource:'user'});expect((await trial.read({query:'q',cwd:'',candidates:records})).length).toBeGreaterThan(0);
  }
  const {dir}=fixture();const noKey=new JevMemoryTrial(dir,async()=>null);noKey.configure({enabled:true},{requestSource:'user'});expect(await noKey.read({query:'q',cwd:'',candidates:records})).toEqual(records);expect(noKey.snapshot().reads[0].reason).toBe('missing_key');
 });
 it('filters scope before network and excludes secrets, without content in logs',async()=>{
  const {dir,trial,fetcher}=fixture(vi.fn(async()=>new Response(JSON.stringify({model:'jev-test',answers:{m0:{type:'noul',noul:1}}}))));trial.configure({enabled:true},{requestSource:'user'});
  const candidates=[records[0],{...records[1],scope:'project' as const,cwd:'/other'},{...records[2],summary:'api_key=super-private-token-value'}];
  const result=await trial.read({query:'private-query-phrase',cwd:'/current',candidates,taskId:'personal-task'});expect(result).toHaveLength(2);
  const payload=JSON.stringify(fetcher.mock.calls);expect(payload).not.toContain('super-private-token-value');expect(payload).not.toContain(records[1].summary);
  const log=readFileSync(join(dir,'memory-jev-metrics.json'),'utf8');for(const text of ['private-query-phrase','personal-task','synthetic evidence','super-private-token-value','test-fixture-key']) expect(log).not.toContain(text);
 });
 it('disable aborts in flight and off/on ignores old results',async()=>{
  let resolve!: (r:Response)=>void; const {trial,fetcher}=fixture(vi.fn(()=>new Promise<Response>(r=>{resolve=r;})));trial.configure({enabled:true},{requestSource:'user'});
  const read=trial.read({query:'q',cwd:'',candidates:records});await vi.waitFor(()=>expect(fetcher).toHaveBeenCalled());trial.configure({enabled:false},{requestSource:'user'});trial.configure({enabled:true},{requestSource:'user'});resolve(new Response('{}'));
  expect(await read).toEqual(records);expect(trial.snapshot().reads[0].reason).toBe('disabled_in_flight');
 });
 it('cancellation and timeout bound ignored transports',async()=>{
  const {trial}=fixture(vi.fn(()=>new Promise<Response>(()=>{})));trial.configure({enabled:true},{requestSource:'user'});
  const controller=new AbortController();const read=trial.read({query:'q',cwd:'',candidates:records,signal:controller.signal});controller.abort();expect(await read).toEqual(records);expect(trial.snapshot().reads[0].reason).toBe('cancelled');
  vi.useFakeTimers();const pending=trial.read({query:'q',cwd:'',candidates:records});await vi.advanceTimersByTimeAsync(2600);expect(await pending).toEqual(records);vi.useRealTimers();expect(trial.snapshot().reads[1].reason).toBe('timeout');
 });
 it('aggregates and exports unknown coverage, feedback and task joins',async()=>{
  const {trial}=fixture();await trial.runTask({taskId:'task',sessionId:'session',model:'llm-test',provider:'test'},async observe=>{await trial.read({query:'q',cwd:'',candidates:records});observe({inputTokens:20,outputTokens:2});});
  const read=trial.snapshot().reads[0];expect(read.taskWallMs).not.toBeNull();expect(read.finalUsage.input).toBe(20);trial.feedback(read.id,'correction',{requestSource:'user'});
  const group=trial.aggregate()[0];expect(group.reads).toBe(1);expect(group.unreviewed).toBe(0);expect(group.unknownCost).toBe(1);expect(group.correction).toBe(1);expect(trial.export('csv')).toContain('correction');expect(JSON.parse(trial.export('json')).reads).toHaveLength(1);trial.clear({requestSource:'user'});expect(trial.snapshot().reads).toHaveLength(0);
 });
 it('notebook tool calls production trial with trusted context, no input scope override',async()=>{
  const {trial}=fixture();const search=vi.fn(async()=>records);const tool=createNotebookTools({save:async()=>{},listRelevant:async()=>records,search},{read:(input)=>trial.read(input)}).find(t=>t.definition.name==='notebook_read')!;
  const answer=await tool.execute({query:'q',cwd:'/evil'});expect(answer).toContain('synthetic evidence');expect(trial.snapshot().reads).toHaveLength(1);expect(search).toHaveBeenCalledTimes(1);
 });
});

describe('Jev trial adversarial boundaries',()=>{
 it('never resolves credentials for disabled, private-query and permission-bound reads',async()=>{
  const {dir}=fixture();const credentials=vi.fn(async()=>null);const trial=new JevMemoryTrial(dir,credentials,vi.fn());
  await trial.read({query:'q',cwd:'',candidates:records});trial.configure({enabled:true},{requestSource:'user'});
  await trial.read({query:'api_key=private-token-value-1234',cwd:'',candidates:records});await trial.read({query:'q',cwd:'',candidates:records,remoteAllowed:false});expect(credentials).not.toHaveBeenCalled();expect(trial.snapshot().reads.map(e=>e.reason)).toEqual(['disabled','sensitive_query','permission_boundary']);
 });
 it('bounds concurrency, requests, errors and unjudged long candidates',async()=>{
  const {trial,fetcher}=fixture(vi.fn(()=>new Promise<Response>(()=>{})));trial.configure({enabled:true},{requestSource:'user'});const controller=new AbortController();const input={query:'q',cwd:'',candidates:records,signal:controller.signal};const a=trial.read(input),b=trial.read(input);expect(await trial.read(input)).toEqual(records);expect(trial.snapshot().reads[0].reason).toBe('concurrency');controller.abort();await Promise.all([a,b]);expect(fetcher.mock.calls.length).toBeLessThanOrEqual(2);
  const fast=fixture(vi.fn(async()=>new Response('private-query-in-error',{status:500})));fast.trial.configure({enabled:true},{requestSource:'user'});expect(await fast.trial.read({query:'q',cwd:'',candidates:records})).toEqual(records);expect(fast.trial.snapshot().reads[0].reason).toBe('error');expect(fast.trial.export('json')).not.toContain('private-query-in-error');
  await fast.trial.read({query:'q'.repeat(5000),cwd:'',candidates:records});expect(fast.trial.snapshot().reads[1].reason).toBe('budget');
 });
 it('prices verified returned version only and joins repeated provider usage once',async()=>{
  const {trial}=fixture(vi.fn(async()=>new Response(JSON.stringify({model:'jev-1.13.0',answers:{m0:{type:'noul',noul:1},m1:{type:'noul',noul:1},m2:{type:'noul',noul:1}},usage:{input_tokens:100,output_tokens:3}}))));trial.configure({enabled:true},{requestSource:'user'});
  await trial.runTask({taskId:'task',sessionId:'session',model:'llm-test',provider:'test'},async()=>{trial.observeProviderUsage('request1');trial.observeProviderUsage('request1',{inputTokens:10,outputTokens:2,cacheReadInputTokens:0,cacheCreationInputTokens:0});trial.observeProviderUsage('request1',{inputTokens:10,outputTokens:3,cacheReadInputTokens:0,cacheCreationInputTokens:0});await trial.read({query:'q',cwd:'',candidates:records});await trial.read({query:'q',cwd:'',candidates:records});});
  const events=trial.snapshot().reads;expect(events[0].costUsd).toBeCloseTo(.0000042);expect(events[0].finalUsage).toEqual({input:10,output:3,cacheRead:0,cacheWrite:0});expect(events[0].finalAttempts).toBe(1);expect(JSON.parse(trial.export('json')).tasks).toHaveLength(1);expect(trial.aggregate()[0].tasks).toBe(1);
 });
 it('drops stale records and whitelists imported metrics, preserves unreviewed count',async()=>{
  const {dir,trial}=fixture();await trial.read({query:'q',cwd:'',candidates:records});const row=trial.snapshot().reads[0];writeFileSync(join(dir,'memory-jev-metrics.json'),JSON.stringify({schema:1,reads:[{...row,at:1},{...row,id:'12345678-1234-1234-1234-123456789012',secret:'private-content'}]}));const reopened=new JevMemoryTrial(dir,async()=>null);expect(reopened.snapshot().reads).toHaveLength(1);expect(reopened.snapshot().retention).toMatchObject({expiredDropped:1,truncated:true});expect(reopened.export('json')).not.toContain('private-content');expect(reopened.aggregate()[0].unreviewed).toBe(1);expect(reopened.aggregate()[0].feedbackRate).toBe(0);
 });
 it('keeps supplier usage separate after model fallback and missing usage unknown',async()=>{
  const {trial}=fixture();await trial.runTask({taskId:'task',sessionId:'session',model:'model-a',provider:'provider-a'},async()=>{
   trial.observeProviderUsage('request-a',{inputTokens:10,outputTokens:2,cacheReadInputTokens:0});
   trial.identifyTask('model-b','provider-b');trial.observeProviderUsage('request-b');
   await trial.read({query:'q',cwd:'',candidates:records});
  });const event=trial.snapshot().reads[0];expect(event.finalProvider).toBe('provider-b');expect(event.finalUsage.input).toBeNull();expect(event.finalProviderUsage).toEqual([{provider:'provider-a',model:'model-a',usage:{input:10,output:2,cacheRead:0,cacheWrite:null},attempts:1},{provider:'provider-b',model:'model-b',usage:{input:null,output:null,cacheRead:null,cacheWrite:null},attempts:1}]);expect(JSON.parse(trial.export('json')).tasks[0].providerUsage).toEqual(event.finalProviderUsage);
 });
 it('analysis mode filters retained rows without changing the source export',async()=>{
  const {dir,trial}=fixture();await trial.read({query:'q',cwd:'',candidates:records});const file=join(dir,'memory-jev-metrics.json');const row=trial.snapshot().reads[0];const original=JSON.stringify({schema:1,reads:[{...row,at:1},row]});writeFileSync(file,original);const metrics=new JevTrialMetrics(file,false);expect(metrics.snapshot().reads).toHaveLength(1);expect(metrics.aggregate()[0].reads).toBe(1);metrics.export('json');expect(readFileSync(file,'utf8')).toBe(original);
 });
 it('exports incomplete tasks and three levels of opaque request correlation',async()=>{
  const {trial}=fixture();trial.configure({enabled:true},{requestSource:'user'});
  await expect(trial.runTask({taskId:'private-task',sessionId:'private-session',model:'model',provider:'provider'},async()=>{trial.observeProviderUsage('private-provider-request');await trial.read({query:'private-query',cwd:'',candidates:records});throw Error('private-error');})).rejects.toThrow();
  const exported=trial.export('json');const data=JSON.parse(exported);expect(data.tasks).toHaveLength(1);expect(data.tasks[0]).toMatchObject({status:'error',incomplete:true,costUsd:null});expect(data.tasks[0].requests[0].requestRef).toMatch(/^[0-9a-f]{64}$/);expect(data.reads[0].selectorRequestId).toMatch(/^[0-9a-f-]{36}$/);expect(data.reads[0].runId).toBe(data.tasks[0].runId);for(const content of ['private-query','private-task','private-session','private-provider-request','private-error'])expect(exported).not.toContain(content);
  expect(trial.aggregate()[0]).toMatchObject({reads:1,eligibleReads:1,dispatchedReads:1,selectedReads:1,incompleteTasks:1,unreviewedRate:1,knownCostUsd:null});
 });
 it('enforces byte retention and exposes capacity loss before the 90-day horizon',async()=>{
  const {dir,trial}=fixture();await trial.read({query:'q',cwd:'',candidates:records});const row={...trial.snapshot().reads[0],finalRequests:Array.from({length:80},(_,i)=>({requestRef:String(i).padStart(64,'0'),provider:'p'.repeat(90),model:'m'.repeat(90),usage:{input:null,output:null,cacheRead:null,cacheWrite:null}}))};const rows=Array.from({length:Math.ceil(4200000/JSON.stringify(row).length)},()=>row);const file=join(dir,'memory-jev-metrics.json');writeFileSync(file,JSON.stringify({schema:1,reads:rows}));const reopened=new JevMemoryTrial(dir,async()=>null);const data=reopened.snapshot();expect(data.retention.capacityDropped).toBeGreaterThan(0);expect(data.retention.expiredDropped).toBe(0);expect(data.retention.truncated).toBe(true);expect(Buffer.byteLength(readFileSync(file,'utf8'))).toBeLessThanOrEqual(4000000);expect(data.retention.oldestAt).not.toBeNull();
 });
 it('keeps unproven adapter estimates separate from provider-reported unknown usage',async()=>{
  const {trial}=fixture();await trial.runTask({taskId:'task',sessionId:'session',model:'model',provider:'provider'},async()=>{trial.observeProviderUsage('request');trial.observeProviderUsage('request',{inputTokens:100,outputTokens:0},'adapter_normalized');await trial.read({query:'q',cwd:'',candidates:records});});const e=trial.snapshot().reads[0];expect(e.finalUsage).toEqual({input:null,output:null,cacheRead:null,cacheWrite:null});expect(e.finalNormalizedUsage).toEqual({input:100,output:0,cacheRead:null,cacheWrite:null});expect(e.finalUsageSource).toBe('adapter_normalized');expect(e.taskCostUsd).toBeNull();expect(JSON.parse(trial.export('json')).tasks[0].usage.input).toBeNull();
 });
 it('caps chunked response size and rejects extra/missing/invalid answers',async()=>{
  for(const payload of ['x'.repeat(40000),JSON.stringify({answers:{m0:{type:'noul',noul:1},m1:{type:'noul',noul:.2},m2:{type:'choice',noul:.2}}}),JSON.stringify({answers:{m0:{type:'noul',noul:1},m1:{type:'noul',noul:.2},m2:{type:'noul',noul:.2},extra:{type:'noul',noul:1}}})]){const {trial}=fixture(vi.fn(async()=>new Response(payload)));trial.configure({enabled:true},{requestSource:'user'});expect(await trial.read({query:'q',cwd:'',candidates:records})).toEqual(records);expect(trial.snapshot().reads[0].reason).toBe('protocol');}
 });
});

describe('Jev scope and evidence retention',()=>{
 it('retains the complete baseline for validated all-low, including evidence too long to judge',async()=>{
  const {trial}=fixture(vi.fn(async()=>new Response(JSON.stringify({model:'jev-test',answers:{m0:{type:'noul',noul:0},m1:{type:'noul',noul:0}}}))));trial.configure({enabled:true},{requestSource:'user'});const long={...records[2],summary:'long evidence '.repeat(200)};
  expect((await trial.read({query:'q',cwd:'',candidates:[records[0],records[1],long]})).map(r=>r.id)).toEqual(['private-0','private-1','private-2']);expect(trial.snapshot().reads[0].reason).toBe('all_low_probability');
 });
 it('matches Windows drive and UNC case/separators and isolates other roots',async()=>{
  const {trial}=fixture();const scoped=[{...records[0],scope:'project' as const,cwd:'C:\\Projects\\Alpha'},{...records[1],scope:'project' as const,cwd:'D:\\Projects\\Alpha'}];expect((await trial.read({query:'q',cwd:'c:/projects/alpha',candidates:scoped})).map(r=>r.id)).toEqual(['private-0']);expect(await trial.read({query:'q',cwd:'',candidates:scoped})).toEqual([]);
  expect(await trial.read({query:'q',cwd:'//SERVER/share/project',candidates:[{...records[0],scope:'project',cwd:'\\\\server\\SHARE\\Project'}]})).toHaveLength(1);
  expect(await trial.read({query:'q',cwd:'/private/project',candidates:[{...records[0],scope:'project',cwd:'/PRIVATE/project'}]})).toEqual([]);
 });
 it('caps metrics at 2000 and filters time/switch/version without treating absence as satisfaction',async()=>{
  const {dir,trial}=fixture();await trial.read({query:'q',cwd:'',candidates:records});const row=trial.snapshot().reads[0];writeFileSync(join(dir,'memory-jev-metrics.json'),JSON.stringify({schema:1,reads:Array.from({length:2002},(_,i)=>({...row,id:`12345678-1234-1234-1234-${String(i).padStart(12,'0')}`}))}));const reopened=new JevMemoryTrial(dir,async()=>null);expect(reopened.snapshot().reads).toHaveLength(2000);expect(reopened.snapshot().retention).toMatchObject({capacityDropped:2,droppedCount:2,truncated:true});expect(new JevMemoryTrial(dir,async()=>null).snapshot().retention.droppedCount).toBe(2);expect(reopened.aggregate()[0].unreviewed).toBe(2000);const metrics=new JevTrialMetrics(join(dir,'memory-jev-metrics.json'));expect(metrics.aggregate({enabled:true})).toEqual([]);expect(metrics.aggregate({from:Date.now()+86400})).toEqual([]);expect(metrics.aggregate({implementation:'bounded-noul-v2'})).toHaveLength(1);expect(metrics.aggregate({implementation:'other'})).toEqual([]);
 });
});
