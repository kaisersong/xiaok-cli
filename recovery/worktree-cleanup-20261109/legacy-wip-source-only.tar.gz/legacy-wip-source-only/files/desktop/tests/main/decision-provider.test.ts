import { describe, it, expect, vi } from 'vitest';
import { createDecisionProvider, validateDecisionSelection } from '../../../src/ai/decision/registry.js';
import { DecisionError } from '../../../src/ai/decision/types.js';

const key = vi.fn(async () => ({ apiKey: 'synthetic-cloud-key', model: 'jev-test', baseUrl: 'https://api.typesafe.ai' }));
const request = { state: { text: 'synthetic' }, questions: { yes: { type: 'noul' as const, instructions: 'Useful?' }, pick: { type: 'choice' as const, instructions: 'Which?', criteria: { a: 'A', b: 'B' } }, score: { type: 'score' as const, instructions: 'Rate', criteria: ['Low', 'High'] } } };
const raw = { model: 'synthetic-model', answers: { yes: { type: 'noul', noul: .8 }, pick: { type: 'choice', choice: 'a', probabilities: { a: .8, b: .2 }, confidence: .6 }, score: { type: 'score', score: .2, probabilities: { '0': .8, '1': .2 }, confidence: .6 } } };
const local = { provider: 'local-systemone' as const, endpoint: 'http://127.0.0.1:8765/v1/systemone', model: 'clef-fixture' };
describe('typed decision provider production contract', () => {
 it('bounds Laya options and preserves only recognized non-content runtime observations',async()=>{const fetcher=vi.fn(async()=>new Response(JSON.stringify({...raw,runtime:{implementation:'xiaok-local-text-v2',engine:'torch-eager',device:'mps',parameterPrecision:'float32',quantization:'none',versions:{laya:'0.3.28',torch:'2.14.1',transformers:'secret-private-query',unexpected:'private-key'},query:'private-memory-content'}})));const provider=createDecisionProvider({...local,profile:'laya-entropy-v1'},key,fetcher);const result=await provider.evaluate(request);expect(result.metadata.runtime).toEqual({implementation:'xiaok-local-text-v2',engine:'torch-eager',device:'mps',parameterPrecision:'float32',quantization:'none',versions:{laya:'0.3.28',torch:'2.14.1'},peakRssBytes:null,peakGpuAllocatedBytes:null});expect(result.metadata.capabilities.maxChoiceOptions).toBe(20);expect(JSON.stringify(result)).not.toContain('private');fetcher.mockClear();await expect(provider.evaluate({state:'synthetic',questions:{many:{type:'choice',instructions:'Choose',criteria:Object.fromEntries(Array.from({length:21},(_,i)=>['k'+i,'Synthetic']))}}})).rejects.toMatchObject({code:'unsupported_capability'});expect(fetcher).not.toHaveBeenCalled();});
 it('records Laya entropy confidence separately with independent questions and no cloud keys',async()=>{const p={a:.8,b:.2};const entropy=1+Object.values(p).reduce((sum,v)=>sum+v*Math.log(v),0)/Math.log(2);const result=await createDecisionProvider({...local,profile:'laya-entropy-v1',questionIndependence:'independent',templateRevision:'laya-pypi-0.3.28-v1'},key,async()=>new Response(JSON.stringify({...raw,answers:{...raw.answers,pick:{...raw.answers.pick,confidence:entropy},score:{...raw.answers.score,confidence:entropy}},usage:{input_tokens:31,output_tokens:0}}))).evaluate(request);expect(result.answers.pick.confidence).toMatchObject({kind:'entropy-normalized-v1',verified:true});expect(result.metadata).toMatchObject({confidenceProfile:'laya-entropy-v1',questionIndependence:'independent',templateRevision:'laya-pypi-0.3.28-v1'});expect(result.cost).toMatchObject({apiUsd:0,localComputeUsd:null,totalUsd:null});expect(result.usage.reported.cacheRead).toBeNull();});
 it('keeps raw probability, tagged confidence, requested/returned model and unknown usage', async () => {
  const fetcher = vi.fn(async () => new Response(JSON.stringify(raw)));
  const result = await createDecisionProvider({provider:'typesafe-jev'}, key, fetcher).evaluate(request);
  expect(result.answers.pick).toMatchObject({type:'choice',choice:'a',probabilities:{a:.8,b:.2},confidence:{value:.6,kind:'choice-uniform-baseline-v1',source:'reported',verified:true}});
  expect(result.answers.score.confidence.kind).toBe('score-ordered-spread-v1');
  expect(result.answers.yes).toMatchObject({type:'noul',probability:.8,semantic:'noul-yes-probability-v1'});
  expect(result.metadata).toMatchObject({provider:'typesafe-jev',requestedModel:'jev-test',returnedModel:'synthetic-model',schemaVersion:1});
  expect(result.usage.reported.input).toBeNull(); expect(result.cost.apiUsd).toBeNull();
  expect(fetcher.mock.calls[0][1]).toMatchObject({redirect:'error'});
 });
 it('local never resolves or forwards cloud credentials; unknown runtime stays unknown', async () => {
  key.mockClear();const fetcher=vi.fn(async()=>new Response(JSON.stringify(raw)));
  const result=await createDecisionProvider(local,key,fetcher).evaluate(request);
  expect(key).not.toHaveBeenCalled();expect(fetcher.mock.calls[0][1]!.headers).not.toHaveProperty('Authorization');
  expect(result.answers.pick.confidence).toMatchObject({value:.6,kind:'unknown',verified:null});
  expect(result.cost).toMatchObject({apiUsd:0,localComputeUsd:null,totalUsd:null});
  expect(result.metadata.capabilities.modalities).toEqual(['text']);
 });
 it('runtime declaration, not model name, determines confidence semantics', async () => {
  for(const [profile,kind] of [['clef-helper-maxprob-v1','max-probability-v1'],['ollama-entropy-v1','entropy-normalized-v1']] as const){
   const result=await createDecisionProvider({...local,profile,runtimeRevision:'fixture-v1'},key,async()=>new Response(JSON.stringify(raw))).evaluate(request);
   expect(result.answers.pick.confidence.kind).toBe(kind);expect(result.answers.pick.confidence.verified).toBe(false);
   expect(result.metadata.confidenceDeclaration).toBe('user-configured');
  }
 });
 it('rejects non-loopback, credentials, alternate encoding, ports/path/query and redirects before transport',async()=>{
  for(const endpoint of ['http://192.168.1.1:8765/v1/systemone','http://127.0.0.2:8765/v1/systemone','http://2130706433:8765/v1/systemone','http://127.1:8765/v1/systemone','http://user:pass@localhost:8765/v1/systemone','http://localhost:8765/other','http://localhost:8765/v1/systemone?q=x','https://api.typesafe.ai/v1/systemone'])expect(()=>validateDecisionSelection({...local,endpoint})).toThrow(DecisionError);
  const fetcher=vi.fn();await expect(createDecisionProvider({provider:'typesafe-jev'},async()=>({apiKey:'synthetic',model:'m',baseUrl:'http://localhost:8765'}),fetcher).evaluate(request)).rejects.toMatchObject({code:'untrusted_endpoint'});expect(fetcher).not.toHaveBeenCalled();
 });
 it('strictly rejects unsupported modality/questions and invalid distributions',async()=>{
  const fetcher=vi.fn(async()=>new Response(JSON.stringify({...raw,answers:{...raw.answers,pick:{...raw.answers.pick,probabilities:{a:.9,b:.9}}}})));
  const provider=createDecisionProvider(local,key,fetcher);
  await expect(provider.evaluate({...request,modality:'image' as 'text'})).rejects.toMatchObject({code:'unsupported_capability'});expect(fetcher).not.toHaveBeenCalled();
  await expect(provider.evaluate({...request,questions:{bad:{type:'other' as 'noul',instructions:'x'}}})).rejects.toMatchObject({code:'unsupported_capability'});expect(fetcher).not.toHaveBeenCalled();
  await expect(provider.evaluate(request)).rejects.toMatchObject({code:'protocol'});
 });
 it('bounds uncooperative transports by timeout and cancel, reports no private errors',async()=>{
  const provider=createDecisionProvider(local,key,()=>new Promise(()=>{}));
  await expect(provider.evaluate(request,{timeoutMs:10})).rejects.toMatchObject({code:'timeout'});
  const controller=new AbortController();const pending=provider.evaluate(request,{signal:controller.signal});controller.abort();await expect(pending).rejects.toMatchObject({code:'cancelled'});
  await expect(createDecisionProvider(local,key,async()=>{throw Error('private-body-and-key');}).evaluate(request)).rejects.toMatchObject({code:'unavailable',message:'decision_unavailable'});
 });
 it('keeps reported and estimated tokens distinct and preserves missing cache as null',async()=>{
  const result=await createDecisionProvider(local,key,async()=>new Response(JSON.stringify({...raw,usage:{input_tokens:20,output_tokens:0},usage_source:'estimated'}))).evaluate(request);
  expect(result.usage.reported.input).toBeNull();expect(result.usage.estimated).toEqual({input:20,output:0,cacheRead:null,cacheWrite:null});
 });
 it('rejects credentials echoed as model metadata and redirects without returning response bodies',async()=>{
  await expect(createDecisionProvider({provider:'typesafe-jev'},key,async()=>new Response(JSON.stringify({...raw,model:'synthetic-cloud-key'}))).evaluate(request)).rejects.toMatchObject({code:'protocol'});
  const fetcher=vi.fn(async()=>new Response('private-response',{status:302,headers:{Location:'http://192.168.1.1/'}}));
  await expect(createDecisionProvider(local,key,fetcher).evaluate(request)).rejects.toMatchObject({code:'error',message:'decision_error'});expect(fetcher.mock.calls[0][1]).toMatchObject({redirect:'error'});
 });
});
