import { describe, it, expect } from 'vitest';
import { runSyntheticEval } from '../../../scripts/evals/jev-memory-trial/eval.js';
describe('Jev memory trial eval production path',()=>{
 it('replays local contract offline with identical fixtures/final model and explicit unknown compute',async()=>{
  const result=await runSyntheticEval(undefined,{provider:'local-systemone',endpoint:'http://127.0.0.1:8765/v1/systemone',model:'synthetic-local'});expect(result.rows).toHaveLength(30);expect(result.rows.every(r=>r.decisionProvider==='local-systemone' && r.finalModel==='synthetic-final-v1')).toBe(true);expect(result.rows.every(r=>r.localComputeUsd===null)).toBe(true);expect(result.rows.filter(r=>r.arm==='decision' && r.reason==='selected').every(r=>r.selectorCostUsd===0)).toBe(true);
 });
 it('replays frozen synthetic data offline with stable quality and no network',async()=>{
  const a=await runSyntheticEval();const b=await runSyntheticEval();expect(a.freeze).toEqual(b.freeze);expect(a.rows.map(r=>r.quality)).toEqual(b.rows.map(r=>r.quality));expect(a.mode).toBe('offline');expect(a.rows.length).toBeGreaterThan(8);expect(a.rows.every(r=>r.readMs>=0&&r.taskMs>=r.readMs)).toBe(true);expect(a.rows.every(r=>r.usage.cacheRead===null)).toBe(true);expect(a.rows.every(r=>r.costUsd===null)).toBe(true);
 });
});
