import React from 'react';
import {afterEach,beforeEach,describe,expect,it,vi} from 'vitest';
import {cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react';
import {ObservationControls} from '../../renderer/src/components/ObservationControls';
import {ObservationEnableModal} from '../../renderer/src/components/ObservationEnableModal';
import {zh} from '../../renderer/src/locales/zh';
import {en} from '../../renderer/src/locales/en';
const state=vi.hoisted(()=>({locale:'zh',prepare:vi.fn(),preconditions:vi.fn(),status:vi.fn(),stop:vi.fn(),revoke:vi.fn()}));
vi.mock('../../renderer/src/contexts/LocaleContext',()=>({useLocale:()=>({t:state.locale==='zh'?zh:en})}));
vi.mock('../../renderer/src/api',()=>({api:{prepareObservationTask:state.prepare,getObservationPreconditions:state.preconditions,getObservationTaskStatus:state.status,stopObservationTask:state.stop,revokeObservationTask:state.revoke}}));
afterEach(()=>{cleanup();vi.clearAllMocks();state.locale='zh';});
beforeEach(()=>{state.preconditions.mockResolvedValue({platformSupported:true,environmentRegistered:true,providerReady:true});});
const button=(name:string)=>screen.getByRole('button',{name}) as HTMLButtonElement;
describe('Observation controls',()=>{
 it('shows semantic outcomes and reserved budget from main, refreshing on existing task activity',async()=>{
  state.status.mockResolvedValue({mode:'active',semantic:{mode:'mechanism-experiment',state:'waiting',attempts:0,maxAttempts:2,reservedCostUnits:0,maxCostUnits:50000000}});
  const view=render(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task" activityRevision={0}/>);
  await screen.findByText('等待已确认的子任务边界');
  state.status.mockResolvedValue({mode:'active',semantic:{mode:'mechanism-experiment',state:'compacted',attempts:1,maxAttempts:2,reservedCostUnits:1000000,maxCostUnits:50000000}});
  view.rerender(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task" activityRevision={1}/>);
  await screen.findByText('历史已压缩，原始要求和执行事实已保留');
  expect(screen.getByText(/摘要调用 1\/2/)).toBeTruthy();expect(screen.getByText(/按发送前核验价格预留/)).toBeTruthy();
 });
 it.each(['revoked'])('shows accurate %s state',async mode=>{state.status.mockResolvedValue({mode});render(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task"/>);await screen.findByText(mode==='revoked'?'披露授权已撤销；任务正在停止':'披露授权已撤销');expect(screen.queryByText(zh.observation.closed)).toBeNull();});
 it('keeps a plain task silent instead of repeating the not-enabled note',async()=>{
  state.status.mockResolvedValue({mode:'unavailable'});
  const {container}=render(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task"/>);
  await waitFor(()=>expect(state.status).toHaveBeenCalledWith('task'));
  await waitFor(()=>{});
  expect(container.textContent).not.toContain('观测记忆策略');
  expect(container.textContent).not.toContain('此任务未启用观测记忆');
 });
 it('shows the policy name when the observation task is active',async()=>{
  state.status.mockResolvedValue({mode:'active',policyScope:{directoryName:'src',fileCount:3,commandCount:0}});
  const view=render(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task"/>);
  await screen.findByText('观测记忆策略：src');
  state.status.mockResolvedValue({mode:'active',policyScope:{fileCount:3,commandCount:0}});
  view.rerender(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task" activityRevision={1}/>);
  await screen.findByText('观测记忆策略：3 个文件');
  state.status.mockResolvedValue({mode:'active',policyScope:{fileCount:0,commandCount:2}});
  view.rerender(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task" activityRevision={2}/>);
  await screen.findByText('观测记忆策略：2 条命令');
 });
 it('hides the enable entry while the model or environment is not ready',async()=>{
  state.preconditions.mockResolvedValue({platformSupported:true,environmentRegistered:true,providerReady:false,providerReason:'DESTINATION_NOT_READY'});
  render(<ObservationControls draftId={null} onDraft={()=>{}} running={false}/>);
  await waitFor(()=>expect(state.preconditions).toHaveBeenCalled());
  expect(screen.queryByRole('button',{name:zh.observation.enable})).toBeNull();
 });
 it.each(['zh','en'])('explains the flow in %s and only returns a native-approved builder draft',async locale=>{
  state.locale=locale;state.prepare.mockResolvedValue({draftId:'approved',model:'deepseek-flash'});const onDraft=vi.fn();
  const labels=(locale==='zh'?zh:en);
  render(<ObservationControls draftId={null} onDraft={onDraft} running={false}/>);
  fireEvent.click(await screen.findByRole('button',{name:labels.observation.enable}));
  expect(await screen.findByText(labels.observation.observationModal.intro)).toBeTruthy();
  await waitFor(()=>expect(button(labels.observation.observationModal.pickButton).disabled).toBe(false));
  fireEvent.click(screen.getByRole('button',{name:labels.observation.observationModal.pickButton}));
  await waitFor(()=>expect(state.prepare).toHaveBeenCalledWith('builder'));
  await waitFor(()=>expect(onDraft).toHaveBeenCalledWith('approved'));
  expect(screen.queryByText(labels.observation.observationModal.intro)).toBeNull();
 });
 it('imports a policy file as the advanced path',async()=>{
  state.prepare.mockResolvedValue(null);const onDraft=vi.fn();
  render(<ObservationControls draftId={null} onDraft={onDraft} running={false}/>);
  fireEvent.click(await screen.findByRole('button',{name:zh.observation.enable}));
  fireEvent.click(await screen.findByRole('button',{name:zh.observation.observationModal.importButton}));
  await waitFor(()=>expect(state.prepare).toHaveBeenCalledWith('file'));
  await waitFor(()=>expect(onDraft).not.toHaveBeenCalled());
  expect(screen.queryByText(zh.observation.observationModal.intro)).toBeNull();
 });
 it('keeps the modal checklist as a second gate when preconditions turn blocked after entry',async()=>{
  state.preconditions.mockResolvedValue({platformSupported:false,environmentRegistered:false,providerReady:false,providerReason:'NO_DEFAULT_MODEL'});
  render(<ObservationEnableModal onDraft={()=>{}} onClose={()=>{}}/>);
  expect(await screen.findByText(`✗ ${zh.observation.observationModal.preconditionPlatformBlocked}`)).toBeTruthy();
  expect(screen.getByText(`✗ ${zh.observation.observationModal.preconditionEnvironmentBlocked}`)).toBeTruthy();
  expect(screen.getByText(`✗ ${zh.observation.observationModal.preconditionProviderNoModel}`)).toBeTruthy();
  expect(screen.queryByRole('button',{name:zh.observation.observationModal.pickButton})).toBeNull();
  expect(screen.queryByRole('button',{name:zh.observation.observationModal.importButton})).toBeNull();
  expect(state.prepare).not.toHaveBeenCalled();
 });
 it('maps policy failures to readable text and keeps the dialog open',async()=>{
  state.prepare.mockRejectedValue(new Error('SOL_PI_PRODUCT_TOO_MANY_SOURCES'));
  render(<ObservationControls draftId={null} onDraft={()=>{}} running={false}/>);
  fireEvent.click(await screen.findByRole('button',{name:zh.observation.enable}));
  fireEvent.click(await screen.findByRole('button',{name:zh.observation.observationModal.pickButton}));
  expect(await screen.findByText(zh.observation.observationModal.errorTooManySources)).toBeTruthy();
  expect(screen.getByText(zh.observation.observationModal.intro)).toBeTruthy();
 });
 it('stop and revoke remain separate controls, and errors do not pretend success',async()=>{
  state.status.mockResolvedValue({mode:'active'});state.stop.mockResolvedValue({mode:'recall-only'});state.revoke.mockRejectedValue(new Error('no authority'));
  render(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task"/>);
  fireEvent.click(await screen.findByRole('button',{name:zh.observation.stop}));await screen.findByText(zh.observation.recallOnly);
  fireEvent.click(screen.getByRole('button',{name:zh.observation.revoke}));await screen.findByRole('alert');
  expect(state.stop).toHaveBeenCalledWith('task');expect(state.revoke).toHaveBeenCalledWith('task');expect(screen.getByText(zh.observation.recallOnly)).toBeTruthy();
 });
});

it.each(['zh','en'])('separates durable edit and validation facts and shows unknown execution in %s',async locale=>{
 state.locale=locale;state.status.mockResolvedValue({mode:'active',compound:{mode:'mechanism-experiment',edit:'succeeded',validation:'unknown',pendingOperations:0,unknownOperations:1,completedOperations:0}});
 render(<ObservationControls draftId={null} onDraft={()=>{}} running taskId="task"/>);
 await screen.findByText(locale==='zh'?'编辑：已成功':'Edit: Succeeded');
 expect(screen.getByText(locale==='zh'?'验证：结果未知':'Validation: Outcome unknown')).toBeTruthy();
 expect(screen.getByText(locale==='zh'?'有 1 项操作结果未知，需要确认执行状态。':'1 operation(s) have an unknown outcome and require execution confirmation.')).toBeTruthy();
});
