import {render,screen,fireEvent,waitFor,cleanup} from '@testing-library/react';
import {afterEach,describe,it,expect,vi} from 'vitest';
import {LocaleProvider} from '../../renderer/src/contexts/LocaleContext';
import {MemorySettingsPane} from '../../renderer/src/components/settings/MemorySettingsPane';
vi.mock('../../renderer/src/components/settings/MemoryModelSettings',()=>({MemoryModelSettings:()=> <div>synthetic memory model config</div>}));
vi.mock('../../renderer/src/components/settings/LocalMemoryStatsCard',()=>({LocalMemoryStatsCard:()=> <input aria-label="synthetic content search"/>}));
vi.mock('../../renderer/src/components/settings/MemoryCompactionSettings',()=>({MemoryCompactionSettings:()=> <div>synthetic compression config</div>}));
vi.mock('../../renderer/src/components/settings/JevMemorySettings',()=>({JevMemorySettings:()=> <div>synthetic decision config</div>}));
afterEach(()=>cleanup());
describe('memory content/configuration tabs',()=>{
 it('supports arrow and home/end keyboard navigation with matching focus',async()=>{render(<LocaleProvider><MemorySettingsPane/></LocaleProvider>);const content=screen.getByRole('tab',{name:'记忆内容'}),configuration=screen.getByRole('tab',{name:'记忆配置'});fireEvent.keyDown(content,{key:'ArrowRight'});expect(configuration).toHaveFocus();expect(configuration).toHaveAttribute('aria-selected','true');fireEvent.keyDown(configuration,{key:'Home'});expect(content).toHaveFocus();expect(content).toHaveAttribute('aria-selected','true');fireEvent.keyDown(content,{key:'End'});expect(configuration).toHaveFocus();});
 it('defaults to content, isolates configuration and retains content input across switching',async()=>{render(<LocaleProvider><MemorySettingsPane/></LocaleProvider>);const content=await screen.findByRole('tab',{name:'记忆内容'});expect(content).toHaveAttribute('aria-selected','true');expect(screen.getByRole('textbox',{name:'synthetic content search'})).toBeVisible();expect(screen.queryByText('synthetic decision config')).not.toBeVisible();fireEvent.change(screen.getByRole('textbox'),{target:{value:'synthetic retained'}});fireEvent.click(screen.getByRole('tab',{name:'记忆配置'}));await waitFor(()=>expect(screen.getByText('synthetic decision config')).toBeVisible());expect(screen.getByText('synthetic compression config')).toBeVisible();expect(screen.queryByRole('textbox')).toBeNull();fireEvent.click(content);expect(screen.getByRole('textbox')).toHaveValue('synthetic retained');expect(screen.getAllByRole('tabpanel')).toHaveLength(1);});
});
