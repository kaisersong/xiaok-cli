import { render, screen, fireEvent, waitFor, cleanup, within, act } from '@testing-library/react';
import { afterEach, describe, it, expect, vi } from 'vitest';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';
import { LocalMemoryStatsCard } from '../../renderer/src/components/settings/LocalMemoryStatsCard';
const memory = vi.hoisted(() => ({
  stats: vi.fn(async () => ({ l0: 1, l1: 0, l2: 0, l3: 0, dbSizeBytes: 0 })),
  listLayer: vi.fn(async () => []),
  getSettings: vi.fn(async () => ({ resolvedCompactionModelId: 'synthetic-model', warning: null })),
  compact: vi.fn(), cancelCompaction: vi.fn(async () => true),
}));
vi.mock('../../renderer/src/shared/desktop', () => ({ getDesktopApi: () => ({ memory }) }));
afterEach(() => { cleanup(); vi.clearAllMocks(); });
describe('manual compaction result and disclosure', () => {
  it('asks before inference, reports failure accurately and never displays successful completion', async () => {
    memory.compact.mockResolvedValue({ status: 'failed', reason: 'missing_credentials', processed: 0, extracted: 0, scenarios: 0, traits: 0 });
    render(<LocaleProvider><LocalMemoryStatsCard /></LocaleProvider>);
    fireEvent.click(await screen.findByRole('button', { name: '压缩' }));
    const dialog = await screen.findByRole('presentation');
    expect(within(dialog).getByText(/synthetic-model/)).toHaveTextContent('发送');
    expect(memory.compact).not.toHaveBeenCalled();
    fireEvent.click(within(dialog).getByRole('button', { name: '压缩' }));
    await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent('失败'));
    expect(screen.getByRole('status')).toHaveTextContent('缺少模型凭据');
    expect(screen.queryByText('完成')).toBeNull();
  });
  it('exposes cancellation during execution and reports the returned cancellation', async () => {
    let resolve!: (value: unknown) => void;
    memory.compact.mockImplementation(() => new Promise(r => { resolve = r; }));
    render(<LocaleProvider><LocalMemoryStatsCard /></LocaleProvider>);
    fireEvent.click(await screen.findByRole('button', { name: '压缩' }));
    fireEvent.click(within(await screen.findByRole('presentation')).getByRole('button', { name: '压缩' }));
    fireEvent.click(await screen.findByRole('button', { name: '取消' }));
    expect(memory.cancelCompaction).toHaveBeenCalledOnce();
    await act(async () => resolve({ status: 'cancelled', processed: 0, extracted: 0, scenarios: 0, traits: 0 }));
    expect(screen.getByRole('status')).toHaveTextContent('已取消');
  });
});
