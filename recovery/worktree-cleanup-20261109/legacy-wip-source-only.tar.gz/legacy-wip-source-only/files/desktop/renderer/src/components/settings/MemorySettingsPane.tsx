import {useState} from 'react'
import {useLocale} from '../../contexts/LocaleContext'
import {LocalMemoryStatsCard} from './LocalMemoryStatsCard'
import {JevMemorySettings} from './JevMemorySettings'
import {MemoryCompactionSettings} from './MemoryCompactionSettings'
import {MemoryModelSettings} from './MemoryModelSettings'

export function MemorySettingsPane(){
 const {t}=useLocale();const ds=t.desktopSettings
 const [active,setActive]=useState<'content'|'configuration'>('content')
 return <>
  <div role="tablist" aria-label={ds.memoryPaneTitle} className="mb-5 flex gap-1 border-b border-[var(--c-border-subtle)]">
   {(['content','configuration'] as const).map(tab=><button key={tab} id={`memory-tab-${tab}`} type="button" role="tab" aria-selected={active===tab} aria-controls={`memory-panel-${tab}`} tabIndex={active===tab?0:-1}
    onClick={()=>setActive(tab)} onKeyDown={event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?'content':event.key==='End'?'configuration':active==='content'?'configuration':'content';setActive(next);document.getElementById(`memory-tab-${next}`)?.focus()}}}
    className={`px-4 py-2 text-sm border-b-2 ${active===tab?'border-[var(--c-accent)] text-[var(--c-text-heading)]':'border-transparent text-[var(--c-text-muted)]'}`}>
    {tab==='content'?ds.memoryContentTab:ds.memoryConfigurationTab}
   </button>)}
  </div>
  <div role="tabpanel" id="memory-panel-content" aria-labelledby="memory-tab-content" hidden={active!=='content'}><LocalMemoryStatsCard/></div>
  <div role="tabpanel" id="memory-panel-configuration" aria-labelledby="memory-tab-configuration" hidden={active!=='configuration'}>
   <div className="flex flex-col gap-6"><JevMemorySettings active={active==='configuration'}/><MemoryCompactionSettings active={active==='configuration'}/><MemoryModelSettings active={active==='configuration'}/></div>
  </div>
 </>
}
