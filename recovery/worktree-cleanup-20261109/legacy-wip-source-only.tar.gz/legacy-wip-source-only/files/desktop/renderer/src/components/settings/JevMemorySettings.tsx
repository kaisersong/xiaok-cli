import { useState, useEffect, useCallback, useRef } from 'react'
import { api } from '../../api/bridge'
import { useLocale } from '../../contexts/LocaleContext'
import type { JevTrialSettings, DecisionSelection, DecisionModelView, TrialReadEvent, TrialAggregate, TrialRetention } from '../../api/types'
import { LocalDecisionModels } from './LocalDecisionModels'
import { modelConfigurationCardClass } from './ModelConfigurationCard'
import { settingsInputCls } from './_settingsClasses'
import { secondaryButtonSmCls, secondaryButtonBorderStyle } from '../buttonStyles'

type LocalSelection = Extract<DecisionSelection, { provider: 'local-systemone' }>
const customDefault: LocalSelection = { provider: 'local-systemone', endpoint: 'http://127.0.0.1:11434/v1/systemone', model: 'clef-flash', profile: 'systemone-unknown' }

export function JevMemorySettings({active=true}:{active?:boolean}={}) {
 const { t } = useLocale()
 const ds = t.desktopSettings
 const fieldCls = settingsInputCls('sm')
 const [settings, setSettings] = useState<JevTrialSettings | null>(null)
 const [models, setModels] = useState<DecisionModelView[]>([])
 const [draft, setDraft] = useState<LocalSelection>(customDefault)
 const [reads, setReads] = useState<TrialReadEvent[]>([])
 const [groups, setGroups] = useState<TrialAggregate[]>([])
 const [retention, setRetention] = useState<TrialRetention | null>(null)
 const [diagnostics, setDiagnostics] = useState(false)
 const [busy, setBusy] = useState(false)
 const [error, setError] = useState(false)
 const busyRef = useRef(false)
 const configVersion = useRef(0)
 const modelVersion = useRef(0)
 const metricsVersion = useRef(0)
 const applySettings = useCallback((config: JevTrialSettings) => {
  setSettings(config)
  if (config.decision?.provider === 'local-systemone' && !config.decision.managedModelId) setDraft(config.decision)
 }, [])
 const refreshSettings = useCallback(async () => {
  const version = ++configVersion.current
  const config = await api.memoryJevGetSettings()
  if (version === configVersion.current) applySettings(config)
 }, [applySettings])
 const refreshModels = useCallback(async () => {
  const version = ++modelVersion.current
  const data = await api.decisionModelsList()
  if (version === modelVersion.current) setModels(data)
 }, [])
 const refreshMetrics = useCallback(async () => {
  const version = ++metricsVersion.current
  const data = await api.memoryJevSnapshot()
  if (version !== metricsVersion.current) return
  setReads(data.reads); setGroups(data.aggregate); setRetention(data.retention ?? null)
 }, [])
 const refresh = async () => { await Promise.all([refreshSettings(), refreshModels(), ...(diagnostics ? [refreshMetrics()] : [])]) }
 useEffect(() => {
  void Promise.all([refreshSettings(), refreshModels()]).catch(() => setError(true))
  const unsubscribe = api.onDecisionModelsChanged(data => { ++modelVersion.current; setModels(data) })
  return () => { ++configVersion.current; ++modelVersion.current; ++metricsVersion.current; unsubscribe() }
 }, [refreshSettings, refreshModels])
 // Ref, rather than render state alone, also excludes duplicate clicks in one event turn.
 const action = async (fn: () => Promise<unknown>, interrupt = false) => {
  if (busyRef.current && !interrupt) return
  if (!interrupt) { busyRef.current = true; setBusy(true) }
  ++configVersion.current; ++modelVersion.current; setError(false)
  try { await fn(); await refresh() } catch { setError(true) }
  finally { if (!interrupt) { busyRef.current = false; setBusy(false) } }
 }
 const configure = async (patch: Parameters<typeof api.memoryJevConfigure>[0]) => { applySettings(await api.memoryJevConfigure(patch)) }
 const current = settings?.decision
 const selected = current?.provider === 'local-systemone' ? current.managedModelId ?? 'custom' : 'typesafe-jev'
 const modelName = (id: string) => id === 'clef-flash-mlx-4bit' ? ds.decisionModelsClef : id === 'laya-multilingual' ? ds.decisionModelsLaya : id
 const selectedModel = models.find(m => m.id === selected)
 const switching = busy || models.some(m => ['checking', 'loading'].includes(m.state))
 const choose = (id: string) => {
  if (selected === id || !settings) return
  void action(async () => {
   if (id === 'typesafe-jev') await configure({decision:{provider:'typesafe-jev'}})
   else if (id === 'custom') await configure({decision:draft})
   else applySettings(await api.decisionModelsUse(id))
  })
 }
 const download = async (format: 'json' | 'csv') => {
  const text = await api.memoryJevExport(format)
  const url = URL.createObjectURL(new Blob([text], { type: format === 'json' ? 'application/json' : 'text/csv;charset=utf-8' }))
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = `memory-jev-metrics.${format}`; anchor.click(); URL.revokeObjectURL(url)
 }
 const button = (label: string, fn: () => Promise<unknown>) => <button type="button" disabled={busy} className={secondaryButtonSmCls} style={secondaryButtonBorderStyle} onClick={() => void action(fn)}>{label}</button>
 const radio = (id: string, label: string, unavailable = false, note?: string) => <label key={id} className={`flex items-start gap-3 ${modelConfigurationCardClass(selected===id)}`}>
  <input className="mt-0.5" type="radio" name="memory-decision-model" aria-label={label} value={id} checked={selected === id} disabled={switching || !settings || unavailable} onChange={() => choose(id)} />
  <span className="flex min-w-0 flex-col gap-1"><span className="text-sm">{label}</span>{note && <span className="text-xs text-[var(--c-text-muted)]">{note}</span>}</span>
 </label>
 return <>
 <section className="rounded-xl border border-[var(--c-border-subtle)] bg-[var(--c-bg-menu)] p-4 flex flex-col gap-3">
  <h4 className="text-sm font-semibold text-[var(--c-text-heading)]">{ds.memoryJevTitle}</h4>
  <p className="text-xs text-[var(--c-text-secondary)]">{ds.memoryDecisionSelectionNote}</p>
  <div role="radiogroup" aria-label={ds.memoryDecisionProvider} className="grid gap-2 sm:grid-cols-2">
   {radio('typesafe-jev', ds.memoryDecisionCloud)}
   {['clef-flash-mlx-4bit', 'laya-multilingual'].map(id => { const model = models.find(m => m.id === id); return radio(id, modelName(id), model?.state !== 'ready', model ? ds.decisionModelState(model.state) : ds.decisionModelState('not_installed')) })}
   {radio('custom', ds.memoryDecisionCustom)}
  </div>
  <p role="status" className="text-xs text-[var(--c-text-secondary)]">{ds.memoryDecisionActive(selected === 'typesafe-jev' ? ds.memoryDecisionCloud : selected === 'custom' ? ds.memoryDecisionCustom : modelName(selected))}</p>
  {current?.provider === 'local-systemone' && current.managedModelId && selectedModel?.state !== 'ready' && <p className="text-xs text-amber-600">{ds.memoryDecisionNeedsLoad}</p>}
  {selected === 'custom' && <>
   <p className="text-xs text-[var(--c-text-secondary)]">{ds.memoryDecisionLocalNote}</p>
   <label className="flex flex-col gap-1 text-xs">{ds.memoryDecisionEndpoint}<input className={fieldCls} aria-label={ds.memoryDecisionEndpoint} value={draft.endpoint} disabled={busy} onChange={e => setDraft({...draft,endpoint:e.target.value})} /></label>
   <label className="flex flex-col gap-1 text-xs">{ds.memoryDecisionModel}<input className={fieldCls} aria-label={ds.memoryDecisionModel} value={draft.model} disabled={busy} onChange={e => setDraft({...draft,model:e.target.value})} /></label>
   <label className="flex flex-col gap-1 text-xs">{ds.memoryDecisionProfile}<select className={fieldCls} aria-label={ds.memoryDecisionProfile} value={draft.profile ?? 'systemone-unknown'} disabled={busy} onChange={e => setDraft({...draft,profile:e.target.value as LocalSelection['profile']})}>
    <option value="systemone-unknown">{ds.memoryDecisionUnknownProfile}</option><option value="clef-helper-maxprob-v1">{ds.memoryDecisionHelperProfile}</option><option value="ollama-entropy-v1">{ds.memoryDecisionOllamaProfile}</option><option value="laya-entropy-v1">{ds.memoryDecisionLayaProfile}</option>
   </select></label>
   <label className="flex flex-col gap-1 text-xs">{ds.memoryDecisionRevision}<input className={fieldCls} aria-label={ds.memoryDecisionRevision} value={draft.runtimeRevision ?? ''} disabled={busy} onChange={e => { const next={...draft}; if (e.target.value) next.runtimeRevision=e.target.value; else delete next.runtimeRevision; setDraft(next) }} /></label>
   {button(ds.memoryDecisionSave, () => configure({decision:draft}))}
  </>}
  <p className="text-xs text-[var(--c-text-secondary)]">{selected === 'typesafe-jev' ? ds.memoryJevDisclosure : ds.memoryDecisionLocalDisclosure}</p>
  <label className="flex items-center gap-2 text-sm"><input type="checkbox" aria-label={ds.memoryJevEnable} checked={settings?.enabled ?? false} disabled={busy || !settings} onChange={e => { const enabled=e.target.checked; void action(() => configure({enabled})) }} />{ds.memoryJevEnable}</label>
  {error && <p role="alert" className="text-sm text-red-500">{ds.memoryDecisionActionError}</p>}
 </section>
 <LocalDecisionModels models={models} busy={busy} selectedId={selected} active={active} onAction={action} />
 <details className="rounded-xl border border-[var(--c-border-subtle)] bg-[var(--c-bg-menu)] p-4" open={diagnostics} onToggle={e => { const open=e.currentTarget.open; setDiagnostics(open); if (open) void refreshMetrics().catch(() => setError(true)) }}>
  <summary className="cursor-pointer text-sm font-medium">{ds.memoryDecisionDiagnostics}</summary>
  {diagnostics && <div className="mt-3 flex flex-col gap-3">
   <p className="text-xs text-[var(--c-text-muted)]">{ds.memoryJevMetricsNote}</p>
   {retention && <p className="text-xs text-[var(--c-text-muted)]">{ds.memoryJevRetention(retention.oldestAt === null ? ds.memoryJevUnknown : new Date(retention.oldestAt).toLocaleString(), retention.newestAt === null ? ds.memoryJevUnknown : new Date(retention.newestAt).toLocaleString(), retention.droppedCount, retention.truncated)}</p>}
   <div className="flex flex-wrap gap-2">{button(ds.memoryJevRefresh, refresh)}{button(ds.memoryJevExportJson, () => download('json'))}{button(ds.memoryJevExportCsv, () => download('csv'))}{button(ds.memoryJevClear, async () => { if (window.confirm(ds.memoryJevClearConfirm)) await api.memoryJevClear() })}</div>
   <p className="text-xs text-[var(--c-text-secondary)]">{ds.memoryJevSummary}</p>
   {groups.length === 0 ? <p className="text-xs text-[var(--c-text-muted)]">{ds.memoryJevEmpty}</p> : groups.map((g, i) => <div className="text-xs" key={i}>{g.day} · {g.group === 'baseline' ? ds.memoryJevBaseline : ds.memoryJevExperiment} · {g.provider} · {g.model ?? ds.memoryJevUnknown} · {g.reads} / {g.tasks} / {g.fallback} / {g.unreviewed} / {g.unknownCost} · {ds.memoryJevUnreviewed(Math.round(g.unreviewedRate * 100))}</div>)}
   {reads.length > 0 && <><p className="text-xs">{ds.memoryJevRecent}</p><p className="text-xs text-[var(--c-text-muted)]">{ds.memoryJevFeedbackNote}</p>{reads.slice(-10).reverse().map(r => <div key={r.id} className="flex flex-wrap items-center gap-2 text-xs"><span>{new Date(r.at).toLocaleString()} · {r.keptCount}/{r.eligibleCount} · {ds.memoryJevReason(r.reason)}</span>{button(ds.memoryJevHelpful, () => api.memoryJevFeedback(r.id, 'helpful'))}{button(ds.memoryJevCorrection, () => api.memoryJevFeedback(r.id, 'correction'))}{r.feedback && <span>{r.feedback === 'helpful' ? ds.memoryJevHelpful : ds.memoryJevCorrection}</span>}</div>)}</>}
  </div>}
 </details>
 </>
}
