import {useEffect,useState} from 'react';
import {api} from '../api';
import {useLocale} from '../contexts/LocaleContext';

type Preconditions={platformSupported:boolean;environmentRegistered:boolean;providerReady:boolean;providerReason?:string};

const EXAMPLE_POLICY=JSON.stringify({
  version:1,
  environmentId:'deepseek-recipe-0.1.1',
  model:'deepseek-flash',
  destination:{provider:'deepseek',url:'https://api.deepseek.com/v1/chat/completions'},
  localPersistence:true,
  allowUnclassifiedText:true,
  allowModelDisclosure:true,
  allowIncomplete:false,
  expiresAt:'<Date.now()+7d 之前的毫秒时间戳>',
  readFileScopes:[{filePath:'/absolute/path/to/file.ts',startLine:1}],
  bashSources:[],
},null,2);

/** 只读授权码到用户文案的映射；未知码回退到 observation.failed。 */
const reasonKeys={
  INVALID_READ_SCOPE:'errorInvalidReadScope',INVALID_BASH_SCOPE:'errorInvalidBashScope',
  INVALID_POLICY:'errorInvalidPolicy',DUPLICATE_KEY:'errorInvalidPolicy',UNSAFE_FILE:'errorUnsafeFile',
  CONSENT_OR_EXPIRY_NOT_READY:'errorConsentOrExpiry',DESTINATION_NOT_READY:'errorDestinationNotReady',
  MODEL_NOT_READY:'errorModelNotReady',NO_DEFAULT_MODEL:'errorModelNotReady',
  TOO_MANY_SOURCES:'errorTooManySources',NO_USABLE_SOURCES:'errorNoUsableSources',
} as const;

export function ObservationEnableModal({onDraft,onClose}:{onDraft:(draftId:string)=>void;onClose:()=>void}) {
  const {t}=useLocale();
  const m=t.observation.observationModal;
  const [preconditions,setPreconditions]=useState<Preconditions>();
  const [loadFailed,setLoadFailed]=useState(false);
  const [busy,setBusy]=useState(false);
  const [errorText,setErrorText]=useState<string|null>(null);
  const [helpOpen,setHelpOpen]=useState(false);
  useEffect(()=>{let live=true;api.getObservationPreconditions().then(result=>{if(live)setPreconditions(result);}).catch(()=>{if(live)setLoadFailed(true);});return()=>{live=false;};},[]);
  const ready=preconditions&&preconditions.platformSupported&&preconditions.environmentRegistered&&preconditions.providerReady;
  const run=async(source:'file'|'builder')=>{
    setBusy(true);setErrorText(null);
    try{const draft=await api.prepareObservationTask(source);if(draft){onDraft(draft.draftId);onClose();}else onClose();}
    catch(error){const code=String((error as Error)?.message??'').replace(/^SOL_PI_PRODUCT_/,'');const key=(reasonKeys as Record<string,string|undefined>)[code];setErrorText(key?(m as unknown as Record<string,string>)[key]:t.observation.failed);}
    finally{setBusy(false);}
  };
  const checkRow=(ok:boolean|undefined,okText:string,blockedText:string)=>{
    if(ok===undefined)return <p className="text-muted-foreground">· {m.checking}</p>;
    return ok?<p className="text-foreground">{`✓ ${okText}`}</p>:<p role="status" className="text-destructive">{`✗ ${blockedText}`}</p>;
  };
  const providerBlocked=preconditions&&!preconditions.providerReady
    ?(preconditions.providerReason==='NO_DEFAULT_MODEL'?m.preconditionProviderNoModel:m.preconditionProviderDestination):m.preconditionProvider;
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" role="dialog" aria-label={m.title} onClick={e=>{if(e.target===e.currentTarget&&!busy)onClose();}}>
    <div className="max-w-lg w-full mx-4 rounded-lg border bg-background p-4 text-sm shadow-lg max-h-[85vh] overflow-y-auto">
      <div className="flex items-start justify-between gap-2">
        <h2 className="text-base font-medium">{m.title}</h2>
        <button type="button" className="text-xs text-muted-foreground underline" disabled={busy} onClick={onClose}>{m.close}</button>
      </div>
      <p className="mt-2 text-muted-foreground">{m.intro}</p>
      <h3 className="mt-3 font-medium">{m.preconditionsHeading}</h3>
      <div className="mt-1 space-y-0.5 text-xs">
        {checkRow(preconditions?.platformSupported,m.preconditionPlatform,m.preconditionPlatformBlocked)}
        {checkRow(preconditions?.environmentRegistered,m.preconditionEnvironment,m.preconditionEnvironmentBlocked)}
        {checkRow(preconditions?.providerReady,m.preconditionProvider,providerBlocked)}
        {loadFailed&&<p role="alert" className="text-destructive">{t.observation.failed}</p>}
      </div>
      {ready&&<div className="mt-3 space-y-2">
        <button type="button" className="w-full rounded-md border px-3 py-2 text-left hover:bg-muted disabled:opacity-50" disabled={busy} onClick={()=>void run('builder')}>{m.pickButton}</button>
        <p className="-mt-1 text-xs text-muted-foreground">{m.pickHint}</p>
        <button type="button" className="w-full rounded-md border px-3 py-2 text-left hover:bg-muted disabled:opacity-50" disabled={busy} onClick={()=>void run('file')}>{m.importButton}</button>
      </div>}
      {errorText&&<p role="alert" className="mt-3 text-xs text-destructive">{errorText}</p>}
      <div className="mt-3 border-t pt-2">
        <button type="button" className="text-xs text-muted-foreground underline" onClick={()=>setHelpOpen(value=>!value)}>{m.helpToggle}</button>
        {helpOpen&&<div className="mt-2 space-y-2 text-xs text-muted-foreground">
          <p>{m.helpData}</p>
          <p className="font-medium text-foreground">{m.helpFormatHeading}</p>
          <p>{m.helpFields}</p>
          <p className="font-medium text-foreground">{m.helpExampleHeading}</p>
          <pre className="max-h-40 overflow-auto rounded bg-muted p-2 text-[11px] select-text">{EXAMPLE_POLICY}</pre>
          <p>{m.helpCli}</p>
        </div>}
      </div>
    </div>
  </div>;
}
