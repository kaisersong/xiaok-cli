import {useEffect,useState} from 'react';
import {api} from '../api';
import {useLocale} from '../contexts/LocaleContext';
import {ObservationEnableModal} from './ObservationEnableModal';
import type {CompoundExecutionStatus} from '../../../../src/runtime/sol-pi/compound-status';
import type {SemanticCompactionStatus} from '../../../../src/runtime/sol-pi/semantic-status';
type PolicyScope={directoryName?:string;fileCount:number;commandCount:number};
export function ObservationControls({draftId,onDraft,taskId,running,activityRevision=0}:{draftId:string|null;onDraft:(id:string|null)=>void;taskId?:string;running:boolean;activityRevision?:number}) {
 const {t}=useLocale();const [busy,setBusy]=useState(false),[mode,setMode]=useState(''),[failed,setFailed]=useState(false);
 const [enableOpen,setEnableOpen]=useState(false),[entryReady,setEntryReady]=useState(false);
 const [policyScope,setPolicyScope]=useState<PolicyScope>();
 const [semantic,setSemantic]=useState<SemanticCompactionStatus>();
 const [compound,setCompound]=useState<CompoundExecutionStatus>();
 useEffect(()=>{setMode('');setSemantic(undefined);setCompound(undefined);setPolicyScope(undefined);},[taskId]);
 // Reuse task activity notifications; renderer owns no background polling loop.
 useEffect(()=>{let live=true;if(taskId)void api.getObservationTaskStatus(taskId).then(result=>{if(live){setMode(result.mode);setSemantic(result.semantic);setCompound(result.compound);setPolicyScope(result.policyScope);}}).catch(()=>{});return()=>{live=false;};},[taskId,running,activityRevision]);
 // Entry visibility follows the model/environment preconditions; no text is shown while unknown or not ready.
 useEffect(()=>{let live=true;if(!running&&!draftId)void api.getObservationPreconditions().then(result=>{if(live)setEntryReady(result.platformSupported&&result.environmentRegistered&&result.providerReady);}).catch(()=>{if(live)setEntryReady(false);});else setEntryReady(false);return()=>{live=false;};},[running,draftId,taskId]);
 const act=async(operation:()=>Promise<void>)=>{setBusy(true);setFailed(false);try{await operation();}catch{setFailed(true);}finally{setBusy(false);}};
 const policyLine=!policyScope?null
  :policyScope.directoryName?t.observation.policyNamed(policyScope.directoryName)
  :policyScope.fileCount>0?t.observation.policyFileCount(policyScope.fileCount)
  :t.observation.policyCommandCount(policyScope.commandCount);
 return <div className="px-4 py-2 text-xs text-muted-foreground" aria-live="polite">
  {entryReady&&!running&&!draftId&&<button type="button" disabled={busy} className="underline" onClick={()=>setEnableOpen(true)}>{t.observation.enable}</button>}
  {enableOpen&&!draftId&&<ObservationEnableModal onDraft={onDraft} onClose={()=>setEnableOpen(false)}/>}
  {draftId&&<><span>{t.observation.ready}</span>{' '}<button type="button" disabled={busy} className="underline" onClick={()=>onDraft(null)}>{t.observation.cancel}</button></>}
  {mode==='active'&&policyLine&&<span>{policyLine}</span>}
  {mode==='recall-only'&&<span>{t.observation.recallOnly}</span>}
  {(mode==='closed'||mode==='restore-blocked')&&<span>{t.observation.closed}</span>}
  {mode==='revoked'&&<span>{running?t.observation.revokedStopping:t.observation.revoked}</span>}
  {compound&&<div className="mt-1">
   <p>{t.observation.compoundExperiment}</p>
   <span>{t.observation.compoundEdit(t.observation.compoundStep[compound.edit])}</span>{' · '}
   <span>{t.observation.compoundValidation(t.observation.compoundStep[compound.validation])}</span>
   {compound.unknownOperations>0&&<p role="status">{t.observation.compoundUnknown(compound.unknownOperations)}</p>}
  </div>}
  {semantic&&<div className="mt-1">
   <span>{t.observation.semanticState[semantic.state]}</span>
   {semantic.reason&&<span>{' '}{t.observation.semanticReason[semantic.reason]}</span>}
   <p>{t.observation.semanticBudget(semantic.attempts,semantic.maxAttempts,(semantic.reservedCostUnits/1e9).toFixed(6),(semantic.maxCostUnits/1e9).toFixed(6))}</p>
   {semantic.mode==='mechanism-experiment'&&<p>{t.observation.semanticExperiment}</p>}
  </div>}
  {running&&taskId&&mode==='active'&&<button type="button" disabled={busy} className="ml-3 underline" onClick={()=>void act(async()=>setMode((await api.stopObservationTask(taskId)).mode))}>{t.observation.stop}</button>}
  {running&&taskId&&(mode==='active'||mode==='recall-only')&&<button type="button" disabled={busy} className="ml-3 underline" onClick={()=>void act(async()=>setMode((await api.revokeObservationTask(taskId)).mode))}>{t.observation.revoke}</button>}
  {failed&&<p role="alert">{t.observation.failed}</p>}
 </div>;
}
