import {useEffect,useRef,useState} from 'react'
import {api} from '../../api/bridge'
import type {DecisionModelView} from '../../api/types'
import {useLocale} from '../../contexts/LocaleContext'
import {secondaryButtonSmCls,secondaryButtonBorderStyle} from '../buttonStyles'
import {ModelConfigurationCard} from './ModelConfigurationCard'
import {ModelActionDialog} from './ModelActionDialog'
type Props={models:DecisionModelView[];busy:boolean;selectedId?:string;active?:boolean;onAction:(fn:()=>Promise<unknown>,interrupt?:boolean)=>Promise<void>}
export function LocalDecisionModels({models,busy,selectedId,active=true,onAction}:Props){
 const {t}=useLocale();const ds=t.desktopSettings
 const [pending,setPending]=useState<{kind:'load'|'remove';model:DecisionModelView}|null>(null);const [details,setDetails]=useState<string|null>(null);const confirming=useRef(false)
 useEffect(()=>{if(!active){setPending(null);setDetails(null)}},[active])
 const name=(m:DecisionModelView)=>m.id==='clef-flash-mlx-4bit'?ds.decisionModelsClef:ds.decisionModelsLaya
 const confirm=()=>{if(!pending||confirming.current)return;const p=pending;confirming.current=true;setPending(null);void onAction(()=>p.kind==='load'?api.decisionModelsStart({modelId:p.model.id,approveCommunityCode:true}):api.decisionModelsRemove(p.model.id)).finally(()=>{confirming.current=false})}
 return <section className="rounded-xl border border-[var(--c-border-subtle)] bg-[var(--c-bg-menu)] p-4 flex flex-col gap-3">
  <h4 className="text-sm font-semibold">{ds.decisionModelsTitle}</h4><p className="text-xs text-[var(--c-text-secondary)]">{ds.memoryDecisionInstallationNote}</p>
  {models.map(m=>{const loading=['checking','loading'].includes(m.state),downloading=m.state==='downloading';const primary=downloading?{label:ds.decisionModelsCancel,disabled:false,interrupt:true,run:()=>api.decisionModelsCancel(m.id)}:!m.verified?{label:m.state==='failed'||m.state==='interrupted'?ds.decisionModelsRetry:ds.decisionModelsDownload,disabled:busy||loading||!m.supported,interrupt:false,run:()=>api.decisionModelsDownload(m.id)}:null;
   return <ModelConfigurationCard key={m.id} name={name(m)} selected={selectedId===m.id} status={ds.decisionModelState(m.state)} description={`${m.sizeLabel} · ${m.supported?ds.decisionModelsSupported:ds.decisionModelsUnsupported}`} active={active}
    primary={primary&&<button type="button" className={secondaryButtonSmCls} style={secondaryButtonBorderStyle} disabled={primary.disabled} onClick={()=>void onAction(primary.run,primary.interrupt)}>{primary.label}</button>}
    actions={[
     {key:'load',label:ds.decisionModelsLoad,disabled:busy||loading||downloading||!m.supported||!m.verified||m.state==='ready',onSelect:()=>setPending({kind:'load',model:m})},
     {key:'stop',label:ds.decisionModelsStop,disabled:!['ready','loading'].includes(m.state),onSelect:()=>void onAction(()=>api.decisionModelsStop(m.id),true)},
     {key:'remove',label:ds.decisionModelsRemove,danger:true,disabled:busy||loading||downloading||m.state==='not_installed',onSelect:()=>setPending({kind:'remove',model:m})},
     {key:'details',label:ds.memoryDecisionRuntimeDetails,onSelect:()=>setDetails(details===m.id?null:m.id)},
    ]}>
    {m.reason&&<p className="text-xs text-amber-600">{ds.decisionModelReason(m.reason)}</p>}
    {downloading&&<><progress className="w-full" max={m.sizeBytes} value={m.downloadedBytes}/><p className="text-xs">{ds.decisionModelsProgress(Math.round(m.downloadedBytes/m.sizeBytes*100),m.currentFile??'')}</p></>}
    {details===m.id&&<div className="flex flex-col gap-2"><p className="text-xs break-all">{ds.decisionModelsSource(m.source,m.revision)}</p><p className="text-xs">{m.runtime==='clef-mlx'?ds.decisionModelsClefRequirements:ds.decisionModelsLayaRequirements}</p>{m.runtimeInfo&&<p className="text-xs">{ds.decisionModelsRuntime([m.runtimeInfo.engine,m.runtimeInfo.device,m.runtimeInfo.parameterPrecision,m.runtimeInfo.quantization,...Object.entries(m.runtimeInfo.versions).map(([key,value])=>`${key} ${value}`)].filter(Boolean).join(' · '))}</p>}</div>}
   </ModelConfigurationCard>
  })}
  <ModelActionDialog open={active&&!!pending} danger={pending?.kind==='remove'} title={pending?.kind==='remove'?ds.decisionModelsRemove:ds.decisionModelsLoad} message={!pending?'':pending.kind==='remove'?ds.decisionModelsRemoveConfirm:ds.decisionModelsTrust(pending.model.source,pending.model.revision,pending.model.codeHash??'',pending.model.runtimeSource??pending.model.source,pending.model.runtimeVersion??pending.model.revision)} onClose={()=>setPending(null)} onConfirm={confirm}/>
 </section>
}
