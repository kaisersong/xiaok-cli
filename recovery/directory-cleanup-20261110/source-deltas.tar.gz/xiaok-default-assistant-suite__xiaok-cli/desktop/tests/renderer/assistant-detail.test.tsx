import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';

import {
  AssistantDetailPanel,
  type AssistantCandidateView,
} from '../../renderer/src/components/assistant/AssistantDetailPanel';
import type { AssistantWorkItemView } from '../../renderer/src/components/assistant/view-types';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

const candidates: AssistantCandidateView[] = [
  {
    id: 'memory-1',
    kind: 'memory',
    status: 'pending',
    title: '记住发布偏好',
    content: '正式发布前必须完成桌面端 E2E。',
    confidence: 0.94,
    evidenceRefs: [{ kind: 'thread', id: 'thread-1' }],
  },
  {
    id: 'knowledge-1',
    kind: 'knowledge',
    status: 'pending',
    title: '归档 MCP 评审结论',
    content: '将一致结论归档到知识库。',
    confidence: 0.88,
    evidenceRefs: [],
  },
];

const workItems: AssistantWorkItemView[] = [
  {
    id: 'built-in-evening', phase: 'evening', title: '晚间复盘', instruction: '整理完成和阻塞', enabled: true,
    sortOrder: 0, builtInKey: 'evening_review', createdAt: 1, updatedAt: 1,
  },
  {
    id: 'custom-morning', phase: 'morning', title: '客户提醒', instruction: '提醒今日客户回访', enabled: true,
    sortOrder: 0, createdAt: 1, updatedAt: 1,
  },
  {
    id: 'custom-morning-2', phase: 'morning', title: '项目提醒', instruction: '提醒今日项目检查', enabled: true,
    sortOrder: 1, createdAt: 1, updatedAt: 1,
  },
];

describe('AssistantDetailPanel', () => {
  it('shows candidate provenance and only mutates after an explicit user decision', () => {
    const onAcceptCandidate = vi.fn();
    const onRejectCandidate = vi.fn();
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open
          profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={candidates}
          workItems={workItems}
          workItemRevision={3}
          knowledgeCollections={[{ id: 'collection-1', name: '产品知识' }]}
          onClose={() => {}}
          onAcceptCandidate={onAcceptCandidate}
          onRejectCandidate={onRejectCandidate}
          onCreateWorkItem={vi.fn()}
          onUpdateWorkItem={vi.fn()}
          onSetWorkItemEnabled={vi.fn()}
          onReorderWorkItems={vi.fn()}
          onDeleteWorkItem={vi.fn()}
          onRestoreBuiltInWorkItem={vi.fn()}
        />
      </LocaleProvider>,
    );

    expect(screen.getByText('正式发布前必须完成桌面端 E2E。')).toBeInTheDocument();
    expect(screen.getByText('thread · thread-1')).toBeInTheDocument();
    expect(screen.getAllByText('待确认')).toHaveLength(2);

    fireEvent.click(screen.getByRole('button', { name: '采纳：记住发布偏好' }));
    expect(onAcceptCandidate).toHaveBeenCalledWith('memory-1');
    fireEvent.click(screen.getByRole('button', { name: '忽略：记住发布偏好' }));
    expect(onRejectCandidate).toHaveBeenCalledWith('memory-1');
    const knowledgeAccept = screen.getByRole('button', { name: '采纳：归档 MCP 评审结论' });
    expect(knowledgeAccept).toBeDisabled();
    fireEvent.change(screen.getByRole('combobox', { name: '选择知识库：归档 MCP 评审结论' }), {
      target: { value: 'collection-1' },
    });
    expect(knowledgeAccept).toBeEnabled();
    fireEvent.click(knowledgeAccept);
    expect(onAcceptCandidate).toHaveBeenCalledWith('knowledge-1', 'collection-1');
  });

  it('does not render when closed', () => {
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open={false}
          profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={candidates}
          workItems={workItems}
          workItemRevision={3}
          knowledgeCollections={[]}
          onClose={() => {}}
          onAcceptCandidate={() => {}}
          onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}}
          onUpdateWorkItem={() => {}}
          onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}}
          onDeleteWorkItem={() => {}}
          onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    expect(screen.queryByRole('dialog', { name: 'XiaoK助理详情' })).not.toBeInTheDocument();
  });

  it('closes through the real overlay button and Escape outside the titlebar drag region', () => {
    const onClose = vi.fn();
    const { container } = render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          onClose={onClose} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}} onUpdateWorkItem={() => {}} onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}} onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    const overlay = container.firstElementChild as HTMLElement;
    expect(overlay).toHaveAttribute('data-app-region', 'no-drag');
    expect(overlay).toHaveClass('no-drag');
    fireEvent.click(screen.getByRole('button', { name: '关闭XiaoK助理详情' }));
    fireEvent.keyDown(document, { key: 'Escape' });
    expect(onClose).toHaveBeenCalledTimes(2);
  });

  it('keeps new work item input focused across parent rerenders and closes through the latest callback', async () => {
    const firstOnClose = vi.fn();
    const latestOnClose = vi.fn();
    const panel = (onClose: () => void) => (
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          onClose={onClose} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}} onUpdateWorkItem={() => {}} onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}} onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>
    );
    const view = render(panel(firstOnClose));

    await waitFor(() => expect(screen.getByRole('button', { name: '关闭XiaoK助理详情' })).toHaveFocus());
    const titleInput = screen.getByLabelText('新任务名称');
    fireEvent.change(titleInput, { target: { value: '每天检查项目风险' } });
    titleInput.focus();
    expect(titleInput).toHaveFocus();

    view.rerender(panel(latestOnClose));
    await new Promise(resolve => window.setTimeout(resolve, 0));

    expect(titleInput).toHaveFocus();
    expect(titleInput).toHaveValue('每天检查项目风险');
    fireEvent.keyDown(document, { key: 'Escape' });
    expect(firstOnClose).not.toHaveBeenCalled();
    expect(latestOnClose).toHaveBeenCalledTimes(1);
  });

  it('edits, toggles, reorders, restores, deletes, and creates work items explicitly', async () => {
    const onUpdateWorkItem = vi.fn().mockResolvedValue(undefined);
    const onSetWorkItemEnabled = vi.fn().mockResolvedValue(undefined);
    const onReorderWorkItems = vi.fn().mockResolvedValue(undefined);
    const onDeleteWorkItem = vi.fn().mockResolvedValue(undefined);
    const onRestoreBuiltInWorkItem = vi.fn().mockResolvedValue(undefined);
    const onCreateWorkItem = vi.fn().mockResolvedValue(undefined);
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          onClose={() => {}} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={onCreateWorkItem} onUpdateWorkItem={onUpdateWorkItem}
          onSetWorkItemEnabled={onSetWorkItemEnabled} onReorderWorkItems={onReorderWorkItems}
          onDeleteWorkItem={onDeleteWorkItem} onRestoreBuiltInWorkItem={onRestoreBuiltInWorkItem}
        />
      </LocaleProvider>,
    );

    fireEvent.change(screen.getByLabelText('任务名称：晚间复盘'), { target: { value: '晚间总结' } });
    fireEvent.click(screen.getByRole('button', { name: '保存：晚间复盘' }));
    await waitFor(() => expect(onUpdateWorkItem).toHaveBeenCalledWith({ id: 'built-in-evening', phase: 'evening', title: '晚间总结', instruction: '整理完成和阻塞' }));
    fireEvent.click(screen.getByRole('checkbox', { name: '启用：晚间复盘' }));
    await waitFor(() => expect(onSetWorkItemEnabled).toHaveBeenCalledWith('built-in-evening', false));
    fireEvent.click(screen.getByRole('button', { name: '恢复默认：晚间复盘' }));
    await waitFor(() => expect(onRestoreBuiltInWorkItem).toHaveBeenCalledWith('built-in-evening'));
    fireEvent.click(screen.getByRole('button', { name: '删除：客户提醒' }));
    await waitFor(() => expect(onDeleteWorkItem).toHaveBeenCalledWith('custom-morning'));
    fireEvent.click(screen.getByRole('button', { name: '下移：客户提醒' }));
    await waitFor(() => expect(onReorderWorkItems).toHaveBeenCalledWith('morning', ['custom-morning-2', 'custom-morning'], 3));

    fireEvent.change(screen.getByLabelText('新任务名称'), { target: { value: '午前检查' } });
    fireEvent.change(screen.getByLabelText('新任务说明'), { target: { value: '检查阻塞事项' } });
    fireEvent.click(screen.getByRole('button', { name: '添加任务' }));
    await waitFor(() => expect(onCreateWorkItem).toHaveBeenCalledWith({ phase: 'evening', title: '午前检查', instruction: '检查阻塞事项' }));
  });

  it('previews the current unsaved draft and renders preview plus latest formal outcomes separately', async () => {
    const onPreviewWorkItem = vi.fn().mockResolvedValue({
      workItemId: 'built-in-evening', phase: 'evening', status: 'completed', summary: '试运行发现两个改进方向。',
      recommendations: [], candidates: [{ title: '记录 Dream', content: '保留本次发现', kind: 'memory', confidence: 0.8, evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }] }],
      evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }], generatedAt: 100, durationMs: 1234,
      context: { from: 10, to: 100, itemCount: 4, scopeCounts: { tasks: 3, projects: 1 }, sourceErrorCount: 0 },
    });
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          latestWorkItemOutcomes={[{
            runId: 'run-1', workItemId: 'built-in-evening', phase: 'evening', status: 'completed', summary: '昨晚正式完成。',
            recommendations: [], candidates: [], evidenceRefs: [{ kind: 'task_snapshot', id: 'task-0' }], generatedAt: 50,
          }]}
          onPreviewWorkItem={onPreviewWorkItem}
          onClose={() => {}} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}} onUpdateWorkItem={() => {}} onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}} onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    fireEvent.change(screen.getByLabelText('任务名称：晚间复盘'), { target: { value: 'Dreaming draft' } });
    fireEvent.change(screen.getByLabelText('任务说明：晚间复盘'), { target: { value: '检查当前改进方向' } });
    fireEvent.click(screen.getByRole('button', { name: '试运行：晚间复盘' }));

    await waitFor(() => expect(onPreviewWorkItem).toHaveBeenCalledWith({
      id: 'built-in-evening', phase: 'evening', title: 'Dreaming draft', instruction: '检查当前改进方向',
    }));
    expect(await screen.findByText('试运行发现两个改进方向。')).toBeInTheDocument();
    expect(screen.getByText('试运行结果（不会保存）')).toBeInTheDocument();
    expect(screen.getByText('读取 4 条 · 任务 3 · 项目 1')).toBeInTheDocument();
    expect(screen.getByText('最近正式运行')).toBeInTheDocument();
    expect(screen.getByText('昨晚正式完成。')).toBeInTheDocument();
    expect(screen.getByText('task_snapshot · task-1')).toBeInTheDocument();
  });

  it('renders a durable formal failure with a user-readable status after reload', () => {
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          latestWorkItemOutcomes={[{
            runId: 'run-failed', workItemRunId: 'item-run-failed', workItemId: 'built-in-evening', phase: 'evening',
            status: 'failed', error: 'assistant_json_invalid', recommendations: [], candidates: [], evidenceRefs: [], generatedAt: 100,
          }]}
          onClose={() => {}} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}} onUpdateWorkItem={() => {}} onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}} onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    expect(screen.getByText('最近正式运行')).toBeInTheDocument();
    expect(screen.getByText('运行失败：模型返回的结果格式不完整，请稍后重试。')).toBeInTheDocument();
  });

  it('shows preview failures inline and restores the button', async () => {
    const onPreviewWorkItem = vi.fn().mockRejectedValue(new Error('provider unavailable'));
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          onPreviewWorkItem={onPreviewWorkItem}
          onClose={() => {}} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}} onUpdateWorkItem={() => {}} onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}} onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    fireEvent.click(screen.getByRole('button', { name: '试运行：晚间复盘' }));
    expect(await screen.findByText('试运行失败：provider unavailable')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '试运行：晚间复盘' })).toBeEnabled();
  });

  it('previews a new unsaved work item without creating it', async () => {
    const onCreateWorkItem = vi.fn();
    const onPreviewWorkItem = vi.fn().mockResolvedValue({
      workItemId: 'assistant-preview:new-work-item', phase: 'evening', status: 'no_result', recommendations: [], candidates: [], evidenceRefs: [],
      generatedAt: 100, durationMs: 5, context: { from: 10, to: 100, itemCount: 0, scopeCounts: {}, sourceErrorCount: 0 },
    });
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          onPreviewWorkItem={onPreviewWorkItem}
          onClose={() => {}} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={onCreateWorkItem} onUpdateWorkItem={() => {}} onSetWorkItemEnabled={() => {}}
          onReorderWorkItems={() => {}} onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    fireEvent.change(screen.getByLabelText('新任务名称'), { target: { value: '未保存 Dreaming' } });
    fireEvent.change(screen.getByLabelText('新任务说明'), { target: { value: '先看看会产生什么' } });
    fireEvent.click(screen.getByRole('button', { name: '试运行：未保存 Dreaming' }));

    await waitFor(() => expect(onPreviewWorkItem).toHaveBeenCalledWith({
      id: 'assistant-preview:new-work-item', phase: 'evening', title: '未保存 Dreaming', instruction: '先看看会产生什么',
    }));
    expect(onCreateWorkItem).not.toHaveBeenCalled();
    expect(await screen.findByText('本次没有生成结果。可以调整任务说明后再次试运行。')).toBeInTheDocument();
  });

  it('keeps the panel open and preserves drafts when a mutation fails', async () => {
    render(
      <LocaleProvider>
        <AssistantDetailPanel
          open profile={{ status: 'active', eveningTime: '21:30', morningTime: '08:30' }}
          candidates={[]} workItems={workItems} workItemRevision={3} knowledgeCollections={[]}
          onClose={() => {}} onAcceptCandidate={() => {}} onRejectCandidate={() => {}}
          onCreateWorkItem={() => {}} onUpdateWorkItem={() => Promise.reject(new Error('offline'))}
          onSetWorkItemEnabled={() => {}} onReorderWorkItems={() => {}}
          onDeleteWorkItem={() => {}} onRestoreBuiltInWorkItem={() => {}}
        />
      </LocaleProvider>,
    );

    const title = screen.getByLabelText('任务名称：晚间复盘');
    fireEvent.change(title, { target: { value: '保留这个草稿' } });
    fireEvent.click(screen.getByRole('button', { name: '保存：晚间复盘' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('保存失败，当前编辑内容已保留，请重试。');
    expect(screen.getByRole('dialog', { name: 'XiaoK助理详情' })).toBeInTheDocument();
    expect(title).toHaveValue('保留这个草稿');
  });
});
