import { describe, expect, it, vi } from 'vitest';

import {
  completeAssistantJson,
  validateAssistantPhaseOutput,
} from '../../electron/assistant-llm.js';

describe('assistant no-tool structured LLM', () => {
  it('uses the narrow completion port without adding tools', async () => {
    const complete = vi.fn().mockResolvedValue({ text: JSON.stringify({ ok: true }) });
    await completeAssistantJson({
      port: { complete },
      systemPrompt: 'Return JSON.',
      snapshot: { snapshot: {}, workItems: [] },
      validate: value => value,
      maxTokens: 500,
    });
    expect(complete).toHaveBeenCalledWith(expect.objectContaining({ model: 'fast', temperature: 0 }));
    expect(complete.mock.calls[0][0]).not.toHaveProperty('tools');
  });

  it('normalizes unknown, duplicate and missing work item outcomes deterministically', () => {
    const output = validateAssistantPhaseOutput({
      schemaVersion: 'assistant_work_items_v1',
      phase: 'morning',
      outcomes: [
        {
          workItemId: 'morning-1',
          summary: '先处理发布。',
          recommendations: [{
            title: '处理发布阻塞',
            reasonCode: 'release_blocked',
            evidenceRefs: [{ kind: 'task', id: 'task-1' }],
          }],
        },
        { workItemId: 'morning-1', summary: '重复项', recommendations: [] },
        { workItemId: 'unknown', summary: '未知项', recommendations: [] },
      ],
    }, { phase: 'morning', workItemIds: ['morning-1', 'morning-2'] });

    expect(output.outcomes).toEqual([
      expect.objectContaining({ workItemId: 'morning-1', status: 'completed', summary: '先处理发布。' }),
      { workItemId: 'morning-2', status: 'no_result', recommendations: [], candidates: [] },
    ]);
    expect(output.anomalies).toEqual([
      { kind: 'duplicate_work_item_id', workItemId: 'morning-1' },
      { kind: 'unknown_work_item_id', workItemId: 'unknown' },
    ]);
  });

  it('validates phase-specific child results and candidate safety fields', () => {
    expect(() => validateAssistantPhaseOutput({
      schemaVersion: 'assistant_work_items_v1',
      phase: 'morning',
      outcomes: [{
        workItemId: 'morning-1',
        summary: 'wrong child',
        candidates: [{ kind: 'memory' }],
      }],
    }, { phase: 'morning', workItemIds: ['morning-1'] })).toThrow('morning candidates');

    expect(() => validateAssistantPhaseOutput({
      schemaVersion: 'assistant_work_items_v1',
      phase: 'evening',
      outcomes: [{
        workItemId: 'evening-1',
        summary: 'candidate',
        candidates: [{
          kind: 'memory', title: 't', content: 'c', scope: 'global', confidence: 2,
          evidenceRefs: [{ kind: 'task', id: '1' }], dedupeKey: 'k',
        }],
      }],
    }, { phase: 'evening', workItemIds: ['evening-1'] })).toThrow('confidence');
  });

  it('rejects evidence references that are not present in the current snapshot catalog', () => {
    expect(() => validateAssistantPhaseOutput({
      schemaVersion: 'assistant_work_items_v1',
      phase: 'evening',
      outcomes: [{
        workItemId: 'dreaming',
        summary: '发现暂停任务。',
        candidates: [{
          kind: 'follow_up', title: '检查暂停任务', content: '确认是否恢复。', scope: 'global', confidence: 0.8,
          evidenceRefs: [{ kind: 'automation', id: 'not-in-snapshot' }], dedupeKey: 'follow-up:paused',
        }],
      }],
    }, {
      phase: 'evening',
      workItemIds: ['dreaming'],
      evidenceRefs: [{ kind: 'timed_action', id: 'action-1' }],
    })).toThrow('assistant evidence reference unknown');
  });

  it('deduplicates valid evidence references after exact catalog membership validation', () => {
    const output = validateAssistantPhaseOutput({
      schemaVersion: 'assistant_work_items_v1',
      phase: 'morning',
      outcomes: [{
        workItemId: 'morning-1',
        summary: '优先处理发布。',
        recommendations: [{
          title: '处理发布', reasonCode: 'release',
          evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }, { kind: 'task_snapshot', id: 'task-1' }],
        }],
      }],
    }, {
      phase: 'morning',
      workItemIds: ['morning-1'],
      evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }],
    });

    expect(output.outcomes[0].recommendations[0].evidenceRefs).toEqual([{ kind: 'task_snapshot', id: 'task-1' }]);
  });

  it('fails closed on malformed JSON', async () => {
    await expect(completeAssistantJson({
      port: { complete: vi.fn().mockResolvedValue({ text: 'not-json' }) },
      systemPrompt: 'Return JSON.',
      snapshot: {},
      validate: value => value,
      maxTokens: 500,
    })).rejects.toThrow('assistant_json_invalid');
  });

  it('accepts a JSON response wrapped in a complete markdown fence', async () => {
    const result = await completeAssistantJson({
      port: {
        complete: vi.fn().mockResolvedValue({
          text: '```json\n{"ok":true,"summary":"Dreaming"}\n```',
        }),
      },
      systemPrompt: 'Return JSON.',
      snapshot: {},
      validate: value => value as { ok: boolean; summary: string },
      maxTokens: 500,
    });

    expect(result).toEqual({ ok: true, summary: 'Dreaming' });
  });

  it('accepts the only complete JSON value inside explanatory text', async () => {
    const result = await completeAssistantJson({
      port: {
        complete: vi.fn().mockResolvedValue({
          text: '分析完成。\n{"summary":"保留字符串里的 } 和 \\\" 引号","items":[{"value":"{nested}"}]}\n以上是结果。',
        }),
      },
      systemPrompt: 'Return JSON.',
      snapshot: {},
      validate: value => value as { summary: string; items: Array<{ value: string }> },
      maxTokens: 500,
    });

    expect(result).toEqual({
      summary: '保留字符串里的 } 和 " 引号',
      items: [{ value: '{nested}' }],
    });
  });

  it('fails closed when explanatory text contains multiple valid JSON values', async () => {
    await expect(completeAssistantJson({
      port: {
        complete: vi.fn().mockResolvedValue({
          text: '候选一 {"ok":true} 候选二 {"ok":false}',
        }),
      },
      systemPrompt: 'Return JSON.',
      snapshot: {},
      validate: value => value,
      maxTokens: 500,
    })).rejects.toThrow('assistant_json_invalid');
  });

  it('fails closed on a truncated fenced JSON response', async () => {
    await expect(completeAssistantJson({
      port: {
        complete: vi.fn().mockResolvedValue({
          text: '```json\n{"ok": true\n```',
        }),
      },
      systemPrompt: 'Return JSON.',
      snapshot: {},
      validate: value => value,
      maxTokens: 500,
    })).rejects.toThrow('assistant_json_invalid');
  });
});
