import { describe, expect, it, vi } from 'vitest';

import { createAssistantContextRetriever } from '../../electron/assistant-context-retriever.js';

const profile = {
  id: 'default-personal-assistant' as const,
  status: 'active' as const,
  locale: 'zh' as const,
  timeZone: 'Asia/Shanghai',
  eveningTime: '22:30',
  morningTime: '08:30',
  workdays: [0, 1, 2, 3, 4, 5, 6],
  quietHours: { start: '23:00', end: '07:00' },
  dataScopes: ['tasks', 'artifacts'] as const,
  createdAt: 1,
  updatedAt: 1,
};

describe('assistant context retriever', () => {
  it('retrieves bounded memory and knowledge content using the work-item query', async () => {
    const memorySearch = vi.fn().mockResolvedValue(Array.from({ length: 8 }, (_, index) => ({
      id: `memory-${index}`, scope: 'global', title: `记忆 ${index}`, summary: `记忆正文 ${index}`,
      tags: [], updatedAt: 1_000 + index,
    })));
    const kbSearch = vi.fn().mockImplementation(async ({ collectionId }: { collectionId: string }) => [{
      chunkId: `chunk-${collectionId}`, sourceId: `source-${collectionId}`, sourceTitle: `知识 ${collectionId}`,
      collectionId, text: `知识正文 ${collectionId}`, pageIndex: null, slideIndex: null, sheetName: null,
      bm25Score: 1, vectorScore: 0, fusedScore: 1,
    }]);
    const retriever = createAssistantContextRetriever({
      memoryStore: { search: memorySearch } as never,
      kbStore: { listCollections: () => [{ id: 'c1' }, { id: 'c2' }] } as never,
      kbRetriever: { search: kbSearch },
    });

    const result = await retriever.retrieve({
      profile: { ...profile, dataScopes: [...profile.dataScopes] },
      workItem: {
        id: 'dreaming', assistantId: 'default-personal-assistant', phase: 'evening', title: 'Dreaming',
        instruction: '检索记忆和知识库，结合上次总结，不要重复', enabled: true, sortOrder: 0, createdAt: 1, updatedAt: 1,
      },
      previousOutcome: { summary: '上次关注了日报延迟', finishedAt: 2_000 },
    });

    expect(memorySearch).toHaveBeenCalledWith(expect.stringContaining('上次关注了日报延迟'), 6);
    expect(kbSearch).toHaveBeenCalledTimes(2);
    expect(result.items.filter(item => item.reference.kind === 'memory')).toHaveLength(6);
    expect(result.items.filter(item => item.reference.kind === 'knowledge_chunk')).toHaveLength(2);
    expect(result.items).toEqual(expect.arrayContaining([
      expect.objectContaining({ summary: '记忆正文 0', reference: { kind: 'memory', id: 'memory-0' } }),
      expect.objectContaining({ summary: '知识正文 c1', reference: { kind: 'knowledge_chunk', id: 'chunk-c1' } }),
    ]));
    expect(result.sourceErrors).toEqual([]);
  });

  it('does not read memory without explicit instruction or knowledge without artifacts scope', async () => {
    const memorySearch = vi.fn();
    const kbSearch = vi.fn();
    const retriever = createAssistantContextRetriever({
      memoryStore: { search: memorySearch } as never,
      kbStore: { listCollections: () => [{ id: 'c1' }] } as never,
      kbRetriever: { search: kbSearch },
    });

    const result = await retriever.retrieve({
      profile: { ...profile, dataScopes: ['tasks'] },
      workItem: {
        id: 'review', assistantId: 'default-personal-assistant', phase: 'evening', title: '复盘',
        instruction: '只整理今天任务', enabled: true, sortOrder: 0, createdAt: 1, updatedAt: 1,
      },
    });

    expect(memorySearch).not.toHaveBeenCalled();
    expect(kbSearch).not.toHaveBeenCalled();
    expect(result.items).toEqual([]);
  });

  it('records retrieval degradation without failing the work item', async () => {
    const retriever = createAssistantContextRetriever({
      memoryStore: { search: vi.fn().mockRejectedValue(new Error('memory unavailable')) } as never,
      kbStore: { listCollections: () => { throw new Error('knowledge unavailable'); } } as never,
      kbRetriever: { search: vi.fn() },
    });

    const result = await retriever.retrieve({
      profile: { ...profile, dataScopes: [...profile.dataScopes] },
      workItem: {
        id: 'dreaming', assistantId: 'default-personal-assistant', phase: 'evening', title: 'Dreaming',
        instruction: '检索记忆', enabled: true, sortOrder: 0, createdAt: 1, updatedAt: 1,
      },
    });

    expect(result.items).toEqual([]);
    expect(result.sourceErrors).toEqual([
      { source: 'memory', message: 'memory unavailable' },
      { source: 'knowledge', message: 'knowledge unavailable' },
    ]);
  });
});
