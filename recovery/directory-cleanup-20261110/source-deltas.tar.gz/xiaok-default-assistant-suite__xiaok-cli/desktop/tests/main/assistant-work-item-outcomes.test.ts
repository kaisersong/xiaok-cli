import { describe, expect, it } from 'vitest';

import { listLatestAssistantWorkItemOutcomes } from '../../electron/assistant-work-item-outcomes.js';

describe('listLatestAssistantWorkItemOutcomes', () => {
  it('returns the latest durable child run for each work item including failures', () => {
    const result = listLatestAssistantWorkItemOutcomes({
      listWorkItemRuns: () => [{
        id: 'new-failed', parentRunId: 'parent-2', workItemId: 'dreaming', workItemTitle: 'Dreaming', phase: 'evening',
        status: 'failed', error: 'assistant_json_invalid', startedAt: 3_000, finishedAt: 3_100, updatedAt: 3_100,
      }, {
        id: 'older-success', parentRunId: 'parent-1', workItemId: 'dreaming', workItemTitle: 'Dreaming', phase: 'evening',
        status: 'completed', summary: '旧结果', output: {
          workItemId: 'dreaming', status: 'completed', summary: '旧结果', candidates: [], recommendations: [],
        }, startedAt: 2_000, finishedAt: 2_100, updatedAt: 2_100,
      }],
    });

    expect(result).toEqual([expect.objectContaining({
      runId: 'parent-2', workItemRunId: 'new-failed', workItemId: 'dreaming', status: 'failed',
      error: 'assistant_json_invalid', generatedAt: 3_100,
    })]);
  });

  it('returns bounded normalized outcomes from the latest successful run for each phase', () => {
    const result = listLatestAssistantWorkItemOutcomes({
      listRuns: phase => phase === 'morning'
        ? [{ id: 'morning-run', status: 'success', finishedAt: 2_000 }]
        : [{ id: 'evening-run', status: 'success', finishedAt: 1_000 }],
      listEvidence: runId => [{
        createdAt: runId === 'morning-run' ? 2_000 : 1_000,
        metadata: {
          assistantKind: runId === 'morning-run' ? 'morning' : 'evening',
          output: {
            schemaVersion: 'assistant_work_items_v1',
            phase: runId === 'morning-run' ? 'morning' : 'evening',
            outcomes: runId === 'morning-run' ? [{
              workItemId: 'morning-1', status: 'completed', summary: '优先发布', candidates: [],
              recommendations: [{ title: '发布', reasonCode: 'release', evidenceRefs: [{ kind: 'task', id: 'task-1' }] }],
            }] : [{
              workItemId: 'evening-1', status: 'no_result', candidates: [], recommendations: [],
            }],
          },
        },
      }],
    });

    expect(result).toEqual([
      expect.objectContaining({ runId: 'evening-run', phase: 'evening', workItemId: 'evening-1', status: 'no_result' }),
      expect.objectContaining({
        runId: 'morning-run', phase: 'morning', workItemId: 'morning-1', status: 'completed',
        recommendations: [expect.objectContaining({ title: '发布' })],
      }),
    ]);
  });
});
