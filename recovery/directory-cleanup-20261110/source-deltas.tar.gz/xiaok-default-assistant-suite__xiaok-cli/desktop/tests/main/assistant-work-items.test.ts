import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { AssistantWorkItemService } from '../../electron/assistant-work-item-service.js';
import { DEFAULT_PERSONAL_ASSISTANT_ID } from '../../electron/assistant-types.js';
import { LoopStore } from '../../electron/loop-store.js';

describe('AssistantWorkItemService', () => {
  let rootDir: string;
  let dbPath: string;
  let loopStore: LoopStore;
  let service: AssistantWorkItemService;
  let clock: number;

  beforeEach(() => {
    rootDir = join(tmpdir(), `xiaok-assistant-work-items-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    mkdirSync(rootDir, { recursive: true });
    dbPath = join(rootDir, 'loop-evidence.sqlite');
    clock = 1_000;
    loopStore = new LoopStore(dbPath);
    loopStore.ensureAssistantProfile({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'needs_consent',
      locale: 'zh',
      timeZone: 'Asia/Shanghai',
      eveningTime: '22:30',
      morningTime: '08:30',
      workdays: [1, 2, 3, 4, 5],
      quietHours: { start: '22:00', end: '08:00' },
      dataScopes: ['threads', 'projects', 'tasks', 'artifacts', 'automations', 'meetings'],
      createdAt: clock,
      updatedAt: clock,
    });
    service = new AssistantWorkItemService({ loopStore, now: () => ++clock });
  });

  afterEach(() => {
    loopStore.close();
    rmSync(rootDir, { recursive: true, force: true, maxRetries: 3 });
  });

  it('bootstraps three built-ins idempotently without overwriting user edits', () => {
    const initial = service.bootstrap();
    expect(initial.revision).toBe(1);
    expect(initial.workItems.map(item => item.builtInKey)).toEqual([
      'evening_review',
      'memory_candidates',
      'morning_priorities',
    ]);

    const eveningReview = initial.workItems.find(item => item.builtInKey === 'evening_review')!;
    const edited = service.update({
      id: eveningReview.id,
      title: '我的晚间复盘',
      instruction: '只整理今天真正完成和阻塞的事项。',
    }, 'user');
    expect(edited.revision).toBe(2);

    loopStore.close();
    loopStore = new LoopStore(dbPath);
    service = new AssistantWorkItemService({ loopStore, now: () => ++clock });
    const reopened = service.bootstrap();
    expect(reopened.revision).toBe(2);
    expect(reopened.workItems.find(item => item.id === eveningReview.id)).toMatchObject({
      title: '我的晚间复盘',
      instruction: '只整理今天真正完成和阻塞的事项。',
    });
    expect(reopened.workItems).toHaveLength(3);
  });

  it.each(['agent', 'scheduler'] as const)('rejects every mutation from %s and persists rejection audits', source => {
    const snapshot = service.bootstrap();
    const builtIn = snapshot.workItems[0];
    const attempts = [
      () => service.create({ phase: 'morning', title: '越权创建', instruction: '不应成功' }, source),
      () => service.update({ id: builtIn.id, title: '越权修改' }, source),
      () => service.setEnabled({ id: builtIn.id, enabled: false }, source),
      () => service.reorder({
        phase: builtIn.phase,
        orderedIds: snapshot.workItems.filter(item => item.phase === builtIn.phase).map(item => item.id),
        expectedRevision: snapshot.revision,
      }, source),
      () => service.delete({ id: builtIn.id }, source),
      () => service.restoreBuiltIn({ id: builtIn.id }, source),
    ];

    for (const attempt of attempts) expect(attempt).toThrow('assistant_work_items_user_only');
    expect(service.getSnapshot()).toEqual(snapshot);

    loopStore.close();
    loopStore = new LoopStore(dbPath);
    const audits = loopStore.listAssistantWorkItemAudits();
    expect(audits).toHaveLength(attempts.length);
    expect(audits.every(audit => audit.requestSource === source && audit.result === 'rejected')).toBe(true);
  });

  it('supports custom CRUD, built-in restore, enabled limits and atomic revisioned reorder', () => {
    let snapshot = service.bootstrap();
    snapshot = service.create({ phase: 'morning', title: '检查发布状态', instruction: '根据任务快照整理发布阻塞。' }, 'user');
    const custom = snapshot.workItems.find(item => item.title === '检查发布状态')!;
    expect(custom.builtInKey).toBeUndefined();

    snapshot = service.update({ id: custom.id, phase: 'evening', title: '检查晚间发布状态' }, 'user');
    expect(snapshot.workItems.find(item => item.id === custom.id)).toMatchObject({ phase: 'evening', title: '检查晚间发布状态' });

    const eveningIds = snapshot.workItems.filter(item => item.phase === 'evening').map(item => item.id);
    const reorderedIds = [...eveningIds].reverse();
    const beforeReorder = snapshot;
    expect(() => service.reorder({ phase: 'evening', orderedIds: reorderedIds, expectedRevision: snapshot.revision - 1 }, 'user'))
      .toThrow('assistant_work_items_revision_conflict');
    expect(service.getSnapshot()).toEqual(beforeReorder);

    snapshot = service.reorder({ phase: 'evening', orderedIds: reorderedIds, expectedRevision: snapshot.revision }, 'user');
    expect(snapshot.workItems.filter(item => item.phase === 'evening').map(item => item.id)).toEqual(reorderedIds);

    const builtIn = snapshot.workItems.find(item => item.builtInKey === 'evening_review')!;
    snapshot = service.update({ id: builtIn.id, title: '临时标题', instruction: '临时内容' }, 'user');
    snapshot = service.setEnabled({ id: builtIn.id, enabled: false }, 'user');
    snapshot = service.restoreBuiltIn({ id: builtIn.id }, 'user');
    expect(snapshot.workItems.find(item => item.id === builtIn.id)).toMatchObject({
      title: '整理当天完成、阻塞和下一步',
      enabled: false,
    });
    expect(() => service.delete({ id: builtIn.id }, 'user')).toThrow('assistant_work_item_built_in_delete_forbidden');

    snapshot = service.delete({ id: custom.id }, 'user');
    expect(snapshot.workItems.some(item => item.id === custom.id)).toBe(false);
  });

  it('fails closed on invalid fields and count limits', () => {
    service.bootstrap();
    expect(() => service.create({ phase: 'morning', title: '', instruction: 'x' }, 'user')).toThrow('assistant_work_item_title_invalid');
    expect(() => service.create({ phase: 'morning', title: 'x', instruction: ' '.repeat(3) }, 'user')).toThrow('assistant_work_item_instruction_invalid');
    expect(() => service.create({ phase: 'invalid' as never, title: 'x', instruction: 'x' }, 'user')).toThrow('assistant_work_item_phase_invalid');

    for (let index = 0; index < 7; index += 1) {
      service.create({ phase: 'morning', title: `Morning ${index}`, instruction: `Instruction ${index}` }, 'user');
    }
    expect(service.listEnabled('morning')).toHaveLength(8);
    expect(() => service.create({ phase: 'morning', title: 'Too many enabled', instruction: 'limit' }, 'user'))
      .toThrow('assistant_work_item_enabled_limit');

    const snapshot = service.getSnapshot();
    expect(snapshot.workItems.every(item => item.assistantId === DEFAULT_PERSONAL_ASSISTANT_ID)).toBe(true);
  });
});
