import { mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import {
  createAssistantRuntime,
  type AssistantRuntime,
} from '../../electron/assistant-runtime.js';
import { createLoopExecutionAdapter } from '../../electron/loop-execution-adapter.js';
import { CompletionEvidenceStore } from '../../electron/completion-evidence-store.js';
import { LoopStore } from '../../electron/loop-store.js';
import {
  ASSISTANT_EVENING_LOOP_ID,
  ASSISTANT_MORNING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
} from '../../electron/assistant-types.js';
import { AssistantWorkItemService } from '../../electron/assistant-work-item-service.js';

describe('assistant runtime wiring', () => {
  let rootDir: string;
  let loopStore: LoopStore;
  let evidenceStore: CompletionEvidenceStore;
  let workItemService: AssistantWorkItemService;

  beforeEach(() => {
    rootDir = join(tmpdir(), `xiaok-assistant-runtime-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    mkdirSync(rootDir, { recursive: true });
    loopStore = new LoopStore(join(rootDir, 'loops.sqlite'));
    evidenceStore = new CompletionEvidenceStore(join(rootDir, 'evidence.sqlite'));
    loopStore.ensureBuiltInLoops(Date.UTC(2026, 7, 14, 0, 0));
    loopStore.setLoopStatus(ASSISTANT_EVENING_LOOP_ID, 'active', 1);
    loopStore.setLoopStatus(ASSISTANT_MORNING_LOOP_ID, 'active', 1);
    loopStore.ensureAssistantProfile({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'active',
      locale: 'zh',
      timeZone: 'Asia/Shanghai',
      eveningTime: '22:30',
      morningTime: '08:30',
      workdays: [1, 2, 3, 4, 5],
      quietHours: { start: '23:00', end: '07:00' },
      dataScopes: ['tasks'],
      createdAt: 1,
      updatedAt: 1,
    });
    workItemService = new AssistantWorkItemService({ loopStore, now: () => 2 });
    workItemService.bootstrap();
  });

  afterEach(() => {
    evidenceStore.close();
    loopStore.close();
    rmSync(rootDir, { recursive: true, force: true });
  });

  it('routes the built-in evening loop through structured no-tool completion instead of the generic scanner', async () => {
    const now = Date.UTC(2026, 7, 14, 14, 30);
    const genericRunner = { runLoopNow: vi.fn() };
    const complete = vi.fn().mockImplementation(async (request: { userMessage: string }) => {
      const payload = JSON.parse(request.userMessage) as { workItems: Array<{ id: string }> };
      const workItemId = payload.workItems[0].id;
      return {
        text: JSON.stringify({
          schemaVersion: 'assistant_work_items_v1', phase: 'evening', outcomes: [{
            workItemId,
            summary: workItemId === 'assistant-work-item:evening-review' ? '今天完成了发布验证。' : '没有新增候选。',
            candidates: workItemId === 'assistant-work-item:evening-review' ? [{
              kind: 'memory', title: '发布偏好', content: '发布前必须验证安装包。', scope: 'global', confidence: 0.9,
              evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }], dedupeKey: 'memory:release-verification',
            }] : [],
          }],
        }),
      };
    });
    const assistantRuntime = createRuntime({
      now,
      complete,
      items: [{
        id: 'task-1', scope: 'tasks', updatedAt: now, summary: '完成发布验证',
        reference: { kind: 'task_snapshot', id: 'task-1' }, priority: 70,
      }],
    });
    const runner = createLoopExecutionAdapter({ genericRunner, assistantRuntime });

    const result = await runner.runLoopNow(ASSISTANT_EVENING_LOOP_ID);

    expect(result).toMatchObject({ status: 'success' });
    expect(genericRunner.runLoopNow).not.toHaveBeenCalled();
    expect(complete).toHaveBeenCalledTimes(2);
    const providerInput = complete.mock.calls[0][0] as Record<string, unknown>;
    expect(providerInput).toMatchObject({ model: 'fast', temperature: 0 });
    expect(providerInput).not.toHaveProperty('tools');
    expect(loopStore.listAssistantCandidates({ statuses: ['pending'] })).toEqual([
      expect.objectContaining({ title: '发布偏好', status: 'pending', workItemId: 'assistant-work-item:evening-review' }),
    ]);
  });

  it('uses the profile timezone and scheduled occurrence date as the exactly-once logical run key', async () => {
    const complete = vi.fn().mockResolvedValue({
      text: JSON.stringify({
        schemaVersion: 'assistant_work_items_v1', phase: 'morning',
        outcomes: [{ workItemId: 'assistant-work-item:morning-priorities', summary: '暂无建议。', recommendations: [] }],
      }),
    });
    const assistantRuntime = createRuntime({
      now: Date.UTC(2026, 7, 15, 3, 0),
      complete,
    });
    const scheduledDueAt = Date.UTC(2026, 7, 14, 0, 30);
    const trigger = {
      kind: 'scheduled',
      timedActionId: 'assistant-morning',
      timedActionRunId: 'timed-run-1',
      scheduledDueAt,
      claimedAt: Date.UTC(2026, 7, 15, 3, 0),
      overdueMs: 95_400_000,
      recoveryReason: 'startup_recovery',
    };

    const first = await assistantRuntime.runLoopNow(ASSISTANT_MORNING_LOOP_ID, trigger);
    const second = await assistantRuntime.runLoopNow(ASSISTANT_MORNING_LOOP_ID, trigger);

    expect(first).toMatchObject({ status: 'success' });
    expect(second).toEqual({
      status: 'already_completed',
      completedRunId: expect.any(String),
    });
    expect(complete).toHaveBeenCalledTimes(1);
    expect(loopStore.listLoopRuns(ASSISTANT_MORNING_LOOP_ID, 10)[0]).toMatchObject({
      trigger: {
        kind: 'assistant',
        source: 'scheduled',
        logicalRunKey: 'assistant:default-personal-assistant:morning:Asia/Shanghai:2026-08-14',
        scheduledDueAt,
      },
      logicalRunKey: 'assistant:default-personal-assistant:morning:Asia/Shanghai:2026-08-14',
    });
  });

  it('deduplicates manual runs by the profile-local calendar date', async () => {
    const complete = vi.fn().mockResolvedValue({
      text: JSON.stringify({
        schemaVersion: 'assistant_work_items_v1', phase: 'evening',
        outcomes: [{ workItemId: 'assistant-work-item:evening-review', summary: '完成。', candidates: [] }],
      }),
    });
    const assistantRuntime = createRuntime({
      now: Date.UTC(2026, 7, 14, 16, 30),
      complete,
    });

    const first = await assistantRuntime.runLoopNow(ASSISTANT_EVENING_LOOP_ID);
    const second = await assistantRuntime.runLoopNow(ASSISTANT_EVENING_LOOP_ID);

    expect(first).toMatchObject({ status: 'success' });
    expect(second).toMatchObject({ status: 'already_completed' });
    expect(complete).toHaveBeenCalledTimes(2);
    expect(loopStore.listLoopRuns(ASSISTANT_EVENING_LOOP_ID, 10)[0].logicalRunKey)
      .toBe('assistant:default-personal-assistant:evening:Asia/Shanghai:2026-08-15');
  });

  it('previews one draft repeatedly without creating runs, evidence, or candidates', async () => {
    const now = Date.UTC(2026, 7, 14, 16, 45);
    const collect = vi.fn().mockResolvedValue({
      from: now - 86_400_000,
      to: now,
      timeZone: 'Asia/Shanghai',
      items: [
        { id: 'task-1', scope: 'tasks', updatedAt: now - 1_000, summary: '完成发布', reference: { kind: 'task_snapshot', id: 'task-1' }, priority: 70 },
        { id: 'task-2', scope: 'tasks', updatedAt: now - 2_000, summary: '修复阻塞', reference: { kind: 'task_snapshot', id: 'task-2' }, priority: 60 },
      ],
      dropped: { duplicate: 0, perScopeLimit: 0, totalBytes: 0, outsideWindow: 0, disabledScope: 0, sourceErrors: 1 },
      sourceErrors: [{ source: 'meeting_metadata', message: 'offline' }],
    });
    const complete = vi.fn().mockResolvedValue({
      text: JSON.stringify({
        schemaVersion: 'assistant_work_items_v1', phase: 'evening', outcomes: [{
          workItemId: 'draft-dreaming', summary: '发现一个值得持续跟踪的优化方向。',
          candidates: [{ kind: 'memory', title: 'Dream 记录', content: '记录本次优化方向。', scope: 'global', confidence: 0.8,
            evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }], dedupeKey: 'dream:task-1' }],
        }],
      }),
    });
    const assistantRuntime = createAssistantRuntime({
      loopStore, evidenceStore, workItemService, now: () => now, collect, llmPort: { complete },
    });

    const input = { id: 'draft-dreaming', phase: 'evening' as const, title: 'Dreaming draft', instruction: '找出改进方向' };
    const first = await assistantRuntime.previewWorkItem(input);
    const second = await assistantRuntime.previewWorkItem(input);

    expect(first).toMatchObject({
      workItemId: 'draft-dreaming', phase: 'evening', status: 'completed', summary: '发现一个值得持续跟踪的优化方向。',
      context: { from: now - 86_400_000, to: now, itemCount: 2, scopeCounts: { tasks: 2 }, sourceErrorCount: 1 },
    });
    expect(first.candidates).toHaveLength(1);
    expect(first.evidenceRefs).toEqual([{ kind: 'task_snapshot', id: 'task-1' }]);
    expect(second.status).toBe('completed');
    expect(collect).toHaveBeenCalledTimes(2);
    expect(complete).toHaveBeenCalledTimes(2);
    expect(complete.mock.calls[0][0].systemPrompt).toContain('只返回输入工作项对应的一个 outcome');
    expect(complete.mock.calls[0][0].systemPrompt).toContain('最多三条 candidates');
    expect(JSON.parse(complete.mock.calls[0][0].userMessage)).toMatchObject({ executionMode: 'preview' });
    expect(complete.mock.calls[0][0].systemPrompt).toContain('只输出一个完整 JSON 对象，不要 Markdown');
    expect(loopStore.listLoopRuns(ASSISTANT_EVENING_LOOP_ID, 10)).toEqual([]);
    expect(loopStore.listAssistantWorkItemRuns()).toEqual([]);
    expect(loopStore.listAssistantCandidates()).toEqual([]);
  });

  it('fails a preview without publishing any formal assistant state', async () => {
    const now = Date.UTC(2026, 7, 14, 16, 45);
    const assistantRuntime = createAssistantRuntime({
      loopStore,
      evidenceStore,
      workItemService,
      now: () => now,
      collect: vi.fn().mockResolvedValue({ from: now - 1_000, to: now, items: [], sourceErrors: [] }),
      llmPort: { complete: vi.fn().mockRejectedValue(new Error('provider unavailable')) },
    });

    await expect(assistantRuntime.previewWorkItem({
      id: 'draft-dreaming', phase: 'evening', title: 'Dreaming', instruction: '找出改进方向',
    })).rejects.toThrow('provider unavailable');
    expect(loopStore.listLoopRuns(ASSISTANT_EVENING_LOOP_ID, 10)).toEqual([]);
    expect(loopStore.listAssistantCandidates()).toEqual([]);
  });

  it('fails closed without publishing candidates when the provider is unavailable', async () => {
    const assistantRuntime = createRuntime({
      now: Date.UTC(2026, 7, 14, 14, 30),
      complete: vi.fn().mockRejectedValue(new Error('provider unavailable')),
    });

    const result = await assistantRuntime.runLoopNow(ASSISTANT_EVENING_LOOP_ID);

    expect(result).toMatchObject({
      status: 'failed',
      run: expect.objectContaining({
        status: 'failed',
        failureKind: 'executor_failed',
        message: 'runtime_unavailable: provider unavailable',
      }),
    });
    expect(loopStore.listAssistantCandidates()).toEqual([]);
    expect(evidenceStore.listEvidenceForOwner('loop_run', result.status === 'failed' ? result.run.id : 'missing')).toEqual([]);
  });

  it('isolates malformed work-item output and preserves successful siblings', async () => {
    const now = Date.UTC(2026, 7, 14, 14, 30);
    const attempts = new Map<string, number>();
    const complete = vi.fn().mockImplementation(async (request: { userMessage: string }) => {
      const payload = JSON.parse(request.userMessage) as { workItems: Array<{ id: string }> };
      const workItemId = payload.workItems[0].id;
      attempts.set(workItemId, (attempts.get(workItemId) ?? 0) + 1);
      if (workItemId === 'assistant-work-item:evening-review') return { text: '{not-json' };
      return {
        text: JSON.stringify({
          schemaVersion: 'assistant_work_items_v1', phase: 'evening', outcomes: [{
            workItemId, summary: '识别到一条可信候选。', candidates: [{
              kind: 'memory', title: '可信候选', content: '保留可验证结论。', scope: 'global', confidence: 0.9,
              evidenceRefs: [{ kind: 'task_snapshot', id: 'task-1' }], dedupeKey: 'memory:trusted',
            }],
          }],
        }),
      };
    });
    const assistantRuntime = createAssistantRuntime({
      loopStore,
      evidenceStore,
      workItemService,
      now: () => now,
      collect: vi.fn().mockResolvedValue({
        from: now - 1_000,
        to: now,
        timeZone: 'Asia/Shanghai',
        items: [{
          id: 'task-1', scope: 'tasks', title: '验证任务', authority: 'derived', updatedAt: now,
          updatedAtLocal: '2026-08-14 22:30:00 GMT+08:00', summary: '已验证',
          attributes: { status: 'completed' }, reference: { kind: 'task_snapshot', id: 'task-1' }, priority: 70,
        }],
        dropped: {},
        sourceErrors: [],
      }),
      llmPort: { complete },
    });

    const result = await assistantRuntime.runLoopNow(ASSISTANT_EVENING_LOOP_ID);

    expect(result).toMatchObject({ status: 'success' });
    expect(attempts.get('assistant-work-item:evening-review')).toBe(2);
    expect(attempts.get('assistant-work-item:memory-candidates')).toBe(1);
    const parentRunId = result.status === 'success' ? result.run.id : 'missing';
    expect(loopStore.listAssistantWorkItemRuns({ parentRunId })).toEqual(expect.arrayContaining([
      expect.objectContaining({ workItemId: 'assistant-work-item:evening-review', status: 'failed', error: 'assistant_json_invalid' }),
      expect.objectContaining({ workItemId: 'assistant-work-item:memory-candidates', status: 'completed', summary: '识别到一条可信候选。' }),
    ]));
    expect(loopStore.listAssistantCandidates({ statuses: ['pending'] })).toEqual([
      expect.objectContaining({ title: '可信候选', workItemId: 'assistant-work-item:memory-candidates' }),
    ]);
  });

  it('skips before snapshot collection and provider calls when a phase has no enabled items', async () => {
    const morning = workItemService.listEnabled('morning')[0];
    workItemService.setEnabled({ id: morning.id, enabled: false }, 'user');
    const collect = vi.fn();
    const complete = vi.fn();
    const assistantRuntime = createAssistantRuntime({
      loopStore, evidenceStore, workItemService, now: () => Date.UTC(2026, 7, 14, 8), collect, llmPort: { complete },
    });

    await expect(assistantRuntime.runLoopNow(ASSISTANT_MORNING_LOOP_ID)).resolves.toEqual({
      status: 'skipped', reason: 'no_enabled_work_items',
    });
    expect(collect).not.toHaveBeenCalled();
    expect(complete).not.toHaveBeenCalled();
  });

  it('delegates non-assistant loops to the existing generic runner', async () => {
    const genericResult = { status: 'skipped' as const, reason: 'missing_loop' as const };
    const genericRunner = { runLoopNow: vi.fn().mockResolvedValue(genericResult) };
    const assistantRuntime = { runLoopNow: vi.fn() } as unknown as AssistantRuntime;
    const runner = createLoopExecutionAdapter({ genericRunner, assistantRuntime });

    await expect(runner.runLoopNow('artifact-evidence-regression', { kind: 'manual' })).resolves.toBe(genericResult);
    expect(genericRunner.runLoopNow).toHaveBeenCalledWith('artifact-evidence-regression', { kind: 'manual' }, undefined);
    expect(assistantRuntime.runLoopNow).not.toHaveBeenCalled();
  });

  function createRuntime(input: {
    now: number;
    complete: ReturnType<typeof vi.fn>;
    items?: unknown[];
  }): AssistantRuntime {
    return createAssistantRuntime({
      loopStore,
      evidenceStore,
      workItemService,
      now: () => input.now,
      collect: vi.fn().mockResolvedValue({
        from: input.now - 86_400_000,
        to: input.now,
        timeZone: 'Asia/Shanghai',
        items: input.items ?? [],
        dropped: {},
      }),
      llmPort: { complete: input.complete },
    });
  }
});
