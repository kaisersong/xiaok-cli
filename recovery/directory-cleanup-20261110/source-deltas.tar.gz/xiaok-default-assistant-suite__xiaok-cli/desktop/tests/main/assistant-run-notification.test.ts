import { describe, expect, it, vi } from 'vitest';
import {
  handleAssistantRunComplete,
  type AssistantRunCompleteWindow,
} from '../../electron/assistant-run-notification.js';
import {
  ASSISTANT_EVENING_LOOP_ID,
  ASSISTANT_MORNING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
  type AssistantProfile,
} from '../../electron/assistant-types.js';
import type { TimedActionRecord } from '../../electron/timed-action-types.js';

const profile: AssistantProfile = {
  id: DEFAULT_PERSONAL_ASSISTANT_ID,
  status: 'active',
  locale: 'zh',
  timeZone: 'Asia/Shanghai',
  eveningTime: '22:30',
  morningTime: '08:30',
  workdays: [0, 1, 2, 3, 4, 5, 6],
  quietHours: { start: '22:00', end: '08:00' },
  dataScopes: ['threads'],
  createdAt: 1,
  updatedAt: 1,
};

function action(loopId: typeof ASSISTANT_MORNING_LOOP_ID | typeof ASSISTANT_EVENING_LOOP_ID): TimedActionRecord {
  return {
    id: `assistant:${DEFAULT_PERSONAL_ASSISTANT_ID}:${loopId === ASSISTANT_MORNING_LOOP_ID ? 'morning' : 'evening'}`,
    title: 'legacy title',
    description: '',
    trigger: { kind: 'daily', hour: 8, minute: 30, timeZone: profile.timeZone, daysOfWeek: profile.workdays },
    executor: { kind: 'loop', loopId },
    policy: {},
    status: 'active',
    source: 'system',
    ownerKind: 'assistant',
    ownerId: DEFAULT_PERSONAL_ASSISTANT_ID,
    nextDueAt: 2_000,
    lastDueAt: 1_000,
    runCount: 1,
    consecutiveFailures: 0,
    userApprovedAuto: true,
    createdAt: 1,
    updatedAt: 1,
  };
}

function windowPort() {
  const send = vi.fn();
  const window: AssistantRunCompleteWindow = {
    isDestroyed: vi.fn(() => false),
    isMinimized: vi.fn(() => true),
    restore: vi.fn(),
    show: vi.fn(),
    focus: vi.fn(),
    webContents: { send },
  };
  return { window, send };
}

describe('assistant run completion feedback', () => {
  it('uses the exact persisted morning summary in the OS notification and refresh event', async () => {
    const { window, send } = windowPort();
    const show = vi.fn().mockResolvedValue({ ok: true });
    const resolveLoopRun = vi.fn(() => ({
      loopRunId: 'loop-run-1',
      loopStatus: 'success' as const,
      nextActionSummary: '今天优先完成发布验收，并跟进昨晚失败任务。',
    }));

    await expect(handleAssistantRunComplete({
      event: { action: action(ASSISTANT_MORNING_LOOP_ID), runId: 'timed-run-1', status: 'success', finishedAt: 3_000 },
      profile,
      resolveLoopRun,
      notificationPort: { show },
      window,
    })).resolves.toBe(true);

    expect(resolveLoopRun).toHaveBeenCalledWith({ action: expect.any(Object), timedActionRunId: 'timed-run-1' });
    expect(send).toHaveBeenCalledWith('desktop:assistantUpdated', {
      runId: 'timed-run-1',
      loopId: ASSISTANT_MORNING_LOOP_ID,
      status: 'success',
    });
    expect(show).toHaveBeenCalledWith(expect.objectContaining({
      title: 'XiaoK助理晨间建议',
      body: '今天优先完成发布验收，并跟进昨晚失败任务。',
      onClick: expect.any(Function),
    }));
    show.mock.calls[0][0].onClick();
    expect(window.restore).toHaveBeenCalledTimes(1);
    expect(window.show).toHaveBeenCalledTimes(1);
    expect(window.focus).toHaveBeenCalledTimes(1);
  });

  it('refreshes evening results without sending a quiet-hours notification', async () => {
    const { window, send } = windowPort();
    const show = vi.fn();

    await expect(handleAssistantRunComplete({
      event: { action: action(ASSISTANT_EVENING_LOOP_ID), runId: 'timed-run-2', status: 'success', finishedAt: 3_000 },
      profile,
      resolveLoopRun: () => ({ loopRunId: 'loop-run-2', loopStatus: 'success', nextActionSummary: '晚间总结' }),
      notificationPort: { show },
      window,
    })).resolves.toBe(true);

    expect(send).toHaveBeenCalledWith('desktop:assistantUpdated', expect.objectContaining({ status: 'success' }));
    expect(show).not.toHaveBeenCalled();
  });

  it('fails safe when the exact loop result is unavailable and ignores skipped runs', async () => {
    const { window, send } = windowPort();
    const show = vi.fn();

    await handleAssistantRunComplete({
      event: { action: action(ASSISTANT_MORNING_LOOP_ID), runId: 'missing-run', status: 'success', finishedAt: 3_000 },
      profile,
      resolveLoopRun: () => undefined,
      notificationPort: { show },
      window,
    });
    await handleAssistantRunComplete({
      event: { action: action(ASSISTANT_MORNING_LOOP_ID), runId: 'skipped-run', status: 'skipped', finishedAt: 4_000 },
      profile,
      resolveLoopRun: () => ({ loopRunId: 'loop-run-3', loopStatus: 'success', nextActionSummary: '不应显示' }),
      notificationPort: { show },
      window,
    });

    expect(send).toHaveBeenCalledTimes(1);
    expect(show).not.toHaveBeenCalled();
  });

  it('localizes empty-result and runtime failure internals before notifying', async () => {
    const { window } = windowPort();
    const show = vi.fn().mockResolvedValue({ ok: true });

    await handleAssistantRunComplete({
      event: { action: action(ASSISTANT_MORNING_LOOP_ID), runId: 'empty-run', status: 'success', finishedAt: 3_000 },
      profile,
      resolveLoopRun: () => ({
        loopRunId: 'loop-empty',
        loopStatus: 'success',
        nextActionSummary: 'assistant_morning_no_results',
      }),
      notificationPort: { show },
      window,
    });
    await handleAssistantRunComplete({
      event: {
        action: action(ASSISTANT_MORNING_LOOP_ID),
        runId: 'failed-run',
        status: 'failed',
        finishedAt: 4_000,
        error: 'loop failed: runtime_unavailable: Connection error.',
      },
      profile,
      resolveLoopRun: () => undefined,
      notificationPort: { show },
      window,
    });

    expect(show).toHaveBeenNthCalledWith(1, expect.objectContaining({ body: '今天暂无高置信建议。' }));
    expect(show).toHaveBeenNthCalledWith(2, expect.objectContaining({ body: '助理运行环境暂不可用，请稍后重试。' }));
  });
});
