import { describe, expect, it, vi } from 'vitest';

import { registerSemanticDesktopIpc } from '../../electron/semantic-ipc.js';

describe('semantic desktop IPC', () => {
  it('registers only semantic assistant and KSwarm operations and fixes user authority in main', async () => {
    const handlers = new Map<string, (...args: any[]) => unknown>();
    const ipcMain = { handle: vi.fn((channel: string, handler: (...args: any[]) => unknown) => handlers.set(channel, handler)) };
    const assistant = {
      getOverview: vi.fn(() => ({ profile: { status: 'active' } })),
      activate: vi.fn(() => ({ status: 'active' })),
      pause: vi.fn(() => ({ status: 'paused' })),
      resume: vi.fn(() => ({ status: 'active' })),
      acceptCandidate: vi.fn(() => ({ status: 'accepted' })),
      rejectCandidate: vi.fn(() => ({ status: 'rejected' })),
      createWorkItem: vi.fn(), updateWorkItem: vi.fn(), setWorkItemEnabled: vi.fn(),
      reorderWorkItems: vi.fn(), deleteWorkItem: vi.fn(), restoreBuiltInWorkItem: vi.fn(),
      previewWorkItem: vi.fn(),
    };
    const kswarm = {
      planProjectTeam: vi.fn(), applyProjectTeamPlan: vi.fn(), getProjectTeamOperation: vi.fn(),
      createKSwarmProject: vi.fn(), createKSwarmAgent: vi.fn(), updateKSwarmAgent: vi.fn(),
      archiveKSwarmAgent: vi.fn(), startKSwarmAgent: vi.fn(), stopKSwarmAgent: vi.fn(), probeKSwarmAgent: vi.fn(),
    };

    registerSemanticDesktopIpc(ipcMain as never, { assistant, kswarm });

    await handlers.get('desktop:assistant:acceptCandidate')?.({}, { candidateId: 'candidate-1', requestSource: 'agent' });
    await handlers.get('desktop:assistant:rejectCandidate')?.({}, { candidateId: 'candidate-1', requestSource: 'scheduler' });
    await handlers.get('desktop:assistant:activate')?.({});
    await handlers.get('desktop:assistant:workItems:create')?.({}, { phase: 'evening', title: '复盘', instruction: '整理阻塞', requestSource: 'agent' });
    await handlers.get('desktop:assistant:workItems:update')?.({}, { id: 'work-1', phase: 'morning', title: '建议', instruction: '给建议', requestSource: 'agent' });
    await handlers.get('desktop:assistant:workItems:setEnabled')?.({}, { id: 'work-1', enabled: false, requestSource: 'scheduler' });
    await handlers.get('desktop:assistant:workItems:reorder')?.({}, { phase: 'morning', orderedIds: ['work-1'], expectedRevision: 7, requestSource: 'agent' });
    await handlers.get('desktop:assistant:workItems:delete')?.({}, { id: 'work-1', requestSource: 'agent' });
    await handlers.get('desktop:assistant:workItems:restoreBuiltIn')?.({}, { id: 'work-1', requestSource: 'agent' });
    await handlers.get('desktop:assistant:workItems:preview')?.({}, { id: 'work-1', phase: 'evening', title: 'Dreaming', instruction: '检查改进方向', requestSource: 'agent' });
    await handlers.get('desktop:kswarm:agent:update')?.({}, { agentId: 'agent-1', patch: { name: 'New' } });
    expect(assistant.acceptCandidate).toHaveBeenCalledWith({ candidateId: 'candidate-1', requestSource: 'user', collectionId: undefined });
    expect(assistant.rejectCandidate).toHaveBeenCalledWith({ candidateId: 'candidate-1', requestSource: 'user' });
    expect(assistant.activate).toHaveBeenCalledWith({ requestSource: 'user' });
    expect(assistant.createWorkItem).toHaveBeenCalledWith({ phase: 'evening', title: '复盘', instruction: '整理阻塞', requestSource: 'user' });
    expect(assistant.updateWorkItem).toHaveBeenCalledWith({ id: 'work-1', phase: 'morning', title: '建议', instruction: '给建议', requestSource: 'user' });
    expect(assistant.setWorkItemEnabled).toHaveBeenCalledWith({ id: 'work-1', enabled: false, requestSource: 'user' });
    expect(assistant.reorderWorkItems).toHaveBeenCalledWith({ phase: 'morning', orderedIds: ['work-1'], expectedRevision: 7, requestSource: 'user' });
    expect(assistant.deleteWorkItem).toHaveBeenCalledWith({ id: 'work-1', requestSource: 'user' });
    expect(assistant.restoreBuiltInWorkItem).toHaveBeenCalledWith({ id: 'work-1', requestSource: 'user' });
    expect(assistant.previewWorkItem).toHaveBeenCalledWith({ id: 'work-1', phase: 'evening', title: 'Dreaming', instruction: '检查改进方向', requestSource: 'user' });
    expect(kswarm.updateKSwarmAgent).toHaveBeenCalledWith({ id: 'agent-1', changes: { name: 'New' } });
    expect([...handlers.keys()]).not.toContain('desktop:assistant:store');
    expect([...handlers.keys()]).not.toContain('desktop:kswarm:request');
  });
});
