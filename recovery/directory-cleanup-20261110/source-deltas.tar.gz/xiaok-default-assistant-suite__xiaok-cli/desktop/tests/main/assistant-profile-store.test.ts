import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AssistantService } from '../../electron/assistant-service.js';
import {
  ASSISTANT_EVENING_LOOP_ID,
  ASSISTANT_MORNING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
} from '../../electron/assistant-types.js';
import { LoopStore } from '../../electron/loop-store.js';
import { TimedActionService } from '../../electron/timed-action-service.js';
import { TimedActionStore } from '../../electron/timed-action-store.js';

describe('AssistantService bootstrap', () => {
  let rootDir: string;
  let loopStore: LoopStore;
  let timedActionStore: TimedActionStore;

  beforeEach(() => {
    rootDir = join(tmpdir(), `xiaok-assistant-profile-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    mkdirSync(rootDir, { recursive: true });
    loopStore = new LoopStore(join(rootDir, 'loop-evidence.sqlite'));
    timedActionStore = new TimedActionStore(join(rootDir, 'timed-actions.sqlite'));
  });

  afterEach(() => {
    loopStore.close();
    timedActionStore.close();
    rmSync(rootDir, { recursive: true, force: true });
  });

  it('creates one needs-consent profile with two paused stable built-in loops and schedules', () => {
    const service = new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => 1_000 }),
      now: () => 1_000,
    });

    const first = service.bootstrap();
    const second = service.bootstrap();

    expect(first).toEqual(second);
    expect(first.profile).toMatchObject({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'needs_consent',
      timeZone: expect.any(String),
      workdays: [0, 1, 2, 3, 4, 5, 6],
    });
    expect(loopStore.getLoopDefinition(ASSISTANT_EVENING_LOOP_ID)?.status).toBe('paused');
    expect(loopStore.getLoopDefinition(ASSISTANT_MORNING_LOOP_ID)?.status).toBe('paused');
    const schedules = timedActionStore.listActions({ includeInactive: true });
    expect(schedules).toHaveLength(2);
    expect(schedules).toEqual(expect.arrayContaining([
      expect.objectContaining({
        id: 'assistant:default-personal-assistant:evening',
        status: 'paused',
        source: 'system',
        ownerKind: 'assistant',
        ownerId: DEFAULT_PERSONAL_ASSISTANT_ID,
        executor: { kind: 'loop', loopId: ASSISTANT_EVENING_LOOP_ID },
      }),
      expect.objectContaining({
        id: 'assistant:default-personal-assistant:morning',
        status: 'paused',
        source: 'system',
        ownerKind: 'assistant',
        ownerId: DEFAULT_PERSONAL_ASSISTANT_ID,
        executor: { kind: 'loop', loopId: ASSISTANT_MORNING_LOOP_ID },
      }),
    ]));
    expect(schedules.every(action => action.nextDueAt === undefined)).toBe(true);
  });

  it('projects an active profile to both loops and schedules without creating duplicates', () => {
    const timedActionService = new TimedActionService(timedActionStore, { now: () => 1_000 });
    const service = new AssistantService({ loopStore, timedActionService, now: () => 1_000 });
    service.bootstrap();

    service.setStatus('active');
    service.bootstrap();

    expect(loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)?.status).toBe('active');
    expect(loopStore.getLoopDefinition(ASSISTANT_EVENING_LOOP_ID)?.status).toBe('active');
    expect(loopStore.getLoopDefinition(ASSISTANT_MORNING_LOOP_ID)?.status).toBe('active');
    expect(timedActionStore.listActions({ includeInactive: true })).toHaveLength(2);
    expect(timedActionStore.listActions({ includeInactive: true }).every(action => action.status === 'active')).toBe(true);
  });

  it('migrates only the legacy weekday default and catches up the current Saturday morning', () => {
    const now = Date.UTC(2026, 7, 15, 1, 30);
    loopStore.ensureAssistantProfile({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'active',
      locale: 'zh',
      timeZone: 'Asia/Shanghai',
      eveningTime: '22:30',
      morningTime: '08:30',
      workdays: [1, 2, 3, 4, 5],
      quietHours: { start: '22:00', end: '08:00' },
      dataScopes: ['threads'],
      createdAt: now - 10_000,
      updatedAt: now - 10_000,
    });
    timedActionStore.createAction({
      id: 'assistant:default-personal-assistant:morning',
      title: 'Personal assistant morning briefing',
      trigger: { kind: 'daily', hour: 8, minute: 30, timeZone: 'Asia/Shanghai', daysOfWeek: [1, 2, 3, 4, 5] },
      executor: { kind: 'loop', loopId: ASSISTANT_MORNING_LOOP_ID },
      source: 'system',
      ownerKind: 'assistant',
      ownerId: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'active',
      now: now - 10_000,
      lastDueAt: Date.UTC(2026, 7, 14, 0, 30),
      nextDueAt: Date.UTC(2026, 7, 17, 0, 30),
    });

    new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => now }),
      now: () => now,
      timeZone: 'Asia/Shanghai',
    }).bootstrap();

    expect(loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)?.workdays).toEqual([0, 1, 2, 3, 4, 5, 6]);
    expect(timedActionStore.getAction('assistant:default-personal-assistant:morning')).toMatchObject({
      title: 'XiaoK Assistant morning briefing',
      trigger: { kind: 'daily', hour: 8, minute: 30, timeZone: 'Asia/Shanghai', daysOfWeek: [0, 1, 2, 3, 4, 5, 6] },
      nextDueAt: Date.UTC(2026, 7, 15, 0, 30),
    });
  });

  it('preserves a non-default custom workday set', () => {
    loopStore.ensureAssistantProfile({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'active',
      locale: 'zh',
      timeZone: 'Asia/Shanghai',
      eveningTime: '22:30',
      morningTime: '08:30',
      workdays: [1, 3, 5],
      quietHours: { start: '22:00', end: '08:00' },
      dataScopes: ['threads'],
      createdAt: 500,
      updatedAt: 500,
    });

    new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => 1_000 }),
      now: () => 1_000,
      timeZone: 'Asia/Shanghai',
    }).bootstrap();

    expect(loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)?.workdays).toEqual([1, 3, 5]);
  });

  it('fails closed when a fixed assistant schedule id belongs to another owner', () => {
    timedActionStore.createAction({
      id: 'assistant:default-personal-assistant:morning',
      title: 'User task',
      trigger: { kind: 'daily', hour: 9, minute: 0 },
      executor: { kind: 'agent_task', prompt: 'do not overwrite' },
      source: 'user',
      ownerKind: 'user',
      ownerId: 'desktop-user',
      now: 500,
    });
    const service = new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => 1_000 }),
      now: () => 1_000,
    });

    expect(() => service.bootstrap()).toThrow(/assistant schedule ownership mismatch/i);
    expect(timedActionStore.getAction('assistant:default-personal-assistant:morning')).toMatchObject({
      ownerKind: 'user',
      executor: { kind: 'agent_task', prompt: 'do not overwrite' },
    });
    expect(() => service.setStatus('active')).toThrow(/assistant schedule ownership mismatch/i);
    expect(loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)?.status).toBe('needs_consent');
  });

  it('restores an owned cancelled fixed schedule instead of crashing bootstrap', () => {
    const now = Date.UTC(2026, 7, 15, 13, 0);
    const service = new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => now }),
      now: () => now,
      timeZone: 'Asia/Shanghai',
    });
    service.bootstrap();
    timedActionStore.cancelAction('assistant:default-personal-assistant:morning', 'deleted from schedules', now);

    expect(() => service.setStatus('active')).not.toThrow();
    expect(timedActionStore.getAction('assistant:default-personal-assistant:morning')).toMatchObject({
      status: 'active',
      ownerKind: 'assistant',
      executor: { kind: 'loop', loopId: ASSISTANT_MORNING_LOOP_ID },
      nextDueAt: Date.UTC(2026, 7, 16, 0, 30),
    });
  });

  it('does not backfill the morning run when the user first activates at night', () => {
    const now = Date.UTC(2026, 7, 15, 13, 0);
    const service = new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => now }),
      now: () => now,
      timeZone: 'Asia/Shanghai',
    });
    service.bootstrap();

    service.setStatus('active');

    expect(timedActionStore.getAction('assistant:default-personal-assistant:morning')?.nextDueAt)
      .toBe(Date.UTC(2026, 7, 16, 0, 30));
  });

  it.each(['failed', 'skipped'] as const)('does not retry the same morning occurrence after a %s attempt and restart', outcome => {
    const dueAt = Date.UTC(2026, 7, 15, 0, 30);
    const failedAt = Date.UTC(2026, 7, 15, 1, 0);
    const restartAt = Date.UTC(2026, 7, 15, 2, 0);
    loopStore.ensureAssistantProfile({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'active',
      locale: 'zh',
      timeZone: 'Asia/Shanghai',
      eveningTime: '22:30',
      morningTime: '08:30',
      workdays: [1, 2, 3, 4, 5],
      quietHours: { start: '22:00', end: '08:00' },
      dataScopes: ['threads'],
      createdAt: dueAt - 10_000,
      updatedAt: dueAt - 10_000,
    });
    timedActionStore.createAction({
      id: 'assistant:default-personal-assistant:morning',
      title: 'Personal assistant morning briefing',
      trigger: { kind: 'daily', hour: 8, minute: 30, timeZone: 'Asia/Shanghai', daysOfWeek: [1, 2, 3, 4, 5] },
      executor: { kind: 'loop', loopId: ASSISTANT_MORNING_LOOP_ID },
      source: 'system',
      ownerKind: 'assistant',
      ownerId: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'active',
      now: dueAt - 10_000,
      nextDueAt: dueAt,
    });
    const [claimed] = timedActionStore.claimDueActions(failedAt, 1);
    if (outcome === 'failed') {
      timedActionStore.finishRunFailure(claimed.action.id, claimed.runId, failedAt, 'runtime unavailable');
    } else {
      timedActionStore.finishRunSkipped(claimed.action.id, claimed.runId, failedAt, {
        action: 'skip',
        reason: 'runtime unavailable',
        nextDueAt: restartAt,
      });
    }

    new AssistantService({
      loopStore,
      timedActionService: new TimedActionService(timedActionStore, { now: () => restartAt }),
      now: () => restartAt,
      timeZone: 'Asia/Shanghai',
    }).bootstrap();

    expect(timedActionStore.getAction('assistant:default-personal-assistant:morning')?.nextDueAt)
      .toBe(Date.UTC(2026, 7, 16, 0, 30));
  });
});
