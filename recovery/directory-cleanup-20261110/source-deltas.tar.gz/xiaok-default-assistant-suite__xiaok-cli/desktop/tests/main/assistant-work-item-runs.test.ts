import { mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { LoopStore } from '../../electron/loop-store.js';
import {
  ASSISTANT_EVENING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
  type AssistantWorkItem,
} from '../../electron/assistant-types.js';

describe('assistant work item run store', () => {
  let rootDir: string;
  let store: LoopStore;

  beforeEach(() => {
    rootDir = join(tmpdir(), `xiaok-assistant-item-runs-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    mkdirSync(rootDir, { recursive: true });
    store = new LoopStore(join(rootDir, 'loops.sqlite'));
    store.ensureBuiltInLoops(1_000);
    store.setLoopStatus(ASSISTANT_EVENING_LOOP_ID, 'active', 1_001);
  });

  afterEach(() => {
    store.close();
    rmSync(rootDir, { recursive: true, force: true });
  });

  it('persists idempotent per-item results and returns the latest successful history', () => {
    const parent = store.beginLoopRun(ASSISTANT_EVENING_LOOP_ID, { kind: 'manual' }, 2_000);
    expect(parent.status).toBe('started');
    if (parent.status !== 'started') throw new Error('parent run did not start');
    const workItem: AssistantWorkItem = {
      id: 'dreaming', assistantId: DEFAULT_PERSONAL_ASSISTANT_ID, phase: 'evening',
      title: 'Dreaming', instruction: '提取优化信号', enabled: true, sortOrder: 0,
      createdAt: 1_000, updatedAt: 1_000,
    };

    const first = store.beginAssistantWorkItemRun({ parentRunId: parent.run.id, workItem, now: 2_100 });
    const repeated = store.beginAssistantWorkItemRun({ parentRunId: parent.run.id, workItem, now: 2_200 });
    expect(repeated.id).toBe(first.id);

    store.finishAssistantWorkItemRun({
      id: first.id,
      status: 'completed',
      summary: '发现一条可验证的优化信号。',
      output: {
        workItemId: workItem.id,
        status: 'completed',
        summary: '发现一条可验证的优化信号。',
        recommendations: [],
        candidates: [],
      },
      now: 2_500,
    });

    expect(store.getLatestSuccessfulAssistantWorkItemRun('dreaming')).toMatchObject({
      parentRunId: parent.run.id,
      workItemId: 'dreaming',
      workItemTitle: 'Dreaming',
      status: 'completed',
      summary: '发现一条可验证的优化信号。',
      finishedAt: 2_500,
    });
    expect(store.listAssistantWorkItemRuns({ parentRunId: parent.run.id })).toHaveLength(1);
  });

  it('keeps failed item history independently from successful siblings', () => {
    const parent = store.beginLoopRun(ASSISTANT_EVENING_LOOP_ID, { kind: 'manual' }, 3_000);
    if (parent.status !== 'started') throw new Error('parent run did not start');
    const base = {
      assistantId: DEFAULT_PERSONAL_ASSISTANT_ID,
      phase: 'evening' as const,
      instruction: '执行', enabled: true, createdAt: 1, updatedAt: 1,
    };
    const failed = store.beginAssistantWorkItemRun({
      parentRunId: parent.run.id,
      workItem: { ...base, id: 'bad', title: '坏任务', sortOrder: 0 },
      now: 3_100,
    });
    const completed = store.beginAssistantWorkItemRun({
      parentRunId: parent.run.id,
      workItem: { ...base, id: 'good', title: '好任务', sortOrder: 1 },
      now: 3_200,
    });

    store.finishAssistantWorkItemRun({ id: failed.id, status: 'failed', error: 'assistant_json_invalid', now: 3_300 });
    store.finishAssistantWorkItemRun({
      id: completed.id, status: 'no_result', summary: '没有新结果。',
      output: { workItemId: 'good', status: 'no_result', recommendations: [], candidates: [] }, now: 3_400,
    });

    expect(store.listAssistantWorkItemRuns({ parentRunId: parent.run.id }).map(run => run.status)).toEqual([
      'no_result',
      'failed',
    ]);
    expect(store.getLatestSuccessfulAssistantWorkItemRun('bad')).toBeUndefined();
    expect(store.getLatestSuccessfulAssistantWorkItemRun('good')?.status).toBe('no_result');
  });
});
