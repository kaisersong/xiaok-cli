import type { LoopLLMPort } from './loop-llm-port.js';
import type { AssistantWorkItemPhase } from './assistant-types.js';

export interface AssistantEvidenceRef {
  kind: string;
  id: string;
}

export interface AssistantEvidenceCatalogEntry {
  reference: AssistantEvidenceRef;
  title?: string;
  authority?: string;
  summary?: string;
  updatedAtLocal?: string;
  attributes?: Record<string, unknown>;
}

export interface AssistantCandidateProposal {
  workItemId: string;
  candidateId?: string;
  kind: 'memory' | 'knowledge' | 'follow_up';
  title: string;
  content: string;
  scope: 'global' | 'project';
  projectId?: string;
  confidence: number;
  evidenceRefs: AssistantEvidenceRef[];
  dedupeKey: string;
}

export interface MorningRecommendation {
  title: string;
  reasonCode: string;
  evidenceRefs: AssistantEvidenceRef[];
}

export interface AssistantWorkItemOutcome {
  workItemId: string;
  status: 'completed' | 'no_result';
  summary?: string;
  recommendations: MorningRecommendation[];
  candidates: AssistantCandidateProposal[];
}

export interface AssistantOutputAnomaly {
  kind: 'unknown_work_item_id' | 'duplicate_work_item_id';
  workItemId: string;
}

export interface AssistantWorkItemFailure {
  workItemId: string;
  error: string;
}

export interface AssistantPhaseOutput {
  schemaVersion: 'assistant_work_items_v1';
  phase: AssistantWorkItemPhase;
  outcomes: AssistantWorkItemOutcome[];
  anomalies: AssistantOutputAnomaly[];
  failures?: AssistantWorkItemFailure[];
  evidenceCatalog?: AssistantEvidenceCatalogEntry[];
}

export async function completeAssistantJson<T>(input: {
  port: Pick<LoopLLMPort, 'complete'>;
  systemPrompt: string;
  snapshot: unknown;
  validate: (value: unknown) => T;
  maxTokens: number;
}): Promise<T> {
  const response = await input.port.complete({
    model: 'fast',
    systemPrompt: input.systemPrompt,
    userMessage: JSON.stringify(input.snapshot),
    maxTokens: input.maxTokens,
    temperature: 0,
  });
  return input.validate(parseAssistantJsonEnvelope(response.text));
}

function parseAssistantJsonEnvelope(text: string): unknown {
  const trimmed = text.trim();
  const direct = tryParseJson(trimmed);
  if (direct.ok) return direct.value;

  const fenced = trimmed.match(/^```(?:json)?[ \t]*\r?\n([\s\S]*?)\r?\n```$/i);
  if (fenced) {
    const inner = tryParseJson(fenced[1].trim());
    if (inner.ok) return inner.value;
  }

  const candidates = extractJsonCandidates(trimmed);
  if (candidates.length === 1) return candidates[0];
  throw new Error('assistant_json_invalid');
}

function tryParseJson(text: string): { ok: true; value: unknown } | { ok: false } {
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch {
    return { ok: false };
  }
}

function extractJsonCandidates(text: string): unknown[] {
  const candidates: unknown[] = [];
  let start = -1;
  let inString = false;
  let escaped = false;
  const closingStack: string[] = [];

  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (start < 0) {
      if (character === '{' || character === '[') {
        start = index;
        closingStack.push(character === '{' ? '}' : ']');
      }
      continue;
    }

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (character === '\\') {
        escaped = true;
      } else if (character === '"') {
        inString = false;
      }
      continue;
    }

    if (character === '"') {
      inString = true;
      continue;
    }
    if (character === '{' || character === '[') {
      closingStack.push(character === '{' ? '}' : ']');
      continue;
    }
    if (character !== '}' && character !== ']') continue;
    if (closingStack.at(-1) !== character) {
      start = -1;
      closingStack.length = 0;
      continue;
    }

    closingStack.pop();
    if (closingStack.length > 0) continue;
    const parsed = tryParseJson(text.slice(start, index + 1));
    if (parsed.ok) candidates.push(parsed.value);
    start = -1;
  }

  return candidates;
}

export function validateAssistantPhaseOutput(
  value: unknown,
  input: { phase: AssistantWorkItemPhase; workItemIds: string[]; evidenceRefs?: AssistantEvidenceRef[] },
): AssistantPhaseOutput {
  const record = asRecord(value, 'assistant_output_invalid');
  if (record.schemaVersion !== 'assistant_work_items_v1') throw new Error('assistant_schema_version_invalid');
  if (record.phase !== input.phase) throw new Error('assistant_phase_invalid');
  if (!Array.isArray(record.outcomes)) throw new Error('assistant_outcomes_invalid');

  const allowedIds = new Set(input.workItemIds);
  const seenIds = new Set<string>();
  const outcomesById = new Map<string, AssistantWorkItemOutcome>();
  const anomalies: AssistantOutputAnomaly[] = [];
  for (const raw of record.outcomes) {
    const outcome = asRecord(raw, 'assistant_outcome_invalid');
    const workItemId = requiredString(outcome.workItemId, 'workItemId');
    if (!allowedIds.has(workItemId)) {
      anomalies.push({ kind: 'unknown_work_item_id', workItemId });
      continue;
    }
    if (seenIds.has(workItemId)) {
      anomalies.push({ kind: 'duplicate_work_item_id', workItemId });
      continue;
    }
    seenIds.add(workItemId);
    const summary = requiredString(outcome.summary, 'summary');
    if (input.phase === 'morning' && Array.isArray(outcome.candidates) && outcome.candidates.length > 0) {
      throw new Error('assistant morning candidates invalid');
    }
    if (input.phase === 'evening' && Array.isArray(outcome.recommendations) && outcome.recommendations.length > 0) {
      throw new Error('assistant evening recommendations invalid');
    }
    const allowedEvidenceRefs = input.evidenceRefs
      ? new Set(input.evidenceRefs.map(reference => evidenceRefKey(reference)))
      : undefined;
    const recommendations = validateRecommendations(outcome.recommendations, allowedEvidenceRefs);
    const candidates = validateCandidates(outcome.candidates, workItemId, allowedEvidenceRefs);
    outcomesById.set(workItemId, {
      workItemId,
      status: 'completed',
      summary,
      recommendations,
      candidates,
    });
  }

  return {
    schemaVersion: 'assistant_work_items_v1',
    phase: input.phase,
    outcomes: input.workItemIds.map(workItemId => outcomesById.get(workItemId) ?? {
      workItemId,
      status: 'no_result' as const,
      recommendations: [],
      candidates: [],
    }),
    anomalies,
  };
}

function validateRecommendations(value: unknown, allowedEvidenceRefs?: Set<string>): MorningRecommendation[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 3) throw new Error('assistant recommendations invalid');
  return value.map(item => {
    const recommendation = asRecord(item, 'assistant recommendation invalid');
    return {
      title: requiredString(recommendation.title, 'title'),
      reasonCode: requiredString(recommendation.reasonCode, 'reasonCode'),
      evidenceRefs: validateEvidenceRefs(recommendation.evidenceRefs, allowedEvidenceRefs),
    };
  });
}

function validateCandidates(value: unknown, workItemId: string, allowedEvidenceRefs?: Set<string>): AssistantCandidateProposal[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 3) throw new Error('assistant candidates invalid');
  return value.map(item => validateCandidate(item, workItemId, allowedEvidenceRefs));
}

function validateCandidate(value: unknown, workItemId: string, allowedEvidenceRefs?: Set<string>): AssistantCandidateProposal {
  const record = asRecord(value, 'assistant candidate invalid');
  if (record.kind !== 'memory' && record.kind !== 'knowledge' && record.kind !== 'follow_up') {
    throw new Error('assistant candidate kind invalid');
  }
  if (record.scope !== 'global' && record.scope !== 'project') throw new Error('assistant candidate scope invalid');
  if (typeof record.confidence !== 'number' || !Number.isFinite(record.confidence)
    || record.confidence < 0 || record.confidence > 1) {
    throw new Error('assistant candidate confidence invalid');
  }
  const projectId = optionalString(record.projectId);
  if (record.scope === 'project' && !projectId) throw new Error('assistant candidate project scope missing projectId');
  return {
    workItemId,
    kind: record.kind,
    title: requiredString(record.title, 'title'),
    content: requiredString(record.content, 'content'),
    scope: record.scope,
    projectId,
    confidence: record.confidence,
    evidenceRefs: validateEvidenceRefs(record.evidenceRefs, allowedEvidenceRefs),
    dedupeKey: requiredString(record.dedupeKey, 'dedupeKey'),
  };
}

function validateEvidenceRefs(value: unknown, allowedEvidenceRefs?: Set<string>): AssistantEvidenceRef[] {
  if (!Array.isArray(value) || value.length === 0) throw new Error('assistant candidate evidence missing');
  const seen = new Set<string>();
  return value.flatMap(item => {
    const evidence = asRecord(item, 'assistant evidence invalid');
    const reference = {
      kind: requiredString(evidence.kind, 'evidence kind'),
      id: requiredString(evidence.id, 'evidence id'),
    };
    const key = evidenceRefKey(reference);
    if (allowedEvidenceRefs && !allowedEvidenceRefs.has(key)) throw new Error('assistant evidence reference unknown');
    if (seen.has(key)) return [];
    seen.add(key);
    return [reference];
  });
}

function evidenceRefKey(reference: AssistantEvidenceRef): string {
  return `${reference.kind}\u0000${reference.id}`;
}

function asRecord(value: unknown, message: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(message);
  return value as Record<string, unknown>;
}

function requiredString(value: unknown, field: string): string {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`assistant ${field} invalid`);
  return value.trim();
}

function optionalString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
