import {
  completeAssistantJson,
  validateAssistantPhaseOutput,
} from './assistant-llm.js';
import {
  createAssistantLoopExecutor,
  type AssistantLoopExecutorDependencies,
} from './assistant-loop-executor.js';
import {
  ASSISTANT_EVENING_LOOP_ID,
  ASSISTANT_MORNING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
  type AssistantProfile,
  type AssistantWorkItem,
  type AssistantWorkItemPhase,
  type AssistantWorkItemRun,
} from './assistant-types.js';
import type { AssistantActivityScope } from './assistant-snapshot-collector.js';
import type {
  AssistantCandidateProposal,
  AssistantEvidenceCatalogEntry,
  AssistantEvidenceRef,
  AssistantWorkItemOutcome,
  MorningRecommendation,
} from './assistant-llm.js';
import type { CompletionEvidenceStore } from './completion-evidence-store.js';
import type { LoopLLMPort } from './loop-llm-port.js';
import type { LoopRunner, RunLoopNowResult } from './loop-executor.js';
import type { LoopStore } from './loop-store.js';
import type { LoopRun, LoopRunTrigger } from './loop-types.js';
import type { AssistantWorkItemService } from './assistant-work-item-service.js';

const EVENING_SYSTEM_PROMPT = `你是XiaoK助理的晚间执行器。只根据输入中的结构化快照和唯一工作项返回 JSON，不得调用任何工具或产生外部副作用。
输出 assistant_work_items_v1：{"schemaVersion":"assistant_work_items_v1","phase":"evening","outcomes":[{"workItemId":"必须来自输入","summary":"...","candidates":[{"kind":"memory|knowledge|follow_up","title":"...","content":"...","scope":"global|project","projectId":"可选","confidence":0.0,"evidenceRefs":[{"kind":"...","id":"..."}],"dedupeKey":"..."}]}]}。
只返回输入工作项对应的一个 outcome；最多三条 candidates，只保留优先级最高且不重复的结果；summary 不超过 300 字，每条 candidate content 不超过 800 字。evidenceRefs 必须逐字复制 evidenceCatalog 中存在的 kind/id，不得自造同义 kind。authority=derived 只能作为历史线索，当前状态必须依据 authority=authoritative 的记录。日期判断只使用 *Local 字段。executionMode=preview 时严禁声称已保存、已记录、已更新或产生任何持久化副作用。只输出一个完整 JSON 对象，不要 Markdown、代码围栏、分析过程或额外说明。`;

const MORNING_SYSTEM_PROMPT = `你是XiaoK助理的晨间执行器。只根据输入中的结构化快照和唯一工作项返回 JSON，不得调用任何工具或产生外部副作用。
输出 assistant_work_items_v1：{"schemaVersion":"assistant_work_items_v1","phase":"morning","outcomes":[{"workItemId":"必须来自输入","summary":"...","recommendations":[{"title":"...","reasonCode":"...","evidenceRefs":[{"kind":"...","id":"..."}]}]}]}。
只返回输入工作项对应的一个 outcome；最多三条 recommendations，只保留优先级最高且不重复的结果；summary 不超过 300 字。evidenceRefs 必须逐字复制 evidenceCatalog 中存在的 kind/id，不得自造同义 kind。authority=derived 只能作为历史线索，当前状态必须依据 authority=authoritative 的记录。日期判断只使用 *Local 字段。executionMode=preview 时严禁声称已保存、已记录、已更新或产生任何持久化副作用。只输出一个完整 JSON 对象，不要 Markdown、代码围栏、分析过程或额外说明。`;

type AssistantKind = 'evening' | 'morning';

export interface CreateAssistantRuntimeOptions {
  loopStore: LoopStore;
  workItemService: Pick<AssistantWorkItemService, 'listEnabled'>;
  evidenceStore: CompletionEvidenceStore;
  llmPort: Pick<LoopLLMPort, 'complete'>;
  collect: AssistantLoopExecutorDependencies['collect'];
  retrieveContext?(input: {
    profile: AssistantProfile;
    workItem: AssistantWorkItem;
    previousOutcome?: AssistantWorkItemRun;
  }): unknown | Promise<unknown>;
  now?: () => number;
  staleAfterMs?: number;
}

export interface AssistantWorkItemPreviewInput {
  id: string;
  phase: AssistantWorkItemPhase;
  title: string;
  instruction: string;
}

export interface AssistantWorkItemPreviewResult {
  workItemId: string;
  phase: AssistantWorkItemPhase;
  status: AssistantWorkItemOutcome['status'];
  summary?: string;
  recommendations: MorningRecommendation[];
  candidates: AssistantCandidateProposal[];
  evidenceRefs: AssistantEvidenceRef[];
  evidenceDetails: AssistantEvidenceCatalogEntry[];
  generatedAt: number;
  durationMs: number;
  context: {
    from: number;
    to: number;
    itemCount: number;
    scopeCounts: Partial<Record<AssistantActivityScope, number>>;
    sourceErrorCount: number;
  };
}

export interface AssistantRuntime extends LoopRunner {
  previewWorkItem(input: AssistantWorkItemPreviewInput): Promise<AssistantWorkItemPreviewResult>;
}

export function createAssistantRuntime(options: CreateAssistantRuntimeOptions): AssistantRuntime {
  const now = options.now ?? (() => Date.now());
  const staleAfterMs = options.staleAfterMs ?? 30 * 60_000;
  const executor = createAssistantLoopExecutor({
    getProfile: () => options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID),
    collect: options.collect,
    complete: async ({ kind, snapshot, workItems, executionMode, previousOutcome, validationError }) => completeAssistantPhase(
      options,
      kind,
      snapshot,
      workItems,
      { executionMode, previousOutcome, validationError },
    ),
    getPreviousOutcome: workItemId => options.loopStore.getLatestSuccessfulAssistantWorkItemRun(workItemId),
    beginWorkItemRun: input => options.loopStore.beginAssistantWorkItemRun(input),
    finishWorkItemRun: input => {
      options.loopStore.finishAssistantWorkItemRun(input);
    },
    stageCandidates: ({ runId, candidates, now: stagedAt }) => (
      options.loopStore.stageAssistantCandidates(runId, candidates, stagedAt)
    ),
    recordEvidence: ({ runId, kind, summary, output, workItems, now: completedAt }) => {
      options.evidenceStore.upsertExpectation({
        ownerKind: 'loop_run',
        ownerId: runId,
        expectedKinds: ['log_diagnostic'],
        source: 'scheduler_executor_contract',
        confidence: 'explicit',
        metadata: { assistantContract: true, assistantKind: kind, assistantSchemaVersion: output.schemaVersion },
        now: completedAt,
      });
      options.evidenceStore.insertEvidence({
        ownerKind: 'loop_run',
        ownerId: runId,
        kind: 'log_diagnostic',
        summary,
        metadata: {
          assistantKind: kind,
          output,
          workItemIds: workItems.map(item => item.id),
          findings: [`assistant_${kind}_completed`, ...output.anomalies.map(anomaly => `assistant_${anomaly.kind}:${anomaly.workItemId}`)],
        },
        now: completedAt,
      });
      return options.evidenceStore.completeOwnerWithEvidence({
        ownerKind: 'loop_run',
        ownerId: runId,
        now: completedAt,
      }).evidenceIds;
    },
    finishSuccess: ({ runId, evidenceIds, summary, now: completedAt }) => {
      options.loopStore.finishAssistantLoopRunSuccess(runId, evidenceIds, completedAt, summary);
    },
    finishFailure: ({ runId, failureKind, message, now: failedAt }) => {
      options.loopStore.finishLoopRunFailure(runId, failureKind, message, [], failedAt);
    },
  });

  return {
    async previewWorkItem(input) {
      const preview = requirePreviewInput(input);
      const startedAt = now();
      const profile = options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID);
      if (!profile) throw new Error('assistant_preview_missing_profile');
      if (profile.status !== 'active') throw new Error(`assistant_preview_${profile.status}`);
      const workItem: AssistantWorkItem = {
        id: preview.id,
        assistantId: DEFAULT_PERSONAL_ASSISTANT_ID,
        phase: preview.phase,
        title: preview.title,
        instruction: preview.instruction,
        enabled: true,
        sortOrder: 0,
        createdAt: startedAt,
        updatedAt: startedAt,
      };
      const snapshot = await options.collect({ kind: preview.phase, profile, now: startedAt });
      const output = await completeAssistantPhase(options, preview.phase, snapshot, [workItem], {
        executionMode: 'preview',
        previousOutcome: options.loopStore.getLatestSuccessfulAssistantWorkItemRun(workItem.id),
      });
      const outcome = output.outcomes[0];
      const generatedAt = now();
      return {
        workItemId: outcome.workItemId,
        phase: preview.phase,
        status: outcome.status,
        summary: outcome.summary,
        recommendations: outcome.recommendations,
        candidates: outcome.candidates,
        evidenceRefs: uniqueEvidenceRefs([
          ...outcome.recommendations.flatMap(item => item.evidenceRefs),
          ...outcome.candidates.flatMap(item => item.evidenceRefs),
        ]),
        evidenceDetails: (output.evidenceCatalog ?? []).filter(entry => uniqueEvidenceRefs([
          ...outcome.recommendations.flatMap(item => item.evidenceRefs),
          ...outcome.candidates.flatMap(item => item.evidenceRefs),
        ]).some(reference => reference.kind === entry.reference.kind && reference.id === entry.reference.id)),
        generatedAt,
        durationMs: Math.max(0, generatedAt - startedAt),
        context: summarizePreviewContext(snapshot, startedAt),
      };
    },
    async runLoopNow(loopId, trigger) {
      const assistantKind = assistantKindForLoop(loopId);
      if (!assistantKind) return { status: 'skipped', reason: 'missing_loop' };
      const startedAt = now();
      const profile = options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID);
      if (!profile) return { status: 'skipped', reason: 'missing_loop' };
      if (profile.status !== 'active') return { status: 'skipped', reason: 'paused' };
      const workItems = options.workItemService.listEnabled(assistantKind);
      if (workItems.length === 0) return { status: 'skipped', reason: 'no_enabled_work_items' };
      const recovery = options.loopStore.recoverStaleRuns(startedAt, staleAfterMs);
      if (!recovery.ok) throw new Error(`Loop stale-run recovery failed: ${recovery.error}`);
      const effectiveTrigger = assistantTrigger({
        assistantKind,
        profile,
        trigger,
        now: startedAt,
      });
      const begin = options.loopStore.beginLoopRun(loopId, effectiveTrigger, startedAt, staleAfterMs);
      if (begin.status !== 'started') return begin;

      await executor.execute({
        kind: assistantKind,
        runId: begin.run.id,
        now: startedAt,
        workItems,
      });
      const persisted = options.loopStore.getLoopRun(begin.run.id) ?? begin.run;
      return resultFromRun(persisted);
    },
  };
}

async function completeAssistantPhase(
  options: CreateAssistantRuntimeOptions,
  kind: AssistantKind,
  snapshot: unknown,
  workItems: AssistantWorkItem[],
  context: {
    executionMode: 'preview' | 'formal';
    previousOutcome?: AssistantWorkItemRun;
    validationError?: string;
  },
) {
  const retrievedContext = workItems[0] && options.retrieveContext
    ? await options.retrieveContext({
        profile: options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)!,
        workItem: workItems[0],
        previousOutcome: context.previousOutcome,
      })
    : undefined;
  const effectiveSnapshot = retrievedContext === undefined
    ? snapshot
    : { current: snapshot, retrievedContext };
  const evidenceCatalog = collectEvidenceCatalog(effectiveSnapshot);
  const output = await completeAssistantJson({
    port: options.llmPort,
    systemPrompt: kind === 'evening' ? EVENING_SYSTEM_PROMPT : MORNING_SYSTEM_PROMPT,
    snapshot: {
      executionMode: context.executionMode,
      validationError: context.validationError,
      snapshot: effectiveSnapshot,
      evidenceCatalog,
      previousOutcome: context.previousOutcome ? {
        status: context.previousOutcome.status,
        summary: context.previousOutcome.summary,
        output: context.previousOutcome.output,
        generatedAt: context.previousOutcome.finishedAt,
      } : undefined,
      workItems: workItems.map(({ id, title, instruction }) => ({ id, title, instruction })),
    },
    validate: value => validateAssistantPhaseOutput(value, {
      phase: kind,
      workItemIds: workItems.map(item => item.id),
      evidenceRefs: evidenceCatalog.map(entry => entry.reference),
    }),
    maxTokens: kind === 'evening' ? 1_200 : 800,
  });
  return { ...output, evidenceCatalog };
}

function collectEvidenceCatalog(value: unknown): AssistantEvidenceCatalogEntry[] {
  const seen = new Set<string>();
  const result: AssistantEvidenceCatalogEntry[] = [];
  const visit = (candidate: unknown): void => {
    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) return;
    const record = candidate as Record<string, unknown>;
    if (Array.isArray(record.items)) {
      for (const raw of record.items) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) continue;
        const item = raw as Record<string, unknown>;
        const reference = item.reference;
        if (!reference || typeof reference !== 'object' || Array.isArray(reference)) continue;
        const ref = reference as Record<string, unknown>;
        if (typeof ref.kind !== 'string' || typeof ref.id !== 'string') continue;
        const key = `${ref.kind}\u0000${ref.id}`;
        if (seen.has(key)) continue;
        seen.add(key);
        result.push({
          reference: { kind: ref.kind, id: ref.id },
          title: typeof item.title === 'string' ? item.title : undefined,
          authority: typeof item.authority === 'string' ? item.authority : undefined,
          summary: typeof item.summary === 'string' ? item.summary : undefined,
          updatedAtLocal: typeof item.updatedAtLocal === 'string' ? item.updatedAtLocal : undefined,
          attributes: item.attributes && typeof item.attributes === 'object' && !Array.isArray(item.attributes)
            ? item.attributes as Record<string, unknown>
            : undefined,
        });
      }
    }
    if (record.snapshot) visit(record.snapshot);
    if (record.current) visit(record.current);
    if (record.retrievedContext) visit(record.retrievedContext);
  };
  visit(value);
  return result;
}

function requirePreviewInput(input: AssistantWorkItemPreviewInput): AssistantWorkItemPreviewInput {
  const id = requirePreviewText(input.id, 200, 'assistant_preview_id_invalid');
  const title = requirePreviewText(input.title, 80, 'assistant_work_item_title_invalid');
  const instruction = requirePreviewText(input.instruction, 2_000, 'assistant_work_item_instruction_invalid');
  if (input.phase !== 'evening' && input.phase !== 'morning') throw new Error('assistant_work_item_phase_invalid');
  return { id, phase: input.phase, title, instruction };
}

function requirePreviewText(value: unknown, maxLength: number, error: string): string {
  if (typeof value !== 'string') throw new Error(error);
  const normalized = value.trim();
  if (!normalized || normalized.length > maxLength) throw new Error(error);
  return normalized;
}

function summarizePreviewContext(snapshot: unknown, fallbackTime: number): AssistantWorkItemPreviewResult['context'] {
  const record = snapshot && typeof snapshot === 'object' && !Array.isArray(snapshot)
    ? snapshot as Record<string, unknown>
    : {};
  const items = Array.isArray(record.items) ? record.items : [];
  const scopeCounts: Partial<Record<AssistantActivityScope, number>> = {};
  for (const item of items) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
    const scope = (item as Record<string, unknown>).scope;
    if (scope === 'threads' || scope === 'projects' || scope === 'tasks' || scope === 'artifacts' || scope === 'automations' || scope === 'meetings') {
      scopeCounts[scope] = (scopeCounts[scope] ?? 0) + 1;
    }
  }
  return {
    from: typeof record.from === 'number' ? record.from : fallbackTime,
    to: typeof record.to === 'number' ? record.to : fallbackTime,
    itemCount: items.length,
    scopeCounts,
    sourceErrorCount: Array.isArray(record.sourceErrors) ? record.sourceErrors.length : 0,
  };
}

function uniqueEvidenceRefs(refs: AssistantEvidenceRef[]): AssistantEvidenceRef[] {
  const seen = new Set<string>();
  return refs.filter(reference => {
    const key = `${reference.kind}\u0000${reference.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function assistantKindForLoop(loopId: string): AssistantKind | undefined {
  if (loopId === ASSISTANT_EVENING_LOOP_ID) return 'evening';
  if (loopId === ASSISTANT_MORNING_LOOP_ID) return 'morning';
  return undefined;
}

function assistantTrigger(input: {
  assistantKind: AssistantKind;
  profile: AssistantProfile;
  trigger?: LoopRunTrigger;
  now: number;
}): LoopRunTrigger {
  const source = input.trigger?.kind === 'scheduled' ? 'scheduled' : 'manual';
  const occurrenceAt = source === 'scheduled' && typeof input.trigger?.scheduledDueAt === 'number'
    ? input.trigger.scheduledDueAt
    : input.now;
  const logicalRunKey = [
    'assistant',
    input.profile.id,
    input.assistantKind,
    input.profile.timeZone,
    localDate(occurrenceAt, input.profile.timeZone),
  ].join(':');
  return {
    ...(input.trigger ?? {}),
    kind: 'assistant',
    source,
    assistantKind: input.assistantKind,
    logicalRunKey,
  };
}

function localDate(instant: number, timeZone: string): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(instant));
  const value = (kind: string) => parts.find(part => part.type === kind)?.value;
  return `${value('year')}-${value('month')}-${value('day')}`;
}

function resultFromRun(run: LoopRun): Extract<RunLoopNowResult, { run: LoopRun }> {
  if (run.status === 'success') return { status: 'success', run };
  if (run.status === 'blocked') return { status: 'blocked', run };
  return { status: 'failed', run };
}
