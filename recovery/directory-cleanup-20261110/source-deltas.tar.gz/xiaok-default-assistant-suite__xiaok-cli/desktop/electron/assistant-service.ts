import {
  ASSISTANT_EVENING_LOOP_ID,
  ASSISTANT_MORNING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
  type AssistantProfile,
  type AssistantStatus,
} from './assistant-types.js';
import type { LoopStore } from './loop-store.js';
import type { TimedActionService } from './timed-action-service.js';

const LEGACY_DEFAULT_WORKDAYS = [1, 2, 3, 4, 5];
const DEFAULT_WORKDAYS = [0, 1, 2, 3, 4, 5, 6];
const ASSISTANT_EVENING_ACTION_ID = 'assistant:default-personal-assistant:evening';
const ASSISTANT_MORNING_ACTION_ID = 'assistant:default-personal-assistant:morning';

export interface AssistantServiceOptions {
  loopStore: LoopStore;
  timedActionService: TimedActionService;
  now?: () => number;
  timeZone?: string;
}

export class AssistantService {
  private readonly now: () => number;
  private readonly timeZone: string;

  constructor(private readonly options: AssistantServiceOptions) {
    this.now = options.now ?? (() => Date.now());
    this.timeZone = options.timeZone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
  }

  bootstrap(): { profile: AssistantProfile } {
    const now = this.now();
    let profile = this.options.loopStore.ensureAssistantProfile({
      id: DEFAULT_PERSONAL_ASSISTANT_ID,
      status: 'needs_consent',
      locale: 'zh',
      timeZone: this.timeZone,
      eveningTime: '22:30',
      morningTime: '08:30',
      workdays: DEFAULT_WORKDAYS,
      quietHours: { start: '22:00', end: '08:00' },
      dataScopes: ['threads', 'projects', 'tasks', 'artifacts', 'automations', 'meetings'],
      createdAt: now,
      updatedAt: now,
    });
    if (sameDays(profile.workdays, LEGACY_DEFAULT_WORKDAYS)) {
      profile = this.options.loopStore.setAssistantProfileWorkdays(profile.id, DEFAULT_WORKDAYS, now)!;
    }
    this.options.loopStore.ensureBuiltInLoops(now);
    this.options.timedActionService.ensureAssistantLoopSchedule({
      id: ASSISTANT_EVENING_ACTION_ID, loopId: ASSISTANT_EVENING_LOOP_ID,
      title: 'XiaoK Assistant evening reflection', time: profile.eveningTime,
      timeZone: profile.timeZone, workdays: profile.workdays, status: profile.status === 'active' ? 'active' : 'paused',
    });
    this.options.timedActionService.ensureAssistantLoopSchedule({
      id: ASSISTANT_MORNING_ACTION_ID, loopId: ASSISTANT_MORNING_LOOP_ID,
      title: 'XiaoK Assistant morning briefing', time: profile.morningTime,
      timeZone: profile.timeZone, workdays: profile.workdays, status: profile.status === 'active' ? 'active' : 'paused',
    });
    this.projectStatus(profile.status, now);
    return { profile: this.options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)! };
  }

  setStatus(status: AssistantStatus): AssistantProfile {
    const current = this.options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID);
    if (!current) throw new Error('assistant profile does not exist');
    this.options.timedActionService.assertAssistantLoopScheduleOwnership(ASSISTANT_EVENING_ACTION_ID, ASSISTANT_EVENING_LOOP_ID);
    this.options.timedActionService.assertAssistantLoopScheduleOwnership(ASSISTANT_MORNING_ACTION_ID, ASSISTANT_MORNING_LOOP_ID);
    const now = this.now();
    const profile = this.options.loopStore.setAssistantProfileStatus(DEFAULT_PERSONAL_ASSISTANT_ID, status, now);
    if (!profile) throw new Error('assistant profile does not exist');
    try {
      this.bootstrap();
      return this.options.loopStore.getAssistantProfile(DEFAULT_PERSONAL_ASSISTANT_ID)!;
    } catch (error) {
      this.options.loopStore.setAssistantProfileStatus(DEFAULT_PERSONAL_ASSISTANT_ID, current.status, now);
      this.projectStatus(current.status, now);
      throw error;
    }
  }

  private projectStatus(status: AssistantStatus, now: number): void {
    const loopStatus = status === 'active' ? 'active' : 'paused';
    this.options.loopStore.setLoopStatus(ASSISTANT_EVENING_LOOP_ID, loopStatus, now);
    this.options.loopStore.setLoopStatus(ASSISTANT_MORNING_LOOP_ID, loopStatus, now);
  }
}

function sameDays(left: number[], right: number[]): boolean {
  return left.length === right.length && left.every((day, index) => day === right[index]);
}
