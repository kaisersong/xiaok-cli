import type { AssistantProfile } from './assistant-types.js';
import {
  ASSISTANT_EVENING_LOOP_ID,
  ASSISTANT_MORNING_LOOP_ID,
  DEFAULT_PERSONAL_ASSISTANT_ID,
} from './assistant-types.js';
import type { DesktopNotificationPort, DesktopNotificationResult } from './desktop-notifications.js';
import type { TimedActionSchedulerOptions } from './timed-action-scheduler.js';
import type { LoopTimedActionDecision } from './timed-action-types.js';

type RunCompleteEvent = Parameters<NonNullable<TimedActionSchedulerOptions['onRunComplete']>>[0];

export interface AssistantRunCompleteWindow {
  isDestroyed(): boolean;
  isMinimized(): boolean;
  restore(): void;
  show(): void;
  focus(): void;
  webContents: { send(channel: string, payload: unknown): void };
}

export interface HandleAssistantRunCompleteOptions {
  event: RunCompleteEvent;
  profile: AssistantProfile | undefined;
  resolveLoopRun(input: { action: RunCompleteEvent['action']; timedActionRunId: string }): LoopTimedActionDecision | undefined;
  notificationPort: DesktopNotificationPort;
  window: AssistantRunCompleteWindow;
  onNotificationResult?: (result: DesktopNotificationResult) => void;
  onDiagnostic?: (message: string, details?: Record<string, unknown>) => void;
}

export async function handleAssistantRunComplete(options: HandleAssistantRunCompleteOptions): Promise<boolean> {
  const { event } = options;
  if (
    event.action.ownerKind !== 'assistant'
    || event.action.ownerId !== DEFAULT_PERSONAL_ASSISTANT_ID
    || event.action.executor.kind !== 'loop'
    || (event.action.executor.loopId !== ASSISTANT_MORNING_LOOP_ID && event.action.executor.loopId !== ASSISTANT_EVENING_LOOP_ID)
  ) return false;
  if (event.status === 'skipped') return false;

  const loopId = event.action.executor.loopId;
  if (!options.window.isDestroyed()) {
    options.window.webContents.send('desktop:assistantUpdated', {
      runId: event.runId,
      loopId,
      status: event.status,
    });
  }
  if (loopId === ASSISTANT_EVENING_LOOP_ID || options.window.isDestroyed()) return true;

  const labels = assistantNotificationLabels(options.profile?.locale ?? 'zh');
  let body: string | undefined;
  if (event.status === 'failed') {
    body = formatAssistantFailure(event.error, labels);
  } else {
    const resolved = options.resolveLoopRun({ action: event.action, timedActionRunId: event.runId });
    body = resolved?.nextActionSummary?.trim();
    if (!body) {
      options.onDiagnostic?.('assistant morning result unavailable', { runId: event.runId });
      return true;
    }
    if (body === 'assistant_morning_no_results') body = labels.noResults;
  }

  const result = await options.notificationPort.show({
    title: event.status === 'success' ? labels.successTitle : labels.failureTitle,
    body,
    silent: false,
    onClick: () => {
      if (options.window.isDestroyed()) return;
      if (options.window.isMinimized()) options.window.restore();
      options.window.show();
      options.window.focus();
    },
  });
  options.onNotificationResult?.(result);
  return true;
}

function assistantNotificationLabels(locale: AssistantProfile['locale']) {
  if (locale === 'en') {
    return {
      successTitle: 'XiaoK Assistant morning suggestions',
      failureTitle: 'XiaoK Assistant morning run failed',
      noResults: 'No high-confidence suggestions today.',
      runtimeUnavailable: 'The assistant runtime is temporarily unavailable. Try again later.',
      failure: (error?: string) => error ? `Reason: ${error}` : 'Open XiaoK to review the failure details.',
    };
  }
  return {
    successTitle: 'XiaoK助理晨间建议',
    failureTitle: 'XiaoK助理晨间运行失败',
    noResults: '今天暂无高置信建议。',
    runtimeUnavailable: '助理运行环境暂不可用，请稍后重试。',
    failure: (error?: string) => error ? `失败原因：${error}` : '请打开 XiaoK 查看失败详情。',
  };
}

function formatAssistantFailure(
  error: string | undefined,
  labels: ReturnType<typeof assistantNotificationLabels>,
): string {
  const reason = error?.replace(/^loop failed:\s*/i, '').trim();
  if (reason && /runtime_unavailable|connection error/i.test(reason)) return labels.runtimeUnavailable;
  return labels.failure(reason);
}
