import { randomUUID } from 'node:crypto';

import {
  DEFAULT_PERSONAL_ASSISTANT_ID,
  type AssistantMutationSource,
  type AssistantWorkItem,
  type AssistantWorkItemAudit,
  type AssistantWorkItemBuiltInKey,
  type AssistantWorkItemPhase,
  type AssistantWorkItemSnapshot,
} from './assistant-types.js';
import type { LoopStore } from './loop-store.js';

const MAX_ITEMS = 20;
const MAX_ENABLED_PER_PHASE = 8;

const BUILT_IN_DEFINITIONS: ReadonlyArray<{
  id: string;
  phase: AssistantWorkItemPhase;
  title: string;
  instruction: string;
  sortOrder: number;
  builtInKey: AssistantWorkItemBuiltInKey;
}> = [
  {
    id: 'assistant-work-item:evening-review',
    phase: 'evening',
    title: '整理当天完成、阻塞和下一步',
    instruction: '根据当天真实工作快照，整理已完成事项、阻塞原因和明确的下一步。',
    sortOrder: 0,
    builtInKey: 'evening_review',
  },
  {
    id: 'assistant-work-item:memory-candidates',
    phase: 'evening',
    title: '识别值得沉淀的内容',
    instruction: '识别值得整理为记忆、知识或跟进的候选；只生成候选，不直接写入。',
    sortOrder: 1,
    builtInKey: 'memory_candidates',
  },
  {
    id: 'assistant-work-item:morning-priorities',
    phase: 'morning',
    title: '给出晨间优先建议',
    instruction: '根据真实状态给出今天最值得优先处理的事项和理由。',
    sortOrder: 0,
    builtInKey: 'morning_priorities',
  },
];

export interface AssistantWorkItemServiceOptions {
  loopStore: LoopStore;
  now?: () => number;
  createId?: () => string;
}

export class AssistantWorkItemService {
  private readonly now: () => number;
  private readonly createId: () => string;

  constructor(private readonly options: AssistantWorkItemServiceOptions) {
    this.now = options.now ?? (() => Date.now());
    this.createId = options.createId ?? randomUUID;
  }

  bootstrap(): AssistantWorkItemSnapshot {
    const now = this.now();
    return this.options.loopStore.ensureAssistantWorkItems(BUILT_IN_DEFINITIONS.map(definition => ({
      ...definition,
      assistantId: DEFAULT_PERSONAL_ASSISTANT_ID,
      enabled: true,
      createdAt: now,
      updatedAt: now,
    })), now);
  }

  getSnapshot(): AssistantWorkItemSnapshot {
    return this.options.loopStore.getAssistantWorkItemSnapshot(DEFAULT_PERSONAL_ASSISTANT_ID);
  }

  listEnabled(phase: AssistantWorkItemPhase): AssistantWorkItem[] {
    requirePhase(phase);
    return this.options.loopStore.listAssistantWorkItems(DEFAULT_PERSONAL_ASSISTANT_ID, phase)
      .filter(item => item.enabled);
  }

  create(input: { phase: AssistantWorkItemPhase; title: string; instruction: string }, source: AssistantMutationSource): AssistantWorkItemSnapshot {
    return this.mutate('create', undefined, source, () => {
      const phase = requirePhase(input.phase);
      const title = requireTitle(input.title);
      const instruction = requireInstruction(input.instruction);
      const snapshot = this.getSnapshot();
      if (snapshot.workItems.length >= MAX_ITEMS) throw new Error('assistant_work_item_total_limit');
      requireEnabledCapacity(snapshot, phase);
      const now = this.now();
      return this.options.loopStore.createAssistantWorkItem({
        id: this.createId(),
        assistantId: DEFAULT_PERSONAL_ASSISTANT_ID,
        phase,
        title,
        instruction,
        enabled: true,
        sortOrder: snapshot.workItems.filter(item => item.phase === phase).length,
        createdAt: now,
        updatedAt: now,
      });
    });
  }

  update(input: { id: string; phase?: AssistantWorkItemPhase; title?: string; instruction?: string }, source: AssistantMutationSource): AssistantWorkItemSnapshot {
    return this.mutate('update', input.id, source, () => {
      const current = this.requireItem(input.id);
      const phase = input.phase === undefined ? current.phase : requirePhase(input.phase);
      if (current.builtInKey && phase !== current.phase) throw new Error('assistant_work_item_built_in_phase_forbidden');
      const next = {
        ...current,
        phase,
        title: input.title === undefined ? current.title : requireTitle(input.title),
        instruction: input.instruction === undefined ? current.instruction : requireInstruction(input.instruction),
        updatedAt: this.now(),
      };
      if (next.enabled && next.phase !== current.phase) requireEnabledCapacity(this.getSnapshot(), next.phase);
      return this.options.loopStore.updateAssistantWorkItem(next, current.phase);
    });
  }

  setEnabled(input: { id: string; enabled: boolean }, source: AssistantMutationSource): AssistantWorkItemSnapshot {
    return this.mutate('set_enabled', input.id, source, () => {
      if (typeof input.enabled !== 'boolean') throw new Error('assistant_work_item_enabled_invalid');
      const current = this.requireItem(input.id);
      if (input.enabled && !current.enabled) requireEnabledCapacity(this.getSnapshot(), current.phase);
      return this.options.loopStore.updateAssistantWorkItem({ ...current, enabled: input.enabled, updatedAt: this.now() }, current.phase);
    });
  }

  reorder(input: { phase: AssistantWorkItemPhase; orderedIds: string[]; expectedRevision: number }, source: AssistantMutationSource): AssistantWorkItemSnapshot {
    return this.mutate('reorder', undefined, source, () => this.options.loopStore.reorderAssistantWorkItems({
      assistantId: DEFAULT_PERSONAL_ASSISTANT_ID,
      phase: requirePhase(input.phase),
      orderedIds: Array.isArray(input.orderedIds) ? input.orderedIds.map(requireId) : [],
      expectedRevision: Number.isSafeInteger(input.expectedRevision) ? input.expectedRevision : -1,
      now: this.now(),
    }));
  }

  delete(input: { id: string }, source: AssistantMutationSource): AssistantWorkItemSnapshot {
    return this.mutate('delete', input.id, source, () => {
      const current = this.requireItem(input.id);
      if (current.builtInKey) throw new Error('assistant_work_item_built_in_delete_forbidden');
      return this.options.loopStore.deleteAssistantWorkItem(current.id, current.assistantId, current.phase);
    });
  }

  restoreBuiltIn(input: { id: string }, source: AssistantMutationSource): AssistantWorkItemSnapshot {
    return this.mutate('restore_built_in', input.id, source, () => {
      const current = this.requireItem(input.id);
      const definition = BUILT_IN_DEFINITIONS.find(item => item.builtInKey === current.builtInKey);
      if (!definition) throw new Error('assistant_work_item_not_built_in');
      return this.options.loopStore.updateAssistantWorkItem({
        ...current,
        phase: definition.phase,
        title: definition.title,
        instruction: definition.instruction,
        sortOrder: definition.sortOrder,
        updatedAt: this.now(),
      }, current.phase);
    });
  }

  private requireItem(id: string): AssistantWorkItem {
    const item = this.options.loopStore.getAssistantWorkItem(requireId(id));
    if (!item || item.assistantId !== DEFAULT_PERSONAL_ASSISTANT_ID) throw new Error('assistant_work_item_not_found');
    return item;
  }

  private mutate(
    action: AssistantWorkItemAudit['action'],
    workItemId: string | undefined,
    source: AssistantMutationSource,
    mutation: () => AssistantWorkItemSnapshot,
  ): AssistantWorkItemSnapshot {
    if (source !== 'user') {
      this.audit({ action, workItemId, source, result: 'rejected', reason: 'assistant_work_items_user_only' });
      throw new Error('assistant_work_items_user_only');
    }
    try {
      const result = mutation();
      this.audit({ action, workItemId, source, result: 'success' });
      return result;
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      this.audit({ action, workItemId, source, result: 'rejected', reason });
      throw error;
    }
  }

  private audit(input: {
    action: AssistantWorkItemAudit['action'];
    workItemId?: string;
    source: AssistantMutationSource;
    result: AssistantWorkItemAudit['result'];
    reason?: string;
  }): void {
    this.options.loopStore.recordAssistantWorkItemAudit({
      id: this.createId(),
      workItemId: input.workItemId,
      action: input.action,
      requestSource: input.source,
      result: input.result,
      reason: input.reason,
      createdAt: this.now(),
    });
  }
}

function requireEnabledCapacity(snapshot: AssistantWorkItemSnapshot, phase: AssistantWorkItemPhase): void {
  if (snapshot.workItems.filter(item => item.phase === phase && item.enabled).length >= MAX_ENABLED_PER_PHASE) {
    throw new Error('assistant_work_item_enabled_limit');
  }
}

function requirePhase(value: unknown): AssistantWorkItemPhase {
  if (value !== 'evening' && value !== 'morning') throw new Error('assistant_work_item_phase_invalid');
  return value;
}

function requireTitle(value: unknown): string {
  if (typeof value !== 'string') throw new Error('assistant_work_item_title_invalid');
  const title = value.trim();
  if (!title || title.length > 80) throw new Error('assistant_work_item_title_invalid');
  return title;
}

function requireInstruction(value: unknown): string {
  if (typeof value !== 'string') throw new Error('assistant_work_item_instruction_invalid');
  const instruction = value.trim();
  if (!instruction || instruction.length > 2_000) throw new Error('assistant_work_item_instruction_invalid');
  return instruction;
}

function requireId(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) throw new Error('assistant_work_item_id_invalid');
  return value.trim();
}
