import type { AssistantWorkItemPhase, AssistantWorkItemRun } from './assistant-types.js';
import type { AssistantCandidateProposal, AssistantEvidenceCatalogEntry, AssistantEvidenceRef, MorningRecommendation } from './assistant-llm.js';

interface OutcomeRun {
  id: string;
  status: string;
  finishedAt?: number;
}

interface OutcomeEvidence {
  createdAt?: number;
  metadata: Record<string, unknown>;
}

export interface AssistantWorkItemOutcomeView {
  runId: string;
  workItemRunId?: string;
  phase: AssistantWorkItemPhase;
  workItemId: string;
  status: 'completed' | 'no_result' | 'failed';
  summary?: string;
  error?: string;
  evidenceRefs: AssistantEvidenceRef[];
  evidenceDetails?: AssistantEvidenceCatalogEntry[];
  recommendations: MorningRecommendation[];
  candidates: AssistantCandidateProposal[];
  generatedAt: number;
}

export function listLatestAssistantWorkItemOutcomes(input: {
  listWorkItemRuns?(): AssistantWorkItemRun[];
  listRuns?(phase: AssistantWorkItemPhase): OutcomeRun[];
  listEvidence?(runId: string): OutcomeEvidence[];
}): AssistantWorkItemOutcomeView[] {
  if (input.listWorkItemRuns) {
    const durable = listDurableOutcomes(input.listWorkItemRuns());
    if (durable.length > 0) return durable;
  }
  if (!input.listRuns || !input.listEvidence) return [];
  const listRuns = input.listRuns;
  const listEvidence = input.listEvidence;
  return (['evening', 'morning'] as const).flatMap(phase => {
    const run = listRuns(phase).find(candidate => candidate.status === 'success');
    if (!run) return [];
    for (const evidence of listEvidence(run.id)) {
      if (evidence.metadata.assistantKind !== phase) continue;
      const output = asRecord(evidence.metadata.output);
      if (output?.schemaVersion !== 'assistant_work_items_v1' || output.phase !== phase || !Array.isArray(output.outcomes)) continue;
      const generatedAt = evidence.createdAt ?? run.finishedAt ?? 0;
      return output.outcomes.slice(0, 8).flatMap(value => parseOutcome(value, run.id, phase, generatedAt));
    }
    return [];
  });
}

function listDurableOutcomes(runs: AssistantWorkItemRun[]): AssistantWorkItemOutcomeView[] {
  const seen = new Set<string>();
  return runs.flatMap(run => {
    if (run.status === 'running') return [];
    if (seen.has(run.workItemId)) return [];
    seen.add(run.workItemId);
    if (run.status === 'failed') {
      return [{
        runId: run.parentRunId,
        workItemRunId: run.id,
        phase: run.phase,
        workItemId: run.workItemId,
        status: 'failed' as const,
        error: run.error,
        evidenceRefs: [],
        evidenceDetails: [],
        recommendations: [],
        candidates: [],
        generatedAt: run.finishedAt ?? run.updatedAt,
      }];
    }
    const parsed = parseOutcome(run.output, run.parentRunId, run.phase, run.finishedAt ?? run.updatedAt);
    return parsed.map(outcome => ({ ...outcome, workItemRunId: run.id }));
  });
}

function parseOutcome(
  value: unknown,
  runId: string,
  phase: AssistantWorkItemPhase,
  generatedAt: number,
): AssistantWorkItemOutcomeView[] {
  const outcome = asRecord(value);
  const workItemId = readString(outcome?.workItemId);
  const status = outcome?.status;
  if (!outcome || !workItemId || (status !== 'completed' && status !== 'no_result')) return [];
  const recommendations = Array.isArray(outcome.recommendations)
    ? outcome.recommendations.flatMap(parseRecommendation)
    : [];
  const candidates = Array.isArray(outcome.candidates)
    ? outcome.candidates.flatMap(parseCandidate)
    : [];
  const evidenceRefs = uniqueEvidenceRefs([
    ...recommendations.flatMap(item => item.evidenceRefs),
    ...candidates.flatMap(item => item.evidenceRefs),
  ]);
  const evidenceDetails = parseEvidenceCatalog(outcome.evidenceCatalog)
    .filter(entry => evidenceRefs.some(reference => reference.kind === entry.reference.kind && reference.id === entry.reference.id));
  return [{
    runId,
    phase,
    workItemId,
    status,
    summary: readString(outcome.summary),
    evidenceRefs,
    evidenceDetails,
    recommendations,
    candidates,
    generatedAt,
  }];
}

function parseEvidenceCatalog(value: unknown): AssistantEvidenceCatalogEntry[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap(raw => {
    const record = asRecord(raw);
    const reference = asRecord(record?.reference);
    const kind = readString(reference?.kind);
    const id = readString(reference?.id);
    if (!kind || !id) return [];
    const attributes = asRecord(record?.attributes);
    return [{
      reference: { kind, id },
      title: readString(record?.title),
      authority: readString(record?.authority),
      summary: readString(record?.summary),
      updatedAtLocal: readString(record?.updatedAtLocal),
      attributes,
    }];
  });
}

function parseRecommendation(value: unknown): MorningRecommendation[] {
  const record = asRecord(value);
  const title = readString(record?.title);
  const reasonCode = readString(record?.reasonCode);
  const evidenceRefs = parseEvidenceRefs(record?.evidenceRefs);
  return title && reasonCode && evidenceRefs.length > 0 ? [{ title, reasonCode, evidenceRefs }] : [];
}

function parseCandidate(value: unknown): AssistantCandidateProposal[] {
  const record = asRecord(value);
  const workItemId = readString(record?.workItemId);
  const title = readString(record?.title);
  const content = readString(record?.content);
  const dedupeKey = readString(record?.dedupeKey);
  const evidenceRefs = parseEvidenceRefs(record?.evidenceRefs);
  const kind = record?.kind;
  const scope = record?.scope;
  const confidence = record?.confidence;
  if (!workItemId || !title || !content || !dedupeKey || evidenceRefs.length === 0
    || (kind !== 'memory' && kind !== 'knowledge' && kind !== 'follow_up')
    || (scope !== 'global' && scope !== 'project')
    || typeof confidence !== 'number' || !Number.isFinite(confidence)) return [];
  return [{
    workItemId,
    candidateId: readString(record?.candidateId),
    kind,
    title,
    content,
    scope,
    projectId: readString(record?.projectId),
    confidence,
    evidenceRefs,
    dedupeKey,
  }];
}

function parseEvidenceRefs(value: unknown): AssistantEvidenceRef[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap(reference => {
    const record = asRecord(reference);
    const kind = readString(record?.kind);
    const id = readString(record?.id);
    return kind && id ? [{ kind, id }] : [];
  });
}

function uniqueEvidenceRefs(refs: AssistantEvidenceRef[]): AssistantEvidenceRef[] {
  const seen = new Set<string>();
  return refs.filter(reference => {
    const key = `${reference.kind}\u0000${reference.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function readString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
