import type { IpcMain } from 'electron';
import type { KSwarmSemanticService } from './kswarm-semantic-service.js';
import type { AssistantWorkItemPhase } from './assistant-types.js';

export interface AssistantSemanticController {
  getOverview(): unknown | Promise<unknown>;
  activate(input: { requestSource: 'user' }): unknown | Promise<unknown>;
  pause(input: { requestSource: 'user' }): unknown | Promise<unknown>;
  resume(input: { requestSource: 'user' }): unknown | Promise<unknown>;
  acceptCandidate(input: { candidateId: string; collectionId?: string; requestSource: 'user' }): unknown | Promise<unknown>;
  rejectCandidate(input: { candidateId: string; requestSource: 'user' }): unknown | Promise<unknown>;
  createWorkItem(input: { phase: AssistantWorkItemPhase; title: string; instruction: string; requestSource: 'user' }): unknown | Promise<unknown>;
  updateWorkItem(input: { id: string; phase?: AssistantWorkItemPhase; title?: string; instruction?: string; requestSource: 'user' }): unknown | Promise<unknown>;
  setWorkItemEnabled(input: { id: string; enabled: boolean; requestSource: 'user' }): unknown | Promise<unknown>;
  reorderWorkItems(input: { phase: AssistantWorkItemPhase; orderedIds: string[]; expectedRevision: number; requestSource: 'user' }): unknown | Promise<unknown>;
  deleteWorkItem(input: { id: string; requestSource: 'user' }): unknown | Promise<unknown>;
  restoreBuiltInWorkItem(input: { id: string; requestSource: 'user' }): unknown | Promise<unknown>;
  previewWorkItem(input: { id: string; phase: AssistantWorkItemPhase; title: string; instruction: string; requestSource: 'user' }): unknown | Promise<unknown>;
}

export function registerSemanticDesktopIpc(
  ipcMain: Pick<IpcMain, 'handle'>,
  options: {
    assistant: AssistantSemanticController;
    kswarm: KSwarmSemanticService;
  },
): void {
  const { assistant, kswarm } = options;
  ipcMain.handle('desktop:assistant:getOverview', () => assistant.getOverview());
  ipcMain.handle('desktop:assistant:activate', () => assistant.activate({ requestSource: 'user' }));
  ipcMain.handle('desktop:assistant:pause', () => assistant.pause({ requestSource: 'user' }));
  ipcMain.handle('desktop:assistant:resume', () => assistant.resume({ requestSource: 'user' }));
  ipcMain.handle('desktop:assistant:acceptCandidate', (_event, input) => assistant.acceptCandidate({
    candidateId: readId(input?.candidateId),
    collectionId: readOptionalId(input?.collectionId),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:rejectCandidate', (_event, input) => assistant.rejectCandidate({
    candidateId: readId(input?.candidateId),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:create', (_event, input) => assistant.createWorkItem({
    phase: readAssistantPhase(input?.phase),
    title: readText(input?.title, 'assistant_work_item_title_required'),
    instruction: readText(input?.instruction, 'assistant_work_item_instruction_required'),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:update', (_event, input) => assistant.updateWorkItem({
    id: readId(input?.id),
    phase: readOptionalAssistantPhase(input?.phase),
    title: readOptionalText(input?.title, 'assistant_work_item_title_invalid'),
    instruction: readOptionalText(input?.instruction, 'assistant_work_item_instruction_invalid'),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:setEnabled', (_event, input) => assistant.setWorkItemEnabled({
    id: readId(input?.id),
    enabled: readBoolean(input?.enabled),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:reorder', (_event, input) => assistant.reorderWorkItems({
    phase: readAssistantPhase(input?.phase),
    orderedIds: readIds(input?.orderedIds),
    expectedRevision: readRevision(input?.expectedRevision),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:delete', (_event, input) => assistant.deleteWorkItem({
    id: readId(input?.id),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:restoreBuiltIn', (_event, input) => assistant.restoreBuiltInWorkItem({
    id: readId(input?.id),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:assistant:workItems:preview', (_event, input) => assistant.previewWorkItem({
    id: readId(input?.id),
    phase: readAssistantPhase(input?.phase),
    title: readText(input?.title, 'assistant_work_item_title_required'),
    instruction: readText(input?.instruction, 'assistant_work_item_instruction_required'),
    requestSource: 'user',
  }));

  ipcMain.handle('desktop:kswarm:team:plan', (_event, input) => kswarm.planProjectTeam({ projectId: readId(input?.projectId) }));
  ipcMain.handle('desktop:kswarm:team:apply', (_event, input) => kswarm.applyProjectTeamPlan({
    projectId: readId(input?.projectId),
    planId: readId(input?.planId),
    projectRevision: readRevision(input?.projectRevision),
  }));
  ipcMain.handle('desktop:kswarm:team:getOperation', (_event, input) => kswarm.getProjectTeamOperation({ projectId: readId(input?.projectId) }));
  ipcMain.handle('desktop:kswarm:project:create', (_event, input) => kswarm.createKSwarmProject(readRecord(input)));
  ipcMain.handle('desktop:kswarm:project:updateExecutionMode', (_event, input) => kswarm.updateKSwarmProjectExecutionMode({
    projectId: readId(input?.projectId),
    executionMode: readExecutionMode(input?.executionMode),
  }));
  ipcMain.handle('desktop:kswarm:project:delete', (_event, input) => kswarm.deleteKSwarmProject({ projectId: readId(input?.projectId) }));
  ipcMain.handle('desktop:kswarm:agent:create', (_event, input) => kswarm.createKSwarmAgent(readRecord(input)));
  ipcMain.handle('desktop:kswarm:agent:update', (_event, input) => kswarm.updateKSwarmAgent({
    id: readId(input?.agentId), changes: readRecord(input?.patch),
  }));
  ipcMain.handle('desktop:kswarm:agent:archive', (_event, input) => kswarm.archiveKSwarmAgent({ id: readId(input?.agentId) }));
  ipcMain.handle('desktop:kswarm:agent:start', (_event, input) => kswarm.startKSwarmAgent({ id: readId(input?.agentId) }));
  ipcMain.handle('desktop:kswarm:agent:stop', (_event, input) => kswarm.stopKSwarmAgent({ id: readId(input?.agentId) }));
  ipcMain.handle('desktop:kswarm:agent:probe', (_event, input) => kswarm.probeKSwarmAgent({ id: readId(input?.agentId) }));
}

function readId(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) throw new Error('id_required');
  return value.trim();
}

function readOptionalId(value: unknown): string | undefined {
  return value === undefined ? undefined : readId(value);
}

function readAssistantPhase(value: unknown): AssistantWorkItemPhase {
  if (value === 'evening' || value === 'morning') return value;
  throw new Error('assistant_work_item_phase_invalid');
}

function readOptionalAssistantPhase(value: unknown): AssistantWorkItemPhase | undefined {
  return value === undefined ? undefined : readAssistantPhase(value);
}

function readText(value: unknown, error: string): string {
  if (typeof value !== 'string') throw new Error(error);
  return value;
}

function readOptionalText(value: unknown, error: string): string | undefined {
  return value === undefined ? undefined : readText(value, error);
}

function readBoolean(value: unknown): boolean {
  if (typeof value !== 'boolean') throw new Error('assistant_work_item_enabled_invalid');
  return value;
}

function readIds(value: unknown): string[] {
  if (!Array.isArray(value)) throw new Error('assistant_work_item_order_invalid');
  return value.map(readId);
}

function readRevision(value: unknown): number {
  if (!Number.isSafeInteger(value) || Number(value) < 0) throw new Error('invalid_project_revision');
  return Number(value);
}

function readExecutionMode(value: unknown): 'direct' | 'auto' | 'workflow_preferred' {
  if (value === 'direct' || value === 'auto' || value === 'workflow_preferred') return value;
  throw new Error('invalid_execution_mode');
}

function readRecord(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('object_required');
  return value as Record<string, unknown>;
}
