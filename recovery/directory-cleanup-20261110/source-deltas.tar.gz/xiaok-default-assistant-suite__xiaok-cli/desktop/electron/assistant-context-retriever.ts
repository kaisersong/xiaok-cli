import type { MemoryStore } from '../../src/ai/memory/store.js';
import type { KbRetriever, KbStore } from './kb-store.js';
import type { AssistantActivityRecord } from './assistant-snapshot-collector.js';
import type { AssistantProfile, AssistantWorkItem, AssistantWorkItemRun } from './assistant-types.js';
import { formatAssistantLocalInstant } from './assistant-desktop-snapshot.js';

const MEMORY_LIMIT = 6;
const KNOWLEDGE_LIMIT = 8;
const CONTENT_LIMIT = 1_200;

export interface AssistantRetrievedContext {
  items: AssistantActivityRecord[];
  sourceErrors: Array<{ source: 'memory' | 'knowledge'; message: string }>;
}

export function createAssistantContextRetriever(input: {
  memoryStore: Pick<MemoryStore, 'search' | 'listRelevant'>;
  kbStore: Pick<KbStore, 'listCollections'>;
  kbRetriever: Pick<KbRetriever, 'search'>;
}) {
  return {
    async retrieve(request: {
      profile: AssistantProfile;
      workItem: AssistantWorkItem;
      previousOutcome?: Pick<AssistantWorkItemRun, 'summary' | 'finishedAt'>;
    }): Promise<AssistantRetrievedContext> {
      const query = buildQuery(request.workItem, request.previousOutcome);
      const items: AssistantActivityRecord[] = [];
      const sourceErrors: AssistantRetrievedContext['sourceErrors'] = [];

      if (requestsMemory(request.workItem)) {
        try {
          const memories = input.memoryStore.search
            ? await input.memoryStore.search(query, MEMORY_LIMIT)
            : await input.memoryStore.listRelevant({ cwd: '', query });
          for (const memory of memories.slice(0, MEMORY_LIMIT)) {
            items.push({
              id: `memory:${memory.id}`,
              scope: 'memories',
              title: memory.title,
              authority: 'authoritative',
              updatedAt: memory.updatedAt,
              updatedAtLocal: formatAssistantLocalInstant(memory.updatedAt, request.profile.timeZone),
              summary: memory.summary.slice(0, CONTENT_LIMIT),
              attributes: {
                scope: memory.scope,
                type: memory.type ?? 'user',
                updatedAtLocal: formatAssistantLocalInstant(memory.updatedAt, request.profile.timeZone),
              },
              reference: { kind: 'memory', id: memory.id },
              priority: 90,
            });
          }
        } catch (error) {
          sourceErrors.push({ source: 'memory', message: errorMessage(error) });
        }
      }

      if (request.profile.dataScopes.includes('artifacts')) {
        try {
          const collections = input.kbStore.listCollections();
          const results = (await Promise.all(collections.map(collection => input.kbRetriever.search({
            query,
            collectionId: collection.id,
            topK: 3,
          })))).flat()
            .sort((left, right) => right.fusedScore - left.fusedScore || left.chunkId.localeCompare(right.chunkId))
            .slice(0, KNOWLEDGE_LIMIT);
          for (const result of results) {
            items.push({
              id: `knowledge-chunk:${result.chunkId}`,
              scope: 'knowledge',
              title: result.sourceTitle,
              authority: 'authoritative',
              updatedAt: request.previousOutcome?.finishedAt ?? Date.now(),
              summary: result.text.slice(0, CONTENT_LIMIT),
              attributes: {
                collectionId: result.collectionId,
                sourceId: result.sourceId,
                ...(result.pageIndex === null ? {} : { pageIndex: result.pageIndex }),
                ...(result.slideIndex === null ? {} : { slideIndex: result.slideIndex }),
                ...(result.sheetName === null ? {} : { sheetName: result.sheetName }),
              },
              reference: { kind: 'knowledge_chunk', id: result.chunkId },
              priority: 85,
            });
          }
        } catch (error) {
          sourceErrors.push({ source: 'knowledge', message: errorMessage(error) });
        }
      }

      return { items, sourceErrors };
    },
  };
}

function requestsMemory(workItem: Pick<AssistantWorkItem, 'title' | 'instruction'>): boolean {
  return /记忆|memory/i.test(`${workItem.title}\n${workItem.instruction}`);
}

function buildQuery(
  workItem: Pick<AssistantWorkItem, 'title' | 'instruction'>,
  previousOutcome?: Pick<AssistantWorkItemRun, 'summary'>,
): string {
  return [workItem.title, workItem.instruction, previousOutcome?.summary]
    .map(value => value?.trim())
    .filter(Boolean)
    .join('\n')
    .slice(0, 2_000);
}

function errorMessage(error: unknown): string {
  return (error instanceof Error ? error.message : String(error)).slice(0, 500);
}
