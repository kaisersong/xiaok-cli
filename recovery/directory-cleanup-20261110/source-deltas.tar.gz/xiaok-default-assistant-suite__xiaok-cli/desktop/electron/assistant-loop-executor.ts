import type { AssistantCandidate, AssistantProfile, AssistantWorkItem, AssistantWorkItemRun } from './assistant-types.js';
import type { AssistantCandidateProposal, AssistantPhaseOutput } from './assistant-llm.js';

export type AssistantLoopProfile = AssistantProfile;

export interface AssistantLoopExecutorDependencies {
  getProfile(): AssistantLoopProfile | undefined | Promise<AssistantLoopProfile | undefined>;
  collect(input: {
    kind: 'evening' | 'morning';
    profile: AssistantLoopProfile;
    now: number;
  }): unknown | Promise<unknown>;
  complete(input: {
    kind: 'evening' | 'morning';
    profile: AssistantLoopProfile;
    snapshot: unknown;
    workItems: AssistantWorkItem[];
    executionMode: 'formal';
    previousOutcome?: AssistantWorkItemRun;
    validationError?: string;
  }): AssistantPhaseOutput | Promise<AssistantPhaseOutput>;
  getPreviousOutcome?(workItemId: string): AssistantWorkItemRun | undefined | Promise<AssistantWorkItemRun | undefined>;
  beginWorkItemRun?(input: {
    parentRunId: string;
    workItem: AssistantWorkItem;
    now: number;
  }): Pick<AssistantWorkItemRun, 'id'> | Promise<Pick<AssistantWorkItemRun, 'id'>>;
  finishWorkItemRun?(input: {
    id: string;
    status: 'completed' | 'no_result' | 'failed';
    output?: Record<string, unknown>;
    summary?: string;
    error?: string;
    now: number;
  }): void | Promise<void>;
  stageCandidates(input: {
    runId: string;
    candidates: AssistantCandidateProposal[];
    now: number;
  }): AssistantCandidate[] | Promise<AssistantCandidate[]>;
  recordEvidence(input: {
    runId: string;
    kind: 'evening' | 'morning';
    summary: string;
    output: AssistantPhaseOutput;
    workItems: AssistantWorkItem[];
    now: number;
  }): string[] | Promise<string[]>;
  finishSuccess(input: {
    runId: string;
    evidenceIds: string[];
    summary: string;
    now: number;
  }): void | Promise<void>;
  finishFailure(input: {
    runId: string;
    failureKind: 'executor_failed';
    message: string;
    now: number;
  }): void | Promise<void>;
}

export type AssistantLoopExecutionResult =
  | { status: 'success'; summary: string; candidateCount: number }
  | { status: 'skipped'; reason: 'needs_consent' | 'paused' | 'missing_profile' }
  | { status: 'failed'; reason: 'runtime_unavailable' };

export function createAssistantLoopExecutor(dependencies: AssistantLoopExecutorDependencies) {
  return {
    async execute(input: {
      kind: 'evening' | 'morning';
      runId: string;
      now: number;
      workItems: AssistantWorkItem[];
    }): Promise<AssistantLoopExecutionResult> {
      const profile = await dependencies.getProfile();
      if (!profile) return { status: 'skipped', reason: 'missing_profile' };
      if (profile.status !== 'active') return { status: 'skipped', reason: profile.status };

      try {
        const snapshot = await dependencies.collect({ kind: input.kind, profile, now: input.now });
        const outcomes: AssistantPhaseOutput['outcomes'] = [];
        const anomalies: AssistantPhaseOutput['anomalies'] = [];
        const failures: NonNullable<AssistantPhaseOutput['failures']> = [];
        let candidateCount = 0;
        for (const workItem of input.workItems) {
          const itemRun = dependencies.beginWorkItemRun
            ? await dependencies.beginWorkItemRun({ parentRunId: input.runId, workItem, now: input.now })
            : { id: `${input.runId}:${workItem.id}` };
          try {
            const previousOutcome = await dependencies.getPreviousOutcome?.(workItem.id);
            let output: AssistantPhaseOutput;
            try {
              output = await dependencies.complete({
                kind: input.kind,
                profile,
                snapshot,
                workItems: [workItem],
                executionMode: 'formal',
                previousOutcome,
              });
            } catch (error) {
              const detail = errorMessage(error);
              if (!isRetryableAssistantOutputError(detail)) throw error;
              output = await dependencies.complete({
                kind: input.kind,
                profile,
                snapshot,
                workItems: [workItem],
                executionMode: 'formal',
                previousOutcome,
                validationError: detail,
              });
            }
            let outcome = output.outcomes[0];
            anomalies.push(...output.anomalies);
            if (input.kind === 'evening' && outcome.status === 'completed' && outcome.candidates.length > 0) {
              const staged = await dependencies.stageCandidates({
                runId: input.runId,
                candidates: outcome.candidates,
                now: input.now,
              });
              candidateCount += staged.length;
              const candidateIds = new Map(staged.map(candidate => [`${candidate.workItemId ?? ''}\u0000${candidate.dedupeKey}`, candidate.id]));
              outcome = {
                ...outcome,
                candidates: outcome.candidates.map(candidate => ({
                  ...candidate,
                  candidateId: candidateIds.get(`${candidate.workItemId}\u0000${candidate.dedupeKey}`),
                })),
              };
            }
            outcomes.push(outcome);
            await dependencies.finishWorkItemRun?.({
              id: itemRun.id,
              status: outcome.status,
              output: {
                ...outcome,
                evidenceCatalog: output.evidenceCatalog,
              } as unknown as Record<string, unknown>,
              summary: outcome.summary,
              now: input.now,
            });
          } catch (error) {
            const detail = errorMessage(error);
            failures.push({ workItemId: workItem.id, error: detail });
            await dependencies.finishWorkItemRun?.({
              id: itemRun.id,
              status: 'failed',
              error: detail,
              now: input.now,
            });
          }
        }
        if (outcomes.length === 0) {
          const detail = failures[0]?.error ?? 'assistant_work_items_all_failed';
          await dependencies.finishFailure({
            runId: input.runId,
            failureKind: 'executor_failed',
            message: `runtime_unavailable: ${detail}`,
            now: input.now,
          });
          return { status: 'failed', reason: 'runtime_unavailable' };
        }
        const output: AssistantPhaseOutput = {
          schemaVersion: 'assistant_work_items_v1',
          phase: input.kind,
          outcomes,
          anomalies,
          failures,
        };
        const completedSummaries = output.outcomes.flatMap(outcome => outcome.status === 'completed' && outcome.summary ? [outcome.summary] : []);
        const baseSummary = completedSummaries.join('\n') || `assistant_${input.kind}_no_results`;
        const summary = failures.length > 0
          ? `${baseSummary}\n${profile.locale === 'zh' ? `${failures.length} 个工作项失败` : `${failures.length} work item(s) failed`}`
          : baseSummary;
        const evidenceIds = await dependencies.recordEvidence({
          runId: input.runId,
          kind: input.kind,
          summary,
          output,
          workItems: input.workItems,
          now: input.now,
        });
        await dependencies.finishSuccess({ runId: input.runId, evidenceIds, summary, now: input.now });
        return { status: 'success', summary, candidateCount };
      } catch (error) {
        const detail = errorMessage(error);
        await dependencies.finishFailure({
          runId: input.runId,
          failureKind: 'executor_failed',
          message: `runtime_unavailable: ${detail}`,
          now: input.now,
        });
        return { status: 'failed', reason: 'runtime_unavailable' };
      }
    },
  };
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function isRetryableAssistantOutputError(message: string): boolean {
  return message.startsWith('assistant_json_')
    || message.startsWith('assistant_schema_')
    || message.startsWith('assistant_phase_')
    || message.startsWith('assistant_outcome')
    || message.startsWith('assistant evidence')
    || message.startsWith('assistant candidate')
    || message.startsWith('assistant recommendation')
    || message.startsWith('assistant workItemId');
}
