interface MorningSuggestionRun {
  id: string;
  status: string;
}

interface MorningSuggestionEvidence {
  metadata: Record<string, unknown>;
}

export interface MorningSuggestionView {
  id: string;
  title: string;
  summary: string;
  evidenceRefs: Array<{ kind: string; id: string }>;
}

export function listLatestMorningSuggestions(input: {
  listRuns(): MorningSuggestionRun[];
  listEvidence(runId: string): MorningSuggestionEvidence[];
}): MorningSuggestionView[] {
  const run = input.listRuns().find(candidate => candidate.status === 'success');
  if (!run) return [];
  for (const evidence of input.listEvidence(run.id)) {
    if (evidence.metadata.assistantKind !== 'morning') continue;
    const output = asRecord(evidence.metadata.output);
    if (output?.schemaVersion !== 'assistant_work_items_v1' || output.phase !== 'morning' || !Array.isArray(output.outcomes)) continue;
    const recommendations = output.outcomes.flatMap(value => {
      const outcome = asRecord(value);
      return outcome?.status === 'completed' && Array.isArray(outcome.recommendations) ? outcome.recommendations : [];
    });
    return recommendations.slice(0, 3).flatMap((value, index) => {
      const recommendation = asRecord(value);
      const title = readString(recommendation?.title);
      const reasonCode = readString(recommendation?.reasonCode);
      const evidenceRefs = parseEvidenceRefs(recommendation?.evidenceRefs);
      if (!title || !reasonCode || evidenceRefs.length === 0) return [];
      return [{ id: `${run.id}:${index}`, title, summary: reasonCode, evidenceRefs }];
    });
  }
  return [];
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function readString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function parseEvidenceRefs(value: unknown): Array<{ kind: string; id: string }> {
  if (!Array.isArray(value) || value.length === 0) return [];
  const refs = value.flatMap(reference => {
    const record = asRecord(reference);
    const kind = readString(record?.kind);
    const id = readString(record?.id);
    return kind && id ? [{ kind, id }] : [];
  });
  return refs.length === value.length ? refs : [];
}
