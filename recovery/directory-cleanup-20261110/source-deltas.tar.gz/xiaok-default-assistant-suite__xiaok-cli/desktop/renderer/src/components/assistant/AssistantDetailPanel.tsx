import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { ArrowDown, ArrowUp, Check, LoaderCircle, Play, Plus, RotateCcw, Trash2, X } from 'lucide-react';

import { useLocale } from '../../contexts/LocaleContext';
import type {
  AssistantCandidateStatusView,
  AssistantCandidateView,
  AssistantProfileView,
  AssistantWorkItemOutcomeView,
  AssistantWorkItemPhaseView,
  AssistantWorkItemPreviewInputView,
  AssistantWorkItemPreviewResultView,
  AssistantWorkItemView,
} from './view-types';

export type { AssistantCandidateView } from './view-types';

export interface AssistantDetailPanelProps {
  open: boolean;
  profile: AssistantProfileView;
  candidates: AssistantCandidateView[];
  workItems: AssistantWorkItemView[];
  workItemRevision: number;
  latestWorkItemOutcomes?: AssistantWorkItemOutcomeView[];
  knowledgeCollections: Array<{ id: string; name: string }>;
  busyCandidateId?: string | null;
  onClose: () => void;
  onAcceptCandidate: (candidateId: string, collectionId?: string) => void | Promise<void>;
  onRejectCandidate: (candidateId: string) => void | Promise<void>;
  onCreateWorkItem: (input: { phase: AssistantWorkItemPhaseView; title: string; instruction: string }) => void | Promise<void>;
  onUpdateWorkItem: (input: { id: string; phase?: AssistantWorkItemPhaseView; title?: string; instruction?: string }) => void | Promise<void>;
  onSetWorkItemEnabled: (id: string, enabled: boolean) => void | Promise<void>;
  onReorderWorkItems: (phase: AssistantWorkItemPhaseView, orderedIds: string[], expectedRevision: number) => void | Promise<void>;
  onDeleteWorkItem: (id: string) => void | Promise<void>;
  onRestoreBuiltInWorkItem: (id: string) => void | Promise<void>;
  onPreviewWorkItem?: (input: AssistantWorkItemPreviewInputView) => Promise<AssistantWorkItemPreviewResultView>;
}

type WorkItemDraft = Pick<AssistantWorkItemView, 'phase' | 'title' | 'instruction'>;

export function AssistantDetailPanel({
  open,
  profile,
  candidates,
  workItems,
  workItemRevision,
  latestWorkItemOutcomes = [],
  knowledgeCollections,
  busyCandidateId = null,
  onClose,
  onAcceptCandidate,
  onRejectCandidate,
  onCreateWorkItem,
  onUpdateWorkItem,
  onSetWorkItemEnabled,
  onReorderWorkItems,
  onDeleteWorkItem,
  onRestoreBuiltInWorkItem,
  onPreviewWorkItem,
}: AssistantDetailPanelProps) {
  const { t } = useLocale();
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const [collectionByCandidate, setCollectionByCandidate] = useState<Record<string, string>>({});
  const [drafts, setDrafts] = useState<Record<string, WorkItemDraft>>({});
  const [newItem, setNewItem] = useState<WorkItemDraft>({ phase: 'evening', title: '', instruction: '' });
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [mutationError, setMutationError] = useState<string | null>(null);
  const [previewingItemId, setPreviewingItemId] = useState<string | null>(null);
  const [previewResults, setPreviewResults] = useState<Record<string, AssistantWorkItemPreviewResultView>>({});
  const [previewErrors, setPreviewErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    setDrafts(Object.fromEntries(workItems.map(item => [item.id, {
      phase: item.phase,
      title: item.title,
      instruction: item.instruction,
    }])));
  }, [workItems]);

  useEffect(() => {
    if (!open) return;
    previousFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const focusTimer = window.setTimeout(() => closeButtonRef.current?.focus(), 0);
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onCloseRef.current();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      window.clearTimeout(focusTimer);
      document.removeEventListener('keydown', handleKeyDown);
      previousFocusRef.current?.focus();
    };
  }, [open]);

  const orderedByPhase = useMemo(() => ({
    evening: workItems.filter(item => item.phase === 'evening').sort((left, right) => left.sortOrder - right.sortOrder),
    morning: workItems.filter(item => item.phase === 'morning').sort((left, right) => left.sortOrder - right.sortOrder),
  }), [workItems]);

  if (!open) return null;

  const runMutation = async (key: string, mutation: () => void | Promise<void>) => {
    setBusyAction(key);
    setMutationError(null);
    try {
      await mutation();
    } catch {
      setMutationError(t.assistant.workItemMutationFailed);
    } finally {
      setBusyAction(null);
    }
  };

  const moveWorkItem = (item: AssistantWorkItemView, direction: -1 | 1) => {
    const phaseItems = orderedByPhase[item.phase];
    const index = phaseItems.findIndex(candidate => candidate.id === item.id);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= phaseItems.length) return;
    const orderedIds = phaseItems.map(candidate => candidate.id);
    [orderedIds[index], orderedIds[target]] = [orderedIds[target], orderedIds[index]];
    void runMutation(`reorder:${item.id}`, () => onReorderWorkItems(item.phase, orderedIds, workItemRevision));
  };

  const previewWorkItem = async (input: AssistantWorkItemPreviewInputView) => {
    if (!onPreviewWorkItem || previewingItemId) return;
    setPreviewingItemId(input.id);
    setPreviewErrors(current => {
      const next = { ...current };
      delete next[input.id];
      return next;
    });
    try {
      const result = await onPreviewWorkItem(input);
      setPreviewResults(current => ({ ...current, [input.id]: result }));
    } catch (error) {
      const message = error instanceof Error && error.message ? error.message : 'unknown_error';
      setPreviewErrors(current => ({ ...current, [input.id]: message }));
    } finally {
      setPreviewingItemId(null);
    }
  };

  const statusLabel = (status: AssistantCandidateStatusView) => {
    const labels: Record<AssistantCandidateStatusView, string> = {
      staged: t.assistant.candidateStatusStaged,
      pending: t.assistant.candidateStatusPending,
      accepting: t.assistant.candidateStatusAccepting,
      accepted: t.assistant.candidateStatusAccepted,
      rejected: t.assistant.candidateStatusRejected,
      superseded: t.assistant.candidateStatusSuperseded,
      accept_failed: t.assistant.candidateStatusAcceptFailed,
    };
    return labels[status];
  };

  return (
    <div
      role="presentation"
      data-app-region="no-drag"
      style={{ WebkitAppRegion: 'no-drag' } as CSSProperties}
      className="no-drag fixed inset-0 z-50 flex justify-end bg-black/25"
      onMouseDown={event => {
        if (event.currentTarget === event.target) onClose();
      }}
    >
      <section role="dialog" aria-modal="true" aria-label={t.assistant.detailTitle} className="flex h-full w-full max-w-xl flex-col border-l border-[var(--c-border)] bg-[var(--c-bg-page)] shadow-2xl">
        <header className="flex items-start justify-between gap-4 border-b border-[var(--c-border)] px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-[var(--c-text-primary)]">{t.assistant.detailTitle}</h2>
            <p className="mt-1 text-xs text-[var(--c-text-secondary)]">{t.assistant.detailSchedule(profile.eveningTime, profile.morningTime)}</p>
          </div>
          <button ref={closeButtonRef} type="button" onClick={onClose} aria-label={t.assistant.closeDetails} className="rounded-md p-1.5 text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)]">
            <X size={16} />
          </button>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          <section aria-labelledby="assistant-work-items-title">
            <div className="mb-3">
              <h3 id="assistant-work-items-title" className="text-sm font-semibold text-[var(--c-text-primary)]">{t.assistant.workItemsTitle}</h3>
              <p className="mt-1 text-xs leading-relaxed text-[var(--c-text-secondary)]">{t.assistant.workItemsDescription}</p>
              {onPreviewWorkItem && <p className="mt-2 rounded-md bg-[var(--c-bg-deep)] px-3 py-2 text-[11px] leading-relaxed text-[var(--c-text-secondary)]">{t.assistant.previewNotice}</p>}
            </div>
            {mutationError && <div role="alert" className="mb-3 rounded-md bg-red-500/10 px-3 py-2 text-xs text-red-600">{mutationError}</div>}
            <div className="space-y-5">
              {(['evening', 'morning'] as const).map(phase => (
                <div key={phase}>
                  <div className="mb-2 flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-[var(--c-text-primary)]">{phase === 'evening' ? t.assistant.phaseEvening : t.assistant.phaseMorning}</h4>
                    <span className="text-right text-[10px] text-[var(--c-text-tertiary)]">
                      <span className="block">{t.assistant.workItemCount(orderedByPhase[phase].length)}</span>
                      <span className="block">{t.assistant.formalScheduleHint(phase === 'evening' ? profile.eveningTime : profile.morningTime)}</span>
                    </span>
                  </div>
                  <div className="space-y-2">
                    {orderedByPhase[phase].map((item, index) => {
                      const draft = drafts[item.id] ?? item;
                      const busy = busyAction?.endsWith(item.id) ?? false;
                      const previewResult = previewResults[item.id];
                      const previewError = previewErrors[item.id];
                      const formalOutcome = latestWorkItemOutcomes.find(outcome => outcome.workItemId === item.id);
                      const isPreviewing = previewingItemId === item.id;
                      return (
                        <article key={item.id} className="rounded-lg border border-[var(--c-border-subtle)] bg-[var(--c-bg-card)] p-3">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={item.enabled}
                                disabled={busy}
                                aria-label={t.assistant.enableWorkItemLabel(item.title)}
                                onChange={event => void runMutation(`enabled:${item.id}`, () => onSetWorkItemEnabled(item.id, event.target.checked))}
                              />
                              <span className="text-[10px] text-[var(--c-text-tertiary)]">{item.builtInKey ? t.assistant.builtInWorkItem : t.assistant.customWorkItem}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <button type="button" disabled={busy || index === 0} aria-label={t.assistant.moveUpWorkItemLabel(item.title)} onClick={() => moveWorkItem(item, -1)} className="rounded p-1 text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)] disabled:opacity-30"><ArrowUp size={13} /></button>
                              <button type="button" disabled={busy || index === orderedByPhase[phase].length - 1} aria-label={t.assistant.moveDownWorkItemLabel(item.title)} onClick={() => moveWorkItem(item, 1)} className="rounded p-1 text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)] disabled:opacity-30"><ArrowDown size={13} /></button>
                            </div>
                          </div>
                          {!item.builtInKey && (
                            <select
                              aria-label={t.assistant.workItemPhaseLabel(item.title)}
                              value={draft.phase}
                              onChange={event => setDrafts(current => ({ ...current, [item.id]: { ...draft, phase: event.target.value as AssistantWorkItemPhaseView } }))}
                              className="mt-2 w-full rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2 py-1.5 text-xs text-[var(--c-text-primary)]"
                            >
                              <option value="evening">{t.assistant.phaseEvening}</option>
                              <option value="morning">{t.assistant.phaseMorning}</option>
                            </select>
                          )}
                          <input
                            aria-label={t.assistant.workItemTitleLabel(item.title)}
                            value={draft.title}
                            maxLength={80}
                            onChange={event => setDrafts(current => ({ ...current, [item.id]: { ...draft, title: event.target.value } }))}
                            className="mt-2 w-full rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2.5 py-2 text-xs text-[var(--c-text-primary)]"
                          />
                          <textarea
                            aria-label={t.assistant.workItemInstructionLabel(item.title)}
                            value={draft.instruction}
                            maxLength={2000}
                            rows={3}
                            onChange={event => setDrafts(current => ({ ...current, [item.id]: { ...draft, instruction: event.target.value } }))}
                            className="mt-2 w-full resize-y rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2.5 py-2 text-xs leading-relaxed text-[var(--c-text-primary)]"
                          />
                          <div className="mt-2 flex flex-wrap justify-end gap-2">
                            {onPreviewWorkItem && (
                              <button
                                type="button"
                                disabled={busy || Boolean(previewingItemId) || !draft.title.trim() || !draft.instruction.trim()}
                                aria-label={t.assistant.previewWorkItemLabel(item.title)}
                                onClick={() => void previewWorkItem({ id: item.id, ...draft })}
                                className="inline-flex items-center gap-1 rounded-md border border-[var(--c-accent)]/30 px-2.5 py-1.5 text-xs font-medium text-[var(--c-accent)] disabled:opacity-50"
                              >
                                {isPreviewing ? <LoaderCircle size={12} className="animate-spin" /> : <Play size={12} />}
                                {isPreviewing ? t.assistant.previewRunning : t.assistant.previewWorkItem}
                              </button>
                            )}
                            {item.builtInKey ? (
                              <button type="button" disabled={busy} aria-label={t.assistant.restoreDefaultWorkItemLabel(item.title)} onClick={() => void runMutation(`restore:${item.id}`, () => onRestoreBuiltInWorkItem(item.id))} className="inline-flex items-center gap-1 rounded-md border border-[var(--c-border)] px-2.5 py-1.5 text-xs text-[var(--c-text-secondary)]"><RotateCcw size={12} />{t.assistant.restoreDefaultWorkItem}</button>
                            ) : (
                              <button type="button" disabled={busy} aria-label={t.assistant.deleteWorkItemLabel(item.title)} onClick={() => void runMutation(`delete:${item.id}`, () => onDeleteWorkItem(item.id))} className="inline-flex items-center gap-1 rounded-md border border-red-500/30 px-2.5 py-1.5 text-xs text-red-600"><Trash2 size={12} />{t.assistant.deleteWorkItem}</button>
                            )}
                            <button type="button" disabled={busy || !draft.title.trim() || !draft.instruction.trim()} aria-label={t.assistant.saveWorkItemLabel(item.title)} onClick={() => void runMutation(`save:${item.id}`, () => onUpdateWorkItem({ id: item.id, ...draft }))} className="rounded-md bg-[var(--c-accent)] px-3 py-1.5 text-xs font-medium text-white disabled:opacity-50">{t.assistant.saveWorkItem}</button>
                          </div>
                          {previewError && <div role="alert" className="mt-3 rounded-md border border-red-500/20 bg-red-500/5 px-3 py-2 text-xs text-red-600">{t.assistant.previewFailure(previewError)}</div>}
                          {previewResult && <WorkItemOutcomeCard label={t.assistant.previewResultEphemeral} outcome={previewResult} preview />}
                          {formalOutcome && <WorkItemOutcomeCard label={t.assistant.latestFormalResult} outcome={formalOutcome} />}
                        </article>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-5 rounded-lg border border-dashed border-[var(--c-border)] p-3">
              <h4 className="text-xs font-semibold text-[var(--c-text-primary)]">{t.assistant.addWorkItemTitle}</h4>
              <select aria-label={t.assistant.newWorkItemPhase} value={newItem.phase} onChange={event => setNewItem(current => ({ ...current, phase: event.target.value as AssistantWorkItemPhaseView }))} className="mt-2 w-full rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2.5 py-2 text-xs text-[var(--c-text-primary)]">
                <option value="evening">{t.assistant.phaseEvening}</option>
                <option value="morning">{t.assistant.phaseMorning}</option>
              </select>
              <input aria-label={t.assistant.newWorkItemTitle} value={newItem.title} maxLength={80} onChange={event => setNewItem(current => ({ ...current, title: event.target.value }))} className="mt-2 w-full rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2.5 py-2 text-xs text-[var(--c-text-primary)]" />
              <textarea aria-label={t.assistant.newWorkItemInstruction} value={newItem.instruction} maxLength={2000} rows={3} onChange={event => setNewItem(current => ({ ...current, instruction: event.target.value }))} className="mt-2 w-full resize-y rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2.5 py-2 text-xs text-[var(--c-text-primary)]" />
              <div className="mt-2 flex justify-end gap-2">
                {onPreviewWorkItem && (
                  <button
                    type="button"
                    disabled={Boolean(previewingItemId) || !newItem.title.trim() || !newItem.instruction.trim()}
                    aria-label={t.assistant.previewWorkItemLabel(newItem.title || t.assistant.addWorkItemTitle)}
                    onClick={() => void previewWorkItem({ id: 'assistant-preview:new-work-item', ...newItem })}
                    className="inline-flex items-center gap-1.5 rounded-md border border-[var(--c-accent)]/30 px-3 py-1.5 text-xs font-medium text-[var(--c-accent)] disabled:opacity-50"
                  >
                    {previewingItemId === 'assistant-preview:new-work-item' ? <LoaderCircle size={13} className="animate-spin" /> : <Play size={13} />}
                    {previewingItemId === 'assistant-preview:new-work-item' ? t.assistant.previewRunning : t.assistant.previewWorkItem}
                  </button>
                )}
                <button type="button" disabled={busyAction === 'create' || !newItem.title.trim() || !newItem.instruction.trim()} onClick={() => void runMutation('create', async () => {
                  await onCreateWorkItem(newItem);
                  setNewItem(current => ({ ...current, title: '', instruction: '' }));
                })} className="inline-flex items-center gap-1.5 rounded-md bg-[var(--c-accent)] px-3 py-1.5 text-xs font-medium text-white disabled:opacity-50"><Plus size={13} />{t.assistant.addWorkItem}</button>
              </div>
              {previewErrors['assistant-preview:new-work-item'] && <div role="alert" className="mt-3 rounded-md border border-red-500/20 bg-red-500/5 px-3 py-2 text-xs text-red-600">{t.assistant.previewFailure(previewErrors['assistant-preview:new-work-item'])}</div>}
              {previewResults['assistant-preview:new-work-item'] && <WorkItemOutcomeCard label={t.assistant.previewResultEphemeral} outcome={previewResults['assistant-preview:new-work-item']} preview />}
            </div>
          </section>

          <section className="mt-7 border-t border-[var(--c-border)] pt-5" aria-labelledby="assistant-candidates-title">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h3 id="assistant-candidates-title" className="text-sm font-semibold text-[var(--c-text-primary)]">{t.assistant.candidatesTitle}</h3>
              <span className="text-xs text-[var(--c-text-tertiary)]">{t.assistant.candidateCount(candidates.length)}</span>
            </div>
            {candidates.length === 0 ? (
              <div className="rounded-lg border border-dashed border-[var(--c-border)] px-4 py-10 text-center text-sm text-[var(--c-text-secondary)]">{t.assistant.noCandidates}</div>
            ) : (
              <div className="space-y-3">
                {candidates.map(candidate => {
                  const canDecide = candidate.status === 'pending' || candidate.status === 'accept_failed';
                  const busy = busyCandidateId === candidate.id || candidate.status === 'accepting';
                  const selectedCollectionId = collectionByCandidate[candidate.id];
                  const needsCollection = candidate.kind === 'knowledge';
                  return (
                    <article key={candidate.id} className="rounded-lg border border-[var(--c-border-subtle)] bg-[var(--c-bg-card)] p-4">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="rounded bg-[var(--c-accent)]/10 px-1.5 py-0.5 text-[10px] font-medium text-[var(--c-accent)]">{t.assistant.candidateKind(candidate.kind)}</span>
                            <span className="text-[10px] text-[var(--c-text-tertiary)]">{t.assistant.confidence(candidate.confidence)}</span>
                          </div>
                          <h4 className="mt-2 text-sm font-semibold text-[var(--c-text-primary)]">{candidate.title}</h4>
                        </div>
                        <span className="rounded bg-[var(--c-bg-deep)] px-2 py-1 text-[10px] text-[var(--c-text-secondary)]">{statusLabel(candidate.status)}</span>
                      </div>
                      <p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed text-[var(--c-text-secondary)]">{candidate.content}</p>
                      {candidate.evidenceRefs.length > 0 && <div className="mt-3 flex flex-wrap gap-1.5">{candidate.evidenceRefs.map(reference => <span key={`${reference.kind}:${reference.id}`} className="rounded-full border border-[var(--c-border-subtle)] px-2 py-0.5 text-[10px] text-[var(--c-text-tertiary)]">{t.assistant.evidence(reference.kind, reference.id)}</span>)}</div>}
                      {canDecide && <div className="mt-4 space-y-3">
                        {needsCollection && <label className="block text-xs text-[var(--c-text-secondary)]">
                          <span className="mb-1 block">{t.assistant.knowledgeCollection}</span>
                          <select aria-label={t.assistant.knowledgeCollectionLabel(candidate.title)} value={selectedCollectionId ?? ''} onChange={event => setCollectionByCandidate(current => ({ ...current, [candidate.id]: event.target.value }))} className="w-full rounded-md border border-[var(--c-border)] bg-[var(--c-bg-page)] px-2.5 py-2 text-xs text-[var(--c-text-primary)]">
                            <option value="">{t.assistant.selectKnowledgeCollection}</option>
                            {knowledgeCollections.map(collection => <option key={collection.id} value={collection.id}>{collection.name}</option>)}
                          </select>
                          {knowledgeCollections.length === 0 && <span className="mt-1 block text-[var(--c-text-tertiary)]">{t.assistant.noKnowledgeCollections}</span>}
                        </label>}
                        <div className="flex justify-end gap-2">
                          <button type="button" disabled={busy} aria-label={t.assistant.rejectCandidateLabel(candidate.title)} onClick={() => onRejectCandidate(candidate.id)} className="rounded-md border border-[var(--c-border)] px-3 py-1.5 text-xs text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)] disabled:opacity-60">{t.assistant.rejectCandidate}</button>
                          <button type="button" disabled={busy || (needsCollection && !selectedCollectionId)} aria-label={t.assistant.acceptCandidateLabel(candidate.title)} onClick={() => needsCollection ? onAcceptCandidate(candidate.id, selectedCollectionId) : onAcceptCandidate(candidate.id)} className="inline-flex items-center gap-1.5 rounded-md bg-[var(--c-accent)] px-3 py-1.5 text-xs font-medium text-white disabled:opacity-60"><Check size={13} />{t.assistant.acceptCandidate}</button>
                        </div>
                      </div>}
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      </section>
    </div>
  );
}

function WorkItemOutcomeCard({
  label,
  outcome,
  preview = false,
}: {
  label: string;
  outcome: AssistantWorkItemOutcomeView | AssistantWorkItemPreviewResultView;
  preview?: boolean;
}) {
  const { t } = useLocale();
  const candidates = Array.isArray(outcome.candidates) ? outcome.candidates : [];
  const recommendations = Array.isArray(outcome.recommendations) ? outcome.recommendations : [];
  const evidenceRefs = Array.isArray(outcome.evidenceRefs) ? outcome.evidenceRefs : [];
  const evidenceDetails = Array.isArray(outcome.evidenceDetails) ? outcome.evidenceDetails : [];
  const context = preview && 'context' in outcome ? outcome.context : undefined;
  const scopeOrder = ['tasks', 'projects', 'threads', 'artifacts', 'automations', 'meetings'] as const;
  const scopeSummary = context
    ? scopeOrder.flatMap(scope => context.scopeCounts[scope] ? [t.assistant.previewScope(scope, context.scopeCounts[scope]!)] : []).join(' · ')
    : '';

  return (
    <div className="mt-3 rounded-md border border-[var(--c-border-subtle)] bg-[var(--c-bg-page)] px-3 py-2.5 text-xs">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="font-medium text-[var(--c-text-primary)]">{label}</span>
        {preview && 'durationMs' in outcome && <span className="text-[10px] text-[var(--c-text-tertiary)]">{t.assistant.previewDuration(outcome.durationMs)}</span>}
      </div>
      {context && (
        <p className="mt-1 text-[10px] text-[var(--c-text-tertiary)]">
          {t.assistant.previewContextSummary(context.itemCount, scopeSummary)}
          {context.sourceErrorCount > 0 ? ` · ${t.assistant.previewSourceErrors(context.sourceErrorCount)}` : ''}
        </p>
      )}
      {outcome.status === 'failed' ? (
        <p className="mt-2 text-red-600">{formatFormalFailure(outcome.error, t.assistant)}</p>
      ) : outcome.status === 'no_result' ? (
        <p className="mt-2 text-[var(--c-text-secondary)]">{t.assistant.previewNoResult}</p>
      ) : (
        <p className="mt-2 whitespace-pre-wrap leading-relaxed text-[var(--c-text-secondary)]">{outcome.summary}</p>
      )}
      {recommendations.length > 0 && (
        <div className="mt-2">
          <div className="text-[10px] font-medium text-[var(--c-text-tertiary)]">{t.assistant.previewRecommendationsTitle}</div>
          {recommendations.map((recommendation, index) => <p key={index} className="mt-1 text-[var(--c-text-secondary)]">{readRecordText(recommendation, 'title')}</p>)}
        </div>
      )}
      {candidates.length > 0 && (
        <div className="mt-2">
          <div className="text-[10px] font-medium text-[var(--c-text-tertiary)]">{t.assistant.previewCandidatesTitle}</div>
          {candidates.map((candidate, index) => (
            <div key={index} className="mt-1 rounded bg-[var(--c-bg-deep)] px-2 py-1.5 text-[var(--c-text-secondary)]">
              <div className="font-medium text-[var(--c-text-primary)]">{readRecordText(candidate, 'title')}</div>
              {readRecordText(candidate, 'content') && <div className="mt-0.5">{readRecordText(candidate, 'content')}</div>}
            </div>
          ))}
        </div>
      )}
      {evidenceRefs.length > 0 && (
        <div className="mt-2 space-y-1.5">
          <span className="text-[10px] font-medium text-[var(--c-text-tertiary)]">{t.assistant.previewEvidenceTitle}</span>
          <div className="flex flex-wrap gap-1.5">
            {evidenceRefs.map(reference => {
              const detail = evidenceDetails.find(item => item.reference.kind === reference.kind && item.reference.id === reference.id);
              const status = detail?.attributes && typeof detail.attributes.status === 'string' ? detail.attributes.status : undefined;
              const label = detail?.title
                ? [detail.title, status, detail.updatedAtLocal].filter(Boolean).join(' · ')
                : t.assistant.evidence(reference.kind, reference.id);
              return <span key={`${reference.kind}:${reference.id}`} title={t.assistant.evidence(reference.kind, reference.id)} className="rounded-md border border-[var(--c-border-subtle)] px-2 py-1 text-[10px] text-[var(--c-text-tertiary)]">{label}</span>;
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function formatFormalFailure(
  error: string | undefined,
  labels: { formalFailure: (detail: string) => string; formalFailureInvalidJson: string; formalFailureUnknown: string },
): string {
  if (error?.includes('assistant_json_invalid')) return labels.formalFailure(labels.formalFailureInvalidJson);
  return labels.formalFailure(error?.trim() || labels.formalFailureUnknown);
}

function readRecordText(value: unknown, key: string): string {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return '';
  const field = (value as Record<string, unknown>)[key];
  return typeof field === 'string' ? field : '';
}
