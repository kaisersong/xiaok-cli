import type { AutomationOverviewSnapshotView, AutomationRecentFailureItemView } from '../api/types';
import type { KSwarmProject } from '../hooks/useKSwarmClient';
import type { AssistantHomeSnapshot, AssistantSuggestionView } from './assistant/view-types';

const ACTIVE_PROJECT_STATUSES = new Set<KSwarmProject['status']>(['planning', 'created', 'active', 'review']);
const COMPLETED_PROJECT_STATUSES = new Set<KSwarmProject['status']>(['delivered', 'closed']);

export type WelcomeAttentionItem =
  | { kind: 'project'; id: string; title: string; reason?: string; nextStep?: string }
  | { kind: 'automation'; id: string; title: string; reason?: string; failure: AutomationRecentFailureItemView };

export interface WelcomeHomeProjection {
  counts: {
    activeProjects: number;
    attention: number;
    activeAutomations: number;
    completedProjects: number;
  };
  attentionItems: WelcomeAttentionItem[];
}

export function buildAssistantHomeProjection(snapshot: AssistantHomeSnapshot): AssistantHomeSnapshot {
  return {
    ...snapshot,
    suggestions: snapshot.suggestions.slice(0, 3).map(suggestion => ({
      ...suggestion,
      evidenceRefs: (suggestion.evidenceRefs ?? []).filter(reference => (
        typeof reference?.kind === 'string' && reference.kind.trim().length > 0
        && typeof reference?.id === 'string' && reference.id.trim().length > 0
      )),
    })),
  };
}

export interface AssistantSuggestionRoute {
  pathname: string;
  search?: string;
}

export interface AssistantSuggestionThread {
  id: string;
  currentTaskId?: string | null;
  taskIds?: string[];
}

export function assistantSuggestionRoute(
  suggestion: AssistantSuggestionView,
  threads: AssistantSuggestionThread[] = [],
): AssistantSuggestionRoute | null {
  const refs = suggestion.evidenceRefs ?? [];
  const threadIds = new Set(threads.map(thread => thread.id));
  const resolvedThreadIds = new Set<string>();

  for (const reference of refs) {
    if (reference.kind !== 'task_snapshot') continue;
    const matches = threads.filter(thread => (
      thread.currentTaskId === reference.id || thread.taskIds?.includes(reference.id)
    ));
    if (matches.length > 1) return null;
    if (matches.length === 1) resolvedThreadIds.add(matches[0].id);
  }
  for (const reference of refs) {
    if (reference.kind === 'thread' && threadIds.has(reference.id)) {
      resolvedThreadIds.add(reference.id);
    }
  }
  if (resolvedThreadIds.size > 1) return null;
  const [threadId] = resolvedThreadIds;
  if (threadId) return { pathname: `/t/${encodeURIComponent(threadId)}` };

  const project = refs.find(reference => reference.kind === 'project');
  if (project?.id) return { pathname: `/projects/${encodeURIComponent(project.id)}` };
  const timedAction = refs.find(reference => reference.kind === 'timed_action');
  if (timedAction?.id) {
    return {
      pathname: '/automations/schedules',
      search: `?focusTask=${encodeURIComponent(timedAction.id)}`,
    };
  }
  return null;
}

export function buildWelcomeHomeProjection(
  projects: KSwarmProject[],
  automation: AutomationOverviewSnapshotView | null,
  localizedAutomationTitles: Partial<Record<string, string>> = {},
): WelcomeHomeProjection {
  const activeProjects = projects.filter(project => ACTIVE_PROJECT_STATUSES.has(project.status));
  const failuresByOwner = new Map<string, AutomationRecentFailureItemView>();
  for (const failure of [...(automation?.recentFailures ?? [])].sort((left, right) => right.occurredAt - left.occurredAt)) {
    const ownerKey = `${failure.source}:${failure.ownerId}`;
    if (!failuresByOwner.has(ownerKey)) failuresByOwner.set(ownerKey, failure);
  }
  const projectAttention: WelcomeAttentionItem[] = activeProjects
    .filter(project => project.projectIntervention?.required)
    .map(project => ({
      kind: 'project',
      id: project.id,
      title: project.name,
      reason: project.projectIntervention?.message || project.projectIntervention?.reason,
      nextStep: project.projectIntervention?.primaryAction?.label,
    }));
  const automationAttention: WelcomeAttentionItem[] = [...failuresByOwner.values()].map(failure => ({
    kind: 'automation',
    id: failure.id,
    title: failure.actionId ? localizedAutomationTitles[failure.actionId] ?? failure.title : failure.title,
    reason: failure.message,
    failure,
  }));

  return {
    counts: {
      activeProjects: activeProjects.length,
      attention: projectAttention.length + automationAttention.length,
      activeAutomations: automation?.totals.activeSchedules ?? 0,
      completedProjects: projects.filter(project => COMPLETED_PROJECT_STATUSES.has(project.status)).length,
    },
    attentionItems: [...projectAttention, ...automationAttention],
  };
}

export function automationFailureRoute(failure: AutomationRecentFailureItemView): string {
  if (failure.source === 'loop_run') {
    if (failure.loopOrigin === 'built_in') return '/automations/diagnostics';
    return failure.loopId ? `/automations/loops#loop-${failure.loopId}` : '/automations/loops';
  }
  if (failure.actionAvailableInSchedules === false) return '/automations';
  return failure.actionId ? `/automations/schedules#task-${failure.actionId}` : '/automations/schedules';
}
