import type {
  AssistantWorkItemOutcomeView as ApiAssistantWorkItemOutcomeView,
  AssistantWorkItemPreviewInputView as ApiAssistantWorkItemPreviewInputView,
  AssistantWorkItemPreviewResultView as ApiAssistantWorkItemPreviewResultView,
} from '../../api/types';

export type AssistantWorkItemOutcomeView = ApiAssistantWorkItemOutcomeView;
export type AssistantWorkItemPreviewInputView = ApiAssistantWorkItemPreviewInputView;
export type AssistantWorkItemPreviewResultView = ApiAssistantWorkItemPreviewResultView;

export type AssistantProfileStatusView = 'needs_consent' | 'active' | 'paused';

export interface AssistantProfileView {
  status: AssistantProfileStatusView;
  eveningTime: string;
  morningTime: string;
}

export interface AssistantSuggestionView {
  id: string;
  title: string;
  summary: string;
  evidenceRefs?: Array<{ kind: string; id: string }>;
}

export interface AssistantHomeSnapshot {
  profile: AssistantProfileView;
  suggestions: AssistantSuggestionView[];
  pendingCandidateCount: number;
}

export type AssistantCandidateKindView = 'memory' | 'knowledge' | 'follow_up';
export type AssistantCandidateStatusView = 'staged' | 'pending' | 'accepting' | 'accepted' | 'rejected' | 'superseded' | 'accept_failed';

export interface AssistantCandidateView {
  id: string;
  kind: AssistantCandidateKindView;
  status: AssistantCandidateStatusView;
  title: string;
  content: string;
  confidence: number;
  evidenceRefs: Array<{ kind: string; id: string }>;
}

export type AssistantWorkItemPhaseView = 'evening' | 'morning';

export interface AssistantWorkItemView {
  id: string;
  phase: AssistantWorkItemPhaseView;
  title: string;
  instruction: string;
  enabled: boolean;
  sortOrder: number;
  builtInKey?: 'evening_review' | 'memory_candidates' | 'morning_priorities';
  createdAt: number;
  updatedAt: number;
}
