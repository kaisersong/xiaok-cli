import type {InstalledCompletionObservation} from '../verification/installed-completion-observation.js';
import type { ProtectedObservationClosure } from '../../ai/runtime/protected-observation-closure.js';
import type { HostDeliveryRecord } from './delivery-types.js';

export type MaterialRole = 'customer_material' | 'product_material' | 'template_material' | 'unknown';
export type MaterialRoleSource = 'user' | 'auto';
export type MaterialParseStatus = 'pending' | 'parsed' | 'unsupported' | 'failed';

export interface MaterialRecord {
  materialId: string;
  taskId: string;
  originalName: string;
  workspacePath: string;
  extractedTextPath?: string;
  /** Extractor version that produced extractedTextPath; absent means it predates versioning. */
  extractorVersion?: number;
  extractionEngine?: string;
  extractionEngineVersion?: string;
  extractionTruncated?: boolean;
  sourceFingerprint?: string;
  extractionErrorCode?: string;
  mimeType: string;
  sizeBytes: number;
  sha256: string;
  role: MaterialRole;
  roleSource: MaterialRoleSource;
  parseStatus: MaterialParseStatus;
  parseSummary?: string;
  errorMessage?: string;
  createdAt: number;
}

export interface MaterialView {
  materialId: string;
  originalName: string;
  role: MaterialRole;
  parseStatus: MaterialParseStatus;
  parseSummary?: string;
}

export type TaskType = 'sales_deck' | 'unknown';
export type RiskLevel = 'low' | 'medium' | 'high';
export type PlanStepStatus = 'planned' | 'running' | 'completed' | 'blocked' | 'failed';

export interface PlanStep {
  id: string;
  label: string;
  status: PlanStepStatus;
}

export interface TaskUnderstandingInput {
  materialId: string;
  name: string;
  role: MaterialRole;
  parseStatus: MaterialParseStatus;
  parseSummary?: string;
}

export interface TaskUnderstanding {
  goal: string;
  deliverable: string;
  taskType: TaskType;
  audience: string;
  inputs: TaskUnderstandingInput[];
  missingInfo: string[];
  assumptions: string[];
  riskLevel: RiskLevel;
  suggestedPlan: PlanStep[];
  nextAction: string;
}

export interface NeedsUserQuestion {
  questionId: string;
  taskId: string;
  kind:
    | 'confirm_understanding'
    | 'missing_material'
    | 'material_role_correction'
    | 'assumption_approval'
    | 'freeform';
  prompt: string;
  choices?: Array<{ id: string; label: string }>;
  expectedAttachments?: MaterialRole[];
  staleAfterEventId?: string;
  owner?:import('./native-approval-owner.js').NativeApprovalOwnerMetadata;
}

export type UserAnswer =
  | { questionId: string; type: 'choice'; choiceId: string }
  | { questionId: string; type: 'text'; text: string }
  | { questionId: string; type: 'materials'; materialIds: string[] }
  | { questionId: string; type: 'role_update'; materialId: string; role: MaterialRole };

export type ArtifactKind = 'pptx' | 'pdf' | 'docx' | 'xlsx' | 'html' | 'image' | 'text' | 'a2ui' | 'other';

export interface ArtifactSummary {
  artifactId: string;
  sourceTaskId?: string;
  kind: ArtifactKind;
  title: string;
  createdAt: string;
  previewAvailable: boolean;
  filePath?: string;
  mimeType?: string;
  sizeBytes?: number;
  sourceMaterialIds?: string[];
  creator?: string; // e.g. "agent", "skill:report", "tool:Write"
}

export interface TaskResult {
  summary: string;
  artifacts: ArtifactSummary[];
  structuredOutput?: Record<string, unknown>;
  assumptions?: string[];
  nextSteps?: string[];
  degraded?: boolean;
}

export interface SalvageSummary {
  summary: string[];
  reason?: string;
}

/** Stable cursor for a committed event; connection generations are not identities. */
export interface TaskEventRecord {
  taskId: string;
  eventIndex: number;
  sourceDataEpoch: string;
  event: DesktopTaskEvent;
}

export type DesktopTaskEvent =
  | { type: 'ui_preview'; turnId: string; toolUseId: string; preview: {title:string;content:string} | null }
  | { type: 'execution_health'; state: import('../execution-health.js').ExecutionHealthState }
  | { type: 'task_started'; taskId: string }
  | { type: 'task_execution_started'; taskId: string }
  | { type: 'task_terminal'; status: Extract<TaskSnapshotStatus, 'completed' | 'failed' | 'cancelled'> }
  | { type: 'understanding_updated'; understanding: TaskUnderstanding }
  | { type: 'plan_updated'; plan: PlanStep[] }
  | { type: 'progress'; message: string; stage?: string; eventId: string }
  | { type: 'assistant_delta'; delta: string; eventId: string }
  | { type: 'needs_user'; question: NeedsUserQuestion }
  | { type: 'question_resolved'; questionId: string; answerText?: string }
  | { type: 'task_cancelled'; taskId: string; reason: string; partialText?: string }
  | { type: 'result'; result: TaskResult }
  | { type: 'artifact_recorded'; artifactId: string; kind: string; label: string; filePath: string; previewAvailable: boolean; turnId: string; creator?: string; mimeType?: string }
  | { type: 'salvage'; salvage: SalvageSummary }
  | { type: 'error'; message: string; retryable?: boolean; code?: 'MODEL_TEXT_REPETITION_DETECTED' }
  // Canvas events (appended, do not replace existing progress events)
  | { type: 'canvas_tool_call'; toolName: string; input: unknown; toolUseId: string; eventId: string; ts?: number; displayInputSummary?: string }
  | { type: 'canvas_tool_result'; toolName: string; toolUseId: string; ok: boolean; response: string; eventId: string; ts?: number }
  | { type: 'canvas_file_changed'; filePath: string; change: 'add' | 'change' | 'unlink'; eventId: string }
  // TaskPanel progress (from report_progress tool)
  | { type: 'progress_plan_reported'; steps: PlanStep[] }
  // Internal durable facts; renderer may ignore these events.
  | { type: 'usage_recorded'; inputTokens: number; outputTokens: number }
  | { type: 'goal_tool_fact'; invocationId: string; toolName: string; factKind: 'command_result' | 'file_mutation'; exitCode?: number | null; normalizedFilePaths?: string[] }
  | { type: 'goal_tool_finished'; invocationId: string; toolName: string; ok: boolean };

export type TaskSnapshotStatus = 'understanding' | 'running' | 'waiting_user' | 'completed' | 'failed' | 'cancelled';
export type TaskPermissionMode = 'plan' | 'auto' | 'default';
export type TaskContextSkipReason = 'missing' | 'invalid' | 'non_terminal' | 'self' | 'too_old';

export interface TaskCreateContext {
  threadId?: string;
  taskIds?: string[];
}

export interface ArtifactWorkspaceExecutionScope {
  kind: 'artifact_workspace_generation';
  generationRequestId: string;
  leaseId: string;
  target?: ArtifactGenerationTarget;
}

export interface GoalTurnExecutionScope {
  kind: 'goal_turn';
  origin: 'user' | 'continuation';
  goalId: string;
  epoch: number;
  goalTurnId: string;
  threadId: string;
}

export type TaskExecutionScope = ArtifactWorkspaceExecutionScope | GoalTurnExecutionScope;

export interface TaskUsage {
  inputTokens: number;
  outputTokens: number;
  known: boolean;
}

export interface ArtifactGenerationTarget {
  workspaceId: string;
  nodeId: string;
  placeholderId?: string;
  sourceArtifactVersionId?: string;
  generationRequestId: string;
  leaseId: string;
  expectedStructureRevision: number;
  requestedKind: 'image' | 'html' | 'markdown' | 'slides';
  width?: number;
  height?: number;
  referenceVersionIds: string[];
}

export interface TaskContextSkip {
  taskId: string;
  reason: TaskContextSkipReason;
}

export interface TaskContextAudit {
  threadId?: string;
  taskIds: string[];
  loadedTaskIds: string[];
  skipped: TaskContextSkip[];
}

export interface TaskCreateInput {
  prompt: string;
  materials: Array<{ materialId: string; role?: MaterialRole }>;
  permissionMode?: TaskPermissionMode;
  watchdogMs?: number;
  maxToolLoopIterations?: number;
  context?: TaskCreateContext;
  executionScope?: TaskExecutionScope;
}

/** Main-only journal binding, persisted atomically with its host checkpoint. */
export interface TaskMultiAgentPreparation {
  groupId: string;
  rootEpoch: number;
  rootTurnId: string;
  preparationId: string;
  bootId: string;
}

export interface TaskSnapshot {
  inputPreparation?: {inputId:string;inputRevision:string};
  /** Original durable prepare fact; never an execution/launch capability. */
  originalChildPreparation?: import('./default-dispatch-preparation.js').OriginalChildPreparation;
  /** Fresh read observation only; omitted for ordinary tasks, never persisted or used as a write grant. */
  readonly currentCompletion?: Exclude<InstalledCompletionObservation,{kind:'ordinary'}>;
  /** Sticky host CAS marker; recovery requires explicit execution reauthorization even before an archive exists. */
  executionProtected?: true;
  protectedObservationClosure?: ProtectedObservationClosure;
  taskId: string;
  sessionId: string;
  status: TaskSnapshotStatus;
  prompt: string;
  materials: MaterialView[];
  events: DesktopTaskEvent[];
  understanding?: TaskUnderstanding;
  result?: TaskResult;
  salvage?: SalvageSummary;
  context?: TaskContextAudit;
  executionScope?: TaskExecutionScope;
  multiAgentPreparation?: TaskMultiAgentPreparation;
  hostDelivery?: HostDeliveryRecord;
  usage?: TaskUsage;
  createdAt: number;
  updatedAt: number;
}

export interface ActiveTaskRef {
  taskId: string;
}

export interface TaskRuntimeHost {
  prepareTask(input: TaskCreateInput): Promise<{ taskId: string; understanding?: TaskUnderstanding }>;
  startTask(taskId: string): Promise<void>;
  createTask(input: TaskCreateInput): Promise<{ taskId: string; understanding?: TaskUnderstanding }>;
  subscribeTask(taskId: string, options?: { sinceIndex?: number; signal?: AbortSignal }): AsyncIterable<DesktopTaskEvent>;
  subscribeTaskRecords?(taskId: string, options?: { sinceIndex?: number; signal?: AbortSignal }): AsyncIterable<TaskEventRecord>;
  answerQuestion(input: { taskId: string; answer: UserAnswer }): Promise<void>;
  cancelTask(taskId: string, reason?: string): Promise<void>;
  getActiveTasks(): Promise<ActiveTaskRef[]>;
  /** @deprecated Use getActiveTasks() */
  getActiveTask(): Promise<ActiveTaskRef | null>;
  recoverTask(taskId: string): Promise<{ snapshot: TaskSnapshot }>;
}
