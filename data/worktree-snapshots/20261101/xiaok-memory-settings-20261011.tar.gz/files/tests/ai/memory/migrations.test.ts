import { describe, expect, it, afterEach } from 'vitest';
import Database from 'better-sqlite3';
import { runMigrations, getSchemaVersion } from '../../../src/ai/memory/migrations.js';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';

describe('migrations', () => {
  let db: Database.Database;
  let tmpDir: string;

  afterEach(() => {
    db.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('should start at schema version 0 on empty db', () => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaok-mig-test-'));
    db = new Database(path.join(tmpDir, 'test.db'));
    expect(getSchemaVersion(db)).toBe(0);
  });

  it('should migrate to version 1 and create all tables', () => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaok-mig-test-'));
    db = new Database(path.join(tmpDir, 'test.db'));

    runMigrations(db);

    expect(getSchemaVersion(db)).toBe(4);

    const tables = db.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).all().map((r: any) => r.name);

    expect(tables).toContain('memory_meta');
    expect(tables).toContain('memory_l0_raw');
    expect(tables).toContain('memory_l1_extracted');
    expect(tables).toContain('memory_l2_scenario');
    expect(tables).toContain('memory_l3_persona');
    expect(tables).toContain('memory_embeddings');
    expect(tables).toContain('memory_l0_fts');
    const columns = db.prepare('PRAGMA table_info(memory_l1_extracted)').all().map((row: any) => row.name);
    expect(columns).toContain('provenance_json');
  });

  it('should be idempotent', () => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaok-mig-test-'));
    db = new Database(path.join(tmpDir, 'test.db'));

    runMigrations(db);
    runMigrations(db);
    expect(getSchemaVersion(db)).toBe(4);
  });

  it('backfills only complete consistent lineage; mixed and missing legacy origins stay unresolved', () => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaok-mig-scope-'));
    db = new Database(path.join(tmpDir, 'test.db'));
    runMigrations(db);
    db.prepare('INSERT INTO memory_l1_extracted(id,summary,scope,cwd) VALUES(?,?,?,?)').run('global', 'g', 'global', null);
    db.prepare('INSERT INTO memory_l1_extracted(id,summary,scope,cwd) VALUES(?,?,?,?)').run('project', 'p', 'project', '/p');
    for (const [id, ids] of [['g', '["global"]'], ['p', '["project"]'], ['mixed', '["global","project"]'], ['missing', '["absent"]'], ['empty', '[]']]) {
      db.prepare('INSERT INTO memory_l2_scenario(id,source_ids,scenario) VALUES(?,?,?)').run(id, ids, id);
    }
    db.prepare('INSERT INTO memory_l3_persona(id,source_ids,trait) VALUES(?,?,?)').run('trait-p', '["p"]', 'private');
    for (const table of ['memory_l2_scenario', 'memory_l3_persona']) {
      db.exec(`ALTER TABLE ${table} DROP COLUMN scope`); db.exec(`ALTER TABLE ${table} DROP COLUMN cwd`);
    }
    db.prepare('UPDATE memory_meta SET value=? WHERE key=?').run('3', 'schema_version');
    runMigrations(db);
    expect(db.prepare('SELECT scope,cwd FROM memory_l2_scenario WHERE id=?').get('p')).toEqual({ scope: 'project', cwd: '/p' });
    expect(db.prepare('SELECT scope FROM memory_l2_scenario WHERE id=?').get('g')).toEqual({ scope: 'global' });
    for (const id of ['mixed', 'missing', 'empty']) expect(db.prepare('SELECT scope FROM memory_l2_scenario WHERE id=?').get(id)).toEqual({ scope: 'unresolved' });
    expect(db.prepare('SELECT scope,cwd FROM memory_l3_persona WHERE id=?').get('trait-p')).toEqual({ scope: 'project', cwd: '/p' });
  });
});
