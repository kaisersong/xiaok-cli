#!/usr/bin/env node
import { spawn, spawnSync } from 'node:child_process';

const MAX_BYTES = 5_000 * 4;
const GENERATED_DIRECTORY = /(?:^|\/)(?:dist|build|coverage|node_modules|vendor|\.generated)\//;
const GENERATED_FILE = /(?:\.min\.(?:js|css)|\.map|\.(?:generated|gen)\.[^/]+)$/i;
const LOCK_FILE = /(?:^|\/)(?:[^/]+\.lock|package-lock\.json|npm-shrinkwrap\.json|pnpm-lock\.yaml|bun\.lockb)$/;

function git(args, options = {}) {
  const result = spawnSync('git', ['--literal-pathspecs', ...args], {
    encoding: 'utf8', maxBuffer: 16 * 1024 * 1024, ...options,
  });
  if (result.error || result.status !== 0) {
    throw new Error(`Git 检查失败：${result.error?.message || result.stderr.trim() || result.status}`);
  }
  return result;
}

function isGenerated(path) {
  if (GENERATED_DIRECTORY.test(path) || GENERATED_FILE.test(path) || LOCK_FILE.test(path)) return true;
  const fields = git(['check-attr', '--cached', '-z', '--stdin', 'linguist-generated', 'generated'], {
    input: `${path}\0`,
  }).stdout.split('\0');
  for (let i = 0; i + 2 < fields.length; i += 3) {
    if (fields[i + 2] === 'set' || fields[i + 2] === 'true') return true;
  }
  return false;
}

// Match Git's NUL-in-the-first-8000-bytes binary heuristic without consulting
// worktree attributes or buffering entire large blobs. Await close after stopping
// the reader, so the hook never leaves a child process running.
async function isBinary(oid) {
  return new Promise((resolve, reject) => {
    const child = spawn('git', ['cat-file', 'blob', oid], { stdio: ['ignore', 'pipe', 'pipe'] });
    let prefix = Buffer.alloc(0);
    let sampled = false;
    let stderr = '';
    child.on('error', reject);
    child.stdout.on('error', reject);
    child.stderr.on('data', chunk => { stderr = (stderr + chunk.toString()).slice(0, 4096); });
    child.stdout.on('data', chunk => {
      if (sampled) return;
      prefix = Buffer.concat([prefix, chunk.subarray(0, 8000 - prefix.length)]);
      if (prefix.length === 8000) {
        sampled = true;
        child.kill();
      }
    });
    child.on('close', code => {
      if (!sampled && code !== 0) reject(new Error(`Git blob 读取失败：${stderr.trim() || code}`));
      else resolve(prefix.includes(0));
    });
  });
}

async function main() {
  const records = git(['diff', '--cached', '--raw', '-z', '--no-abbrev', '--no-renames',
    '--no-ext-diff', '--diff-filter=ACMT']).stdout.split('\0');
  const violations = [];
  for (let i = 0; i + 1 < records.length; i += 2) {
    const [, mode, , oid] = records[i].split(' ');
    const path = records[i + 1];
    // Symlinks and submodules are not authored regular-file content.
    if (!['100644', '100755'].includes(mode)) continue;
    const size = Number(git(['cat-file', '-s', oid]).stdout.trim());
    if (!Number.isSafeInteger(size) || size < 0) throw new Error('Git 返回了无效的文件字节数');
    if (size <= MAX_BYTES || isGenerated(path)) continue;
    if (await isBinary(oid)) continue;
    violations.push({ path, size });
  }
  if (violations.length === 0) return;
  process.stderr.write([
    '[staged-token-limit] 提交被阻止：以下暂存文件超过 5000 token（字节数 / 4，上限 20000 字节）。',
    ...violations.map(({ path, size }) =>
      `  - ${JSON.stringify(path)}：${size} 字节，${size / 4} token；至少拆成 ${Math.ceil(size / MAX_BYTES)} 个文件。`),
    '拆分步骤：',
    '  1. 按职责提取独立模块（组件、业务逻辑、工具函数），原文件只保留入口和组合逻辑；更新 import/export。',
    '  2. 测试按功能拆成独立测试文件；文档按主题拆成页面并添加链接。每个文件均须 <= 20000 字节。',
    '  3. 重新运行相关测试，再用 git add -- <拆分后的文件> 更新暂存区后重试提交。',
    '确属生成代码时，在 .gitattributes 为具体生成路径设置 linguist-generated=true 并一同暂存；请修改生成源。',
    '',
  ].join('\n'));
  process.exitCode = 1;
}

try {
  await main();
} catch (error) {
  process.stderr.write(`[staged-token-limit] ${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}
