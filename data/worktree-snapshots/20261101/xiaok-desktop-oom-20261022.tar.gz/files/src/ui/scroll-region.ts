/**
 * Scroll region manager for terminal output.
 *
 * Uses ANSI scroll regions to keep input area and status bar fixed at bottom
 * while content + live activity scroll in the upper region.
 *
 * Layout:
 * ┌──────────────────────────────────┐
 * │                                  │
 * │   Output content                 │  ← Scroll region (rows 1 to rows-footerHeight-gapHeight)
 * │   (markdown, tools, etc)         │
 * │                                  │
 * │ ⠴ Thinking(4m 12s • esc to int)  │  ← Live activity (bottom of scroll)
 * │                                  │  ← Gap row (empty)
 * │                                  │  ← Gap row (empty)
 * │                                  │  ← Input background padding row
 * ├──────────────────────────────────┤
 * │ ❯ working...                     │  ← Input bar text row
 * │ gpt-5.4 · 0% · master · xiaok-cli│  ← Status bar (fixed footer bottom row)
 * └──────────────────────────────────┘
 */

import { readTerminalCursor } from './terminal-cursor.js';
import { getDisplayWidth, splitSymbols, stripAnsi, truncateAnsi } from './text-metrics.js';

export interface ScrollRegionConfig {
  /** Height of fixed footer (input bar + status bar) */
  footerHeight: number;
  /** Empty gap rows between transcript/activity/overlay and the input bar */
  gapHeight: number;
  /** Terminal rows */
  rows: number;
  /** Terminal columns */
  columns: number;
}

export interface ScrollPromptFrame {
  inputValue: string;
  cursor: number;
  placeholder: string;
  summaryLine?: string;
  statusLine: string;
  overlayLines?: string[];
  overlayKind?: 'generic' | 'permission' | 'feedback' | 'queued' | 'question';
  owner?: 'input' | 'renderer';
}

const RESET_SCROLL_REGION = '\x1b[r';
const SET_SCROLL_REGION = '\x1b[1;%dr';
const CLEAR_LINE = '\x1b[2K';
const HIDE_CURSOR = '\x1b[?25l';
const SHOW_CURSOR = '\x1b[?25h';
const MOVE_TO_ROW = '\x1b[%d;1H';
// Cursor movement
const CURSOR_DOWN_999 = '\x1b[999B';
const CURSOR_UP = '\x1b[%dA';
const CURSOR_HOME = '\r';

// Input bar styling
const INPUT_BG = '\x1b[48;5;238m';   // Darker gray background
const PROMPT_FG = '\x1b[1;36m';      // Bold cyan for ❯
const RESET_FG = '\x1b[22;39m';      // Reset bold + fg, keep bg
const RESET_ALL = '\x1b[0m';
const DIM = '\x1b[2m';
const MAX_INPUT_ROWS = 6;
const INPUT_PADDING_ROWS = 1;
const INPUT_BOTTOM_PADDING_ROWS = 1;

function shouldCompactSubmittedInputForWindowsTmux(): boolean {
  return process.platform === 'win32' && Boolean(process.env.TMUX);
}

function shouldSkipPermissionOverlayReserve(): boolean {
  return process.platform === 'win32' && Boolean(process.env.TMUX);
}

function getFooterPromptGlyph(): string {
  return shouldCompactSubmittedInputForWindowsTmux() ? '>' : '❯';
}

function getSafeRenderWidth(width: number): number {
  const margin = shouldCompactSubmittedInputForWindowsTmux() ? 2 : 1;
  return Math.max(1, width - margin);
}

interface FooterInputState {
  visibleStart: number;
  visibleLines: string[];
  cursorVisualLine: number;
  cursorColumn: number;
}

interface WrappedFooterLine {
  text: string;
  cursorColumn?: number;
}

export class ScrollRegionManager {
  private active = false;
  // SSH forwards TERM, whereas TERM_PROGRAM is often only available locally.
  // Multiplexers own their own grid/reflow and must not inherit this protocol.
  private savedContentCursor = false;
  private readonly redrawablePrompt = !process.env.TMUX && !process.env.STY
    && (process.env.TERM === 'xterm-ghostty' || process.env.TERM_PROGRAM === 'ghostty');
  private config: ScrollRegionConfig;
  private lastActivityLine = '';
  private lastActivityRow: number | null = null;
  private lastActivityRows = 0;
  private lastInputPrompt = '';
  private lastSummaryLine = '';
  private lastStatusLine = '';
  private lastInputValue = '';
  private lastInputCursor = 0;
  private lastOverlayRenderRows = 0;
  /** Number of terminal rows the welcome screen occupies. */
  private _welcomeRows = 0;
  /** Total content rows written since begin() (including welcome). */
  private _totalRows = 0;
  /** Whether content is currently being streamed. */
  private _contentStreaming = false;
  /** Whether any markdown content has been streamed yet. */
  private _hasStreamedContent = false;
  /** Whether a renderer-owned permission overlay currently owns the prompt/footer area. */
  private _overlayPromptVisible = false;
  /** Active overlay kind currently rendered above the footer input, if any. */
  private _activeOverlayKind: ScrollPromptFrame['overlayKind'] | null = null;
  /** Which subsystem last rendered the active overlay. */
  private _activeOverlayOwner: ScrollPromptFrame['owner'] | null = null;
  /** Last overlay lines, used to preserve queued overlays across footer redraws. */
  private lastOverlayLines: string[] = [];
  /** Footer is currently visible on screen. */
  private _footerVisible = false;
  /** Tracks if we have already pushed past the welcome screen. */
  private _pastWelcome = false;
  /** Last row containing content (before footer). Updated at end of streaming. */
  private _contentEndRow = 0;
  /** Actual terminal cursor row (1-based), tracked by counting \n writes. */
  private _cursorRow = 1;
  /** Actual terminal cursor, which usually sits in the editor rather than content. */
  private _terminalCursorRow = 1;
  /** Actual terminal cursor column (0-based), for wrapping calculation. */
  private _cursorCol = 0;
  /** Internal flag: cursor position may be unreliable (just after screen clear). */
  private _cursorUncertain = false;
  /** Content row where the current markdown streaming block began. */
  private _streamStartRow = 1;
  /** Number of rows currently occupied by the input editor above status. */
  private lastInputRenderRows = 1 + INPUT_PADDING_ROWS + INPUT_BOTTOM_PADDING_ROWS;
  /** Last screen rows occupied by footer/overlay chrome, used to clear stale rows after terminal resize. */
  private lastFooterClearStartRow = 0;
  private lastFooterClearEndRow = 0;
  private lastOverlayClearStartRow = 0;


  constructor(
    private readonly stream: NodeJS.WriteStream = process.stdout,
    config?: ScrollRegionConfig,
  ) {
    const rows = stream.rows ?? 24;
    const columns = stream.columns ?? 80;
    this.config = config ?? {
      footerHeight: 3, // Input padding row + input bar + status bar
      gapHeight: 3,    // Conservative empty gap between transcript/activity/overlay and input bar
      rows,
      columns,
    };
  }

  private semanticOutput(): string {
    return this.redrawablePrompt ? '\x1b]133;C\x07' : '';
  }

  private semanticInput(): string {
    return this.redrawablePrompt ? '\x1b]133;B\x07' : '';
  }

  private semanticPrompt(startRow: number, endRow: number): string {
    // Mark continuation rows too: a physical resize may trim the initial blank
    // padding row. Continuations stop prompt lookup at the transcript boundary.
    // P marks an existing row; unlike A, it never inserts a fresh line.
    if (!this.redrawablePrompt) return '';
    this.savedContentCursor = true;
    // CUP clamps columns beyond the right margin. Save the next blank row for
    // deferred wrap, so later ED cannot erase the final character of the line.
    const pendingWrap = this._cursorCol >= this.config.columns;
    const row = this._cursorRow + (pendingWrap ? 1 : 0);
    const column = pendingWrap ? 1 : this._cursorCol + 1;
    let output = `${this.semanticOutput()}\x1b[${row};${column}H\x1b7`;
    for (let row = startRow; row <= endRow; row++) {
      output += `\x1b[${row};1H\x1b]133;P;k=${row === startRow ? 'i' : 's'}\x07`;
    }
    return output;
  }

  private clampCursorRow(row: number): number {
    return Math.max(1, Math.min(row, this.getScrollBottom()));
  }

  private maxInputRows(): number {
    return Math.max(1, Math.min(MAX_INPUT_ROWS, this.config.rows - this.config.gapHeight - 4));
  }

  private countFooterLineRows(text: string): number {
    if (!text) {
      return 0;
    }
    const cols = Math.max(1, this.config.columns);
    return Math.max(1, Math.ceil(getDisplayWidth(stripAnsi(text)) / cols));
  }

  private getSummaryReserveRows(summaryLine = this.lastSummaryLine): number {
    return this.countFooterLineRows(summaryLine);
  }

  private getSummaryStartRow(inputStartRow: number, summaryLine = this.lastSummaryLine): number {
    const summaryRows = this.getSummaryReserveRows(summaryLine);
    if (summaryRows <= 0) {
      return -1;
    }
    return Math.max(1, inputStartRow - 1 - summaryRows);
  }

  private getScrollBottomForLayout(
    inputFrameRows: number,
    overlayRows: number,
    summaryLine: string,
  ): number {
    const summaryReserveRows = this.getSummaryReserveRows(summaryLine);
    const reservedRowsAboveInput = overlayRows > 0
      ? overlayRows + this.config.gapHeight + summaryReserveRows
      : this.config.gapHeight + summaryReserveRows;
    const overlayStartRow = this.getInputStartRow(inputFrameRows) - reservedRowsAboveInput;
    const leadingGapRows = overlayRows > 0 && overlayStartRow >= 3 ? 1 : 0;
    return Math.max(1, overlayStartRow - leadingGapRows - 1);
  }

  /**
   * Calculate the bottom row of the scroll region (where activity line renders).
   */
  private getScrollBottom(): number {
    return this.getScrollBottomForLayout(
      this.lastInputRenderRows,
      this.lastOverlayRenderRows,
      this.lastSummaryLine,
    );
  }

  private getActivityRow(): number {
    const scrollBottom = this.getScrollBottom();
    // Use the existing footer gap: content ends at B, B+1 stays blank,
    // activity occupies B+2, and B+3 separates it from the input frame.
    // Never shrink or scroll the transcript merely to make this spacing.
    return Math.min(this.getInputStartRow() - 2, scrollBottom + 2);
  }

  /**
   * Calculate the input bar row where the last input line sits.
   */
  private getInputBarRow(): number {
    return this.getStatusBarRow() - 1;
  }

  private getInputFrameRows(inputRows = 1): number {
    return inputRows + INPUT_PADDING_ROWS + INPUT_BOTTOM_PADDING_ROWS;
  }

  private getInputStartRow(frameRows = this.lastInputRenderRows): number {
    return Math.max(1, this.getInputBarRow() - frameRows + 1);
  }

  private getInputTextStartRow(inputRows: number): number {
    return this.getInputStartRow(this.getInputFrameRows(inputRows)) + INPUT_PADDING_ROWS;
  }

  /**
   * Calculate the status bar row (fixed footer bottom row).
   */
  private getStatusBarRow(): number {
    return this.config.rows;
  }

  private getOverlayVisibleLines(
    lines: string[],
    inputRows: number,
    overlayKind?: ScrollPromptFrame['overlayKind'],
  ): string[] {
    const inputFrameRows = this.getInputFrameRows(inputRows);
    const availableRows = Math.max(
      0,
      this.config.rows - inputFrameRows - 1 - this.config.gapHeight - this.getSummaryReserveRows(),
    );
    // Keep the transcript tail (including its final newline) and a separator
    // above menus. In tiny terminals prioritize visible choices and the input.
    const maxOverlayRows = availableRows >= 4
      ? availableRows - 3
      : Math.max(0, availableRows - (availableRows > 1 ? 1 : 0));
    if (maxOverlayRows <= 0) {
      return [];
    }
    if (overlayKind === 'queued') {
      if (maxOverlayRows === 1 && lines.length > 1) {
        const compactText = lines.slice(1).join(' ').trim();
        return [`${lines[0]} ${compactText}`.trim()];
      }
      return lines.slice(0, maxOverlayRows);
    }
    // Question menus need a moving option window: a fixed top slice hides both
    // the selection and the navigation hint after moving to a later choice.
    if (overlayKind === 'question') {
      if (lines.length <= maxOverlayRows) return lines;
      const optionIndices = lines.flatMap((line, index) => (
        /^\s*(?:❯\s*)?\d+\./u.test(stripAnsi(line)) ? [index] : []
      ));
      if (optionIndices.length === 0) return lines.slice(0, maxOverlayRows);
      const firstOption = optionIndices[0];
      const lastOption = optionIndices[optionIndices.length - 1];
      const prefix = lines.slice(0, firstOption);
      const hasHintRoom = maxOverlayRows >= prefix.length + 2;
      const visiblePrefix = prefix.slice(0, Math.max(0, maxOverlayRows - 1));
      const hint = hasHintRoom && lastOption < lines.length - 1 ? lines.at(-1) : undefined;
      const optionBudget = maxOverlayRows - visiblePrefix.length - (hint ? 1 : 0);
      const options = lines.slice(firstOption, lastOption + 1);
      const selected = Math.max(0, options.findIndex(line => /^\s*❯\s*\d+\./u.test(stripAnsi(line))));
      const start = Math.max(0, Math.min(selected - optionBudget + 1, options.length - optionBudget));
      return [...visiblePrefix, ...options.slice(start, start + optionBudget), ...(hint ? [hint] : [])];
    }
    return lines.slice(-maxOverlayRows);
  }

  hasActiveOverlayPrompt(): boolean {
    return this.lastOverlayRenderRows > 0 && this._activeOverlayKind !== null;
  }

  private isRendererPermissionOverlayActive(): boolean {
    return this._activeOverlayKind === 'permission' && this._activeOverlayOwner === 'renderer';
  }

  private clearActiveOverlayPrompt(): void {
    this._overlayPromptVisible = false;
    this._activeOverlayKind = null;
    this._activeOverlayOwner = null;
    this.lastOverlayLines = [];
  }

  private clearScreenRow(row: number): void {
    this.stream.write(`\x1b[${row};1H${CLEAR_LINE}`);
    this._terminalCursorRow = row;
  }

  private getClearScreenRowSequence(row: number): string {
    return `\x1b[${row};1H${CLEAR_LINE}`;
  }

  private composeActivityLineRender(activityLine: string): string {
    const activityRow = this.getActivityRow();
    const allLines = activityLine.split('\n');
    // Leave at least half the content region available for transcript. Only
    // overflow pages rotate; the main activity always stays on the last row.
    const budget = Math.max(1, Math.floor(activityRow / 2));
    let lines = allLines;
    if (allLines.length > budget) {
      const slots = Math.max(0, budget - 1);
      const children = allLines.slice(0, -1);
      const page = Math.floor(Date.now() / 4000) % Math.max(1, Math.ceil(children.length / Math.max(1, slots)));
      lines = [...children.slice(page * slots, (page + 1) * slots), allLines[allLines.length - 1]];
    }
    const firstRow = activityRow - lines.length + 1;
    let output = this.semanticOutput() + this.composeActivityClear();
    // Clear old rows before scrolling so stale activity never enters history.
    // Single-line activity keeps its existing overlay behavior.
    if (lines.length > 1) {
      output += this.reserveTranscriptRows(Math.max(1, firstRow - 1), this.getScrollBottom(), false);
    }
    lines.forEach((line, index) => {
      output += `${MOVE_TO_ROW.replace('%d', String(firstRow + index))}${CLEAR_LINE}${truncateAnsi(line, getSafeRenderWidth(this.config.columns))}\x1b[0m`;
    });
    this.lastActivityRow = firstRow;
    this.lastActivityRows = lines.length;
    this._terminalCursorRow = activityRow;
    return output;
  }

  private composeActivityClear(rowShift = 0, maxRow = this.config.rows): string {
    let output = '';
    if (this.lastActivityRow !== null) {
      for (let index = 0; index < this.lastActivityRows; index++) {
        const oldRow = this.lastActivityRow + index;
        const row = oldRow - rowShift;
        if (row >= 1 && row <= maxRow) {
          output += `${MOVE_TO_ROW.replace('%d', String(row))}${CLEAR_LINE}`;
          this._terminalCursorRow = row;
        }
      }
    }
    this.lastActivityRow = null;
    this.lastActivityRows = 0;
    return output;
  }

  private clearActivityIfContentWillUseRow(row: number): void {
    if (this.lastActivityRow === null) return;
    const overlapsActivity = row >= this.lastActivityRow && row < this.lastActivityRow + this.lastActivityRows;
    const resumesAtContentBoundary = row >= this.getScrollBottom() && this.lastActivityRow > this.getScrollBottom();
    if (overlapsActivity || resumesAtContentBoundary) this.clearActivity();
  }

  private clearRenderedFooterRows(rowShift = 0, maxRow = this.config.rows): void {
    const fallbackStart = this.getInputStartRow();
    const fallbackEnd = this.getStatusBarRow();
    const start = this.lastFooterClearStartRow || fallbackStart;
    const end = this.lastFooterClearEndRow || fallbackEnd;

    for (let row = Math.max(1, start - rowShift); row <= Math.min(maxRow, Math.max(start, end) - rowShift); row += 1) {
      this.clearScreenRow(row);
    }
  }

  private clearPromptChromeRows(): void {
    const fallbackStart = this.getInputStartRow();
    const fallbackEnd = this.getStatusBarRow();
    const cachedStart = Math.min(
      this.lastFooterClearStartRow || fallbackStart,
      this.lastOverlayClearStartRow || fallbackStart,
      fallbackStart,
    );
    const start = shouldCompactSubmittedInputForWindowsTmux()
      ? Math.max(1, cachedStart - this.config.gapHeight - 1)
      : cachedStart;
    const end = this.lastFooterClearEndRow || fallbackEnd;

    this.stream.write(RESET_SCROLL_REGION);
    for (let row = Math.max(1, start); row <= Math.max(start, end); row += 1) {
      this.clearScreenRow(row);
    }
    this.setScrollRegion();
  }

  private clearSummaryChromeRows(): void {
    const summaryRows = this.getSummaryReserveRows(this.lastSummaryLine);
    if (summaryRows <= 0) {
      return;
    }
    const summaryStartRow = this.getSummaryStartRow(this.getInputStartRow(), this.lastSummaryLine);
    if (summaryStartRow < 1) {
      return;
    }

    this.stream.write(RESET_SCROLL_REGION);
    for (let row = summaryStartRow; row < summaryStartRow + summaryRows; row += 1) {
      this.clearScreenRow(row);
    }
    this.setScrollRegion();
  }

  /**
   * Calculate cursor column after the "❯ " prefix.
   * "❯" is at column 1, space at column 2, text starts at column 3.
   */
  private getCursorBase(): number {
    return 3;
  }

  private getFooterTextWidth(): number {
    return Math.max(1, this.config.columns - this.getCursorBase() + 1);
  }

  private wrapFooterLine(line: string, maxWidth: number, cursorSentinel: string): WrappedFooterLine[] {
    const wrapped: WrappedFooterLine[] = [];
    const symbols = splitSymbols(line);
    let current = '';
    let currentWidth = 0;
    let currentCursorColumn: number | undefined;

    const pushCurrent = () => {
      wrapped.push({
        text: current,
        cursorColumn: currentCursorColumn,
      });
      current = '';
      currentWidth = 0;
      currentCursorColumn = undefined;
    };

    for (const symbol of symbols) {
      if (symbol === cursorSentinel) {
        if (currentWidth >= maxWidth) {
          pushCurrent();
        }
        currentCursorColumn = currentWidth;
        continue;
      }

      const symbolWidth = Math.max(1, getDisplayWidth(symbol));
      if (current !== '' && currentWidth + symbolWidth > maxWidth) {
        pushCurrent();
      }

      current += symbol;
      currentWidth += symbolWidth;
    }

    if (current.length > 0 || currentCursorColumn !== undefined || wrapped.length === 0) {
      pushCurrent();
    }

    return wrapped;
  }

  private getFooterInputState(inputValue: string, cursor: number): FooterInputState {
    const cursorSentinel = '\uFFF0';
    const safeCursor = Math.max(0, Math.min(cursor, inputValue.length));
    const inputWithCursor = `${inputValue.slice(0, safeCursor)}${cursorSentinel}${inputValue.slice(safeCursor)}`;
    const rawLines = inputWithCursor.split('\n');
    const wrappedLines: string[] = [];
    const maxWidth = this.getFooterTextWidth();
    let cursorVisualLine = 0;
    let cursorColumn = 0;

    rawLines.forEach((line) => {
      const wrapped = this.wrapFooterLine(line, maxWidth, cursorSentinel);
      wrapped.forEach((entry) => {
        if (entry.cursorColumn !== undefined) {
          cursorVisualLine = wrappedLines.length;
          cursorColumn = entry.cursorColumn;
        }
        wrappedLines.push(entry.text);
      });
    });

    const maxRows = this.maxInputRows();
    const maxStart = Math.max(0, wrappedLines.length - maxRows);
    const visibleStart = Math.min(Math.max(0, cursorVisualLine - maxRows + 1), maxStart);
    const visibleLines = wrappedLines.slice(visibleStart, visibleStart + maxRows);

    return {
      visibleStart,
      visibleLines,
      cursorVisualLine,
      cursorColumn,
    };
  }

  /**
   * Update terminal size.
   */
  updateSize(rows: number, columns: number): void {
    if (rows === this.config.rows && columns === this.config.columns) return;
    const measuredCursor = this.active && this.redrawablePrompt && this.savedContentCursor
      ? readTerminalCursor(this.stream, this.semanticOutput() + RESET_SCROLL_REGION + '\x1b8')
      : null;
    if (measuredCursor?.rows && measuredCursor.columns) {
      rows = measuredCursor.rows;
      columns = measuredCursor.columns;
    }
    const previousScrollBottom = this.getScrollBottom();
    const hadChrome = this._footerVisible || this.lastActivityRow !== null || this.hasActiveOverlayPrompt();
    const pulledHistoryRows = Math.min(Math.max(0, rows - this.config.rows), Math.max(0, this._totalRows - this._cursorRow));
    // A shrinking terminal keeps the physical cursor in view and may clip the
    // rows below it. It does not necessarily scroll by the whole height delta.
    const rowShift = measuredCursor ? this._cursorRow - measuredCursor.row : !hadChrome ? 0 : rows < this.config.rows
      ? Math.max(0, Math.min(this.config.rows, this._terminalCursorRow) - rows)
      : -pulledHistoryRows;
    const visiblePreviousBottom = measuredCursor ? rows : Math.max(1, Math.min(rows, previousScrollBottom - rowShift));
    if (this.active) {
      // CPR leaves the cursor at the reflowed content anchor. Clear detached
      // SSH chrome here, before DECSTBM homes the physical cursor.
      if (measuredCursor) this.stream.write(RESET_ALL + '\x1b[J');
      this.stream.write(this.semanticOutput() + RESET_SCROLL_REGION);
      if (measuredCursor) {
        this.lastActivityRow = null;
        this.lastActivityRows = 0;
      } else {
        this.stream.write(this.composeActivityClear(rowShift, rows));
      }
      // Ghostty erases the semantic prompt before reflow. Its resulting row
      // positions cannot be reconstructed from the old height alone, and old
      // absolute chrome coordinates may now contain transcript text.
      if (!this.redrawablePrompt) this.clearRenderedFooterRows(rowShift, rows);
      // The terminal has already moved its visible rows upward on shrink.
      // Move content anchors too, including idle input (without activity).
      this._cursorRow = Math.max(1, this._cursorRow - rowShift);
      if (measuredCursor) this._cursorCol = measuredCursor.column - 1;
      this._contentEndRow = Math.max(0, this._contentEndRow - rowShift);
      this._streamStartRow = Math.max(1, this._streamStartRow - rowShift);
      this._terminalCursorRow = Math.max(1, Math.min(rows, this._terminalCursorRow - rowShift));
    }

    this.config = { ...this.config, rows, columns };
    if (this.active) {
      this.reserveTranscriptRows(this.getScrollBottom(), visiblePreviousBottom);
      // Reflow can move chrome away from its old absolute rows. Clear the
      // unoccupied tail before restoring it, preserving the transcript cursor.
      const firstEmptyRow = this._cursorRow + (this._cursorCol > 0 ? 1 : 0);
      for (let row = firstEmptyRow; !this.redrawablePrompt && row <= visiblePreviousBottom; row++) {
        this.clearScreenRow(row);
      }
      // Re-apply scroll region with new size
      this.setScrollRegion();
      if (this.hasActiveOverlayPrompt()) {
        this.renderPromptFrame({
          inputValue: this.lastInputValue,
          cursor: this.lastInputCursor,
          placeholder: this.lastInputPrompt,
          summaryLine: this.lastSummaryLine,
          statusLine: this.lastStatusLine,
          overlayLines: this.lastOverlayLines,
          overlayKind: this._activeOverlayKind ?? undefined,
          owner: this._activeOverlayOwner ?? undefined,
        });
      } else {
        this.renderFooter();
      }
    }
  }

  /**
   * Activate scroll region mode.
   * Clears the screen and moves cursor to top,
   * so the welcome screen fills the entire visible area.
   */
  begin(): void {
    if (this.active) return;

    this.active = true;
    this.savedContentCursor = false;
    this.lastActivityLine = '';
    this.lastActivityRow = null;
    this.lastInputPrompt = '';
    this.lastInputValue = '';
    this.lastInputCursor = 0;
    this.lastSummaryLine = '';
    this.lastStatusLine = '';
    this.lastInputRenderRows = this.getInputFrameRows(1);
    this.lastFooterClearStartRow = 0;
    this.lastFooterClearEndRow = 0;
    this.lastOverlayClearStartRow = 0;
    this.clearActiveOverlayPrompt();

    // Set scroll region (rows 1 to scrollBottom)
    this.setScrollRegion();

    // Clear entire screen and move cursor to top-left.
    // \x1b[2J clears all lines, \x1b[H homes the cursor.
    // This pushes the shell command that launched the CLI off screen.
    this.stream.write(`\x1b[2J\x1b[H`);

    // Don't render footer here - it will be rendered by beginActivity()
  }

  /**
   * Deactivate scroll region mode.
   * Restores normal terminal scrolling and clears footer area.
   */
  end(): void {
    if (!this.active) return;
    this.stream.write(this.semanticOutput());

    this.active = false;

    // Reset scroll region to full terminal
    this.stream.write(`\x1b[0m\x1b[?25h${RESET_SCROLL_REGION}`);

    // Clear footer area: status row plus currently expanded input rows.
    this.stream.write(CURSOR_DOWN_999);
    this.stream.write(CLEAR_LINE);
    for (let row = 0; row < this.lastInputRenderRows; row += 1) {
      this.stream.write(`${CURSOR_UP.replace('%d', '1')}${CLEAR_LINE}`);
    }

    // Move cursor to after the last content line
    this.stream.write(CURSOR_UP.replace('%d', '2'));
    this.stream.write('\n');

    this.lastActivityLine = '';
    this.lastActivityRow = null;
    this.lastInputPrompt = '';
    this.lastInputValue = '';
    this.lastStatusLine = '';
    this.lastSummaryLine = '';
    this.lastFooterClearStartRow = 0;
    this.lastFooterClearEndRow = 0;
    this.lastOverlayClearStartRow = 0;
    this.clearActiveOverlayPrompt();
  }

  resumeAfterExternalCommand(options?: {
    inputPrompt?: string;
    summaryLine?: string;
    statusLine?: string;
  }): void {
    if (this.active) {
      this.renderFooter(options);
      return;
    }

    this.active = true;
    this.lastActivityLine = '';
    this.lastActivityRow = null;
    this.lastInputPrompt = options?.inputPrompt ?? '';
    this.lastInputValue = '';
    this.lastInputCursor = 0;
    this.lastSummaryLine = options?.summaryLine ?? '';
    this.lastStatusLine = options?.statusLine ?? '';
    this.lastOverlayRenderRows = 0;
    this.lastInputRenderRows = this.getInputFrameRows(1);
    this.lastFooterClearStartRow = 0;
    this.lastFooterClearEndRow = 0;
    this.lastOverlayClearStartRow = 0;
    this.clearActiveOverlayPrompt();

    this._contentStreaming = false;
    this._hasStreamedContent = true;
    this._footerVisible = false;
    this._pastWelcome = true;
    this._welcomeRows = 0;
    this._cursorCol = 0;
    this._cursorUncertain = false;

    const footerReserveRows = this.getInputFrameRows(1)
      + this.config.gapHeight
      + this.getSummaryReserveRows(options?.summaryLine ?? '')
      + 1;
    // External commands can leave the terminal cursor inside the rows that the
    // fixed footer is about to clear. Scroll enough to preserve output even
    // when the cursor is at the top of that clear band, not only at the bottom.
    const preservedOutputPaddingRows = footerReserveRows * 2 - 1;
    this.stream.write(RESET_SCROLL_REGION);
    for (let row = 0; row < preservedOutputPaddingRows; row += 1) {
      this.stream.write('\n');
    }

    const scrollBottom = this.getScrollBottom();
    this._totalRows = scrollBottom;
    this._cursorRow = scrollBottom;
    this._contentEndRow = scrollBottom;
    this._streamStartRow = scrollBottom;

    this.setScrollRegion();
    this.renderFooter(options);
  }
  /**
   * Check if scroll region is active.
   */
  isActive(): boolean {
    return this.active;
  }

  renderPromptFrame(frame: ScrollPromptFrame): void {
    if (!this.active) return;

    const owner = frame.owner ?? 'input';
    this.lastInputValue = frame.inputValue;
    this.lastInputCursor = frame.cursor;
    this.lastInputPrompt = frame.placeholder;
    this.lastSummaryLine = frame.summaryLine ?? '';
    this.lastStatusLine = frame.statusLine;

    if ((frame.overlayLines?.length ?? 0) > 0) {
      this._activeOverlayKind = frame.overlayKind ?? 'generic';
      this._activeOverlayOwner = owner;
      this._overlayPromptVisible = this.isRendererPermissionOverlayActive();
      this.lastOverlayLines = [...(frame.overlayLines ?? [])];
      this.renderOverlayPromptFrame(frame);
      return;
    }

    if (this.isRendererPermissionOverlayActive() && owner !== 'renderer') {
      return;
    }

    this.clearActiveOverlayPrompt();
    this.renderFooter({
      inputPrompt: frame.placeholder,
      summaryLine: frame.summaryLine,
      statusLine: frame.statusLine,
    });
    this.lastOverlayRenderRows = 0;
  }

  /**
   * Render input in the fixed footer area.
   * This should be called when user types during streaming.
   * @param inputValue - The current input value (may contain newlines)
   * @param cursor - Cursor position in the input value
   */
  renderInput(inputValue: string, cursor: number): void {
    if (!this.active) {
      // Not in scroll region mode, use inline rendering
      const cursorWidth = getDisplayWidth(inputValue.slice(0, cursor));
      const cursorCol = this.getCursorBase() + cursorWidth;
      this.stream.write(`\r${CLEAR_LINE}${INPUT_BG}${PROMPT_FG}❯${RESET_FG} ${inputValue}${RESET_ALL}`);
      this.stream.write(`\x1b[1;${cursorCol}H`);
      return;
    }

    this.lastInputValue = inputValue;
    this.lastInputCursor = cursor;

    this.renderFooter();
  }

  /**
   * Update the footer content (input prompt and status line).
   * Call this when the activity label changes or to update status.
   * This only updates the status line, not the input bar.
   * After rendering, cursor is positioned at input line for typing.
   */
  updateFooter(inputPrompt: string, summaryLine?: string, statusLine?: string): void {
    if (!this.active) return;

    this.lastInputPrompt = inputPrompt;
    if (summaryLine !== undefined) {
      this.lastSummaryLine = summaryLine;
    }
    if (statusLine !== undefined) {
      this.lastStatusLine = statusLine;
    }

    const inputStartRow = this.getInputStartRow();
    const summaryStartRow = this.getSummaryStartRow(inputStartRow, this.lastSummaryLine);
    const summaryRows = this.getSummaryReserveRows(this.lastSummaryLine);
    const statusBarRow = this.getStatusBarRow();

    if (summaryStartRow >= 1) {
      for (let row = summaryStartRow; row < summaryStartRow + summaryRows; row += 1) {
        this.stream.write(`${MOVE_TO_ROW.replace('%d', String(row))}${CLEAR_LINE}`);
      }
      if (this.lastSummaryLine) {
        this.stream.write(`${MOVE_TO_ROW.replace('%d', String(summaryStartRow))}`);
        this.stream.write(this.lastSummaryLine);
      }
    }
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(statusBarRow))}${CLEAR_LINE}`);
    if (statusLine) {
      this.stream.write(this.renderSingleFooterTextLine(statusLine, this.config.columns));
    }

    // Position cursor at input line for typing
    this.positionCursorForInput();
  }

  /**
   * Render the footer area (input prompt + status bar).
   * Status bar shows static info like model, percentage, branch, project.
   * After rendering, cursor is positioned at input line for user typing.
   */
  private renderFooterFrame(
    options: {
      inputPrompt?: string;
      summaryLine?: string;
      statusLine?: string;
    } | undefined,
    restoreActivity: boolean,
    footerOnly = false,
  ): void {
    if (!this.active) return;

    this._footerVisible = true;
    // Retain the old footprint clear in this frame. Sending a separate clear
    // exposes a blank SubAgent/activity area on every animation tick.
    const previousActivityClear = this.composeActivityClear();

    const cols = this.config.columns;
    const previousInputRows = this.lastInputRenderRows;
    const previousOverlayRows = this.lastOverlayRenderRows;
    const previousSummaryLine = this.lastSummaryLine;
    const previousScrollBottom = this.getScrollBottomForLayout(
      previousInputRows,
      previousOverlayRows,
      previousSummaryLine,
    );

    // Use inputPrompt as a placeholder text when no user input
    const inputPrompt = options?.inputPrompt ?? this.lastInputPrompt ?? 'waiting...';
    const summaryLine = options?.summaryLine ?? this.lastSummaryLine ?? '';
    const statusLine = options?.statusLine ?? this.lastStatusLine ?? '';

    // Update cached values
    if (options?.inputPrompt) this.lastInputPrompt = options.inputPrompt;
    if (options?.summaryLine !== undefined) this.lastSummaryLine = options.summaryLine;
    if (options?.statusLine) this.lastStatusLine = options.statusLine;

    const inputState = this.lastInputValue
      ? this.getFooterInputState(this.lastInputValue, this.lastInputCursor)
      : undefined;
    const inputLines = inputState?.visibleLines ?? [inputPrompt];
    const inputRows = Math.max(1, inputLines.length);
    const inputFrameRows = this.getInputFrameRows(inputRows);
    const isPlaceholder = !this.lastInputValue;
    const nextScrollBottom = this.getScrollBottomForLayout(inputFrameRows, 0, summaryLine);

    // Use absolute row positioning instead of cursor-down-999 which may be
    // unreliable in some terminals. Calculate exact footer rows.
    const statusBarRow = this.getStatusBarRow();
    const previousInputStartRow = this.getInputStartRow(previousInputRows);
    const inputStartRow = this.getInputStartRow(inputFrameRows);
    const inputTextStartRow = inputStartRow + INPUT_PADDING_ROWS;
    const inputEndRow = this.getInputBarRow();

    // Reset scroll region to allow writing to footer area. Batch the footer
    // redraw into a single terminal write so prompt/status don't flicker apart.
    let footerOutput = `${this.semanticOutput()}${RESET_SCROLL_REGION}${SHOW_CURSOR}${previousActivityClear}`;

    // Clear previous and current editor rows. This prevents stale rows when
    // the input grows or shrinks between redraws.
    const previousOverlayStartRow = previousOverlayRows > 0
      ? Math.max(
        1,
        previousInputStartRow - previousOverlayRows - this.config.gapHeight - this.getSummaryReserveRows(previousSummaryLine),
      )
      : previousInputStartRow;
    if (previousOverlayRows > 0) {
      this.lastOverlayClearStartRow = Math.min(
        this.lastOverlayClearStartRow || previousOverlayStartRow,
        previousOverlayStartRow,
      );
    }
    const currentFooterClearStartRow = Math.max(1, inputStartRow - this.config.gapHeight - this.getSummaryReserveRows(summaryLine));
    const previousFooterClearStartRow = Math.max(
      1,
      previousInputStartRow - this.config.gapHeight - this.getSummaryReserveRows(previousSummaryLine),
    );
    const footerClearStartRow = Math.min(currentFooterClearStartRow, previousFooterClearStartRow);
    const transientClearStartRow = previousOverlayRows > 0
      ? Math.max(1, this._cursorRow + 1)
      : previousOverlayStartRow;
    const clearStartRow = footerOnly
      ? footerClearStartRow
      : Math.max(1, Math.min(previousOverlayStartRow, footerClearStartRow, transientClearStartRow));
    footerOutput += this.reserveTranscriptRows(nextScrollBottom, previousScrollBottom, false);
    for (let row = clearStartRow; row <= inputEndRow; row += 1) {
      // Current editor rows are overwritten below and erased to end-of-line.
      // Clearing them first exposes a blank draft on every activity tick.
      if (row < inputStartRow) footerOutput += this.getClearScreenRowSequence(row);
    }
    if (shouldCompactSubmittedInputForWindowsTmux()) {
      footerOutput += SET_SCROLL_REGION.replace('%d', String(this.getScrollBottom()));
      for (let row = clearStartRow; row <= statusBarRow; row += 1) {
        if (row < inputStartRow || row > inputEndRow) footerOutput += this.getClearScreenRowSequence(row);
      }
    }

    const summaryStartRow = this.getSummaryStartRow(inputStartRow, summaryLine);
    footerOutput += this.semanticPrompt(currentFooterClearStartRow, statusBarRow);
    if (summaryStartRow >= 1 && summaryLine) {
      footerOutput += `\x1b[${summaryStartRow};1H`;
      footerOutput += summaryLine;
    }

    for (let index = 0; index < INPUT_PADDING_ROWS; index += 1) {
      const row = inputStartRow + index;
      footerOutput += `\x1b[${row};1H`;
      footerOutput += this.padBackgroundRow(cols);
    }

    inputLines.forEach((line, index) => {
      const row = inputTextStartRow + index;
      const prefix = index === 0
        ? `${INPUT_BG}${PROMPT_FG}${getFooterPromptGlyph()}${RESET_FG} `
        : `${INPUT_BG}  `;
      footerOutput += `\x1b[${row};1H`;
      if (isPlaceholder) {
        footerOutput += this.padLineWithBg(`${prefix}${DIM}${line}`, cols);
      } else {
        footerOutput += this.padLineWithBg(`${prefix}${line}`, cols);
      }
    });

    for (let index = 0; index < INPUT_BOTTOM_PADDING_ROWS; index += 1) {
      const row = inputTextStartRow + inputLines.length + index;
      footerOutput += `\x1b[${row};1H`;
      footerOutput += this.padBackgroundRow(cols);
    }

    // Status bar (bottom row) is rendered last so any footer-line wrap quirks
    // in the input editor cannot leave stale status text above it.
    footerOutput += `\x1b[${statusBarRow};1H${CLEAR_LINE}`;
    if (statusLine) {
      footerOutput += this.renderSingleFooterTextLine(statusLine, cols);
    }

    this.lastInputRenderRows = inputFrameRows;
    this.lastOverlayRenderRows = 0;
    this.lastFooterClearStartRow = clearStartRow;
    this.lastFooterClearEndRow = statusBarRow;

    // Restore scroll region. Windows tmux is sensitive to applying DECSTBM
    // after writing the footer rows, so keep the region active before footer
    // output on that path and skip the second application here.
    if (!shouldCompactSubmittedInputForWindowsTmux()) {
      footerOutput += SET_SCROLL_REGION.replace('%d', String(this.getScrollBottom()));
    }

    if (restoreActivity && this.lastActivityLine && !this._contentStreaming && !this.hasActiveOverlayPrompt()) {
      footerOutput += this.composeActivityLineRender(this.lastActivityLine);
    }

    // Keep the final cursor move in the same write as the editor frame so the
    // visible cursor cannot linger on the status/activity row between writes.
    footerOutput += this.getInputCursorSequence();
    this.stream.write(footerOutput);
  }

  renderFooter(options?: {
    inputPrompt?: string;
    summaryLine?: string;
    statusLine?: string;
  }): void {
    if (this.hasActiveOverlayPrompt() && this._activeOverlayKind === 'queued' && this.lastOverlayLines.length > 0) {
      this.renderPromptFrame({
        inputValue: this.lastInputValue,
        cursor: this.lastInputCursor,
        placeholder: options?.inputPrompt ?? this.lastInputPrompt ?? 'waiting...',
        summaryLine: options?.summaryLine ?? this.lastSummaryLine,
        statusLine: options?.statusLine ?? this.lastStatusLine,
        overlayLines: this.lastOverlayLines,
        overlayKind: 'queued',
        owner: this._activeOverlayOwner ?? 'input',
      });
      return;
    }
    this.renderFooterFrame(options, true);
  }

  private reserveTranscriptRows(nextScrollBottom: number, previousScrollBottom: number, emit = true): string {
    const clampedCurrentBottom = Math.max(1, previousScrollBottom);
    const occupiedContentRow = this._cursorCol > 0
      ? this._cursorRow + 1
      : this._cursorRow;
    const visibleContentRow = Math.max(1, Math.min(occupiedContentRow, clampedCurrentBottom));
    const rowsToScroll = Math.max(0, visibleContentRow - nextScrollBottom);
    if (rowsToScroll === 0) {
      return '';
    }

    const output = SET_SCROLL_REGION.replace('%d', String(clampedCurrentBottom))
      + MOVE_TO_ROW.replace('%d', String(clampedCurrentBottom))
      + '\n'.repeat(rowsToScroll);
    if (emit) this.stream.write(output);

    this._cursorRow = Math.max(1, this._cursorRow - rowsToScroll);
    this._contentEndRow = Math.max(0, this._contentEndRow - rowsToScroll);
    this._streamStartRow = Math.max(1, this._streamStartRow - rowsToScroll);
    this._cursorUncertain = false;
    return output;
  }

  private renderOverlayPromptFrame(frame: ScrollPromptFrame): void {
    this.stream.write(this.semanticOutput() + this.composeActivityClear());
    const overlayKind = frame.overlayKind ?? 'generic';
    const isPermissionOverlay = overlayKind === 'permission';
    const keepStatusLineVisible = (
      (isPermissionOverlay && !shouldSkipPermissionOverlayReserve())
      || overlayKind === 'feedback'
      || overlayKind === 'queued'
    );
    this._footerVisible = isPermissionOverlay || keepStatusLineVisible;
    const cols = this.config.columns;
    const previousInputRows = this.lastInputRenderRows;
    const previousOverlayRows = this.lastOverlayRenderRows;
    const previousScrollBottom = this.getScrollBottom();
    const inputState = this.lastInputValue
      ? this.getFooterInputState(this.lastInputValue, this.lastInputCursor)
      : undefined;
    const inputLines = inputState?.visibleLines ?? [frame.placeholder];
    const inputRows = Math.max(1, inputLines.length);
    const inputFrameRows = this.getInputFrameRows(inputRows);
    const overlayLines = this.getOverlayVisibleLines(frame.overlayLines ?? [], inputRows, overlayKind);
    const overlayRows = overlayLines.length;
    const summaryReserveRows = this.getSummaryReserveRows(frame.summaryLine ?? this.lastSummaryLine);
    const statusBarRow = this.getStatusBarRow();
    const inputStartRow = this.getInputStartRow(inputFrameRows);
    const inputTextStartRow = inputStartRow + INPUT_PADDING_ROWS;
    const overlayStartRow = Math.max(1, inputStartRow - this.config.gapHeight - summaryReserveRows - overlayRows);
    const previousOverlayStartRow = Math.max(
      1,
      this.getInputStartRow(previousInputRows) - this.config.gapHeight - this.getSummaryReserveRows() - previousOverlayRows,
    );
    const previousFooterStartRow = Math.max(
      1,
      this.getInputStartRow(previousInputRows) - this.config.gapHeight - this.getSummaryReserveRows(),
    );
    const scrollBottom = this.getScrollBottomForLayout(inputFrameRows, overlayRows, frame.summaryLine ?? this.lastSummaryLine);
    const leadingGapStartRow = scrollBottom + 1;
    const previousLeadingGapStartRow = previousOverlayRows > 0 ? previousScrollBottom + 1 : previousOverlayStartRow;
    const clearStartRow = isPermissionOverlay && shouldSkipPermissionOverlayReserve()
      ? 1
      : Math.min(previousLeadingGapStartRow, leadingGapStartRow);
    const isPlaceholder = !this.lastInputValue;

    this.stream.write(RESET_SCROLL_REGION);
    if (isPermissionOverlay) {
      this.stream.write(HIDE_CURSOR);
    } else {
      this.stream.write(SHOW_CURSOR);
    }
    for (let row = previousFooterStartRow; row <= statusBarRow; row += 1) {
      this.clearScreenRow(row);
    }
    const shouldReserveTranscript = !(isPermissionOverlay && shouldSkipPermissionOverlayReserve())
      && !(shouldCompactSubmittedInputForWindowsTmux() && overlayKind === 'generic');
    if (shouldReserveTranscript) {
      this.reserveTranscriptRows(scrollBottom, previousScrollBottom);
    }
    this.setScrollRegion(scrollBottom);
    for (let row = clearStartRow; row <= statusBarRow; row += 1) {
      this.clearScreenRow(row);
    }

    this.stream.write(this.semanticPrompt(leadingGapStartRow, statusBarRow));

    for (let row = leadingGapStartRow; row < overlayStartRow; row += 1) {
      this.clearScreenRow(row);
      this.stream.write(this.padLine('', cols, false));
    }

    overlayLines.forEach((line, index) => {
      const row = overlayStartRow + index;
      this.clearScreenRow(row);
      this.stream.write(this.padLine(line, cols, false));
    });

    for (let row = overlayStartRow + overlayRows; row < inputStartRow; row += 1) {
      this.clearScreenRow(row);
      this.stream.write(this.padLine('', cols, false));
    }

    for (let index = 0; index < INPUT_PADDING_ROWS; index += 1) {
      const row = inputStartRow + index;
      this.clearScreenRow(row);
      this.stream.write(this.padBackgroundRow(cols));
    }

    inputLines.forEach((line, index) => {
      const row = inputTextStartRow + index;
      const prefix = index === 0
        ? `${INPUT_BG}${PROMPT_FG}${getFooterPromptGlyph()}${RESET_FG} `
        : `${INPUT_BG}  `;
      this.clearScreenRow(row);
      if (isPlaceholder) {
        this.stream.write(this.padLineWithBg(`${prefix}${DIM}${line}`, cols));
      } else {
        this.stream.write(this.padLineWithBg(`${prefix}${line}`, cols));
      }
    });

    for (let index = 0; index < INPUT_BOTTOM_PADDING_ROWS; index += 1) {
      const row = inputTextStartRow + inputLines.length + index;
      this.clearScreenRow(row);
      this.stream.write(this.padBackgroundRow(cols));
    }

    const effectiveSummaryLine = frame.summaryLine ?? this.lastSummaryLine;
    const summaryStartRow = this.getSummaryStartRow(inputStartRow, effectiveSummaryLine);
    if (summaryStartRow >= 1 && effectiveSummaryLine) {
      this.stream.write(`\x1b[${summaryStartRow};1H`);
      this.stream.write(effectiveSummaryLine);
    }

    if (keepStatusLineVisible) {
      this.stream.write(`\x1b[${statusBarRow};1H${CLEAR_LINE}`);
      this.stream.write(this.renderSingleFooterTextLine(frame.statusLine, cols));
    }

    this.lastInputRenderRows = inputFrameRows;
    this.lastOverlayRenderRows = overlayRows;
    this.lastFooterClearStartRow = clearStartRow;
    this.lastFooterClearEndRow = statusBarRow;
    this.lastOverlayClearStartRow = Math.min(
      this.lastOverlayClearStartRow || clearStartRow,
      clearStartRow,
    );
    if (isPermissionOverlay) {
      this.positionCursorForPermissionOverlay(inputFrameRows);
      return;
    }
    this.positionCursorForOverlayInput(inputState, inputRows);
  }

  private positionCursorForPermissionOverlay(inputFrameRows: number): void {
    const safeRow = Math.max(1, this.getInputStartRow(inputFrameRows) - 1);
    this._terminalCursorRow = safeRow;
    this.stream.write(`\x1b[${safeRow};1H${this.semanticInput()}`);
  }

  private positionCursorForOverlayInput(
    inputState: FooterInputState | undefined,
    inputRows: number,
  ): void {
    const inputTextStartRow = this.getInputTextStartRow(inputRows);

    if (!this.lastInputValue || !inputState) {
      this._terminalCursorRow = inputTextStartRow;
      this.stream.write(`\x1b[${inputTextStartRow};${this.getCursorBase()}H${this.semanticInput()}`);
      return;
    }

    const cursorVisibleLine = Math.max(
      0,
      Math.min(inputState.cursorVisualLine - inputState.visibleStart, inputState.visibleLines.length - 1),
    );
    const cursorRow = inputTextStartRow + cursorVisibleLine;
    const cursorCol = this.getCursorBase() + inputState.cursorColumn;

    this._terminalCursorRow = cursorRow;
    this.stream.write(`\x1b[${cursorRow};${cursorCol}H${this.semanticInput()}`);
  }

  /**
   * Position the cursor in the input bar for typing.
   * When showing a placeholder (no user input), cursor goes to column 3 (after "❯ ").
   * When showing user input, cursor goes to the actual cursor position.
   */
  private positionCursorForInput(): void {
    this.stream.write(this.getInputCursorSequence());
  }

  private getInputCursorSequence(): string {
    if (!this.lastInputValue) {
      this._terminalCursorRow = this.getInputTextStartRow(1);
      return `\x1b[${this._terminalCursorRow};${this.getCursorBase()}H${this.semanticInput()}`;
    }

    const state = this.getFooterInputState(this.lastInputValue, this.lastInputCursor);
    const cursorVisibleLine = Math.max(
      0,
      Math.min(state.cursorVisualLine - state.visibleStart, state.visibleLines.length - 1),
    );
    const cursorRow = this.getInputTextStartRow(state.visibleLines.length) + cursorVisibleLine;
    const cursorCol = this.getCursorBase() + state.cursorColumn;

    this._terminalCursorRow = cursorRow;
    return `\x1b[${cursorRow};${cursorCol}H${this.semanticInput()}`;
  }

  /**
   * Clear the last input value.
   * Call this after user submits input so the footer shows placeholder during turn.
   */
  clearLastInput(options?: { renderFooter?: boolean; inputPrompt?: string }): void {
    this.lastInputValue = '';
    this.lastInputCursor = 0;
    if (options?.inputPrompt) {
      this.lastInputPrompt = options.inputPrompt;
    }
    if (this.active && options?.renderFooter !== false) {
      this.renderFooter({
        summaryLine: this.lastSummaryLine || undefined,
        statusLine: this.lastStatusLine || undefined,
        inputPrompt: options?.inputPrompt,
      });
    }
  }

  /**
   * Clear the activity line at the bottom of the scroll region.
   * Call this after user input is written, before AI response starts.
   * Does NOT reposition the cursor — content continues from current position.
   */
  clearActivityLine(): void {
    if (!this.active) return;

    this.lastActivityLine = '';
    this.stream.write(this.composeActivityClear());
    this.stream.write(RESET_ALL);
    this.lastActivityRow = null;
  }

  clearActivityState(): void {
    this.lastActivityLine = '';
    this.lastActivityRow = null;
  }

  clearOverlayPromptState(): void {
    if (this.active) {
      this.clearPromptChromeRows();
    }
    this.lastInputValue = '';
    this.lastInputCursor = 0;
    this.clearActiveOverlayPrompt();
    this.lastOverlayRenderRows = 0;
    this.lastOverlayClearStartRow = 0;
  }

  positionCursorAtContentCursor(): void {
    if (!this.active) return;
    this.stream.write(this.semanticOutput());

    const targetRow = this.clampCursorRow(this._cursorRow);
    this.clearActivityIfContentWillUseRow(targetRow);
    this._terminalCursorRow = targetRow;
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(targetRow))}`);
    if (this._cursorCol > 0) {
      this.stream.write(`\x1b[${this._cursorCol + 1}G`);
    } else {
      this.stream.write('\r');
    }
    this.stream.write(RESET_ALL);
  }

  /**
   * Position cursor for content output, based on how many rows of content
   * were written. Calculates the actual end row (accounting for terminal
   * wrapping) and positions cursor there + gapHeight + 1 to preserve the
   * required blank safety rows before the fixed footer.
   */
  positionAfterContent(contentRows?: number): void {
    if (!this.active) return;
    this.stream.write(this.semanticOutput());

    const scrollBottom = this.getScrollBottom();
    // Content starts at row 1, ends at row `contentRows`
    // Leave gapHeight blank rows: position at contentEnd + gapHeight + 1.
    const contentEnd = Math.min(contentRows ?? scrollBottom, scrollBottom);
    const targetRow = Math.min(contentEnd + this.config.gapHeight + 1, scrollBottom);

    this._terminalCursorRow = targetRow;
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(targetRow))}`);
    this.stream.write(RESET_ALL);
  }

  /**
   * Prepare for content output.
   * Clears the activity line at the bottom of the scroll region and positions
   * the cursor there for content to begin.
   * Call this before writing any content to the scroll region.
   */
  beginContentStreaming(): void {
    if (!this.active) return;
    this.stream.write(this.semanticOutput());

    // A tool interrupt may end a partial assistant row without rendering a
    // visible tool block. Finalize it only when another assistant segment
    // actually starts: visible tool blocks already advance the cursor and must
    // not receive a second spacer row here.
    if (!this._contentStreaming && this._cursorCol > 0) {
      const nextRow = this._cursorRow + 1;
      this._totalRows++;
      this.absorbRegionScroll(nextRow);
      this._cursorRow = this.clampCursorRow(nextRow);
      this._cursorCol = 0;
      this._cursorUncertain = false;
    }
    this._contentStreaming = true;
    this.clearSummaryChromeRows();
    this.clearActivity();
    // Keep the footer rows reserved and visible while content streams so the
    // prompt/status area never visually disappears. Tool phases may temporarily
    // end streaming and show live activity above the footer.
    this._footerVisible = true;
    const scrollBottom = this.getScrollBottom();
    const targetRow = Math.max(1, Math.min(this._cursorRow, scrollBottom));
    this._streamStartRow = targetRow;
    this._terminalCursorRow = targetRow;
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(targetRow))}`);
    if (this._cursorCol > 0) {
      this.stream.write(`\x1b[${this._cursorCol + 1}G`);
    }
    this.stream.write(RESET_ALL);
  }

  /**
   * Restore footer after content streaming completes.
   */
  endContentStreaming(options?: {
    inputPrompt?: string;
    summaryLine?: string;
    statusLine?: string;
    reserveActivityRow?: boolean;
  }): void {
    if (!this.active) return;

    // The activity overlay owns the last scroll-region row. If assistant text
    // currently ends there without a newline, rendering activity would clear
    // that text. Emit the newline only at this boundary so the terminal scrolls
    // the content up before the overlay takes ownership.
    if (options?.reserveActivityRow === true && this._cursorCol > 0 && this._cursorRow >= this.getScrollBottom()) {
      this.getNewlineCallback()();
    }
    this._contentStreaming = false;
    // Busy capture still owns this draft. Only explicit submission/clear may
    // reset it; a streaming boundary must not hide text that remains editable.
    this.renderFooter(options);
    if (shouldCompactSubmittedInputForWindowsTmux()) {
      this.renderFooter(options);
    }
  }

  /**
   * Prepare for content output.
   * Clears the activity line so content can be output without overlap.
   * Call this before writing any content to the scroll region.
   */
  prepareForContent(): void {
    if (!this.active) return;
    this.stream.write(this.semanticOutput());

    // Clear the activity line (scroll region bottom)
    const scrollBottom = this.getScrollBottom();
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(scrollBottom))}${CLEAR_LINE}`);
  }

  /**
   * Render live activity in the scroll region (not footer).
   * Activity line shows at bottom of scroll region, above the gap row.
   *
   * This method only updates the activity line. Cursor stays at activity line
   * after rendering - do NOT use [s/[u as it resets attributes.
   */
  renderActivity(activityLine: string): void {
    if (!this.active) {
      // Not in scroll region mode, use inline rendering
      this.stream.write(`\r${CLEAR_LINE}${activityLine}`);
      return;
    }
    if (this.hasActiveOverlayPrompt()) {
      return;
    }

    this.lastActivityLine = activityLine;

    const footerFrame = {
      inputPrompt: this.lastInputPrompt || 'Type your message...',
      summaryLine: this.lastSummaryLine || undefined,
      statusLine: this.lastStatusLine || undefined,
    };

    // When the footer is visible, render activity and footer in one batched
    // frame. Writing an activity-only frame first creates a visible flicker
    // where screenshots can catch the input/status footer as missing.
    if (!this._footerVisible && !this._contentStreaming && !this.hasActiveOverlayPrompt()) {
      this.renderFooterFrame(footerFrame, true);
      return;
    }
    if (this._footerVisible) {
      this.renderFooterFrame(footerFrame, true, true);
      return;
    }

    // Render activity line at bottom of scroll region
    this.stream.write(this.composeActivityLineRender(activityLine));
    if (shouldCompactSubmittedInputForWindowsTmux()) {
      this.renderFooter({
        inputPrompt: this.lastInputPrompt || 'Type your message...',
        statusLine: undefined,
      });
    }
  }

  /**
   * Clear activity line from scroll region.
   * Cursor stays at activity line after clearing.
   */
  clearActivity(): void {
    if (!this.active) {
      this.stream.write(`\r${CLEAR_LINE}`);
      return;
    }

    if (!this.lastActivityLine && this.lastActivityRow === null) {
      return;
    }

    this.lastActivityLine = '';
    this.stream.write(this.composeActivityClear());
    this.lastActivityRow = null;
  }

  /**
   * Update status line only (without re-rendering everything).
   */
  updateStatusLine(statusLine: string): void {
    this.lastStatusLine = statusLine;
    if (this.active) {
      if (this.isRendererPermissionOverlayActive() && shouldSkipPermissionOverlayReserve()) {
        return;
      }
      if (this._contentStreaming || !this._footerVisible) {
        return;
      }
      if (this.isRendererPermissionOverlayActive()) {
        const statusBarRow = this.getStatusBarRow();
        this.stream.write(`${MOVE_TO_ROW.replace('%d', String(statusBarRow))}${CLEAR_LINE}`);
        this.stream.write(this.renderSingleFooterTextLine(statusLine, this.config.columns));
        this.stream.write(HIDE_CURSOR);
        this.positionCursorForPermissionOverlay(this.lastInputRenderRows);
        return;
      }
      if (this.hasActiveOverlayPrompt()) {
        const statusBarRow = this.getStatusBarRow();
        this.stream.write(`${MOVE_TO_ROW.replace('%d', String(statusBarRow))}${CLEAR_LINE}`);
        this.stream.write(this.renderSingleFooterTextLine(statusLine, this.config.columns));
        const inputState = this.lastInputValue
          ? this.getFooterInputState(this.lastInputValue, this.lastInputCursor)
          : undefined;
        const inputRows = Math.max(1, inputState?.visibleLines.length ?? 1);
        this.positionCursorForOverlayInput(inputState, inputRows);
        return;
      }
      this.renderFooterFrame({
        inputPrompt: this.lastInputPrompt || 'Type your message...',
        summaryLine: this.lastSummaryLine || undefined,
        statusLine,
      }, true, true);
    }
  }

  /**
   * Set the scroll region ANSI sequence.
   */
  private setScrollRegion(scrollEnd = this.getScrollBottom()): void {
    this.stream.write(SET_SCROLL_REGION.replace('%d', String(scrollEnd)));
    this._terminalCursorRow = 1;
  }

  /**
   * Pad a line to fill the terminal width (clears any remaining characters).
   * If hasBackground is true, the padding will have the background color.
   */

  isContentStreaming(): boolean {
    return this._contentStreaming;
  }

  getPromptFrameState(): ScrollPromptFrame {
    return {
      inputValue: this.lastInputValue,
      cursor: this.lastInputCursor,
      placeholder: this.lastInputPrompt || 'Type your message...',
      summaryLine: this.lastSummaryLine,
      statusLine: this.lastStatusLine,
      overlayLines: this.lastOverlayRenderRows > 0 ? [] : undefined,
    };
  }

  setWelcomeRows(rows: number): void {
    this._welcomeRows = rows;
    this._pastWelcome = true;
    this._totalRows = rows;
    this._cursorRow = this.clampCursorRow(rows + 1);
    this._terminalCursorRow = this._cursorRow;
    this._cursorCol = 0;
  }

  clearContentArea(): void {
    if (!this.active) return;

    const scrollBottom = this.getScrollBottom();
    this.stream.write(RESET_SCROLL_REGION);
    for (let row = 1; row <= scrollBottom; row += 1) {
      this.stream.write(`${MOVE_TO_ROW.replace('%d', String(row))}${CLEAR_LINE}`);
    }
    this.setScrollRegion();
    this._welcomeRows = 0;
    this._totalRows = 0;
    this._contentEndRow = 0;
    this._cursorRow = 1;
    this._cursorCol = 0;
    this._cursorUncertain = false;
    this._pastWelcome = true;
    this._hasStreamedContent = false;
  }

  clearVisibleViewport(): void {
    if (!this.active) return;

    const scrollBottom = this.getScrollBottom();
    this.stream.write(RESET_SCROLL_REGION);
    for (let row = 1; row <= scrollBottom; row += 1) {
      this.stream.write(`${MOVE_TO_ROW.replace('%d', String(row))}${CLEAR_LINE}`);
    }
    this.setScrollRegion();
  }

  advanceContentCursor(rows: number): void {
    if (!this.active) return;
    this._totalRows += rows;
    this._cursorRow = this.clampCursorRow(this._cursorRow + rows);
    this._cursorUncertain = false;
  }

  advanceContentCursorByRenderedText(
    text: string,
    options?: { finalizeLine?: boolean },
  ): void {
    if (!this.active || text.length === 0) return;

    const cols = this.config.columns;
    const plain = stripAnsi(text);
    let row = this._cursorRow;
    let col = this._cursorCol;

    for (const ch of plain) {
      if (ch === '\n') {
        row = this.clampCursorRow(row + 1);
        col = 0;
        continue;
      }

      const width = Math.max(1, getDisplayWidth(ch));
      if (col + width >= cols) {
        row = this.clampCursorRow(row + 1);
        col = 0;
      }
      col += width;
    }

    const finalizeLine = options?.finalizeLine === true;
    const contentEndRow = row;

    if (finalizeLine && col > 0) {
      this._cursorRow = this.clampCursorRow(row + 1);
      this._cursorCol = 0;
    } else {
      this._cursorRow = row;
      this._cursorCol = col;
    }

    this._contentEndRow = Math.max(this._contentEndRow, contentEndRow);
    this._totalRows = Math.max(this._totalRows, contentEndRow);
    this._cursorUncertain = false;
  }

  setContentCursor(row: number): void {
    if (!this.active) return;
    this._totalRows = row;
    this._cursorRow = this.clampCursorRow(row);
  }

  getContentCursor(): number {
    return this._totalRows;
  }

  get maxContentRows(): number {
    return this.getScrollBottom();
  }

  writeAtContentCursor(text: string, options?: { clearPromptChrome?: boolean }): void {
    if (!this.active) {
      this.stream.write(text);
      return;
    }
    this.stream.write(this.semanticOutput());
    const shouldRestoreFooter = options?.clearPromptChrome !== false
      && this._footerVisible
      && !this._contentStreaming
      && !this.hasActiveOverlayPrompt();
    if (shouldRestoreFooter) {
      this.clearSummaryChromeRows();
    }
    this.stream.write(RESET_ALL);
    const targetRow = this.clampCursorRow(this._cursorRow);
    this.clearActivityIfContentWillUseRow(targetRow);
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(targetRow))}\r`);

    const cols = this.config.columns;
    const visibleText = stripAnsi(text);
    let col = this._cursorCol;
    let newlines = 0;
    let extraRows = 0;

    for (const ch of visibleText) {
      if (ch === '\n') {
        newlines++;
        col = 0;
      } else if (ch === '\r') {
        col = 0;
      } else if (ch === '\t') {
        const next = col + 4 - (col % 4);
        extraRows += Math.floor(next / cols);
        col = next % cols;
      } else {
        const w = getDisplayWidth(ch);
        if (col + w >= cols) {
          extraRows++;
          col = 0;
          if (w === cols) {
            extraRows++;
            col = 0;
          } else {
            col = w;
          }
        } else {
          col += w;
        }
      }
    }

    const totalRows = newlines + extraRows;
    this._cursorCol = col;
    this._totalRows += totalRows;
    this._cursorRow = this.clampCursorRow(targetRow + totalRows);
    this._contentEndRow = Math.max(this._contentEndRow, this._cursorRow);
    this._pastWelcome = true;
    this._cursorUncertain = false;
    this.stream.write(text);
    this._terminalCursorRow = this._cursorRow;

    if (shouldRestoreFooter) {
      this.renderFooter({
        inputPrompt: this.lastInputPrompt || 'Type your message...',
        summaryLine: this.lastSummaryLine || undefined,
        statusLine: this.lastStatusLine || undefined,
      });
    }
  }

  /**
   * Writes terminal graphics payloads (kitty APC / iTerm2 OSC) verbatim.
   * stripAnsi() only strips CSI, so routing these bytes through
   * writeAtContentCursor would count the base64 payload as visible columns and
   * inflate the row bookkeeping by thousands of phantom rows.
   */
  writeRawBlock(
    text: string,
    rows: number,
    options?: {
      clearPromptChrome?: boolean;
      /** Kitty C=1 leaves the cursor stationary. Reserve its footprint before placement. */
      cursorStationary?: boolean;
      logger?: {
        beginSuppress(): void;
        endSuppress(): void;
        recordOutput(stream: 'stdout' | 'stderr', chunk: string): void;
      };
      placeholder?: string;
    },
  ): void {
    const logger = options?.logger;
    const stationary = options?.cursorStationary === true;
    const availableRows = this.active ? this.getScrollBottom() : (this.stream.rows ?? 24);
    if (stationary && (!Number.isInteger(rows) || rows < 1 || rows >= availableRows)) {
      throw new Error('image rows must fit inside the content region with a trailing cursor row');
    }
    if (!this.active) {
      this.writeRawBytes(stationary ? `${'\n'.repeat(rows)}\x1b[${rows}A\r${text}\x1b[${rows}B\r` : text, logger);
      if (options?.placeholder) logger?.recordOutput('stdout', `${options.placeholder}\n`);
      return;
    }
    this.stream.write(this.semanticOutput());

    const shouldRestoreFooter = options?.clearPromptChrome !== false
      && this._footerVisible
      && !this._contentStreaming
      && !this.hasActiveOverlayPrompt();
    if (shouldRestoreFooter) {
      this.clearSummaryChromeRows();
    }
    this.stream.write(RESET_ALL);
    const targetRow = this.clampCursorRow(this._cursorRow);
    this.clearActivityIfContentWillUseRow(stationary ? this.clampCursorRow(targetRow + rows) : targetRow);
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(targetRow))}\r`);

    if (stationary) {
      // A placement straddling the bottom margin does not scroll with content.
      // Allocate the complete footprint first, then place entirely inside the
      // margin. CUP after the opaque payload keeps both physical and tracked
      // cursors on the following content row, independent of chunk count.
      const endRow = this.clampCursorRow(targetRow + rows);
      const imageRow = endRow - rows;
      this.writeRawBytes(`${'\n'.repeat(rows)}\x1b[${imageRow};1H${text}\x1b[${endRow};1H\r`, logger);
    } else {
      this.writeRawBytes(text, logger);
    }
    if (options?.placeholder) {
      logger?.recordOutput('stdout', `${options.placeholder}\n`);
    }

    this._cursorCol = 0;
    this._totalRows += rows;
    this.absorbRegionScroll(targetRow + rows);
    this._cursorRow = this.clampCursorRow(targetRow + rows);
    this._terminalCursorRow = this._cursorRow;
    this._contentEndRow = Math.max(this._contentEndRow, this._cursorRow);
    this._pastWelcome = true;
    this._cursorUncertain = false;

    if (shouldRestoreFooter) {
      this.renderFooter({
        inputPrompt: this.lastInputPrompt || 'Type your message...',
        summaryLine: this.lastSummaryLine || undefined,
        statusLine: this.lastStatusLine || undefined,
      });
    }
  }

  private writeRawBytes(
    text: string,
    logger?: { beginSuppress(): void; endSuppress(): void },
  ): void {
    logger?.beginSuppress();
    try {
      this.stream.write(text);
    } finally {
      logger?.endSuppress();
    }
  }

  writeSubmittedInput(text: string): void {
    if (!this.active) {
      this.stream.write(text);
      return;
    }
    this.stream.write(this.semanticOutput());
    const targetRow = this.clampCursorRow(this._cursorRow);
    this._terminalCursorRow = targetRow;
    this.stream.write(`${MOVE_TO_ROW.replace('%d', String(targetRow))}`);
    if (this._cursorCol > 0) {
      this.stream.write(`\x1b[${this._cursorCol + 1}G`);
    }
    this.stream.write(RESET_ALL);

    const hasPriorTranscript = this._totalRows > this._welcomeRows;
    const separatorRows = hasPriorTranscript
      ? (this._cursorCol > 0 ? 2 : 1)
      : (this._cursorCol > 0 ? 1 : 0);

    for (let index = 0; index < separatorRows; index += 1) {
      this.stream.write('\n');
      this._totalRows++;
      this._cursorRow = this.clampCursorRow(this._cursorRow + 1);
      this._cursorCol = 0;
    }
    // formatSubmittedInput() ends with a spacer row plus a trailing newline.
    // On Windows tmux, counting that final newline as transcript height pushes
    // one extra visible row out of the pane; let the next assistant chunk start
    // on the spacer row instead. Keep the default behavior elsewhere so the
    // existing non-tmux layout semantics stay unchanged.
    const transcriptText = shouldCompactSubmittedInputForWindowsTmux() && text.endsWith('\n')
      ? text.slice(0, -1)
      : text;
    this.writeAtContentCursor(transcriptText, { clearPromptChrome: false });
    this._contentEndRow = this._cursorRow;
    this._cursorCol = 0;
    this._pastWelcome = true;

    // Some real terminals can scroll the fixed footer up by one or more rows
    // when a submitted transcript block lands directly against the footer
    // boundary. Re-anchor the footer immediately so later activity/status
    // updates never inherit a half-cleared prompt/status chrome.
    if (this._footerVisible && !this.hasActiveOverlayPrompt()) {
      this.renderFooter({
        inputPrompt: this.lastInputPrompt || 'Type your message...',
        summaryLine: this.lastSummaryLine || undefined,
        statusLine: this.lastStatusLine || undefined,
      });
    }
  }

  getNewlineCallback(): (() => void) {
    const self = this;
    return function newlineCallback() {
      if (self._cursorCol === 0) {
        self.clearActivityIfContentWillUseRow(self.clampCursorRow(self._cursorRow));
      }
      self.stream.write('\n');
      self._totalRows++;
      self.absorbRegionScroll(self._cursorRow + 1);
      self._cursorRow = self.clampCursorRow(self._cursorRow + 1);
      self._cursorCol = 0;
      self._cursorUncertain = false;
      self._terminalCursorRow = self._cursorRow;
    };
  }

  /**
   * Report visible columns written inside a rendered row that did not end in a
   * newline. Uses the terminal's deferred-wrap rule: filling the last column
   * leaves the cursor on the same row until one more character arrives.
   */
  getColumnAdvanceCallback(): ((visibleWidth: number) => void) {
    const self = this;
    return function columnAdvanceCallback(visibleWidth: number) {
      if (!self.active || visibleWidth <= 0) return;

      const cols = Math.max(1, self.config.columns);
      const end = self._cursorCol + visibleWidth;
      const rowsAdvanced = Math.floor((end - 1) / cols);

      if (rowsAdvanced > 0) {
        self._totalRows += rowsAdvanced;
        self.absorbRegionScroll(self._cursorRow + rowsAdvanced);
        self._cursorRow = self.clampCursorRow(self._cursorRow + rowsAdvanced);
      }
      self._cursorCol = ((end - 1) % cols) + 1;
      self._contentEndRow = Math.max(self._contentEndRow, self._cursorRow);
      self._cursorUncertain = false;
      self._terminalCursorRow = self._cursorRow;
    };
  }

  /**
   * When content pushes past the bottom margin the region scrolls up, so every
   * absolute row anchor recorded earlier shifts with it. `clampCursorRow` hides
   * the overflow, hence the compensation has to be computed before clamping.
   */
  private absorbRegionScroll(intendedRow: number): void {
    const overflow = intendedRow - this.getScrollBottom();
    if (overflow > 0) {
      this._streamStartRow = Math.max(1, this._streamStartRow - overflow);
    }
  }

  syncContentCursorFromRenderedLines(lines: string[]): void {
    if (!this.active || lines.length === 0) return;

    const cols = this.config.columns;
    let row = this._streamStartRow;
    let col = 0;

    for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
      const text = stripAnsi(lines[lineIndex] ?? '');
      col = 0;

      for (const ch of text) {
        if (ch === '\n') {
          row = this.clampCursorRow(row + 1);
          col = 0;
          continue;
        }

        const w = getDisplayWidth(ch);
        // Deferred wrap: the cursor only leaves a full row once the next
        // character arrives, and a full-width glyph never straddles the margin.
        if (col >= cols || col + w > cols) {
          row = this.clampCursorRow(row + 1);
          col = 0;
        }
        col += w;
      }

      if (lineIndex < lines.length - 1) {
        row = this.clampCursorRow(row + 1);
        col = 0;
      }
    }

    this._cursorRow = row;
    this._cursorCol = col;
    this._totalRows = Math.max(this._totalRows, row);
    this._cursorUncertain = false;
  }
  private padLine(line: string, width: number, hasBackground = false): string {
    const safeWidth = getSafeRenderWidth(width);
    const visibleLen = getDisplayWidth(line);
    if (visibleLen >= safeWidth) return truncateAnsi(line, safeWidth);
    const padding = ' '.repeat(safeWidth - visibleLen);
    if (hasBackground) {
      // Background already set, just add spaces, then reset
      return line + padding + RESET_ALL;
    }
    return line + padding;
  }

  /**
   * Pad a line with background color to fill the terminal width.
   * The line should already have background set. Adds spaces and resets.
   */
  private padLineWithBg(line: string, width: number): string {
    // Erase with the current background instead of writing padding spaces:
    // spaces become content during terminal resize/reflow and duplicate chrome.
    return truncateAnsi(line, getSafeRenderWidth(width)) + '\x1b[K' + RESET_ALL;
  }

  private padBackgroundRow(width: number): string {
    return this.padLineWithBg(INPUT_BG, width);
  }

  private renderSingleFooterTextLine(line: string, width: number): string {
    return truncateAnsi(line, getSafeRenderWidth(width)) + '\x1b[K';
  }

}
