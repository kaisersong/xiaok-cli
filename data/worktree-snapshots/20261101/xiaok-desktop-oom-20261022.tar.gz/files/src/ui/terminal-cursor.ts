import { closeSync, constants, openSync, readSync } from 'node:fs';
import { isatty } from 'node:tty';

export interface CursorPosition { row: number; column: number; rows?: number; columns?: number }
export interface CursorQueryIo {
  write(sequence: string): void;
  read(): Buffer;
  now(): number;
  pause(): void;
  replay(bytes: Buffer): void;
}

/** Read one solicited CPR without treating user bytes as terminal protocol. */
export function queryTerminalCursor(io: CursorQueryIo, timeoutMs = 150): CursorPosition | null {
  let received = '';
  try {
    io.write('\x1b[6n');
    const deadline = io.now() + timeoutMs;
    while (io.now() < deadline && received.length < 65536) {
      received += io.read().toString('latin1');
      const report = /\x1b\[(\d+);(\d+)R/.exec(received);
      if (report && Number(report[1]) > 0 && Number(report[2]) > 0) {
        received = received.slice(0, report.index) + received.slice(report.index + report[0].length);
        return { row: Number(report[1]), column: Number(report[2]) };
      }
      io.pause();
    }
  } catch {
    // Unsupported or disconnected terminals keep the existing geometry fallback.
  } finally {
    if (received) io.replay(Buffer.from(received, 'latin1'));
  }
  return null;
}

const pauseWord = new Int32Array(new SharedArrayBuffer(4));

/** Serialize a short query with the resize frame; never change raw-mode ownership. */
export function readTerminalCursor(stream: NodeJS.WriteStream, restore: string): CursorPosition | null {
  const streamFd = (stream as NodeJS.WriteStream & { fd?: number }).fd;
  if (process.platform === 'win32' || !process.stdin.isRaw
    || !isatty(process.stdin.fd) || typeof streamFd !== 'number' || !isatty(streamFd)) return null;
  let fd: number;
  try { fd = openSync('/dev/tty', constants.O_RDWR | constants.O_NONBLOCK); }
  catch { return null; }
  try {
    const bytes = Buffer.alloc(512);
    // Node's public getWindowSize() returns cached dimensions until SIGWINCH is
    // dispatched. Read libuv's TTY ioctl while this short JS turn is serialized.
    const handle = (stream as NodeJS.WriteStream & {
      _handle?: { getWindowSize(size: number[]): number | undefined };
    })._handle;
    const readSize = (): number[] | null => {
      const size = [0, 0];
      return handle && !handle.getWindowSize(size) && size.every(value => value > 0) ? size : null;
    };
    const deadline = performance.now() + 600;
    for (let attempt = 0; attempt < 2; attempt++) {
      let size = readSize();
      let stableSince = performance.now();
      while (size && performance.now() - stableSince < 40 && performance.now() < deadline - 150) {
        Atomics.wait(pauseWord, 0, 0, 5);
        const next = readSize();
        if (!next || next[0] !== size[0] || next[1] !== size[1]) stableSince = performance.now();
        size = next;
      }
      const position = queryTerminalCursor({
        write: request => { stream.write(restore + request); },
        read: () => {
          try { return Buffer.from(bytes.subarray(0, readSync(fd, bytes, 0, bytes.length, null))); }
          catch (error) {
            if ((error as NodeJS.ErrnoException).code === 'EAGAIN') return Buffer.alloc(0);
            throw error;
          }
        },
        now: () => performance.now(),
        pause: () => { Atomics.wait(pauseWord, 0, 0, 2); },
        // unshift leaves UTF-8 decoding and key/interrupt ownership with stdin.
        replay: input => queueMicrotask(() => {
          if (!process.stdin.destroyed && process.stdin.readable) process.stdin.unshift(input);
        }),
      }, Math.min(150, Math.max(1, deadline - performance.now())));
      const after = readSize();
      if (!position) return null;
      if (!size || !after) return position;
      if (size[0] === after[0] && size[1] === after[1]) {
        return { ...position, columns: after[0], rows: after[1] };
      }
    }
    return null;
  } finally {
    closeSync(fd);
  }
}
