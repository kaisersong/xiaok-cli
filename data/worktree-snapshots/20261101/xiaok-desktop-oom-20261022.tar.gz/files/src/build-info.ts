export const BUILD_TIME: string | null = "2026-10-22 13:15";
