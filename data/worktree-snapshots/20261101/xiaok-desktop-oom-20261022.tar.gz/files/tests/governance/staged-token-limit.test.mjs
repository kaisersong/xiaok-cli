import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { afterEach, test } from 'node:test';
import { chmodSync, copyFileSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const checker = fileURLToPath(new URL('../../scripts/check-staged-token-limit.mjs', import.meta.url));
const hook = fileURLToPath(new URL('../../.githooks/pre-commit', import.meta.url));
const roots = [];
afterEach(() => {
  for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true, maxRetries: 5 });
});
function run(root, command, args) {
  return spawnSync(command, args, { cwd: root, encoding: 'utf8' });
}
function git(root, ...args) {
  const result = run(root, 'git', args);
  assert.equal(result.status, 0, result.stderr);
  return result;
}
function repo() {
  const root = mkdtempSync(join(tmpdir(), 'xiaok-token-hook-'));
  roots.push(root);
  git(root, 'init', '--quiet');
  git(root, 'config', 'user.name', 'Fixture');
  git(root, 'config', 'user.email', 'fixture@example.invalid');
  git(root, 'config', 'core.autocrlf', 'false');
  git(root, 'config', 'core.hooksPath', '.githooks');
  return root;
}
function put(root, path, content, stage = true) {
  mkdirSync(dirname(join(root, path)), { recursive: true });
  writeFileSync(join(root, path), content);
  if (stage) git(root, 'add', '--', path);
}
function check(root) { return run(root, process.execPath, [checker]); }

test('empty index and exact byte boundary pass; excess bytes give actionable split guidance', () => {
  const root = repo();
  assert.equal(check(root).status, 0);
  put(root, 'boundary.ts', 'x'.repeat(20_000));
  assert.equal(check(root).status, 0);
  put(root, 'boundary.ts', 'x'.repeat(20_001));
  const result = check(root);
  assert.equal(result.status, 1);
  assert.match(result.stderr, /boundary\.ts/);
  assert.match(result.stderr, /20001/);
  assert.match(result.stderr, /5000\.25/);
  assert.match(result.stderr, /至少.*2.*文件/);
  assert.match(result.stderr, /职责.*模块/);
  assert.match(result.stderr, /git add/);
});
test('reads only staged bytes in both partial-staging directions', () => {
  const root = repo();
  put(root, 'large.ts', 'x'.repeat(20_001));
  put(root, 'large.ts', 'small', false);
  assert.equal(check(root).status, 1);
  put(root, 'large.ts', 'small');
  put(root, 'large.ts', 'x'.repeat(20_001), false);
  put(root, 'untracked.ts', 'x'.repeat(20_001), false);
  assert.equal(check(root).status, 0);
});
test('UTF-8 counts bytes and reports every offending special filename safely', () => {
  const root = repo();
  const names = ['中文 文件.ts', '-option.ts'];
  if (process.platform !== 'win32') names.push('line\nbreak.ts', 'literal$(touch injected).ts');
  for (const name of names) put(root, name, '中'.repeat(6667));
  const result = check(root);
  assert.equal(result.status, 1);
  for (const name of names) assert.ok(result.stderr.includes(JSON.stringify(name)), result.stderr);
  assert.match(result.stderr, /20001/);
});
test('ignores lockfiles, generated outputs, binary files; ordinary JSON and declarations remain checked', () => {
  const root = repo();
  const large = 'x'.repeat(20_001);
  for (const name of ['package-lock.json', 'desktop/pnpm-lock.yaml', 'yarn.lock', 'Cargo.lock',
    'dist/entry.js', 'desktop/dist/main.js', '.generated/schema.ts', 'node_modules/pkg/code.js',
    'vendor/library.js', 'bundle.min.js', 'bundle.js.map', 'schema.generated.ts']) put(root, name, large);
  put(root, 'asset.bin', Buffer.alloc(20_001));
  assert.equal(check(root).status, 0);
  put(root, 'schema.json', large);
  put(root, 'types.d.ts', large);
  const result = check(root);
  assert.equal(result.status, 1);
  assert.match(result.stderr, /schema\.json/);
  assert.match(result.stderr, /types\.d\.ts/);
});
test('only staged generated attributes exempt files, including nested paths with spaces', () => {
  const root = repo();
  put(root, 'custom/output.ts', 'x'.repeat(20_001));
  put(root, '.gitattributes', 'custom/** linguist-generated=true\n', false);
  assert.equal(check(root).status, 1);
  git(root, 'add', '.gitattributes');
  assert.equal(check(root).status, 0);
  put(root, '.gitattributes', 'custom/** -linguist-generated\n', false);
  assert.equal(check(root).status, 0);
  put(root, 'other/generated file.ts', 'x'.repeat(20_001));
  put(root, '.gitattributes', 'custom/** linguist-generated=true\nother/** generated\n');
  assert.equal(check(root).status, 0);
});
test('rename checks destination; deletion passes; binary-to-text conversion is checked', () => {
  const root = repo();
  put(root, 'old.ts', 'x'.repeat(20_001));
  put(root, 'binary.ts', Buffer.alloc(20_001));
  git(root, 'commit', '--quiet', '-m', 'fixture');
  git(root, 'mv', 'old.ts', 'new name.ts');
  assert.equal(check(root).status, 1);
  git(root, 'rm', '-f', '--', 'new name.ts');
  assert.equal(check(root).status, 0);
  put(root, 'binary.ts', 'x'.repeat(20_001));
  assert.equal(check(root).status, 1);
});
test('actual pre-commit blocks oversized commit, permits fixed commit and preserves docs check', () => {
  const root = repo();
  put(root, '.githooks/pre-commit', '', false);
  copyFileSync(hook, join(root, '.githooks/pre-commit'));
  chmodSync(join(root, '.githooks/pre-commit'), 0o755);
  mkdirSync(join(root, 'scripts'));
  copyFileSync(checker, join(root, 'scripts/check-staged-token-limit.mjs'));
  put(root, 'scripts/check-external-docs.mjs', "process.stderr.write('docs-check-ran\\n');\n", false);
  put(root, 'source.ts', 'x'.repeat(20_001));
  let result = run(root, 'git', ['commit', '--quiet', '-m', 'blocked']);
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /source\.ts/);
  put(root, 'source.ts', 'small');
  result = git(root, 'commit', '--quiet', '-m', 'allowed');
  assert.match(result.stderr, /docs-check-ran/);
});
test('git errors fail closed outside a repository', () => {
  const root = mkdtempSync(join(tmpdir(), 'xiaok-token-not-repo-'));
  roots.push(root);
  assert.equal(check(root).status, 1);
});

test('unstaged binary attributes cannot exempt staged authored text', () => {
  const root = repo();
  put(root, 'source.ts', 'x'.repeat(20_001));
  put(root, '.gitattributes', 'source.ts -diff\n', false);
  const result = check(root);
  assert.equal(result.status, 1);
  assert.match(result.stderr, /source\.ts/);
});
