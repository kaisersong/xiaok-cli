#!/usr/bin/env python3
"""macOS native acceptance in an owned Ghostty window (Python >= 3.10).

Usage: python3 tests/e2e/ghostty-footer-return.py [absolute-cli-entry]
Requires an unlocked desktop, Automation/Screen Recording permissions and the
standard xterm gray 238 footer. Screenshots stay private in a temp directory.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import time


def osa(code, *args):
    result = subprocess.run(['osascript', '-e', code, *map(str, args)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    return result.stdout.strip()


def run(entry, ssh_host=None, decision=None):
    assert sys.platform == 'darwin', 'Ghostty acceptance requires macOS'
    registry = plistlib.loads(subprocess.check_output(['ioreg', '-n', 'Root', '-d1', '-a']))
    if isinstance(registry, list): registry = registry[0]
    assert not any(user.get('CGSSessionScreenIsLocked') for user in registry.get('IOConsoleUsers', [])), 'Unlock the Mac before native acceptance'
    repo = Path(__file__).resolve().parents[2]
    node = shutil.which('node'); assert node, 'node is required'
    spec = importlib.util.spec_from_file_location('helpers', repo / 'tests/e2e/tmux-e2e.py')
    h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
    root = Path(tempfile.mkdtemp(prefix='xiaok-native-footer-'))
    work, home, config = root / 'project', root / 'home', root / 'config'
    work.mkdir(); home.mkdir()
    checker = root / 'footer-bands'
    subprocess.run(['swiftc', str(repo / 'tests/support/footer-bands.swift'), '-o', str(checker)], check=True)
    answer = '\n'.join(f'NATIVE_LINE_{i:03d}' for i in range(75)) + '\nNATIVE_ANSWER_READY'
    server = h.FakeOpenAIServer([answer, 'NATIVE_SECOND_READY'], first_token_delay=.1)
    measurements, win, term = [], None, None
    remote_root = None

    def remote(command):
        return subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', ssh_host, command], text=True).strip()
    original = osa('tell application "System Events" to get bundle identifier of first application process whose frontmost is true')

    def text(value):
        osa('on run a\ntell application "Ghostty" to input text (item 1 of a) to terminal id (item 2 of a)\nend run', value, term)

    def key(value, modifiers=None):
        if modifiers:
            osa('on run a\ntell application "Ghostty" to send key (item 1 of a) modifiers (item 2 of a) to terminal id (item 3 of a)\nend run', value, modifiers, term)
            return
        osa('on run a\ntell application "Ghostty" to send key (item 1 of a) to terminal id (item 2 of a)\nend run', value, term)

    def input_events():
        if ssh_host:
            raw = remote('cat ' + shlex.quote(remote_root + '/config/transcripts') + '/sess_*.jsonl')
        else:
            raw = '\n'.join(f.read_text() for f in (config / 'transcripts').glob('sess_*.jsonl'))
        return [json.loads(line) for line in raw.splitlines() if json.loads(line).get('type') == 'input_key']

    def terminal_dump(kind, name):
        before = len(input_events())
        osa('on run a\ntell application "Ghostty" to perform action (item 1 of a) on terminal id (item 2 of a)\nend run', 'write_' + kind + '_file:paste', term)
        path = ''; deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            path = ''.join(event['key'] for event in input_events()[before:])
            if path.endswith('.txt') and Path(path).is_file(): break
            time.sleep(.05)
        assert path.endswith('.txt') and Path(path).is_file(), 'terminal dump path not received'
        contents = Path(path).read_text()
        (root / (name + '-' + kind + '.txt')).write_text(contents)
        # Remove only the appended dump path, retaining the original draft.
        osa('on run a\ntell application "Ghostty"\nrepeat (item 1 of a as integer) times\nsend key "backspace" to terminal id (item 2 of a)\nend repeat\nend tell\nend run', len(path), term)
        return contents

    def capture(name):
        osa('on run a\ntell application "Ghostty"\nactivate\nfocus terminal id (item 1 of a)\nend tell\nend run', term)
        time.sleep(.2)
        rect = osa('tell application "System Events" to tell process "Ghostty"\nset p to position of front window\nset s to size of front window\nreturn (item 1 of p as text) & "," & (item 2 of p) & "," & (item 1 of s) & "," & (item 2 of s)\nend tell')
        screenshot = root / (name + '.png')
        subprocess.run(['screencapture', '-x', '-R', rect, str(screenshot)], check=True)
        measurement = json.loads(subprocess.check_output([str(checker), str(screenshot)], text=True, timeout=30))
        measurements.append(measurement)
        (root / 'bands.json').write_text(json.dumps(measurements, indent=2))
        if name != 'submitted':
            assert len(measurement['bands']) == 1, f'stale native footer bands: {measurement}'
        visible = measurement['text'].replace('_', '').replace(' ', '')
        if name.startswith('permission'):
            assert 'write' in visible.lower(), f'permission owner lost: {measurement}'
        elif name == 'busy-resized':
            assert 'NATIVEBUSYDRAFT' in visible, f'busy draft lost: {measurement}'
        elif name in ('submitted', 'busy-finished'):
            assert 'NATIVESECONDREADY' in visible, f'next response lost: {measurement}'
        else:
            screen = terminal_dump('screen', name)
            history = terminal_dump('scrollback', name)
            combined = history + screen
            assert all(f'NATIVE_LINE_{index:03d}' in combined for index in range(75)), 'native response history erased'
            assert 'NATIVE_ANSWER_READY' in combined, 'native response tail erased'
            assert screen.count('KEEP_NATIVE_DRAFT') == 1, 'native draft lost or duplicated'



    try:
        server.start(); h.write_config(config, server.base_url, 'gpt-4o')
        settings = json.loads((config / 'config.json').read_text())
        settings.update({'memory': {'enabled': False}, 'automations': {'enabled': False}, 'intentBoundary': {'enabled': False}})
        (config / 'config.json').write_text(json.dumps(settings))
        launch = root / 'launch.sh'
        launch_flags = [] if decision else ['--yolo']
        command = ['env', 'XIAOK_CONFIG_DIR=' + str(config), 'HOME=' + str(home), 'XIAOK_DISABLE_GLOBAL_PLUGINS=1', 'NO_COLOR=', node, str(entry), *launch_flags]
        if ssh_host:
            remote_root = remote('mktemp -d /tmp/xiaok-native-footer-XXXXXXXX')
            (root / 'remote.json').write_text(json.dumps({'host': ssh_host, 'root': remote_root, 'entry': str(entry)}))
            remote('mkdir -p ' + shlex.join([remote_root + '/project', remote_root + '/home', remote_root + '/config']))
            remote_port = 45000 + os.getpid() % 10000
            settings['models']['custom']['baseUrl'] = f'http://127.0.0.1:{remote_port}/v1'
            (config / 'config.json').write_text(json.dumps(settings))
            subprocess.run(['scp', '-q', str(config / 'config.json'), ssh_host + ':' + remote_root + '/config/config.json'], check=True)
            remote_command = 'cd ' + shlex.quote(remote_root + '/project') + '; echo $$ > ' + shlex.quote(remote_root + '/pid') + '; exec ' + shlex.join([
                'env', 'XIAOK_CONFIG_DIR=' + remote_root + '/config', 'HOME=' + remote_root + '/home',
                'XIAOK_DISABLE_GLOBAL_PLUGINS=1', 'NO_COLOR=', 'node', str(entry), *launch_flags])
            command = ['ssh', '-tt', '-o', 'BatchMode=yes', '-o', 'ExitOnForwardFailure=yes', '-R',
                f'127.0.0.1:{remote_port}:127.0.0.1:{server._server.server_port}', ssh_host, remote_command]
        target = remote_root + '/project/synthetic.txt' if ssh_host else str(work / 'synthetic.txt')
        if decision:
            server.responses[1:] = [h.tool_call_response_events('write', {'file_path': target, 'content': 'SYNTHETIC_WRITE'}, 'native_permission'), [{'_sleep': 12}] + h.text_response_events('NATIVE_SECOND_READY')]
        launch.write_text('#!/bin/sh\necho $$ > ' + shlex.quote(str(root / 'pid')) + '\ncd ' + shlex.quote(str(work)) + '\nexec ' + shlex.join(command) + ' 2> ' + shlex.quote(str(root / 'stderr.log')) + '\n')
        ids = osa('on run argv\ntell application "Ghostty"\nactivate\nset c to new surface configuration\nset command of c to item 1 of argv\nset wait after command of c to true\nset w to new window with configuration c\ndelay 1\nset t to focused terminal of selected tab of w\nfocus t\nreturn (id of w) & "," & (id of t)\nend tell\nend run', shlex.join(['/bin/sh', str(launch)]))
        win, term = ids.split(',')
        (root / 'ids.json').write_text(json.dumps({'window': win, 'terminal': term}))
        print('EVIDENCE', root, flush=True)
        time.sleep(2)
        text('Native terminal return probe'); key('enter'); time.sleep(2)
        text('KEEP_NATIVE_DRAFT'); capture('before')
        osa('tell application "Finder" to activate'); time.sleep(.8); capture('focus-return')
        for index, (width, height) in enumerate([(1100, 850), (650, 430), (1100, 850), (650, 550), (1100, 650)]):
            osa('on run a\ntell application "Ghostty" to focus terminal id (item 1 of a)\ntell application "System Events" to tell process "Ghostty" to set size of front window to {item 2 of a as integer,item 3 of a as integer}\nend run', term, width, height)
            time.sleep(.5); capture(f'resize-{index}')
        text('X'); key('backspace'); capture('editable')
        key('enter'); time.sleep(1)
        if decision:
            capture('permission')
            osa('on run a\ntell application "Ghostty"\nactivate\nfocus terminal id (item 1 of a)\nend tell\ntell application "System Events" to tell process "Ghostty" to set size of front window to {650,550}\nend run', term)
            time.sleep(.5); capture('permission-resized')
            exists = remote('test -f ' + shlex.quote(target) + ' && echo yes || echo no') if ssh_host else ('yes' if Path(target).exists() else 'no')
            assert exists == 'no', 'tool executed before permission'
            key('enter' if decision == 'allow' else 'escape'); time.sleep(.7)
            text('NATIVE_BUSY_DRAFT')
            osa('on run a\ntell application "Ghostty"\nactivate\nfocus terminal id (item 1 of a)\nend tell\ntell application "System Events" to tell process "Ghostty" to set size of front window to {1100,650}\nend run', term)
            time.sleep(.5); capture('busy-resized')
            time.sleep(12); capture('busy-finished')
            exists = remote('test -f ' + shlex.quote(target) + ' && echo yes || echo no') if ssh_host else ('yes' if Path(target).exists() else 'no')
            assert (exists == 'yes') == (decision == 'allow'), 'permission decision changed'
        capture('submitted')
        assert len(server.requests) == (3 if decision else 2), f'unexpected provider request count: {len(server.requests)}'
        content = [m['content'] for m in server.requests[-1]['messages'] if m['role'] == 'user'][-1]
        if ssh_host:
            session_text = remote('cat ' + shlex.quote(remote_root + '/config/sessions') + '/*.json')
            session = json.loads(session_text)
        else:
            session = json.loads(next((config / 'sessions').glob('*.json')).read_text())
        saved = [m['content'] for m in session['messages'] if m['role'] == 'user'
            and any(block.get('type') == 'text' for block in m['content'])][-1]
        assert saved[-1]['text'] == 'KEEP_NATIVE_DRAFT', repr(saved[-1])
        expected = ''.join(block['text'] for block in saved) if isinstance(content, str) else saved
        assert content == expected, 'provider draft changed'
        (root / 'result.json').write_text(json.dumps({'passed': True, 'entry': str(entry), 'nativeScreens': len(measurements), 'exactNextInput': True, 'sshHost': ssh_host, 'decision': decision, 'responseTailRetained': True}, indent=2))
        print('PASS: Ghostty focus return and five resizes; one gray footer; next input exact', flush=True)
    finally:
        if win:
            try: osa('on run a\ntell application "Ghostty"\nset ownedWindow to first window whose id is (item 1 of a)\nclose window ownedWindow\nend tell\nend run', win)
            except Exception: pass
        if remote_root:
            remote('if test -f ' + shlex.quote(remote_root + '/pid') + '; then kill -TERM $(cat ' + shlex.quote(remote_root + '/pid') + ') 2>/dev/null || true; fi')
        server.close()
        remote_remaining = []
        if remote_root:
            own_pid = remote('cat ' + shlex.quote(remote_root + '/pid') + ' 2>/dev/null || true')
            if own_pid.isdigit():
                deadline = time.monotonic() + 5
                while remote('kill -0 ' + own_pid + ' 2>/dev/null && echo alive || echo gone') == 'alive':
                    if time.monotonic() >= deadline:
                        remote_remaining.append(int(own_pid)); break
                    time.sleep(.1)
        remaining = []
        if (root / 'pid').exists():
            pid = int((root / 'pid').read_text())
            try: os.kill(pid, signal.SIGTERM)
            except ProcessLookupError: pass
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                try: os.kill(pid, 0)
                except ProcessLookupError: break
                time.sleep(.05)
            else: remaining.append(pid)
        (root / 'owned-pids.json').write_text(json.dumps({'remaining': remaining, 'remoteRemaining': remote_remaining}))
        print(f'CLEANUP: owned CLI processes remaining={len(remaining)}; local SSE closed', flush=True)
        try: osa('on run a\ntell application id (item 1 of a) to activate\nend run', original)
        except Exception: pass
        assert not remaining and not remote_remaining


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('entry', nargs='?')
    parser.add_argument('--ssh-host')
    parser.add_argument('--decision', choices=['allow', 'deny'])
    args = parser.parse_args()
    entry = args.entry or str(Path(__file__).resolve().parents[2] / 'dist/index.js')
    run(entry if args.ssh_host else Path(entry).resolve(), args.ssh_host, args.decision)
