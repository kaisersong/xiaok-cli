import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { PassThrough } from 'node:stream';
import { createTtyHarness } from '../support/tty.js';
import { ScrollRegionManager } from '../../src/ui/scroll-region.js';
import { readTerminalCursor } from '../../src/ui/terminal-cursor.js';
vi.mock('../../src/ui/terminal-cursor.js', () => ({ readTerminalCursor: vi.fn(() => null) }));
beforeEach(() => vi.mocked(readTerminalCursor).mockReturnValue(null));

describe('terminal return geometry', () => {
  it.each([false, true])('shifts content and chrome into the resized viewport (busy=%s)', busy => {
    const stream = new PassThrough() as unknown as NodeJS.WriteStream;
    let output = ''; stream.on('data', data => { output += data.toString(); });
    const manager = new ScrollRegionManager(stream, { footerHeight: 3, gapHeight: 3, rows: 60, columns: 110 });
    manager.begin(); manager.setContentCursor(20); manager.writeAtContentCursor('TRANSCRIPT_TAIL');
    manager.renderInput('KEEP_DRAFT', 4);
    if (busy) manager.renderActivity('Thinking');
    output = '';
    manager.updateSize(24, 65);
    expect((manager as any)._cursorRow).toBe(1);
    expect(manager.getContentCursor()).toBe(20);
    const cursorRows = [...output.matchAll(/\x1b\[(\d+);\d+H/g)].map(match => Number(match[1]));
    expect(cursorRows.every(row => row <= 24)).toBe(true);
    expect(output).toContain('KEEP_DRAFT');
    manager.end();
  });
  it.each(['question', 'permission'] as const)('keeps the active %s owner and choices while resizing', kind => {
    const stream = new PassThrough() as unknown as NodeJS.WriteStream;
    let output = ''; stream.on('data', data => { output += data.toString(); });
    const manager = new ScrollRegionManager(stream, { footerHeight: 3, gapHeight: 3, rows: 24, columns: 80 });
    manager.begin();
    manager.renderPromptFrame({ inputValue: 'DRAFT', cursor: 3, placeholder: '', statusLine: 'MODEL',
      overlayLines: ['CHOICE_WAITING'], overlayKind: kind, owner: 'renderer' });
    output = ''; manager.updateSize(30, 100);
    expect(output).toContain('CHOICE_WAITING');
    expect(manager.hasActiveOverlayPrompt()).toBe(true);
    manager.end();
  });

  it('does not erase the response tail when resize clips rows below the editor cursor', () => {
    const h = createTtyHarness(110, 60);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin(); manager.setContentCursor(53); manager.writeAtContentCursor('FINAL_RESPONSE');
      manager.renderInput('DRAFT', 3);
      h.resize(65, 24);
      expect(h.screen.text()).toContain('FINAL_RESPONSE');
      manager.updateSize(24, 65);
      expect(h.screen.text()).toContain('FINAL_RESPONSE');
      expect(h.screen.text()).toContain('DRAFT');
    } finally { manager.end(); h.restore(); }
  });

});

describe('Ghostty redrawable prompt boundary', () => {
  const capture = () => {
    const stream = new PassThrough() as unknown as NodeJS.WriteStream;
    let output = ''; stream.on('data', data => { output += data.toString(); });
    const manager = new ScrollRegionManager(stream, { footerHeight: 3, gapHeight: 3, rows: 30, columns: 90 });
    manager.begin();
    return { manager, take: () => { const result = output; output = ''; return result; } };
  };
  afterEach(() => vi.unstubAllEnvs());
  const ghostty = () => {
    vi.stubEnv('TERM', 'xterm-ghostty'); vi.stubEnv('TERM_PROGRAM', '');
    vi.stubEnv('TMUX', ''); vi.stubEnv('STY', '');
  };

  it('marks live chrome and returns the physical editor cursor to input semantics', () => {
    ghostty(); const { manager, take } = capture(); take();
    manager.renderPromptFrame({ inputValue: '草稿', cursor: 1, placeholder: '', summaryLine: 'SUMMARY', statusLine: 'MODEL' });
    const frame = take();
    expect(frame).toContain('\x1b]133;P;k=i\x07');
    expect(frame.indexOf('\x1b]133;P;k=i\x07')).toBeLessThan(frame.indexOf('SUMMARY'));
    expect(frame).toMatch(/\x1b\[\d+;\d+H\x1b\]133;B\x07$/);
    manager.renderActivity('THINKING');
    const activity = take();
    expect(activity.slice(0, activity.indexOf('THINKING'))).toContain('\x1b]133;C\x07');
    expect(activity).toMatch(/\x1b\]133;B\x07$/);
    manager.end();
  });

  it.each(['question', 'permission'] as const)('marks the complete %s overlay before rendering choices', kind => {
    ghostty(); const { manager, take } = capture(); take();
    manager.renderPromptFrame({ inputValue: 'DRAFT', cursor: 2, placeholder: '', statusLine: 'MODEL',
      overlayLines: ['CHOICE'], overlayKind: kind, owner: 'renderer' });
    const frame = take();
    expect(frame.indexOf('\x1b]133;P;k=i\x07')).toBeGreaterThanOrEqual(0);
    expect(frame.indexOf('\x1b]133;P;k=i\x07')).toBeLessThan(frame.indexOf('CHOICE'));
    expect(frame).toMatch(/\x1b\]133;B\x07$/);
    manager.updateSize(24, 65); expect(take()).toContain('CHOICE');
    expect(manager.hasActiveOverlayPrompt()).toBe(true); manager.end();
  });

  it.each(['direct', 'submitted', 'streaming', 'raw', 'position', 'resize', 'exit'])('ends prompt semantics before %s output', kind => {
    ghostty(); const { manager, take } = capture(); manager.renderInput('DRAFT', 2); take();
    if (kind === 'direct') manager.writeAtContentCursor('ANSWER');
    if (kind === 'submitted') manager.writeSubmittedInput('QUESTION\n');
    if (kind === 'streaming') manager.beginContentStreaming();
    if (kind === 'raw') manager.writeRawBlock('GRAPHIC', 1);
    if (kind === 'position') manager.positionCursorAtContentCursor();
    if (kind === 'resize') manager.updateSize(24, 65);
    if (kind === 'exit') manager.end();
    expect(take()).toMatch(/^\x1b\]133;C\x07/);
    manager.end();
  });

  it('uses the measured content anchor and erases SSH chrome before homing the cursor', () => {
    ghostty(); const { manager, take } = capture();
    manager.setContentCursor(20); manager.writeAtContentCursor('RESPONSE_TAIL');
    manager.renderInput('DRAFT', 3); take();
    vi.mocked(readTerminalCursor).mockImplementationOnce((stream, restore) => {
      stream.write(restore + '\x1b[6n');
      return { row: 9, column: 14 };
    });
    manager.updateSize(24, 65);
    const frame = take();
    expect(frame).toContain('\x1b8\x1b[6n\x1b[0m\x1b[J');
    expect(frame).toContain('\x1b[9;14H\x1b7');
    expect((manager as any)._cursorRow).toBe(9);
    expect((manager as any)._cursorCol).toBe(13);
    expect(frame).toContain('DRAFT'); manager.end();
  });

  it('saves the blank row after a full-width line instead of its last character', () => {
    ghostty(); const { manager, take } = capture();
    manager.beginContentStreaming(); manager.getColumnAdvanceCallback()(90); take();
    manager.renderInput('DRAFT', 3);
    const frame = take();
    expect(frame).toContain('\x1b[2;1H\x1b7');
    expect(frame).not.toContain('\x1b[1;91H\x1b7');
    manager.end();
  });

  it('uses the measured viewport and skips the already coalesced resize event', () => {
    ghostty(); const { manager } = capture(); manager.renderInput('DRAFT', 3);
    vi.mocked(readTerminalCursor).mockReturnValueOnce({ row: 9, column: 14, rows: 24, columns: 65 });
    manager.updateSize(27, 70);
    expect((manager as any).config.rows).toBe(24);
    expect((manager as any).config.columns).toBe(65);
    const calls = vi.mocked(readTerminalCursor).mock.calls.length;
    manager.updateSize(24, 65);
    expect(vi.mocked(readTerminalCursor).mock.calls.length).toBe(calls);
    manager.end();
  });

  it.each(['other', 'tmux', 'screen'])('keeps %s terminal output unchanged', terminal => {
    ghostty();
    if (terminal === 'other') vi.stubEnv('TERM', 'xterm-256color');
    if (terminal === 'tmux') vi.stubEnv('TMUX', 'test');
    if (terminal === 'screen') vi.stubEnv('STY', 'test');
    const { manager, take } = capture(); manager.renderInput('DRAFT', 2); manager.end();
    expect(take()).not.toContain('\x1b]133;');
  });
});
