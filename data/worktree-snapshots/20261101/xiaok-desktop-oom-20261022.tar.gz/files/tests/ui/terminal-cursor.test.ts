import { describe, expect, it, vi } from 'vitest';
import { queryTerminalCursor, type CursorQueryIo } from '../../src/ui/terminal-cursor.js';

function fixture(chunks: Array<Buffer | Error>) {
  let time = 0;
  const replay = vi.fn();
  const io: CursorQueryIo = {
    write: vi.fn(), replay,
    read: () => { const chunk = chunks.shift(); if (chunk instanceof Error) throw chunk; return chunk ?? Buffer.alloc(0); },
    now: () => time, pause: () => { time += 5; },
  };
  return { io, replay };
}

describe('bounded terminal cursor report', () => {
  it('reads a fragmented report and preserves coalesced UTF-8 input byte for byte', () => {
    const input = Buffer.from('草稿');
    const { io, replay } = fixture([Buffer.concat([input.subarray(0, 2), Buffer.from('\x1b[1')]), Buffer.from('7;22R'), input.subarray(2)]);
    // Input after the report remains unread for the normal stdin owner.
    expect(queryTerminalCursor(io)).toEqual({ row: 17, column: 22 });
    expect(io.write).toHaveBeenCalledWith('\x1b[6n');
    expect(replay).toHaveBeenCalledWith(input.subarray(0, 2));
  });
  it('returns bytes before and after the report without interpreting control keys', () => {
    const { io, replay } = fixture([Buffer.from('before\x1b[8;9R\x03after')]);
    expect(queryTerminalCursor(io)).toEqual({ row: 8, column: 9 });
    expect(replay).toHaveBeenCalledWith(Buffer.from('before\x03after'));
  });
  it('bounds a missing response and returns all ordinary input', () => {
    const { io, replay } = fixture([Buffer.from('keep-this')]);
    expect(queryTerminalCursor(io, 20)).toBeNull();
    expect(io.now()).toBe(20);
    expect(replay).toHaveBeenCalledWith(Buffer.from('keep-this'));
  });
  it('preserves input on a read failure', () => {
    const { io, replay } = fixture([Buffer.from('retain'), new Error('read failed')]);
    expect(queryTerminalCursor(io)).toBeNull();
    expect(replay).toHaveBeenCalledWith(Buffer.from('retain'));
  });
  it('falls back on write failure without attempting a read', () => {
    const { io } = fixture([]); io.write = () => { throw new Error('write failed'); }; io.read = vi.fn();
    expect(queryTerminalCursor(io)).toBeNull(); expect(io.read).not.toHaveBeenCalled();
  });
});
