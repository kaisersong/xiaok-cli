/**
 * Tests for scroll region activity line rendering and the
 * contentStreaming flag that prevents thinking line duplication.
 *
 * Uses only \n, \r, \x1b[1A (cursor up), \x1b[2K (clear line) —
 * no absolute cursor positioning for terminal compatibility.
 */

import { describe, expect, it, vi, beforeEach, afterEach } from 'vitest';
import { PassThrough } from 'node:stream';
import { MarkdownRenderer } from '../../src/ui/markdown.js';
import { formatProgressNote, formatSubmittedInput, setColorsEnabled } from '../../src/ui/render.js';
import { formatCurrentTurnIntentSummaryLine, formatIntentStageSummaryTranscriptBlock } from '../../src/ui/orchestration.js';
import { ScrollRegionManager } from '../../src/ui/scroll-region.js';
import { renderImageLines } from '../../src/ui/image-renderer.js';
import { createTtyHarness } from '../support/tty.js';

// These byte-level compatibility cases use the generic ANSI terminal.
// Ghostty's semantic prompt protocol has dedicated tests in scroll-region-return.
beforeEach(() => { vi.stubEnv('TERM', 'xterm-256color'); vi.stubEnv('TERM_PROGRAM', ''); });
afterEach(() => vi.unstubAllEnvs());

function createMockScrollRegion() {
  const mock = new PassThrough();
  const chunks: string[] = [];
  mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));

  const stream = mock as unknown as NodeJS.WriteStream;
  (stream as any).rows = 24;
  (stream as any).columns = 80;

  const manager = new ScrollRegionManager(stream);
  return {
    manager,
    stream: mock,
    getOutput: () => chunks.join(''),
    getChunks: () => [...chunks],
    resetOutput: () => {
      chunks.length = 0;
    },
  };
}

describe('ScrollRegionManager activity rendering', () => {
  it('commits multi-row SubAgent ticks as one frame without a blank activity interval', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const originalWrite = process.stdout.write;
    const frames: string[] = [];
    try {
      manager.begin();
      manager.renderInput('KEEP_DRAFT', 4);
      manager.renderActivity('SubAgent 双鱼座: 思考中 1m2s\n⠋ Thinking · 26m20s');
      process.stdout.write = ((chunk: string | Uint8Array) => {
        const result = originalWrite.call(process.stdout, chunk);
        frames.push(harness.screen.text());
        return result;
      }) as typeof process.stdout.write;
      for (let index = 0; index < 12; index++) {
        const before = frames.length;
        manager.renderActivity(`SubAgent 双鱼座: 思考中 1m${index + 3}s\n⠙ Thinking · 26m20s`);
        expect(frames.length - before).toBe(1);
        for (const frame of frames.slice(before)) {
          expect(frame).toContain('SubAgent 双鱼座');
          expect(frame).toContain('Thinking');
          expect(frame).toContain('KEEP_DRAFT');
        }
      }
    } finally {
      process.stdout.write = originalWrite;
      manager.end();
      harness.restore();
    }
  });

  it('commits transcript reservation and activity growth together', () => {
    const { manager, getChunks, resetOutput } = createMockScrollRegion();
    manager.begin();
    manager.setContentCursor(manager.maxContentRows);
    manager.writeAtContentCursor('TAIL');
    manager.renderActivity('Thinking');
    resetOutput();
    manager.renderActivity('SubAgent A: thinking\nSubAgent B: read\nWorking');
    const frames = getChunks().filter(Boolean);
    expect(frames).toHaveLength(1);
    expect(frames[0]).toContain('SubAgent A');
    expect(frames[0]).toContain('Working');
    manager.end();
  });

  it('separates live activity from a full transcript using existing footer space without scrolling', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.renderInput('KEEP_DRAFT', 4);
      const bottom = manager.maxContentRows;
      manager.setContentCursor(bottom);
      manager.writeAtContentCursor('TAIL');
      const cursor = manager.getContentCursor();
      const offset = harness.output.raw.length;
      for (let i = 0; i < 20; i++) manager.renderActivity('Running verification');
      const lines = harness.screen.lines();
      const tail = lines.findIndex(line => line.includes('TAIL'));
      const activity = lines.findIndex(line => line.includes('Running verification'));
      expect(tail).toBe(bottom - 1);
      expect(activity).toBe(tail + 2);
      expect(lines[activity - 1].trim()).toBe('');
      expect(lines[activity + 1].trim()).toBe('');
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
      expect(manager.maxContentRows).toBe(bottom);
      expect(manager.getContentCursor()).toBe(cursor);
      expect(harness.output.raw.slice(offset)).not.toContain('\n');
    } finally { manager.end(); harness.restore(); }
  });

  it('keeps live activity visible when the footer status refreshes', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.renderActivity('Running verification');
      manager.updateStatusLine('updated status');
      expect(harness.screen.text()).toContain('Running verification');
      expect(harness.screen.text()).toContain('updated status');
    } finally { manager.end(); harness.restore(); }
  });

  it('preserves a multiline draft and cursor when streaming ends', () => {
    const { manager } = createMockScrollRegion();
    manager.begin();
    manager.beginContentStreaming();
    manager.renderInput('first\n继续输入', 8);
    manager.endContentStreaming({ inputPrompt: 'Finishing response...' });
    expect(manager.getPromptFrameState()).toMatchObject({ inputValue: 'first\n继续输入', cursor: 8 });
    manager.clearLastInput();
    expect(manager.getPromptFrameState().inputValue).toBe('');
  });

  it.each(['darwin', 'win32'])('refreshes activity and status without erasing input on %s', (platform) => {
    const descriptor = Object.getOwnPropertyDescriptor(process, 'platform')!;
    Object.defineProperty(process, 'platform', { value: platform, configurable: true });
    vi.stubEnv('TMUX', 'input-flicker-test');
    try {
      const { manager, getOutput, getChunks, resetOutput } = createMockScrollRegion();
      manager.begin();
      manager.renderInput('KEEP_DRAFT', 4);
      resetOutput();
      manager.renderActivity('Working');
      manager.updateStatusLine('new status');
      expect(getOutput()).not.toContain('\x1b[22;1H\x1b[2K');
      for (const chunk of getChunks().filter(chunk => chunk.includes('KEEP_DRAFT'))) {
        expect(chunk.endsWith('\x1b[22;7H')).toBe(true);
      }
    } finally {
      Object.defineProperty(process, 'platform', descriptor);
      vi.unstubAllEnvs();
    }
  });

  it('resets terminal style and shows cursor before clearing the footer on exit', () => {
    const {manager,resetOutput,getOutput}=createMockScrollRegion();
    manager.begin();resetOutput();manager.end();
    expect(getOutput()).toMatch(/^\x1b\[0m\x1b\[\?25h/);
  });

  it('renders vertical agents and Working separately, preserves the draft, clears shrinking rows without scrolling each tick', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.renderPromptFrame({ inputValue: 'KEEP_DRAFT', cursor: 10, placeholder: '', statusLine: 'MODEL' });
      manager.renderActivity('SubAgent Pisces: read\nSubAgent Libra: thinking\nWorking');
      const lines = harness.screen.lines();
      const first = lines.findIndex(line => line.includes('SubAgent Pisces'));
      expect(first).toBeGreaterThanOrEqual(0);
      expect(lines[first + 1]).toContain('SubAgent Libra');
      expect(lines[first + 2]).toContain('Working');
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
      const before = harness.output.raw.length;
      for (let i = 0; i < 20; i++) manager.renderActivity('SubAgent Pisces: read\nSubAgent Libra: thinking\nWorking');
      expect(harness.output.raw.slice(before)).not.toContain('\n');
      manager.renderActivity('Working');
      expect(harness.screen.text()).not.toContain('SubAgent');
      manager.clearActivity();
      expect(harness.screen.text()).not.toContain('Working');
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
    } finally { manager.end(); harness.restore(); }
  });
  it('pages ten agents on a short screen and preserves the main activity and transcript tail', () => {
    vi.useFakeTimers();
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      vi.setSystemTime(0);
      manager.begin();
      manager.writeAtContentCursor(Array.from({ length: 15 }, (_, i) => `BODY_${i}\n`).join(''));
      const activity = [...Array.from({ length: 10 }, (_, i) => `SubAgent agent_${i}`), 'Working'].join('\n');
      manager.renderActivity(activity);
      expect(harness.screen.text()).toContain('BODY_14');
      expect(harness.screen.text()).toContain('agent_0');
      expect(harness.screen.text()).toContain('Working');
      const offset = harness.output.raw.length;
      vi.setSystemTime(4000);
      manager.renderActivity(activity);
      expect(harness.screen.text()).toContain('agent_9');
      expect(harness.screen.text()).not.toContain('agent_0');
      expect(harness.screen.text()).toContain('BODY_14');
      expect(harness.output.raw.slice(offset)).not.toContain('\n');
      manager.clearActivity();
      expect(harness.screen.text()).not.toContain('SubAgent');
      expect(harness.screen.text()).toContain('BODY_14');
    } finally { manager.end(); harness.restore(); vi.useRealTimers(); }
  });

  it('keeps vertical activity and input intact when the terminal shrinks then grows', () => {
    const harness = createTtyHarness(80, 30);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.renderPromptFrame({ inputValue: 'KEEP_DRAFT', cursor: 10, placeholder: '', statusLine: 'MODEL' });
      manager.renderActivity('SubAgent Pisces\nSubAgent Libra\nWorking');
      harness.resize(45, 20);
      manager.updateSize(20, 45);
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
      expect(harness.screen.text()).toContain('SubAgent Pisces');
      manager.renderActivity('Working');
      expect(harness.screen.text()).not.toContain('SubAgent');
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
      harness.resize(80, 30);
      manager.updateSize(30, 80);
      expect(harness.screen.text()).toContain('Working');
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
    } finally { manager.end(); harness.restore(); }
  });

  it('clears every agent row while a question owns the footer, then restores live progress', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.renderActivity('SubAgent Pisces\nSubAgent Libra\nWorking');
      manager.renderPromptFrame({ inputValue: 'DRAFT', cursor: 5, placeholder: '', statusLine: 'MODEL', overlayLines: ['QUESTION'], overlayKind: 'question', owner: 'renderer' });
      expect(harness.screen.text()).not.toContain('SubAgent');
      manager.renderActivity('SubAgent hidden\nWorking');
      expect(harness.screen.text()).not.toContain('hidden');
      expect(harness.screen.text()).toContain('QUESTION');
      manager.clearOverlayPromptState();
      // The input owner restores its draft after releasing the question editor.
      manager.renderPromptFrame({ inputValue: 'DRAFT', cursor: 5, placeholder: '', statusLine: 'MODEL' });
      manager.renderActivity('SubAgent Pisces\nWorking');
      expect(harness.screen.text()).toContain('SubAgent Pisces');
      expect(harness.screen.text()).toContain('DRAFT');
    } finally { manager.end(); harness.restore(); }
  });

  it('reserves transcript space before a smaller footer can erase a completed response', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.writeAtContentCursor(Array.from({ length: 14 }, (_, i) => `LINE_${i}\n`).join(''));
      manager.writeAtContentCursor('FINAL_RESPONSE');
      manager.renderFooter();
      harness.resize(52, 20);
      manager.updateSize(20, 52);
      expect(harness.screen.text()).toContain('FINAL_RESPONSE');
    } finally { manager.end(); harness.restore(); }
  });

  it('does not pad activity rows with spaces that reflow when the terminal narrows', () => {
    const { manager, getOutput, resetOutput } = createMockScrollRegion();
    manager.begin();
    resetOutput();
    manager.renderActivity('SubAgent Pisces\nWorking');
    expect(getOutput()).not.toMatch(/(?:SubAgent Pisces|Working) +/);
    manager.end();
  });

  describe('basic activity rendering', () => {
    it('renders activity line when scroll region is active', () => {
      const { manager, getOutput } = createMockScrollRegion();
      manager.begin();

      manager.renderActivity('⠋ Thinking · 3s');
      manager.renderFooter({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });

      const output = getOutput();
      // Should contain the activity text
      expect(output).toContain('⠋ Thinking · 3s');
      // Should contain the footer content
      expect(output).toContain('waiting...');
      expect(output).toContain('gpt-5.4');
    });

    it('does not render activity when scroll region is inactive', () => {
      const { manager, getOutput } = createMockScrollRegion();
      manager.renderActivity('⠋ Thinking');
      const output = getOutput();
      expect(output).toContain('⠋ Thinking');
    });

    it('does not clear the last visible content row when no activity line is active', () => {
      const harness = createTtyHarness(80, 24);
      const manager = new ScrollRegionManager(process.stdout);

      try {
        manager.begin();
        manager.writeAtContentCursor('tail line');
        manager.clearActivity();

        const lines = harness.screen.lines();
        expect(lines.some((line) => line.includes('tail line'))).toBe(true);
      } finally {
        harness.restore();
      }
    });

    it('clears same-row activity before markdown emits a content newline', () => {
      const harness = createTtyHarness(80, 24);
      const manager = new ScrollRegionManager(process.stdout);

      try {
        manager.begin();
        manager.renderFooter({
          inputPrompt: 'Finishing response...',
          statusLine: 'gpt-terminal-e2e · auto · project',
        });
        manager.renderActivity('⠸ Running command · 0s');
        manager.setContentCursor(manager.maxContentRows);
        manager.positionCursorAtContentCursor();
        manager.getNewlineCallback()();

        expect(harness.screen.text()).not.toContain('Running command');
      } finally {
        harness.restore();
      }
    });

    it('batches footer redraw while restoring an existing activity line', () => {
      const { manager, getChunks, resetOutput } = createMockScrollRegion();
      manager.begin();
      manager.renderActivity('⠋ Thinking · 1s');
      resetOutput();

      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 4% · project',
      });

      const chunks = getChunks();
      const promptChunks = chunks.filter((chunk) => chunk.includes('Type your message...'));
      const statusChunks = chunks.filter((chunk) => chunk.includes('gpt-terminal-e2e · auto · 4% · project'));

      expect(promptChunks).toHaveLength(1);
      expect(statusChunks).toHaveLength(1);
      expect(promptChunks[0]).toContain('⠋ Thinking · 1s');
    });

    it('does not emit a standalone activity-only frame when refreshing activity above a visible footer', () => {
      const { manager, getChunks, resetOutput } = createMockScrollRegion();
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        statusLine: 'kimi-for-coding · 29% · master',
      });
      resetOutput();

      manager.renderActivity('⠼ Finalizing response · 4m 49s');

      const chunks = getChunks();
      const activityChunks = chunks.filter((chunk) => chunk.includes('Finalizing response'));

      expect(activityChunks).toHaveLength(1);
      expect(activityChunks[0]).toContain('Finishing response...');
      expect(activityChunks[0]).toContain('kimi-for-coding');
    });
  });

  describe('content streaming flag behavior', () => {
    it('beginContentStreaming sets streaming flag', () => {
      const { manager, getOutput } = createMockScrollRegion();
      manager.begin();
      manager.beginContentStreaming();
      const output = getOutput();
      expect(manager.isContentStreaming()).toBe(true);
      expect(output).toContain('\x1b[1;1H');
    });

    it('endContentStreaming renders footer', () => {
      const { manager, getOutput } = createMockScrollRegion();
      manager.begin();
      manager.beginContentStreaming();
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
      });

      const output = getOutput();
      // Should contain footer rendering
      expect(output).toContain('Type your message...');
      expect(output).toContain('gpt-5.4 · 5%');
    });

    it('finalizes an unterminated content row before the next streaming segment', () => {
      const { manager, getOutput, resetOutput } = createMockScrollRegion();
      manager.begin();
      manager.beginContentStreaming();
      manager.getColumnAdvanceCallback()(17);

      manager.endContentStreaming({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });
      resetOutput();
      manager.beginContentStreaming();
      expect((manager as any)._cursorCol).toBe(0);
      expect(getOutput()).not.toContain('\x1b[18G');
    });

    it('scrolls an unterminated bottom-row segment before activity can clear it', () => {
      const { manager, getOutput, resetOutput } = createMockScrollRegion();
      manager.begin();
      manager.setContentCursor(manager.maxContentRows);
      manager.beginContentStreaming();
      manager.getColumnAdvanceCallback()(17);
      resetOutput();

      manager.endContentStreaming({
        inputPrompt: 'waiting...',
        statusLine: 'gpt-5.4',
        reserveActivityRow: true,
      });

      expect((manager as any)._cursorCol).toBe(0);
      expect(getOutput()).toContain('\n');
    });

    it('pads placeholder input with footer background across the row', () => {
      const { manager, getOutput } = createMockScrollRegion();
      manager.begin();

      manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'gpt-5.4' });

      const output = getOutput();
      expect(output).toMatch(/❯\x1b\[22;39m \x1b\[2mType your message\.\.\.\x1b\[K\x1b\[0m/);
    });

    it('keeps the footer rows visible while content is streaming', () => {
      const harness = createTtyHarness(80, 24);
      const manager = new ScrollRegionManager(process.stdout);

      try {
        manager.begin();
        manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'gpt-5.4 · 5% · project' });
        manager.beginContentStreaming();
        manager.writeAtContentCursor('streaming line');

        const lines = harness.screen.lines();
        expect(lines.some((line) => line.includes('❯ Type your message...'))).toBe(true);
        expect(lines.some((line) => line.includes('gpt-5.4 · 5% · project'))).toBe(true);
      } finally {
        harness.restore();
      }
    });
  });
});

describe('contentStreaming flag logic (simulated)', () => {
  function simulateTurnWithStreaming(
    renderActivityCalls: { at: 'tool_use' | 'content_streaming' | 'idle'; label: string }[],
  ): { renderedLabels: string[]; duplicates: string[] } {
    let contentStreaming = false;
    const renderedLabels: string[] = [];

    const renderLiveActivity = (label: string): void => {
      if (contentStreaming) return;
      renderedLabels.push(label);
    };

    for (const call of renderActivityCalls) {
      if (call.at === 'content_streaming') {
        contentStreaming = true;
        renderLiveActivity(call.label);
      } else if (call.at === 'idle') {
        contentStreaming = false;
        renderLiveActivity(call.label);
      }
    }

    const seen = new Map<string, number>();
    const duplicates: string[] = [];
    for (const label of renderedLabels) {
      const count = seen.get(label) ?? 0;
      seen.set(label, count + 1);
      if (count > 0) {
        duplicates.push(label);
      }
    }

    return { renderedLabels, duplicates };
  }

  it('without fix: rapid timer causes thinking line duplication during streaming', () => {
    const result = simulateTurnWithStreaming([
      { at: 'idle', label: '⠋ Thinking · 1s' },
      { at: 'idle', label: '⠙ Thinking · 1s' },
      { at: 'idle', label: '⠹ Thinking · 2s' },
      { at: 'content_streaming', label: '⠸ Thinking · 2s' },
      { at: 'content_streaming', label: '⠼ Thinking · 3s' },
      { at: 'content_streaming', label: '⠴ Thinking · 3s' },
    ]);

    expect(result.renderedLabels).toEqual([
      '⠋ Thinking · 1s',
      '⠙ Thinking · 1s',
      '⠹ Thinking · 2s',
    ]);
    expect(result.duplicates).toEqual([]);
  });

  it('tool execution phase can still show activity after content streaming ends', () => {
    const result = simulateTurnWithStreaming([
      { at: 'idle', label: '⠋ Thinking · 1s' },
      { at: 'content_streaming', label: '⠙ Thinking · 2s' },
      { at: 'content_streaming', label: '⠹ Thinking · 2s' },
      { at: 'idle', label: '⠸ Running command' },
      { at: 'idle', label: '⠼ Running command' },
    ]);

    expect(result.renderedLabels).toEqual([
      '⠋ Thinking · 1s',
      '⠸ Running command',
      '⠼ Running command',
    ]);
  });

  it('multiple turns: each turn resets contentStreaming flag', () => {
    const turn1 = simulateTurnWithStreaming([
      { at: 'idle', label: '⠋ Thinking · 1s' },
      { at: 'content_streaming', label: '⠙ Content · 2s' },
      { at: 'content_streaming', label: '⠹ Content · 3s' },
    ]);

    const turn2 = simulateTurnWithStreaming([
      { at: 'idle', label: '⠸ Tool exec · 1s' },
      { at: 'content_streaming', label: '⠼ Content · 2s' },
    ]);

    expect(turn1.renderedLabels).toEqual(['⠋ Thinking · 1s']);
    expect(turn2.renderedLabels).toEqual(['⠸ Tool exec · 1s']);
  });

  it('edge case: no content streaming at all (pure tool execution)', () => {
    const result = simulateTurnWithStreaming([
      { at: 'idle', label: '⠋ Reading file' },
      { at: 'idle', label: '⠙ Searching' },
      { at: 'idle', label: '⠹ Analyzing' },
    ]);

    expect(result.renderedLabels).toEqual([
      '⠋ Reading file',
      '⠙ Searching',
      '⠹ Analyzing',
    ]);
  });
});

describe('scroll-region prompt frame ownership', () => {
  it('renders queued overlay while preserving the status line', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Finishing response...',
        summaryLine: '',
        statusLine: 'gpt-5.4 · 5% · project',
        overlayKind: 'queued',
        overlayLines: [
          'Queued (press ↑ to edit):',
          '  更新了没',
        ],
      });

      const text = harness.screen.text();
      expect(text).toContain('Queued (press ↑ to edit):');
      expect(text).toContain('更新了没');
      expect(text).toContain('gpt-5.4 · 5% · project');
    } finally {
      harness.restore();
    }
  });

  it('clears stale queued overlay rows when the prompt frame no longer has an overlay', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Finishing response...',
        summaryLine: '',
        statusLine: 'gpt-5.4 · 5% · project',
        overlayKind: 'queued',
        overlayLines: [
          'Queued (press ↑ to edit):',
          '  更新了没',
        ],
      });
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Finishing response...',
        summaryLine: '',
        statusLine: 'gpt-5.4 · 5% · project',
        overlayLines: [],
      });

      const text = harness.screen.text();
      expect(text).not.toContain('Queued (press ↑ to edit):');
      expect(text).not.toContain('更新了没');
      expect(text).toContain('gpt-5.4 · 5% · project');
    } finally {
      harness.restore();
    }
  });

  it('keeps queued overlay visible when footer chrome redraws during the busy turn', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Finishing response...',
        summaryLine: '',
        statusLine: 'gpt-5.4 · 5% · project',
        overlayKind: 'queued',
        overlayLines: [
          'Queued (press ↑ to edit):',
          '  更新了没',
        ],
      });

      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        summaryLine: '',
        statusLine: 'gpt-5.4 · 6% · project',
      });

      const text = harness.screen.text();
      expect(text).toContain('Queued (press ↑ to edit):');
      expect(text).toContain('更新了没');
      expect(text).toContain('gpt-5.4 · 6% · project');
    } finally {
      harness.restore();
    }
  });

  it('compacts queued overlay to keep the queued text visible when only one overlay row fits', () => {
    const harness = createTtyHarness(48, 8);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Finishing response...',
        summaryLine: '',
        statusLine: 'gpt-5.4 · 8% · project',
        overlayKind: 'queued',
        overlayLines: [
          'Queued (press ↑ to edit):',
          '  第二次提示词',
        ],
      });

      const text = harness.screen.text();
      expect(text).toContain('Queued (press ↑ to edit):');
      expect(text).toContain('第二次提示词');
    } finally {
      harness.restore();
    }
  });

  it('renders the sticky summary line above the input and separate from activity and status rows', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'Customer proposal',
      stageOrder: 0,
      totalStages: 1,
      stageLabel: 'Collect',
      status: 'Drafting Plan',
    });

    try {
      manager.begin();
      manager.renderActivity('⠋ Thinking · 1s');
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine,
        statusLine: 'gpt-5.4 · 5% · master · xiaok-cli',
      });

      const lines = harness.screen.lines();
      const activityIndex = lines.findIndex((line) => line.includes('Thinking · 1s'));
      const summaryIndex = lines.findIndex((line) => line.includes('Intent: Customer proposal'));
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const statusIndex = lines.findIndex((line) => line.includes('gpt-5.4 · 5% · master · xiaok-cli'));

      expect(activityIndex).toBeGreaterThanOrEqual(0);
      expect(summaryIndex).toBeGreaterThan(activityIndex);
      expect(promptIndex).toBeGreaterThan(summaryIndex);
      expect(statusIndex).toBeGreaterThan(promptIndex);
      expect(lines[summaryIndex]).not.toContain('gpt-5.4');
      expect(lines[summaryIndex]).not.toContain('Thinking');
      expect(lines[summaryIndex]).toContain('● Intent: Customer proposal · Stage 1/1 Collect · Drafting Plan');
      expect(summaryIndex).toBe(promptIndex - 3);
      expect(lines[summaryIndex + 1]).toBe('');
      expect(lines[activityIndex]).not.toContain('Intent: Customer proposal');
    } finally {
      harness.restore();
    }
  });

  it('preserves ANSI intent-hint styling in the rendered footer summary line', () => {
    const { manager, getOutput } = createMockScrollRegion();
    setColorsEnabled(true);
    try {
      const summaryLine = formatCurrentTurnIntentSummaryLine({
        deliverable: 'md -> 报告',
        stageOrder: 0,
        totalStages: 2,
        stageLabel: '提取 Markdown',
        status: 'Drafting Plan',
      });

      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine,
        statusLine: 'gpt-5.4 · 5% · master · xiaok-cli',
      });

      const output = getOutput();
      expect(output).toContain('\x1b[38;2;122;168;255m●\x1b[0m');
      expect(output).toContain('\x1b[38;2;142;142;142mIntent: md -> 报告 · Stage 1/2 提取 Markdown · Drafting Plan\x1b[0m');
    } finally {
      setColorsEnabled(
        process.stdout.isTTY !== false &&
        !process.env.NO_COLOR &&
        !process.argv.includes('--no-color'),
      );
    }
  });

  it('keeps the prompt and status visible when a wrapped summary line shares the footer with changed and ran tool blocks', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 0,
      totalStages: 2,
      stageLabel: '提取 Markdown 并生成结构化报告草稿',
      status: 'Executing tools',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine,
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      for (let index = 0; index < 10; index += 1) {
        manager.writeAtContentCursor(`context line ${index + 1}\n`);
      }

      manager.writeAtContentCursor('\n\n  ╭─ Changed\n  │ Wrote report-analysis.report.md\n');
      manager.writeAtContentCursor(
        '\n\n  ╭─ Ran\n'
        + '  │ printf "const fs = require(\'fs\'); const report = fs.readFileSync(\'report-analysis.report.md\', \'utf8\'); // 解析并生成总结"\n',
      );
      manager.renderActivity('⠋ Executing command · 8s');

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('project') && line.includes('%'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(lines[21]).toContain('❯ Type your message...');
      expect(lines[23]).toContain('gpt-terminal-e2e · auto · 0% · project');
      expect(lines.some((line) => line.includes('Intent: md -> 报告'))).toBe(true);
      expect(lines.some((line) => line.includes('Wrote report-analysis.report.md'))).toBe(true);
      expect(lines.some((line) => line.includes('printf "const fs = require'))).toBe(true);
      expect(lines.some((line) => line.includes('Executing command · 8s'))).toBe(true);
    } finally {
      harness.restore();
    }
  });

  it('keeps the prompt row visible while consecutive ran blocks refresh the activity rail', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 0,
      totalStages: 2,
      stageLabel: '提取 Markdown',
      status: 'Working',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine,
        statusLine: 'gpt-terminal-e2e · 4% · project',
      });

      manager.writeAtContentCursor('\n\n  ╭─ Changed\n  │ Wrote combined-source.report.md\n');
      manager.writeAtContentCursor('\n\n  ╭─ Ran\n  │ printf "E2E_FEEDBACK_CONFIRM_MERGED_MD"\n');
      manager.renderActivity('⠋ Executing command · 7s');
      manager.writeAtContentCursor('  │ printf "E2E_FEEDBACK_CONFIRM_WRAP_BLOCK verifying footer stability after feedback confirmation"\n');
      manager.renderActivity('⠸ Executing command · 8s');
      manager.writeAtContentCursor('  │ printf "E2E_FEEDBACK_CONFIRM_STAGE2_OK"\n');
      manager.renderActivity('⠼ Executing command · 9s');

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('gpt-terminal-e2e · 4% · project'));
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const activityIndex = lines.findIndex((line) => line.includes('Executing command · 9s'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(promptIndex).toBeGreaterThan(activityIndex);
      expect(lines.slice(activityIndex + 1, promptIndex).filter((line) => line === '').length).toBeGreaterThanOrEqual(2);
      expect(lines.some((line) => line.includes('Wrote combined-source.report.md'))).toBe(true);
      expect(lines.filter((line) => line.includes('printf "E2E_FEEDBACK_CONFIRM')).length).toBeGreaterThanOrEqual(2);
    } finally {
      harness.restore();
    }
  });

  it('keeps the footer visible when a long ran block fills a short terminal before finalizing activity', () => {
    const harness = createTtyHarness(60, 8);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        statusLine: 'kimi-for-coding · 29% · master',
      });

      manager.writeAtContentCursor(
        '\n\n  ╭─ Ran\n'
        + '  │ cd /Users/song/projects/xiaok-cli/.tmp-slide-brief.json\n'
        + '  │ cd /Users/song/projects/xiaok-cli/.tmp-slide-brief.json --output\n'
        + '  │ cp "/Users/song/projects/xiaok-cli/Downloads/金蝶灵基-V1.9-"*\n',
      );
      manager.renderActivity('⠼ Finalizing response · 4m 49s');

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('kimi-for-coding'));
      const activityIndex = lines.findIndex((line) => line.includes('Finalizing response'));
      const promptIndex = lines.findIndex((line) => line.includes('❯ Finishing response...'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(promptIndex).toBe(5);
      expect(activityIndex).toBeLessThan(promptIndex);
    } finally {
      harness.restore();
    }
  });

  it('keeps the prompt row visible while activity ticks refresh above an existing footer', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 0,
      totalStages: 2,
      stageLabel: '提取 Markdown',
      status: 'Working',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        summaryLine,
        statusLine: 'gpt-terminal-e2e · auto · 4% · project',
      });

      manager.writeAtContentCursor('\n\n  ╭─ Explored\n  │ Read 01-market-overview.md\n');
      manager.writeAtContentCursor('\n\n  ╭─ Changed\n  │ Wrote report-analysis.report.md\n');

      manager.renderActivity('⠋ Updating files · 1s');
      manager.renderActivity('⠙ Updating files · 2s');
      manager.renderActivity('⠹ Updating files · 3s');
      manager.renderActivity('⠸ Updating files · 4s');

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('gpt-terminal-e2e · auto · 4% · project'));
      const promptIndex = lines.findIndex((line) => line.includes('❯ Finishing response...'));
      const activityIndex = lines.findIndex((line) => line.includes('Updating files · 4s'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(promptIndex).toBe(21);
      expect(activityIndex).toBeLessThan(promptIndex);
      expect(lines.some((line) => line.includes('Wrote report-analysis.report.md'))).toBe(true);
      expect(lines.some((line) => line.includes('Intent: md -> 报告'))).toBe(true);
    } finally {
      harness.restore();
    }
  });

  it('re-anchors the footer when activity ticks continue after the footer rows were cleared', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 0,
      totalStages: 2,
      stageLabel: '提取 Markdown',
      status: 'Working',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        summaryLine,
        statusLine: 'gpt-terminal-e2e · auto · 4% · project',
      });

      process.stdout.write('\x1b[20;1H\x1b[2K');
      process.stdout.write('\x1b[21;1H\x1b[2K');
      process.stdout.write('\x1b[22;1H\x1b[2K');
      process.stdout.write('\x1b[23;1H\x1b[2K');
      process.stdout.write('\x1b[24;1H\x1b[2K');

      manager.renderActivity('⠋ Finalizing response · 1m 47s');

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('gpt-terminal-e2e · auto · 4% · project'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(lines[21]).toContain('❯ Finishing response...');
      expect(lines[23]).toContain('gpt-terminal-e2e · auto · 4% · project');
      expect(lines.some((line) => line.includes('Finalizing response · 1m 47s'))).toBe(true);
    } finally {
      harness.restore();
    }
  });

  it('re-anchors the footer when a status-only update lands after the prompt row was cleared', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 0,
      totalStages: 2,
      stageLabel: '提取 Markdown',
      status: 'Working',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        summaryLine,
        statusLine: 'gpt-terminal-e2e · auto · 4% · project',
      });

      process.stdout.write('\x1b[23;1H\x1b[2K');
      process.stdout.write('\x1b[24;1H\x1b[2Kgpt-terminal-e2e · auto · 5% · project');

      manager.updateStatusLine('gpt-terminal-e2e · auto · 6% · project');

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('gpt-terminal-e2e · auto · 6% · project'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(lines[21]).toContain('❯ Finishing response...');
      expect(lines[23]).toContain('gpt-terminal-e2e · auto · 6% · project');
    } finally {
      harness.restore();
    }
  });

  it('suppresses activity redraws while the feedback overlay owns the footer', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · 4% · project',
        overlayLines: ['[xiaok] 这次结果是否满足预期？ [y] 满意 / [n] 不满意 / [s] 跳过'],
        overlayKind: 'feedback',
      });

      manager.renderActivity('⠋ Thinking · 1s');

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const overlayIndex = lines.findIndex((line) => line.includes('[xiaok] 这次结果是否满足预期？'));

      expect(lines.some((line) => line.includes('Thinking · 1s'))).toBe(false);
      expect(overlayIndex).toBeGreaterThanOrEqual(0);
      expect(promptIndex).toBeGreaterThan(overlayIndex);
      expect(lines.slice(overlayIndex + 1, promptIndex).filter((line) => line === '').length).toBeGreaterThanOrEqual(2);
    } finally {
      harness.restore();
    }
  });

  it('clears stale feedback overlay rows before restoring the normal footer', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · 4% · project',
        overlayLines: ['[xiaok] 这次结果是否满足预期？ [y] 满意 / [n] 不满意 / [s] 跳过'],
        overlayKind: 'feedback',
      });

      manager.clearOverlayPromptState();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · 4% · project',
      });

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯ Type your message...'));
      const statusRows = lines.filter((line) => line.includes('gpt-terminal-e2e · 4% · project'));

      expect(lines.some((line) => line.includes('[xiaok] 这次结果是否满足预期？'))).toBe(false);
      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(lines[21]).toContain('❯ Type your message...');
      expect(lines[23]).toContain('gpt-terminal-e2e · 4% · project');
    } finally {
      harness.restore();
    }
  });

  it('clears stale multi-row slash overlay rows before restoring the normal footer', () => {
    const previousTmux = process.env.TMUX;
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const promptGlyph = process.platform === 'win32' ? '>' : '❯';

    try {
      process.env.TMUX = 'tmux-test,1,0';
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '/mod',
        cursor: 4,
        placeholder: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · 4% · project',
        overlayLines: [
          '  ❯ /mode  查看当前权限模式',
          '    /mode default  切到 default',
          '    /mode auto  切到 auto',
          '    /models  打开模型选择器',
        ],
      });
      manager.renderPromptFrame({
        inputValue: '/mod',
        cursor: 4,
        placeholder: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · 4% · project',
        overlayLines: [],
      });

      manager.clearOverlayPromptState();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · 4% · project',
      });

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes(`${promptGlyph} Type your message...`));
      const statusRows = lines.filter((line) => line.includes('gpt-terminal-e2e · 4% · project'));

      expect(lines.some((line) => line.includes('/mode'))).toBe(false);
      expect(lines.some((line) => line.includes('/models'))).toBe(false);
      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
    } finally {
      if (previousTmux === undefined) {
        delete process.env.TMUX;
      } else {
        process.env.TMUX = previousTmux;
      }
      harness.restore();
    }
  });

  it('renders prompt, status, and overlay from a single scroll-region frame', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();

    manager.renderPromptFrame({
      inputValue: '/mo',
      cursor: 3,
      placeholder: 'Type your message...',
      statusLine: 'gpt-5.4 · 5%',
      overlayLines: ['  /mode  Show or change permission mode'],
    });

    const output = getOutput();
    expect(output).toContain('/mo');
    expect(output).toContain('/mode  Show or change permission mode');
  });

  it('renders multiple slash menu rows above the input when overlay is open', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '/',
        cursor: 1,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
        overlayLines: [
          '  ❯ /clear  Clear the screen',
          '    /commit  Commit staged changes',
          '    /context  Show loaded repo context',
          '    /doctor  Inspect local CLI health',
        ],
      });

      const lines = harness.screen.lines();
      expect(lines.some((line) => line.includes('/clear'))).toBe(true);
      expect(lines.some((line) => line.includes('/commit'))).toBe(true);
      expect(lines.some((line) => line.includes('/context'))).toBe(true);
      expect(lines.some((line) => line.includes('/doctor'))).toBe(true);
      expect(lines.some((line) => line.includes('gpt-5.4 · 5%'))).toBe(false);
      expect(lines[21]).toContain('❯ /');
    } finally {
      harness.restore();
    }
  });

  it('keeps two blank rows between overlay content and the input footer', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '/',
        cursor: 1,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
        overlayLines: [
          '⚡ xiaok 想要执行以下操作',
          '工具: bash',
          '命令: cmd /c where pi',
          '❯ 允许一次',
          '↑↓ 选择  Enter 确认  Esc 取消',
        ],
      });

      const lines = harness.screen.lines();
      const overlayBottomIndex = lines.findIndex((line) => line.includes('↑↓ 选择  Enter 确认  Esc 取消'));
      const promptIndex = lines.findIndex((line) => line.includes('❯ /'));

      expect(overlayBottomIndex).toBeGreaterThanOrEqual(0);
      expect(promptIndex).toBe(overlayBottomIndex + 5);
      expect(lines[overlayBottomIndex + 1]).toBe('');
      expect(lines[overlayBottomIndex + 2]).toBe('');
      expect(lines[overlayBottomIndex + 3]).toBe('');
      expect(lines[overlayBottomIndex + 4]).toBe('');
    } finally {
      harness.restore();
    }
  });

  it('truncates tall overlays so the footer gap remains intact', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const overlayLines = Array.from({ length: 30 }, (_, index) => `line ${index + 1}`);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
        overlayLines,
      });

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const overlayBottomIndex = lines.findIndex((line) => line.includes('line 30'));

      expect(overlayBottomIndex).toBeGreaterThanOrEqual(0);
      expect(promptIndex).toBe(overlayBottomIndex + 5);
      expect(lines[overlayBottomIndex + 1]).toBe('');
      expect(lines[overlayBottomIndex + 2]).toBe('');
      expect(lines[overlayBottomIndex + 3]).toBe('');
      expect(lines[overlayBottomIndex + 4]).toBe('');
    } finally {
      harness.restore();
    }
  });

  it('keeps the question and leading options visible when a question overlay is taller than the viewport', () => {
    const harness = createTtyHarness(80, 10);
    const manager = new ScrollRegionManager(process.stdout);
    const overlayLines = [
      '想吃什么类型的？',
      '  ❯ 1. 中餐炒菜  经典家常',
      '    2. 面食/粉类  面条',
      '    3. 轻食/沙拉  低卡',
      '    4. Other  Enter custom text',
      '  ↑↓ navigate   Enter select',
    ];

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'AskUserQuestion',
        statusLine: 'status',
        overlayLines,
        overlayKind: 'question',
      });

      const text = harness.screen.lines().join('\n');
      expect(text).toContain('想吃什么类型的？');
      expect(text).toContain('1. 中餐炒菜');
      // The footer hint is the least important and may be trimmed on short terminals.
    } finally {
      harness.restore();
    }
  });

  it.each([16, 10])('keeps the selected question option visible in a %s-row terminal', rows => {
    const harness = createTtyHarness(36, rows);
    const manager = new ScrollRegionManager(process.stdout);
    const render = (selected: number) => manager.renderPromptFrame({
      inputValue: '', cursor: 0, placeholder: 'AskUserQuestion', statusLine: 'status',
      overlayKind: 'question',
      overlayLines: [
        'QUESTION_TO_KEEP',
        ...Array.from({ length: 6 }, (_, index) => `  ${index === selected ? '\x1b[36m❯\x1b[0m' : ' '} ${index + 1}. CHOICE_${index + 1}${index === 0 ? ' ❯ label' : ''}`),
        '  1-6 select   ↑↓   Enter',
      ],
    });
    try {
      manager.begin();
      render(0);
      expect(harness.screen.text()).toContain('QUESTION_TO_KEEP');
      expect(harness.screen.text()).toContain('❯ 1. CHOICE_1');
      render(5);
      const text = harness.screen.text();
      expect(text).toContain('QUESTION_TO_KEEP');
      expect(text).toContain('❯ 6. CHOICE_6');
      if (rows === 16) expect(text.match(/1-6 select/g)).toHaveLength(1);
      expect(text).toContain('❯ AskUserQuestion');
      manager.renderPromptFrame({ inputValue: '', cursor: 0, placeholder: 'NEXT_INPUT', statusLine: 'status', overlayLines: [] });
      expect(harness.screen.text()).not.toContain('CHOICE_6');
      expect(harness.screen.text()).not.toContain('1-6 select');
      expect(harness.screen.text()).toContain('NEXT_INPUT');
    } finally { manager.end(); harness.restore(); }
  });

  it('clears stale overlay rows when the input shrinks while the overlay stays open', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const overlayLines = [
      '⚡ xiaok 想要执行以下操作',
      '工具: bash',
      '命令: cmd /c echo E2E_PERMISSION_OK',
      '❯ 允许一次',
      '  本次会话始终允许 bash(cmd *)',
      '  始终允许 bash(cmd *) (保存到项目)',
      '  始终允许 bash(cmd *) (保存到全局)',
      '  拒绝',
      '↑↓ 选择  Enter 确认  Esc 取消',
    ];

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: 'x'.repeat(150),
        cursor: 150,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
        overlayLines,
      });

      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
        overlayLines,
      });

      const lines = harness.screen.lines();
      expect(lines.filter((line) => line.includes('xiaok 想要执行以下操作'))).toHaveLength(1);
      expect(lines.filter((line) => line.includes('工具: bash'))).toHaveLength(1);
    } finally {
      harness.restore();
    }
  });

  it('clears stale prompt rows from the footer gap before redrawing the placeholder', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      process.stdout.write('\x1b[20;1H❯ stale prompt row');
      process.stdout.write('\x1b[21;1Hstale status row');

      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      const lines = harness.screen.lines();
      expect(lines[19]).toBe('');
      expect(lines[20]).toBe('');
      expect(lines[21]).toContain('❯ Type your message...');
      expect(lines[20]).not.toContain('stale prompt row');
      expect(lines[21]).not.toContain('stale prompt row');
      expect(lines[20]).not.toContain('stale status row');
    } finally {
      harness.restore();
    }
  });

  it('clears permission overlay rows before transcript output resumes', () => {
    const harness = createTtyHarness(120, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.setWelcomeRows(8);
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      manager.renderPromptFrame({
        inputValue: '',
        cursor: 0,
        placeholder: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
        overlayLines: [
          '⚡ xiaok 想要执行以下操作',
          '工具: bash',
          '命令: cmd /c echo E2E_PERMISSION_OK',
          '❯ 允许一次',
          '  本次会话始终允许 bash(cmd *)',
          '  始终允许 bash(cmd *) (保存到项目)',
          '  始终允许 bash(cmd *) (保存到全局)',
          '  拒绝',
          '↑↓ 选择  Enter 确认  Esc 取消',
        ],
      });

      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });
      manager.setContentCursor(9);
      manager.writeAtContentCursor('E2E_PERMISSION_RESPONSE_ONE');

      const lines = harness.screen.lines();
      expect(lines.some((line) => line.includes('E2E_PERMISSION_RESPONSE_ONE'))).toBe(true);
      expect(lines.some((line) => line.includes('xiaok 想要执行以下操作'))).toBe(false);
      expect(lines.some((line) => line.includes('工具: bash'))).toBe(false);
      expect(lines.some((line) => line.includes('↑↓ 选择  Enter 确认  Esc 取消'))).toBe(false);
    } finally {
      harness.restore();
    }
  });

  it('re-anchors the footer after out-of-band transcript writes', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'Customer proposal',
      stageOrder: 0,
      totalStages: 1,
      stageLabel: 'Collect',
      status: 'Drafting Plan',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine,
        statusLine: 'gpt-5.4 · 5% · master · xiaok-cli',
      });

      manager.writeAtContentCursor('\n[background] job_1 completed: background worker finished\n');

      const lines = harness.screen.lines();
      const backgroundIndex = lines.findIndex((line) => line.includes('[background] job_1 completed'));
      const summaryRows = lines.filter((line) => line.includes('Intent: Customer proposal'));
      const promptRows = lines.filter((line) => line.includes('❯ Type your message...'));
      const statusRows = lines.filter((line) => line.includes('gpt-5.4 · 5% · master · xiaok-cli'));

      expect(backgroundIndex).toBeGreaterThanOrEqual(0);
      expect(summaryRows).toHaveLength(1);
      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
    } finally {
      harness.restore();
    }
  });

  it('pushes the transcript tail up when a new summary row shrinks the footer gap', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'Customer proposal',
      stageOrder: 0,
      totalStages: 1,
      stageLabel: 'Collect',
      status: 'Drafting Plan',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-5.4 · 5% · master · xiaok-cli',
      });

      manager.setContentCursor(manager.maxContentRows);
      manager.writeAtContentCursor('TAIL_LINE');

      manager.renderFooter({
        inputPrompt: ' ',
        summaryLine,
        statusLine: 'gpt-5.4 · 5% · master · xiaok-cli',
      });

      const lines = harness.screen.lines();
      const tailIndex = lines.findIndex((line) => line.includes('TAIL_LINE'));
      const summaryIndex = lines.findIndex((line) => line.includes('Intent: Customer proposal'));
      const promptIndex = lines.findIndex((line) => line.includes('❯'));
      const statusIndex = lines.findIndex((line) => line.includes('gpt-5.4 · 5% · master · xiaok-cli'));

      expect(tailIndex).toBeGreaterThanOrEqual(0);
      expect(summaryIndex).toBe(promptIndex - 3);
      expect(tailIndex).toBeLessThan(summaryIndex);
      expect(lines[summaryIndex - 1]).toBe('');
      expect(lines[summaryIndex + 1]).toBe('');
      expect(lines[summaryIndex + 2]).toBe('');
      expect(statusIndex).toBe(promptIndex + 2);
    } finally {
      harness.restore();
    }
  });

  it('keeps agent questions visible above the restored footer', () => {
    const harness = createTtyHarness(100, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const summaryLine = formatCurrentTurnIntentSummaryLine({
      deliverable: 'Customer proposal',
      stageOrder: 0,
      totalStages: 1,
      stageLabel: 'Collect',
      status: 'Drafting Plan',
    });

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine,
        statusLine: 'test-model · auto · 0% · project',
      });

      manager.writeAtContentCursor('\nAgent question: 确认目标？\n');

      const lines = harness.screen.lines();
      const questionIndex = lines.findIndex((line) => line.includes('Agent question: 确认目标？'));
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const statusIndex = lines.findIndex((line) => line.includes('test-model · auto · 0% · project'));

      expect(questionIndex).toBeGreaterThanOrEqual(0);
      expect(promptIndex).toBeGreaterThan(questionIndex);
      expect(statusIndex).toBeGreaterThan(promptIndex);
    } finally {
      harness.restore();
    }
  });
});

describe('ANSI compatibility', () => {
  it('footer rendering uses absolute positioning to place at terminal bottom', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderActivity('⠋ Thinking');
    manager.renderFooter({ inputPrompt: 'Type...', statusLine: 'gpt-5.4' });

    const output = getOutput();
    // Footer uses absolute cursor positioning (\x1b[row;colH) to ensure
    // it renders at exact terminal bottom rows regardless of cursor state.
    expect(output).toMatch(/\x1b\[21;1H\x1b\[48;5;238m\x1b\[K\x1b\[0m/);  // padded background row above the prompt
    expect(output).toMatch(/\x1b\[22;1H/);  // input bar at row 22
    expect(output).toMatch(/\x1b\[24;1H/);  // status bar at row 24
    expect(output).toContain('Type...');
    expect(output).toContain('gpt-5.4');
  });

  it('positions the cursor after restoring the scroll region', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderFooter({ inputPrompt: 'Type...', statusLine: 'gpt-5.4' });

    const output = getOutput();
    expect(output).toMatch(/\x1b\[1;17r\x1b\[22;3H$/);
  });

  it('does not leave the input background SGR active after footer rendering', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderInput('abc', 3);

    const output = getOutput();
    expect(output).toMatch(/\x1b\[0m\x1b\[24;1H\x1b\[2K(?:\x1b\[2m.*?\x1b\[0m)?\x1b\[1;17r\x1b\[22;6H$/);
    expect(output).not.toMatch(/\x1b\[23;6H\x1b\[48;5;244m$/);
  });

  it('uses a darker footer background for input contrast', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderInput('abc', 3);

    const output = getOutput();
    expect(output).toContain('\x1b[48;5;238m');
    expect(output).not.toContain('\x1b[48;5;244m');
  });

  it('truncates an overlong status line so the footer still occupies a single terminal row', () => {
    const harness = createTtyHarness(40, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const longStatusLine = 'kimi-for-coding · auto · master · 37% · xiaok-cli';

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: longStatusLine,
      });

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes('❯'));
      const statusIndex = lines.findIndex((line) => line.includes('kimi-for-coding'));

      expect(promptIndex).toBe(21);
      expect(statusIndex).toBe(23);
      expect(lines[21]).toContain('❯ Type your message...');
      expect(lines[23]).toContain('kimi-for-coding');
      expect(lines[23]).not.toContain('xiaok-cli');
    } finally {
      harness.restore();
    }
  });

  it('expands multiline prompt input while keeping a single status line', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      for (const inputValue of ['1', '1\n2', '1\n2\n3', '1\n2\n3\n4']) {
        manager.renderPromptFrame({
          inputValue,
          cursor: inputValue.length,
          placeholder: 'Type your message...',
          statusLine: 'gpt-5.4 · 5% · master · xiaok-cli',
        });
      }

      const lines = harness.screen.lines();
      const promptLines = lines.filter((line) => line.includes('❯'));
      const inputLines = lines.filter((line) => /^[\s]*[234]$/.test(line)).map((line) => line.trim());
      const statusLines = lines.filter((line) => line.includes('gpt-5.4 · 5% · master · xiaok-cli'));

      expect(promptLines).toHaveLength(1);
      expect(promptLines[0]).toContain('1');
      expect(inputLines).toEqual(['2', '3', '4']);
      expect(statusLines).toHaveLength(1);
    } finally {
      harness.restore();
    }
  });

  it('soft-wraps long single-line footer input instead of truncating it horizontally', () => {
    const harness = createTtyHarness(20, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      const inputValue = '0123456789abcdefghijk';

      manager.begin();
      manager.renderPromptFrame({
        inputValue,
        cursor: inputValue.length,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
      });

      const lines = harness.screen.lines();
      const renderedFooter = lines.join('\n');
      const statusLines = lines.filter((line) => line.includes('gpt-5.4 · 5%'));

      expect(renderedFooter).toContain('❯ 0123456789');
      expect(renderedFooter).toContain('ijk');
      expect(statusLines).toHaveLength(1);
      expect(harness.output.raw).toMatch(/\x1b\[22;6H$/);
    } finally {
      harness.restore();
    }
  });

  it('activity line uses absolute row positioning inside the scroll region', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderActivity('⠋ Thinking');
    manager.renderActivity('⠙ Content');

    const output = getOutput();
    expect(output).toContain('\x1b[19;1H');
    expect(output).toContain('⠋ Thinking');
    expect(output).toContain('⠙ Content');
  });

  it('activity line renders when footer is visible', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderFooter({ inputPrompt: 'Type...', statusLine: 'gpt-5.4' });
    manager.renderActivity('⠋ Thinking');
    const output = getOutput();
    expect(output).toContain('⠋ Thinking');
    expect(output).toContain('\x1b[19;1H');
  });

  it('repositions the real terminal cursor back to the footer after rendering activity', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderFooter({ inputPrompt: 'Type...', statusLine: 'gpt-5.4' });

    const before = getOutput().length;
    manager.renderActivity('⠋ Thinking');
    const delta = getOutput().slice(before);

    expect(delta).toContain('\x1b[19;1H');
    expect(delta).toContain('\x1b[22;3H');
    expect(delta.lastIndexOf('\x1b[22;3H')).toBeGreaterThan(delta.indexOf('\x1b[19;1H'));
  });

    it('renders activity above the input footer with two blank gap rows', () => {
      const harness = createTtyHarness(80, 24);
      const manager = new ScrollRegionManager(process.stdout);

      try {
      manager.begin();
      manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'gpt-5.4 · 5%' });
        manager.renderActivity('⠋ Thinking');

        const lines = harness.screen.lines();
      expect(lines[17]).toBe('');
      expect(lines[18]).toContain('Thinking');
      expect(lines[19]).toBe('');
      expect(lines[20]).toBe('');
      expect(lines[21]).not.toContain('Thinking');
      expect(lines[21]).not.toContain('working');
      expect(lines[21]).toContain('❯ Type your message...');
      expect(lines[23]).toContain('gpt-5.4 · 5%');
    } finally {
      harness.restore();
    }
  });

  it('re-renders the cached footer when activity updates after footer visibility state was lost', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: ' ',
        statusLine: 'gpt-5.4 · 5% · project',
      });

      (manager as unknown as { _footerVisible: boolean })._footerVisible = false;
      manager.renderActivity('⠋ Working · 11s');

      const lines = harness.screen.lines();
      const activityIndex = lines.findIndex((line) => line.includes('Working · 11s'));
      const promptIndex = lines.findIndex((line) => line.includes('❯'));
      expect(activityIndex).toBeGreaterThanOrEqual(0);
      expect(activityIndex).toBeLessThan(promptIndex);
      expect(lines[21]).toContain('❯');
      expect(lines[23]).toContain('gpt-5.4 · 5% · project');
    } finally {
      harness.restore();
    }
  });

  it('keeps the prompt and status pinned to the final two rows while activity keeps refreshing', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: ' ',
        summaryLine: '● Intent: md -> 报告 · Stage 1/2 提取 Markdown · Working',
        statusLine: 'gpt-5.4 · 5% · project',
      });

      manager.renderActivity('⠋ Exploring codebase · 2s');
      manager.renderActivity('⠙ Running command · 4s');
      manager.renderActivity('⠹ Working · 11s');

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes('❯'));
      const statusIndex = lines.findIndex((line) => line.includes('gpt-5.4 · 5% · project'));
      const summaryIndex = lines.findIndex((line) => line.includes('Intent: md -> 报告'));
      const activityIndex = lines.findIndex((line) => line.includes('Working · 11s'));

      expect(promptIndex).toBe(21);
      expect(statusIndex).toBe(23);
      expect(summaryIndex).toBe(promptIndex - 3);
      expect(lines.slice(summaryIndex + 1, promptIndex).filter((line) => line === '')).toHaveLength(2);
      expect(activityIndex).toBeLessThan(summaryIndex);
    } finally {
      harness.restore();
    }
  });

  it('keeps blank gap above the input after a flushed wrapped markdown list tail', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const renderer = new MarkdownRenderer();
    const response = [
      '- 报告：金蝶灵基_for_CEO_V2.0，包含 KPI 概览、里程碑时间线、组织能力地图',
      '- 幻灯片：金蝶灵基_for_CEO_V2.0，瑞士现代风格（Swiss Modern）',
    ].join('\n');

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'kimi-for-coding · 29% · master',
      });
      manager.setContentCursor(manager.maxContentRows);
      manager.beginContentStreaming();
      renderer.setNewlineCallback(manager.getNewlineCallback());
      renderer.write(response);
      const flushResult = renderer.flush();
      manager.syncContentCursorFromRenderedLines(MarkdownRenderer.renderToLines(response));
      expect(flushResult.renderedLine).toContain('\n');
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'kimi-for-coding · 29% · master',
      });

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const lastContentIndex = Math.max(
        lines.findIndex((line) => line.includes('报告：金蝶灵基')),
        lines.findIndex((line) => line.includes('瑞士现代风格')),
        lines.findIndex((line) => line.includes('Swiss Modern')),
      );

      expect(promptIndex).toBe(21);
      expect(lastContentIndex).toBeGreaterThanOrEqual(0);
      expect(lines.slice(lastContentIndex + 1, promptIndex).filter((line) => line === '').length).toBeGreaterThanOrEqual(2);
      expect(lines[23]).toContain('kimi-for-coding · 29% · master');
    } finally {
      renderer.reset();
      harness.restore();
    }
  });

  it('keeps blank gap above the input after a final plain Chinese paragraph following bullets', () => {
    const harness = createTtyHarness(40, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const renderer = new MarkdownRenderer();
    const response = [
      '- 报告：金蝶灵基-V1.9-研发计划报告.html',
      '- 幻灯片：金蝶灵基-V1.9-研发计划演示.html',
      '',
      '两个文件均为零依赖，可直接浏览器打开查看；幻灯片按 F5 进入演讲模式。',
    ].join('\n');

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'kimi-for-coding · 18% · master',
      });
      manager.setContentCursor(manager.maxContentRows);
      manager.beginContentStreaming();
      renderer.setNewlineCallback(manager.getNewlineCallback());
      renderer.write(response);
      renderer.flush();
      manager.syncContentCursorFromRenderedLines(MarkdownRenderer.renderToLines(response));
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'kimi-for-coding · 18% · master',
      });

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const finalParagraphIndex = lines.findIndex((line) => line.includes('两个文件均为零依赖'));

      expect(promptIndex).toBeGreaterThan(finalParagraphIndex);
      expect(finalParagraphIndex).toBeGreaterThanOrEqual(0);
      expect(lines.slice(finalParagraphIndex + 1, promptIndex).filter((line) => line === '').length).toBeGreaterThanOrEqual(2);
      expect(lines[23]).toContain('kimi-for-coding');
    } finally {
      renderer.reset();
      harness.restore();
    }
  });

  it('counts embedded newlines from markdown-wrapped rendered lines when syncing the content cursor', () => {
    const { manager } = createMockScrollRegion();
    const renderedLines = [
      '• 报告：金蝶灵基_for_CEO_V2.0，包含 KPI 概览\n  里程碑时间线、组织能力地图',
      '• 幻灯片：金蝶灵基_for_CEO_V2.0，瑞士现代风格',
    ];

    manager.begin();
    manager.beginContentStreaming();
    manager.syncContentCursorFromRenderedLines(renderedLines);

    expect((manager as any)._cursorRow).toBe(3);
  });

  it('clears submitted input without putting working text in the input footer', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderPromptFrame({
        inputValue: 'hello',
        cursor: 5,
        placeholder: 'Type your message...',
        statusLine: 'gpt-5.4 · 5%',
      });

      manager.clearLastInput();

      const lines = harness.screen.lines();
      expect(lines[21]).toContain('❯ Type your message...');
      expect(lines[21]).not.toContain('working');
      expect(lines[21]).not.toContain('Thinking');
    } finally {
      harness.restore();
    }
  });

  it('footer is rendered below content', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderFooter({
      inputPrompt: 'Type...',
      statusLine: 'gpt-5.4',
    });

    const output = getOutput();
    expect(output).toContain('Type...');
    expect(output).toContain('gpt-5.4');
  });
});

describe('CJK cursor positioning in renderInput', () => {
  function createMock() {
    const mock = new PassThrough();
    const chunks: string[] = [];
    mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));
    const stream = mock as unknown as NodeJS.WriteStream;
    (stream as any).rows = 24;
    (stream as any).columns = 120;
    const manager = new ScrollRegionManager(stream);
    return { manager, getOutput: () => chunks.join('') };
  }

  function extractCursorCol(output: string): number | null {
    // Match \x1b[1;colH pattern from non-active mode rendering
    const matches = [...output.matchAll(/\x1b\[1;(\d+)H/g)];
    if (matches.length === 0) return null;
    return parseInt(matches[matches.length - 1][1], 10);
  }

  // Tests use non-active path (no begin()) where renderInput uses \x1b[1;colH
  it('empty input: cursor at col 3 (after "❯ ")', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('', 0);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(3);
  });

  it('English text: cursor at correct column', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('hello', 5);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(8);
  });

  it('Chinese text: cursor after 1 char (你) at col 5', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('你好', 1);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(5);
  });

  it('Chinese text: cursor after 2 chars (你好) at col 7', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('你好', 2);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(7);
  });

  it('mixed CJK+ASCII: cursor after 测t at col 6', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('测t', 2);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(6);
  });

  it('mixed CJK+ASCII: cursor after all 4 chars 测a试b at col 9', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('测a试b', 4);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(9);
  });

  it('mixed CJK+ASCII: cursor after 测a at col 6', () => {
    const { manager, getOutput } = createMock();
    manager.renderInput('测a试b', 2);
    const cursorCol = extractCursorCol(getOutput());
    expect(cursorCol).toBe(6);
  });
});

/**
 * Tests for bugs found during adversarial review (Bugs 8-14).
 * Bug 7 is a chat.ts integration issue, tested via E2E.
 */

describe('Bug 8: _cursorUncertain cleared in beginContentStreaming else branch', () => {
  function createMock(rows = 24, cols = 80) {
    const mock = new PassThrough();
    const chunks: string[] = [];
    mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));
    const stream = mock as unknown as NodeJS.WriteStream;
    (stream as any).rows = rows;
    (stream as any).columns = cols;
    const manager = new ScrollRegionManager(stream);
    return { manager, getOutput: () => chunks.join(''), stream };
  }

  function countNewlines(output: string): number {
    return (output.match(/\n/g) || []).length;
  }

  it('_cursorUncertain is true after clearLastInput', () => {
    const { manager } = createMock();
    manager.begin();
    manager.beginContentStreaming();
    manager.endContentStreaming();
    // Simulate second turn
    manager.clearLastInput();
    // _cursorUncertain should be true after clearLastInput
    // (internal state, but we can verify via endContentStreaming behavior)
    expect(manager.isContentStreaming()).toBe(false);
  });

  it('beginContentStreaming (2nd turn) clears _cursorUncertain', () => {
    const { manager, getOutput } = createMock();
    manager.begin();
    // First turn
    manager.beginContentStreaming();
    manager.endContentStreaming({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });

    // Clear and start second turn
    manager.clearLastInput();
    manager.writeSubmittedInput('hello');
    manager.beginContentStreaming();

    // _cursorUncertain should be false now (set in beginContentStreaming else branch)
    // Verify by checking that endContentStreaming uses cursor-based fill, not maxContentRows
    manager.writeAtContentCursor('Hi!\n'); // Short response
    const beforeEndOutput = getOutput();
    manager.endContentStreaming({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });
    const afterEndOutput = getOutput();

    // If _cursorUncertain was true, fill would be 21 newlines
    // If _cursorUncertain was false with cursorRow ~5, fill = 21 - 5 = 16 newlines
    const newlinesAdded = countNewlines(afterEndOutput) - countNewlines(beforeEndOutput);
    // With _cursorUncertain=false: fill + 1(input \n) = ~17
    // With _cursorUncertain=true: fill(21) + 1 = 22
    expect(newlinesAdded).toBeLessThan(22);
  });

  it('short response without newline: endContentStreaming does not overfill', () => {
    const { manager, getOutput } = createMock();
    manager.begin();
    manager.beginContentStreaming();
    manager.endContentStreaming({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });

    // Second turn: clear + submit short input + begin streaming
    manager.clearLastInput();
    manager.writeSubmittedInput('hi');
    manager.beginContentStreaming();
    // Simulate a very short AI response (no newline)
    manager.writeAtContentCursor('Hi!');

    const beforeEndOutput = getOutput();
    manager.endContentStreaming({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });
    const afterEndOutput = getOutput();

    const newlinesAdded = countNewlines(afterEndOutput) - countNewlines(beforeEndOutput);
    // With _cursorUncertain=false (cursorRow ~5): fill = 21 - 5 = 16 + 1 input newline = 17
    // With _cursorUncertain=true: fill = 21 + 1 = 22
    expect(newlinesAdded).toBeLessThan(22);
  });

  it('regression: beginContentStreaming always sets _cursorUncertain consistently', () => {
    // Bug 8: after clearLastInput + beginContentStreaming (first-turn branch),
    // _cursorUncertain is set to true. If no content is written before
    // endContentStreaming, fill uses maxContentRows (22) instead of cursor-based fill.
    // The fix ensures that in the else branch, _cursorUncertain is also cleared.
    // Since clearLastInput resets _hasStreamedContent, the first-turn branch is
    // always taken. This test verifies the fix indirectly by ensuring
    // writeAtContentCursor clears _cursorUncertain properly.

    const ctx = createMock();
    ctx.manager.begin();
    ctx.manager.beginContentStreaming();
    ctx.manager.endContentStreaming({ inputPrompt: 'w...', statusLine: 's' });
    ctx.manager.clearLastInput();
    // After clearLastInput, _hasStreamedContent is false.
    // beginContentStreaming enters first-turn branch, clears activity lines and sets _cursorUncertain=false.
    ctx.manager.beginContentStreaming();
    expect((ctx.manager as any)._cursorUncertain).toBe(false);
    // Writing content keeps _cursorUncertain false
    ctx.manager.writeAtContentCursor('Hi!\n');
    expect((ctx.manager as any)._cursorUncertain).toBe(false);
  });
});

describe('Bug 9: CJK cursor wrap at column boundary', () => {
  function createMock(cols = 80) {
    const mock = new PassThrough();
    const chunks: string[] = [];
    mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));
    const stream = mock as unknown as NodeJS.WriteStream;
    (stream as any).rows = 24;
    (stream as any).columns = cols;
    const manager = new ScrollRegionManager(stream);
    return { manager, getOutput: () => chunks.join('') };
  }

  it('CJK character at col 78 (cols-2) on 80-col terminal should wrap', () => {
    const { manager } = createMock(80);
    manager.begin();

    // Write 78 spaces to get to col 78
    manager.writeAtContentCursor(' '.repeat(78));
    // Now write a CJK character (width 2)
    manager.writeAtContentCursor('测');

    // col 78 + 2 >= 80 → wrap. CJK char can't fit in 1 col remaining,
    // so it goes on new row at col 2.
    expect((manager as any)._cursorCol).toBe(2);
    expect((manager as any)._cursorRow).toBe(2);
  });

  it('CJK character exactly filling remaining row wraps correctly', () => {
    const { manager } = createMock(80);
    manager.begin();

    // Write 80 spaces to fill the row. The 80th space triggers wrap
    // (col 79 + 1 >= 80), then next char starts on new row at col 1.
    manager.writeAtContentCursor(' '.repeat(80));
    expect((manager as any)._cursorCol).toBe(1);
    expect((manager as any)._cursorRow).toBe(2);
  });

  it('CJK character at col 79 on 80-col terminal wraps', () => {
    const { manager } = createMock(80);
    manager.begin();

    // Write 79 spaces
    manager.writeAtContentCursor(' '.repeat(79));
    // Write a CJK char (width 2) — should wrap since 79 + 2 >= 80
    manager.writeAtContentCursor('测');

    // After wrapping: col 2 (CJK width on new row), row 2 (wrap)
    expect((manager as any)._cursorCol).toBe(2);
    expect((manager as any)._cursorRow).toBe(2);
  });

  it('ASCII character at col 79 on 80-col terminal: fills last column, next char starts on new row', () => {
    const { manager } = createMock(80);
    manager.begin();

    manager.writeAtContentCursor(' '.repeat(79));
    manager.writeAtContentCursor('a');

    // 'a' at col 79: 79+1 >= 80 → wrap. col = 1, _cursorRow increments by 1.
    // After fix: col = 1 (next char position), _cursorRow = 2 (wrapped to next row)
    expect((manager as any)._cursorRow).toBe(2);
    expect((manager as any)._cursorCol).toBe(1);
  });
});

describe('Bug 10: Content exceeding maxContentRows', () => {
  function createMock(rows = 24, cols = 80) {
    const mock = new PassThrough();
    const chunks: string[] = [];
    mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));
    const stream = mock as unknown as NodeJS.WriteStream;
    (stream as any).rows = rows;
    (stream as any).columns = cols;
    const manager = new ScrollRegionManager(stream);
    return { manager, getOutput: () => chunks.join('') };
  }

  function countNewlines(output: string): number {
    return (output.match(/\n/g) || []).length;
  }

  it('endContentStreaming clamps cursorRow for fill when content exceeds maxContentRows', () => {
    const { manager, getOutput } = createMock(24, 80);
    manager.begin();
    manager.beginContentStreaming();

    // Simulate content that exceeds maxContentRows (22)
    // Write 30 newlines worth of content
    for (let i = 0; i < 30; i++) {
      manager.writeAtContentCursor(`line ${i}\n`);
    }

    // _cursorRow is now > maxContentRows (clamped or not)
    const cursorRow = (manager as any)._cursorRow;

    manager.endContentStreaming({ inputPrompt: 'waiting...', statusLine: 'gpt-5.4' });
    const output = getOutput();

    // The fill newlines should bring us to maxContentRows, not beyond
    // If _cursorRow was clamped to maxContentRows in fill calculation,
    // fill would be 0 (since effectiveRow = min(30+, 22) = 22, fill = 22 - 22 = 0)
    // Footer renders right after content
    const footerIdx = output.indexOf('waiting...');
    expect(footerIdx).toBeGreaterThan(-1);
  });

  it('footer always renders at terminal bottom for long content', () => {
    const { manager, getOutput } = createMock(24, 80);
    manager.begin();
    manager.beginContentStreaming();

    // Write enough content to definitely overflow
    const longContent = 'x'.repeat(80);
    for (let i = 0; i < 30; i++) {
      manager.writeAtContentCursor(longContent + '\n');
    }

    manager.endContentStreaming({ inputPrompt: 'INPUT_PROMPT', statusLine: 'STATUS_LINE' });
    const output = getOutput();

    // Footer should be present
    expect(output).toContain('INPUT_PROMPT');
    expect(output).toContain('STATUS_LINE');
  });

  it('raw stdout progress notes do not dislodge the fixed footer after activity is cleared at the transcript boundary', () => {
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-5.4 · 5% · project',
      });

      for (let index = 0; index < 12; index += 1) {
        manager.writeAtContentCursor(`Ran printf "/Users/song/.xiaok/skills/kai-report-creator/path-${index}"\n`);
      }

      manager.renderActivity('⠋ Waiting for command output · 46s');
      manager.clearActivity();
      process.stdout.write(formatProgressNote('Goal 已完成。'));

      const lines = harness.screen.lines();
      const promptRows = lines.filter((line) => line.includes('❯'));
      const statusRows = lines.filter((line) => line.includes('project') && line.includes('%'));
      const activityRows = lines.filter((line) => line.includes('Waiting for command output'));

      expect(promptRows).toHaveLength(1);
      expect(statusRows).toHaveLength(1);
      expect(activityRows).toHaveLength(0);
      expect(lines[21]).toContain('❯');
      expect(lines[23]).toContain('project');
    } finally {
      harness.restore();
    }
  });

  it('clearContentArea resets the scroll region content without touching the footer rows', () => {
    const { manager, getOutput } = createMock(24, 80);
    manager.begin();
    manager.setWelcomeRows(12);
    manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'STATUS_LINE' });

    manager.clearContentArea();
    manager.writeSubmittedInput('› hello\n');
    manager.endContentStreaming({ inputPrompt: 'Type your message...', statusLine: 'STATUS_LINE' });

    const output = getOutput();
    expect(output).toContain('› hello');
    expect(output).toContain('STATUS_LINE');
    expect((manager as any)._cursorRow).toBeGreaterThanOrEqual(1);
    expect((manager as any)._welcomeRows).toBe(0);
  });
});

describe('Bug 11: Terminal resize handling', () => {
  function createMock(rows = 24, cols = 80) {
    const mock = new PassThrough();
    const chunks: string[] = [];
    mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));
    const stream = mock as unknown as NodeJS.WriteStream;
    (stream as any).rows = rows;
    (stream as any).columns = cols;
    const manager = new ScrollRegionManager(stream);
    return { manager, getOutput: () => chunks.join('') };
  }

  it('updateSize changes maxContentRows', () => {
    const { manager } = createMock(24, 80);
    // Before: 3 gap rows + padded input footer keep the scroll region bottom at row 17
    expect((manager as any).maxContentRows).toBe(17);

    manager.updateSize(30, 100);
    // After resize the same chrome leaves the scroll region bottom at row 23
    expect((manager as any).maxContentRows).toBe(23);
  });

  it('updateSize changes columns for wrap calculation', () => {
    const { manager } = createMock(24, 80);
    manager.begin();

    // 90 characters on an 80-col terminal wrap onto a second row.
    manager.writeAtContentCursor('x'.repeat(90));
    expect((manager as any)._cursorRow).toBe(2);

    // The same text fits on one row once the terminal is 100 columns wide.
    const { manager: manager2 } = createMock(24, 100);
    manager2.begin();
    manager2.writeAtContentCursor('x'.repeat(90));
    expect((manager2 as any)._cursorRow).toBe(1);
  });

  it('clears the old footer rows when a Mac terminal resize moves the footer down', () => {
    const harness = createTtyHarness(80, 30);
    const manager = new ScrollRegionManager(process.stdout, {
      footerHeight: 2,
      gapHeight: 2,
      rows: 24,
      columns: 80,
    });

    try {
      manager.begin();
      manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'gpt-5.4 · 6% · master' });

      manager.updateSize(30, 80);

      const lines = harness.screen.lines();
      expect(lines[22]).not.toContain('Type your message...');
      expect(lines[23]).not.toContain('gpt-5.4');
      expect(lines[27]).toContain('❯ Type your message...');
      expect(lines[29]).toContain('gpt-5.4 · 6% · master');
    } finally {
      harness.restore();
    }
  });
});

describe('updateStatusLine respects _contentStreaming guard', () => {
  function createMock() {
    const mock = new PassThrough();
    const chunks: string[] = [];
    mock.on('data', (chunk: Buffer) => chunks.push(chunk.toString()));
    const stream = mock as unknown as NodeJS.WriteStream;
    (stream as any).rows = 24;
    (stream as any).columns = 80;
    const manager = new ScrollRegionManager(stream);
    return { manager, getOutput: () => chunks.join('') };
  }

  it('updateStatusLine caches the footer status without writing during streaming', () => {
    const { manager, getOutput } = createMock();
    manager.begin();
    manager.beginContentStreaming();
    manager.writeAtContentCursor('content\n');

    manager.updateStatusLine('new status');

    const output = getOutput();
    expect((manager as any).lastStatusLine).toBe('new status');
    expect(output).not.toContain('new status');
    expect(output).not.toContain('\x1b[s');
    expect(output).not.toContain('\x1b[u');
  });

  it('updateStatusLine works when not streaming', () => {
    const { manager, getOutput } = createMock();
    manager.begin();
    manager.renderFooter({ inputPrompt: 'waiting...', statusLine: 'old status' });

    manager.updateStatusLine('new status');

    const output = getOutput();
    expect(output).toContain('new status');
  });
});

describe('streaming cursor handoff', () => {
  beforeEach(() => {
    setColorsEnabled(false);
  });

  afterEach(() => {
    setColorsEnabled(true);
  });

  it('keeps streamed output above the fixed footer after a submitted input block', () => {
    const harness = createTtyHarness(120, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const markdown = new MarkdownRenderer();

    try {
      manager.begin();
      manager.setWelcomeRows(12);
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'claude-test · auto · 0% · xiaok-cli',
      });

      manager.clearLastInput();
      manager.writeSubmittedInput(formatSubmittedInput('分三次显示123'));

      markdown.setNewlineCallback(manager.getNewlineCallback());
      manager.beginContentStreaming();
      markdown.write('1\n2\n3');
      markdown.flush();
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'claude-test · auto · 0% · xiaok-cli',
      });

      const lines = harness.screen.lines();
      const submittedIndex = lines.findIndex((line) => line.includes('› 分三次显示123'));
      const line1Index = lines.findIndex((line) => {
        const trimmed = line.trim();
        return trimmed === '1' || trimmed === '● 1';
      });
      const line2Index = lines.findIndex((line) => line.trim() === '2');
      const line3Index = lines.findIndex((line) => line.trim() === '3');
      const promptIndex = lines.findIndex((line) => line.includes('❯ Type your message...'));
      const statusIndex = lines.findIndex((line) => line.includes('claude-test') && line.includes('auto'));

      expect(submittedIndex).toBeGreaterThanOrEqual(0);
      expect(line1Index).toBeGreaterThan(submittedIndex + 1);
      expect(lines[line1Index - 1]).toBe('');
      expect(line2Index).toBeGreaterThan(line1Index);
      expect(line3Index).toBeGreaterThan(line2Index);
      expect(promptIndex).toBeGreaterThan(line3Index);
      expect(statusIndex).toBeGreaterThan(promptIndex);
    } finally {
      harness.restore();
    }
  });

  it('keeps a flushed single-line assistant reply visible when the next submitted input is written', () => {
    const harness = createTtyHarness(120, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const markdown = new MarkdownRenderer();

    try {
      manager.begin();
      manager.setWelcomeRows(12);
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'claude-test · auto · 0% · xiaok-cli',
      });

      manager.clearLastInput();
      manager.writeSubmittedInput(formatSubmittedInput('first question'));

      markdown.setNewlineCallback(manager.getNewlineCallback());
      manager.beginContentStreaming();
      markdown.write('FIRST_REPLY');
      const flushResult = markdown.flush();
      manager.advanceContentCursorByRenderedText(flushResult.renderedLine);
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'claude-test · auto · 0% · xiaok-cli',
      });

      manager.clearLastInput();
      manager.writeSubmittedInput(formatSubmittedInput('second question'));

      const lines = harness.screen.lines();
      const firstReplyIndex = lines.findIndex((line) => line.includes('FIRST_REPLY'));
      const secondQuestionIndex = lines.findIndex((line) => line.includes('› second question'));

      expect(firstReplyIndex).toBeGreaterThanOrEqual(0);
      expect(secondQuestionIndex).toBeGreaterThan(firstReplyIndex);
    } finally {
      harness.restore();
    }
  });

  it('preserves the first response tail across a second turn in a 24-row tmux-style layout', () => {
    const harness = createTtyHarness(120, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const markdown = new MarkdownRenderer();
    const firstResponse = [
      '适合中午的：',
      '',
      '- 快餐：鸡腿饭',
      '- 面食：拉面',
      '- 轻食：三明治',
      '',
      '想吃点重口还是清淡的？',
    ].join('\n');
    const secondResponse = [
      '辣的午餐：',
      '',
      '- 川菜：麻婆豆腐饭',
      '- 小吃：麻辣烫',
    ].join('\n');

    try {
      manager.begin();
      manager.setWelcomeRows(14);
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      manager.clearLastInput();
      manager.writeSubmittedInput(formatSubmittedInput('first terminal request'));
      markdown.setNewlineCallback(manager.getNewlineCallback());
      manager.beginContentStreaming();
      markdown.write(firstResponse);
      const firstFlush = markdown.flush();
      manager.advanceContentCursorByRenderedText(firstFlush.renderedLine);
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      markdown.reset();
      manager.clearLastInput();
      manager.writeSubmittedInput(formatSubmittedInput('second terminal request'));
      markdown.setNewlineCallback(manager.getNewlineCallback());
      manager.beginContentStreaming();
      markdown.write(secondResponse);
      const secondFlush = markdown.flush();
      manager.advanceContentCursorByRenderedText(secondFlush.renderedLine);
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      const lines = harness.screen.lines();
      const firstTailIndex = lines.findIndex((line) => line.includes('想吃点重口还是清淡的？'));
      const secondHeadIndex = lines.findIndex((line) => line.includes('辣的午餐：'));

      expect(firstTailIndex).toBeGreaterThanOrEqual(0);
      expect(secondHeadIndex).toBeGreaterThan(firstTailIndex);
    } finally {
      harness.restore();
    }
  });

  it('keeps activity closest to the prompt when a third turn enters busy state in Windows tmux layout', () => {
    const previousTmux = process.env.TMUX;
    const harness = createTtyHarness(120, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const markdown = new MarkdownRenderer();
    const promptGlyph = process.platform === 'win32' ? '>' : '❯';
    const firstResponse = [
      '适合中午的：',
      '',
      '- 快餐：鸡腿饭',
      '- 面食：拉面',
      '- 轻食：三明治',
      '',
      '想吃点重口还是清淡的？',
    ].join('\n');
    const secondResponse = [
      '辣的午餐：',
      '',
      '- 川菜：麻婆豆腐饭',
      '- 小吃：麻辣烫',
    ].join('\n');

    const writeTurn = (input: string, response: string) => {
      manager.clearLastInput({ inputPrompt: 'Type your message...' });
      manager.writeSubmittedInput(formatSubmittedInput(input));
      markdown.reset();
      markdown.setNewlineCallback(manager.getNewlineCallback());
      manager.beginContentStreaming();
      markdown.write(response);
      const flushResult = markdown.flush();
      manager.advanceContentCursorByRenderedText(flushResult.renderedLine);
      manager.endContentStreaming({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });
    };

    try {
      process.env.TMUX = 'tmux-test,1,0';
      manager.begin();
      manager.setWelcomeRows(14);
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        statusLine: 'gpt-terminal-e2e · auto · 0% · project',
      });

      writeTurn('first terminal request', firstResponse);
      writeTurn('second terminal request', secondResponse);

      manager.clearLastInput({ inputPrompt: 'Type your message...' });
      manager.writeSubmittedInput(formatSubmittedInput('queued slow first turn'));
      manager.clearLastInput({ inputPrompt: 'Finishing response...' });
      manager.renderActivity('⠋ Thinking · 1s');

      const lines = harness.screen.lines();
      const promptIndex = lines.findIndex((line) => line.includes(`${promptGlyph} Finishing response...`));
      expect(promptIndex).toBeGreaterThanOrEqual(0);

      let cursor = promptIndex - 1;
      while (cursor >= 0 && lines[cursor].trim() === '') {
        cursor -= 1;
      }
      expect(lines[cursor]).toContain('Thinking · 1s');
      expect(lines.slice(cursor + 1, promptIndex).filter((line) => line === '').length).toBeGreaterThanOrEqual(2);
    } finally {
      if (previousTmux === undefined) {
        delete process.env.TMUX;
      } else {
        process.env.TMUX = previousTmux;
      }
      harness.restore();
    }
  });

  it('clears wrapped intent summary chrome before writing non-streaming transcript blocks in Windows tmux layout', () => {
    const previousTmux = process.env.TMUX;
    const harness = createTtyHarness(60, 24);
    const manager = new ScrollRegionManager(process.stdout);
    const markdown = new MarkdownRenderer();
    const workingSummary = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 0,
      totalStages: 2,
      stageLabel: '提取 Markdown',
      status: 'Working',
    });
    const completedSummary = formatCurrentTurnIntentSummaryLine({
      deliverable: 'md -> 报告',
      stageOrder: 1,
      totalStages: 2,
      stageLabel: '生成报告',
      status: 'Completed',
    });
    const stageSummaryBlock = formatIntentStageSummaryTranscriptBlock({
      deliverable: 'md -> 报告',
      stages: [
        { order: 0, totalStages: 2, label: '提取 Markdown', status: 'Completed' },
        { order: 1, totalStages: 2, label: '生成报告', status: 'Completed' },
      ],
    });

    try {
      process.env.TMUX = 'tmux-test,1,0';
      manager.begin();
      manager.setWelcomeRows(14);
      manager.renderFooter({
        inputPrompt: 'Finishing response...',
        summaryLine: workingSummary,
        statusLine: 'gpt-terminal-e2e · 5% · project',
      });
      manager.renderActivity('⠋ Exploring codebase · 1s');

      manager.writeAtContentCursor('\n  ╭─ Explored\n  │ Read 01-market-overview.md\n');
      markdown.setNewlineCallback(manager.getNewlineCallback());
      manager.beginContentStreaming();
      markdown.write('三份文档已先合并为 Markdown，再生成报告。');
      const flushResult = markdown.flush();
      manager.advanceContentCursorByRenderedText(flushResult.renderedLine);
      manager.endContentStreaming({
        inputPrompt: 'Finishing response...',
        summaryLine: workingSummary,
        statusLine: 'gpt-terminal-e2e · 0% · project',
      });
      manager.writeAtContentCursor(`\n${stageSummaryBlock}`);
      manager.renderFooter({
        inputPrompt: 'Type your message...',
        summaryLine: completedSummary,
        statusLine: 'gpt-terminal-e2e · 0% · project',
      });

      const lines = harness.screen.lines();
      const summaryRows = lines.filter((line) => line.includes('Intent: md -> 报告'));
      const staleWorkingRows = lines.filter((line) => line.includes('Stage 1/2 提取 Markdown') && line.includes('Working'));
      const stageRowsWithIntent = lines.filter((line) => line.includes('│ Stage') && line.includes('Intent:'));

      expect(summaryRows).toHaveLength(1);
      expect(staleWorkingRows).toHaveLength(0);
      expect(stageRowsWithIntent).toHaveLength(0);
      expect(lines.some((line) => line.includes('三份文档已先合并为 Markdown，再生成报告。'))).toBe(true);
      expect(lines.some((line) => line.includes('│ Stage 2/2 生成报告 · Completed'))).toBe(true);
    } finally {
      if (previousTmux === undefined) {
        delete process.env.TMUX;
      } else {
        process.env.TMUX = previousTmux;
      }
      harness.restore();
    }
  });

  it('moves the real terminal cursor back to the content tail before inserting separator newlines', () => {
    const { manager, getOutput } = createMockScrollRegion();
    const markdown = new MarkdownRenderer();

    manager.begin();
    manager.setWelcomeRows(12);
    manager.renderFooter({
      inputPrompt: 'Type your message...',
      statusLine: 'claude-test · auto · 0% · xiaok-cli',
    });

    manager.clearLastInput();
    manager.writeSubmittedInput(formatSubmittedInput('first question'));

    markdown.setNewlineCallback(manager.getNewlineCallback());
    manager.beginContentStreaming();
    markdown.write('line 1\nline 2\nTAIL_LINE');
    const flushResult = markdown.flush();
    manager.advanceContentCursorByRenderedText(flushResult.renderedLine);
    manager.endContentStreaming({
      inputPrompt: 'Type your message...',
      statusLine: 'claude-test · auto · 0% · xiaok-cli',
    });

    const contentRow = (manager as any)._cursorRow as number;
    const contentCol = (manager as any)._cursorCol as number;
    const before = getOutput().length;

    manager.clearLastInput();
    manager.writeSubmittedInput(formatSubmittedInput('second question'));

    const delta = getOutput().slice(before);
    const moveToContentCursor = `\x1b[${contentRow};1H`;
    const moveToContentColumn = `\x1b[${contentCol + 1}G`;

    expect(contentCol).toBeGreaterThan(0);
    expect(delta.indexOf(moveToContentCursor)).toBeGreaterThanOrEqual(0);
    expect(delta.indexOf(moveToContentColumn)).toBeGreaterThan(delta.indexOf(moveToContentCursor));
    expect(delta.indexOf('\n')).toBeGreaterThan(delta.indexOf(moveToContentColumn));
  });

  it('re-anchors the footer after writing a long submitted input block against a visible footer', () => {
    const { manager, getOutput } = createMockScrollRegion({ rows: 24, columns: 60 });
    const statusLine = 'gpt-terminal-e2e · auto · 0% · project';
    const longFollowup = '基于刚才这份报告，请补充制造业与 SaaS 的差异、风险、建议和下一步行动';

    manager.begin();
    manager.setWelcomeRows(14);
    manager.renderFooter({
      inputPrompt: 'Type your message...',
      statusLine,
    });

    manager.writeAtContentCursor([
      'line 1',
      'line 2',
      'line 3',
      'line 4',
      'line 5',
      'line 6',
      'line 7',
      'line 8',
    ].join('\n'));

    manager.clearLastInput();
    const before = getOutput().length;

    manager.writeSubmittedInput(formatSubmittedInput(longFollowup));

    const delta = getOutput().slice(before);
    const lastTranscriptWrite = delta.lastIndexOf('› 基于刚才这份报告');
    const lastStatusWrite = delta.lastIndexOf(statusLine);

    expect(lastTranscriptWrite).toBeGreaterThanOrEqual(0);
    expect(lastStatusWrite).toBeGreaterThan(lastTranscriptWrite);
  });

  it('uses visible rows instead of ANSI bytes when advancing past a submitted input block', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    manager.setWelcomeRows(14);

    manager.writeSubmittedInput(formatSubmittedInput('first terminal request'));
    manager.beginContentStreaming();

    const output = getOutput();
    expect(output).toContain('\x1b[15;1H');
    expect(output).toContain('\x1b[17;1H');
    expect(output).not.toContain('\x1b[19;1H\x1b[0m');
  });
});


describe('ScrollRegionManager external command handoff', () => {
  it('resumes the fixed footer without clearing a password prompt written while released', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'STATUS_LINE' });
      manager.end();

      process.stdout.write('[sudo] Password:');
      manager.resumeAfterExternalCommand({
        inputPrompt: 'Type your message...',
        statusLine: 'STATUS_LINE',
      });

      const screenText = harness.screen.text();
      expect(screenText).toContain('[sudo] Password:');
      expect(screenText).toContain('❯ Type your message...');
      expect(screenText).toContain('STATUS_LINE');
    } finally {
      harness.restore();
    }
  });
});


describe('ScrollRegionManager.writeRawBlock', () => {
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=', 'base64');

  it.each([1, 8, 17])('places stationary images entirely inside the content margin at cursor %s and scrolls them with later text', start => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin();
      manager.renderInput('KEEP_DRAFT', 4);
      manager.setContentCursor(Math.min(start, manager.maxContentRows));
      const bottom = manager.maxContentRows;
      manager.writeRawBlock('\x1b_Ga=T,f=100,C=1,i=42,c=10,r=4;QQ==\x1b\\', 4, { cursorStationary: true });
      const placed = harness.screen.images()[0];
      expect(placed).toBeDefined();
      expect(placed.row).toBeGreaterThanOrEqual(1);
      expect(placed.row + placed.rows - 1).toBeLessThan(bottom);
      const before = manager.getContentCursor();
      manager.writeAtContentCursor('AFTER_IMAGE\n');
      expect(manager.getContentCursor()).toBe(before + 1);
      const distanceToMargin = Math.max(0, bottom - Math.min(start + 4, bottom));
      manager.writeAtContentCursor('\n'.repeat(distanceToMargin + 1));
      const moved = harness.screen.images()[0];
      expect(!moved || moved.row < placed.row || moved.rows < placed.rows).toBe(true);
      expect(harness.screen.text()).toContain('KEEP_DRAFT');
      expect(manager.getPromptFrameState()).toMatchObject({ inputValue: 'KEEP_DRAFT', cursor: 4 });
    } finally { manager.end(); harness.restore(); }
  });

  it('retains two consecutive images within the margin instead of anchoring the second over the input', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);
    try {
      manager.begin(); manager.setContentCursor(manager.maxContentRows);
      for (const id of [11, 12]) manager.writeRawBlock(`\x1b_Ga=T,C=1,i=${id},c=10,r=3;QQ==\x1b\\`, 3, { cursorStationary: true });
      const images = harness.screen.images();
      expect(images).toHaveLength(2);
      expect(images[0].row + images[0].rows).toBe(images[1].row);
      expect(images[1].row + images[1].rows - 1).toBeLessThan(manager.maxContentRows);
      manager.writeAtContentCursor('TAIL\n');
      expect(harness.screen.images()[1].row).toBe(images[1].row - 1);
    } finally { manager.end(); harness.restore(); }
  });

  it('uses real renderer chunks without counting their payload as terminal rows', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    const rendered = renderImageLines({ data: png, mediaType: 'image/png', protocol: 'kitty', imageId: 14 });
    const before = manager.getContentCursor();
    manager.writeRawBlock(rendered.lines[0], rendered.rows, { cursorStationary: true });
    expect(manager.getContentCursor()).toBe(before + rendered.rows);
    expect(getOutput()).toContain(rendered.lines[0]);
  });

  it('rejects a stationary image taller than the available content region', () => {
    const { manager } = createMockScrollRegion(); manager.begin();
    expect(() => manager.writeRawBlock('PAYLOAD', manager.maxContentRows, { cursorStationary: true })).toThrow(/rows/);
  });

  it('advances the content cursor by exactly the declared row count', () => {
    const { manager } = createMockScrollRegion();
    manager.begin();
    manager.setWelcomeRows(4);

    const before = manager.getContentCursor();
    manager.writeRawBlock('\x1b_Ga=T,f=100,C=1,i=1;QUJD\x1b\\\n\n\n', 4);

    expect(manager.getContentCursor()).toBe(before + 4);
  });

  it('does not measure the raw payload as visible width', () => {
    const { manager } = createMockScrollRegion();
    manager.begin();
    manager.setWelcomeRows(2);

    const hugePayload = 'A'.repeat(140_000);
    const before = manager.getContentCursor();
    manager.writeRawBlock(`\x1b_Ga=T,f=100,C=1,i=9;${hugePayload}\x1b\\\n\n`, 3);

    // A width-measuring path would report ~1700 phantom rows for this payload.
    expect(manager.getContentCursor()).toBe(before + 3);
  });

  it('zeroes the cursor column so the next text write starts at column 1', () => {
    const { manager, getOutput, resetOutput } = createMockScrollRegion();
    manager.begin();
    manager.setWelcomeRows(3);

    manager.writeAtContentCursor('partial line without newline');
    resetOutput();
    manager.writeRawBlock('\x1b]1337;File=inline=1;size=3:QUJD\x07\n', 2);
    resetOutput();
    manager.writeAtContentCursor('next text line\n');

    const output = getOutput();
    expect(output).toContain('\r');
    expect(output).toContain('next text line');
  });

  it('re-anchors the footer after writing the raw block', () => {
    const { manager, getOutput, resetOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'MODEL_X' });
    resetOutput();

    manager.writeRawBlock('\x1b_Ga=T;QUJD\x1b\\\n\n', 2);

    const output = getOutput();
    expect(output).toContain('Type your message...');
    expect(output).toContain('MODEL_X');
  });

  it('skips the footer re-anchor when prompt chrome restore is disabled', () => {
    const { manager, getOutput, resetOutput } = createMockScrollRegion();
    manager.begin();
    manager.renderFooter({ inputPrompt: 'Type your message...', statusLine: 'MODEL_X' });
    resetOutput();

    manager.writeRawBlock('\x1b_Ga=T;QUJD\x1b\\\n', 1, { clearPromptChrome: false });

    expect(getOutput()).not.toContain('MODEL_X');
  });

  it('clamps positioning at the scroll region bottom', () => {
    const { manager, getOutput, resetOutput } = createMockScrollRegion();
    manager.begin();
    manager.setContentCursor(manager.maxContentRows);
    resetOutput();

    manager.writeRawBlock('\x1b_Ga=T;QUJD\x1b\\\n\n\n\n', 5);
    resetOutput();
    manager.writeAtContentCursor('after clamp\n');

    const rows = [...getOutput().matchAll(/\x1b\[(\d+);1H/g)].map((match) => Number(match[1]));
    expect(rows.length).toBeGreaterThan(0);
    for (const row of rows) {
      expect(row).toBeLessThanOrEqual(manager.maxContentRows);
    }
  });

  it('writes the payload verbatim to the stream', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.begin();
    const payload = '\x1b_Ga=T,f=100,C=1,i=5;QUJDRA==\x1b\\';

    manager.writeRawBlock(`${payload}\n`, 1);

    expect(getOutput()).toContain(payload);
  });

  it('does not render the raw payload as visible screen text', () => {
    const harness = createTtyHarness(80, 24);
    const manager = new ScrollRegionManager(process.stdout);

    try {
      manager.begin();
      manager.setWelcomeRows(3);
      manager.writeAtContentCursor('before image\n');
      manager.writeRawBlock('\x1b_Ga=T,f=100,C=1,i=2;QUJDRA==\x1b\\\n\n', 2);
      manager.writeAtContentCursor('after image\n');

      const screenText = harness.screen.text();
      expect(screenText).toContain('before image');
      expect(screenText).toContain('after image');
      expect(screenText).not.toContain('QUJDRA==');
    } finally {
      harness.restore();
    }
  });

  it('suppresses raw payload logging and records only the placeholder', () => {
    const { manager } = createMockScrollRegion();
    manager.begin();

    const recorded: string[] = [];
    let depth = 0;
    const logger = {
      beginSuppress: () => {
        depth += 1;
      },
      endSuppress: () => {
        depth -= 1;
      },
      recordOutput: (_stream: 'stdout' | 'stderr', chunk: string) => {
        if (depth > 0) return;
        recorded.push(chunk);
      },
    };

    manager.writeRawBlock('\x1b_Ga=T,f=100,C=1,i=4;QUJDRA==\x1b\\\n\n', 2, {
      logger,
      placeholder: '  ↳ [Image 1388×278]',
    });

    expect(depth).toBe(0);
    const joined = recorded.join('');
    expect(joined).toContain('[Image 1388×278]');
    expect(joined).not.toContain('QUJDRA==');
  });

  it('falls back to a direct stream write when the scroll region is inactive', () => {
    const { manager, getOutput } = createMockScrollRegion();
    manager.writeRawBlock('\x1b_Ga=T;QQ==\x1b\\\n', 1);
    expect(getOutput()).toContain('\x1b_Ga=T;QQ==\x1b\\');
  });
});
