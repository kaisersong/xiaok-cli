// tests/ai/adapters/claude.test.ts
import { describe, it, expect, vi } from 'vitest';

const anthropicConstructorCalls: unknown[] = [];

// Mock @anthropic-ai/sdk
vi.mock('@anthropic-ai/sdk', () => {
  return {
    default: class Anthropic {
      messages = {
        stream: vi.fn(() => ({
          async *[Symbol.asyncIterator]() {
            yield { type: 'message_stop' };
          },
        })),
      };

      constructor(options?: unknown) {
        anthropicConstructorCalls.push(options);
      }
    },
  };
});

describe('ClaudeAdapter', () => {
  it('exposes the same existing output reservation sent in the real adapter request',async()=>{
    const {ClaudeAdapter}=await import('../../../src/ai/adapters/claude.js');
    const Anthropic=(await import('@anthropic-ai/sdk')).default;
    const instance=new Anthropic({apiKey:'fixture'}),adapter=new ClaudeAdapter('fixture','claude-opus-4-7');
    (adapter as unknown as {client:typeof instance}).client=instance;
    for await(const _ of adapter.stream([],[],'system')){/* consume actual adapter */}
    expect(adapter.getOutputTokenReserve()).toBe(8192);
    expect(instance.messages.stream).toHaveBeenCalledWith(expect.objectContaining({max_tokens:adapter.getOutputTokenReserve()}),expect.anything());
  });
  it.each(['/coding/v1', '/coding/v2'])(
    'lazily applies Kimi compatibility headers for %s',
    async (path) => {
      const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');
      anthropicConstructorCalls.length = 0;
      const adapter = new ClaudeAdapter(
        'test-key',
        'claude-opus-4-6',
        `https://api.kimi.com${path}`,
      );

      expect(anthropicConstructorCalls).toHaveLength(0);

      for await (const _ of adapter.stream([], [], 'system')) { /* consume */ }

      expect(anthropicConstructorCalls).toEqual([{
        apiKey: 'test-key',
        baseURL: `https://api.kimi.com${path}`,
        maxRetries: 3,
        defaultHeaders: {
          'User-Agent': 'claude-cli/1.0.0 (external, cli)',
          'X-Stainless-Lang': null,
          'X-Stainless-Package-Version': null,
          'X-Stainless-OS': null,
          'X-Stainless-Arch': null,
          'X-Stainless-Runtime': null,
          'X-Stainless-Runtime-Version': null,
          'X-Stainless-Retry-Count': null,
          'X-Stainless-Timeout': null,
        },
      }]);
    },
  );

  it('emits text chunks from streaming response', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { type: 'content_block_delta', delta: { type: 'text_delta', text: 'Hello ' } };
        yield { type: 'content_block_delta', delta: { type: 'text_delta', text: 'world' } };
        yield { type: 'message_stop' };
      },
    };

    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockReturnValue(mockStream as never);

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    // Replace internal client
    (adapter as unknown as { client: typeof instance }).client = instance;

    const chunks: string[] = [];
    for await (const chunk of adapter.stream([], [], 'system')) {
      if (chunk.type === 'text') chunks.push(chunk.delta);
    }
    expect(chunks).toEqual(['Hello ', 'world']);
  });

  it('buffers tool_use input_json_delta and emits single tool_use chunk', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { type: 'content_block_start', index: 0, content_block: { type: 'tool_use', id: 'tu_1', name: 'bash' } };
        yield { type: 'content_block_delta', index: 0, delta: { type: 'input_json_delta', partial_json: '{"cmd":' } };
        yield { type: 'content_block_delta', index: 0, delta: { type: 'input_json_delta', partial_json: '"ls"}' } };
        yield { type: 'content_block_stop', index: 0 };
        yield { type: 'message_stop' };
      },
    };

    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockReturnValue(mockStream as never);

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    const chunks = [];
    for await (const chunk of adapter.stream([], [], 'system')) {
      chunks.push(chunk);
    }

    const toolChunk = chunks.find(c => c.type === 'tool_use');
    expect(toolChunk).toMatchObject({ type: 'tool_use', id: 'tu_1', name: 'bash', input: { cmd: 'ls' } });
  });

  it('serializes block-based assistant and tool_result history', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let capturedMessages: unknown[] = [];
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { type: 'message_stop' };
      },
    };

    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation((params: unknown) => {
      capturedMessages = (params as { messages: unknown[] }).messages;
      return mockStream as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    const messages = [
      {
        role: 'assistant' as const,
        content: [
          { type: 'text' as const, text: 'running tools' },
        ],
      },
      {
        role: 'user' as const,
        content: [
          { type: 'tool_result' as const, tool_use_id: 'tu_1', content: 'done', is_error: false },
        ],
      },
    ];

    for await (const _ of adapter.stream(messages, [], 'system')) { /* consume */ }

    expect(capturedMessages).toEqual([
      { role: 'assistant', content: [{ type: 'text', text: 'running tools' }] },
      {
        role: 'user',
        content: [{ type: 'tool_result', tool_use_id: 'tu_1', content: 'done', is_error: false }],
      },
    ]);
  });

  it('maps prompt cache metadata onto Anthropic request payloads', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let capturedParams: Record<string, unknown> | null = null;
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { type: 'message_stop' };
      },
    };

    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation((params: unknown) => {
      capturedParams = params as Record<string, unknown>;
      return mockStream as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    for await (const _ of adapter.stream(
      [
        {
          role: 'user',
          content: [{ type: 'text', text: 'hello', cache_control: { type: 'ephemeral' } }],
        },
      ],
      [
        {
          name: 'read',
          description: 'Read a file',
          inputSchema: { type: 'object', properties: {} },
        },
      ],
      'system',
      {
        promptCache: {
          systemPrompt: [{ type: 'text', text: 'cached system', cache_control: { type: 'ephemeral' } }],
          tools: [
            {
              name: 'read',
              description: 'Read a file',
              inputSchema: { type: 'object', properties: {} },
              cache_control: { type: 'ephemeral' },
            },
          ],
          messages: [
            {
              role: 'user',
              content: [{ type: 'text', text: 'hello', cache_control: { type: 'ephemeral' } }],
            },
          ],
        },
      },
    )) { /* consume */ }

    expect(capturedParams).toMatchObject({
      system: [{ type: 'text', text: 'cached system', cache_control: { type: 'ephemeral' } }],
      tools: [{ name: 'read', cache_control: { type: 'ephemeral' } }],
      messages: [
        {
          role: 'user',
          content: [{ type: 'text', text: 'hello', cache_control: { type: 'ephemeral' } }],
        },
      ],
    });
  });

  it('propagates external abort signal to Anthropic stream requests', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let capturedOptions: { signal?: AbortSignal } | undefined;
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { type: 'message_stop' };
      },
    };

    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation((_params: unknown, options: unknown) => {
      capturedOptions = options as { signal?: AbortSignal };
      return mockStream as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    const controller = new AbortController();
    for await (const _ of adapter.stream([], [], 'system', { signal: controller.signal } as never)) { /* consume */ }

    expect(capturedOptions?.signal).toBeDefined();
    expect(capturedOptions?.signal?.aborted).toBe(true);
    expect(controller.signal.aborted).toBe(false);
    controller.abort();
    expect(capturedOptions?.signal?.aborted).toBe(true);
  });

  it('retries up to 3 times on 529 overload then succeeds', async () => {
    vi.useFakeTimers();
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let calls = 0;
    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation(() => {
      calls += 1;
      if (calls < 3) {
        const err = Object.assign(new Error('overload'), { status: 529 });
        throw err;
      }
      return (async function* () { yield { type: 'message_stop' }; })() as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    const streamPromise = (async () => {
      const chunks: string[] = [];
      for await (const chunk of adapter.stream([], [], 'sys')) {
        chunks.push(chunk.type);
      }
      return chunks;
    })();

    // 推进所有定时器
    await vi.runAllTimersAsync();
    const chunks = await streamPromise;

    expect(calls).toBe(3);
    expect(chunks).toContain('done');
    vi.useRealTimers();
  });

  it('throws after exhausting all retries', async () => {
    vi.useFakeTimers();
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let calls = 0;
    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation(() => {
      calls += 1;
      const err = Object.assign(new Error('overload'), { status: 529 });
      throw err;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    let caughtError: Error | undefined;
    const streamPromise = (async () => {
      try {
        for await (const _ of adapter.stream([], [], 'sys')) { /* drain */ }
      } catch (e) {
        caughtError = e as Error;
      }
    })();

    await vi.runAllTimersAsync();
    await streamPromise;

    expect(caughtError?.message).toBe('overload');
    expect(calls).toBe(4); // 1 initial + 3 retries
    vi.useRealTimers();
  });

  it('serializes image blocks for Claude-compatible payloads', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let capturedMessages: unknown[] = [];
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { type: 'message_stop' };
      },
    };

    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation((params: unknown) => {
      capturedMessages = (params as { messages: unknown[] }).messages;
      return mockStream as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    for await (const _ of adapter.stream([
      {
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/png',
              data: 'YWJj',
            },
          },
        ],
      },
    ], [], 'system')) { /* consume */ }

    expect(capturedMessages).toEqual([
      {
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: 'image/png',
              data: 'YWJj',
            },
          },
        ],
      },
    ]);
  });

  it('retries when the stream is dropped mid-flight with "Premature close"', async () => {
    vi.useFakeTimers();
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let calls = 0;
    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation(() => {
      calls += 1;
      if (calls < 2) {
        // 模拟 Node fetch/undici 在响应体传输中途断开
        const err = Object.assign(new Error('Premature close'), { code: 'ERR_STREAM_PREMATURE_CLOSE' });
        return (async function* () { throw err; })() as never;
      }
      return (async function* () {
        yield { type: 'content_block_delta', delta: { type: 'text_delta', text: 'ok' } };
        yield { type: 'message_stop' };
      })() as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    const streamPromise = (async () => {
      const chunks: string[] = [];
      for await (const chunk of adapter.stream([], [], 'sys')) {
        if (chunk.type === 'text') chunks.push(chunk.delta);
      }
      return chunks;
    })();

    await vi.runAllTimersAsync();
    const chunks = await streamPromise;

    expect(calls).toBe(2);
    expect(chunks).toEqual(['ok']);
    vi.useRealTimers();
  });

  it('does not retry once a chunk has already been emitted', async () => {
    vi.useFakeTimers();
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');

    let calls = 0;
    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const instance = new Anthropic({ apiKey: 'test' });
    vi.spyOn(instance.messages, 'stream').mockImplementation(() => {
      calls += 1;
      // 先产出一个 chunk，再断流：此时重试会重复输出，必须放弃
      return (async function* () {
        yield { type: 'content_block_delta', delta: { type: 'text_delta', text: 'partial' } };
        throw Object.assign(new Error('Premature close'), { code: 'ERR_STREAM_PREMATURE_CLOSE' });
      })() as never;
    });

    const adapter = new ClaudeAdapter('test-key', 'claude-opus-4-6');
    (adapter as unknown as { client: typeof instance }).client = instance;

    let caughtError: Error | undefined;
    const chunks: string[] = [];
    const streamPromise = (async () => {
      try {
        for await (const chunk of adapter.stream([], [], 'sys')) {
          if (chunk.type === 'text') chunks.push(chunk.delta);
        }
      } catch (e) {
        caughtError = e as Error;
      }
    })();

    await vi.runAllTimersAsync();
    await streamPromise;

    expect(calls).toBe(1);
    expect(chunks).toEqual(['partial']);
    expect(caughtError?.message).toBe('Premature close');
    vi.useRealTimers();
  });
});


describe('Claude memory output budget', () => {
  it('maps max_tokens and rejects output exhaustion', async () => {
    const { ClaudeAdapter } = await import('../../../src/ai/adapters/claude.js');
    const Anthropic = (await import('@anthropic-ai/sdk')).default;
    const client = new Anthropic({ apiKey: 'fixture' }); const adapter = new ClaudeAdapter('fixture', 'claude-opus-4-7');
    client.messages.stream = vi.fn(() => ({ async *[Symbol.asyncIterator]() {
      yield { type: 'message_delta', delta: { stop_reason: 'max_tokens' }, usage: { output_tokens: 4096 } };
      yield { type: 'message_stop' };
    } })) as never;
    (adapter as unknown as { client: typeof client }).client = client;
    const consume = async () => { for await (const _ of adapter.stream([], [], 'system', { maxOutputTokens: 4096 })) { /* consume */ } };
    await expect(consume()).rejects.toThrow('memory_output_incomplete');
    expect(client.messages.stream).toHaveBeenCalledWith(expect.objectContaining({ max_tokens: 4096 }), expect.anything());
  });
});
