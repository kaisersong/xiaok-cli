import { modelConfigErrorMessage } from '../lib/model-config-error';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ChevronDown, Cpu } from 'lucide-react';
import { api } from '../api';
import type {
  DesktopModelConfigSnapshot,
  DesktopModelEntryView,
  DesktopModelProviderView,
} from '../../../electron/preload-api';
import { useLocale } from '../contexts/LocaleContext';

interface ChatModelPickerProps {
  disabled?: boolean;
}

export function ChatModelPicker({ disabled }: ChatModelPickerProps) {
  const { t } = useLocale();
  const [config, setConfig] = useState<DesktopModelConfigSnapshot | null>(null);
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [saving, setSaving] = useState(false);
  const [modelError, setModelError] = useState('');
  const [menuStyle, setMenuStyle] = useState<React.CSSProperties>({});
  const btnRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const loadConfig = async () => {
    try {
      const snapshot = await api.getModelConfig();
      setConfig(snapshot);
    } catch (error) {
      setModelError(modelConfigErrorMessage(error, { operationUnknown: t.desktopSettings.modelConfigOperationUnknown, inputInvalid: t.desktopSettings.modelConfigInputInvalid, unavailable: t.desktopSettings.modelConfigUnavailable }) ?? t.desktopSettings.modelConfigUnavailable);
      setConfig(null);
    }
  };

  useEffect(() => {
    void loadConfig();
  }, []);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (
        menuRef.current?.contains(e.target as Node)
        || btnRef.current?.contains(e.target as Node)
      ) {
        return;
      }
      setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const currentModel: DesktopModelEntryView | null = (() => {
    if (!config) return null;
    return (
      config.models.find((m) => m.id === config.defaultModelId)
      ?? config.models.find((m) => m.isDefault)
      ?? null
    );
  })();
  const currentProvider: DesktopModelProviderView | null = currentModel
    ? config?.providers.find((p) => p.id === currentModel.provider) ?? null
    : null;

  const modelLabel = (model: DesktopModelEntryView) => model.id === 'local-codex' ? t.localCodex : model.label;
  const buttonLabel = currentModel ? modelLabel(currentModel) : t.chatInput.modelPicker.empty;
  const effortLabels = {
    none: t.chatInput.modelPicker.effortNone,
    minimal: t.chatInput.modelPicker.effortMinimal,
    low: t.chatInput.modelPicker.effortLow,
    medium: t.chatInput.modelPicker.effortMedium,
    high: t.chatInput.modelPicker.effortHigh,
    xhigh: t.chatInput.modelPicker.effortXhigh,
    max: t.chatInput.modelPicker.effortMax,
  };
  const currentEfforts = currentModel?.runtimeConstraints?.reasoningEfforts ?? [];
  const defaultEffort = currentEfforts[Math.floor(currentEfforts.length / 2)];
  const currentEffort = currentModel?.runtimeOptions?.reasoningEffort;

  const handleOpen = () => {
    if (disabled || saving) return;
    if (!open && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      const menuWidth = Math.max(rect.width, 240);
      setMenuStyle({
        position: 'fixed',
        bottom: window.innerHeight - rect.top + 6,
        left: rect.left,
        width: menuWidth,
        zIndex: 9999,
      });
    }
    setOpen((v) => !v);
  };

  const handleSelect = async (model: DesktopModelEntryView) => {
    if (!config || saving) return;
    if (config.defaultModelId === model.id) {
      setOpen(Boolean(model.runtimeConstraints?.reasoningEfforts?.length));
      return;
    }
    setOpen(Boolean(model.runtimeConstraints?.reasoningEfforts?.length));
    setSaving(true);
    setModelError('');
    try {
      const updated = await api.saveModelConfig({
        providerId: model.provider,
        modelId: model.id,
      });
      setConfig(updated);
    } catch (error) {
      setModelError(modelConfigErrorMessage(error, { operationUnknown: t.desktopSettings.modelConfigOperationUnknown, inputInvalid: t.desktopSettings.modelConfigInputInvalid, unavailable: t.desktopSettings.modelConfigUnavailable }) ?? t.desktopSettings.modelConfigUnavailable);
      void loadConfig();
    } finally {
      setSaving(false);
    }
  };

  const handleEffortSelect = async (effort: NonNullable<NonNullable<DesktopModelEntryView['runtimeOptions']>['reasoningEffort']>) => {
    if (!currentModel || !currentEfforts.includes(effort) || saving) return;
    if (currentEffort === effort) return;
    setSaving(true);
    setModelError('');
    try {
      const updated = await api.updateModelRuntimeOptions({
        modelId: currentModel.id,
        runtimeOptions: { ...currentModel.runtimeOptions, reasoningEffort: effort },
      });
      setConfig(updated);
    } catch (error) {
      setModelError(modelConfigErrorMessage(error, { operationUnknown: t.desktopSettings.modelConfigOperationUnknown, inputInvalid: t.desktopSettings.modelConfigInputInvalid, unavailable: t.desktopSettings.modelConfigUnavailable }) ?? t.desktopSettings.modelConfigUnavailable);
      void loadConfig();
    } finally {
      setSaving(false);
    }
  };

  const grouped = (() => {
    if (!config) return [] as Array<{ provider: DesktopModelProviderView; models: DesktopModelEntryView[] }>;
    const byProvider = new Map<string, DesktopModelEntryView[]>();
    for (const model of config.models) {
      const list = byProvider.get(model.provider) ?? [];
      list.push(model);
      byProvider.set(model.provider, list);
    }
    return config.providers
      .map((provider) => ({ provider, models: byProvider.get(provider.id) ?? [] }))
      .filter((g) => g.models.length > 0);
  })();

  const empty = !config || config.models.length === 0;

  const menu = open ? (
    <div
      ref={menuRef}
      className="dropdown-menu"
      style={{
        ...menuStyle,
        border: '0.5px solid var(--c-border-subtle)',
        borderRadius: '10px',
        padding: '4px',
        background: 'var(--c-bg-menu)',
        boxShadow: 'var(--c-dropdown-shadow)',
        maxHeight: '320px',
        overflowY: 'auto',
      }}
    >
      {empty ? (
        <div
          className="px-3 py-2 text-xs"
          style={{ color: 'var(--c-text-tertiary)' }}
        >
          {t.chatInput.modelPicker.empty}
        </div>
      ) : (
        grouped.map(({ provider, models }) => (
          <div key={provider.id} style={{ marginBottom: '4px' }}>
            <div
              className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-wider"
              style={{ color: 'var(--c-text-tertiary)' }}
            >
              {provider.label}
            </div>
            {models.map((model) => {
              const active = model.id === config?.defaultModelId;
              return (
                <button
                  key={model.id}
                  type="button"
                  disabled={saving}
                  onClick={() => { void handleSelect(model); }}
                  className="flex w-full items-center justify-between px-3 py-2 text-sm transition-colors bg-[var(--c-bg-menu)] hover:bg-[var(--c-bg-deep)]"
                  style={{
                    borderRadius: '8px',
                    fontWeight: active ? 600 : 400,
                    color: active ? 'var(--c-text-heading)' : 'var(--c-text-secondary)',
                  }}
                >
                  <span className="truncate">{modelLabel(model)}</span>
                  {active && (
                    <span
                      className="ml-2 shrink-0 rounded px-1.5 py-0.5 text-[10px]"
                      style={{ background: 'var(--c-bg-deep)', color: 'var(--c-text-tertiary)' }}
                    >
                      {t.chatInput.modelPicker.activeBadge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))
      )}
      {currentEfforts.length > 0 && (
        <div style={{ borderTop: '0.5px solid var(--c-border-subtle)', marginTop: '4px', padding: '8px 8px 4px' }}>
          <div className="px-1 pb-1 text-[10px] uppercase tracking-wider" style={{ color: 'var(--c-text-tertiary)' }}>
            {t.chatInput.modelPicker.effortLabel}
          </div>
          <p className="px-1 pb-2 text-[10px]" style={{ color: 'var(--c-text-tertiary)' }}>{t.chatInput.modelPicker.effortHint}</p>
          <div className="grid grid-cols-3 gap-1">
            {currentEfforts.map(effort => (
              <button
                key={effort}
                type="button"
                disabled={saving}
                aria-pressed={effort === currentEffort}
                onClick={() => { void handleEffortSelect(effort); }}
                className="flex-1 rounded-md px-2 py-1.5 text-xs disabled:opacity-50"
                style={{
                  background: effort === currentEffort ? 'var(--c-bg-deep)' : 'transparent',
                  color: effort === currentEffort ? 'var(--c-text-heading)' : 'var(--c-text-secondary)',
                  fontWeight: effort === currentEffort ? 600 : 400,
                }}
              >
                {effortLabels[effort]} ({effort}){effort === defaultEffort ? ` · ${t.chatInput.modelPicker.effortDefault}` : ''}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  ) : null;

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        disabled={disabled || saving}
        onClick={handleOpen}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        title={currentProvider ? `${currentProvider.label} · ${buttonLabel}` : t.chatInput.modelPicker.tooltip}
        aria-label={t.chatInput.modelPicker.tooltip}
        className="flex h-[26px] max-w-[180px] items-center gap-1 rounded-md px-2 text-xs disabled:cursor-not-allowed disabled:opacity-50"
        style={{
          border: `0.5px solid ${hovered && !disabled ? 'var(--c-border-mid)' : 'var(--c-border-subtle)'}`,
          background: hovered && !disabled ? 'var(--c-bg-deep)' : 'transparent',
          color: 'var(--c-text-secondary)',
          transition: 'border-color 0.15s, background-color 0.15s',
        }}
      >
        <Cpu size={12} className="shrink-0 opacity-70" />
        <span className="truncate" style={{ fontWeight: 400 }}>{buttonLabel}</span>
        {currentEfforts.length > 0 && currentEffort && (
          <span className="shrink-0 opacity-70">· {effortLabels[currentEffort]}</span>
        )}
        <ChevronDown size={12} className="shrink-0 opacity-70" />
      </button>
      {modelError ? <span role="alert" className="text-xs text-[var(--c-status-error-text)]">{modelError}</span> : null}
      {menu && createPortal(menu, document.body)}
    </>
  );
}
