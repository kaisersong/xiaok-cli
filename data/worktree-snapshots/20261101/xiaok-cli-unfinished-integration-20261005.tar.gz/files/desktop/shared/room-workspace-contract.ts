/** Renderer receives projections only; main authenticates every operation. */
export interface RoomWorkspaceRequest { roomId: string }
export interface RoomWorkspaceScope { kind: 'room_only' | 'project'; projectId?: string }
export type RoomWorkspaceActor = { kind: 'user'; userId: string }
  | { kind: 'agent'; logicalAgentId: string } | { kind: 'system'; service: string };
export interface RoomWorkspaceTerminationEvidence {
  executorInstanceId: string; kind: 'process-exit' | 'session-disposed' | 'resources-disposed'; verified: boolean;
}
/** Complete existing broker facts, never an execution or authorization grant. */
export interface RoomWorkspaceClaim {
  claimId: string; runId: string; executionState: string; authorizationState: string;
  instructionsRevision: number; agentName?: string; executorInstanceId?: string; projectId?: string;
  roomId?: string; logicalAgentId?: string; contextScope?: RoomWorkspaceScope;
  parentClaimId?: string | null; projectMappingRevision?: number | null; taskId?: string | null;
  protocolVersion?: number; workspaceId?: string; originHostId?: string; hostPrincipal?: string;
  hostIncarnation?: number; bindingId?: string; generation?: number; workspaceRevision?: number;
  instructionsDigest?: string | null; membershipRevision?: number; createdAt?: string;
  acquireDigest?: string; taskName?: string; mappingRevision?: number; roomSequence?: number;
  updatedAt?: string; lastHeartbeatAt?: string; terminationEvidence?: RoomWorkspaceTerminationEvidence;
}
export interface RoomWorkspaceArtifactHandoff {
  reportedSummary: string; completionStatus: string; unfinished: null; blockers: null; sourceMessageIds: string[];
}
export interface RoomWorkspaceInstructions {
  revision: number; publishedText: string; sourceRelativePath?: string | null; sourceHash?: string | null;
  sourceChanged?: boolean; candidateText?: string; candidateHash?: string; roomId?: string;
  description?: string; directoryNotes?: string | string[]; snapshotDigest?: string;
  publishedBy?: RoomWorkspaceActor; publishedAt?: string;
}
export interface RoomWorkspaceArtifact {
  artifactId: string; versionId: string; relativePath: string; state: string;
  bindingId: string; generation: number; contentHash?: string; size?: number;
  producerAgentId?: string; producerRunId?: string; producerDisplayName?: string; producerType?: 'user' | 'unknown' | 'agent';
  projectId?: string; synchronization?: 'pending' | 'synced';
  roomId?: string; workspaceId?: string; originHostId?: string; workspaceRevision?: number;
  contextScope?: RoomWorkspaceScope; producerClaimId?: string; handoff?: RoomWorkspaceArtifactHandoff;
  observedAt?: string; commitTicketId?: string; confirmationTicketId?: string; sourceSequence?: number;
}
export interface RoomWorkspaceSnapshot {
  localCommandsAllowed?: boolean;
  ok: boolean; code?: string; phase: string; revision: number;
  permissions: { canManage: boolean; canRead: boolean; canReadArtifacts?: boolean; canRegister?: boolean };
  workspaceId?: string | null; bindingId?: string | null; generation?: number; rootDisplayPath?: string; operationId?: string | null;
  instructions?: RoomWorkspaceInstructions | null;
  claims: RoomWorkspaceClaim[];
  artifacts: RoomWorkspaceArtifact[];
  projectMappings?: Array<{ projectId: string; name?: string; state: string; mappingRevision?: number; projectRevision?: number; workFolderRelativePath?: string; artifactsRelativePath?: string }>;
}
export interface RoomWorkspaceChangeInput extends RoomWorkspaceRequest {
  expectedRevision: number; mode: 'existing' | 'create' | 'unset'; selectedPath?: string; directoryName?: string;
  templateEntries: Array<{ relativePath: string; kind: 'directory' | 'file'; content?: string }>;
  instructionsText?: string;
}
export interface RoomWorkspacePreview {
  ok: boolean; code?: string; previewId?: string; canCommit: boolean;
  changes: Array<{ relativePath: string; kind: 'directory' | 'file'; action: 'create' | 'existing'; content?: string }>;
  conflicts: string[]; overlaps: string[];
}
export interface RoomWorkspaceMutationResult { ok: boolean; code?: string; operationId?: string; snapshot?: RoomWorkspaceSnapshot }
export interface RoomWorkspaceFileRequest extends RoomWorkspaceRequest { bindingId: string; generation: number; relativePath: string }
export interface RoomWorkspaceFilePage { ok: boolean; code?: string; entries: Array<{ relativePath: string; name: string; kind: 'directory' | 'file'; size?: number; state?: string }>; nextCursor?: string }
export interface RoomWorkspaceFilePreview { ok: boolean; code?: string; state?: 'current' | 'changed' | 'missing'; text?: string; truncated?: boolean; mimeType?: string; contentHash?: string }
export interface RoomWorkspaceApi {
  setCollaborationRoomLocalCommands(input: RoomWorkspaceRequest & { bindingId: string; generation: number; enabled: boolean; requestSource: 'user' }): Promise<RoomWorkspaceMutationResult>;
  retryCollaborationRoomWorkspaceChange(input: RoomWorkspaceRequest & { operationId: string; expectedRevision: number; idempotencyKey: string }): Promise<RoomWorkspaceMutationResult>;
  mapCollaborationRoomWorkspaceProject(input: RoomWorkspaceRequest & { projectId: string; expectedRevision: number; expectedProjectRevision: number; idempotencyKey: string; workFolderRelativePath: string; artifactsRelativePath: string }): Promise<RoomWorkspaceMutationResult>;
  getCollaborationRoomWorkspace(input: RoomWorkspaceRequest): Promise<RoomWorkspaceSnapshot>;
  previewCollaborationRoomWorkspace(input: RoomWorkspaceChangeInput): Promise<RoomWorkspacePreview>;
  commitCollaborationRoomWorkspace(input: RoomWorkspaceRequest & { previewId: string; expectedRevision: number; idempotencyKey: string; confirmOverlap: boolean; confirmSharedReadGrant: boolean }): Promise<RoomWorkspaceMutationResult>;
  cancelCollaborationRoomWorkspaceChange(input: RoomWorkspaceRequest & { operationId: string; expectedRevision: number; idempotencyKey: string }): Promise<RoomWorkspaceMutationResult>;
  listCollaborationRoomWorkspaceFiles(input: RoomWorkspaceFileRequest & { cursor?: string }): Promise<RoomWorkspaceFilePage>;
  previewCollaborationRoomWorkspaceFile(input: RoomWorkspaceFileRequest & { versionId?: string }): Promise<RoomWorkspaceFilePreview>;
  publishCollaborationRoomWorkspaceInstructions(input: RoomWorkspaceRequest & { expectedRevision: number; idempotencyKey: string; publishedText: string; sourceRelativePath?: string; sourceHash?: string }): Promise<RoomWorkspaceMutationResult>;
  confirmCollaborationRoomWorkspaceArtifact(input: RoomWorkspaceRequest & { artifactId: string; versionId: string; expectedRevision: number; idempotencyKey: string }): Promise<RoomWorkspaceMutationResult>;
  registerCollaborationRoomWorkspaceArtifact(input: RoomWorkspaceFileRequest & { expectedRevision: number; idempotencyKey: string }): Promise<RoomWorkspaceMutationResult>;
}
