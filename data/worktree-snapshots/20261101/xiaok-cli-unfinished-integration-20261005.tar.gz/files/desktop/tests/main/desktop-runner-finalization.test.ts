// @vitest-environment node
import { openOwnedWorkflowNormalCase } from '../support/owned-workflow-normal-case.js';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { Message, ToolDefinition } from '../../../src/types.js';

const adapterState = vi.hoisted(() => ({
  streamCalls: 0,
  toolCounts: [] as number[],
  emptySecondTurn: false,
}));

function stubAdapter() {
  return {
    getModelName: () => 'unit-test-model',
    async *stream(_messages: Message[], tools: ToolDefinition[]) {
      adapterState.streamCalls += 1;
      adapterState.toolCounts.push(tools.length);
      if (tools.length === 0) {
        yield {
          type: 'text',
          delta: JSON.stringify({
            output: {
              summary: 'finalized from prior tool results',
              artifacts: [],
              evidenceRefs: ['tool-results'],
            },
          }),
        };
        return;
      }
      if (adapterState.emptySecondTurn && adapterState.streamCalls === 2) {
        return;
      }
      yield {
        type: 'tool_use',
        id: `tool_${adapterState.streamCalls}`,
        name: 'report_progress',
        input: {
          steps: [
            { id: `step-${adapterState.streamCalls}`, label: 'collect evidence', status: 'running' },
          ],
        },
      };
    },
  };
}

// The runner resolves a model binding and then calls createAdapterFromBinding,
// so stubbing createAdapter alone intercepts nothing. Keep the rest of the
// module real: other desktop code paths import from it too.
vi.mock('../../../src/ai/models.js', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../../../src/ai/models.js')>()),
  createAdapter: vi.fn(() => stubAdapter()),
  createAdapterFromBinding: vi.fn(() => stubAdapter()),
}));

const { createDesktopServices } = await import('../../electron/desktop-services.js');

describe('desktop runner finalization', () => {
  let rootDir: string;

  beforeEach(() => {
    rootDir = join(tmpdir(), `xiaok-desktop-runner-finalization-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    mkdirSync(rootDir, { recursive: true });
    process.env.XIAOK_CONFIG_DIR = join(rootDir, 'config');
    adapterState.streamCalls = 0;
    adapterState.toolCounts = [];
    adapterState.emptySecondTurn = false;
  });

  afterEach(() => {
    // The task host persists snapshots asynchronously after the runner returns.
    // Deleting the temp root here races Windows rename() and creates false failures.
    delete process.env.XIAOK_CONFIG_DIR;
    vi.unstubAllEnvs();
  });

  it('runs a no-tool finalization turn at an explicit limit but does not report the exhausted task as completed', async () => {
    vi.stubEnv('XIAOK_AGENT_MAX_ITERATIONS', '2');
    const owned = await openOwnedWorkflowNormalCase({"project":{"id":"proj-finalize","name":"AI infrastructure","goal":"Collect updates"},"workflowName":"dynamic_research_workflow","prompt":"Collect AI infrastructure updates and return structured JSON.","label":"Research node","phaseTitle":"Research node"});
    let services: ReturnType<typeof createDesktopServices> | undefined;
    try {
    const workFolder = owned.fixture.workspace.path;
    services = createDesktopServices({
      dataRoot: join(rootDir, 'data'),
      kswarmService: owned.kswarmService,
      now: () => 300,
    });
    // Binding resolution runs before the adapter is built and rejects an empty
    // config, so the finalization logic under test is never reached without it.
    await services.saveModelConfig({ providerId: 'kimi', apiKey: 'sk-kimi' }, undefined, 'user');

    const execution = services.runKSwarmWorkflowNode({
      handoff: owned.handoff,
      targetParticipantId: 'xiaok-worker',
    });

    await expect(execution).rejects.toThrow('desktop_task_failed');
    expect(adapterState.streamCalls).toBe(3);
    expect(adapterState.toolCounts.slice(0, 2).every((count) => count > 0)).toBe(true);
    expect(adapterState.toolCounts[2]).toBe(0);
  
    } finally { await owned.close(services); }
  });

  it('runs a no-tool finalization turn when the model returns an empty turn after tool results', async () => {
    adapterState.emptySecondTurn = true;
    const owned = await openOwnedWorkflowNormalCase({"project":{"id":"proj-finalize-empty","name":"AI infrastructure","goal":"Collect updates"},"workflowName":"dynamic_research_workflow","prompt":"Collect AI infrastructure updates and return structured JSON.","label":"Research node","phaseTitle":"Research node"});
    let services: ReturnType<typeof createDesktopServices> | undefined;
    try {
    const workFolder = owned.fixture.workspace.path;
    services = createDesktopServices({
      dataRoot: join(rootDir, 'data'),
      kswarmService: owned.kswarmService,
      now: () => 300,
    });
    await services.saveModelConfig({ providerId: 'kimi', apiKey: 'sk-kimi' }, undefined, 'user');

    const result = await services.runKSwarmWorkflowNode({
      handoff: owned.handoff,
      targetParticipantId: 'xiaok-worker',
    });

    expect(adapterState.streamCalls).toBe(3);
    expect(adapterState.toolCounts).toEqual([
      expect.any(Number),
      expect.any(Number),
      0,
    ]);
    expect(adapterState.toolCounts[0]).toBeGreaterThan(0);
    expect(adapterState.toolCounts[1]).toBeGreaterThan(0);
    expect(result.output?.summary).toBe('finalized from prior tool results');
  
    } finally { await owned.close(services); }
  });
});
