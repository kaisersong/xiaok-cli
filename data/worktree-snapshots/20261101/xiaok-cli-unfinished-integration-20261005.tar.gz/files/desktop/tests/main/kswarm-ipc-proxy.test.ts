import { describe, expect, it, vi } from 'vitest';

import { registerKSwarmProxy } from '../../electron/kswarm-ipc-proxy.js';

function createIpcMainMock() {
  const handlers = new Map<string, (...args: unknown[]) => unknown>();
  return {
    handlers,
    ipcMain: {
      handle: vi.fn((channel: string, handler: (...args: unknown[]) => unknown) => {
        handlers.set(channel, handler);
      }),
    },
  };
}

describe('kswarm ipc proxy', () => {
  it.each(['get', 'getText'])('reads nested project artifacts through the production %s handler', async (channel) => {
    const { ipcMain, handlers } = createIpcMainMock();
    const body = channel === 'getText' ? '# 综合报告\n正文' : JSON.stringify({ safe: true });
    const request = vi.fn(async () => new Response(body, { status: 200 }));
    registerKSwarmProxy(ipcMain as never, {} as never, { request });
    const path = '/projects/proj-1/artifacts/run-a/' + encodeURIComponent('报告 中文 100%.md');
    const result = await handlers.get(`desktop:kswarm:proxy:${channel}`)?.({}, path);
    expect(result).toEqual(channel === 'getText' ? body : { safe: true });
    expect(request).toHaveBeenCalledWith(path, expect.objectContaining({ method: 'GET' }));
  });

  it.each([
    '/projects/proj-1/artifacts/run-a/../report.md',
    '/projects/proj-1/artifacts/run-a/%2e%2e/report.md',
    '/projects/proj-1/artifacts/run-a%2freport.md',
    '/projects/proj-1/artifacts/run-a/%5creport.md',
    '/projects/proj-1/artifacts/run-a//report.md',
    '/projects/proj-1/artifacts/run-a/./report.md',
    '/projects/proj-1/private/run-a/report.md',
  ])('keeps rejecting unsafe nested artifact reads %s', async (path) => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn();
    registerKSwarmProxy(ipcMain as never, {} as never, { request });
    for (const channel of ['get', 'getText']) {
      expect(await handlers.get(`desktop:kswarm:proxy:${channel}`)?.({}, path)).toBeNull();
    }
    expect(request).not.toHaveBeenCalled();
  });

  it('does not expand write permissions for nested artifacts', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn();
    registerKSwarmProxy(ipcMain as never, {} as never, { request });
    expect(await handlers.get('desktop:kswarm:proxy:put')?.({}, '/projects/p/artifacts/run-a/report.md', { content: 'x' })).toBeNull();
    expect(request).not.toHaveBeenCalled();
  });

  it.each(['post','postJson'])('routes %s workspace dispatch through one trusted semantic owner without legacy fallback',async channel=>{
    const {ipcMain,handlers}=createIpcMainMock(),request=vi.fn();
    const dispatchProject=vi.fn(async()=>({ok:false,code:'workspace_mapping_required'}));
    registerKSwarmProxy(ipcMain as never,{} as never,{request},{dispatchProject,authorize:event=>(event as any).trusted===true});
    const call=handlers.get(`desktop:kswarm:proxy:${channel}`)!;
    expect(await call({trusted:false},'/projects/p/dispatch',{})).toMatchObject({ok:false});
    expect(dispatchProject).not.toHaveBeenCalled();
    expect(await call({trusted:true},'/projects/p/dispatch',{})).toMatchObject({ok:false,code:'workspace_mapping_required'});
    expect(dispatchProject).toHaveBeenCalledTimes(1);expect(request).not.toHaveBeenCalled();
  });
  it('routes write requests through the managed kswarm service gateway', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(JSON.stringify({ ok: true, project: { id: 'proj-1' } }), { status: 200 }));

    registerKSwarmProxy(ipcMain as never, { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never, { request, getDesktopMutationToken: () => 'desktop-token' });

    const handler = handlers.get('desktop:kswarm:proxy:post');
    expect(handler).toBeDefined();
    const result = await handler?.({}, '/projects/proj-1/tasks', { tasks: [{ title: 'Review' }] });

    expect(request).toHaveBeenCalledWith('/projects/proj-1/tasks', expect.objectContaining({
      method: 'POST',
      headers: expect.objectContaining({ 'x-kswarm-mutation-token': 'desktop-token' }),
      body: JSON.stringify({ tasks: [{ title: 'Review' }] }),
    }));
    expect(result).toEqual({ ok: true, project: { id: 'proj-1' } });
  });

  it('applies one default-deny gate to all seven generic proxy channels', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(JSON.stringify({ ok: true }), { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    const attempts: Array<[string, unknown[]]> = [
      ['desktop:kswarm:proxy:get', [{}, '/agents/secret-agent']],
      ['desktop:kswarm:proxy:getText', [{}, '/agents/secret-agent']],
      ['desktop:kswarm:proxy:post', [{}, '/agents', { name: 'unsafe' }]],
      ['desktop:kswarm:proxy:postJson', [{}, '/agents/secret-agent/archive', {}]],
      ['desktop:kswarm:proxy:put', [{}, '/agents/secret-agent', { apiKey: 'secret' }]],
      ['desktop:kswarm:proxy:patch', [{}, '/projects/project-1/execution-mode', { executionMode: 'auto' }]],
      ['desktop:kswarm:proxy:delete', [{}, '/agents/secret-agent']],
    ];

    for (const [channel, args] of attempts) {
      await handlers.get(channel)?.(...args);
    }
    expect(request).not.toHaveBeenCalled();
  });

  it.each([
    '/agents/agent-1/',
    '/agents/agent-1?allowed=true',
    '/agents/%2fsecret',
    '/agents/%2Fsecret',
    '/agents%2fagent-1',
    '/agents/agent-1/../liveness',
    '/agents//liveness',
    '//agents/agent-1',
  ])('rejects normalized-path bypass attempt %s', async (path) => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response('{}', { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    expect(await handlers.get('desktop:kswarm:proxy:get')?.({}, path)).toBeNull();
    expect(request).not.toHaveBeenCalled();
  });

  // design §9.1/§9.3：getProjectGateSnapshot(projectId) 通过通用 GET 代理暴露
  // 给 renderer，不需要新增专用 IPC channel——但必须先加入 SAFE_GET_PATTERNS
  // 白名单，否则会被 default-deny 拒绝。
  it('allows GET /projects/:id/gate-snapshot through the safe GET allowlist (design §9.1/§9.3)', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      snapshot: { projectId: 'proj-1', phase: 'active', counts: {}, conditionSummaries: [], artifacts: [], userActions: [] },
    }), { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    const result = await handlers.get('desktop:kswarm:proxy:get')?.({}, '/projects/proj-1/gate-snapshot');
    expect(request).toHaveBeenCalledWith('/projects/proj-1/gate-snapshot', expect.objectContaining({ method: 'GET' }));
    expect(result).toEqual({
      ok: true,
      snapshot: { projectId: 'proj-1', phase: 'active', counts: {}, conditionSummaries: [], artifacts: [], userActions: [] },
    });
  });

  // design §9.1/§9.3：submitUserGateAction 的第一个真实映射——用户批准候选
  // FinalDeliverable，通过通用 POST 代理暴露。
  it('allows POST /projects/:id/final-deliverables/:id/approve through the safe POST allowlist (design §9.1/§9.3)', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(JSON.stringify({ ok: true, finalDeliverable: { deliverableId: 'fd-1', status: 'approved' } }), { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    const handler = handlers.get('desktop:kswarm:proxy:post');
    const result = await handler?.({}, '/projects/proj-1/final-deliverables/fd-1/approve', { approvalIdempotencyKey: 'k1' });

    expect(request).toHaveBeenCalledWith('/projects/proj-1/final-deliverables/fd-1/approve', expect.objectContaining({
      method: 'POST',
      headers: expect.objectContaining({ 'x-kswarm-mutation-token': 'desktop-token' }),
      body: JSON.stringify({ approvalIdempotencyKey: 'k1' }),
    }));
    expect(result).toEqual({ ok: true, finalDeliverable: { deliverableId: 'fd-1', status: 'approved' } });
  });

  it('redacts agent credentials from JSON and JSON-shaped text responses', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const secretAgent = {
      id: 'agent-1',
      apiKey: 'secret',
      baseUrl: 'https://secret.example',
      customEnv: { TOKEN: 'secret' },
      runtimePath: '/secret/runtime',
      execution: { credential: 'secret' },
      nested: { providerSecret: 'secret', safe: true },
    };
    const request = vi.fn(async (path: string) => {
      if (path === '/agents') {
        return new Response(JSON.stringify({ agents: [secretAgent] }), { status: 200 });
      }
      return new Response(JSON.stringify(secretAgent), { status: 200 });
    });
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    const json = await handlers.get('desktop:kswarm:proxy:get')?.({}, '/agents');
    const text = await handlers.get('desktop:kswarm:proxy:getText')?.({}, '/projects/project-1/artifacts/agent.json');

    expect(JSON.stringify(json)).not.toContain('secret');
    expect(JSON.stringify(json)).not.toContain('runtimePath');
    expect(String(text)).not.toContain('secret');
    expect(String(text)).not.toContain('runtimePath');
    expect(json).toEqual({ agents: [{ id: 'agent-1', nested: { safe: true } }] });
  });

  it('preserves non-sensitive project execution facts while removing credential-bearing execution blocks', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(JSON.stringify({
      project: {
        id: 'project-1',
        execution: { status: 'running', attempts: 2 },
        agent: { id: 'agent-1', execution: { credential: 'secret' } },
      },
    }), { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    expect(await handlers.get('desktop:kswarm:proxy:get')?.({}, '/projects/project-1')).toEqual({
      project: {
        id: 'project-1',
        execution: { status: 'running', attempts: 2 },
        agent: { id: 'agent-1' },
      },
    });
  });

  it('keeps postJson null semantics for an empty successful response', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(null, { status: 204 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    expect(await handlers.get('desktop:kswarm:proxy:postJson')?.(
      {},
      '/projects/project-1/continue',
      {},
    )).toBeNull();
  });

  it('rejects secret-bearing bodies even on an otherwise allowed write route', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response('{}', { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    expect(await handlers.get('desktop:kswarm:proxy:post')?.(
      {},
      '/projects/project-1/tasks',
      { tasks: [{ title: 'Review', provider: 'openai', apiKey: 'secret' }] },
    )).toBeNull();
    expect(request).not.toHaveBeenCalled();
  });

  it('denies unknown routes by default while preserving query parameters on allowed reads', async () => {
    const { ipcMain, handlers } = createIpcMainMock();
    const request = vi.fn(async () => new Response(JSON.stringify({ models: ['safe'] }), { status: 200 }));
    registerKSwarmProxy(
      ipcMain as never,
      { subscribe: vi.fn(), unsubscribe: vi.fn(), getConnectionStatus: vi.fn(() => 'connected') } as never,
      { request, getDesktopMutationToken: () => 'desktop-token' },
    );

    expect(await handlers.get('desktop:kswarm:proxy:get')?.({}, '/future/admin/export')).toBeNull();
    expect(await handlers.get('desktop:kswarm:proxy:get')?.({}, '/llm/models?provider=openai')).toEqual({ models: ['safe'] });
    expect(request).toHaveBeenCalledTimes(1);
    expect(request).toHaveBeenCalledWith('/llm/models?provider=openai', expect.objectContaining({ method: 'GET' }));
  });
});
