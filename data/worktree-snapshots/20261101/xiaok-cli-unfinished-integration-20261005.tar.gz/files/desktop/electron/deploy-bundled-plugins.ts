/**
 * Deploy Bundled Plugins
 *
 * On app startup, copies bundled plugins from Resources to ~/.xiaok/plugins/
 * with version-aware upgrade logic. Also sets up Python venv for slide-renderer.
 */

import { app } from 'electron';
import { randomUUID } from 'node:crypto';
import { join, dirname, basename } from 'node:path';
import { existsSync, cpSync, lstatSync, mkdirSync, readFileSync, readdirSync, rmSync, renameSync, writeFileSync } from 'node:fs';
import { getConfigDir } from '../../src/utils/config.js';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { detectPythonCompatibilityTag, ensureSlideRendererPythonReady, isCompatibleSlideRendererWheelhouse } from './python-runtime.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const execFileAsync = promisify(execFile);

const BUNDLED_PLUGINS = ['kai-report-creator', 'kai-slide-creator', 'cua-computer-use', 'kai-infinity-canvas', 'kai-meeting-assistant'];

/** Semver-aware: returns true if a >= b */
function semverGte(a: string, b: string): boolean {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return true;
    if ((pa[i] || 0) < (pb[i] || 0)) return false;
  }
  return true; // equal
}

export function resolveBundledPluginsDir(): string | null {
  const candidates = app.isPackaged
    ? [join(process.resourcesPath, 'bundled-plugins')]
    : [
        // Built dev main: desktop/dist/main/desktop/electron -> ../../../../../../kai-xiaok-plugins/plugins
        join(__dirname, '..', '..', '..', '..', '..', '..', 'kai-xiaok-plugins', 'plugins'),
        // Source-tree dev fallback.
        join(__dirname, '..', '..', 'kai-xiaok-plugins', 'plugins'),
        // CWD fallbacks for launching from desktop/ or repo root.
        join(process.cwd(), '..', '..', 'kai-xiaok-plugins', 'plugins'),
        join(process.cwd(), '..', 'kai-xiaok-plugins', 'plugins'),
      ];

  return candidates.find(candidate => existsSync(candidate)) ?? null;
}

export interface DeployResult {
  deployed: string[];
  pythonAvailable: boolean;
  venvReady: boolean;
  pythonCommand?: string;
  dependencyInstallMode?: string;
  bundledWheelsUsable?: boolean;
}

export interface BundledPluginFileDeployment {
  deployed: string[];
  pythonState: 'not_started';
  bundledDir: string | null;
  slideWheelhouseCompatTargets: Array<{ dest: string; src: string }>;
}

export interface ManagedPythonVenvOptions {
  pythonCmd: string;
  venvDir: string;
  venvPython: string;
  exec?: typeof execFileAsync;
}

export async function ensureManagedPythonVenv(options: ManagedPythonVenvOptions): Promise<boolean> {
  const exec = options.exec ?? execFileAsync;

  try {
    await exec(options.pythonCmd, ['-m', 'venv', options.venvDir], { timeout: 30_000 });
    return existsSync(options.venvPython);
  } catch {
    // Some Windows Python installs have a working global pip but a broken
    // ensurepip payload. Avoid bundling Python by creating the venv without pip
    // and then asking global pip to bootstrap pip into that venv.
  }

  try {
    await exec(options.pythonCmd, ['-m', 'venv', '--without-pip', options.venvDir], { timeout: 30_000 });
    if (!existsSync(options.venvPython)) return false;
    await exec(options.pythonCmd, [
      '-m', 'pip',
      '--python', options.venvPython,
      'install', 'pip',
      '--disable-pip-version-check',
    ], { timeout: 120_000 });
    return true;
  } catch {
    return false;
  }
}

export async function ensureHealthyManagedPythonVenv(
  options: Omit<ManagedPythonVenvOptions, 'pythonCmd'> & { candidates: string[] },
): Promise<boolean> {
  const exec = options.exec ?? execFileAsync;
  const usable = async (command: string) => {
    const tag = await detectPythonCompatibilityTag(command, exec);
    // The bundled MCP SDK requires Python >= 3.10.
    return tag !== null && Number(tag.slice(2)) >= 310;
  };
  if (existsSync(options.venvPython) && await usable(options.venvPython)) return true;

  let pythonCmd: string | undefined;
  for (const candidate of options.candidates) {
    if (await usable(candidate)) { pythonCmd = candidate; break; }
  }
  if (!pythonCmd) return false;

  mkdirSync(dirname(options.venvDir), { recursive: true });
  const backup = existsSync(options.venvDir)
    ? join(dirname(options.venvDir), `.${basename(options.venvDir)}.backup-${randomUUID()}`)
    : undefined;
  if (backup) renameSync(options.venvDir, backup);
  let ready = false;
  try {
    ready = await ensureManagedPythonVenv({ ...options, pythonCmd, exec })
      && await usable(options.venvPython);
    return ready;
  } finally {
    // Build at the final path: moving a completed venv breaks its entrypoints.
    // Failed recreation must never discard the user's original environment.
    if (!ready) {
      rmSync(options.venvDir, { recursive: true, force: true });
      if (backup) renameSync(backup, options.venvDir);
    }
  }
}

export function ensureReportRendererCssCompat(pluginDir: string): void {
  const distDir = join(pluginDir, 'mcp-servers', 'report-renderer', 'dist');
  const legacyCssDir = join(distDir, 'css');
  const themedCssDir = join(distDir, 'themes', 'css');

  if (!existsSync(themedCssDir) || existsSync(legacyCssDir)) {
    return;
  }

  mkdirSync(legacyCssDir, { recursive: true });
  cpSync(themedCssDir, legacyCssDir, { recursive: true });
}

export function ensureReportRendererDistCompat(pluginDir: string, bundledPluginDir: string): void {
  const bundledDistDir = join(bundledPluginDir, 'mcp-servers', 'report-renderer', 'dist');
  const installedDistDir = join(pluginDir, 'mcp-servers', 'report-renderer', 'dist');
  if (!existsSync(bundledDistDir)) return;

  const criticalFiles = [
    join(installedDistDir, 'server.bundle.js'),
    join(installedDistDir, 'renderer', 'html-builder.js'),
  ];
  if (criticalFiles.every(file => existsSync(file))) {
    return;
  }

  mkdirSync(dirname(installedDistDir), { recursive: true });
  rmSync(installedDistDir, { recursive: true, force: true });
  cpSync(bundledDistDir, installedDistDir, { recursive: true });
  ensureReportRendererCssCompat(pluginDir);
}

/**
 * Ensure the kai-infinity-canvas canvas-server MCP can launch from the installed
 * plugin. Its only load-time hard dependency is `fractional-indexing-jittered`
 * (zero-dep, pure JS); `sharp` is imported dynamically and is optional. When a
 * same-version bundled-managed install is missing this dependency (e.g. an older
 * deploy that copied the plugin before node_modules was packaged), the MCP server
 * crashes on startup with ERR_MODULE_NOT_FOUND and its canvas-read tools
 * (kai_canvas_get_content / kai_canvas_export_png / ...) never register — which
 * pushes the agent to fall back to Computer Use to "see" the canvas. Repair it
 * from the bundled source, mirroring ensureReportRendererDistCompat.
 */
export function ensureCanvasServerDepsCompat(pluginDir: string, bundledPluginDir: string): void {
  const depRelative = join('node_modules', 'fractional-indexing-jittered');
  const installedDep = join(pluginDir, depRelative);
  const bundledDep = join(bundledPluginDir, depRelative);
  if (!existsSync(bundledDep)) return;
  if (existsSync(join(installedDep, 'package.json'))) return;

  mkdirSync(dirname(installedDep), { recursive: true });
  rmSync(installedDep, { recursive: true, force: true });
  cpSync(bundledDep, installedDep, { recursive: true });
}

export function ensureMeetingTranscriberCompat(pluginDir: string, bundledPluginDir: string): void {
  const files = [
    join('mcp-servers', 'meeting-transcriber', 'server.py'),
    join('mcp-servers', 'meeting-transcriber', 'requirements.txt'),
  ];

  for (const relativePath of files) {
    const bundledFile = join(bundledPluginDir, relativePath);
    if (!existsSync(bundledFile)) continue;

    const installedFile = join(pluginDir, relativePath);
    if (existsSync(installedFile) && readFileSync(installedFile, 'utf8') === readFileSync(bundledFile, 'utf8')) {
      continue;
    }

    mkdirSync(dirname(installedFile), { recursive: true });
    cpSync(bundledFile, installedFile);
  }
}

export function ensureSlideRendererWheelhouseCompat(
  pluginDir: string,
  bundledPluginDir: string,
  pythonTag?: string,
): void {
  const bundledWheelsDir = join(bundledPluginDir, 'bundled-wheels');
  if (!existsSync(bundledWheelsDir)) return;

  const bundledWheelNames = readdirSync(bundledWheelsDir);
  if (!isCompatibleSlideRendererWheelhouse(bundledWheelNames, process.platform, process.arch, pythonTag)) {
    return;
  }

  const installedWheelsDir = join(pluginDir, 'bundled-wheels');
  const installedWheelNames = existsSync(installedWheelsDir) ? readdirSync(installedWheelsDir) : [];
  const installedMatchesBundled = sortedWheelNames(installedWheelNames).join('\n')
    === sortedWheelNames(bundledWheelNames).join('\n');

  if (installedMatchesBundled) return;

  rmSync(installedWheelsDir, { recursive: true, force: true });
  cpSync(bundledWheelsDir, installedWheelsDir, { recursive: true });
}

function sortedWheelNames(wheelNames: string[]): string[] {
  return wheelNames
    .filter(name => name.toLowerCase().endsWith('.whl'))
    .map(name => name.toLowerCase())
    .sort();
}

function isSymlink(path: string): boolean {
  try {
    return lstatSync(path).isSymbolicLink();
  } catch {
    return false;
  }
}

function backupExistingPlugin(pluginPath: string, pluginName: string): void {
  const backupRoot = getConfigDir('.symlink-backups');
  mkdirSync(backupRoot, { recursive: true });
  const backupPath = join(backupRoot, `${pluginName}-${Date.now()}`);
  renameSync(pluginPath, backupPath);
}

export function deployBundledPluginFiles(): BundledPluginFileDeployment {
  const result: BundledPluginFileDeployment = {
    deployed: [],
    pythonState: 'not_started',
    bundledDir: null,
    slideWheelhouseCompatTargets: [],
  };
  const pluginsDir = getConfigDir('plugins');
  mkdirSync(pluginsDir, { recursive: true });

  // Legacy migration: kai-canvas-creator → kai-infinity-canvas (renamed in v1.4.15).
  // Move the old folder aside so it does not load alongside the new plugin.
  try {
    const legacyCanvasDir = join(pluginsDir, 'kai-canvas-creator');
    if (existsSync(legacyCanvasDir) && !isSymlink(legacyCanvasDir)) {
      const backup = join(pluginsDir, 'kai-canvas-creator.legacy-backup');
      if (existsSync(backup)) rmSync(backup, { recursive: true, force: true });
      renameSync(legacyCanvasDir, backup);
    }
  } catch {
    // legacy migration is best-effort; never block deploy
  }

  const bundledDir = resolveBundledPluginsDir();
  result.bundledDir = bundledDir;

  if (!bundledDir) return result;

  // 1. Copy plugin files (version-aware)
  for (const name of BUNDLED_PLUGINS) {
    const src = join(bundledDir, name);
    const dest = join(pluginsDir, name);
    if (!existsSync(src)) continue;

    const srcManifest = join(src, 'plugin.json');
    const destManifest = join(dest, 'plugin.json');
    if (isSymlink(dest)) {
      backupExistingPlugin(dest, name);
    }

    if (existsSync(destManifest)) {
      try {
        const srcVer = JSON.parse(readFileSync(srcManifest, 'utf8')).version || '0.0.0';
        const destMeta = JSON.parse(readFileSync(destManifest, 'utf8'));
        const destVer = destMeta.version || '0.0.0';
        // Skip if installed version >= bundled AND not managed by us
        if (semverGte(destVer, srcVer) && destMeta.source !== 'bundled') continue;
        if (semverGte(destVer, srcVer)) {
          if (name === 'kai-report-creator') {
            ensureReportRendererDistCompat(dest, src);
            ensureReportRendererCssCompat(dest);
          }
          if (name === 'kai-infinity-canvas') {
            ensureCanvasServerDepsCompat(dest, src);
          }
          if (name === 'kai-meeting-assistant') {
            ensureMeetingTranscriberCompat(dest, src);
          }
          if (name === 'kai-slide-creator') {
            result.slideWheelhouseCompatTargets.push({ dest, src });
          }
          continue;
        }
      } catch {
        // parse error, overwrite
      }
    }

    cpSync(src, dest, { recursive: true });
    if (name === 'kai-report-creator') {
      ensureReportRendererDistCompat(dest, src);
      ensureReportRendererCssCompat(dest);
    }
    if (name === 'kai-infinity-canvas') {
      ensureCanvasServerDepsCompat(dest, src);
    }
    if (name === 'kai-meeting-assistant') {
      ensureMeetingTranscriberCompat(dest, src);
    }
    if (name === 'kai-slide-creator') {
      result.slideWheelhouseCompatTargets.push({ dest, src });
    }
    // Mark as bundled-managed
    try {
      const manifest = JSON.parse(readFileSync(join(dest, 'plugin.json'), 'utf8'));
      manifest.source = 'bundled';
      writeFileSync(join(dest, 'plugin.json'), JSON.stringify(manifest, null, 2));
    } catch {
      // ignore
    }
    result.deployed.push(name);
  }

  return result;
}

export async function prepareBundledPluginPythonRuntime(
  deployment: BundledPluginFileDeployment,
): Promise<DeployResult> {
  const result: DeployResult = {
    deployed: deployment.deployed,
    pythonAvailable: false,
    venvReady: false,
  };
  const bundledDir = deployment.bundledDir;
  if (!bundledDir) return result;

  // 2. Setup Python venv for slide-renderer.
  // Prefer an existing managed venv even when the launched app cannot see a
  // global Python on PATH; Explorer-launched Windows apps often inherit a
  // different PATH than the user's terminal.
  const venvDir = getConfigDir(join('runtime', 'python-env'));
  const venvPython = process.platform === 'win32'
    ? join(venvDir, 'Scripts', 'python.exe')
    : join(venvDir, 'bin', 'python3');
  const bundledPython = join(bundledDir, 'kai-slide-creator', 'bundled-python',
    `${process.platform}-${process.arch}`, 'python',
    ...(process.platform === 'win32' ? ['python.exe'] : ['bin', 'python3']));
  const candidates = [bundledPython, ...(process.platform === 'win32' ? ['python', 'py'] : ['python3', 'python'])];
  const healthy = await ensureHealthyManagedPythonVenv({ venvDir, venvPython, candidates });
  result.pythonAvailable = healthy;
  if (!healthy) return result;

  if (existsSync(venvPython)) {
    const pythonTag = await detectPythonCompatibilityTag(venvPython);
    for (const target of deployment.slideWheelhouseCompatTargets) {
      ensureSlideRendererWheelhouseCompat(target.dest, target.src, pythonTag ?? undefined);
    }

    // Install from bundled wheels (no network), then fall back to online pip
    // only if the environment is not already usable.
    const wheelsDir = app.isPackaged
      ? join(process.resourcesPath, 'bundled-plugins', 'kai-slide-creator', 'bundled-wheels')
      : join(bundledDir, 'kai-slide-creator', 'bundled-wheels');
    const wheelsUsable = existsSync(wheelsDir) && isCompatibleSlideRendererWheelhouse(
      readdirSync(wheelsDir),
      process.platform,
      process.arch,
      pythonTag ?? undefined,
    );
    result.bundledWheelsUsable = wheelsUsable;

    const depsMarker = join(venvDir, '.deps-installed');
    const runtimeReady = await ensureSlideRendererPythonReady({
      venvPython,
      wheelsDir: wheelsUsable ? wheelsDir : undefined,
      markerPath: depsMarker,
      markerExists: existsSync(depsMarker),
      writeMarker: (markerPath) => {
        writeFileSync(markerPath, new Date().toISOString());
      },
    });
    result.venvReady = runtimeReady.ready;
    result.dependencyInstallMode = runtimeReady.mode;
    if (runtimeReady.ready) result.pythonCommand = venvPython;
  }

  return result;
}

/** Compatibility entry point for callers that explicitly need eager readiness. */
export async function deployBundledPlugins(): Promise<DeployResult> {
  return prepareBundledPluginPythonRuntime(deployBundledPluginFiles());
}
