import type { RoomListResultDto, RoomSnapshotDto, RoomCreateResultDto, RoomArchiveResultDto, RoomDeleteResultDto, RoomMembersResultDto, RoomSendResultDto, RoomSeenResultDto, RoomCancelResultDto, RoomProjectCreateResultDto, RoomTaskCreateResultDto } from '../shared/collaboration-room-ipc-contract.js';
/**
 * CollaborationRoom semantic service (design §9, §12, §16.3).
 *
 * Electron main owns this service. The renderer never talks to the broker
 * directly: every room mutation goes through a semantic method here, and
 * user mutations are pinned to the local owner identity — renderer-supplied
 * requestSource / actor / scopes fields are ignored, never forwarded.
 *
 * Project truth in composed snapshots comes from KSwarm, never from room
 * event payloads (design §16.3: the composer must not treat event payloads
 * as project state).
 */
import { randomUUID } from 'node:crypto';
import { basename } from 'node:path';
import type { CollaborationRoomDispatchEvent } from './collaboration-room-wake-dispatcher.js';
import { XIAOK_WORKER_SEED_ID } from '../shared/kswarm-seed-contract.js';
import { roomAgentNames } from '../shared/room-agent-names.js';

export interface CollaborationRoomActorContext {
  sessionId: string;
  requestSource: 'user';
  actor: { kind: 'user'; userId: string };
  allowedLogicalAgentIds: string[];
  issuedAt: string;
}

interface RoomProjectSagaJournalPort {
  prepare(input: { operationId: string; clientRequestKey: string; roomId: string; expectedRoomRevision: number; sourceMessageIds: string[] }): { ok: boolean; code?: string };
  markProjectObserved(operationId: string, projectId: string): unknown;
  markRoomEventObserved(operationId: string, projectionEventId: string): unknown;
  complete(operationId: string, options?: { outcome?: string }): unknown;
}

export interface RoomAgentExecutionCapability {
  logicalAgentId: string;
  mode: 'workspace_worker' | 'discussion_only' | 'discussion_unavailable';
  runtime?: string;
  reason?: string;
}

const LOCAL_OWNER_USER_ID = 'user.local';
const MAX_ROOM_ATTACHMENTS = 20;
const MAX_ROOM_ATTACHMENT_PATH_LENGTH = 4096;
const ROOM_MENTION_BOUNDARY = '[\\s，。！？、,.;:!?）)\\]】}\\}]';

function localOwnerContext(): CollaborationRoomActorContext {
  return {
    sessionId: 'desktop-main-user',
    requestSource: 'user',
    actor: { kind: 'user', userId: LOCAL_OWNER_USER_ID },
    allowedLogicalAgentIds: [],
    issuedAt: new Date().toISOString(),
  };
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim() !== '';
}

function activeAgentIdsFromSnapshot(snapshot: unknown): string[] {
  if (!snapshot || typeof snapshot !== 'object' || !Array.isArray((snapshot as { members?: unknown }).members)) return [];
  return [...new Set((snapshot as {
    members: Array<{ status?: unknown; subject?: { kind?: unknown; logicalAgentId?: unknown } }>;
  }).members
    .filter(member => member.status === 'active'
      && member.subject?.kind === 'agent'
      && isNonEmptyString(member.subject.logicalAgentId))
    .map(member => member.subject!.logicalAgentId as string))];
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function containsRoomMention(text: string, logicalAgentId: string): boolean {
  return new RegExp(`(^|\\s)@${escapeRegExp(logicalAgentId)}(?=$|${ROOM_MENTION_BOUNDARY})`, 'u').test(text);
}

function canonicalRoomRoute(text: string, activeAgentIds: string[], names = new Map<string, string>()): {
  mentions: Array<{ kind: 'all' } | { kind: 'agent'; logicalAgentId: string }>;
  logicalAgentIds: string[];
  usedDefault: boolean;
} {
  const sortedActiveAgentIds = [...new Set(activeAgentIds)].sort();
  if (containsRoomMention(text, 'all')) {
    return { mentions: [{ kind: 'all' }], logicalAgentIds: sortedActiveAgentIds, usedDefault: false };
  }
  const handles = new Map(sortedActiveAgentIds.map(id => [id, id]));
  for (const [id, label] of names) handles.set(label, id);
  const pattern = [...handles.keys()].sort((a, b) => b.length - a.length).map(escapeRegExp).join('|');
  const matched = new Set(pattern ? [...text.matchAll(new RegExp(`(^|\\s)@(${pattern})(?=$|${ROOM_MENTION_BOUNDARY})`, 'gu'))].map(match => handles.get(match[2])) : []);
  const mentionedAgentIds = sortedActiveAgentIds.filter(id => matched.has(id));
  if (mentionedAgentIds.length > 0) {
    return {
      mentions: mentionedAgentIds.map(logicalAgentId => ({ kind: 'agent' as const, logicalAgentId })),
      logicalAgentIds: mentionedAgentIds,
      usedDefault: false,
    };
  }
  return {
    mentions: [{ kind: 'agent', logicalAgentId: XIAOK_WORKER_SEED_ID }],
    logicalAgentIds: [XIAOK_WORKER_SEED_ID],
    usedDefault: true,
  };
}

function sanitizeRoomAttachmentPaths(value: unknown): Array<{ filePath: string; name: string }> {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const attachments: Array<{ filePath: string; name: string }> = [];
  for (const candidate of value) {
    if (!isNonEmptyString(candidate) || candidate.length > MAX_ROOM_ATTACHMENT_PATH_LENGTH || seen.has(candidate)) continue;
    seen.add(candidate);
    attachments.push({ filePath: candidate, name: basename(candidate) || candidate });
    if (attachments.length >= MAX_ROOM_ATTACHMENTS) break;
  }
  return attachments;
}

export interface CollaborationRoomService {
  listRooms(): Promise<RoomListResultDto>;
  getRoom(roomId: string): Promise<RoomSnapshotDto>;
  createRoom(input: Record<string, unknown>, authority?: { requestSource: 'user'; signal?: AbortSignal }): Promise<RoomCreateResultDto>;
  archiveRoom(input: Record<string, unknown>): Promise<RoomArchiveResultDto>;
  deleteRoom(input: unknown, authority?: { requestSource: 'user' | 'agent' | 'scheduler' }): Promise<RoomDeleteResultDto>;
  updateRoomMembers(input: Record<string, unknown>): Promise<RoomMembersResultDto>;
  sendMessage(input: Record<string, unknown>): Promise<RoomSendResultDto>;
  markRoomSeen(input: Record<string, unknown>): Promise<RoomSeenResultDto>;
  cancelDiscussion(input: Record<string, unknown>): Promise<RoomCancelResultDto>;
  createProjectFromRoom(input: Record<string, unknown>): Promise<RoomProjectCreateResultDto>;
  createTaskFromRoomMessage(input: Record<string, unknown>): Promise<RoomTaskCreateResultDto>;
}

export function createCollaborationRoomService({
  brokerClient,
  kswarmClient,
  sagaJournal,
  wakeDispatcher,
  emitRoomEvent,
  getExecutionCapabilities,
  stopRoomExecution,
  prepareRoomDefaults,
}: {
  brokerClient: {
    createRoom: (input: unknown, ctx: unknown) => Promise<unknown>;
    archiveRoom: (input: unknown, ctx: unknown) => Promise<unknown>;
    deleteRoom?: (input: unknown, ctx: unknown) => Promise<unknown>;
    updateRoomMembers: (input: unknown, ctx: unknown) => Promise<unknown>;
    sendRoomMessage: (input: unknown, ctx: unknown) => Promise<unknown>;
    markRoomSeen: (input: unknown, ctx: unknown) => Promise<unknown>;
    cancelDiscussion?: (input: unknown, ctx: unknown) => Promise<unknown>;
    getRoomSnapshot: (roomId: string) => Promise<unknown>;
    listRooms?: () => Promise<unknown>;
  };
  kswarmClient: {
    request: (path: string, init?: unknown) => Promise<{ ok: boolean; json: () => Promise<unknown> }>;
  };
  prepareRoomDefaults?: (input: Record<string, unknown>, signal?: AbortSignal) => Promise<{title:string;description:string;memberAgentIds:string[]}>;
  sagaJournal?: RoomProjectSagaJournalPort;
  wakeDispatcher?: {
    dispatchMessage(input: { roomId: string; roomMessageId: string; logicalAgentIds: string[] }): Promise<unknown>;
  };
  emitRoomEvent?: (event: CollaborationRoomDispatchEvent) => void;
  getExecutionCapabilities?: (agentIds?: string[]) => Promise<RoomAgentExecutionCapability[]>;
  stopRoomExecution?: (roomId: string) => Promise<unknown>;
}) {
  /** Renderer identity fields are transport facts — strip them, pin the owner. */
  function userCtx(): CollaborationRoomActorContext {
    return localOwnerContext();
  }

  async function resolveAgentNames(snapshot: unknown) {
    const members = (snapshot as { members?: Array<{ alias?: string; status?: string; subject?: { kind?: string; logicalAgentId?: string } }> }).members ?? [];
    let agents: Array<{ id: string; name?: string }> = [];
    try {
      const response = await kswarmClient.request('/agents');
      if (response.ok) { const body = await response.json() as { agents?: typeof agents }; if (Array.isArray(body.agents)) agents = body.agents; }
    } catch { /* Stable readable fallback when the catalog is unavailable. */ }
    return roomAgentNames(members.filter(m => m.status === 'active' && m.subject?.kind === 'agent' && m.subject.logicalAgentId).map(m => ({ id: m.subject!.logicalAgentId!, alias: m.alias, name: agents.find(a => a.id === m.subject!.logicalAgentId)?.name })));
  }

  async function callBroker(method: keyof typeof brokerClient, input: unknown) {
    const fn = brokerClient[method] as (input: unknown, ctx: unknown) => Promise<Record<string, unknown>>;
    try {
      const result = await fn(input, userCtx());
      if (result && typeof result === 'object' && result.ok === false) {
        return result;
      }
      return result;
    } catch {
      return { ok: false, code: 'broker_unavailable' };
    }
  }

  const roomCreations = new Map<string, {signature:string;promise:Promise<unknown>}>();
  const roomDrafts = new Map<string, {signature:string;draft:{title:string;description:string;memberAgentIds:string[]}}>();
  async function createRoom(input: Record<string, unknown>, authority?: {requestSource:'user';signal?:AbortSignal}) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) return {ok:false,code:'room_input_invalid'};
    if (authority && authority.requestSource!=='user') return {ok:false,code:'room_actor_forbidden'};
    authority?.signal?.throwIfAborted();
    const key = isNonEmptyString(input.clientRequestKey) ? input.clientRequestKey : '';
    if (input.clientRequestKey!==undefined && (!isNonEmptyString(input.clientRequestKey) || key.length>256)) return {ok:false,code:'room_input_invalid'};
    const signature = JSON.stringify({goal:input.goal,title:input.title,description:input.description,memberAgentIds:input.memberAgentIds});
    const prior = key ? roomCreations.get(key) : undefined;
    if (prior) return prior.signature===signature ? prior.promise : {ok:false,code:'room_create_request_conflict'};
    const draft = key ? roomDrafts.get(key) : undefined;
    if (draft && draft.signature!==signature) return {ok:false,code:'room_create_request_conflict'};
    const run = createRoomOnce(input,authority,key,signature).finally(()=>{if(key)roomCreations.delete(key);});
    if (key) roomCreations.set(key,{signature,promise:run});
    return run;
  }
  async function createRoomOnce(input: Record<string, unknown>, authority: {requestSource:'user';signal?:AbortSignal}|undefined, key:string, signature:string) {
    if (authority && authority.requestSource!=='user') return {ok:false,code:'room_actor_forbidden'};
    authority?.signal?.throwIfAborted();
    if (!input || typeof input !== 'object' || Array.isArray(input)) return {ok:false,code:'room_input_invalid'};
    if (isNonEmptyString(input.goal)) {
      if (!prepareRoomDefaults) return {ok:false,code:'room_defaults_unavailable'};
      try {
        let draft = key ? roomDrafts.get(key)?.draft : undefined;
        if (!draft) {
          draft = await prepareRoomDefaults(input, authority?.signal);
          if (key) {
            if (roomDrafts.size>=100) roomDrafts.delete(roomDrafts.keys().next().value!);
            roomDrafts.set(key,{signature,draft});
          }
        }
        input = {...input,...draft};
      }
      catch { return {ok:false,code:'room_defaults_failed'}; }
    }
    authority?.signal?.throwIfAborted();
    const title = typeof input.title === 'string' ? input.title.trim() : '';
    const memberAgentIds = input.memberAgentIds;
    if (!title || !Array.isArray(memberAgentIds)) {
      return { ok: false, code: 'room_input_invalid' };
    }
    const canonicalMemberAgentIds = [...new Set(
      memberAgentIds.filter(isNonEmptyString).concat(XIAOK_WORKER_SEED_ID),
    )];
    return callBroker('createRoom', {
      title,
      memberAgentIds: canonicalMemberAgentIds,
      ...(isNonEmptyString(input.description) ? { description: input.description } : {}),
      ...(isNonEmptyString(input.clientRequestKey) ? { clientRequestKey: input.clientRequestKey } : {}),
    });
  }

  async function archiveRoom(input: Record<string, unknown>) {
    if (!isNonEmptyString(input.roomId)) return { ok: false, code: 'room_input_invalid' };
    return callBroker('archiveRoom', {
      roomId: input.roomId,
      expectedRoomRevision: input.expectedRoomRevision,
    });
  }

  async function deleteRoom(input: unknown, authority?: { requestSource: 'user' | 'agent' | 'scheduler' }) {
    if (authority?.requestSource !== 'user') return {ok: false, code: 'room_actor_forbidden'};
    if (!input || typeof input !== 'object' || Array.isArray(input)) return {ok: false, code: 'room_input_invalid'};
    const value = input as Record<string, unknown>;
    if (!isNonEmptyString(value.roomId) || !Number.isSafeInteger(value.expectedRoomRevision) || (value.expectedRoomRevision as number) < 1) return {ok: false, code: 'room_input_invalid'};
    const canonical = {roomId: value.roomId, expectedRoomRevision: value.expectedRoomRevision};
    const result = await callBroker('deleteRoom', canonical);
    if (result?.ok === false && result.code === 'room_delete_pending' && stopRoomExecution) {
      // A pending disclosure on an active room must not stop execution. Only
      // settle work after the broker has authorized and fenced this revision.
      try {
        const snapshot = await brokerClient.getRoomSnapshot(value.roomId) as {ok?: boolean; room?: {status?: string; revision?: number}};
        if (snapshot?.ok && snapshot.room?.revision === value.expectedRoomRevision
          && ['archiving', 'archived'].includes(snapshot.room?.status ?? '')) {
          await stopRoomExecution(value.roomId);
          return callBroker('deleteRoom', canonical);
        }
      } catch { /* Keep the broker's honest pending result; never hide the room. */ }
    }
    return result;
  }

  async function updateRoomMembers(input: Record<string, unknown>) {
    if (!isNonEmptyString(input.roomId)) return { ok: false, code: 'room_input_invalid' };
    const addAgentIds = Array.isArray(input.addAgentIds)
      ? [...new Set(input.addAgentIds.filter(isNonEmptyString))]
      : [];
    const removeAgentIds = Array.isArray(input.removeAgentIds)
      ? [...new Set(input.removeAgentIds.filter(isNonEmptyString))]
        .filter((agentId) => agentId !== XIAOK_WORKER_SEED_ID)
      : [];
    return callBroker('updateRoomMembers', {
      roomId: input.roomId,
      expectedRoomRevision: input.expectedRoomRevision,
      addAgentIds,
      removeAgentIds,
      ...(input.aliasChanges !== undefined ? { aliasChanges: input.aliasChanges } : {}),
    });
  }

  async function sendMessage(input: Record<string, unknown>) {
    if (!isNonEmptyString(input.roomId) || !isNonEmptyString(input.text)) {
      return { ok: false, code: 'room_input_invalid' };
    }
    let snapshot: unknown;
    try {
      snapshot = await brokerClient.getRoomSnapshot(input.roomId);
    } catch {
      return { ok: false, code: 'broker_unavailable' };
    }
    if (!snapshot || typeof snapshot !== 'object' || (snapshot as { ok?: unknown }).ok === false) {
      return { ok: false, code: (snapshot as { code?: unknown })?.code ?? 'room_not_found' };
    }
    let activeAgentIds = activeAgentIdsFromSnapshot(snapshot);
    const agentNames = await resolveAgentNames(snapshot);
    let route = canonicalRoomRoute(input.text.trim(), activeAgentIds, agentNames);
    if (route.usedDefault && /(^|\s)@\S/u.test(input.text)) return { ok: false, code: 'room_mention_unknown' };
    if (route.usedDefault && !activeAgentIds.includes(XIAOK_WORKER_SEED_ID)) {
      const room = (snapshot as { room?: { revision?: unknown } }).room;
      const backfill = await callBroker('updateRoomMembers', {
        roomId: input.roomId,
        expectedRoomRevision: typeof room?.revision === 'number' ? room.revision : undefined,
        addAgentIds: [XIAOK_WORKER_SEED_ID],
        removeAgentIds: [],
      });
      if (!backfill || backfill.ok === false) {
        return { ok: false, code: 'room_default_agent_unavailable', cause: backfill?.code };
      }
      activeAgentIds = [...activeAgentIds, XIAOK_WORKER_SEED_ID];
      route = canonicalRoomRoute(input.text.trim(), activeAgentIds, agentNames);
    }
    let logicalAgentIds = route.logicalAgentIds;
    const unavailable: Array<{ logicalAgentId: string; reason: string }> = [];
    if (getExecutionCapabilities) {
      const capabilities = await getExecutionCapabilities(logicalAgentIds).catch(() => []);
      logicalAgentIds = logicalAgentIds.filter(logicalAgentId => {
        const capability = capabilities.find(item => item.logicalAgentId === logicalAgentId);
        if (capability?.mode === 'workspace_worker' || capability?.mode === 'discussion_only') return true;
        unavailable.push({ logicalAgentId, reason: capability?.reason ?? 'unsupported_protocol' });
        return false;
      });
    }
    const attachments = sanitizeRoomAttachmentPaths(input.filePaths);
    const result = await callBroker('sendRoomMessage', {
      roomId: input.roomId,
      text: input.text.trim(),
      mentions: getExecutionCapabilities ? logicalAgentIds.map(logicalAgentId => ({ kind: 'agent', logicalAgentId })) : route.mentions,
      responsePolicy: 'mentioned',
      ...(isNonEmptyString(input.idempotencyKey) ? { idempotencyKey: input.idempotencyKey } : {}),
      ...(isNonEmptyString(input.replyToMessageId) ? { replyToMessageId: input.replyToMessageId } : {}),
      ...(input.contextScope && typeof input.contextScope === 'object' ? { contextScope: input.contextScope } : {}),
      ...(attachments.length > 0 ? {
        sourceRef: { kind: 'user_attachments', attachments },
      } : {}),
    }) as Record<string, unknown>;
    if (!wakeDispatcher || result?.ok === false || !result?.message || typeof result.message !== 'object') {
      return result;
    }
    const message = result.message as Record<string, unknown>;
    const roomMessageId = String(message.messageId);
    const dispatchInput = {
      roomId: input.roomId,
      roomMessageId,
      logicalAgentIds,
    };
    if (logicalAgentIds.length > 0) setImmediate(() => {
      void wakeDispatcher.dispatchMessage(dispatchInput).catch(() => {
        emitRoomEvent?.({
          type: 'discussion_settled',
          roomId: input.roomId as string,
          roomMessageId,
          completed: [],
          failed: logicalAgentIds,
        });
      });
    });
    return {
      ...result,
      wake: {
        status: logicalAgentIds.length > 0 ? 'queued' : 'unavailable',
        roomMessageId,
        logicalAgentIds,
        ...(getExecutionCapabilities ? { unavailable } : {}),
      },
    };
  }

  async function markRoomSeen(input: Record<string, unknown>) {
    if (!isNonEmptyString(input.roomId)) return { ok: false, code: 'room_input_invalid' };
    return callBroker('markRoomSeen', input);
  }

  async function cancelDiscussion(input: Record<string, unknown>) {
    if (!brokerClient.cancelDiscussion) {
      return { ok: false, code: 'room_input_invalid' };
    }
    return callBroker('cancelDiscussion', input);
  }

  interface RoomSnapshotShape {
    ok: boolean;
    requiredProtocol?:string|null;
    code?: string;
    degraded?: boolean;
    room?: { roomId: string; status: string; revision?: number;requiredProtocol?:string|null };
    members?: unknown[];
    messages?: Array<{
      messageId: string;
      kind: string;
      contextScope?: { kind: string; projectId?: string };
      sourceRef?: { projectId?: string; projectionEventId?: string };
    }>;
    projects?: string[];
  }

  /**
   * Compose the room snapshot. Project facts are fetched from KSwarm
   * (authoritative), never rebuilt from room event payloads.
   */
  async function getRoom(roomId: string) {
    let snapshot: RoomSnapshotShape;
    try {
      snapshot = (await brokerClient.getRoomSnapshot(roomId)) as RoomSnapshotShape;
    } catch {
      return { ok: false, code: 'broker_unavailable', degraded: true };
    }
    if (!snapshot || snapshot.ok === false) {
      return { ok: false, code: snapshot?.code ?? 'room_not_found', degraded: snapshot?.degraded };
    }

    const projectIds = Array.isArray(snapshot.projects)
      ? snapshot.projects
      : [
          ...new Set(
            (snapshot.messages ?? [])
              .map((message) => message.sourceRef?.projectId)
              .filter((projectId): projectId is string => typeof projectId === 'string')
          ),
        ];

    const projects: Array<Record<string, unknown>> = [];
    for (const projectId of projectIds) {
      try {
        const response = await kswarmClient.request(`/projects/${projectId}`);
        if (!response || response.ok !== true) continue;
        const body = (await response.json()) as { project?: Record<string, unknown> };
        if (body?.project) projects.push(body.project);
      } catch {
        // degraded: project facts simply stay absent rather than being
        // reconstructed from room event payloads
      }
    }

    const agentNames = await resolveAgentNames(snapshot);
    return {
      ok: true,
      room: snapshot.room,
      members: (snapshot.members ?? []).map(member => {
        const item = member as { subject?: { logicalAgentId?: string } };
        return { ...item, displayName: agentNames.get(item.subject?.logicalAgentId ?? '') };
      }),
      messages: snapshot.messages ?? [],
      projects,
      ...(getExecutionCapabilities ? { executionCapabilities: await getExecutionCapabilities().catch(() => []) } : {}),
    };
  }

  async function listRooms() {
    if (!brokerClient.listRooms) return { ok: false, code: 'broker_unavailable' };
    try {
      return await brokerClient.listRooms();
    } catch {
      return { ok: false, code: 'broker_unavailable' };
    }
  }

  /**
   * Validate that every source message belongs to the room before creating
   * a project from the discussion (design §8.2 step 3).
   */
  async function createProjectFromRoom(input: Record<string, unknown>) {
    const roomId = input.roomId;
    if (!isNonEmptyString(roomId)) return { ok: false, code: 'room_input_invalid' };
    const sourceMessageIds = Array.isArray(input.sourceMessageIds)
      ? (input.sourceMessageIds as unknown[]).filter(isNonEmptyString)
      : [];
    if (sourceMessageIds.length === 0) return { ok: false, code: 'room_input_invalid' };

    let snapshot: RoomSnapshotShape;
    try {
      snapshot = (await brokerClient.getRoomSnapshot(roomId)) as RoomSnapshotShape;
    } catch {
      return { ok: false, code: 'broker_unavailable' };
    }
    if (!snapshot || snapshot.ok === false) {
      return { ok: false, code: snapshot?.code ?? 'room_not_found' };
    }
    const knownMessageIds = new Set((snapshot.messages ?? []).map((message) => message.messageId));
    for (const messageId of sourceMessageIds) {
      if (!knownMessageIds.has(messageId)) {
        return { ok: false, code: 'room_message_not_found', messageId };
      }
    }

    const clientRequestKey = isNonEmptyString(input.clientRequestKey)
      ? input.clientRequestKey
      : `room-project:${randomUUID()}`;
    const operationId = `room-project-op:${randomUUID()}`;
    const expectedRoomRevision = Number(snapshot.room?.revision ?? 0);
    if (sagaJournal) {
      const prepared = sagaJournal.prepare({
        operationId,
        clientRequestKey,
        roomId,
        expectedRoomRevision,
        sourceMessageIds,
      });
      if (!prepared.ok && prepared.code !== 'room_project_operation_duplicate') {
        return { ok: false, code: prepared.code ?? 'room_project_operation_failed' };
      }
    }

    // The trusted user create is performed by the saga owner with a pinned
    // user context; KSwarm enforces room subset + lease on its side.
    const response = await kswarmClient.request('/projects/room-first', {
      method: 'POST',
      body: JSON.stringify({
        name: input.name,
        goal: input.goal,
        poAgent: input.poAgentId,
        members: input.memberAgentIds ?? [],
        primaryRoomId: roomId,
        ...((snapshot.requiredProtocol??snapshot.room?.requiredProtocol)==='room_workspace_v1'?{requiredProtocol:'room_workspace_v1'}:{}),
        sourceMessageIds,
        clientRequestKey,
        expectedRoomRevision,
        requestSource: 'user',
      }),
    });
    if (!response || response.ok !== true) {
      return { ok: false, code: 'kswarm_unavailable' };
    }
    const result = (await response.json()) as Record<string, unknown>;
    const project = result.project as { id?: string; roomEventOutbox?: Array<{ projectionEventId?: string; status?: string }> } | undefined;
    const projection = project?.roomEventOutbox?.[0];
    if (sagaJournal && project?.id) {
      sagaJournal.markProjectObserved(operationId, project.id);
      if (projection?.projectionEventId && projection.status === 'published') {
        sagaJournal.markRoomEventObserved(operationId, projection.projectionEventId);
        sagaJournal.complete(operationId);
      } else if (projection?.status === 'suppressed_room_archived') {
        sagaJournal.complete(operationId, { outcome: 'suppressed_room_archived' });
      }
    }
    return result;
  }

  async function createTaskFromRoomMessage(input: Record<string, unknown>) {
    const roomId = input.roomId;
    if (!isNonEmptyString(roomId) || !isNonEmptyString(input.messageId) || !isNonEmptyString(input.projectId)) {
      return { ok: false, code: 'room_input_invalid' };
    }
    let snapshot: RoomSnapshotShape;
    try {
      snapshot = (await brokerClient.getRoomSnapshot(roomId)) as RoomSnapshotShape;
    } catch {
      return { ok: false, code: 'broker_unavailable' };
    }
    if (!snapshot || snapshot.ok === false) {
      return { ok: false, code: snapshot?.code ?? 'room_not_found' };
    }
    const message = (snapshot.messages ?? []).find((item) => item.messageId === input.messageId);
    if (!message) return { ok: false, code: 'room_message_not_found' };
    // the message must belong to the project's primary room scope
    if (message.sourceRef?.projectId && message.sourceRef.projectId !== input.projectId) {
      return { ok: false, code: 'room_scope_mismatch' };
    }

    const response = await kswarmClient.request(`/projects/${input.projectId}/tasks/human`, {
      method: 'POST',
      body: JSON.stringify({
        tasks: [{
          title: input.title,
          brief: input.brief,
          sourceRoomId: roomId,
          sourceMessageId: input.messageId,
        }],
      }),
    });
    if (!response || response.ok !== true) {
      return { ok: false, code: 'kswarm_unavailable' };
    }
    return (await response.json()) as Record<string, unknown>;
  }

  return {
    createRoom,
    archiveRoom,
    deleteRoom,
    updateRoomMembers,
    sendMessage,
    markRoomSeen,
    cancelDiscussion,
    getRoom,
    listRooms,
    createProjectFromRoom,
    createTaskFromRoomMessage,
  } as CollaborationRoomService;
}
