# Fixed installed Codex capture join
Current collector retains Codex full producer event as unsupported-family.
Actual readCapturedSQLiteCodexSources already validates both complete schemas,
all native snapshots/profile-owner strings/messages and exact physical directory
pairs, including null external thread, absent thread and failed initialization.
No general callback/input/checker/new authority is added. Same four opaque
collector objects, all original mapper events/gaps/census/native CHECK remain.

Independent record kinds: codex-session (native persisted id), codex-thread
(routes source original threadId), codex-route (original taskId). None is an
AgentSession definition or a global thread/Task definition for Goal joins.
Route -> actual unique captured Task -> actual unique original AgentSession.
Thread -> every original route within the SAME routes source having exact
threadId. Native row -> every exact thread in the production-validated pair,
matching original nativeId to persisted native row id. All edges are directed
to actual consumers, no Task -> Thread/Native edge, no source-wide union back
into an entity, no basename-only, text-owner or external-id guess.
Only the original producer pair directory canonicalPath/device/inode permits
cross-source linking. Missing/foreign native peer or missing thread remains
unresolved. Orphan native row retains its complete snapshot and unresolved.
native owner and external nativeId are declared external facts, preserved as
unresolved, never translated to session/profile ownership, even when strings
coincide with actual AgentSession IDs. Nullable/empty original external scalars
are retained, not converted into empty source or new owner.

All rows/settings/pairs remain in mapper.events. Source output exists for empty
sources. Native source cost sessions may union all verified consumers of its
original rows, but entity graph is separate. All previous unknown rows/families,
legacy-inventory-required, original native profiles/enrollment and old full
parent migration/capacity/workflow/99/84/review/OS/GH/release gates unchanged.

Actual fixtures instantiate CodexTaskBridge/CodexNativeService and actual Task
host/FileTaskStore/MaterialRegistry. A simulated external Codex client only
supplies external turn events, labelled fixture, not real provider evidence.
The SQLite/native capture/broker registry/importer/mapper remain production;
installed lifetime/UID/IPC/ordinary routing remain explicit existing fixtures.
Bridge completes two actual Tasks on SAME logical thread with separate generated
sessionIds. Save each original identity using actual FileSessionStore; another
real AgentSession has a name equal to logical thread and external owner/native
thread strings. Exact consumers union their own actual Task sessions only.
Test missing captured Task source, duplicate actual Task root and duplicate
Session, missing native peer, foreign-directory peer copied with SAME native
row IDs and orphan/failed-null native histories. Both logical thread name and
native persisted id collisions with actual AgentSession definitions must not
mint implicit sessions. Preserve all original messages/snapshots/settings,
unresolved and actual final CHECK. Do not use fake producer iterators or row
projections. Red precedes production; strict/Main/relevant sibling tests and
actual frozen source code review required before this leaf is complete.


## Code R1/R2 actual BLOCK retained
Dual routes source fixture added, but its first attempted mutation and complete
suite hit the NEW test's implicit 5s Vitest default before assertions. Those
STACK_TRACE_ERROR/remote-close-unknown failures are NOT semantic red evidence.
New dual-source case now explicitly bounded at 15s from its own creation;
all old test deadlines and original parent 99 Intent 15s/300s/1h are unchanged.
No body/entity/source population is removed, no production CHECK is cached or
relaxed, no performance or whole-parent qualification is claimed. Ground truth
comes from original real SQLite native rows and source stat descriptors captured
BEFORE the collector; assert all four original route bodies, both full native
id/owner/snapshot/messages, both external fields exact origins/details and
both complete producer pairs. Re-run actual same-source-filter mutation only
after the bounded fixture reaches genuine relation assertions, restore exact
production bytes, and retain every previous BLOCK/failure artefact.
