## 第五片：TaskSnapshot 原保护读取的取消与实际排空

源码 recoverTask 的最初 observations.readProtection(taskId) 是新增真实异步IO，却在 waitSnapshotRead/trackPending 外 await。期间取消不会让外层及时返回，也不会登记该读取为未排空；保护还没读完时原在途writer wait未进入。这是实际新增入口遗漏，不能仅更新旧raw promise计数刷绿。

沿既有 waitSnapshotRead 包住该真实 readProtection 原promise，不向任何底层IO传AbortSignal，不提前清raw；之后仍用原保护事实、原write queue、原checkpoint+journal及最后fresh completion观测，未知/错误保护继续defaultdeny。保护IO尚pending时外部abort立即以原reason返回，raw obligation直到实际完结仍保留，不触发后续checkpoint读取或late cache。原有cached/noncached/earlyabort/lateENOENT/EIO/current完成显示全部继续保留。

新测试用真实POSIX FIFO放在实际protected-observation session路径，通过真实FileSessionStore.load/readProtection进入OS read；实际writer未供字节时原tracker非settled，取消后reader及时拒绝且没有checkpoint读取；写端随后提供无效JSON使真实IO结束，raw才settled且没有业务fallback。另在正常保护读取后精确到原pending task write queue的等候阶段再abort，核writer继续完成、原queue Promise被实际track，而非即刻abort碰巧跳过该阶段。旧counts按新增保护与已存在fresh completion这两个真实async阶段扩展，并核对应原raw身份，不减原场景。

仅修这个异步入口的track/abandon，现有同步alias解析、同步compatibility读取、其它owner native/profile迁移闸门仍各按父验收保留，不能凭本片票宣称全部physical IO或Main protected writer完成。


### 第五片 R1 BLOCK，真实叶实现纠正

实读 FileSessionStore.load 确认它直接调用loadSync→readFileSync，readProtection虽有async签名，原IO仍同步；只包waitSnapshotRead不能满足FIFO及时取消，撤回该实施方向，尚未修改这片production。Qoder独立实读同样BLOCK；不能把假异步当raw排空。下一版需将本次纯读取放在实际独立Worker，保留同原parser/alias/profile边界和线程实际exit作为raw终态；writeQueue测试核map里原tracked promise而非save返回run；明确跑desktop-task-closure原拒绝以及raw无效保护拒绝。同步CAS/admission读不能顺便改成async，不扩大该片资格。接受BLOCK日志snapshot-protection-design-qoder-r1.log。

全量R1（build前置待补）CLI8033：7906pass/51fail/76pending；Desktop5617：5529pass/54fail/34pending。原未缩验收分母和完整失败JSON保留。此后collector真实ESM装载及worker/encoding原80项80/80。当前worktree的root node_modules原symlink引起D9闭图escape，改为原已安装依赖APFS独立clone，不联网安装或全局npm link；源码/锁SHA记录dependency-isolation.json。补当前源码test:sandbox:build完成，重新跑原编译入口失败集合。


## 第六片：安装controller启动失败的真实lifetime保留

实读 installed-controller.catch：注释要求关闭已创建component并retain lifetime，但retainLifetime只assertCurrent，不像正常close失败分支将lifetime放入强Set failedLifetimes。其它assembly/capacity/lifetime registry均WeakMap/WeakSet。原controller-owner.sqlite锁使用better-sqlite3真实native连接，失去强引用可能被GC关闭并释放，违背未知失败保留lifetime原要求。不是改回自动释放来满足旧4条startup测试。

catch进入清理前就failedLifetimes.add(lifetime)，保留原异常/原拒绝状态，全部cleanup仍逐项尝试，cleanup失败也不丢lifetime。不开新listener、不重新资格、不自动replay或unlock。与正常close失败共用现有强retainer，真正进程终止释放OS锁；不新增外部管理API。

测试仍走实际startInstalledVerificationController和closeInstalledControllerComponents，只mock部署/初始容量leaf。原mapping缺失正常maintenance仍成功close lifetime；integrity failure及normalassembly早期失败核原components关闭而lifetime未close。增加WeakRef+独立child强制GC（测试mockfactory不持返回结果）验证原startupfailed lifetime仍强保留，反例同时核原lifetime close计数0。该测试是真实productionretainer的组件行为，不冒root安装资格。先设计独立复审，再红测试，再一行retainer实现；其它stack构造unknown/cleanup失败与正常close重入测试全部保留。


### 第五片 R2：真实保护读取 Worker，取消与物理终态分离

不再把同步 FileSessionStore.load 包 Promise 假称异步。仅带 TaskSnapshotReadOptions 的 recoverTask 保护读取（最初与 withProtection 最后的重新读取两处）新增 host-only DesktopTaskObservationStore.readProtectionInWorker(taskId)：从该原 store 捕获 resolve(root)、已被实际 canonical routing 更新的 canonicalRoot 和原 taskId，不接受 caller 给 path、脚本、SQL 或 mapper。固定 Worker entry 只实例化原 DesktopTaskObservationStore 与原 FileSessionStore.readProtection，保持原 alias、migration/deletion、完整 parser/初始化/closure 校验，不在 Worker 重实现 JSON 或决定保护。其 constructor 的内部可选 canonicalRoot 仅把原 host 已绑定路径传进同一 reader，普通构造默认保持。写、同步 CAS、readProtectionSync、无 options 的 recoverTask/其它 owner 入口不变；这是原取消读取漏洞修复，不授 protected writer/read authority、不跨旧 profile 命名空间。

Worker response 只为固定 taskId/protection 或固定 protected-unavailable code。Main 校验 taskId/封闭 envelope，并用原 mergeProtectedObservationClosures 校验传回完整 closure；不存在、无效、缺 response、异常 exit、duplicate response 都 default deny。Worker 捕获原异常仅回 unavailable，不将原 snapshot/body/stack写日志；Main drain worker stdout/stderr，但不转用户 transcript。host 原 raw Promise 只有 Worker actual exit=0 且完整匹配成功响应后才成功，未知异常/exit 亦只在实际 exit 后 reject；message 或 parentPort close 不是物理终态。外部 abort 只由原 waitSnapshotRead 放弃 continuation，不传 rawIO signal、不 terminate/unref Worker、不清 tracker，尚阻塞 FIFO 的 worker 保持 original obligation，实际供字节/EOF 后才 exit。初始保护读被取消后不开始 checkpoint/journal、final protection 或 late cache；最后保护读被取消后不新增 completion inspection/cache publication。

生产/dist 与 emitted tests 固定 worker .js，由同目录 import.meta URL 获取；源 TS 开发入口固定 .ts bootstrap 只含可原生解析的 JavaScript 语法，bootstrap 自己 register 本仓库 tsx/esm/api 再动态 import 原 reader。register仅 source .ts 分支、无可由 RPC 改写 loader/entry；正式 .js 分支不依赖 dev tsx。真实本机 probe 已证明只给 Worker execArgv --import tsx 不能转译 parameter property（ERR_UNSUPPORTED_TYPESCRIPT_SYNTAX），在固定 worker bootstrap 注册 tsx/esm/api 后原 DesktopTaskObservationStore.readProtection 与 actual Worker exit0 成功。正式 Electron/Windows sidecar 仍用 compiled entry，无 shell/.cmd。测试子进程原 profile-account setup 的 --import 保留 Worker 默认 inherited execArgv/environment，原 getConfigDir/OS account 的 namespace 和实际 canonical route必须一致，不给 renderer 配置执行路径。

先对这一修订做只读设计审，随后真实 red：在 hashed desktop-observation sidecar 放 FIFO，由真实 FileSessionStore.readFileSync 在 Worker 等供字节；主 heartbeat继续、abort原reason及时拒、raw仍pending、无 checkpoint读取；写端给无效JSON后actual worker exit失败/raw才结算。另真实有效初始化/legacy closure/alias/canonical保护读取、无效closure/migration/deletion拒绝、worker未知exit不回普通结果、cached/uncached/preabort所有旧场景。旧 D4 raw 计数按实际两次保护 Worker 和原 fresh completion 扩充，必须核 worker Promise 身份/原 writer tracked queue，不以减少场景或放大原 timeout刷绿。OS FIFO/cold worker资格只在实际平台报告；所有原桌面task closure/取消/原父验收仍保留。

### 第五片 R3：最终保护取消不得发布缓存

接受 R2 BLOCK。uncached recovery 的 cache.set 移到最终保护读取与 fresh completion observation 都成功、且原 signal 仍未取消之后；任何错误或取消不发布 cache。带 options 的两次保护 raw 各自直接交给 waitSnapshotRead，不把多个 IO 合并为一个 opaque continuation；无 options 保留原读取语义，但同样最后成功才缓存。

增加第二个真实 FIFO 子进程回归：先用原 FileTaskSnapshotStore.save 创建有效 checkpoint 与保护 sidecar；创建全新无缓存 store，把 sidecar 换成 FIFO。第一次 raw tracker 登记后写端供原合法 sidecar 字节，checkpoint/journal 实际读取完成，第二次 raw tracker 登记确认最终保护 Worker 开始，FIFO 再次保持无写端并用独立事件循环 heartbeat 证明主线程未阻塞。此时 abort，原 recover Promise 以同一个 reason 拒绝，最终 raw 保持未结算。写端供合法字节，让原 Worker actual exit 后 raw 才结算；随后恢复原合法 sidecar，删除 checkpoint 和 journal，对同一个 store 再次 recover 必须拒绝 SOL_PI_PROTECTED_HISTORY_STORE_UNAVAILABLE，证明取消没有留下 cache。以 Promise 身份区分两个保护 raw、实际 checkpoint/journal 与 completion，不使用猜测时间或放大旧 timeout；写端 gate 在 finally 供 EOF/字节退出，不能遗留线程。首阶段 FIFO 取消回归继续保留，并在尚未实现 Worker 的旧源码上通过独立父进程 watchdog 明确报告主 heartbeat 停滞，不让测试自身无限死锁。
