**BLOCK**

- **早期 SIGTERM 会在首次登录向导中永久死锁。** `src/commands/chat.ts:422-424` 提前接管信号；缺少 provider key 时，bootstrap 在 `src/commands/chat.ts:471` 等待登录向导。实际 readline prompt `src/commands/login.ts:54-57,122-146` 及 raw secret prompt `src/commands/login.ts:85-114` 均无 host cancellation。信号 finalizer 又在 `src/commands/chat.ts:394-397` 等待 bootstrap，而 bootstrap 只能在 `src/commands/chat.ts:4848` 结算，形成互等。
- **真实反例：** 使用无 API key 的配置启动交互式 `xiaok chat`，停在“输入编号或 provider id”后发送 SIGTERM；进程不会退出，必须再次输入或强杀。现有 `chat-finalization-process.test.ts` 未覆盖登录 bootstrap prompt。
- **修法：** 给登录向导传入 host-owned `AbortSignal`，在 provider、secret、默认模型三个 prompt 上关闭实际 readline、移除 raw listener并恢复 raw mode；早期 dispatcher 同步触发该取消，再等待 bootstrap。补真实 PTY：停在 provider prompt及 secret prompt 时 SIGTERM，均结算原 prompt并退出 143。

原票的 bootstrap resume/commit-error、五 host settled failure、Goal private reason、factory→compound→agent→product→fresh CAS 本轮未发现新反例。本票仅覆盖第七片代码 R2；未运行测试，也不代表父级验收通过。

