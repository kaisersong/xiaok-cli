# Installed metadata namespace confinement (R22)

The real SQLite R21 probe forges session identities through TEMP invocation
and receipt tables while the native census reads main. R20 code review also
identified copied TEMP KSwarm receipts concealing a deleted main receipt.

Fix every semantic SELECT/join and DML in installed-metadata-source,
kswarm-enrollment-store and storage-owner-schema to explicitly name main.
Dynamic table names remain the existing internal fixed inventory; this does
not expose caller SQL. Keep CREATE TABLE declaration text unchanged so exact
schema identity and legacy census hashes remain compatible.

KSwarm also calls unqualified sibling queries in proof-authority and the
completion boundary. Extend its existing shared integrity guard to reject
any TEMP table/view/trigger or attached database other than main/temp.
No production verification path creates TEMP objects or attaches databases.
Inspect the real PRAGMA database_list, default-deny unknown row names. Retain
the exact permitted main publication trigger and writable_schema rejection.
Check at existing before/after callback guard points. This is a security fix,
not a performance optimization. Ordinary non-KSwarm metadata may ignore TEMP
and attached data, since all its semantic reads and census are fixed to main.

Tests precede production: migrate the actual R21 probe into the Source suite,
verify hash, session attribution, native facts and previously issued owner
still refer to main; attached same-name fallback cannot hide missing main;
storage feature reads/writes cannot be shadowed. For KSwarm exercise actual
installed-controller fixture openOwner, resolveOwnerKey, readApprovedRecipe,
readKSwarmApplicationRegistration, completion.inspect and snapshot with TEMP
table, TEMP view or attached receipt concealing a main deletion. Also inject
TEMP table/attachment through the qualified clock after an earlier valid
read and require rejection; assert TEMP DDL rollback, detach attachment in
finally without assuming ATTACH is transactional. Keep native business hard
denial and all existing roster/trigger/rollback checks. Update only exact SQL
spy predicates to main-qualified production text to retain two-connection
WAL/snapshot injection coverage.

Run full related suites, strict TS/Main, governance and changed architecture,
freeze input SHA and independent code review. Preserve the three existing
5000ms growth failures as failures; namespace correctness is not parent
completion, OS grant qualification or metadata target migration readiness.

## R23 adversarial correction: identity resolution precedes the KSwarm guard

R22 design review BLOCK identified TEMP invocations remapping a KSwarm key to
an ordinary enrolled task before the guard selects owner kind. Extend main
qualification to every SQL read/write and fixed dynamic registration row
query in profile-owner-registry and owner-enrollment-authority. This includes
resolveOwnerKey/getProfile/createCapacityOwnerBinding and all registration
read vectors, main catalog existence checks, receipts, challenge/request,
dependency and enrollment activation paths. Keep their CREATE declarations
and all existing callback/fence semantics intact. No caller query added.

Add actual installed fixture tests with a genuine ordinary task registration
and distinct invocation plus genuine KSwarm invocation. Copy profiles,
owners, invocations and receipts into TEMP, then remap only the KS invocation
to the ordinary owner and its genuine committed receipt. Test preexisting
and callback-introduced shadows via actual resolveOwnerKey and capacity
binding. These must never issue ordinary owner identity/binding for KS;
main resolution retains KS identity and therefore rejects namespace through
the shared guard. Include readProfileCapacityOwnerBinding on an already
issued KS binding to verify its fresh revalidation. Parameterize onCurrent
and onClock fixture callbacks, keeping the production issuers intact.

R23 test correction: resolveOwnerKey does not call the clock; the initial
clock identity test had no injected attack and its failure was not evidence.
Use the actual principal callback instead (test fixture optional onPrincipal
leaf), assert attack consumed. Existing qualified clock namespace tests call
completion.inspect and remain unchanged. Re-run exact pre-fix identity
queries with archived originals, restoring reviewed main-qualified code in
finally, then full regression.

R24 code review found one missed literal migration_publication_intents query
in assertMigrationPublished. The R23 design required every semantic SQL;
extend its approved main qualification to this remaining query. Add a real
ordinary task openOwner regression: pending main migration cannot disappear
behind an empty TEMP same-name table; no new read grant may be issued. Audit
all five target files for remaining unqualified FROM/JOIN/INSERT/UPDATE, not
only prefixes assumed by the initial mechanical replacement.
