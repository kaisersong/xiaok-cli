# 源码 Desktop 测试的固定 protection Worker 编译入口 R1

原 A18 latechild.cancel 后持 actualchild，到 root host.drain 冷读/Goal费用确认结束才释放；根真实诊断是 service runtime_blocked=true，store.goalChildReadiness=waiting_children、原取消消息context_applied，不是SQL丢消息。原closeGrace500ms已届满：源码protection Worker每次tsx启动225-234ms，主root多次actualread累积~1.3s。原阻塞正确，不放宽原500ms或跳read/改deadline。

测量同原 actual DesktopTaskObservationStore.readProtectionInWorker missing普通sidecar5次，源码225-234ms；fresh CLI emitted dist compiled真实Worker（同父tsx execArgv）110-121ms。仅是开发loader overhead诊断，不授用户性能收益或所有生产边界资格。原source-specific Worker CPU/FIFO/晚写/未知成本专测继续source入口，不能拿编译fixture替代那些验收。

原Desktop provenance、Goal/revocation、factory等nativeWorker fixtures已经把 delivery-verifier-worker.js固定URL映射到真实源码编译入口，未fakeWorker/result/exit。补一个固定 protection-read-worker.ts URL 映射到fresh测试编译的同源实际 .test-dist/src/runtime/task-host/protection-read-worker.js。beforeAll 必须先真实npm run test:sandbox:build（仅一次fixture主流程，不能直接信旧bundle），固定源码SHA与emitted依赖树fresh digest/artifact记录。或fixture自己tsc编译至其owned临时root，保全部actual .js sibling依赖/NativeWorker Node运行，无只搬单worker后missingdependency。路径仍由本repo固定，workerData/root/taskId/options原样，NativeWorker actual物理创建/message/error/exit/terminate不替换；不得传任务选URL，不用Promise.resolvefakeclean，不关闭nativegate/成本确认。包装计数两个固定Worker原真实start/exit，afterEach原物理相等。

只先给原A18 multi-agent-goal fixture使用，原delivery编译与全部assertions/原500ms grace/原waitFor1000/完整Goal消费门槛不改；新ownerframe/nativeIO专测原 source mode全保。编译entry属于测试入口纠正，不改productcache/readProtection/guard，不为test选原deadline更大。

先故障4红已经真实有效，新增firstWorkerUrl选择/actualstart&exitfact无需重实现payload；再加fixedactualemitted Worker普通/CPU heldread smoke保生产入口。若同源compiled也超过原500ms仍按产品runtimeblock红，不篡改原等待断言。评审必须检查actualfresh依赖与原acceptance是否被替代，不授native权限/其它模型population/installedmetadata/OS父资格。
