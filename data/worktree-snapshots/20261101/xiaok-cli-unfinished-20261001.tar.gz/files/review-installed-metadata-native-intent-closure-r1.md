# Original native Intent contract and whole-subject source attribution

Observed actual readCapturedSessionDocument already validates the entire
ordinary Session body, all Intent records and stages, historical native contract
journals with original Draft/contract hashes, and yields intentSubjects plus
publicationDeclarations.nativeContracts. CapturedProfile mapper retains them
as original complex declarations/gaps. Current installed collector ignores
Intent nodes and searches raw index kind=ownerKind/id, so real native Intent
full-subject owner has no graph Session. Existing independent original native
invocation Sessions do resolve and must stay independent, never substitute
native contract/source matching. No original input slot or gap is removed.

Build private whole canonical IntentHostSubject nodes from actual Session
declarations (file and SQLite), using exact original source Session object.
Intent root and Stage are distinct original entities; record keys use complete
subject identity and no raw intentId/stageId/name/path fallbacks. Node references
the original physical Session object; cannot look up by logical Session name
and choose one across roots. If storedSessionIdentity absent/null, retain
explicit original gap and no claimed AgentSession. Whole subject duplicates
across physical sources remain ambiguous, even if contract hashes match.
All ordinary intent subjects and historical native contracts remain separate
facts; an ordinary plan is not a native contract or approved enrollment.

Native Intent resolves only unique original exact logical owner (UID/account
generation/kind/id) and exact owner key (profile/kind/id), committed intent row
and unique owner_enrollment_intent_contracts receipt, canonical contract_json
identical to intent.intent_contract_json. Parse through original
parseIntentContractEnrollment, owner mapping exact, subject complete. Original
contract-derived expected registration AND historical receipt registration
must each be ordered prefixes of original current intent registration, with
same epoch/source, matching original native authority's intentReceipt contract.
The unique whole-subject source entity must have exactly one actual original
publicationDeclarations.nativeContracts record whose COMPLETE parsed contract
equals receipt.contract and whose original subjects includes this stage/null.
No sessionId-only join or source contract hash-only shortcut. Native receipt
does not issue capacity owner/approval/graph grants; missing/ambiguous/foreign/
noncanonical/mismatched original facts retain concrete unresolved details.
Original pending/reserved/enrolled/retired/stale journal histories remain facts,
not inferred grants. Narrow Stage references its original physical Session;
no parent/sibling graph edge is invented. Existing native invocation identity
join remains independent and real Session ambiguity rules remain unchanged.

Tests: actual FileSessionStore, createIntentPlan/appendIntentToLedger,
SessionExecutionAuthority and actual reserveIntentNativeContract with original
lease/owned ledger. Only installed route/lifetime/IPC/enrollment SQL is explicit
component fixture. Create two same-intent/stage IDs in two physical Session
roots by copying actual produced original durable body; duplicate whole subject
must fail, not first root. Create historical native contract and later active
ordinary plan so native source remains historical. Multiple stages same Session
must resolve exact source. Missing original contract, same subject but changed
valid contract, wrong native mapping/foreign logical or owner/intent receipt
contract mismatch, missing/duplicate receipts, absent/null stored identity,
valid append versus reordered receipt or expected-contract obligations,
and independent invocation-only Sessions all tested. Native receipt mutation
at mapper await and after collection must invalidate complete original census.
Assert full original native journal/Draft/contracts/attempt histories in mapper
and source node original, not parsed DTO replacement. Observe true red before
production. Run complete existing source/capture files, relevant actual
Intent producer/native journal/contract enrollment/mapper and capacity siblings,
strict root/Desktop Main and actual frozen-SHA read-only code review.

Parent requirements unchanged: all original other dependencies/unknown body/
custom root population/full closedU, installed target/four semantic MainStores,
charged growth/atomic ready/native explicit retirement/drain/absence fsync,
all Goal/TaskHost/KSwarm workflows/capacities, original 99 Intent body/time
population, new 84 paired, final same-SHA reviews and complete CLI/Hook/Intl,
OS/UI/TTY/install/download/integration/GitHub/release. This is only the original
readonly Native Intent source attribution, not full Intent workflow acceptance.


## R2 accepts and preserves both actual R1 BLOCKs
Intent/Stage and each original native-contract journal node COPY ONLY the exact
source Session node's direct physical Session identity, never targets.push(Session).
No traversal into that Session's lineage/fork or other historical dependencies.
Existing Session traversal remains unchanged. A test puts real Session B in A's
lineage AND fork; Intent/Stage/native-contract must still own ONLY physical A.
Absent/null stored identity retains an empty direct array and specific gap,
never borrows an ancestor's Session to qualify the native Intent owner.

Every original native contract is its own intent-native-contract entity, storing
the COMPLETE original record (original Draft/hash, full contract/hash, subjects,
all attempts/phase/revision/timestamps), source Session origin and direct identity.
Each Intent/Stage entity stores exact original subject and Session origin; native
matching consumes that source's original native-contract entities only, complete
canonical contract equality AND original subject membership; no DTO substitutes.

Independent population gate: after building nodes, separately iterate immutable
mapper.events and both file/session original Session arrays AGAIN to enumerate
every source/session-origin/subject-array-position and every native-contract-
array-position with complete original-body fingerprint. Compare these expected
slots against the ACTUAL constructed Intent/Stage/native-contract entities'
origins/bodies (not a parallel counter that could increment without a node).
Fail collect with installed_metadata_intent_population if omitted/extra/changed;
do not return a closure handle while keeping complex gaps for an omitted entity.
This second pass does not share node builder loop/condition/active-pointer logic.
Actual same-source entity counts and full original journal bodies are regression
assertions. Add artifact-run production mutations: omit one subject node and,
separately, one native contract node, run the real positive test, require actual
population rejection before handle, then finally restore original exact bytes.
These are production mutation checks, not fake DTO/iterator/checker fixtures.
Both original mapper complex-gap/slot checks remain untouched and still required.

Red R1 retains two fixture errors, not semantic red: original native journal correctly refuses a new contract while an old reservation is pending; wrong-mapping fixture reused one fake owner across three subjects. R2 uses actual Store.advanceIntentNativeContractSubject reserved->enrolling->stale before a later actual reserve, preserving the full historical phases/revisions. Wrong mappings use distinct opaque identities per original subject. No production change yet.


## Final R1 code evidence
Actual design R1 two BLOCKs preserved; R2 APPROVE. Red R1 fixture pending/new
contract and duplicate synthetic owner errors preserved, excluded from semantic
evidence; repaired by actual reserved->enrolling->stale Store transitions and
distinct incorrect mapping ids. Focused red R2 runs the new 20 cases: 18 real
AssertionError missing nodes and two original complete native census mutation
passes. Its 71 unselected cases are -t filtering, NOT a completed full suite.
Production then implemented. Actual full source/capture files 132/132/0pending,
original native host/controller/file+SQLite journal/contract/enrollment/mapper/
capacity siblings 365/365/0pending. Strict root tsc/Desktop Main build exit 0.
Actual subject-omission and native-contract-omission production mutations each
reject installed_metadata_intent_population before a handle; exact original
source bytes restored in finally, SHA recorded. Actual Qoder readonly code
APPROVE this first physical source attribution only, 16 original files frozen
before/after with identical SHA.

Physical attribution never traverses the Session node: Intent/Stage/full original
native-contract entities contain only source.direct. Every original subject and
complete journal is constructed; independent second-pass population compares
raw origins/bodies against actual entities, not another builder counter. All
complex gaps/input slots remain, native contracts match full actual source body
and exact original native receipt/current intent scope, expected and historical
registration ordered-prefix. Historical stale/reserved attempts/active pointer
differences retained, absent/null and duplicate roots unresolved. Independent
native invocation Sessions remain separate, never infer a source contract grant.
Evidence is component-level; no OS approved registration/full closedU/workflow/
target/migration qualification. The original complete parent remains active.
