# Fixed installed Groups declaration joins

The actual Groups producer already validates full captured schemas/userVersion
1/2/3, every row's original indexed cells/canonical JSON/bytes/content hash,
group accounting, event sequence, message and publication immutable anchors.
Collector currently keeps all Groups frames as unsupported-family. Extend the
same four-original-object collector; no new authority/input/checker/iterator.

Each original row gets an independent source/family/kind/recordKey/origin node.
groups table: group node with original group_id.
agents: group-agent with exact composite (group_id,agent_id).
Other 9 fixed tables: groups-row with exact composite (table,original rowid).
All raw cells, parsed bodies, reference array, unmapped and observation
declarations remain the original producer frame. Every actual zero-row source
still appears in complete source output. Unknown tables are already rejected by
the existing producer; no parser weakening or test reimplementation.

Only the original fixed producer's typed task/session references resolve to
actual unique captured Task/AgentSession definitions. No nested unknown fields,
arbitrary command result sourceTaskId, user text, thread/agent names, profile
or workspace strings become session references. All other typed declarations
are retained declaration-only with concrete unsupported-groups-reference.
Original unmapped/observation/external/full-legacy gaps remain, not marked ready.

Each original row with real cells.group_id attaches as a child to the UNIQUE
group in the SAME source. Group -> all its historical/current original rows;
no Row/Agent -> Group reverse edge or physical-source-wide union into entities.
Each agent's own sessions come only from its own exact typed Task/Session
declarations. Original group aggregation collects all relevant A/B rows while
Agent A remains A. No agent_id global link without exact source/group scope.
Old historical group is retained when active_group advances to new empty group.
No active pointer or boot ownership is reinterpreted as current authority.

Tests use actual DesktopMultiAgentStore calls to initialize authorization,
register thread, create historical group, put two Agents bound to actual Tasks
A/B, retained content/messages/resources/root-binding and unknown command body.
Store then advances active group to a real empty group. Capture both history
and empty group. An actual second SQLite copy retains same group/agent IDs and
production putAgent/putRootBinding switches sourceTask to B; exact-source graph
must keep Agent A only A in first source, only B in second source. Preserve
complete originals and all prior messages/events, do not infer unknown-command
sourceTaskId or thread name equal to Session B. Missing Task, duplicate Task
and duplicate actual Session remain unresolved. Explicit full body/origin/input
descriptor expectations come from original Store/SQLite before collector.
Actual native helper/broker/importer/mapper are production, installed lifetime
UID/IPC/ordinary route remains the existing explicit fixture, not OS authority.
Bound NEW multi-source test explicitly at 15s; all original case deadlines and
parent 99 Intent 15s/300s/1h stay untouched. No source/body population trimmed.

All parent conditions remain: further Loop records/Codex external semantics,
Artifact/KSwarm/Intent/material and complete full closedU, installed target/
four MainStore semantic proxies/all writer drain/native explicit retirement/
source absence fsync/charged capacity/atomic ready; all workflows/size budgets,
original 99, new final 84 paired/four same-SHA review, CLI full/Hook/IntlDoctor,
OS/native/UI/TTY/real install/packages/download/integration/GH/release.

Actual fixture discovery: agents.agent_id is already globally UNIQUE inside each original SQLite source; middle group must use its genuine independent middle-child id. Do not change the original schema to fake an impossible same-id cross-group case. Actual second physical SQLite source keeps all original SAME agent/group IDs and remains the cross-source collision counterexample. First fixture UNIQUE failures before capture do not qualify as feature red; all five cases must re-run through original native capture/mapper to missing Group assertion.
