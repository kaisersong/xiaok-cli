# 源码 Desktop 测试的固定 protection Worker 编译入口 R2

原 A18 latechild.cancel 后持 actualchild，到 root host.drain 冷读/Goal费用确认结束才释放；根真实诊断是 service runtime_blocked=true，store.goalChildReadiness=waiting_children、原取消消息context_applied，不是SQL丢消息。原closeGrace500ms已届满：源码protection Worker每次tsx启动225-234ms，主root多次actualread累积~1.3s。原阻塞正确，不放宽原500ms或跳read/改deadline。

测量同原 actual DesktopTaskObservationStore.readProtectionInWorker missing普通sidecar5次，源码225-234ms；fresh CLI emitted dist compiled真实Worker（同父tsx execArgv）110-121ms。仅是开发loader overhead诊断，不授用户性能收益或所有生产边界资格。原source-specific Worker CPU/FIFO/晚写/未知成本专测继续source入口，不能拿编译fixture替代那些验收。

原Desktop provenance、Goal/revocation、factory等nativeWorker fixtures已经把 delivery-verifier-worker.js固定URL映射到真实源码编译入口，未fakeWorker/result/exit。补一个固定 protection-read-worker.ts URL 映射到fresh测试编译的同源实际 .test-dist/src/runtime/task-host/protection-read-worker.js。beforeAll 必须先真实npm run test:sandbox:build（仅一次fixture主流程，不能直接信旧bundle），固定源码SHA与emitted依赖树fresh digest/artifact记录。或fixture自己tsc编译至其owned临时root，保全部actual .js sibling依赖/NativeWorker Node运行，无只搬单worker后missingdependency。路径仍由本repo固定，workerData/root/taskId/options原样，NativeWorker actual物理创建/message/error/exit/terminate不替换；不得传任务选URL，不用Promise.resolvefakeclean，不关闭nativegate/成本确认。包装计数两个固定Worker原真实start/exit，afterEach原物理相等。

只先给原A18 multi-agent-goal fixture使用，原delivery编译与全部assertions/原500ms grace/原waitFor1000/完整Goal消费门槛不改；新ownerframe/nativeIO专测原 source mode全保。编译entry属于测试入口纠正，不改productcache/readProtection/guard，不为test选原deadline更大。

先故障4红已经真实有效，新增firstWorkerUrl选择/actualstart&exitfact无需重实现payload；再加fixedactualemitted Worker普通/CPU heldread smoke保生产入口。若同源compiled也超过原500ms仍按产品runtimeblock红，不篡改原等待断言。评审必须检查actualfresh依赖与原acceptance是否被替代，不授native权限/其它模型population/installedmetadata/OS父资格。

## R1 实施后的实际证据与 R2 编译打包修正

R1整树tsc真实编译/物理退出smoke通过；A18原四红仍红。实际NativeWorker记录固定URL确实mapped=true，继承仅--conditions node/development（无tsx）；每个 protection actual exit89-100ms，主root原6次物理读合计约600ms，500ms grace合法block。不能关该block、pool Worker、用message代exit或删任一前后sourceguard。

独立非资格benchmark对本次freshrootdist实际完整 protected-observation-store.js 及其整依赖做esbuild bundle，原NativeWorker+真实FileStore+5次missing普通sidecaractualexit63-95ms（较原source225-234ms、R1compiled89-100ms，有实际收益）。该未经路径保持bundle只作耗时诊断，不资格：metafile已发现依赖6处import.meta，聚合到一文件会改变Windowsabsence、skillsdefaults、usage文件定位和createRequire原owner。不能拿仅ordinary {}结果授alias/protectedprofile资格。

R2先保R1 beforeAll实际fulltsc临时完整树+独立buildinfo、fullsourceSHA前后一致、packagejson及原目录/文件均保留；再esbuild只bundle实际 emitted protected-observation-store.js 到temporary bundle .js，packages:'external'，Node native包不合并。构建onLoad仅对当前临时全树内 .js 文件将 import.meta.url 的词法表达式固化为该文件在原emitted完整树的绝对fileURL常量（其真实原Node ESM值），保每个原module的文件定位/createRequire/相对asset路径；不改变readProtection/alias/FileStore/schema/packet/exit/sourceguards任何操作和分支。只允许常规表达式，所有实际出现位置需逐项rg核（benchmetafile 6modules），若其它形式或源码字符串内非词法出现不能盲replace，构建必须拒绝。直接.esbuild原编译class依赖不删成员、不换轻量reader。把生成bundle替换该临时根同名protected-observation-store.js，原Worker入口仍是原fulltsc保护readWorker.js；import.meta值与replace前实际父路径完全同，原静态JS siblings仍全部在，native模块仍从同projectnode_modules解析。不是原prod代码变更/发布优化。

新smoke沿原真实Owner reader读取普通missing sidecar，实际source/outfile/treehash+originalMetaURL记录，原NativeWorker创建与exit数量一致；现有source CPU/FIFO/protectedalias/晚IO全部继续原source路径并实跑相关原tests，不假充bundle另有权限。A18原20用例断言、500/1000限期保，若仍超deadline则保红并放弃这一测试入口打包修正，不追加其它宽限。该leaf不授所有OS/安装metadata/别的factory资格。
