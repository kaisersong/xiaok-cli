# Exact native SQLite census scalars

Observed original inventorySnapshot uses default Number SELECT * rows and
canonical JSON to sort/hash the original complete enrollment population.
Actual SQLite + actual production canonical function probe (artifact
native-census-precision-probe-r2.log) stores 9007199254740992 then
9007199254740993, exact SQL TEXT proves different original INTEGER values,
but both default driver rows/canonical strings equal. This probe is only the
actual driver/protocol evidence, not installed lifetime/native authority.
The full original installed source getter/collector must have red tests next.

Keep original four getter shapes/opaque brands/lifetime/native mapping/receipt
prefix/uniqueness/orphan/default-deny semantics. No new grant, caller database,
SQL, callback or target. Same ORIGINAL inventorySnapshot SQLite transaction,
including nested actual capacity transactions. Never globally change
db.defaultSafeIntegers: only private census statements use safeIntegers(true).

For each fixed original enrollment table, capture complete original cells with
the existing encodeCapturedSqliteCell and capturedSqliteEncoding helpers:
exact int64 decimal strings, IEEE754 REAL bits (including infinity), TEXT
decoded from actual CAST(column AS BLOB) bytes with original DB encoding,
BLOB base64 and NULL tag. Fixed SELECT projection includes original column
value/typeof/raw text bytes. Escape exact original SQL column identifiers;
no caller SQL and no field omission. Object.fromEntries retains __proto__/
constructor columns as own fields without mutating prototypes. Reject invalid
encoding explicitly, never normalize corrupt text or discard original rows.

Expose cellRows alongside the ordinary semantic rows in enrollmentPopulation.
Every cellRows row matches exactly one rows row, both sorted together by full
canonical ORIGINAL tagged cells. Semantic rows preserve natural null/string/
safe number; unsafe integer, BLOB and nonfinite REAL use their original tagged
declaration instead of lossy Number/mutable Buffer. Native known-field gates
still require the original string/number types, not tags converted to identities.
Unknown fields remain unknown; no privilege inferred from a tagged value.
Original schema and column census also include exact tagged scalar rows before
using original column names; invalid name/SQL text encoding fails closed.
Both full original semantic and tagged populations enter the one census hash,
so storage-class changes cannot collide and all getters share the same hash.
Ordinary getter return shapes stay the same; checksum changes conservatively
invalidate old snapshot qualification, never approve migration or relax gates.

Audit siblings: all four getters and already-issued beneficiary getter share
inventory. Original KSwarm SELECT * receipt/storage-feature records must use
the same exact row reader if they otherwise retain mutable Buffer/rounded
unknown cells. Their actual committed/owner/receipt validation remains intact.
No parallel second census outside the original SQLite snapshot or wrapper.
Absence/empty/duplicate full original optional rows and pending/failed native
enrollments remain retained and unresolved, not dropped or upgraded.

Tests first: actual source fixture (only installed lifetime mocked), all
getter hashes differ for adjacent int64 beyond JS precision and integer/text/
REAL class changes; exact independent literal cells/SQLite typeof and
pre-capture values for all tables/schema/column metadata; int64 min/max,
fractional REAL, infinity, BLOB, null, BOM/Unicode, unknown quoted and
__proto__ column names, empty/absent/pending population and frozen nested cells.
Original known UID/type/receipt/domain negative gates remain. Real fixed
collector from original four handles must reject native extra-integer drift
both after handle creation and during mapper await, even if old rounded
semantic rows would compare equal. No test reimplements a hash/parser.
Run complete source/capture tests and metadata/capacity/replacement siblings,
strict root/Main, freeze changed source SHA for independent code review.

All original unfinished-development parent gates remain incomplete: target/
four semantic proxies/all writers/full closedU/native explicit retirement/
absence fsync/charged replacement, full business/cap/99 Intent/new84/final
four-way/Intl/full tests/OS/UI/install/integration/GH/release. This safety leaf
does not establish all native data/source semantics or OS installation.


## R2 corrections (retain actual R1 BLOCK)
1. Same-permission sibling scope includes the actual
readKSwarmEnrollmentSnapshot's ALL seven raw groups: verification_owners,
mandatory_observation_checks, verification_owner_dependencies,
verification_registered_owners, verification_profiles,
verification_registered_invocations, owner_enrollment_invocation_receipts.
Keep each original exact owner_key/parent_key/profile_id filter and query
ordering, original validated receipt, no global unrelated owner union. Share
one internal exact scalar reader with a FIXED table/query allowlist, no
caller SQL/where column/callback. All exact rows/schema/column metadata in
this fence's JSON string; proof-authority and completion-boundary keep their
existing pre/post callback fences. All seven actual int64 drift fixtures and
their original full-controller SQL-tail regression remain required. This
does NOT enable KSwarm business_not_enabled or remove any application gate.
2. Private owners WeakMap stores the issue-time censusHash alongside original
source and identity. readInstalledMetadataOwner recomputes the original
complete current census and rejects mismatch before returning the same old
identity shape. Includes both controller metadata owner and every beneficiary.
Caller spreads/Proxy cannot fabricate the stored hash. Legitimate recapture
issues fresh bindings; old ones never silently remain qualified after native
data drift. Capacity/replacement siblings must detect compatibility regressions,
not weaken this gate or whitelist unknown-field drift for green tests.
3. Exactly THREE hash getters (source, sessions, fixed facts) change on adjacent
int64/storage-class drift; old owner/beneficiary getter REJECTS; new owner from
the actual refreshed source remains usable. Collector rejects post-handle
and mapper-await mutation. No assertion invents a hash field on owner getter.
Fixed original population is 12 tables (six required, six optional), each
original row + sqlite_master(type/name/tbl_name/sql) + complete table_xinfo,
all storage classes and declared absent/empty. Add actual malformed UTF text
and name/SQL fail-closed tests; no Unicode normalization or silent omission.
All original R1 domains/ABI/transaction/unknown/gap/parent requirements stay.

Red R1 retained: adjacent hash and malformed-UTF cases were accidentally unselected by narrow -t; do not treat missing selection as passed. KSwarm dependency ordinary enrollment omitted required invocations array and failed fixture shape; excluded from semantic red. R2 corrects original ordinary request shape, explicit BOM literal and selects all new getter/cell/UTF/collector/seven-group cases. Current BLOB/prototype Cannot-freeze errors are real current production inability to retain valid original unknown BLOB scalars, not fixture creation failures. No production edits.

Red R2 dependency child still violates actual ordinary Task enrollment requiring a nonempty invocation population. R3 supplies a distinct actual original invocation and strengthens all seven row-population assertions to >0. R1/R2 dependency errors are fixture defects, not semantic red; no production edits.

Full R1 226/229: new actual clock callback is rejected earlier by the original authority inspectOwner KSwarm fence (enrollment_kswarm_changed), not completion fence. R2 asserts that exact actual gate and original transaction rollback; no production gate change. Two schema-corruption fixtures were blocked during setup by better-sqlite3 defensive mode; R2 enables unsafeMode only on their private disposable in-memory databases, never in production. Original malformed schema bytes and reader rejection still required.

## R3 code-review corrections (retain code R1 BLOCK)
The actual KSwarm ready() validation parses its original subject SELECT * and
reads a storage-feature field, which are not replaced by the seven existing
snapshot groups. Add two private FIXED scoped queries: subject on
owner_enrollment_kswarm_subjects WHERE owner_key = exact already-validated
canonical owner; storageFeature on verification_storage_features WHERE
feature = the original literal kswarm-owner. Preserve parsed/validated receipt,
all original seven filters and order, and include the exact two complete
row/schema/column census frames in the same pre/post snapshot. A duplicate
matching owner row cannot disappear from the snapshot. No other owner/feature
union, business enablement, caller SQL or grant. Native-source inventory already
retains both complete tables; this correction is its snapshot sibling only.
Add original adjacent int64 drift for both new groups and actual callback
rollback for subject and feature, retaining all seven old group tests.

Original schema is typed SQLite metadata, not arbitrary opaque user columns.
Before deriving columns, require sqlite_master type/name/tbl_name to be TEXT,
type one of table/index/trigger/view, nonempty name, exact tbl_name. Require
SQL TEXT except legitimate NULL for an internal sqlite_autoindex_<table>_*
index. A primary type=table/name=table row must be present. Otherwise explicit
native_sqlite_census_schema before table_xinfo/data access. Original user row
BLOB/NULL etc remain retained. Tests use disposable unsafeMode DB only to
write schema name/sql BLOB and NULL primary-table SQL, prove original storage
class with independent SQL, then actual census reader rejection; valid auto
index NULL and all old typed user scalars stay accepted. No source repair,
SQL execution, Unicode normalization or field omission in production.

## R4 schema discovery corrections (retain R3 design BLOCK)
Use fixed schema selection WHERE name=? OR tbl_name=? with the same literal
original table twice, rather than filtering solely on tbl_name. Validate all
discovered schema rows BEFORE data access: exact typed names/tbl_name, exactly
one type=table/name=original primary row with TEXT SQL; other associated rows
must be index/trigger. BLOB/NULL/wrong TEXT tbl_name is explicit schema error,
never absent. If no selected schema rows exist, use the fixed original
pragma_table_xinfo(table,main) lookup: any actual columns mean inconsistent
schema and reject, while true absence has no columns. This also detects both
master names being corrupted while the native connection still has its actual
table cache; fresh SQLite cache corruption errors remain fail closed.
NULL index SQL requires both the internal automatic name and an exact actual
pragma_index_list(table,main) name with origin pk/u, not mere name prefix.
The private encoded row reader supplies those name/origin facts; no caller
SQL, index creation, source repair or execution. Legitimate ordinary user
index SQL stays TEXT. Require red cases for primary tbl_name BLOB/NULL/wrong
TEXT through inventory and BOTH newly scoped subject/storageFeature queries,
plus forged NULL SQL on a user-created index, legitimate automatic-index NULL,
and both original master names corrupted. Preserve R3 full nine populations,
original seven filters, all typed rows and previous ABI/native gates.

## R5 complete master census (retain R4 design BLOCK)
Do not filter the original sqlite_master population before capture. Read ALL
original type/name/tbl_name/sql cells from main.sqlite_master in fixed order,
retain them as masterCells in every native census frame, including true
absent frames. Thus no associated index/trigger can disappear from the hash
when its tbl_name is moved to another real table. This is schema facts only;
scoped DATA rows remain the original exact nine groups, not a global owner
union. Validate original typed schema fields globally, exact primary-table
identity for each actual requested table, and duplicate schema identities
using SQLite ASCII name folding and its separate trigger namespace. A NULL
index SQL needs the internal autoindex name and an exact actual native
pragma_index_list(row.tbl_name,main) match with origin pk/u; global duplicate
names reject the forged-user-index/real-autoindex collision. Cross-check all
actual target index-list names against the complete master (type/index/name/
exact tbl_name), so a cached associated index with corrupt tbl_name cannot
evade local population. For triggers, the complete master original fields
are retained and hashed, not inferred from SQL text or executed. A valid
TEXT tbl_name redirected to another real table is an explicit ORIGINAL
declaration, never silently omitted; actual callback drift must change the
snapshot. Existing KSwarm assertKSwarmSqlIntegrity still rejects non-original
triggers independently, before authority qualification. No new schema/trigger
semantic authority or full-native qualification is claimed by this readonly
leaf. Full target/writer qualification remains the original parent gate.
Global typed invalid tbl_name (BLOB/NULL) rejects even on associated rows.
Primary wrong TEXT/absent cache check, malformed schema encoding, NULL primary
SQL and all R3/R4 genuine rejection requirements remain. Add independent
WHOLE sqlite_master pre-capture oracle for both frame masterCells and all
source tables; original per-table schema fields are not the only oracle.
Add user index+trigger tbl_name BLOB/NULL rejection and redirected valid TEXT
complete original master preservation/hash change, including another real
table; fake NULL index reuse of a real automatic name rejection. Ordinary
valid index/trigger metadata stays retained; do not globally ban legitimate
capacity trace/rejection triggers or remove original tests to get green.

## R6 bounded local census context (actual R5 growth regression)
R5 complete source 180/180 and boundary 71/71 passed, strict/Main0, but brothers
213/217: four original real growth tests timed out. Original same tests were
1.06/2.22/2.46/2.83 seconds in R1; R5 7.11/15.85/18.31/18.94 seconds. Isolated
actual R5 growth run (no concurrent heavy tests) still four 5000ms timeouts.
Do NOT increase deadlines or remove original growth cases.
Actual code creates a new whole-master/indexCache in EACH census call; source
inventory calls it twelve times PER owner recheck. Every NULL automatic index
in the entire controller is revalidated via native pragma_index_list in each
call. Fixed batch context removes these duplicate native queries, not facts.

Extract a PRIVATE createContext(database) for the existing exact encoding,
whole-master cells/typed/duplicate/NULL-autoindex validation and native index
cache. PRIVATE census(context,query,argument) retains EXACT current per-frame
shape/order/full masterCells, schema/xinfo/rows/cellRows. No compacting facts,
new digest definition or omission; stable original snapshots/hash remain
byte-identical. Keep old single readonly census API/guards.
Add two FIXED readonly batch entries only: original twelve enrollment tables
with no caller query list/args, and original nine KSwarm groups with only
primitive original validated ownerKey/profileId bindings (feature literal
kswarm-owner). Context is created once per synchronous batch under the caller's
original SQLite transaction, never exported or retained between calls/awaits/
fences/transactions. No DB-wide/epoch/total_changes memoization. All DATA rows
are still read fresh. Original pre/post fences build two separate contexts.
Source uses this fixed twelve-table batch and reuses its actual subject and
storage-feature frames for its existing validated receipt records. KSwarm
uses the fixed nine-group batch after its original ready/receipt validation.
Before batch return compare complete original masterCells again and exact
native schema_version/total_changes with start: reads cannot mutate their own
schema/data and cache cannot hide even a transient own-connection write.
No caller callback, SQL/where fields, injected context, write grant or custody.

Tests first: real DB prepare spy delegates original prepare and measures whole
master/index_list query count for actual fixed source getter vs an independent
explicit original single-census sequence; capture expected frames BEFORE spy
from real original helper, then actual production batch output identical full
facts/order/typed cells. Runtime absence of fixed batch is API red only, not
exploit proof. New actual Source getter no more than TWO full master reads per
inventory (one context, one end-check), complete native rows/schema/indices
still independently asserted by original R5 population tests. All nine group
fences and actual callback drift stay. Add own-connection data/schema mutation
from a production-delegating prepare spy within the batch => reject before
return; no stale context reused after two calls or outside a transaction.
Original 180 source/71 boundary/217 brothers (especially all four growth)
must pass under old deadlines, plus strict/Main and independent frozen review.
This is a regression repair; all original parent completion gates remain.

## R7 rollback-DDL frame consistency (retain actual R6 BLOCK)
R6 end-only cookie/master comparison cannot detect SAVEPOINT ALTER rollback
after a newer xinfo frame has been captured. Keep this BLOCK, no batch
production code yet. Do not claim observing every invisible transient write;
the requirement is that transient schema cannot pollute returned facts.
Anchor EACH xinfo and DATA read to its actual primary table SQL in the SAME
SQLite SELECT: add an internal scalar subquery for main.sqlite_master.sql
(fixed type=table and fixed original table) to the exact encoded projection.
Compare its encoded SQL cell with the context's original primary SQL BEFORE
accepting any returned row. Remove only this internal duplicate anchor from
output; every original column/row remains. Also read the original table SQL
immediately around empty reads, because zero rows cannot carry an anchor.
No caller SQL/anchor/context or SQL parsing/execution. All original public
frame shapes, full master population and stable snapshot hashes unchanged.
Normal ALTER ADD COLUMN changes its actual SQL text, even if a prepare/all
fault-injection spy subsequently rolls back: the returned xinfo's same-SELECT
anchor exposes the changed SQL and rejects before that frame can enter output.
R6 end checks remain for persistent schema and own DATA writes. A transient
index with no retained schema/data difference cannot pollute output: global
schema/index facts remain the original validated snapshot. This readonly
batch does not attest a complete absence of arbitrary privileged SQL actions;
the original full-native custody/writer/drain parent requirements remain.
Add exact R6 SAVEPOINT ALTER ADD COLUMN -> actual xinfo read -> ROLLBACK
fault-injection regression expecting native_sqlite_census_changed, plus data
frame ALTER/rollback and empty-table anchor case. SQL prepare spies always
delegate real statements. Require every actual index_list table once per
batch, complete original facts equality to independent single-query baseline,
and all original growth deadlines. No data truncation, guard relaxation or
global cache. Fixed bundles only; each pre/post fence a fresh local context.

## R8 byte-identical serialization (actual R7 CPU evidence)
R7 complete component141:138pass/3 original growth timeouts. All new fixed
context count/equality/rollback-DDL tests passed; strict0. Actual original
legacy-growth CPU profile: protocol record/canonical samples attributable to
Source hash 908 and finish 344, compared with rows517/prepare359; true worker
profile, not a reimplemented benchmark. Growth remains old 5000ms requirement.
Do not change general protocol canonicalVerificationJson or digest definition,
drop full master arrays, compact DTO, memoize census facts across calls or
relax owner invalidation. Public frame shapes/full facts stay identical.

Add a pure native-population encoder for only frames issued by this module:
private WeakSet marks the exact frozen present/absent frame objects. Copied,
Proxy and arbitrary objects reject before serialization. Frame masterCells
and all tagged cells are already immutable actual captured originals. Per
ENCODER CALL WeakMap caches json(masterCells) by exact array identity; every
other original property is encoded using the existing production canonical
function, keys sorted exactly as before. Assemble frame/array JSON with that
same original key order, byte-for-byte equal to ordinary json(frames). This
adds no fact/grant/source issuer. No shared cache between calls or generations.
Source census hash feeds original profiles/records via ordinary canonical,
and this exact same population string, in the original sorted three-property
order. Whole original hash bytes must stay identical. Root primitive hash
helper and all other protocol users unchanged. finish compares full original
tagged master arrays by Node isDeepStrictEqual (not canonical serialization),
all exact cells/order/type remain checked before/after; stamps stay checked.

Tests first: real fixed batch frame encoding equals the original production
json(frames), includes literal prototype/quotes/unicode/BLOB/int64/storage
classes via original tests; copy/Proxy/raw frames reject, fresh changed frame
not cached stale. Freeze a before-change source fixture census hash and assert
the actual Source getter still produces that exact value (same physical-path
independent fixture original data/schema). Keep exact emitted population JSON
equivalence as independent production-function oracle, no test hash rewrite.
Original 5000ms growth tests and all corpus/source/fence/semantic tests remain.

## R9 local prepared statements (preserve R7/R8 guards)
R8 exact canonical equality and frozen old Source checksum passed, strict0;
component143/140 with three old growth timeouts (8.00/8.78/9.13s), improved
but still not acceptable under old5000ms. Keep every real fence/anchor/full
record and deadline. Native prepare is another measured359 CPU samples.
Within the EXISTING single private batch context only, prepare each identical
fixed SQL string once and reuse its actual Statement with fresh parameter
bindings/current rows. Never reuse returned rows/cookies/indices between
contexts or Source owner checks. Per-statement raw/safeIntegers still set;
no global DB default changes. This is internal SQL already assembled from
private fixed query names/escaped original columns. No caller cache/maps.
Context's statement Map includes its whole-master begin/end statement,
index_list, stamp and fixed table-SQL probes, metadata/data statements.
Parameterize the primary-SQL scalar subquery (three literal original-table
bindings before FROM/WHERE parameters), so the same original xinfo SQL can
be reused for every actual table. All actual same-SELECT tagged SQL anchors
and original before/after probes remain; no weakening of zero-row guard.
End fence still reads fresh complete current master and stamps. Original
rollback-DDL tests must pass even with Statement reuse; SQLite automatic
reprepare remains its native responsibility, no SQLITE_SCHEMA fallback.

Tests first: production-delegating prepare spy requires pragma_index_list
PREPARE once per batch, each actual table's index list still exactly one
READ (all R7 count tests preserved); whole-master same Statement PREPARE once
and READ twice. New changed batch prepares new statements and reads new
values; old original full-fact/canonical/checksum/DDL/API/callback negatives
remain. Original growth5000ms, strict/Main and complete related suites remain.

## R10 concrete tests for R9 review objections
R9 reviewer found no implementation-design safety defect, blocked because old
R7 tests did not yet prove R9 prepare identities and empty DATA probes. New
actual delegate spy now records exact Statement identity/prepares/reads:
whole master prepare1/read2, index_list prepare1/read12, next batch entirely
new Statement. Current production still re-prepares and must be red. New
empty DATA actual all returns[], then real ALTER before return; existing
post-SQL probe must reject. R7 empty-xinfo rollback test also retained. This
is persistent empty-read schema change, not a fabricated zero-row witness
of fully rolled-back invisible DDL. No production change in this revision.

## R11 test attribution corrections
R10 BLOCK retained. Empty actual DATA test now requires complete master read
count exactly one, proving rejection before finish. Entire second-batch
prepared Statement set must be disjoint from the first; index prepare once,
identity change and twelve fresh reads required explicitly. Current prepare
count remains legitimately red until private-context-only R9 implementation.

## R12 final attribution corrections
R11 BLOCK retained. Exact actual total_changes Statement.get count must be
one along with masterReads one, proving no finish initial stamp occurred.
All actual prepared SQL strings in the batch must be unique, covering every
fixed SQL statement, not only master/index. Next batch entire set disjoint
and existing true index/master fresh read counts remain. Existing per-table
xinfo and original tag-anchor/rollbackDDL protections unchanged.

## R13 xinfo parameterization test
R12 BLOCK retained. Actual xinfo Statement prepare count one, reads twelve,
exact observed bindings [table,table,table,table,main] in fixed table order
now required. All original rollback-DLL, complete cells, digest equality,
copy/proxy rejection and lifetime/generation/current-source negatives remain.

## R15 authentic immutable frame encoding (no protocol change)
R13 design APPROVE led to actual batch-local Statements implementation. R14
default rest-bind Statement type strict0. Full component145/142pass/3growth
timeouts, all new actual prepare/bind/DDL/byte-equality cases passed. Growth
boundary7171/usable6932/failed5856ms vs R8 9131/8776/8005ms; material improvement
but old5000ms still unmet. No deadline/test/body reduction.

Original actual worker CPU trace R7 attributed Source.hash908 canonical
samples, including protocol.record descriptor checking, rows517/prepare359.
R8 only reused master fragment; each remaining authentic frame field still
recursively allocates/describes every already-private, deeply frozen object.
Inside canonicalNativeCensusPopulation ONLY, after every frame exact WeakSet
brand check, recursively encode its immutable private constructor data using
the unchanged sorted Object.keys and JSON.stringify primitive rule, with a
per-call WeakMap of object->canonical fragment. No general protocol changes,
no exported raw encoder, no cross-call cache, no authority from encoder.
All issued descendants are fresh native columns/cells/semantic plain records,
arrays and scalar values, deeply frozen before exposure. Unknown scalars
cannot inject callback/accessor/Proxy. Copy/Proxy/raw frames remain rejected.
Fragments can be reused only within this exact pure invocation; future batch
must read fresh facts. Keys retain lexicographic original ordering including
__proto__, Unicode, quote/control strings, signed integer/real tags and BLOB.

For freezing, freeze complete masterCells once in the same private context;
freeze each frame other own property by original freezeCapturedData, then
freeze/issue root. Source removes its second recursive freeze of an already
deeply frozen returned population. No skip-on-Object.isFrozen for arbitrary
caller data; generic freezeCapturedData and protocol.record stay unchanged.

Before production add actual SQLite storage-types/escaped original-column
fixture equality with production canonicalVerificationJson, assert all
descendants frozen (including shared master), existing caller/Proxy/copy
rejection/fresh-batch/old Source fixture checksum and all DDL negatives.
Current three full growth reds are the real performance acceptance, no new
toy benchmark or retry-to-pass. Run full related and Main then frozen review.

## R17 exact SQL anchor byte comparison
R15 design AP, real before invariants35/35, current component148/145pass,
strict0; boundary6442/usable6005/failed5446ms still fail old5000. R16 actual
worker CPU2.947s: rows519 samples vs canonical86/record113/encode73;
actual native all/row marshalling now main cost. Keep every SQL query/read,
sameSELECT anchors before/after/zero-row probes/stamps/master and table binds.

Each private census primary SQL is already strictly decoded/roundtripped
TEXT by master capture. Build its original exact encoding bytes once in a
private anchor (UTF8 or UTF16le plus swap16 for be); not exposed or authorized.
Anchor comparison checks same original storage class TEXT, native CAST BLOB
Buffer and exact Buffer.equals(originalSQLBytes). This is precisely the
original tagged TEXT equality because original SQL already passed fatal
decode and roundtrip. Invalid current bytes or different class reject as
native_sqlite_census_changed. No interpreting driver lossy string as source.
Before/after probes directly read the SAME existing three-column raw SQL
statement and compare these original type/bytes; do not build semantic/cells
record and JSON merely to compare known SQL. SameSELECT extra triple retains
all original fields and is checked per original row. Query SQL, parameters,
raw(true)/safeIntegers(true), complete native row encoder unchanged.

Tests preserve every original prepare/bind count, all three actual rollback
DDL modes, emptyDATA finish-attribution, malformed original schema encoding,
source drift/oldowner and canonical/Source checksums. Add actual readable
writable_schema corruption of SQL after real xinfo all, require rejection
before finish counts; run for all3 original database encodings. This change
does not skip any current source read or census, no ticket/DB/fact cache.
Original three growth reds remain actual acceptance. New full/codeAP needed.

## R17 measured rejection and restored implementation
Actual component151/148pass/3growth reds. Boundary6369/usable6173/failed5913ms
against R15 6442/6005/5446ms: no5percent gain, so R17 production restored to
R15 original tagged SQL comparisons. Its new three real malformed SQL tests
retained. Typecheck R17 additionally found indexed unknown narrowing error;
not hidden by cast or baseline update. R15 original strict0 implementation
restored, not a claim that remaining capacity performance is acceptable.

## R18 invocation-local exact scalar encoding
R17 actual gain below5percent rejected/restored; no accepted bypass of original
tagged SQL anchors. Original R15 full3growth reds remain, original5000ms unchanged.
R16 measured rows519, actual cell encoder35/decodeUTF836 plus native row
marshalling. Current master/xinfo/data/probes repeatedly decode identical
original TEXT bytes and allocate identical INTEGER/NULL tags in one batch.

Only inside one private native census context, memoize PURE encoding results
of actual freshly returned scalar values, never SQL rows, schema facts or
statements across calls. All original queries/checks/freshall unchanged.
TEXT key is exact original native CAST BLOB bytes via injective base64, not
the possibly lossy driver string; same original encoding fixed by context.
Only originaltypeof=text plus actualBuffer can use TEXT memo; the first
encounter calls original fatal decode+encoding roundtrip. Malformed bytes
cannot enter memo. INTEGER key is exact native BigInt and typeof=integer;
NULL memo only typeof=null/value===null. Other classes always originalcodec.
Bound new memo to at most1024 TEXT entries of at most4096 original bytes
each and256 integer entries; overflow calls originalcodec, not rejection.
No memo between batches/getters, no bytes truncation, same deeply frozen tag
objects may alias because immutable. Encoder and generic protocol unchanged.

Tests first actual delegate spy on imported production cell codec requires
same repeated TEXT/integer encode exactly once in a batch, but again next
batch; current native rows are still queried each time (all existing read
count and exact parameter tests kept). Compare all actual original frame
values/canonical bytes/old Source digest, malformed TEXT and rollbackDDL;
all Unicode/BOM/UTF16 and distinct raw bytes/storage types retain distinction.
Every current Source getter and owner hash still fully reads source each time.
Performance acceptance remains complete original growth5000ms and fullsuites;
if actual gain below5percent revert this production candidate as forR17.

## R18 actual no-gain rejection
Actual component155/152pass/3growth reds, strict0; new private encoding-count
specs all passed but boundary6398/usable6257/failed5441ms against originalR15
6442/6005/5446 gave no5percent improvement. Candidate production reverted;
candidate implementation-detail tests archived verbatim with code in Art,
not imposed on the restored implementation. All original requirements and
behavior tests retained (151 cases). Do not rerun this candidate to seek a
better sample. Complete native facts performance still fails old5000ms.

## R19 capture checked frame sequence once
Self-review of R15 found its pure encoder brand-checks caller frames via
for-of, then reads the caller container a second time via frames.map. An
array index getter/custom Proxy container can return authentic frame first,
forged accessor object second. Actual Source uses frozen private population,
so this is a standalone pure-encoder boundary defect, not a capacity grant.
Capture observed authentic frame references into one local ordinary array
while validating each exact WeakSet brand. Encode only that local snapshot.
No caller second read, no new brands/authority. Legitimate canonical bytes
unchanged; no new source/rows/cache skips. Tests first: actual issued frame
plus alternating index getter and custom map method must preserve original
first observation, never access forged descendant, while existing direct
copy/Proxy frame rejection remains. Regress original fullsuites and codeAP.

## R20 R19 review and actual tests
R19 reviewer confirmed the existing defect and accepted the proposed private
capture direction, but labelled current old code BLOCK. Two real regression
cases now prove alternating array getter and custom map defects in existing
production. Planned exact correction: local `const captured:object[]=[];`
for each observed frame check existing WeakSet then captured.push(frame);
finally encode `captured.map(encode)`, not `frames.map`. No caller second read.
