# Loop complete original records and forward relationship closure

Observed: the actual captured SQLite Loop producer validates all table schemas,
rows, native history and publication/result hashes and emits every original
cell plus parsed bodies, typed references and embedded Task declarations.
The installed readonly collector only creates definition/run/stage nodes.
All other frames are unsupported-loop-record, losing usable original typed
Session/Task execution references and actual forward publication ancestry.

Keep the four-original-object ABI, all original full mapper events and gaps,
actual per-await/census/CHECK validation, opaque brands and parent requirements.
Add one loop-row entity for EACH other original row, keyed by [table,rowid],
without replacing original frame/body by a reduced DTO or inventing native
ownership. Independently compare actual constructed Loop row entities with
ALL original immutable producer row frames before issuing the handle.
This population check must fail under a real production omission mutation.

Private exact-source table/column identity index, not global aliases:
definitions.id, runs.id, stages.id, completion expectations/evidence/records.id,
constraints.id, assistant candidates.id, publication candidates.id,
native attempts.id, verification sessions.id. Match actual physical sourceId
and exact original IDs; duplicate/missing remains a concrete full-body gap.
Never first match, union sources, trim/normalize IDs or borrow another DB.

Forward OWNERSHIP only: existing Loop->all historical Runs->Stages stays.
Loop -> own template/config/constraint; Run -> own basis/producer result/
projection rows/assistant candidates; Stage -> own execution results;
Run or Stage -> corresponding publication candidate (stage_id determines
the narrower owner and original run_id must agree); candidate -> its native
attempts -> their verification sessions/publication attempts; verification
session -> its verification executions; candidate -> members, export journals;
assistant candidate -> own promotion intents. Original FK-validated producer
already authenticates the native history. Link child into parent, never
child -> parent; same-source exact population only. Completion rows whose
owner_kind is loop_run/loop_stage attach downward to that exact owner.
Anomaly scan_run attaches downward to its exact original Run; pseudo health
owner IDs do not become Runs. No sibling or active-pointer replacement.

Original typed Task/Session references call the existing unique actual entity
resolver and Session direct-identity gate. Exclude embedded Task goal/task
parent attachments and publication route.owner (hashed native owner) from
execution edges, retaining full declaration/gap. Completion owner Task/Goal
references use actual original namespaces; completion expectation/evidence/
record edges and Stage constraint edges resolve in the exact same physical
source. Other references, including Loop/Run navigation/source pointers,
native profile/challenge/operation/material request, project, schedule action,
assistant target and knowledge collection, retain full original declaration
and unsupported-loop-reference. They cannot be guessed into Session IDs.
All original embedded Tasks retain separate nodes and exact Stage parent;
no reverse Task/Goal attachment inheritance or duplicate global Task node.

Tests extend actual native-capture integration fixture with original Stores,
scanners, historical completion records, constraints, candidate Task provenance
and actual stored publication/native/verification-session journals. Native
publication wire/lifetime/UID/IPC/route remain explicit component mocks;
real Store transitions and capture/mapper/collector are the tested entries.
Independent pre-capture SQLite queries compare every cell and SQLite storage
class from every table with actual constructed entities. Positive/negative
cases: split/same-ID physical DBs; verification Session missing/duplicate/
null identity; narrow Stage vs Run; task/candidate provenance; arbitrary JSON
and typed namespace collisions cannot become Session; both scanner pseudo
owner IDs; every original declaration/scope and parent occurrence retained.
Run full source tests, related Store/producer/mapper/native history regressions,
strict root and Main build; freeze changed source SHA for independent review.

This is readonly source closure work, not OS/native grant or full migration.
All original unfinished-development parent gates remain: installed target/
four proxies/closedU/explicit metadata retirement/absence fsync/charged WAL
and replacement, full business workflows/99 Intent deadlines/new84paired,
Intl/full CLI/Desktop/Hook/OS/UI/install/integration/GH/release. No total
completion claim or relaxed acceptance follows from this incremental leaf.


## R2 corrections (retain actual R1 BLOCK)
1. Session relations are a fixed allowlist: ONLY the actual validated
loop_verification_sessions.session and actual parsed embedded Task session
declarations can enter the Session resolver. assistant_candidates.evidence
kind is arbitrary: even kind=session is unsupported, never a Session edge.
Task allows actual loop_stages.task, completion_*.owner/evidence_anomalies.owner
when namespace=task, and assistant_candidates.evidence kind=task (original
execution provenance). Task/Goal embedded parent attachments remain excluded.
Goal allows only actual completion/anomaly owner namespace=goal. No generic
namespace-only resolver for any Loop reference. Add assistant evidence kind
session + id of real Session B negative test, alongside kind memory collision.
2. Producer result stage_id!=null attaches to that exact same-source Stage
with original run_id agreement; null attaches Run. Candidate same condition.
3. Actual index columns are publication_candidates.candidate_id and
native_attempts.attempt_id. Projection origins are keyed by run_id and attach
to Run; projection generations attach to that exact origin.run_id, not flat
to the Run. Both complete source bodies retained, no extra global alias.
4. Artifact export is NOT a schema FK. Keep its candidate/run declarations
unsupported in this iteration; full export journal entity/body and existing
validated source semantics retained. Do not add an inferred parent edge.
All remaining R1 population/source/narrowness/native/gap/parent gates retained.

Red R1: all nine cases failed fixture health scanner not drained because the async scan was not awaited. These are NOT semantic red evidence. Fixture R2 awaits the original actual scanner before closing; no production edits.

Red R2: eight real missing-population AssertionErrors, collision fixture violates actual unique verification Session id. R3 swaps the two original IDs transactionally within the copied physical DB, preserving both unique rows; expected copied narrower Stage B/root A frozen before production. R2 collision is not semantic red.

First complete production run: 162 total,155 pass,7 failures,0pending. Two old physical-source expectations excluded the already-preserved original Task A completion records in copied DB/missing Stage Task cases. Full row expansion correctly includes that independent original Task A, while narrower Loop/Run/Stage isolation stayed green. Strengthen tests with exact original completion owner A + actual unique Task A and complete physical union; do not remove narrow assertions. Five new scanner expectations mistakenly inherited scan Run Sessions backwards into anomaly, contrary to approved forward-only design. Correct anomaly to empty, assert exact pseudo-owner kswarm-service unsupported and original Run->anomaly dependency. No production changes for these fixture/oracle corrections; all failures retained.

Add explicit completion same-ID cross-DB adversarial case: all three original expectation/evidence/record IDs duplicated in second DB, original owner switched together A->B keeping producer owner equality/schema. Actual records must be A-only/B-only by exact original source. A production global-first reference mutation must make the B record incorrectly A/B and fail. Full both bodies/SQLite storage classes retained. No production edit required.

Completion collision fixture R1 failed actual unique expectation owner because original B owner already exists. R2 transactionally swaps ALL A/B Task owners in expectation/evidence/record together via temporary value; final full history preserves both uniqueness and exact expectation/evidence owner matches. No production edit. Focused case first, then complete source suite.


## Final R1 evidence
Actual design R1 BLOCK four real defects retained; revised R2 APPROVE.
Fixture red R1/R2 failures explicitly excluded, R3 nine genuine original
population AssertionErrors before production (112 unselected, not full skips).
Complete source/capture files 163/163/0pending, nine actual related Store/
native producer/mapper/query/capacity/replacement files 351/351/0pending.
Root strict TypeScript and Desktop Main exit 0. Actual Qoder readonly code
APPROVE with 21 original source/test files frozen SHA before/after identical.

Independent original pre-capture SQLite values/typeof compare every column,
row and table, including empty tables and original full body/native histories.
Three real production mutations are detected: omit completion evidence row
builder -> installed_metadata_loop_population; remove Session relation
allowlist -> arbitrary assistant kind=session wrongly adds B; global-first
completion lookup -> copied B completion record incorrectly inherits A/B.
All production bytes restored exactly, SHA restoration independently saved.

Original full rows now each have an actual entity; original exact-source FK
parentage is downward only, preserving narrow Stage/candidate vs Run scopes.
Native verification Session chain joins actual unique direct Session identity;
missing/duplicate/nil identities cannot borrow lineage. Completion internal
IDs are physical-source scoped; copied same IDs/foreign owner population stay
independent. Embedded Task parent attachments and hashed publication route
owners remain declarations. Scanner pseudo-owner and arbitrary identifiers do
not become Sessions. Export journals have no FK: full source body retained,
references remain unsupported. Other unknown semantics and original mapper
gaps remain; this incremental representation is not full Loop/native authority.

All original parent gates remain incomplete: actual target/four proxies/
closedU/native explicit retirement/absence fsync/charged replacement, full
business workflows and capacities, 99 Intent deadlines/new84paired, final
same-version four-way audit, Intl/full CLI/Desktop/Hook/OS/UI/TTY/install/
integration/GH/release. No approval/migration/ready grant is issued here.
