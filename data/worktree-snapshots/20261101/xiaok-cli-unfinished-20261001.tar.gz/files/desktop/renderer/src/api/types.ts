export type {LoopArtifactPageRequest,LoopArtifactListView} from '../../../shared/loop-artifacts.js';
import type {LoopCompletionObservation} from '../../../shared/loop-current-view-types';
export type {LoopPublicationAction,LoopPublicationActionResult,LoopPublicationStateView,StoredLoopPublicationConfiguration} from '../../../shared/loop-publication-types.js';
export type { GoalAttachmentRequest, GoalAttachmentSource } from '../../../shared/goal-attachment';
export type {
  ArtifactWorkspaceEventName,
  ArtifactWorkspaceFeatureAccess,
  ArtifactWorkspaceLayoutPatch,
  ArtifactWorkspaceNode,
  ArtifactWorkspacePreview,
  ArtifactWorkspaceRelation,
  ArtifactWorkspaceRelationKind,
  ArtifactWorkspaceRequestedKind,
  ArtifactWorkspaceSelectedArtifact,
  ArtifactWorkspaceSnapshot,
  ArtifactWorkspaceVersionView,
  WorkspaceGenerationRequest,
} from '../../../shared/artifact-workspace-types';
export type {
  ArtifactWorkspaceIpcError,
  ArtifactWorkspaceIpcResult,
  ArtifactWorkspaceIdentityInput,
  ArtifactWorkspaceVersionInput,
  CancelArtifactGenerationInput,
  CreateArtifactPlaceholderInput,
  CreateArtifactWorkspaceCollectionInput,
  CreateArtifactWorkspaceNoteInput,
  CreateArtifactWorkspaceRelationInput,
  GetArtifactWorkspaceSnapshotInput,
  PreferArtifactVersionInput,
  RecordArtifactWorkspaceEventInput,
  RemoveArtifactWorkspaceNodeInput,
  RetryArtifactGenerationInput,
  SaveArtifactWorkspaceViewportInput,
  SetArtifactCollectionMembershipInput,
  SubmitArtifactGenerationInput,
  UpdateArtifactWorkspaceLayoutInput,
  UpdateArtifactWorkspaceNoteInput,
} from '../../../electron/preload-api';
export type {
  AssistantOverviewView,
  CreateKSwarmProjectSemanticInput,
  KSwarmAgentSemanticInput,
  ProjectTeamOperationView,
  ProjectTeamPlanItemView,
  ProjectTeamPlanView,
} from '../../../electron/preload-api';

// Thread types (local storage + desktop web-client compatibility)
export type ThreadMode = 'chat' | 'work';
export type CollaborationMode = ThreadMode;
export type ThreadGtdBucket = 'inbox' | 'todo' | 'waiting' | 'someday' | 'archived';

export interface ThreadRecord {
  /** Local association reservation only; main owns execution/deletion status. */
  deletionPending?: boolean;
  id: string;
  title: string | null;
  status: 'idle' | 'running' | 'completed' | 'failed';
  mode: ThreadMode;
  createdAt: number;
  updatedAt: number;
  starred: boolean;
  gtdBucket: ThreadGtdBucket | null;
  pinnedAt: number | null;
  currentTaskId: string | null;
  taskIds: string[];  // All task IDs for this thread (in order)

  // Compatibility fields mirrored from the web-client API shape. Desktop's
  // IndexedDB store uses camelCase, while shared sidebar code still consumes
  // snake_case metadata from the server-backed client.
  created_at?: string | number;
  updated_at?: string | number;
  active_run_id?: string | null;
  sidebar_work_folder?: string | null;
  sidebar_pinned_at?: string | number | null;
  sidebar_gtd_bucket?: ThreadGtdBucket | null;
  is_private?: boolean;
  collaboration_mode?: CollaborationMode;
  collaboration_mode_revision?: number | null;
}

/** Alias used by thread-list context (web-client naming convention). */
export type ThreadResponse = ThreadRecord;

export interface UpdateThreadSidebarRequest {
  starred?: boolean;
  gtdBucket?: ThreadGtdBucket | null;
  mode?: ThreadMode;
  sidebar_work_folder?: string | null;
  sidebar_pinned?: boolean;
  sidebar_gtd_bucket?: ThreadGtdBucket | null;
}

// LLM Provider types (mapped from config)
export interface LlmProvider {
  id: string;
  label: string;
  type: 'first_party' | 'custom';
  protocol: string;
  baseUrl?: string;
  apiKeyConfigured: boolean;
  advanced_json?: Record<string, unknown>;
}

export interface LlmProviderModel {
  id: string;
  provider: string;
  model: string;
  label: string;
  capabilities?: string[];
  isDefault: boolean;
}

export type AvailableModel = { modelId: string; model: string; label: string; capabilities?: string[] };

export interface AvailableModelView {
  modelId: string;
  model: string;
  label: string;
  capabilities?: string[];
}

export interface TestProviderConnectionResult {
  success: boolean;
  latencyMs?: number;
  error?: string;
}

export interface SpawnProfile {
  name: string;
  model: string;
}

// Persona types (mock)
export interface Persona {
  id?: string;
  persona_key: string;
  display_name: string;
  description?: string;
  scope?: string;
  budgets?: unknown[];
}

// Skill types (mock)
export interface SkillPackage {
  skill_key: string;
  display_name: string;
  is_active: boolean;
}

// User types (local mode)
export interface MeResponse {
  id: string;
  username: string;
  email?: string;
  email_verified: boolean;
  work_enabled: boolean;
}

// Config types
export interface CaptchaConfig { enabled: boolean; }
export interface MemoryConfig { enabled: boolean; }
export type ConnectorsSearchProvider = 'duckduckgo' | 'tavily' | 'brave' | 'firecrawl' | 'searxng';
export type ConnectorsFetchProvider = 'basic' | 'jina' | 'firecrawl';
export interface ConnectorsConfig {
  search: {
    provider: ConnectorsSearchProvider;
    tavilyApiKey?: string;
    braveApiKey?: string;
    firecrawlApiKey?: string;
    searxngBaseUrl?: string;
  };
  fetch: {
    provider: ConnectorsFetchProvider;
    jinaApiKey?: string;
    firecrawlApiKey?: string;
    firecrawlBaseUrl?: string;
  };
}
export type ConnectorsLoadStatus = 'ok' | 'missing' | 'parse_failed';
export interface ConnectorsProviderRuntime {
  provider_name: string;
  runtime_state: 'ready' | 'missing_config' | 'invalid_config' | 'inactive' | 'not_implemented';
  runtime_reason?: string;
}
export interface ConnectorsConfigSnapshot {
  config: ConnectorsConfig;
  loadStatus: ConnectorsLoadStatus;
  providers: ConnectorsProviderRuntime[];
}
export interface CreditsBalance { balance: number; }

// Channel types
export type ChannelType = 'yunzhijia' | 'discord' | 'feishu' | 'qq' | 'qqbot' | 'weixin' | 'telegram';

export interface ChannelConfig {
  id: string;
  type: ChannelType;
  name: string;
  webhookUrl?: string;
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface ChannelBindCode {
  code: string;
  expiresAt: number;
}

// MCP types
export type MCPInstallSource = 'npm' | 'github' | 'local';

export interface MCPInstallConfig {
  id: string;
  name: string;
  source: MCPInstallSource;
  command: string;
  args?: string[];
  env?: Record<string, string>;
  enabled: boolean;
  createdAt: number;
}

// Usage types
export interface MeUsageSummary { totalRequests: number; totalTokens: number }
export interface MeHourlyUsageItem { hour: string; requests: number; tokens: number }
export interface MeDailyUsageItem { date: string; requests: number; tokens: number }
export interface MeModelUsageItem { model: string; requests: number; tokens: number; cost: number }

// Channel / Persona types (for settings shared)
export interface ChannelResponse { id: string; type: string; name: string; enabled: boolean }
export interface ChannelBindingResponse { id: string; channelType: string; bindingType: string }
export interface ChannelIdentityResponse { id: string; channelType: string; channelName?: string; boundAt?: string }

// Memory types
export type MemoryErrorEvent = { id: string; message: string; timestamp: number; errorType: string }

// Run type
export interface Run { id: string; threadId: string; status: string; createdAt: number; completedAt?: number }

export type LoopDefinitionStatus = 'active' | 'paused' | 'deleted';
export type LoopDefinitionOrigin = 'built_in' | 'user_template';
export type LoopRunStatus = 'running' | 'success' | 'failed' | 'blocked';
export type EvidenceAnomalyStatus = 'open' | 'resolved' | 'ignored';

export interface LoopDefinitionView {
  id: string;
  title: string;
  description: string;
  status: LoopDefinitionStatus;
  origin?: LoopDefinitionOrigin;
  activeRunId?: string;
  deletedAt?: number;
  deleteReason?: string;
  createdAt: number;
  updatedAt: number;
}

export type UserLoopTemplateKind = 'markdown_file' | 'task_completion';

export interface UserLoopTemplateView {
  loopId: string;
  kind: UserLoopTemplateKind;
  prompt: string;
  outputDirectory: string;
  outputFileName: string;
  scheduleActionId?: string;
  scheduleEnabled?: boolean;
  scheduleTrigger?: Record<string, unknown>;
  autoRunApproved?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface CreateUserLoopTemplateInputView {
  loopId: string;
  title: string;
  description?: string;
  kind: UserLoopTemplateKind;
  prompt: string;
  outputDirectory?: string;
  outputFileName?: string;
}

export interface CreateUserLoopTemplateResultView {
  template: UserLoopTemplateView;
  ignoredLegacyScheduleFields?: string[];
}

export interface CreateLoopScheduleInputView {
  id?: string;
  loopId: string;
  title: string;
  description?: string;
  trigger: Record<string, unknown>;
}

export interface LoopScheduleBindingView {
  loopId: string;
  kind: 'single' | 'multiple';
  count: number;
  activeCount: number;
  actionIds: string[];
  primaryActionId?: string;
  schedules: Array<{
    id: string;
    title: string;
    status: 'active' | 'paused';
    trigger: Record<string, unknown>;
    nextDueAt?: number;
    updatedAt: number;
  }>;
}

export interface TimedActionView {
  id: string;
  title: string;
  description?: string;
  status: string;
  trigger: Record<string, unknown>;
  executor: Record<string, unknown>;
  nextDueAt?: number;
  createdAt: number;
  updatedAt: number;
}

export interface AutomationsConfigView {
  globalBackgroundAutoRunEnabled: boolean;
}

export type AutomationRecentFailureSourceView = 'loop_run' | 'timed_action_run';

export interface AutomationRecentFailureItemView {
  id: string;
  source: AutomationRecentFailureSourceView;
  ownerId: string;
  title: string;
  status: string;
  message?: string;
  occurredAt: number;
  loopId?: string;
  loopOrigin?: 'built_in' | 'user_template';
  actionId?: string;
  actionAvailableInSchedules?: boolean;
}

export interface AutomationOverviewSnapshotView {
  generatedAt: number;
  sourceVersions: {
    loopStore: number;
    timedActionStore: number;
  };
  globalBackgroundAutoRunEnabled: boolean;
  totals: {
    loops: number;
    userLoops: number;
    schedules: number;
    activeSchedules: number;
    diagnostics: number;
    recentFailures: number;
  };
  recentFailures: AutomationRecentFailureItemView[];
}

export interface AutomationRunHistoryItemView {
  historyStatus?:AutomationRunHistoryItemView['status'];
  completionObservation?:LoopCompletionObservation;
  id: string;
  automationKind: 'loop' | 'notify' | 'agent_task';
  scheduleRunId?: string;
  loopRunId?: string;
  actionId?: string;
  loopId?: string;
  title: string;
  startedAt: number;
  finishedAt?: number;
  status: 'success' | 'failed' | 'blocked' | 'skipped' | 'running' | 'publication_pending';
  schedulerStatus?: string;
  loopStatus?: LoopRunStatus|'publication_pending';
  failureKind?: string;
  message?: string;
  outputPreviewAvailable?: boolean;
}

export type LoopOutputActionResultView =
  | { ok: true; loopId: string; pathLabel: string }
  | { ok: false; loopId: string; error: string; message?: string; pathLabel?: string; sizeBytes?: number; limitBytes?: number };

export type LoopOutputPreviewView =
  | { ok: true; loopId: string; pathLabel: string; content: string; sizeBytes: number; truncated: boolean;runId?:string;origin?:'verified_publication';checkedAt?:number }
  | { ok: false; loopId: string; error: string; message?: string; pathLabel?: string; sizeBytes?: number; limitBytes?: number };

export type LoopTaskResultView =
  | { ok: true; loopId: string; runId: string; content: string; taskId?: string;origin?:'verified_publication';checkedAt?:number }
  | { ok: false; loopId: string; error: string; message?: string; runId?: string; taskId?: string };

export interface LoopRunView {
  completionObservation?:LoopCompletionObservation;
  businessState?:LoopRunStatus|'publication_pending';
  id: string;
  loopId: string;
  status: LoopRunStatus;
  trigger: { kind: string; [key: string]: unknown };
  evidenceIds: string[];
  startedAt: number;
  finishedAt?: number;
  updatedAt: number;
  failureKind?: string;
  message?: string;
  summary?: string;
  nextActionKind?: string;
  nextActionSummary?: string;
}

export interface EvidenceAnomalyView {
  id: string;
  loopId: string;
  ownerKind: string;
  ownerId: string;
  kind: string;
  status: EvidenceAnomalyStatus;
  firstSeenAt: number;
  lastSeenAt: number;
  lastResolvedAt?: number;
  seenCount: number;
  ignoredUntil?: number;
  message: string;
  evidenceIds: string[];
  metadata: Record<string, unknown>;
}

export type RunLoopNowResultView =
  | {status:'publication_pending'|'executing';run:LoopRunView}
  | {status:'already_completed';completedRunId:string}
  | { status: 'success'; run: LoopRunView }
  | { status: 'blocked'; run: LoopRunView }
  | { status: 'failed'; run: LoopRunView }
  | { status: 'already_running'; activeRunId: string }
  | { status: 'skipped'; reason: 'paused' | 'missing_loop' | 'deleted_loop' };

export interface UploadedThreadAttachment { id: string; fileName: string; fileSize: number }

export type LearnedConstraintSourceView = 'llm_extraction' | 'rule_extraction' | 'user_manual';
export type LearnedConstraintDeactivationReasonView = 'user' | 'stale' | 'ineffective' | 'overflow' | 'superseded';

export interface LearnedConstraintView {
  id: string;
  loopId: string;
  source: LearnedConstraintSourceView;
  rule: string;
  sourceRunId: string;
  failureKind: string | null;
  failureReason: string | null;
  active: boolean;
  hitCount: number;
  consecutiveIneffectiveCount: number;
  createdAt: number;
  updatedAt: number;
  lastHitAt: number | null;
  supersededBy: string | null;
  deactivationReason: LearnedConstraintDeactivationReasonView | null;
  extractionContext: string | null;
}
