import { useEffect, useState } from 'react';
import { Brain, RefreshCw } from 'lucide-react';
import { api } from '../api';
import { getDesktopApi } from '../shared/desktop';
import { useLocale } from '../contexts/LocaleContext';

interface MemoryEntryView {
  id: string;
  content: string;
  tags?: string[];
  createdAt?: number | string;
  source?: string;
}

interface LayerStats {
  l0: number;
  l1: number;
  l2: number;
  l3: number;
  dbSizeBytes: number;
}

function formatCreatedAt(value: number | string | undefined): string {
  if (typeof value === 'number') {
    return new Date(value).toLocaleString();
  }
  if (typeof value === 'string' && value.trim()) {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) {
      return parsed.toLocaleString();
    }
  }
  return '';
}

export function LocalMemoryStats() {
  const { t } = useLocale();
  const [entries, setEntries] = useState<MemoryEntryView[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [layerStats, setLayerStats] = useState<LayerStats | null>(null);

  const loadEntries = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.listMemories();
      setEntries(Array.isArray(result) ? result as MemoryEntryView[] : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setEntries([]);
    } finally {
      setLoading(false);
    }
    try {
      const w = getDesktopApi() as any;
      if (w?.memoryStats) {
        const stats = await w.memoryStats();
        if (stats) setLayerStats(stats);
      }
    } catch {}
  };

  useEffect(() => {
    void loadEntries();
  }, []);

  return (
    <div
      className="rounded-2xl border p-4"
      style={{
        borderColor: 'var(--c-border)',
        background: 'var(--c-bg-soft)',
      }}
    >
      <div className="mb-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div
            className="flex size-9 items-center justify-center rounded-xl"
            style={{ background: 'var(--c-bg-elevated)' }}
          >
            <Brain size={18} />
          </div>
          <div>
            <div className="text-sm font-medium text-[var(--c-text-primary)]">Notebook</div>
            <div className="text-xs text-[var(--c-text-secondary)]">
              {loading ? t.localMemoryStatsLoading : t.localMemoryStatsCount(entries.length)}
            </div>
          </div>
        </div>
        {layerStats ? (
          <div className="mt-3 grid grid-cols-4 gap-2 text-xs">
            <div className="rounded-lg px-2 py-1" style={{ background: 'var(--c-bg-elevated)' }}>
              <div className="text-[var(--c-text-secondary)]">{t.localMemoryStatsL0}</div>
              <div className="font-medium text-[var(--c-text-primary)]">{layerStats.l0}</div>
            </div>
            <div className="rounded-lg px-2 py-1" style={{ background: 'var(--c-bg-elevated)' }}>
              <div className="text-[var(--c-text-secondary)]">{t.localMemoryStatsL1}</div>
              <div className="font-medium text-[var(--c-text-primary)]">{layerStats.l1}</div>
            </div>
            <div className="rounded-lg px-2 py-1" style={{ background: 'var(--c-bg-elevated)' }}>
              <div className="text-[var(--c-text-secondary)]">{t.localMemoryStatsL2}</div>
              <div className="font-medium text-[var(--c-text-primary)]">{layerStats.l2}</div>
            </div>
            <div className="rounded-lg px-2 py-1" style={{ background: 'var(--c-bg-elevated)' }}>
              <div className="text-[var(--c-text-secondary)]">{t.localMemoryStatsL3}</div>
              <div className="font-medium text-[var(--c-text-primary)]">{layerStats.l3}</div>
            </div>
          </div>
        ) : null}
        <button
          type="button"
          onClick={() => void loadEntries()}
          className="inline-flex h-8 items-center gap-1 rounded-lg px-3 text-xs transition-colors"
          style={{
            border: '1px solid var(--c-border)',
            background: 'var(--c-bg-elevated)',
            color: 'var(--c-text-secondary)',
          }}
        >
          <RefreshCw size={12} />
          {t.localMemoryStatsRefresh}
        </button>
      </div>

      {error ? (
        <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-600">
          {t.localMemoryStatsLoadFailed(error)}
        </div>
      ) : null}

      {!loading && !error && entries.length === 0 ? (
        <div className="rounded-xl border border-dashed px-4 py-6 text-sm text-[var(--c-text-secondary)]">
          {t.localMemoryStatsEmpty}
        </div>
      ) : null}

      {entries.length > 0 ? (
        <div className="space-y-2">
          {entries.slice(0, 8).map((entry) => (
            <div
              key={entry.id}
              className="rounded-xl border px-3 py-2"
              style={{
                borderColor: 'var(--c-border-subtle)',
                background: 'var(--c-bg-elevated)',
              }}
            >
              <div className="mb-1 text-sm text-[var(--c-text-primary)]">{entry.content}</div>
              <div className="flex flex-wrap items-center gap-2 text-[11px] text-[var(--c-text-secondary)]">
                {entry.tags && entry.tags.length > 0 ? (
                  <span>{entry.tags.join(' / ')}</span>
                ) : null}
                {entry.source ? <span>{t.localMemoryStatsSource(entry.source)}</span> : null}
                {formatCreatedAt(entry.createdAt) ? <span>{formatCreatedAt(entry.createdAt)}</span> : null}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
