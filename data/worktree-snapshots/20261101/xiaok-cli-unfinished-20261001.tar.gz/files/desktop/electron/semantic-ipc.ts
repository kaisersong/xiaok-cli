import { captureExecutionValue } from './loop-verification-execution.js';
import type { KSwarmSemanticService } from './kswarm-semantic-service.js';
import type { IpcHandleRegistrar } from './shutdown-aware-ipc-main.js';

/**
 * CollaborationRoom semantic controller (design §12, §16.3). Null until the
 * broker/KSwarm service adapters are wired in main — renderer calls then get
 * the stable broker_unavailable degraded code instead of a raw crash.
 */
export interface CollaborationRoomSemanticController {
  listRooms(): unknown | Promise<unknown>;
  getRoom(roomId: string): unknown | Promise<unknown>;
  createRoom(input: unknown): unknown | Promise<unknown>;
  archiveRoom(input: unknown): unknown | Promise<unknown>;
  deleteRoom?(input: unknown, authority: {requestSource: 'user'}): unknown | Promise<unknown>;
  updateRoomMembers(input: unknown): unknown | Promise<unknown>;
  sendMessage(input: unknown): unknown | Promise<unknown>;
  markRoomSeen(input: unknown): unknown | Promise<unknown>;
  cancelDiscussion(input: unknown): unknown | Promise<unknown>;
  createProjectFromRoom(input: unknown): unknown | Promise<unknown>;
  createTaskFromRoomMessage(input: unknown): unknown | Promise<unknown>;
}

export interface AssistantSemanticController {
  getOverview(): unknown | Promise<unknown>;
  activate(input: { requestSource: 'user' }): unknown | Promise<unknown>;
  pause(input: { requestSource: 'user' }): unknown | Promise<unknown>;
  resume(input: { requestSource: 'user' }): unknown | Promise<unknown>;
  acceptCandidate(input: { candidateId: string; collectionId?: string; requestSource: 'user' }): unknown | Promise<unknown>;
  rejectCandidate(input: { candidateId: string; requestSource: 'user' }): unknown | Promise<unknown>;
}

export function registerSemanticDesktopIpc(
  ipcMain: IpcHandleRegistrar,
  options: {
    assistant: AssistantSemanticController;
    authorizeAssistant?: (event: unknown) => boolean;
    authorizeRoomDeletion?: (event: unknown) => boolean;
    kswarm: KSwarmSemanticService;
    collaborationRooms?: CollaborationRoomSemanticController | null;
  },
): void {
  const { assistant, kswarm } = options;
  const rooms = options.collaborationRooms ?? null;
  const unavailable = () => ({ ok: false, code: 'broker_unavailable' });
  const roomHandler = <T,>(fn: (controller: CollaborationRoomSemanticController, input: T) => unknown | Promise<unknown>) =>
    (input: T) => (rooms ? fn(rooms, input) : unavailable());
  function assistantInput(event: unknown, args: unknown[], fields?: string[]): Record<string, unknown> {
    if (options.authorizeAssistant?.(event) !== true) throw Error('assistant_ipc_denied');
    if (args.length !== (fields ? 1 : 0)) throw Error('assistant_ipc_input');
    if (!fields) return {};
    const input = captureExecutionValue(args[0]);
    if (!input || typeof input !== 'object' || Array.isArray(input)
      || Object.keys(input).some(key => !fields.includes(key))) throw Error('assistant_ipc_input');
    return input as Record<string, unknown>;
  }
  ipcMain.handle('desktop:assistant:getOverview', (event, ...args) => { assistantInput(event, args); return assistant.getOverview(); });
  ipcMain.handle('desktop:assistant:activate', (event, ...args) => { assistantInput(event, args); return assistant.activate({ requestSource: 'user' }); });
  ipcMain.handle('desktop:assistant:pause', (event, ...args) => { assistantInput(event, args); return assistant.pause({ requestSource: 'user' }); });
  ipcMain.handle('desktop:assistant:resume', (event, ...args) => { assistantInput(event, args); return assistant.resume({ requestSource: 'user' }); });
  ipcMain.handle('desktop:assistant:acceptCandidate', (event, ...args) => {
    const input = assistantInput(event, args, ['candidateId', 'collectionId']);
    return assistant.acceptCandidate({candidateId: readId(input.candidateId), collectionId: readOptionalId(input.collectionId), requestSource: 'user'});
  });
  ipcMain.handle('desktop:assistant:rejectCandidate', (event, ...args) => {
    const input = assistantInput(event, args, ['candidateId']);
    return assistant.rejectCandidate({candidateId: readId(input.candidateId), requestSource: 'user'});
  });

  ipcMain.handle('desktop:kswarm:team:plan', (_event, input) => kswarm.planProjectTeam({ projectId: readId(input?.projectId) }));

  // CollaborationRoom semantic channels: room mutations are ONLY reachable
  // here — the kswarmProxy* routes deny every room/link path (design §9.3).
  ipcMain.handle('desktop:collaborationRoom:listRooms', () => roomHandler((controller) => controller.listRooms())(undefined));
  ipcMain.handle('desktop:collaborationRoom:getRoom', (_event, roomId: string) => roomHandler((controller) => controller.getRoom(roomId))(roomId));
  ipcMain.handle('desktop:collaborationRoom:createRoom', (_event, input: unknown) => roomHandler((controller) => controller.createRoom(input))(input));
  ipcMain.handle('desktop:collaborationRoom:archiveRoom', (_event, input: unknown) => roomHandler((controller) => controller.archiveRoom(input))(input));
  ipcMain.handle('desktop:collaborationRoom:deleteRoom', (event, input: unknown) => {
    if (options.authorizeRoomDeletion?.(event) !== true) return {ok: false, code: 'room_actor_forbidden'};
    return rooms?.deleteRoom ? rooms.deleteRoom(input, {requestSource: 'user'}) : unavailable();
  });
  ipcMain.handle('desktop:collaborationRoom:updateMembers', (_event, input: unknown) => roomHandler((controller) => controller.updateRoomMembers(input))(input));
  ipcMain.handle('desktop:collaborationRoom:sendMessage', (_event, input: unknown) => roomHandler((controller) => controller.sendMessage(input))(input));
  ipcMain.handle('desktop:collaborationRoom:markSeen', (_event, input: unknown) => roomHandler((controller) => controller.markRoomSeen(input))(input));
  ipcMain.handle('desktop:collaborationRoom:cancelDiscussion', (_event, input: unknown) => roomHandler((controller) => controller.cancelDiscussion(input))(input));
  ipcMain.handle('desktop:collaborationRoom:createProjectFromRoom', (_event, input: unknown) => roomHandler((controller) => controller.createProjectFromRoom(input))(input));
  ipcMain.handle('desktop:collaborationRoom:createTaskFromRoomMessage', (_event, input: unknown) => roomHandler((controller) => controller.createTaskFromRoomMessage(input))(input));
  ipcMain.handle('desktop:kswarm:team:apply', (_event, input) => kswarm.applyProjectTeamPlan({
    projectId: readId(input?.projectId),
    planId: readId(input?.planId),
    projectRevision: readRevision(input?.projectRevision),
  }));
  ipcMain.handle('desktop:kswarm:team:getOperation', (_event, input) => kswarm.getProjectTeamOperation({ projectId: readId(input?.projectId) }));
  ipcMain.handle('desktop:kswarm:project:create', (_event, input) => kswarm.createKSwarmProject(readRecord(input)));
  ipcMain.handle('desktop:kswarm:project:updateExecutionMode', (_event, input) => kswarm.updateKSwarmProjectExecutionMode({
    projectId: readId(input?.projectId),
    executionMode: readExecutionMode(input?.executionMode),
  }));
  ipcMain.handle('desktop:kswarm:project:delete', (_event, input) => kswarm.deleteKSwarmProject({ projectId: readId(input?.projectId) }));
  ipcMain.handle('desktop:kswarm:agent:create', (_event, input) => kswarm.createKSwarmAgent(readRecord(input), { requestSource: 'user' }));
  ipcMain.handle('desktop:kswarm:agent:update', (_event, input) => kswarm.updateKSwarmAgent({
    id: readId(input?.agentId), changes: readRecord(input?.patch),
  }, { requestSource: 'user' }));
  ipcMain.handle('desktop:kswarm:agent:archive', (_event, input) => kswarm.archiveKSwarmAgent({ id: readId(input?.agentId) }));
  ipcMain.handle('desktop:kswarm:agent:start', (_event, input) => kswarm.startKSwarmAgent({ id: readId(input?.agentId) }));
  ipcMain.handle('desktop:kswarm:agent:stop', (_event, input) => kswarm.stopKSwarmAgent({ id: readId(input?.agentId) }));
  ipcMain.handle('desktop:kswarm:agent:probe', (_event, input) => kswarm.probeKSwarmAgent({ id: readId(input?.agentId) }));
}

function readId(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) throw new Error('id_required');
  return value.trim();
}

function readOptionalId(value: unknown): string | undefined {
  return value === undefined ? undefined : readId(value);
}

function readRevision(value: unknown): number {
  if (!Number.isSafeInteger(value) || Number(value) < 0) throw new Error('invalid_project_revision');
  return Number(value);
}

function readExecutionMode(value: unknown): 'direct' | 'auto' | 'workflow_preferred' {
  if (value === 'direct' || value === 'auto' || value === 'workflow_preferred') return value;
  throw new Error('invalid_execution_mode');
}

function readRecord(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('object_required');
  return value as Record<string, unknown>;
}
