import { parseGoalVerificationDefinition } from '../../src/runtime/goal/verification-definition.js';
import { authorizeDesktopValidationMaterials } from './desktop-validation-materials.js';
import { createDesktopObservationApprovals } from './desktop-observation-approval.js';
import { parseObservationPolicyFile, describeProductObservationPolicy } from '../../src/runtime/sol-pi/product-bootstrap.js';
import { readClipboardPathCandidates } from './clipboard-file-paths.js';
import { app, BrowserWindow, clipboard, dialog, shell, systemPreferences, type IpcMain, type IpcMainInvokeEvent } from 'electron';
import { randomUUID } from 'node:crypto';
import { mkdir, readdir, readFile, realpath, rm, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import { basename, dirname, extname, isAbsolute, join, relative, resolve } from 'node:path';
import type { createDesktopServices } from './desktop-services.js';
import type { DesktopLoopRuntime } from './loop-executor.js';
import type { MeetingTranscriber } from './meeting-service.js';
import type { CreateUserLoopTemplateInput } from './loop-types.js';
import { createMeetingAudioPermissionService } from './meeting-audio-permission.js';
import type { ArtifactWorkspaceErrorCode } from '../shared/artifact-workspace-types.js';
import { OFFICE_EXTENSIONS } from '../../src/runtime/materials/document-formats.js';
import {
  computeKnowledgeContentHash,
  reconstructKnowledgeSourceText,
} from './kb-source-identity.js';
import type { IpcHandleRegistrar } from './shutdown-aware-ipc-main.js';
import { registerDesktopMultiAgentIpc, type MultiAgentIpcEvent } from './desktop-multi-agent-ipc.js';
import { parseGoalRequestId } from '../shared/goal-attachment.js';

type DesktopServices = ReturnType<typeof createDesktopServices>;

const ARTIFACT_WORKSPACE_ERROR_CODES = new Set<ArtifactWorkspaceErrorCode>([
  'workspace_not_found',
  'artifact_not_found',
  'structure_revision_conflict',
  'layout_revision_conflict',
  'version_referenced',
  'permission_denied',
  'invalid_target',
  'artifact_kind_mismatch',
  'artifact_too_large',
  'artifact_package_invalid',
  'plugin_unavailable',
  'runtime_unavailable',
  'artifact_missing',
  'feature_disabled',
  'generation_conflict',
]);

const GOAL_EVIDENCE_KINDS = new Set([
  'answer', 'file_artifact', 'command_action', 'project_update',
]);

function parseGoalThreadId(value: unknown): string {
  const threadId = typeof value === 'string' ? value.trim() : '';
  if (!threadId || threadId.length > 200) throw new Error('invalid_goal_thread_id');
  return threadId;
}

function parseGoalInput(raw: unknown, operation: 'create' | 'replace'): {
  verificationDefinition?: unknown;
  threadId: string;
  requestId?: string;
  objective: string;
  completionCriterion?: string;
  expectedEvidenceKinds: Array<'answer' | 'file_artifact' | 'command_action' | 'project_update'>;
  turnLimit?: number;
} {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('invalid_goal_input');
  const input = raw as Record<string, unknown>;
  const allowed = new Set([
    'threadId', 'objective', 'completionCriterion', 'expectedEvidenceKinds', 'turnLimit', 'requestId', 'verificationDefinition',
  ]);
  const unknown = Object.keys(input).find(key => !allowed.has(key));
  if (unknown) throw new Error(`invalid_goal_field:${unknown}`);
  const requestId = parseGoalRequestId(input.requestId);
  const objective = typeof input.objective === 'string' ? input.objective.trim() : '';
  if (!objective || objective.length > 4_000) throw new Error(`invalid_goal_${operation}_objective`);
  const completionCriterion = typeof input.completionCriterion === 'string'
    ? input.completionCriterion.trim()
    : undefined;
  if (completionCriterion && completionCriterion.length > 4_000) {
    throw new Error('invalid_goal_completion_criterion');
  }
  if (!Array.isArray(input.expectedEvidenceKinds) || input.expectedEvidenceKinds.length === 0) {
    throw new Error('invalid_goal_evidence_kinds');
  }
  const expectedEvidenceKinds = [...new Set(input.expectedEvidenceKinds)].map(value => {
    if (typeof value !== 'string' || !GOAL_EVIDENCE_KINDS.has(value)) {
      throw new Error('invalid_goal_evidence_kind');
    }
    return value as 'answer' | 'file_artifact' | 'command_action' | 'project_update';
  });
  const turnLimit = input.turnLimit;
  if (turnLimit !== undefined && (!Number.isSafeInteger(turnLimit) || (turnLimit as number) < 1 || (turnLimit as number) > 50)) {
    throw new Error('invalid_goal_turn_limit');
  }
  return {
    threadId: parseGoalThreadId(input.threadId), objective,
    ...(input.verificationDefinition === undefined ? {} : { verificationDefinition: parseGoalVerificationDefinition(input.verificationDefinition) }),
    ...(requestId === undefined ? {} : { requestId }),
    ...(completionCriterion ? { completionCriterion } : {}),
    expectedEvidenceKinds,
    ...(turnLimit === undefined ? {} : { turnLimit: turnLimit as number }),
  };
}

function sanitizeTaskContext(raw: unknown): { threadId?: string; taskIds?: string[] } | undefined {
  if (raw === undefined) return undefined;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('invalid_task_context');
  const context = raw as Record<string, unknown>;
  const threadId = context.threadId === undefined ? undefined : parseGoalThreadId(context.threadId);
  let taskIds: string[] | undefined;
  if (context.taskIds !== undefined) {
    if (!Array.isArray(context.taskIds)) throw new Error('invalid_task_context_task_ids');
    taskIds = context.taskIds.map(value => {
      if (typeof value !== 'string' || !value.trim() || value.length > 200) {
        throw new Error('invalid_task_context_task_id');
      }
      return value.trim();
    });
  }
  return {
    ...(threadId ? { threadId } : {}),
    ...(taskIds ? { taskIds } : {}),
  };
}

function sanitizeTaskCreateInput(raw: unknown): {
  prompt: string;
  materials: Array<{ materialId: string; role?: 'customer_material' | 'product_material' | 'template_material' | 'unknown' }>;
  context?: { threadId?: string; taskIds?: string[] };
} {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('invalid_task_input');
  const input = raw as Record<string, unknown>;
  if (typeof input.prompt !== 'string') throw new Error('invalid_task_prompt');
  if (!Array.isArray(input.materials)) throw new Error('invalid_task_materials');
  const roles = new Set(['customer_material', 'product_material', 'template_material', 'unknown']);
  const materials = input.materials.map(value => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('invalid_task_material');
    const material = value as Record<string, unknown>;
    if (typeof material.materialId !== 'string' || !material.materialId.trim()) throw new Error('invalid_task_material_id');
    if (material.role !== undefined && (typeof material.role !== 'string' || !roles.has(material.role))) {
      throw new Error('invalid_task_material_role');
    }
    return {
      materialId: material.materialId.trim(),
      ...(material.role ? { role: material.role as 'customer_material' | 'product_material' | 'template_material' | 'unknown' } : {}),
    };
  });
  const context = sanitizeTaskContext(input.context);
  return { prompt: input.prompt, materials, ...(context ? { context } : {}) };
}

const ARTIFACT_WORKSPACE_ALLOWED_FIELDS = {
  getArtifactWorkspaceSnapshot: ['conversationId', 'workspaceRootId', 'selectedArtifact'],
  closeArtifactWorkspace: ['conversationId', 'workspaceRootId'],
  readArtifactWorkspaceVersionPreview: ['conversationId', 'workspaceRootId', 'versionId'],
  exportArtifactWorkspaceVersion: ['conversationId', 'workspaceRootId', 'versionId'],
  createArtifactPlaceholder: ['conversationId', 'workspaceRootId', 'requestedKind', 'title', 'x', 'y', 'expectedStructureRevision'],
  submitArtifactGeneration: ['conversationId', 'workspaceRootId', 'placeholderNodeId', 'prompt', 'sourceVersionId', 'selectedArtifact', 'requestedKind', 'expectedStructureRevision'],
  cancelArtifactGeneration: ['conversationId', 'workspaceRootId', 'generationRequestId'],
  retryArtifactGeneration: ['conversationId', 'workspaceRootId', 'generationRequestId', 'prompt'],
  preferArtifactVersion: ['conversationId', 'workspaceRootId', 'lineageId', 'versionId', 'expectedStructureRevision'],
  removeArtifactWorkspaceNode: ['conversationId', 'workspaceRootId', 'nodeId', 'expectedStructureRevision'],
  updateArtifactWorkspaceLayout: ['conversationId', 'workspaceRootId', 'patches'],
  saveArtifactWorkspaceViewport: ['conversationId', 'workspaceRootId', 'viewport', 'expectedViewRevision'],
  createArtifactWorkspaceCollection: ['conversationId', 'workspaceRootId', 'title', 'x', 'y', 'expectedStructureRevision'],
  createArtifactWorkspaceNote: ['conversationId', 'workspaceRootId', 'title', 'noteText', 'x', 'y', 'expectedStructureRevision'],
  updateArtifactWorkspaceNote: ['conversationId', 'workspaceRootId', 'nodeId', 'noteText', 'expectedStructureRevision'],
  createArtifactWorkspaceRelation: ['conversationId', 'workspaceRootId', 'fromNodeId', 'toNodeId', 'kind', 'order', 'expectedStructureRevision'],
  setArtifactCollectionMembership: ['conversationId', 'workspaceRootId', 'collectionNodeId', 'memberNodeId', 'included', 'order', 'expectedStructureRevision'],
  recordArtifactWorkspaceEvent: ['conversationId', 'workspaceRootId', 'eventName', 'requestId', 'dedupeKey', 'metadata'],
} as const;

const ARTIFACT_WORKSPACE_REQUIRED_FIELDS: Record<ArtifactWorkspaceOperation, readonly string[]> = {
  getArtifactWorkspaceSnapshot: [],
  closeArtifactWorkspace: [],
  readArtifactWorkspaceVersionPreview: ['versionId'],
  exportArtifactWorkspaceVersion: ['versionId'],
  createArtifactPlaceholder: ['requestedKind', 'expectedStructureRevision'],
  submitArtifactGeneration: ['prompt'],
  cancelArtifactGeneration: ['generationRequestId'],
  retryArtifactGeneration: ['generationRequestId'],
  preferArtifactVersion: ['lineageId', 'versionId', 'expectedStructureRevision'],
  removeArtifactWorkspaceNode: ['nodeId', 'expectedStructureRevision'],
  updateArtifactWorkspaceLayout: ['patches'],
  saveArtifactWorkspaceViewport: ['viewport'],
  createArtifactWorkspaceCollection: ['title', 'expectedStructureRevision'],
  createArtifactWorkspaceNote: ['noteText', 'expectedStructureRevision'],
  updateArtifactWorkspaceNote: ['nodeId', 'noteText', 'expectedStructureRevision'],
  createArtifactWorkspaceRelation: ['fromNodeId', 'toNodeId', 'kind', 'expectedStructureRevision'],
  setArtifactCollectionMembership: ['collectionNodeId', 'memberNodeId', 'included', 'expectedStructureRevision'],
  recordArtifactWorkspaceEvent: ['eventName'],
};

const ARTIFACT_WORKSPACE_REQUESTED_KINDS = new Set(['image', 'html', 'markdown', 'slides']);
const ARTIFACT_WORKSPACE_RELATION_KINDS = new Set(['derived_from', 'references', 'part_of_collection']);
const ARTIFACT_WORKSPACE_EVENT_NAMES = new Set([
  'revision_compare_opened',
  'revision_branched',
]);

type ArtifactWorkspaceOperation = keyof typeof ARTIFACT_WORKSPACE_ALLOWED_FIELDS;
type ArtifactWorkspaceIpcRecord = Record<string, unknown>;

type ArtifactWorkspaceDesktopServices = Record<
  ArtifactWorkspaceOperation,
  (input: ArtifactWorkspaceIpcRecord, viewKey?: string) => unknown
> & {
  subscribeArtifactWorkspaceChanges?: (listener: (change: { conversationId: string; workspaceId: string }) => void) => () => void;
  closeArtifactWorkspaceViewKey?: (viewKey: string) => number;
};

function isRecordValue(value: unknown): value is ArtifactWorkspaceIpcRecord {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function requireNonEmptyString(input: ArtifactWorkspaceIpcRecord, key: string): void {
  if (typeof input[key] !== 'string' || !(input[key] as string).trim()) {
    throw Object.assign(new Error(`Invalid artifact workspace field: ${key}`), { code: 'invalid_target' });
  }
}

function validateOptionalPrimitiveFields(input: ArtifactWorkspaceIpcRecord): void {
  const stringFields = [
    'versionId', 'requestedKind', 'title', 'placeholderNodeId', 'prompt', 'sourceVersionId',
    'generationRequestId', 'lineageId', 'nodeId', 'noteText', 'fromNodeId', 'toNodeId',
    'kind', 'collectionNodeId', 'memberNodeId', 'eventName', 'requestId', 'dedupeKey',
  ];
  for (const key of stringFields) {
    if (key in input && typeof input[key] !== 'string') {
      throw Object.assign(new Error(`Invalid artifact workspace field: ${key}`), { code: 'invalid_target' });
    }
  }
  for (const key of ['x', 'y', 'order', 'expectedStructureRevision', 'expectedViewRevision']) {
    if (key in input && (typeof input[key] !== 'number' || !Number.isFinite(input[key]))) {
      throw Object.assign(new Error(`Invalid artifact workspace field: ${key}`), { code: 'invalid_target' });
    }
  }
  if ('included' in input && typeof input.included !== 'boolean') {
    throw Object.assign(new Error('Invalid artifact workspace field: included'), { code: 'invalid_target' });
  }
}

function validateArtifactWorkspaceNestedFields(input: ArtifactWorkspaceIpcRecord): void {
  for (const artifactField of ['selectedArtifact'] as const) {
    if (!(artifactField in input)) continue;
    if (!isRecordValue(input[artifactField])) {
      throw Object.assign(new Error(`Invalid artifact workspace field: ${artifactField}`), { code: 'invalid_target' });
    }
    const selected = input[artifactField];
    requireNonEmptyString(selected, 'artifactId');
    for (const key of ['sourceTaskId', 'kind', 'mimeType', 'title']) {
      if (key in selected && typeof selected[key] !== 'string') {
        throw Object.assign(new Error(`Invalid artifact workspace selected artifact field: ${key}`), { code: 'invalid_target' });
      }
    }
    input[artifactField] = Object.fromEntries(
      ['artifactId', 'sourceTaskId', 'kind', 'mimeType', 'title']
        .filter((key) => key in selected)
        .map((key) => [key, selected[key]]),
    );
  }
  if ('patches' in input) {
    if (!Array.isArray(input.patches)) {
      throw Object.assign(new Error('Invalid artifact workspace field: patches'), { code: 'invalid_target' });
    }
    input.patches = input.patches.map((value) => {
      if (!isRecordValue(value)) {
        throw Object.assign(new Error('Invalid artifact workspace layout patch'), { code: 'invalid_target' });
      }
      requireNonEmptyString(value, 'nodeId');
      for (const key of ['x', 'y', 'zIndex', 'expectedLayoutRevision']) {
        if (typeof value[key] !== 'number' || !Number.isFinite(value[key])) {
          throw Object.assign(new Error(`Invalid artifact workspace layout field: ${key}`), { code: 'invalid_target' });
        }
      }
      return {
        nodeId: value.nodeId,
        x: value.x,
        y: value.y,
        zIndex: value.zIndex,
        expectedLayoutRevision: value.expectedLayoutRevision,
      };
    });
  }
  if ('viewport' in input) {
    if (!isRecordValue(input.viewport)) {
      throw Object.assign(new Error('Invalid artifact workspace field: viewport'), { code: 'invalid_target' });
    }
    const viewport = input.viewport;
    for (const key of ['x', 'y', 'zoom']) {
      if (typeof viewport[key] !== 'number' || !Number.isFinite(viewport[key])) {
        throw Object.assign(new Error(`Invalid artifact workspace viewport field: ${key}`), { code: 'invalid_target' });
      }
    }
    input.viewport = { x: viewport.x, y: viewport.y, zoom: viewport.zoom };
  }
  if ('metadata' in input) {
    if (!isRecordValue(input.metadata)) {
      throw Object.assign(new Error('Invalid artifact workspace field: metadata'), { code: 'invalid_target' });
    }
    const metadata: Record<string, string | number | boolean | null> = {};
    for (const [key, value] of Object.entries(input.metadata)) {
      if (value !== null && !['string', 'number', 'boolean'].includes(typeof value)) {
        throw Object.assign(new Error(`Invalid artifact workspace metadata field: ${key}`), { code: 'invalid_target' });
      }
      metadata[key] = value as string | number | boolean | null;
    }
    input.metadata = metadata;
  }
}

export function sanitizeArtifactWorkspaceIpcInput(
  operation: ArtifactWorkspaceOperation,
  rawInput: unknown,
): ArtifactWorkspaceIpcRecord {
  if (!isRecordValue(rawInput)) {
    throw Object.assign(new Error('Artifact workspace input must be an object'), { code: 'invalid_target' });
  }
  const input = Object.fromEntries(
    ARTIFACT_WORKSPACE_ALLOWED_FIELDS[operation]
      .filter((key) => key in rawInput)
      .map((key) => [key, rawInput[key]]),
  );
  requireNonEmptyString(input, 'conversationId');
  // Renderer-supplied paths/roots are never authorization input. Keep the
  // legacy field in the wire allowlist for compatibility, then overwrite it
  // with a main-owned stable opaque identity.
  input.workspaceRootId = 'desktop-artifact-workspace-v1';
  for (const key of ARTIFACT_WORKSPACE_REQUIRED_FIELDS[operation]) {
    if (!(key in input)) {
      throw Object.assign(new Error(`Missing artifact workspace field: ${key}`), { code: 'invalid_target' });
    }
    if (typeof input[key] === 'string') requireNonEmptyString(input, key);
  }
  validateOptionalPrimitiveFields(input);
  validateArtifactWorkspaceNestedFields(input);
  if ('requestedKind' in input && !ARTIFACT_WORKSPACE_REQUESTED_KINDS.has(input.requestedKind as string)) {
    throw Object.assign(new Error('Invalid artifact workspace field: requestedKind'), { code: 'invalid_target' });
  }
  if (operation === 'submitArtifactGeneration' && !input.placeholderNodeId && !input.sourceVersionId && !input.selectedArtifact) {
    throw Object.assign(new Error('Artifact generation needs placeholderNodeId, sourceVersionId or selectedArtifact'), { code: 'invalid_target' });
  }
  if (operation === 'createArtifactWorkspaceRelation' && !ARTIFACT_WORKSPACE_RELATION_KINDS.has(input.kind as string)) {
    throw Object.assign(new Error('Invalid artifact workspace field: kind'), { code: 'invalid_target' });
  }
  if ('eventName' in input && !ARTIFACT_WORKSPACE_EVENT_NAMES.has(input.eventName as string)) {
    throw Object.assign(new Error('Invalid artifact workspace field: eventName'), { code: 'invalid_target' });
  }
  return input;
}

function artifactWorkspaceErrorCode(error: unknown): ArtifactWorkspaceErrorCode {
  if (isRecordValue(error) && typeof error.code === 'string' && ARTIFACT_WORKSPACE_ERROR_CODES.has(error.code as ArtifactWorkspaceErrorCode)) {
    return error.code as ArtifactWorkspaceErrorCode;
  }
  return 'runtime_unavailable';
}

export function normalizeArtifactWorkspaceIpcError(error: unknown): {
  ok: false;
  error: { code: ArtifactWorkspaceErrorCode; message: string; canonical?: unknown };
} {
  const record = isRecordValue(error) ? error : {};
  const canonical = record.canonical ?? record.canonicalSnapshot ?? record.canonicalNodes;
  const code = artifactWorkspaceErrorCode(error);
  return {
    ok: false,
    error: {
      code,
      message: code !== 'runtime_unavailable' && typeof record.message === 'string' && record.message
        ? record.message
        : 'Artifact workspace operation failed',
      ...(canonical === undefined ? {} : { canonical }),
    },
  };
}

function sanitizeArtifactWorkspacePreviewOutput(value: unknown): unknown {
  if (!isRecordValue(value)) return value;
  const output = Object.fromEntries(
    ['versionId', 'kind', 'mimeType', 'title', 'contentKind', 'content']
      .filter((key) => key in value)
      .map((key) => [key, value[key]]),
  );
  if (output.contentKind === 'package_manifest' && isRecordValue(output.content)) {
    const isSafeRef = (candidate: unknown): candidate is string => typeof candidate === 'string'
      && !!candidate
      && !candidate.startsWith('/')
      && !candidate.startsWith('\\')
      && !/^[a-z]:[\\/]/i.test(candidate)
      && !candidate.split(/[\\/]+/).includes('..');
    const files = Array.isArray(output.content.files)
      ? output.content.files.flatMap((file) => {
          if (!isRecordValue(file) || !isSafeRef(file.path)) return [];
          if (typeof file.size !== 'number' || !Number.isFinite(file.size) || typeof file.sha256 !== 'string') return [];
          return [{ path: file.path, size: file.size, sha256: file.sha256 }];
        })
      : [];
    output.content = {
      entryRef: isSafeRef(output.content.entryRef) ? output.content.entryRef : '',
      files,
    };
  } else if (typeof output.content !== 'string') {
    output.content = '';
  }
  return output;
}

function sanitizeArtifactWorkspaceSnapshotOutput(value: unknown): unknown {
  if (!isRecordValue(value)) return value;
  const output = Object.fromEntries(
    ['workspace', 'access', 'nodes', 'relations', 'lineages', 'versions', 'generationRequests', 'staging', 'view']
      .filter((key) => key in value)
      .map((key) => [key, value[key]]),
  );
  if (Array.isArray(output.staging)) {
    output.staging = output.staging.map((entry) => {
      if (!isRecordValue(entry)) return entry;
      const { fileRef: _fileRef, ...safe } = entry;
      return safe;
    });
  }
  return output;
}

function sanitizeArtifactWorkspaceExportOutput(value: unknown): unknown {
  if (!isRecordValue(value)) return value;
  return {
    exported: value.exported === true,
    ...(typeof value.canceled === 'boolean' ? { canceled: value.canceled } : {}),
  };
}

async function invokeArtifactWorkspaceOperation(
  operation: () => unknown,
  sanitizeData: (value: unknown) => unknown = (value) => value,
): Promise<unknown> {
  try {
    const value = await operation();
    if (isRecordValue(value) && value.ok === true && 'data' in value) {
      return { ok: true, data: sanitizeData(value.data) };
    }
    if (isRecordValue(value) && value.ok === false) return normalizeArtifactWorkspaceIpcError(value.error);
    return { ok: true, data: sanitizeData(value) };
  } catch (error) {
    return normalizeArtifactWorkspaceIpcError(error);
  }
}

function invokeArtifactWorkspaceIpcOperation(
  services: ArtifactWorkspaceDesktopServices,
  operation: ArtifactWorkspaceOperation,
  rawInput: unknown,
  options: {
    viewKey?: string;
    sanitizeData?: (value: unknown) => unknown;
  } = {},
): Promise<unknown> {
  return invokeArtifactWorkspaceOperation(() => {
    const input = sanitizeArtifactWorkspaceIpcInput(operation, rawInput);
    return options.viewKey === undefined
      ? services[operation](input)
      : services[operation](input, options.viewKey);
  }, options.sanitizeData);
}

interface RegisterDesktopIpcOptions {
  loopRuntime?: Pick<DesktopLoopRuntime, 'loopStore' | 'evidenceStore' | 'scanner' | 'runner' | 'listAnomalies'>;
  multiAgentAuthorize?: (event: MultiAgentIpcEvent) => { actorId: string } | null;
  getMainWindow?: () => BrowserWindow | null;
  registerLifetimeDisposer?: (dispose: () => void) => void;
}

const MEETING_TRANSCRIBER_ALLOWED_MODELS = new Set(['tiny', 'base', 'small', 'medium', 'large', 'turbo']);
const MEETING_SHERPA_ONNX_ALLOWED_MODELS = new Set(['sherpa-onnx-paraformer-zh-small-2024-03-09']);
const MEETING_TRANSCRIBER_ALLOWED_ENGINES = new Set(['sherpa-onnx-paraformer', 'whisper', 'volcengine-asr', 'aliyun-asr']);
const DEFAULT_MEETING_TRANSCRIBER_ENGINE = 'sherpa-onnx-paraformer';
const MEETING_RECORDING_ALLOWED_SCENARIOS = new Set(['discussion', 'meeting', 'sales']);
const DATA_URL_MIME_BY_EXTENSION = new Map<string, string>([
  ['.pdf', 'application/pdf'],
]);

const HTML_EDIT_IMAGE_MIME_BY_EXTENSION = new Map<string, string>([
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.gif', 'image/gif'],
  ['.webp', 'image/webp'],
  ['.avif', 'image/avif'],
]);

const meetingAudioPermissionService = createMeetingAudioPermissionService({
  platform: process.platform,
  getMediaAccessStatus: (mediaType) => systemPreferences.getMediaAccessStatus(mediaType),
  askForMediaAccess: (mediaType) => systemPreferences.askForMediaAccess(mediaType),
});

function getDataUrlMimeType(filePath: string): string | null {
  return DATA_URL_MIME_BY_EXTENSION.get(extname(filePath).toLowerCase()) ?? null;
}

function getHtmlEditImageMimeType(filePath: string): string | null {
  return HTML_EDIT_IMAGE_MIME_BY_EXTENSION.get(extname(filePath).toLowerCase()) ?? null;
}

function decodeBase64DataUrl(content: string): Buffer | null {
  const match = /^data:[^,;]+(?:;[^,]*)*;base64,([\s\S]*)$/i.exec(content);
  if (!match) return null;
  return Buffer.from(match[1], 'base64');
}

function decodeBase64Audio(content: string): Buffer {
  const dataUrl = decodeBase64DataUrl(content);
  return dataUrl ?? Buffer.from(content, 'base64');
}

function safeMeetingRecordingFileName(title: unknown): string {
  const raw = typeof title === 'string' ? title.trim() : '';
  const base = raw
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'meeting';
  const suffix = Math.random().toString(36).slice(2, 8);
  return `${Date.now()}-${base}-${suffix}.wav`;
}

function isPathInside(childPath: string, parentPath: string): boolean {
  const child = resolve(childPath);
  const parent = resolve(parentPath);
  const rel = relative(parent, child);
  return rel === '' || (!!rel && !rel.startsWith('..') && !isAbsolute(rel));
}

async function realpathIfExists(path: string): Promise<string> {
  try {
    return await realpath(path);
  } catch {
    return resolve(path);
  }
}

type ArtifactEditPurpose = 'html-edit' | 'text-edit';

const EDIT_PURPOSE_CONFIG: Record<ArtifactEditPurpose, { extensions: Set<string>; errorPrefix: string }> = {
  'html-edit': {
    extensions: new Set(['.html', '.htm']),
    errorPrefix: 'html_edit',
  },
  'text-edit': {
    extensions: new Set(['.md', '.markdown']),
    errorPrefix: 'text_edit',
  },
};

async function validateArtifactEditWritePath(
  filePath: string,
  services: DesktopServices,
  purpose: ArtifactEditPurpose,
): Promise<string | null> {
  const config = EDIT_PURPOSE_CONFIG[purpose];
  if (!filePath || typeof filePath !== 'string' || !isAbsolute(filePath)) {
    return `${config.errorPrefix}_path_not_allowed`;
  }

  const resolved = resolve(filePath);
  const extension = extname(resolved).toLowerCase();
  if (!config.extensions.has(extension)) {
    return `${config.errorPrefix}_invalid_extension`;
  }

  const segments = resolved.split(/[\\/]+/);
  if (segments.includes('node_modules') || basename(resolved).startsWith('.')) {
    return `${config.errorPrefix}_path_not_allowed`;
  }

  const allowedRoots = [
    services.getDataRoot(),
    app.getPath('downloads'),
    join(os.homedir(), '.kswarm', 'projects'),
    join(os.homedir(), '.xiaok', 'tasks'),
    // Report-renderer artifacts are written under the current working directory
    // (see isAllowedReportArtifactOutputPath in desktop-services, which allows
    // process.cwd()). Editing must be allowed there too, otherwise saving an
    // edit to a freshly generated report fails with path_not_allowed.
    process.cwd(),
  ];
  const parentReal = await realpathIfExists(dirname(resolved));
  const allowed = await Promise.all(allowedRoots.map((root) => realpathIfExists(root)));
  return allowed.some((root) => isPathInside(parentReal, root)) ? null : `${config.errorPrefix}_path_not_allowed`;
}

function log(level: string, msg: string, ...args: unknown[]) {
  const ts = new Date().toISOString();
  const payload = args.length ? ' ' + args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') : '';
  console.log(`[${ts}] [${level}] [ipc] ${msg}${payload}`);
}

export type MeetingTranscriberEngineForIpc = 'sherpa-onnx-paraformer' | 'whisper' | 'volcengine-asr' | 'aliyun-asr';

export interface MeetingTranscriberOptionsForIpc {
  engine: MeetingTranscriberEngineForIpc;
  model?: string;
  language?: string;
}

export function parseMeetingTranscriberOptions(input: unknown): MeetingTranscriberOptionsForIpc {
  const record = input && typeof input === 'object' ? input as Record<string, unknown> : {};
  const requestedEngine = typeof record.engine === 'string' ? record.engine.trim() : '';
  const model = typeof record.model === 'string' ? record.model.trim() : '';
  const language = typeof record.language === 'string' ? record.language.trim() : '';
  const engine = MEETING_TRANSCRIBER_ALLOWED_ENGINES.has(requestedEngine)
    ? requestedEngine as MeetingTranscriberEngineForIpc
    : MEETING_TRANSCRIBER_ALLOWED_MODELS.has(model)
      ? 'whisper'
      : DEFAULT_MEETING_TRANSCRIBER_ENGINE;
  const options: MeetingTranscriberOptionsForIpc = { engine };

  if (engine === 'whisper' && model && MEETING_TRANSCRIBER_ALLOWED_MODELS.has(model)) {
    options.model = model;
  }
  if (engine === 'sherpa-onnx-paraformer' && model && MEETING_SHERPA_ONNX_ALLOWED_MODELS.has(model)) {
    options.model = model;
  }
  if (language && language !== 'auto' && /^[a-z]{2,8}(?:-[a-z0-9]{2,8})?$/i.test(language)) {
    options.language = language;
  }

  return options;
}

async function createMeetingTranscriberForIpc(input: unknown): Promise<MeetingTranscriber> {
  const options = parseMeetingTranscriberOptions(input);
  if (options.engine === 'volcengine-asr') {
    const { loadConfig } = await import('../../src/utils/config.js');
    const { resolveMeetingVolcengineAsrCredentials } = await import('./meeting-asr-config.js');
    const { createVolcengineMeetingTranscriber } = await import('./meeting-online-asr-transcriber.js');
    return createVolcengineMeetingTranscriber(resolveMeetingVolcengineAsrCredentials(await loadConfig()));
  }
  if (options.engine === 'aliyun-asr') {
    const { loadConfig } = await import('../../src/utils/config.js');
    const { resolveMeetingAliyunAsrCredentials } = await import('./meeting-asr-config.js');
    const { createAliyunMeetingTranscriber } = await import('./meeting-online-asr-transcriber.js');
    return createAliyunMeetingTranscriber(resolveMeetingAliyunAsrCredentials(await loadConfig()));
  }
  if (options.engine === 'sherpa-onnx-paraformer') {
    const { createSherpaOnnxParaformerTranscriber } = await import('./meeting-sherpa-onnx-transcriber.js');
    const { createLocalMeetingTranscriber } = await import('./meeting-local-transcriber.js');
    return createFallbackMeetingTranscriber([
      createSherpaOnnxParaformerTranscriber({ model: options.model }),
      createLocalMeetingTranscriber(toWhisperFallbackOptions(options)),
    ]);
  }

  const { createLocalMeetingTranscriber } = await import('./meeting-local-transcriber.js');
  return createLocalMeetingTranscriber(toWhisperFallbackOptions(options));
}

function toWhisperFallbackOptions(options: MeetingTranscriberOptionsForIpc): { model?: string; language?: string } {
  return {
    ...(options.engine === 'whisper' && options.model ? { model: options.model } : {}),
    ...(options.language ? { language: options.language } : {}),
  };
}

function createFallbackMeetingTranscriber(transcribers: MeetingTranscriber[]): MeetingTranscriber {
  return {
    async transcribeFile(input) {
      let lastError: unknown;
      for (const transcriber of transcribers) {
        try {
          return await transcriber.transcribeFile(input);
        } catch (error) {
          lastError = error;
          if (!isMeetingTranscriberFallbackError(error)) {
            throw error;
          }
        }
      }
      throw lastError instanceof Error ? lastError : new Error('transcription_failed');
    },
  };
}

async function restorePreviewPunctuation(transcription: Awaited<ReturnType<MeetingTranscriber['transcribeFile']>>) {
  const { createMeetingPunctuationService } = await import('./meeting-punctuation-service.js');
  const punctuationService = createMeetingPunctuationService();
  const result = await punctuationService.restoreFinalPunctuation({
    text: transcription.text,
    segments: transcription.segments,
    language: 'zh',
  });
  return {
    text: result.punctuatedText,
    segments: result.segments.map(segment => ({
      start: segment.start,
      end: segment.end,
      text: segment.punctuatedText,
    })),
  };
}

function isMeetingTranscriberFallbackError(error: unknown): boolean {
  if (!(error instanceof Error)) return false;
  return error.message === 'sherpa_onnx_runtime_missing'
    || error.message === 'sherpa_onnx_model_not_downloaded'
    || error.message === 'sherpa_onnx_model_incomplete';
}

type MeetingRecordingScenarioForIpc = 'discussion' | 'meeting' | 'sales';

function parseMeetingRecordingScenario(input: unknown): MeetingRecordingScenarioForIpc {
  const record = input && typeof input === 'object' ? input as Record<string, unknown> : {};
  const scenario = typeof record.scenario === 'string' ? record.scenario.trim() : '';
  return MEETING_RECORDING_ALLOWED_SCENARIOS.has(scenario)
    ? scenario as MeetingRecordingScenarioForIpc
    : 'meeting';
}

function parseMeetingTranscriptSegments(input: unknown): Array<{ start: number; end: number; text: string }> {
  if (!Array.isArray(input)) return [];
  return input.flatMap((item) => {
    if (!item || typeof item !== 'object') return [];
    const record = item as Record<string, unknown>;
    const text = typeof record.text === 'string' ? record.text.trim() : '';
    if (!text) return [];
    const start = Number(record.start);
    const end = Number(record.end);
    return [{
      start: Number.isFinite(start) ? start : 0,
      end: Number.isFinite(end) ? end : Number.isFinite(start) ? start : 0,
      text,
    }];
  });
}

function parseMeetingLiveSessionId(value: unknown): string {
  const sessionId = typeof value === 'string' ? value.trim() : '';
  if (!sessionId || sessionId.length > 100 || !/^[a-z0-9-]+$/i.test(sessionId)) {
    throw new Error('meeting_live_session_not_found');
  }
  return sessionId;
}

function stableMeetingLiveError(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message === 'aliyun_asr_not_configured'
    || message === 'volcengine_asr_not_configured'
    || /^(?:aliyun|volcengine|meeting)_live_[a-z0-9_]+(?::[a-z0-9_.-]+)?$/i.test(message)) {
    return message;
  }
  return 'meeting_live_failed';
}

export async function registerDesktopIpc(
  ipcMain: IpcHandleRegistrar,
  window: BrowserWindow,
  services: DesktopServices,
  options: RegisterDesktopIpcOptions = {}
): Promise<void> {
  const primaryWindow = () => options.getMainWindow?.() ?? window;
  const disposeMultiAgentViews = registerDesktopMultiAgentIpc(ipcMain, services.multiAgent, {
    authorize: event => options.multiAgentAuthorize?.(event) ?? null,
  });
  const { createAliyunLiveTranscriptionRegistry } = await import('./meeting-aliyun-live-transcriber.js');
  const { createVolcengineLiveTranscriptionRegistry } = await import('./meeting-volcengine-live-transcriber.js');
  const meetingAliyunLiveRegistry = createAliyunLiveTranscriptionRegistry();
  const meetingVolcengineLiveRegistry = createVolcengineLiveTranscriptionRegistry();
  const meetingLiveSessions = new Map<string, { ownerId: number; provider: 'aliyun' | 'volcengine' }>();
  const meetingLiveOwnerCleanupRegistered = new Set<number>();

  const cancelMeetingLiveOwner = (ownerId: number) => {
    meetingAliyunLiveRegistry.cancelOwner(ownerId);
    meetingVolcengineLiveRegistry.cancelOwner(ownerId);
    for (const [sessionId, active] of meetingLiveSessions) {
      if (active.ownerId === ownerId) meetingLiveSessions.delete(sessionId);
    }
  };

  const readMeetingLiveSession = (ownerId: number, sessionId: string) => {
    const active = meetingLiveSessions.get(sessionId);
    if (!active || active.ownerId !== ownerId) throw new Error('meeting_live_session_not_found');
    return active;
  };
  const artifactWorkspaceServices = services as DesktopServices & ArtifactWorkspaceDesktopServices;
  const unsubscribeArtifactWorkspaceChanges = artifactWorkspaceServices.subscribeArtifactWorkspaceChanges?.((change) => {
    const targets = typeof BrowserWindow?.getAllWindows === 'function'
      ? BrowserWindow.getAllWindows()
      : [window];
    for (const target of targets) {
      if (!target.isDestroyed()) target.webContents.send('desktop:artifactWorkspace:changed', change);
    }
  });
  const unsubscribeGoalChanges = services.subscribeGoalChanged?.((change) => {
    const targets = typeof BrowserWindow?.getAllWindows === 'function'
      ? BrowserWindow.getAllWindows()
      : [window];
    for (const target of targets.length > 0 ? targets : [window]) {
      if (!target.isDestroyed()) target.webContents.send('desktop:goal:changed', change);
    }
  });
  const unsubscribeGoalTaskPrepared = services.subscribeGoalTaskPrepared?.((prepared) => {
    const targets = typeof BrowserWindow?.getAllWindows === 'function'
      ? BrowserWindow.getAllWindows()
      : [window];
    for (const target of targets.length > 0 ? targets : [window]) {
      if (!target.isDestroyed()) target.webContents.send('desktop:goal:taskPrepared', prepared);
    }
  });
  const disposeApplicationViews = () => {
    disposeMultiAgentViews();
    unsubscribeArtifactWorkspaceChanges?.();
    unsubscribeGoalChanges?.();
    unsubscribeGoalTaskPrepared?.();
  };
  options.registerLifetimeDisposer?.(disposeApplicationViews);
  const onPrimaryClosed = () => {
    if (!options.registerLifetimeDisposer) disposeApplicationViews();
    artifactWorkspaceServices.closeArtifactWorkspaceViewKey?.('primary');
  };
  if (typeof window.once === 'function') window.once('closed', onPrimaryClosed);
  const secondaryArtifactWorkspaceViewKeys = new Map<number, string>();
  const artifactWorkspaceViewKey = (event: IpcMainInvokeEvent): string => {
    const senderWindow = typeof BrowserWindow?.fromWebContents === 'function'
      ? BrowserWindow.fromWebContents(event.sender)
      : undefined;
    if (senderWindow === primaryWindow() || senderWindow?.webContents.id === primaryWindow().webContents.id || event.sender.id === primaryWindow().webContents.id) {
      return 'primary';
    }
    const ownerId = senderWindow?.id ?? event.sender.id;
    const existing = secondaryArtifactWorkspaceViewKeys.get(ownerId);
    if (existing) return existing;
    const viewKey = `window-${randomUUID()}`;
    secondaryArtifactWorkspaceViewKeys.set(ownerId, viewKey);
    if (typeof senderWindow?.once === 'function') {
      senderWindow.once('closed', () => {
        secondaryArtifactWorkspaceViewKeys.delete(ownerId);
        artifactWorkspaceServices.closeArtifactWorkspaceViewKey?.(viewKey);
      });
    }
    return viewKey;
  };

  ipcMain.handle('desktop:artifactWorkspace:getArtifactWorkspaceSnapshot', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'getArtifactWorkspaceSnapshot', rawInput, {
      viewKey: artifactWorkspaceViewKey(event),
      sanitizeData: sanitizeArtifactWorkspaceSnapshotOutput,
    });
  });
  ipcMain.handle('desktop:artifactWorkspace:closeArtifactWorkspace', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'closeArtifactWorkspace', rawInput, {
      viewKey: artifactWorkspaceViewKey(event),
    });
  });
  ipcMain.handle('desktop:artifactWorkspace:readArtifactWorkspaceVersionPreview', async (_event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'readArtifactWorkspaceVersionPreview', rawInput, {
      sanitizeData: sanitizeArtifactWorkspacePreviewOutput,
    });
  });
  ipcMain.handle('desktop:artifactWorkspace:exportArtifactWorkspaceVersion', async (event, rawInput) => {
    return invokeArtifactWorkspaceOperation(async () => {
      const input = sanitizeArtifactWorkspaceIpcInput('exportArtifactWorkspaceVersion', rawInput);
      const prepared = await artifactWorkspaceServices.exportArtifactWorkspaceVersion(input);
      if (!isRecordValue(prepared) || typeof prepared.sourcePath !== 'string' || typeof prepared.fileName !== 'string') {
        throw Object.assign(new Error('Artifact workspace export is unavailable'), { code: 'artifact_missing' });
      }
      const senderWindow = (typeof BrowserWindow?.fromWebContents === 'function'
        ? BrowserWindow.fromWebContents(event.sender)
        : undefined) ?? window;
      const selected = await dialog.showSaveDialog(senderWindow, { defaultPath: prepared.fileName });
      if (selected.canceled || !selected.filePath) return { exported: false, canceled: true };
      await artifactWorkspaceServices.exportArtifactWorkspaceVersion({ ...input, destinationPath: selected.filePath });
      return { exported: true };
    }, sanitizeArtifactWorkspaceExportOutput);
  });
  ipcMain.handle('desktop:artifactWorkspace:createArtifactPlaceholder', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'createArtifactPlaceholder', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:submitArtifactGeneration', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'submitArtifactGeneration', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:cancelArtifactGeneration', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'cancelArtifactGeneration', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:retryArtifactGeneration', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'retryArtifactGeneration', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:preferArtifactVersion', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'preferArtifactVersion', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:removeArtifactWorkspaceNode', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'removeArtifactWorkspaceNode', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:updateArtifactWorkspaceLayout', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'updateArtifactWorkspaceLayout', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:saveArtifactWorkspaceViewport', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'saveArtifactWorkspaceViewport', rawInput, {
      viewKey: artifactWorkspaceViewKey(event),
    });
  });
  ipcMain.handle('desktop:artifactWorkspace:createArtifactWorkspaceCollection', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'createArtifactWorkspaceCollection', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:createArtifactWorkspaceNote', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'createArtifactWorkspaceNote', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:updateArtifactWorkspaceNote', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'updateArtifactWorkspaceNote', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:createArtifactWorkspaceRelation', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'createArtifactWorkspaceRelation', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:setArtifactCollectionMembership', async (event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'setArtifactCollectionMembership', rawInput, { viewKey: artifactWorkspaceViewKey(event) });
  });
  ipcMain.handle('desktop:artifactWorkspace:recordArtifactWorkspaceEvent', async (_event, rawInput) => {
    return invokeArtifactWorkspaceIpcOperation(artifactWorkspaceServices, 'recordArtifactWorkspaceEvent', rawInput);
  });
  ipcMain.handle('desktop:getModelConfig', async () => {
    log('info', 'getModelConfig');
    const r = await services.getModelConfig();
    log('info', 'getModelConfig ok', { providers: r?.providers?.length ?? 0 });
    return r;
  });
  ipcMain.handle('desktop:saveModelConfig', async (_event, input) => {
    log('info', 'saveModelConfig', { providerId: input?.providerId });
    const r = await services.saveModelConfig(input, options.multiAgentAuthorize?.(_event) ? { ...options.multiAgentAuthorize(_event)!, requestSource: 'user' } : undefined);
    log('info', 'saveModelConfig ok');
    return r;
  });
  ipcMain.handle('desktop:updateModelRuntimeOptions', async (_event, input) => {
    log('info', 'updateModelRuntimeOptions', { modelId: input?.modelId });
    const r = await services.updateModelRuntimeOptions(input);
    log('info', 'updateModelRuntimeOptions ok', { modelId: input?.modelId });
    return r;
  });
  ipcMain.handle('desktop:createManagedXiaokAgent', async (_event, input) => {
    log('info', 'createManagedXiaokAgent', { name: input?.name, roles: input?.roles });
    const r = await services.createManagedXiaokAgent(input, { requestSource: 'user' });
    log('info', 'createManagedXiaokAgent ok');
    return r;
  });
  ipcMain.handle('desktop:testProviderConnection', async (_event, input) => {
    log('info', 'testProviderConnection', { providerId: input?.providerId });
    const r = await services.testProviderConnection(input);
    log('info', 'testProviderConnection ok', { success: r?.success, latencyMs: r?.latencyMs });
    return r;
  });
  ipcMain.handle('desktop:listAvailableModelsForProvider', async (_event, providerId) => {
    log('info', 'listAvailableModelsForProvider', { providerId });
    const r = await services.listAvailableModelsForProvider(providerId);
    log('info', 'listAvailableModelsForProvider ok', { count: r?.length });
    return r;
  });
  ipcMain.handle('desktop:deleteProvider', async (_event, providerId) => {
    log('info', 'deleteProvider', { providerId });
    await services.deleteProvider(providerId, { requestSource: 'user' });
    log('info', 'deleteProvider ok');
  });
  ipcMain.handle('desktop:deleteModel', async (_event, modelId) => {
    log('info', 'deleteModel', { modelId });
    await services.deleteModel(modelId, { requestSource: 'user' });
    log('info', 'deleteModel ok');
  });
  ipcMain.handle('desktop:kswarm:startProjectPlanning', async (_event, input) => {
    log('info', 'startProjectPlanning', { projectId: input?.projectId });
    const r = services.startProjectPlanning(input);
    log('info', 'startProjectPlanning ok', { ok: r?.ok });
    return r;
  });
  ipcMain.handle('desktop:readClipboardFilePaths', async () => expandSelectedMaterialPaths(readClipboardPathCandidates(clipboard)));
  ipcMain.handle('desktop:readClipboardImage', async () => {
    try {
      const img = clipboard.readImage();
      if (img.isEmpty()) return null;
      const png = img.toPNG();
      const tmpDir = join(os.tmpdir(), 'xiaok-clipboard-images');
      await mkdir(tmpDir, { recursive: true });
      const filePath = join(tmpDir, `clipboard-${Date.now()}.png`);
      await writeFile(filePath, png);
      return filePath;
    } catch { return null; }
  });
  ipcMain.handle('desktop:selectDirectory', async () => {
    log('info', 'selectDirectory');
    const result = await dialog.showOpenDialog(primaryWindow(), {
      properties: ['openDirectory', 'createDirectory'],
    });
    if (result.canceled || !result.filePaths[0]) {
      log('info', 'selectDirectory cancelled');
      return { filePath: '' };
    }
    log('info', 'selectDirectory ok', { filePath: result.filePaths[0] });
    return { filePath: result.filePaths[0] };
  });
  ipcMain.handle('desktop:selectMaterials', async () => {
    log('info', 'selectMaterials');
    const result = await dialog.showOpenDialog(primaryWindow(), {
      properties: ['openFile', 'multiSelections'],
    });
    if (result.canceled) {
      log('info', 'selectMaterials cancelled');
      return { filePaths: [] };
    }
    const expanded = await expandSelectedMaterialPaths(result.filePaths);
    log('info', 'selectMaterials ok', { fileCount: expanded.length });
    return { filePaths: expanded };
  });
  ipcMain.handle('desktop:importMaterial', async (_event, input) => {
    log('info', 'importMaterial', { filePath: input?.filePath });
    const r = await services.importMaterial(input);
    log('info', 'importMaterial ok');
    return r;
  });
  const observationSenders = new Map<string, {sender:IpcMainInvokeEvent['sender'];control:object}>();
  const watchedObservationSenders = new WeakSet<object>();
  const observationApprovals = createDesktopObservationApprovals({
    async selectPolicy(sender) {
      const selected = await dialog.showOpenDialog(BrowserWindow.fromWebContents(sender as IpcMainInvokeEvent['sender'])!, { properties: ['openFile'], filters: [{ name: 'Observation policy', extensions: ['json'] }] });
      if (selected.canceled || selected.filePaths.length !== 1) return null;
      const policy = parseObservationPolicyFile(selected.filePaths[0]); return {policy,summary:describeProductObservationPolicy(policy)};
    },
    async confirm(sender, summary, kind) {
      const zh = app.getLocale().startsWith('zh');
      const result = await dialog.showMessageBox(BrowserWindow.fromWebContents(sender as IpcMainInvokeEvent['sender'])!, {
        type:'warning',defaultId:0,cancelId:0,buttons:zh?['取消','明确同意']:['Cancel','Explicitly agree'],
        message:kind==='compound'
          ? (zh?'允许本次任务试用编辑后验证的融合执行？每一步仍需通过工具权限检查；执行结果不明时将停止后续变更。':'Allow the edit-and-validate execution experiment for this task? Each step still requires tool permission; uncertain execution stops further mutations.')
          : kind==='semantic'
          ? (zh?'允许在所列次数和预留预算内，额外调用模型压缩本次任务的上下文？按发送前核验的价格预留，实际账单由服务商计费；实验模式可能增加费用。':'Allow extra model calls to summarize this task within the listed call and reservation budget? Reservations use verified pre-dispatch prices; the provider determines the actual bill. Experiment mode may increase costs.')
          : kind==='persistence' ? (zh?'允许本次任务本地保存所选来源的未分类全文（包含原本被截断的尾部）？':'Allow this task to store unclassified full text from these exact sources, including truncated tails?') : (zh?'允许向以下精确模型和目的地披露这些内容并召回？':'Allow disclosure and recall of this content to this exact model and destination?'),
        detail:JSON.stringify(summary,null,2),
      });return result.response===1;
    },
  });
  const observationSender = (event:IpcMainInvokeEvent) => {
    if (!options.multiAgentAuthorize?.(event) || event.sender.isDestroyed()) throw new Error('observation_user_sender_required');
    if(!watchedObservationSenders.has(event.sender)) {
      watchedObservationSenders.add(event.sender);event.sender.once('destroyed',()=>{
        observationApprovals.destroySender(event.sender);
        for(const [taskId,record]of observationSenders)if(record.sender===event.sender){void services.revokeObservationTask(taskId,{requestSource:'user',control:record.control}).catch(()=>{});observationSenders.delete(taskId);}
      });
    }return event.sender;
  };
  ipcMain.handle('desktop:prepareObservationTask', async(event,input) => {
    if(input!==undefined)throw new Error('observation_input_invalid');return observationApprovals.prepare(observationSender(event));
  });
  ipcMain.handle('desktop:createObservationTask', async(event,raw) => {
    const sender=observationSender(event);
    if(!raw||typeof raw!=='object'||Object.keys(raw).some(key=>!['draftId','prompt','threadId'].includes(key))||typeof raw.draftId!=='string'||typeof raw.prompt!=='string'||!raw.prompt.trim()||raw.prompt.length>100000||raw.threadId!==undefined&&(typeof raw.threadId!=='string'||!/^[a-zA-Z0-9_-]{1,256}$/.test(raw.threadId)))throw new Error('observation_input_invalid');
    const approval=observationApprovals.consume(sender,raw.draftId);
    const result=await services.createObservationTask({prompt:raw.prompt,materials:[],permissionMode:'default',...(raw.threadId?{threadId:raw.threadId}:{})}, {requestSource:'user',approval,
      authorizeValidationMaterials:async request=>{
        if(sender.isDestroyed())throw Error('observation_sender_destroyed');
        const window=BrowserWindow.fromWebContents(sender);if(!window||window.isDestroyed())throw Error('observation_sender_destroyed');
        return authorizeDesktopValidationMaterials({...request,requestSource:'user',window,cwd:request.workspaceRoot});
      },
      onPrompt:async(tool,input)=>{
        if(sender.isDestroyed())return false;const detail=JSON.stringify({tool,input},null,2);if(detail.length>65536)return false;
        const zh=app.getLocale().startsWith('zh');const answer=await dialog.showMessageBox(BrowserWindow.fromWebContents(sender)!, {type:'question',defaultId:0,cancelId:0,buttons:zh?['拒绝','仅本次允许']:['Deny','Allow once'],message:zh?'确认本次工具执行？':'Approve this exact tool execution?',detail});
        return !sender.isDestroyed()&&answer.response===1;
      }});
    if(sender.isDestroyed()){await services.revokeObservationTask(result.taskId,{requestSource:'user',control:result.control}).catch(()=>{});throw new Error('observation_sender_destroyed');}
    observationSenders.set(result.taskId,{sender,control:result.control});return {taskId:result.taskId};
  });
  const observationControl=(action:'stop'|'revoke'|'status')=>async(event:IpcMainInvokeEvent,input:unknown)=>{
      const value=input as {taskId:string};
      const sender=observationSender(event);
      if(!input||typeof input!=='object'||Object.keys(input).length!==1||typeof value.taskId!=='string'||(action!=='status'&&observationSenders.get(value.taskId)?.sender!==sender))throw new Error('observation_task_owner_required');
      if(action==='stop')services.stopObservationTask(value.taskId,{requestSource:'user',control:observationSenders.get(value.taskId)!.control});
      if(action==='revoke')await services.revokeObservationTask(value.taskId,{requestSource:'user',control:observationSenders.get(value.taskId)!.control});
      const diagnostics=services.observationTaskDiagnostics?.(value.taskId),semantic=diagnostics?.semantic,compound=diagnostics?.compound;
      return {mode:await services.observationTaskStatus(value.taskId),...(semantic?{semantic}:{}),...(compound?{compound}:{})};
  };
  ipcMain.handle('desktop:stopObservationTask',observationControl('stop'));
  ipcMain.handle('desktop:revokeObservationTask',observationControl('revoke'));
  ipcMain.handle('desktop:getObservationTaskStatus',observationControl('status'));
  ipcMain.handle('desktop:createTask', async (_event, input) => {
    log('info', 'createTask', { prompt: input?.prompt?.slice(0, 50) });
    const r = await services.createTask(sanitizeTaskCreateInput(input), options.multiAgentAuthorize?.(_event) ? { ...options.multiAgentAuthorize(_event)!, requestSource: 'user' } : undefined);
    log('info', 'createTask ok', { taskId: r?.taskId });
    return r;
  });
  ipcMain.handle('desktop:goal:get', async (_event, input) => (
    services.getGoal(parseGoalThreadId(input?.threadId))
  ));
  ipcMain.handle('desktop:goal:create', async (_event, input) => (
    services.createGoal(parseGoalInput(input, 'create'))
  ));
  ipcMain.handle('desktop:goal:pause', async (_event, input) => (
    services.pauseGoal(parseGoalThreadId(input?.threadId))
  ));
  ipcMain.handle('desktop:goal:resume', async (_event, input) => {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_goal_resume_input');
    const fields = Object.keys(input).filter(key => !['threadId', 'turnLimit', 'requestId'].includes(key));
    if (fields.length > 0) throw new Error(`invalid_goal_field:${fields[0]}`);
    const requestId = parseGoalRequestId(input.requestId);
    const turnLimit = input.turnLimit;
    if (turnLimit !== undefined && (!Number.isSafeInteger(turnLimit) || turnLimit < 1 || turnLimit > 50)) {
      throw new Error('invalid_goal_turn_limit');
    }
    return services.resumeGoal({
      threadId: parseGoalThreadId(input.threadId),
      ...(requestId === undefined ? {} : { requestId }),
      ...(turnLimit === undefined ? {} : { turnLimit }),
    });
  });
  const parseGoalPublicationInput = (input: unknown) => {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw Error('invalid_goal_publication_input');
    if (Object.keys(input).some(key => key !== 'threadId')) throw Error('invalid_goal_publication_field');
    return { threadId: parseGoalThreadId((input as { threadId?: unknown }).threadId), requestSource: 'user' as const };
  };
  ipcMain.handle('desktop:goal:getNativeMutation', async (_event, input) => services.getGoalNativeMutation(parseGoalPublicationInput(input).threadId));
  ipcMain.handle('desktop:goal:recoverNativeMutation', async (_event, input) => services.recoverGoalNativeMutation(parseGoalPublicationInput(input)));
  ipcMain.handle('desktop:goal:cancelNativeMutation', async (_event, input) => services.cancelGoalNativeMutation(parseGoalPublicationInput(input)));
  ipcMain.handle('desktop:goal:continueNativeMutation', async (_event, input) => {
    if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).some(key => !['threadId','requestId'].includes(key))) throw Error('invalid_goal_native_input');
    const requestId = parseGoalRequestId(input.requestId);
    return services.continueGoalNativeMutation({ threadId: parseGoalThreadId(input.threadId), requestSource: 'user', ...(requestId === undefined ? {} : { requestId }) });
  });
  ipcMain.handle('desktop:goal:recoverPublication', async (_event, input) => services.recoverGoalPublication(parseGoalPublicationInput(input)));
  ipcMain.handle('desktop:goal:continuePublication', async (_event, input) => services.continueGoalPublication(parseGoalPublicationInput(input)));
  ipcMain.handle('desktop:goal:cancel', async (_event, input) => (
    services.cancelGoal(parseGoalThreadId(input?.threadId))
  ));
  ipcMain.handle('desktop:goal:replace', async (_event, input) => (
    services.replaceGoal(parseGoalInput(input, 'replace'))
  ));
  ipcMain.handle('desktop:goal:ackTaskAttached', async (_event, input) => {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('invalid_goal_attachment');
    const attachmentId = typeof input.attachmentId === 'string' ? input.attachmentId.trim() : '';
    if (!attachmentId || attachmentId.length > 200) throw new Error('invalid_goal_attachment');
    return services.ackGoalTaskAttached({
      threadId: parseGoalThreadId(input.threadId), attachmentId,
    });
  });
  ipcMain.handle('desktop:goal:setUserQueuePending', async (_event, input) => {
    if (!input || typeof input !== 'object' || Array.isArray(input) || typeof input.pending !== 'boolean') {
      throw new Error('invalid_goal_queue_state');
    }
    return services.setGoalUserQueuePending({
      threadId: parseGoalThreadId(input.threadId), pending: input.pending,
    });
  });
  ipcMain.handle('desktop:answerQuestion', async (_event, input) => {
    log('info', 'answerQuestion', { taskId: input?.taskId });
    const r = await services.answerQuestion(input, options.multiAgentAuthorize?.(_event) ? { ...options.multiAgentAuthorize(_event)!, requestSource: 'user' } : undefined);
    log('info', 'answerQuestion ok');
    return r;
  });
  ipcMain.handle('desktop:cancelTask', async (_event, input) => {
    log('info', 'cancelTask', { taskId: input?.taskId });
    await services.cancelTask(input.taskId, options.multiAgentAuthorize?.(_event) ? { ...options.multiAgentAuthorize(_event)!, requestSource: 'user' } : undefined);
    log('info', 'cancelTask ok');
  });
  ipcMain.handle('desktop:getActiveTask', async () => {
    const r = await services.getActiveTask();
    log('debug', 'getActiveTask', { taskId: r?.taskId ?? null });
    return r;
  });
  ipcMain.handle('desktop:recoverTask', async (_event, input) => {
    log('info', 'recoverTask', { taskId: input?.taskId });
    const r = await services.recoverTask(input.taskId);
    log('info', 'recoverTask ok', { status: r?.snapshot?.status });
    return r;
  });
  ipcMain.handle('desktop:openArtifact', async (_event, input) => {
    log('info', 'openArtifact', { artifactId: input?.artifactId });
    return services.openArtifact(input.artifactId);
  });
  ipcMain.handle('desktop:openFileInSystemApp', async (_event, input) => {
    const filePath = input?.filePath as string;
    if (!filePath || !isAbsolute(filePath)) return { ok: false, error: 'invalid_path' };
    const error = await shell.openPath(filePath);
    return error ? { ok: false, error } : { ok: true };
  });
  ipcMain.handle('desktop:readFileContent', async (_event, input) => {
    const filePath = input?.filePath as string;
    log('info', 'readFileContent', { filePath });
    try {
      const dataUrlMimeType = getDataUrlMimeType(filePath);
      if (dataUrlMimeType) {
        const content = await readFile(filePath);
        return { content: `data:${dataUrlMimeType};base64,${content.toString('base64')}` };
      }
      const content = await readFile(filePath, 'utf-8');
      return { content };
    } catch (e) {
      return { content: '', error: String(e) };
    }
  });
  ipcMain.handle('desktop:selectHtmlEditMedia', async (_event, input) => {
    const kind = input?.kind as 'image' | 'svg' | undefined;
    if (kind !== 'image' && kind !== 'svg') {
      return { canceled: true, filePath: '', content: '', error: 'invalid_kind' };
    }

    const result = await dialog.showOpenDialog(primaryWindow(), {
      properties: ['openFile'],
      filters: kind === 'image'
        ? [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'avif'] }]
        : [{ name: 'SVG', extensions: ['svg'] }],
    });
    const filePath = result.filePaths[0];
    if (result.canceled || !filePath) {
      return { canceled: true, filePath: '', content: '' };
    }

    try {
      if (kind === 'image') {
        const mimeType = getHtmlEditImageMimeType(filePath);
        if (!mimeType) {
          return { canceled: true, filePath, content: '', error: 'invalid_extension' };
        }
        const content = await readFile(filePath);
        return { canceled: false, filePath, content: `data:${mimeType};base64,${content.toString('base64')}` };
      }

      if (extname(filePath).toLowerCase() !== '.svg') {
        return { canceled: true, filePath, content: '', error: 'invalid_extension' };
      }
      return { canceled: false, filePath, content: await readFile(filePath, 'utf-8') };
    } catch (e) {
      return { canceled: true, filePath, content: '', error: String(e) };
    }
  });
  const activeTaskSubs = new Map<string, AbortController>();
  ipcMain.handle('desktop:subscribeTask', async (_event, input) => {
    const taskId = input.taskId as string;
    const target = _event?.sender ?? primaryWindow().webContents;
    const subscriptionKey = `${target.id}:${taskId}`;
    const sinceIndex = typeof input.sinceIndex === 'number' ? input.sinceIndex : undefined;
    log('info', 'subscribeTask', { taskId, sinceIndex });

    // Cancel any existing subscription for this taskId to prevent duplicate streams
    const prev = activeTaskSubs.get(subscriptionKey);
    if (prev) {
      prev.abort();
      activeTaskSubs.delete(subscriptionKey);
    }

    const controller = new AbortController();
    activeTaskSubs.set(subscriptionKey, controller);
    const onDestroyed = () => controller.abort();
    target.once?.('destroyed', onDestroyed);

    void (async () => {
      try {
        const stream = sinceIndex !== undefined
          ? services.subscribeTask(taskId, { sinceIndex })
          : services.subscribeTask(taskId);
        for await (const event of stream) {
          if (controller.signal.aborted || target.isDestroyed?.()) {
            break;
          }
          target.send(`desktop:taskEvent:${taskId}`, event);
        }
        log('info', 'subscribeTask stream ended', { taskId });
      } catch (e) {
        if (!controller.signal.aborted) {
          log('error', 'subscribeTask error', { taskId, message: String(e) });
        }
      } finally {
        target.removeListener?.('destroyed', onDestroyed);
        if (activeTaskSubs.get(subscriptionKey) === controller) {
          activeTaskSubs.delete(subscriptionKey);
        }
      }
    })();
  });
  ipcMain.handle('desktop:listSkills', async () => {
    const r = await services.listSkills();
    log('info', 'listSkills', { count: r.length });
    return r;
  });
  ipcMain.handle('desktop:installSkill', async (_event, skillName) => {
    log('info', 'installSkill', { skillName });
    const r = await services.installSkill(skillName);
    log('info', 'installSkill result', { success: r.success });
    return r;
  });
  ipcMain.handle('desktop:uninstallSkill', async (_event, skillName) => {
    log('info', 'uninstallSkill', { skillName });
    const r = await services.uninstallSkill(skillName);
    log('info', 'uninstallSkill result', { success: r.success });
    return r;
  });
  // Channel IPC
  ipcMain.handle('desktop:listChannels', async () => services.listChannels());
  ipcMain.handle('desktop:testChannel', async (_event, channelId) => {
    log('info', 'testChannel', { channelId });
    const r = await services.testChannel(channelId);
    log('info', 'testChannel result', { success: r.success });
    return r;
  });
  ipcMain.handle('desktop:createChannel', async (_event, input) => services.createChannel(input));
  ipcMain.handle('desktop:updateChannel', async (_event, id, input) => services.updateChannel(id, input));
  ipcMain.handle('desktop:deleteChannel', async (_event, id) => services.deleteChannel(id));
  // MCP IPC
  ipcMain.handle('desktop:listMCPInstalls', async () => services.listMCPInstalls());
  ipcMain.handle('desktop:createMCPInstall', async (_event, input) => services.createMCPInstall(input));
  ipcMain.handle('desktop:updateMCPInstall', async (_event, id, input) => services.updateMCPInstall(id, input));
  ipcMain.handle('desktop:deleteMCPInstall', async (_event, id) => services.deleteMCPInstall(id));
  // Plugin MCP servers
  ipcMain.handle('desktop:listPluginMcpServers', () => services.listPluginMcpServers());
  // Design v58 §7.2: `setPluginMcpServerEnabled` only mutated a view model and
  // had no durable desired-state store, and the blanket restart bypassed the CUA
  // preference. Both are deleted; retry is component-scoped and user-sourced.
  ipcMain.handle('desktop:retryPluginComponent', (_event, input) => services.retryPluginComponent({
    componentId: String((input as { componentId?: unknown })?.componentId ?? ''),
    requestSource: 'user',
  }));
  ipcMain.handle('desktop:getComputerUseCapabilityStatus', () => services.getComputerUseCapabilityStatus());
  ipcMain.handle('desktop:enableComputerUse', () => services.enableComputerUse());
  ipcMain.handle('desktop:reconnectComputerUse', () => services.reconnectComputerUse());
  ipcMain.handle('desktop:disableComputerUse', () => services.disableComputerUse());
  ipcMain.handle('desktop:openPluginDependencyPermissionSettings', async (_event, input) => {
    const permission = String(input?.permission ?? '');
    const pane = permission === 'screen'
      ? 'Privacy_ScreenCapture'
      : 'Privacy_Accessibility';
    await shell.openExternal(`x-apple.systempreferences:com.apple.preference.security?${pane}`);
  });
  ipcMain.handle('desktop:installPlugin', (_event, name) => services.installPlugin(name));
  ipcMain.handle('desktop:listAvailablePlugins', () => services.listAvailablePlugins());
  ipcMain.handle('desktop:listPluginDependencyStatuses', () => services.listPluginDependencyStatuses());
  ipcMain.handle('desktop:installPluginDependency', (_event, input) => services.installPluginDependency(input));
  ipcMain.handle('desktop:updatePluginDependency', (_event, input) => services.updatePluginDependency(input));
  ipcMain.handle('desktop:diagnosePluginDependency', (_event, input) => services.diagnosePluginDependency(input));
  ipcMain.handle('desktop:createTaskWithFiles', async (_event, input) => {
    log('info', 'createTaskWithFiles', { prompt: input?.prompt?.slice(0, 50), files: input?.filePaths?.length });
    if (!input || typeof input !== 'object' || Array.isArray(input) || typeof input.prompt !== 'string' || !Array.isArray(input.filePaths)) {
      throw new Error('invalid_task_files_input');
    }
    if (input.filePaths.some((value: unknown) => typeof value !== 'string')) throw new Error('invalid_task_file_path');
    const expanded = await expandSelectedMaterialPaths(input.filePaths);
    const context = sanitizeTaskContext(input.context);
    const r = await services.createTaskWithFiles({
      prompt: input.prompt,
      filePaths: expanded,
      ...(context ? { context } : {}),
    }, options.multiAgentAuthorize?.(_event) ? { ...options.multiAgentAuthorize(_event)!, requestSource: 'user' } : undefined);
    log('info', 'createTaskWithFiles ok', { taskId: r?.taskId });
    return r;
  });
  ipcMain.handle('desktop:getSkillStats', async () => {
    try {
      return await services.getSkillStats();
    } catch { return []; }
  });
  ipcMain.handle('desktop:trace:export', async (_event, input) => {
    log('info', 'traceExport', { kind: input?.kind, id: input?.id });
    const result = await services.exportTraceBundle(input);
    log('info', 'traceExport result', { ok: result.ok, path: result.path });
    return result;
  });
  ipcMain.handle('desktop:diagnose', async (_event, input) => {
    log('info', 'diagnose', { kind: input?.kind, id: input?.id });
    const result = await services.diagnose(input);
    log('info', 'diagnose result', { health: result?.health, primaryFinding: result?.primaryFinding?.category ?? null });
    return result;
  });

  ipcMain.handle('desktop:loops:listDefinitions', () => {
    const loopRuntime = getLoopRuntime(options);
    return loopRuntime.loopStore.listLoopDefinitions();
  });
  ipcMain.handle('desktop:loops:listUserTemplates', () => {
    const loopRuntime = getLoopRuntime(options);
    return loopRuntime.loopStore.listUserLoopTemplates();
  });
  ipcMain.handle('desktop:loops:createUserTemplate', (_event, input) => {
    log('info', 'loops:createUserTemplate', { title: input?.title, kind: input?.kind, loopId: input?.loopId });
    try {
      const loopRuntime = getLoopRuntime(options);
      const result = loopRuntime.loopStore.createUserLoopTemplate(readCreateUserLoopTemplateInput(input));
      log('info', 'loops:createUserTemplate ok', { loopId: result.template.loopId });
      return result;
    } catch (e) {
      log('error', 'loops:createUserTemplate failed', String(e));
      throw e;
    }
  });
  ipcMain.handle('desktop:loops:updateUserTemplate', (_event, loopId, patch) => {
    log('info', 'loops:updateUserTemplate', { loopId, patchKeys: patch ? Object.keys(patch) : [] });
    try {
      const loopRuntime = getLoopRuntime(options);
      const id = readLoopId(loopId);
      const result = loopRuntime.loopStore.updateUserLoopTemplate(id, patch ?? {});
      log('info', 'loops:updateUserTemplate ok', { loopId: id, found: !!result });
      return result;
    } catch (e) {
      log('error', 'loops:updateUserTemplate failed', { loopId, error: String(e) });
      throw e;
    }
  });
  ipcMain.handle('desktop:loops:deleteUserTemplate', (_event, loopId) => {
    log('info', 'loops:deleteUserTemplate', { loopId });
    try {
      const loopRuntime = getLoopRuntime(options);
      const id = readLoopId(loopId);
      loopRuntime.loopStore.deleteUserLoopTemplate(id);
      log('info', 'loops:deleteUserTemplate ok', { loopId: id });
    } catch (e) {
      log('error', 'loops:deleteUserTemplate failed', { loopId, error: String(e) });
      throw e;
    }
  });
  ipcMain.handle('desktop:loops:listAnomalies', (_event, loopId) => {
    const loopRuntime = getLoopRuntime(options);
    return loopRuntime.listAnomalies(readLoopId(loopId));
  });
  ipcMain.handle('desktop:loops:runNow', async (_event, loopId) => {
    log('info', 'loops:runNow', { loopId });
    try {
      const loopRuntime = getLoopRuntime(options);
      const result = await loopRuntime.runner.runLoopNow(readLoopId(loopId),undefined,undefined,{requestSource:'user'});
      log('info', 'loops:runNow result', { loopId, status: result.status });
      return result;
    } catch (e) {
      log('error', 'loops:runNow failed', { loopId, error: String(e) });
      throw e;
    }
  });
  ipcMain.handle('desktop:loops:listConstraints', (_event, loopId) => {
    const loopRuntime = getLoopRuntime(options);
    return loopRuntime.loopStore.getConstraintsByLoopId(readLoopId(loopId));
  });
  ipcMain.handle('desktop:loops:setConstraintActive', (_event, constraintId, active) => {
    const loopRuntime = getLoopRuntime(options);
    return loopRuntime.loopStore.setConstraintActive(String(constraintId), Boolean(active));
  });
  ipcMain.handle('desktop:loops:confirmConstraint', (_event, constraintId) => {
    const loopRuntime = getLoopRuntime(options);
    return loopRuntime.loopStore.confirmConstraint(String(constraintId));
  });
  ipcMain.handle('desktop:loops:clearRunHistory', (_event, loopId, statuses) => {
    log('info', 'loops:clearRunHistory', { loopId, statuses });
    try {
      const loopRuntime = getLoopRuntime(options);
      const id = readLoopId(loopId);
      const validStatuses = Array.isArray(statuses) && statuses.every(s => typeof s === 'string') ? statuses : undefined;
      const removed = loopRuntime.loopStore.clearLoopRunHistory(id, validStatuses);
      log('info', 'loops:clearRunHistory ok', { loopId: id, removed });
      return { ok: true, removed };
    } catch (e) {
      log('error', 'loops:clearRunHistory failed', { loopId, error: String(e) });
      throw e;
    }
  });

  // ---- Memory ----
  const { getDesktopMemoryStore } = await import('./desktop-services.js');
  const { parseMemories } = await import('./memory-import-parser.js');
  const memoryStore = getDesktopMemoryStore(services.getDataRoot());

  ipcMain.handle('desktop:listMemories', async () => {
    try {
      if (memoryStore.search) {
        return (await memoryStore.search('', 50)).map(r => ({
          id: r.id, content: r.summary, tags: r.tags, createdAt: r.updatedAt,
        }));
      }
      return (await memoryStore.listRelevant({ cwd: '', query: '' })).map(r => ({
        id: r.id, content: r.summary, tags: r.tags, createdAt: r.updatedAt,
      }));
    } catch (e) { log('error', 'listMemories failed', e); return []; }
  });
  ipcMain.handle('desktop:createMemory', async (_event, input: { content: string; tags: string[]; source?: string }) => {
    try {
      const id = `mem_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await memoryStore.save({
        id, scope: 'global', title: input.content.slice(0, 80),
        summary: input.content, tags: input.tags, updatedAt: Date.now(), type: 'user',
      });
      return { id, content: input.content, tags: input.tags, createdAt: Date.now() };
    } catch (e) { log('error', 'createMemory failed', e); throw e; }
  });
  ipcMain.handle('desktop:updateMemory', async (_event, input: { id: string; content?: string; tags?: string[] }) => {
    try {
      // Delete old + re-save with updated content
      await memoryStore.delete?.(input.id);
      const content = input.content ?? '';
      await memoryStore.save({
        id: input.id, scope: 'global', title: content.slice(0, 80),
        summary: content, tags: input.tags ?? [], updatedAt: Date.now(), type: 'user',
      });
      return { id: input.id, content, tags: input.tags ?? [], createdAt: Date.now() };
    } catch (e) { log('error', 'updateMemory failed', e); throw e; }
  });
  ipcMain.handle('desktop:deleteMemory', async (_event, id: string) => {
    try { return await memoryStore.delete?.(id) ?? false; }
    catch (e) { log('error', 'deleteMemory failed', e); throw e; }
  });
  ipcMain.handle('desktop:importMemories', async (_event, raw: string) => {
    try {
      const { items, errors } = parseMemories(raw);
      if (items.length === 0 && errors.length === 0) return { imported: 0, deduped: 0, parseErrors: ['未解析到任何记忆'] };
      let imported = 0;
      for (const item of items) {
        const content = (item.content || '').trim();
        if (!content) continue;
        await memoryStore.save({
          id: `mem_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          scope: 'global', title: content.slice(0, 80),
          summary: content, tags: item.tags || [], updatedAt: Date.now(), type: 'user',
        });
        imported++;
      }
      return { imported, deduped: 0, parseErrors: errors };
    } catch (e) {
      return { imported: 0, deduped: 0, parseErrors: [`导入失败: ${e}`] };
    }
  });
  ipcMain.handle('desktop:memoryStats', async () => {
    try { return memoryStore.getStats?.() ?? null; }
    catch (e) { log('error', 'memoryStats failed', e); return null; }
  });
  ipcMain.handle('desktop:memoryCompact', async () => {
    try { await memoryStore.compact?.(); return true; }
    catch (e) { log('error', 'memoryCompact failed', e); return false; }
  });
  ipcMain.handle('desktop:memoryPersonaTraits', async () => {
    try { return memoryStore.getPersonaTraits?.() ?? []; }
    catch (e) { log('error', 'memoryPersonaTraits failed', e); return []; }
  });
  ipcMain.handle('desktop:memoryListLayer', async (_event, layer: number, limit?: number, offset?: number) => {
    try { return memoryStore.listLayer?.(layer, limit ?? 50, offset ?? 0) ?? []; }
    catch (e) { log('error', 'memoryListLayer failed', e); return []; }
  });
  ipcMain.handle('desktop:memoryDeleteEntry', async (_event, id: string, layer: number) => {
    try { return await memoryStore.delete?.(id, layer) ?? false; }
    catch (e) { log('error', 'memoryDeleteEntry failed', e); return false; }
  });
  ipcMain.handle('desktop:memoryClearAll', async () => {
    try { memoryStore.clearAll?.(); return true; }
    catch (e) { log('error', 'memoryClearAll failed', e); return false; }
  });
  ipcMain.handle('desktop:memoryGetModelId', async () => {
    try {
      const config = await (await import('../../src/utils/config.js')).loadConfig();
      return config.memory?.modelId ?? null;
    } catch { return null; }
  });
  ipcMain.handle('desktop:memorySetModelId', async (_event, modelId: string | null) => {
    try {
      const { loadConfig, saveConfig: saveConfigFn } = await import('../../src/utils/config.js');
      const config = await loadConfig();
      if (!config.memory) config.memory = {};
      config.memory.modelId = modelId ?? undefined;
      await saveConfigFn(config);
      return true;
    } catch (e) { log('error', 'memorySetModelId failed', e); return false; }
  });

  ipcMain.handle('desktop:getEmbeddingModels', async () => {
    try {
      const { MODEL_REGISTRY, isModelDownloaded, getManualDownloadHint } = await import('../../src/ai/memory/model-registry.js');
      const { loadConfig } = await import('../../src/utils/config.js');
      const config = await loadConfig();
      const activeModelId = config.memory?.modelId ?? 'all-MiniLM-L6-v2';
      return MODEL_REGISTRY.map(m => ({
        id: m.id,
        name: m.name,
        dims: m.dims,
        size: m.size,
        languages: m.languages,
        downloaded: isModelDownloaded(m.id),
        active: m.id === activeModelId,
        manualHint: getManualDownloadHint(m.id),
      }));
    } catch (e) { log('error', 'getEmbeddingModels failed', e); return []; }
  });

  ipcMain.handle('desktop:downloadEmbeddingModel', async (_event, modelId: string) => {
    const { downloadModel } = await import('../../src/ai/memory/model-registry.js');
    await downloadModel(modelId);
  });

  ipcMain.handle('desktop:setEmbeddingModel', async (_event, modelId: string) => {
    try {
      const { loadConfig, saveConfig: saveConfigFn, getConfigDir } = await import('../../src/utils/config.js');
      const config = await loadConfig();
      const prevModelId = config.memory?.modelId;
      if (!config.memory) config.memory = {};
      config.memory.modelId = modelId;
      await saveConfigFn(config);
      if (prevModelId !== modelId) {
        try {
          const Database = (await import('better-sqlite3')).default;
          const path = await import('node:path');
          const dbPath = path.join(getConfigDir(), 'memory.db');
          const db = new Database(dbPath);
          db.prepare('DELETE FROM memory_embeddings').run();
          db.close();
          log('info', 'Cleared memory_embeddings after model switch', { from: prevModelId, to: modelId });
        } catch (e) { log('warn', 'Failed to clear embeddings on model switch', e); }
      }
    } catch (e) { log('error', 'setEmbeddingModel failed', e); throw e; }
  });

  // ---- Artifact Editing ----
  const { sessionHash, backupArtifact, revertArtifact, cleanupBackups, watchArtifactFile, unwatchArtifactFile } = await import('./artifact-editing.js');

  ipcMain.handle('desktop:artifactBackup', async (_event, filePath: string) => {
    const sid = sessionHash(filePath);
    return backupArtifact(filePath, sid);
  });

  ipcMain.handle('desktop:artifactRevert', async (_event, filePath: string) => {
    const sid = sessionHash(filePath);
    const ok = revertArtifact(filePath, sid);
    if (ok && !primaryWindow().isDestroyed()) primaryWindow().webContents.send('desktop:artifactFileChanged', filePath);
    return ok;
  });

  ipcMain.handle('desktop:artifactCleanup', async (_event, filePath: string) => {
    const sid = sessionHash(filePath);
    cleanupBackups(sid);
  });

  ipcMain.handle('desktop:artifactWatch', async (_event, filePath: string) => {
    watchArtifactFile(filePath, () => {
      if (!primaryWindow().isDestroyed()) primaryWindow().webContents.send('desktop:artifactFileChanged', filePath);
    });
  });

  ipcMain.handle('desktop:artifactUnwatch', async (_event, filePath: string) => {
    unwatchArtifactFile(filePath);
  });

  // ---- File Export ----
  ipcMain.handle('desktop:showSaveDialog', async (_event, input: { defaultPath?: string; filters?: Array<{ name: string; extensions: string[] }> }) => {
    log('info', 'showSaveDialog', { defaultPath: input?.defaultPath });
    const result = await dialog.showSaveDialog(primaryWindow(), {
      defaultPath: input?.defaultPath,
      filters: input?.filters ?? [{ name: 'Markdown', extensions: ['md'] }],
    });
    if (result.canceled || !result.filePath) {
      log('info', 'showSaveDialog cancelled');
      return { canceled: true, filePath: '' };
    }
    log('info', 'showSaveDialog ok', { filePath: result.filePath });
    return { canceled: false, filePath: result.filePath };
  });

  ipcMain.handle('desktop:saveFile', async (_event, input: { filePath: string; content: string; purpose?: string }) => {
    log('info', 'saveFile', { filePath: input?.filePath });
    try {
      if (input?.purpose === 'html-edit' || input?.purpose === 'text-edit') {
        const validationError = await validateArtifactEditWritePath(input.filePath, services, input.purpose);
        if (validationError) {
          log('warn', 'saveFile rejected artifact edit', { filePath: input?.filePath, purpose: input.purpose, error: validationError });
          return { success: false, error: validationError };
        }
      }
      const binaryContent = decodeBase64DataUrl(input.content);
      if (binaryContent) {
        await writeFile(input.filePath, binaryContent);
      } else {
        await writeFile(input.filePath, input.content, 'utf-8');
      }
      log('info', 'saveFile ok');
      return { success: true };
    } catch (e) {
      log('error', 'saveFile failed', String(e));
      return { success: false, error: String(e) };
    }
  });

  // ---- Project Principles ----
  const { PrinciplesStore } = await import('./principles-store.js');
  const principlesStore = new PrinciplesStore(services.getDataRoot());

  ipcMain.handle('desktop:listPrinciples', async () => {
    log('info', 'listPrinciples');
    return principlesStore.list();
  });

  ipcMain.handle('desktop:savePrinciple', async (_event, input) => {
    log('info', 'savePrinciple', { id: input?.id });
    const result = await principlesStore.save(input);
    log('info', 'savePrinciple result', result);
    return result;
  });

  ipcMain.handle('desktop:deletePrinciple', async (_event, id: string) => {
    log('info', 'deletePrinciple', { id });
    const result = await principlesStore.delete(id);
    log('info', 'deletePrinciple result', result);
    return result;
  });

  // ---- Knowledge Base ----
  const { createKbStoreSqlite } = await import('./kb-store-sqlite.js');
  const { createChunker } = await import('./kb-chunker.js');
  const { createSourceExtractor } = await import('./kb-source-extractor.js');
  const { app } = await import('electron');
  const kbSourceExtractor = createSourceExtractor({
    officeParser: { parse: input => services.parseOfficeDocument(input) },
  });
  const kbChunker = createChunker();

  const sourceExtractionMetadata = (result: import('./kb-store.js').SourceExtractionResult): Record<string, unknown> => ({
    ...(result.engine ? { engine: result.engine } : {}),
    ...(result.engineVersion ? { engineVersion: result.engineVersion } : {}),
    ...(result.truncated !== undefined ? { truncated: result.truncated } : {}),
  });

  const finishSourceExtraction = (
    store: import('./kb-store.js').KbStore,
    sourceId: string,
    result: import('./kb-store.js').SourceExtractionResult,
    requestSource: import('./kb-types.js').RequestSource,
  ) => {
    if (result.ok && result.text) {
      const claim = store.claimSourceContentHash(
        sourceId,
        computeKnowledgeContentHash(result.text),
        requestSource,
      );
      if (!claim.created) return claim.source;
      const chunks = kbChunker.chunk({ text: result.text, mimeType: result.mimeType });
      store.insertChunks(sourceId, chunks);
      return store.updateSourceParseResult(sourceId, {
        parseStatus: 'parsed',
        metadata: sourceExtractionMetadata(result),
      }, requestSource);
    }
    return store.updateSourceParseResult(sourceId, {
      parseStatus: result.errorCode === 'unsupported_format' ? 'unsupported' : 'failed',
      errorCode: result.errorCode ?? 'extraction_failed',
      errorMessage: result.error ?? 'unknown',
      metadata: sourceExtractionMetadata(result),
    }, requestSource);
  };

  let kbStore: import('./kb-store.js').KbStore | null = null;
  function getKbStore() {
    if (!kbStore) {
      kbStore = createKbStoreSqlite(join(app.getPath('userData'), 'knowledge.db'));
      if (kbStore.listCollections().length === 0) {
        kbStore.createCollection({
          name: '我的知识库',
          description: '默认知识库集合',
          embeddingModelId: 'bge-small-zh-v1.5',
          embeddingDim: 512,
        });
      }
      const pendingSources = kbStore.listCollections()
        .flatMap(collection => kbStore!.listSources(collection.id))
        .filter(source => source.parseStatus === 'pending');
      if (pendingSources.length) {
        const store = kbStore!;
        setImmediate(async () => {
          for (const src of pendingSources) {
            try {
              if (store.listChunks(src.id).length > 0) {
                const chunks = store.listChunks(src.id);
                store.claimSourceContentHash(
                  src.id,
                  computeKnowledgeContentHash(reconstructKnowledgeSourceText(chunks)),
                  'scheduler',
                );
                store.updateSourceParseResult(src.id, { parseStatus: 'parsed' }, 'scheduler');
                continue;
              }
              if (!src.rawPath) continue;
              const extractResult = await kbSourceExtractor.extract({
                filePath: src.rawPath,
                mimeType: src.mimeType || 'application/octet-stream',
              });
              finishSourceExtraction(store, src.id, extractResult, 'scheduler');
            } catch (error) {
              try {
                store.updateSourceParseResult(src.id, {
                  parseStatus: 'failed',
                  errorCode: 'io_error',
                  errorMessage: error instanceof Error ? error.message : String(error),
                }, 'scheduler');
              } catch {
                // Another recovery path already finalized this source.
              }
            }
          }
        });
      }
    }
    return kbStore;
  }

  ipcMain.handle('desktop:kb:listCollections', async () => {
    log('info', 'kb:listCollections');
    return getKbStore().listCollections();
  });

  ipcMain.handle('desktop:kb:createCollection', async (_event, input) => {
    log('info', 'kb:createCollection', { name: input?.name });
    return getKbStore().createCollection(input);
  });

  ipcMain.handle('desktop:kb:deleteCollection', async (_event, id: string) => {
    log('info', 'kb:deleteCollection', { id });
    getKbStore().deleteCollection(id);
  });

  ipcMain.handle('desktop:kb:listSources', async (_event, collectionId: string) => {
    log('info', 'kb:listSources', { collectionId });
    return getKbStore().listSources(collectionId);
  });

  ipcMain.handle('desktop:kb:addSource', async (_event, input) => {
    log('info', 'kb:addSource', { kind: input?.kind, title: input?.title });
    const store = getKbStore();
    const unsafeMetadata = input?.metadata && typeof input.metadata === 'object'
      ? input.metadata as Record<string, unknown>
      : {};
    const { createdBy: _createdBy, requestSource: _requestSource, ...metadata } = unsafeMetadata;
    const source = store.addSource({
      collectionId: input?.collectionId,
      kind: input?.kind,
      title: input?.title,
      uri: input?.uri,
      filePath: input?.filePath,
      mimeType: input?.mimeType,
      text: input?.text,
      byteSize: input?.byteSize,
      rawPath: input?.rawPath,
      parseStatus: 'pending',
      metadata,
    }, 'user');
    try {
      let extractResult: import('./kb-store.js').SourceExtractionResult | null = null;
      if (input?.kind === 'paste' && input?.text) {
        extractResult = kbSourceExtractor.extractFromText(input.text, input.title || '粘贴文本');
      } else if (input?.kind === 'file' && input?.filePath) {
        extractResult = await kbSourceExtractor.extract({ filePath: input.filePath, mimeType: input.mimeType || 'application/octet-stream' });
      } else if (input?.kind === 'url' && input?.uri) {
        extractResult = await kbSourceExtractor.extractFromUrl(input.uri);
      }
      const finalized = finishSourceExtraction(store, source.id, extractResult ?? {
        ok: false,
        errorCode: 'invalid_source_input',
        error: 'Source content is missing.',
      }, 'user');
      return finalized;
    } catch (e) {
      log('error', 'kb:addSource processing failed', String(e));
      try {
        store.updateSourceParseResult(source.id, {
          parseStatus: 'failed',
          errorCode: 'io_error',
          errorMessage: e instanceof Error ? e.message : String(e),
        }, 'user');
      } catch {
        // The source may already have reached a terminal parse state.
      }
    }
    return store.getSource(source.id) ?? source;
  });

  ipcMain.handle('desktop:kb:pickFiles', async () => {
    const { dialog } = await import('electron');
    const result = await dialog.showOpenDialog({
      properties: ['openFile', 'multiSelections'],
      filters: [
        {
          name: '文档',
          extensions: [
            'pdf', 'txt', 'md', 'html', 'json', 'csv',
            ...Array.from(OFFICE_EXTENSIONS, extension => extension.slice(1)),
          ],
        },
        { name: '所有文件', extensions: ['*'] },
      ],
    });
    if (result.canceled) return [];
    return result.filePaths;
  });

  ipcMain.handle('desktop:meeting:pickAudioFile', async () => {
    const { dialog } = await import('electron');
    const result = await dialog.showOpenDialog({
      properties: ['openFile'],
      filters: [
        { name: 'WAV audio', extensions: ['wav'] },
      ],
    });
    if (result.canceled) return null;
    return result.filePaths[0] ?? null;
  });

  ipcMain.handle('desktop:meeting:getMicrophonePermission', async () => (
    meetingAudioPermissionService.getStatus()
  ));

  ipcMain.handle('desktop:meeting:requestMicrophonePermission', async () => (
    meetingAudioPermissionService.requestPermission()
  ));

  ipcMain.handle('desktop:meeting:getAsrConfig', async () => {
    const { loadConfig } = await import('../../src/utils/config.js');
    const { createMeetingAsrConfigSnapshot } = await import('./meeting-asr-config.js');
    return createMeetingAsrConfigSnapshot(await loadConfig());
  });

  ipcMain.handle('desktop:meeting:saveAsrConfig', async (_event, input) => {
    const { loadConfig, saveConfig } = await import('../../src/utils/config.js');
    const { applyMeetingAsrConfigUpdate, createMeetingAsrConfigSnapshot } = await import('./meeting-asr-config.js');
    const config = applyMeetingAsrConfigUpdate(await loadConfig(), input ?? {});
    await saveConfig(config);
    return createMeetingAsrConfigSnapshot(config);
  });

  ipcMain.handle('desktop:meeting:listModels', async () => {
    const { createMeetingModelService } = await import('./meeting-model-service.js');
    return createMeetingModelService().listModels();
  });

  ipcMain.handle('desktop:meeting:downloadModel', async (_event, modelId: string) => {
    const { createMeetingModelService } = await import('./meeting-model-service.js');
    return createMeetingModelService().downloadModel(String(modelId ?? ''));
  });

  ipcMain.handle('desktop:meeting:uninstallModel', async (_event, modelId: string) => {
    const { createMeetingModelService } = await import('./meeting-model-service.js');
    return createMeetingModelService().uninstallModel(String(modelId ?? ''));
  });

  ipcMain.handle('desktop:meeting:saveRecordedAudio', async (_event, input) => {
    const wavBase64 = typeof input?.wavBase64 === 'string' ? input.wavBase64 : '';
    if (!wavBase64) return { ok: false, error: 'missing_audio' };
    if (Buffer.byteLength(wavBase64, 'utf8') > 512 * 1024 * 1024) {
      return { ok: false, error: 'audio_too_large' };
    }

    let audioBuffer: Buffer;
    try {
      audioBuffer = decodeBase64Audio(wavBase64);
      const { parsePcm16WavInfo } = await import('./meeting-audio-format.js');
      parsePcm16WavInfo(audioBuffer);
    } catch {
      return { ok: false, error: 'invalid_wav' };
    }

    const recordingsDir = join(app.getPath('userData'), 'meeting-recordings');
    await mkdir(recordingsDir, { recursive: true });
    const filePath = join(recordingsDir, safeMeetingRecordingFileName(input?.title));
    await writeFile(filePath, audioBuffer);
    return { ok: true, filePath };
  });

  ipcMain.handle('desktop:meeting:transcribePreview', async (_event, input) => {
    const wavBase64 = typeof input?.wavBase64 === 'string' ? input.wavBase64 : '';
    if (!wavBase64) return { ok: false, error: 'missing_audio' };
    if (Buffer.byteLength(wavBase64, 'utf8') > 96 * 1024 * 1024) {
      return { ok: false, error: 'audio_too_large' };
    }

    let audioBuffer: Buffer;
    try {
      audioBuffer = decodeBase64Audio(wavBase64);
      const { parsePcm16WavInfo } = await import('./meeting-audio-format.js');
      parsePcm16WavInfo(audioBuffer);
    } catch {
      return { ok: false, error: 'invalid_wav' };
    }

    const previewDir = join(app.getPath('temp'), 'xiaok-meeting-preview');
    await mkdir(previewDir, { recursive: true });
    const filePath = join(previewDir, safeMeetingRecordingFileName(input?.title));
    await writeFile(filePath, audioBuffer);
    try {
      const transcriber = await createMeetingTranscriberForIpc(input);
      const transcription = await transcriber.transcribeFile({
        audioFilePath: filePath,
        meetingId: `preview-${Date.now()}`,
      });
      const punctuated = await restorePreviewPunctuation(transcription);
      return { ok: true, ...punctuated };
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : 'preview_transcription_failed',
      };
    } finally {
      await rm(filePath, { force: true }).catch(() => undefined);
    }
  });

  ipcMain.handle('desktop:meeting:live:start', async (event, input) => {
    try {
      const engine = input?.engine === 'aliyun-asr' || input?.engine === 'volcengine-asr'
        ? input.engine as 'aliyun-asr' | 'volcengine-asr'
        : null;
      if (!engine) throw new Error('meeting_live_provider_not_supported');
      const sampleRate = Number(input?.sampleRate);
      const language = typeof input?.language === 'string' ? input.language.trim() : undefined;
      const { loadConfig } = await import('../../src/utils/config.js');
      const config = await loadConfig();
      const ownerId = event.sender.id;
      if (!meetingLiveOwnerCleanupRegistered.has(ownerId)) {
        meetingLiveOwnerCleanupRegistered.add(ownerId);
        event.sender.once('destroyed', () => {
          meetingLiveOwnerCleanupRegistered.delete(ownerId);
          cancelMeetingLiveOwner(ownerId);
        });
      }
      const onUpdate = (activeSessionId: string, update: {
        sentenceId: string;
        start: number;
        end: number;
        text: string;
        final: boolean;
      }) => {
        if (!event.sender.isDestroyed()) {
          event.sender.send('desktop:meeting:live:update', { sessionId: activeSessionId, ...update });
        }
      };
      let sessionId: string;
      let provider: 'aliyun' | 'volcengine';
      if (engine === 'aliyun-asr') {
        const { resolveMeetingAliyunAsrCredentials } = await import('./meeting-asr-config.js');
        const credentials = resolveMeetingAliyunAsrCredentials(config);
        provider = 'aliyun';
        sessionId = await meetingAliyunLiveRegistry.start(ownerId, {
          apiKey: credentials.apiKey,
          baseUrl: credentials.baseUrl,
          sampleRate,
          language,
        }, onUpdate);
      } else {
        const { resolveMeetingVolcengineAsrCredentials } = await import('./meeting-asr-config.js');
        const credentials = resolveMeetingVolcengineAsrCredentials(config);
        provider = 'volcengine';
        sessionId = await meetingVolcengineLiveRegistry.start(ownerId, {
          ...credentials,
          sampleRate,
        }, onUpdate);
      }
      meetingLiveSessions.set(sessionId, { ownerId, provider });
      return { ok: true, sessionId };
    } catch (error) {
      return { ok: false, error: stableMeetingLiveError(error) };
    }
  });

  ipcMain.handle('desktop:meeting:live:pushAudio', async (event, input) => {
    try {
      const sessionId = parseMeetingLiveSessionId(input?.sessionId);
      const active = readMeetingLiveSession(event.sender.id, sessionId);
      const pcmBase64 = typeof input?.pcmBase64 === 'string' ? input.pcmBase64 : '';
      if (!pcmBase64 || Buffer.byteLength(pcmBase64, 'utf8') > 1024 * 1024) {
        throw new Error('meeting_live_invalid_audio');
      }
      const audio = Buffer.from(pcmBase64, 'base64');
      if (audio.length === 0 || audio.length % 2 !== 0) throw new Error('meeting_live_invalid_audio');
      if (active.provider === 'aliyun') {
        meetingAliyunLiveRegistry.pushAudio(event.sender.id, sessionId, audio);
      } else {
        meetingVolcengineLiveRegistry.pushAudio(event.sender.id, sessionId, audio);
      }
      return { ok: true };
    } catch (error) {
      return { ok: false, error: stableMeetingLiveError(error) };
    }
  });

  ipcMain.handle('desktop:meeting:live:finish', async (event, input) => {
    try {
      const sessionId = parseMeetingLiveSessionId(input?.sessionId);
      const active = readMeetingLiveSession(event.sender.id, sessionId);
      try {
        if (active.provider === 'aliyun') {
          await meetingAliyunLiveRegistry.finish(event.sender.id, sessionId);
        } else {
          await meetingVolcengineLiveRegistry.finish(event.sender.id, sessionId);
        }
      } finally {
        meetingLiveSessions.delete(sessionId);
      }
      return { ok: true };
    } catch (error) {
      return { ok: false, error: stableMeetingLiveError(error) };
    }
  });

  ipcMain.handle('desktop:meeting:live:cancel', async (event, input) => {
    try {
      const sessionId = parseMeetingLiveSessionId(input?.sessionId);
      const active = readMeetingLiveSession(event.sender.id, sessionId);
      meetingLiveSessions.delete(sessionId);
      if (active.provider === 'aliyun') {
        meetingAliyunLiveRegistry.cancel(event.sender.id, sessionId);
      } else {
        meetingVolcengineLiveRegistry.cancel(event.sender.id, sessionId);
      }
      return { ok: true };
    } catch (error) {
      return { ok: false, error: stableMeetingLiveError(error) };
    }
  });

  ipcMain.handle('desktop:meeting:processRecording', async (_event, input) => {
    log('info', 'meeting:processRecording', { collectionId: input?.collectionId, title: input?.title });
    const { createMeetingService } = await import('./meeting-service.js');
    const { createLocalMeetingSummaryService } = await import('./meeting-summary-service.js');
    const { createMeetingPunctuationService } = await import('./meeting-punctuation-service.js');
    const service = createMeetingService({
      store: getKbStore(),
      transcriber: await createMeetingTranscriberForIpc(input),
      punctuationService: createMeetingPunctuationService(),
      summaryService: createLocalMeetingSummaryService(),
    });
    return service.processRecording({
      requestSource: 'user',
      collectionId: String(input?.collectionId ?? ''),
      title: String(input?.title ?? '').trim() || 'Meeting',
      audioFilePath: String(input?.audioFilePath ?? ''),
      summaryProvider: 'local-only',
      scenario: parseMeetingRecordingScenario(input),
    });
  });

  ipcMain.handle('desktop:meeting:draftRecording', async (_event, input) => {
    log('info', 'meeting:draftRecording', { title: input?.title });
    const { createMeetingService } = await import('./meeting-service.js');
    const { createLocalMeetingSummaryService } = await import('./meeting-summary-service.js');
    const { createMeetingPunctuationService } = await import('./meeting-punctuation-service.js');
    const service = createMeetingService({
      store: getKbStore(),
      transcriber: await createMeetingTranscriberForIpc(input),
      punctuationService: createMeetingPunctuationService(),
      summaryService: createLocalMeetingSummaryService(),
    });
    return service.draftRecording({
      requestSource: 'user',
      title: String(input?.title ?? '').trim() || 'Meeting',
      audioFilePath: String(input?.audioFilePath ?? ''),
      summaryProvider: 'local-only',
      scenario: parseMeetingRecordingScenario(input),
      transcript: typeof input?.transcript === 'string' ? input.transcript : undefined,
      segments: parseMeetingTranscriptSegments(input?.segments),
    });
  });

  ipcMain.handle('desktop:meeting:saveTranscript', async (_event, input) => {
    log('info', 'meeting:saveTranscript', { collectionId: input?.collectionId, title: input?.title });
    const { createMeetingService } = await import('./meeting-service.js');
    const service = createMeetingService({ store: getKbStore() });
    return service.saveTranscript({
      requestSource: 'user',
      collectionId: String(input?.collectionId ?? ''),
      title: String(input?.title ?? '').trim() || 'Meeting',
      audioFilePath: String(input?.audioFilePath ?? ''),
      transcript: String(input?.transcript ?? ''),
    });
  });

  ipcMain.handle('desktop:kb:deleteSource', async (_event, id: string) => {
    log('info', 'kb:deleteSource', { id });
    getKbStore().deleteSource(id);
  });

  ipcMain.handle('desktop:kb:getCollectionState', async (_event, collectionId: string) => {
    log('info', 'kb:getCollectionState', { collectionId });
    return getKbStore().getCollectionState(collectionId);
  });

  ipcMain.handle('desktop:kb:getSourceContent', async (_event, input) => {
    const sourceId = String(input?.sourceId ?? '');
    const offset = Math.max(0, Number(input?.offset ?? 0) || 0);
    const requestedLimit = Number(input?.limit ?? 64_000) || 64_000;
    const limit = Math.min(Math.max(1, requestedLimit), 128_000);
    log('info', 'kb:getSourceContent', { sourceId, offset, limit });
    return getKbStore().getSourceWithContent(sourceId, offset, limit);
  });

  ipcMain.handle('desktop:kb:search', async (_event, input) => {
    log('info', 'kb:search', { collectionId: input?.collectionId, query: input?.query?.slice(0, 50) });
    const store = getKbStore();
    const query = (input?.query ?? '').trim();
    const topK = input?.topK ?? 10;
    if (!query) return [];
    const collectionId = input?.collectionId ?? '';
    const sourceIds = input?.sourceIds as string[] | undefined;
    const allSources = store.listSources(collectionId);
    const filteredSources = sourceIds?.length ? allSources.filter(s => sourceIds.includes(s.id)) : allSources;
    const { extractQueryTerms, meetsRelevanceFloor } = await import('./kb-query-terms.js');
    const uniqueTerms = extractQueryTerms(query);
    const results: Array<{ chunkId: string; sourceId: string; sourceTitle: string; collectionId: string; text: string; pageIndex: number | null; slideIndex: number | null; sheetName: string | null; bm25Score: number; vectorScore: number; fusedScore: number }> = [];
    for (const src of filteredSources) {
      const srcChunks = store.listChunks(src.id);
      for (const chunk of srcChunks) {
        const lower = chunk.text.toLowerCase();
        const matchCount = uniqueTerms.filter((t: string) => lower.includes(t)).length;
        const score = matchCount / uniqueTerms.length;
        if (meetsRelevanceFloor(score)) {
          results.push({
            chunkId: chunk.id,
            sourceId: chunk.sourceId,
            sourceTitle: src.title,
            collectionId: chunk.collectionId,
            text: chunk.text,
            pageIndex: chunk.pageIndex,
            slideIndex: chunk.slideIndex,
            sheetName: chunk.sheetName,
            bm25Score: score,
            vectorScore: 0,
            fusedScore: score,
          });
        }
      }
    }
    results.sort((a, b) => b.fusedScore - a.fusedScore);
    return results.slice(0, topK);
  });
}

function getLoopRuntime(options: RegisterDesktopIpcOptions): NonNullable<RegisterDesktopIpcOptions['loopRuntime']> {
  if (!options.loopRuntime) {
    throw new Error('loop diagnostics runtime is not registered');
  }
  return options.loopRuntime;
}

function readLoopId(input: unknown): string {
  if (typeof input !== 'string' || input.trim().length === 0) {
    throw new Error('loopId must be a non-empty string');
  }
  return input;
}


function readCreateUserLoopTemplateInput(input: unknown): CreateUserLoopTemplateInput {
  if (!isRecord(input)) {
    throw new Error('user loop template input must be an object');
  }
  if (input.kind !== 'markdown_file' && input.kind !== 'task_completion') {
    throw new Error('user loop template kind must be markdown_file or task_completion');
  }
  const base = {
    loopId: readLoopId(input.loopId),
    title: readNonEmptyString(input.title, 'title'),
    description: typeof input.description === 'string' ? input.description : undefined,
    prompt: readNonEmptyString(input.prompt, 'prompt'),
    now: Date.now(),
  };
  let result: CreateUserLoopTemplateInput;
  if (input.kind === 'task_completion') {
    result = { ...base, kind: 'task_completion' };
  } else {
    result = {
      ...base,
      kind: 'markdown_file',
      outputDirectory: readNonEmptyString(input.outputDirectory, 'outputDirectory'),
      outputFileName: readNonEmptyString(input.outputFileName, 'outputFileName'),
    };
  }
  if (Object.prototype.hasOwnProperty.call(input, 'scheduleEnabled')) {
    result.scheduleEnabled = input.scheduleEnabled === true;
  }
  if (isRecord(input.scheduleTrigger)) {
    result.scheduleTrigger = input.scheduleTrigger;
  }
  if (Object.prototype.hasOwnProperty.call(input, 'autoRunApproved')) {
    result.autoRunApproved = input.autoRunApproved === true;
  }
  return result;
}

function readNonEmptyString(input: unknown, fieldName: string): string {
  if (typeof input !== 'string' || input.trim().length === 0) {
    throw new Error(`${fieldName} must be a non-empty string`);
  }
  return input;
}

function isRecord(input: unknown): input is Record<string, unknown> {
  return typeof input === 'object' && input !== null && !Array.isArray(input);
}

export async function expandSelectedMaterialPaths(paths: string[]): Promise<string[]> {
  const files = new Set<string>();
  for (const path of paths) {
    try {
      const entry = await stat(path);
      if (entry.isFile()) {
        files.add(path);
      } else if (entry.isDirectory()) {
        for (const file of await listFilesInDirectory(path)) files.add(file);
      }
    } catch {
      // Skip non-existent paths (e.g. pasted text that looks like a path)
    }
  }
  return [...files].sort();
}

async function listFilesInDirectory(directory: string): Promise<string[]> {
  const files: string[] = [];
  const entries = await readdir(directory, { withFileTypes: true });
  for (const entry of entries) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) {
      files.push(...await listFilesInDirectory(path));
      continue;
    }
    if (entry.isFile()) {
      files.push(path);
    }
  }
  return files;
}
