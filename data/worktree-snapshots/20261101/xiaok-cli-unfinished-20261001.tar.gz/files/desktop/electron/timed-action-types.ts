export type TimedActionTrigger =
  | { kind: 'once'; at: number }
  | { kind: 'interval'; intervalMinutes: number }
  | { kind: 'daily'; hour: number; minute: number; timeZone?: string; daysOfWeek?: number[] }
  | { kind: 'weekdays'; hour: number; minute: number }
  | { kind: 'weekly'; dayOfWeek: number; hour: number; minute: number };

export interface TimedActionRoomTarget {roomId:string;logicalAgentId:string;bindingId:string;generation:number}
export type TimedActionExecutor =
  | { kind: 'notify'; message: string }
  | { kind: 'agent_task'; prompt: string; materials?: unknown[]; roomTarget?:TimedActionRoomTarget }
  | { kind: 'loop'; loopId: string };

export interface TimedActionPolicy {
  maxRuns?: number;
  expiresAt?: number;
  maxConsecutiveFailures?: number;
  minIntervalMinutes?: number;
  overdueGraceMs?: number;
}

export type TimedActionStatus = 'active' | 'paused' | 'completed' | 'cancelled';
export type TimedActionSource = 'user' | 'agent' | 'migration' | 'system';
export type TimedActionOwnerKind = 'user' | 'agent_task' | 'assistant' | 'migration';
export type TimedActionRequestSource = 'user' | 'agent' | 'scheduler';
export interface TimedActionOwnership { ownerKind: TimedActionOwnerKind; ownerId: string; }
export interface TimedActionMutationRequest { requestSource: TimedActionRequestSource; ownerId?: string; }
export type TimedActionExecutorKind = TimedActionExecutor['kind'];

export interface TimedActionRecord {
  id: string;
  title: string;
  description?: string;
  trigger: TimedActionTrigger;
  executor: TimedActionExecutor;
  policy: TimedActionPolicy;
  status: TimedActionStatus;
  source: TimedActionSource;
  ownerKind: TimedActionOwnerKind;
  ownerId: string;
  createdByTaskId?: string;
  nextDueAt?: number;
  lastDueAt?: number;
  runCount: number;
  consecutiveFailures: number;
  lockedRunId?: string;
  lockedAt?: number;
  lastRuntimeTaskId?: string;
  lastError?: string;
  reviewedAt?: number;
  userApprovedAuto?: boolean;
  createdAt: number;
  updatedAt: number;
}

export type TimedActionRecoveryReason =
  | 'normal_tick'
  | 'startup_recovery'
  | 'stale_lock'
  | 'sleep_wake'
  | 'clock_jump';

export interface OverdueRecoveryContext {
  scheduledDueAt: number;
  claimedAt: number;
  overdueMs: number;
  missedIntervals?: number;
  recoveryReason: TimedActionRecoveryReason;
}

export type ExecutorRecoveryDecision =
  | { action: 'execute'; reason: string }
  | { action: 'skip'; reason: string; nextDueAt?: number }
  | { action: 'complete'; reason: string }
  | { action: 'pause'; reason: string };

export interface TimedActionRunRecord {
  runId: string;
  actionId: string;
  executorKind: TimedActionExecutorKind;
  status: string;
  startedAt: number;
  finishedAt?: number;
  runtimeTaskId?: string;
  error?: string;
  decision?: Record<string, unknown>;
}

export interface LoopTimedActionDecision {
  loopRunId: string;
  loopStatus: 'success' | 'failed' | 'blocked' | 'publication_pending';
  nextActionKind?: string;
  nextActionSummary?: string;
  [key: string]: unknown;
}

export interface TimedActionExecutorRuntimeContext {
  timedActionRunId: string;
  /**
   * AbortSignal that fires when the scheduler's executor timeout elapses or
   * when the scheduler is asked to terminate this run. Handlers should
   * propagate this signal into any long-running work they kick off so the
   * underlying task can be cancelled instead of left running as a zombie.
   */
  signal?: AbortSignal;
}

export interface ClaimedTimedAction {
  action: TimedActionRecord;
  runId: string;
  context: OverdueRecoveryContext;
}

export interface TimedActionExecutorResult {
  /** Actual Loop execution remains pending; never a policy skip. */
  awaitingLoopRunId?: string;
  runtimeTaskId?: string;
  decision?: Record<string, unknown>;
  skip?: Exclude<ExecutorRecoveryDecision, { action: 'execute' }>;
}

export interface TimedActionExecutorHandler {
  kind: TimedActionExecutorKind;
  decideRecovery?: (
    action: TimedActionRecord,
    context: OverdueRecoveryContext
  ) => ExecutorRecoveryDecision;
  execute: (
    action: TimedActionRecord,
    context: OverdueRecoveryContext,
    runtimeContext?: TimedActionExecutorRuntimeContext
  ) => Promise<TimedActionExecutorResult> | TimedActionExecutorResult;
}

export interface CreateTimedActionInput {
  id?: string;
  title: string;
  description?: string;
  trigger: TimedActionTrigger;
  executor: TimedActionExecutor;
  policy?: TimedActionPolicy;
  status?: TimedActionStatus;
  source: TimedActionSource;
  ownerKind?: TimedActionOwnerKind;
  ownerId?: string;
  createdByTaskId?: string;
  now?: number;
  nextDueAt?: number;
  lastDueAt?: number;
  runCount?: number;
  consecutiveFailures?: number;
  lastRuntimeTaskId?: string;
  userApprovedAuto?: boolean;
}
