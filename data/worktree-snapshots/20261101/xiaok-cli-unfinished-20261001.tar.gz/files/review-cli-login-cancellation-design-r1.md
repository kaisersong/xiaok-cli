### 第七片代码 R3 BLOCK：bootstrap 登录原 prompt 必须可取消

接受真实首次登录 readline/secret prompt 在早期 signal 后互等 bootstrap 的反例。独立 xiaok login 无 host cancellation 时保留原行为；runLoginCommand 增加第二个可选 host-only cancellation 参数（原 AbortSignal 和可选 onInterrupt），不是 CLI 参数或权限授予。chat-login-bootstrap 只在 host 给 signal 时向原 login 传该对象，现有无 signal dependencies 测试继续只传原 options。

chat 一开始创建唯一 bootstrapAbortController，finalizeChat 发布唯一 promise 后、任何 freezeIngress callback 前同步以 private finalizationReason abort；首次登录和完整 population 中都不替换该 controller。provider、secret、默认模型、验证后 prompt 共用同一 signal：预取消拒同一 reason，不创建新 readline；期间 abort 移除原 data/close/SIGINT/abort listener，关闭实际 readline，并恢复 secret 开始前 raw mode，原 question promise 必须结算。TTY Ctrl+C 的 readline SIGINT 或 secret 字节在 host 下调用原 chat interrupt dispatcher，从而走同一 finalizer；独立 login 保留原 Ctrl+C 退出130。没有 onInterrupt 的其它 host caller 则只结算 cancelled，不擅自 process.exit。prompt 正常结束同样清自己 listeners；EOF 结算空输入，不能无限悬挂。

signal 在 loadConfig 后、每个 prompt 后、原只读 probe 后和每个 saveConfig 前检查，阻止取消后新网络或新配置写；已经开始的 probe/save 不抢先丢弃原 Promise，bootstrap 保持到其实际终态再 finalizer。saveConfig unknown error 仍原启动失败语义，不能制造 session release。bootstrap login abort 只是 private cancellation，不纳未知 writer failures，SIGTERM 最终143。不得把 secret 内容写日志/marker/transcript。

先真实 PTY 红测：无 key 配置停 provider prompt→SIGTERM，不给其它输入，原 prompt 应结算且143；停 secret prompt→SIGTERM；provider prompt→Ctrl+C、secret prompt→Ctrl+C 都经同一host finalizer。独立 login 带 host signal 的真实 PTY验证 default-model prompt abort、preabort无 listener、EOF原 promise 结算，以及 secret 开始前 raw状态和取消后 data listener计数。固定临时 account/config，清所有 provider key env，只用 synthetic key且不输出；验证 disabled 或 synthetic只读fetch，不发真实外部请求。原 login/chunk/bootstrap 测试及所有 CLI finalizer分母继续保留。
