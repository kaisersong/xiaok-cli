# Fixed original Artifact workspace source joins
Current collector keeps the actual Artifact producer full stream as unsupported
family. Actual producer already validates all 16 original tables/schema/exact
lossless SQLite scalar cells/foreign-key integrity and full population. It
declares typed Task and internal pointers plus uninterpreted/external fields.
No changes to original producer/schema/typed cells, no authority/target/ready.
Same four original opaque collector objects and every census/CHECK/end guard.

Every original row remains a physical independent entity, original entire frame
with record/references/parsedMetadata. Record kinds artifact-workspace/lineage/
version for actual three tables' original id; all other 13 tables artifact-row
with exact (table,original rowid), not arbitrary text converted to session ID.
Only original references domain task with referenceState declared and TEXT value
resolve to actual unique Task -> actual unique Session. Every other reference,
raw file/package path, external actor/agent/conversation/workspace root and
metadata remains declaration-only and concrete unresolved, no text scanning.
Unsafe integers, fractional/Infinity/-0 REAL, blobs and NULL are original cells,
not Number/string lossy conversions. The independent existing mapper slots
and gaps remain, including nested/scalar metadata and unresolved history.

Workspace -> original same-source children with literal record.workspace_id;
Lineage -> original same-source Versions with literal record.lineage_id.
Workspace owns Lineage, so its aggregate includes all historical versions,
while a Version does not point back to Lineage/Workspace and inherit siblings.
No reverse parent pointers/physical source union feed individual Version nodes.
For this incremental first join, parent_version_id and every other internal
pointer is retained declaration-only/unresolved until its separately reviewed
semantic dependency is expanded; do not pretend all 16 tables are full closed.
Exact same-source owner cardinality required, missing/ambiguous parent unknown.
All zero-row sources/meta/cursors/views/raw headers and every original full row
are retained and get source output, not dropped for having no current Task.

Tests instantiate original ArtifactWorkspaceStore and make two real Workspaces,
Lineage with historical Version A and appended Version B Task consumers A/B,
independent Lineage/Workspace B and empty Workspace. Version A only Session A,
Version B only Session B (parent pointer explicitly still unresolved), Lineage
and Workspace union A/B; unrelated Workspace never feeds Version A. Actual second
SQLite copy retains all same IDs but original append/store APIs or legal original
row declarations give separate Task attribution; never fake schema/iterator.
Missing Task/duplicate Task/duplicate Session reject guessing. Compare raw original
SQLite rows/typed cell input retained independently before collector, all16-table
brother fullpopulation/scalars and old schema/error tests remain. Explicit nested
metadata containing Session/Task-like strings is unknown, never new identity.
The existing installed UID/IPC/ordinary route are labelled fixtures; production
Store/native helper/broker registry/importer/mapper are real, no OS qualification.
NEW complex cases bounded 15s, old tests and parent99 15s/300s/1h unchanged.

Parent all semantics/Loop/Codex/Groups unresolved/Artifact/KSwarm/Intent/material
and full closedU, installed target/four MainStore/writer drain/native explicit
retirement/absencefsync/charged headroom/atomic ready, full workflow/size gates,
99/new84/final sameSHA review/CLI full/Hook/IntlDoctor/OS/UI/install/GH/release
remain required. No source/body population is clipped, grants or ready minted.

R1 code BLOCK retained: initial tests only counted table rows and checked sampled fields. R2 independently reads every pre-capture original SQLite row/column and typeof(), verifies exact column population and storage class, reverse-decodes each captured cell to compare original value (no production encoder/parser reused). Extra original storage BLOB case updates actual original DB rows without schema changes: source_task_id BLOB must stay uninterpreted/unknown, note_text exact BLOB bytes retained. All earlier cases/time limits and parent gates remain.
