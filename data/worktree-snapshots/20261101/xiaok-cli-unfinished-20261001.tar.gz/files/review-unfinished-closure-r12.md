# 未完成开发收尾（2026-10-01）

用户要求先完成所有在途开发，ZCode 新需求后置。基线为已推送 master a89d7319 加当前未提交源码；隔离 worktree 为 ../xiaok-cli-unfinished-20261001，分支 dev/unfinished-closure-20261001。原目录不覆盖、不清理、不 npm link。初始文件 SHA 清单与日志保存在原 checkout .artifacts/unfinished-closure-20261001/。

## 完整范围与完成条件

逐项保留原 adoption plan、root-progress 和后续各设计的验收，不将测试变绿等同所有功能完成：

1. 实际来源盘点、native custody、完整历史 import 和受保护目标 writer；所有 family 与未解析历史不能丢失或伪造授权。
2. Loop 导出 controller journal：原 principal/current-set、retained session attribution、同库业务与容量事务、真实初始化、大 metadata 增长及兄弟 writer。
3. controller/maintenance 全执行和子进程排空；失败保留实际 lifetime；成功真实重启并重新取得资格。KSwarm shutdown/event/broker writer 同时检查。
4. Intent 父正常链、当前完成消费与完整 99 场景，保持原 15 秒/300 秒/1 小时限额。
5. Goal/Loop/TaskHost/KSwarm 等原全部消费者；50MiB 材料、100MiB 产物、512MiB 包和同 profile 共享容量、旧数据迁移。
6. 原实际 OS/native/VM/receiver 和跨平台资格；实际 unavailable 不能被 mock 或宽松拒绝替代。
7. 每片先设计与独立对抗评审、生产入口红测、实现与回归；最终同版本四方代码审及全功能之后的新 84 paired eval，保持旧 baseline。

完成后核对源码、自动化测试、真实进程/界面、实际安装资格与评测各层证据；不把未运行层称完成。构建产物从隔离源码重建，不复制原 dist 混合产物。临时/private 数据不进入交付。

## 第一片：Intent 首次登记与恢复分流

实测 tests/runtime/intent-delegation/native-contract-host-controller.test.ts 四场景和 publication-host-controller 两场景失败。源码 native-contract-host.run 已捕获 freshRequest，但未使用：reserved → enrolling 后无条件 recoverRequest。controller 的 recoverRequest 对不存在请求持久化 not_prepared 墓碑，首次显式 user advance 因而永远不进入 prepare/authorize。

复用 completion-client 的 prepareRequest/authorize/recoverRequest，不新建协议、store 或权限口。只有本次从 reserved 切 enrolling 且 requestSource=user 的新 advance 可以 prepareRequest，然后显式原 challenge 的 authorize；保存 committed 仍经过原 basis、authority lease 与同版本 Store CAS。输入 requestId、完整 registration/enrollment 固定于原 native record，不新生成请求 ID。

非 fresh（已有 enrolling 的 user advance、scheduler recover）只 recoverRequest，绝不重新 prepare/authorize、换 ID 或自动批准。prepare 已远端成功但丢回包后，同原 ID 恢复原未批准事实；authorize 已提交但丢回包后，恢复原 committed。退休原请求仅 explicit user retrySubject 追加新 request，已有历史不覆盖。close/取消/owner/contract 变化原 guard 必须贯穿 await 与实际持久提交；发生过远端操作的错误保留 enrolling，不假定撤销。

兄弟路径：CLI 的 native host 入口、publication host 对同 enrolled graph 的依赖、原 completion-client、Goal 与 Loop 首次 enrollment 都沿原服务边界审查；不改服务 default-deny，不让恢复入口承担 fresh 授权。

测试保留四个真实 signed controller + SQLite close/reopen 场景及 publication 两场景；另检查只有首次用户 advance 调 prepare/authorize，recover/重复 advance 仅查原请求；丢响应/取消不 replay；原 session-source gate 不因修测试放开。已有 ordinary-source 叶 mock 仅能证明 fixture 的局部协议，不能作为 protected writer 完成证据。

### 第一片 R1 BLOCK 与修订

Qoder 实读源码提出终态判断后重新取 ledger/lease 的竞态；接受该 BLOCK，不写 production。修订：从 enrolling 的完整 expected ledger 捕获开始，fresh 使用实际 direct-mutation lease，恢复用实际 recovery lease，远端 prepare/authorize/recover 和最终 advanceRecord 共用该一次 lease/trackInFlight。首次 prepare 返回后、authorize 前在该 lease 内重核原完整 expected/admission/source/owner。created:false 不 authorize，仅恢复。

savePhase 的终态计算移动到已经获取的实际 lease 内：重新读取 actual ledger，并与原 pre-await expected 全量 hash 和原业务 basis 比较；有 drift 则仅写 stale，native record 本身的 revision/request drift 则原 Store CAS 拒绝。不在 changed 判断之后重取另一个 ledger作为授权依据。原 lease admission callback 在提交阶段改为仅接受该实际 before 与精确 predicted after 两个完整 hash；所有 actual store lock 内检查仍走它。无新 store schema/IPC；不得申请嵌套 lease造成死锁。

原 reserved→enrolling 的持久 reservation 仍先完成，随后本次 fresh 只能在完整 expected 不变时进入 remote lease。两独立 host 同 reserved 竞争，后者原 Store revision CAS 拒，不可两次 native。prepare/authorize结果丢失仍保留 enrolling，恢复只读/退休原请求。终态阶段可能变为 stale，不将正常业务变化误写 enrolled/retired。

## 当前检查

- CLI 全 src strict typecheck 退出 0。
- KSwarm 实际 server shutdown 26/26 通过。
- CLI 全量回归运行中；Intent signed chain 6/6 失败，Loop receiver chain 1/1 失败；原错误日志保留。
- Loop receiver 的隐藏 service error 尚需实际分层定位；在根因确定前不修改 challenge 校验。

## 第二片：完成边界的 receiver 正向 handler

继续实读发现 completion-boundary.invoke 的 receiver-challenge/receiver-reply 分支只有 shape/tuple 检查，随后无条件落到 completion_method。challenge() 与 verifyReply 已定义但未使用。Loop publisher 的失败因此不能直接归因 challenge 生命周期；先恢复这个实际 handler 正向路径，不改变 journal 随机 challenge、upload 独立 challenge 或任何签名校验。

固定实现使用原 read scope：同原数据库 transaction 内核原 row/readGrant 的 owner/kernel principal/epoch/service/current clock，receiver-challenge 仅读既存 settlement challenge，重复读取必须稳定；不签发新 challenge。receiver-reply 以这份实际 fullTupleHash/challenge 调原固定 verifier，原 host.acceptReceiverReply 只接受其私票，再在实际 SQL 尾重核原 read scope，失败完整回滚 journal/其后继失效。返回原 accepted:true 普通事实，不发 mutation grant、不自动 authorize/commit、不宣称新业务执行。

复制/错 owner/错登录 session/旧 scope/无 settlement/伪造 reply 均拒绝；原合法 signed cancellation/committed/unknown/prepared 按 journal 现有状态机处理。verify 的 envelope 在入口已经 canonical clone，回调中不接受 caller 可变引用。所有兄弟 completion.inspect/settle/authorize 的 scope 检查保持，并检查 KSwarm owner fence 在 receiver SQL 尾无遗漏。

原 completion-boundary.test.ts 的稳定 challenge、read scope 不能 settle、伪造签名、合法 signed cancellation、SQL trigger 篡改 scope 后 journal 回滚均继续真实红测；增加 receiver 两 handler 的 wrong-owner/wrong-principal/旧 scope 与 missing settlement 反例。Loop published-candidate-controller 的真实 receiver/socket 链必须恢复绿，再跑相关 verification/publication/Goal/Intent/Loop 消费回归。

### 第二片 R2 BLOCK 与修订

接受 Qoder 两项 BLOCK：receiver-reply 入口显式拒绝 db.inTransaction，防 borrowed outer TX 回滚使 accepted:true 虚假；receiver-challenge 只读既存事实，可以在外层读取但不创造事实。两路径捕获原 readGrant 行与同一次 kswarmFence，末尾必须调用该原 fence，不能仅依赖 check() 内重新捕获的新基线。reply 末check和原fence均在同事务 rollback 域内。新增真实 borrowed-database 外层事务拒绝、原 KSwarm journal UPDATE trigger 改变 enrollment 快照后全回滚的红测。

## 第三片：当前发布 schema 和原生审批构建兼容

完整基线发现 Groups parser 只接受 user_version 1/2，而发布后的实际 DesktopMultiAgentStore 已迁到 3。保持 exact sqlite_master 内容匹配，只新增真实生产 v3 schema variant（若与既存 v2 字节完全相同则复用这份固定比较数据并允许 version3）。userVersion 事件保留真实3，threadQuery 对2/3沿既存完整列查询。未知版本、额外/缺失/篡改index/table仍拒；旧v1/v2分母不裁剪。测试从真实生产Store取得实际schema/pragma，并验证每一个index定义漂移、未知4、原legacy fixture与完整capture mapper。

实际 native review-panel.m 所有对象 property 被改为 assign；clang -fobjc-arc -Werror 在 window/scroll/text直接赋alloc结果时报unsafe-retained-assign，其他对象也可能立即释放。改这些对象property为strong，scalar/function-pointer保持原属性。panel生命周期仍explicit invalidate timer、清window delegate并close，不引入新审批路径。实际编译与private AppKit lifecycle/全部native authorizer拒绝、过期和正文完整性测试作为验收；新增release后弱引用归零检查，避免strong引入未断timer/窗口生命周期环。该测试不构成root安装/真实用户批准资格。

### 第三片 R1 BLOCK 与测试修订

接受 Qoder 的三个测试门槛：对真实生产Store读出的完整schema，逐个table/index分别删除并分别变更type/name/tbl_name/sql，及额外对象，原matcher必须拒绝；保留独立真实SQLite user_version=2正向fixture，v1三个分支与v3原complete capture/mapper全部保留。实测原v2固定sqlite_master与当前v3全部字节相等（证据 groups-v3-actual-schema.json），只能复用这份相同数据，不改DDL匹配或忽略对象。v3原source-start报告3，2/3使用完整同列query，未知0/4/更高拒绝。

R2 对 v2 覆盖表述提出 BLOCK，明确补充：真实 SQLite v2 和 v3 各自必须独立经过完整 native capture → Groups parser 的全部 11 表 → 完整 mapper 的 complete 末事件；仅 v2 matcher 正向不够。旧 v1 三分支另保留。不缩分母或重建测试版DDL。

AppKit weak测试实际设置panel.timer为target=panel的repeating timer并加入RunLoop；释放caller强引用之后先断言weak仍非nil，证明timer实际持有。再从weak临时取得对象，严格执行原invalidate → delegate=nil → close，退出临时强引用/autoreleasepool后断言weak归零。这样真正覆盖timer环而非只测空panel作用域。当前原ARC编译失败保留，所有authorizer与既有close/expiry/正文/滚动/非root拒绝测试保持。

### 第一片代码 R1 兄弟入口 BLOCK

接受 retrySubject 仍以短actor lease执行有副作用recoverRequest的BLOCK。显式user retry必须用同一次direct-mutation lease覆盖原远端请求退休事实核对与本地新request追加；await前后核完整expected、owner/source/admission，提交仍只接受原before与精确单个新增reserved请求after。不重用native票，不调用prepare/authorize，错误仍保留原退休历史。新增held retry时实际ownership release writer必须等待的红测；与普通advance/recover的权限和取消边界一起复测。


## 当前实证更新

- 第一片实际重试同lease串行红测后修复：29/29；第二片receiver相关整链121项，120通过、1原pending。两片固定源码SHA的Qoder代码复评 APPROVE（intent-receiver-code-qoder-r2.log），票仅覆盖这两条链。
- 第三片 Groups 独立v2/v3完整native→11表→mapper和原混合完整mapper：67/67。包含所有schema对象四字段/缺失/extra/unknown拒绝，旧v1三分支不删除。代码独立复审在进行。
- 原生review panel真实ARC编译和AppKit生命周期、application/archive/ordinary-account拒绝：7/7。代码复审APPROVE（native-panel-code-qoder-r1.log）；不包括实际root审批/受保护writer资格。
- KSwarm shutdown 26/26与test:all退出0。CLI/desktop/main/renderer构建基线通过。全量CLI原8020项301失败、Desktop5617项108失败仍为原验收分母；修复后正在重新量，不宣称全量完成。

## 既有 renderer 回归 fixture 跟进

实际3个ChatShell测试共46项中25失败，15个uncaught均是局部api mock没包含新增getObservationTaskStatus；生产api有该语义入口，ObservationControls实际测试已有对应status mock。仅在这3个老fixture补当前接口的unavailable返回，不改生产组件、不移除Observer、不吞掉生产错误，完整rerun原46项与独立ObservationControls；保留所有草稿/ACK/导航/订阅/历史artifact验收。preload flatkeys旧292统计另核实际增量语义API和对应contract后更新，禁止盲目snapshot update。


Groups代码固定SHA复评APPROVE（groups-v3-code-qoder-r1.log）。修正3个旧renderer mock后原46加独立ObservationControls 8，共54/54通过。

preload盘点发现原regex把函数体return/handler误当API，同时遗漏spread的25个MultiAgent方法；308是错误regex计数，实际对象307。将原测试改为在隔离VM运行真实preload.cjs，require只允许electron/contextBridge捕获和os.userInfo fixture，直接Object.keys核canonical FULL_PRELOAD_KEYS，并保留实际307快照。原固定CJS contract/sandbox/IPC权限tests继续跑，不改生产API或屏蔽差异。


## 第四片：真实旧 collector 验证 fixture 的 ESM 装载

desktop-post-seal-facts 原8项失败都来自 loadActualLegacyCollectors 将生产 ESM task-runtime-host.ts 及含import.meta.url的默认skills模块错误bundle为CJS，import.meta变空导致fileURLToPath(undefined)；不是collector语义差异。固定harness继续只给真实task-runtime-host追加两个export，不重实现collector、不改production。改为ESM .mjs；npm dependencies采用packages:external，输出创建在当前repo .artifacts私有临时目录，确保实际Node ESM从本repo依赖解析而非用户全局包。内置/少量动态require以createRequire绑定原sourcePath提供，不接受任意测试request。原worker及8个原判定场景完整继续运行，fixture目录afterEach清理。所有production module/source/auth协议保持，不把fixture装载绿作为任何用户原生资格。

先Qoder只读设计复审；原8条当前构建错误保留，再改harness并跑全部facts/encoding/worker相关集合。实际依赖root来自本fixture的import.meta.url，不用硬编码机器路径或全局npm link。


## 第五片：TaskSnapshot 原保护读取的取消与实际排空

源码 recoverTask 的最初 observations.readProtection(taskId) 是新增真实异步IO，却在 waitSnapshotRead/trackPending 外 await。期间取消不会让外层及时返回，也不会登记该读取为未排空；保护还没读完时原在途writer wait未进入。这是实际新增入口遗漏，不能仅更新旧raw promise计数刷绿。

沿既有 waitSnapshotRead 包住该真实 readProtection 原promise，不向任何底层IO传AbortSignal，不提前清raw；之后仍用原保护事实、原write queue、原checkpoint+journal及最后fresh completion观测，未知/错误保护继续defaultdeny。保护IO尚pending时外部abort立即以原reason返回，raw obligation直到实际完结仍保留，不触发后续checkpoint读取或late cache。原有cached/noncached/earlyabort/lateENOENT/EIO/current完成显示全部继续保留。

新测试用真实POSIX FIFO放在实际protected-observation session路径，通过真实FileSessionStore.load/readProtection进入OS read；实际writer未供字节时原tracker非settled，取消后reader及时拒绝且没有checkpoint读取；写端随后提供无效JSON使真实IO结束，raw才settled且没有业务fallback。另在正常保护读取后精确到原pending task write queue的等候阶段再abort，核writer继续完成、原queue Promise被实际track，而非即刻abort碰巧跳过该阶段。旧counts按新增保护与已存在fresh completion这两个真实async阶段扩展，并核对应原raw身份，不减原场景。

仅修这个异步入口的track/abandon，现有同步alias解析、同步compatibility读取、其它owner native/profile迁移闸门仍各按父验收保留，不能凭本片票宣称全部physical IO或Main protected writer完成。


### 第五片 R1 BLOCK，真实叶实现纠正

实读 FileSessionStore.load 确认它直接调用loadSync→readFileSync，readProtection虽有async签名，原IO仍同步；只包waitSnapshotRead不能满足FIFO及时取消，撤回该实施方向，尚未修改这片production。Qoder独立实读同样BLOCK；不能把假异步当raw排空。下一版需将本次纯读取放在实际独立Worker，保留同原parser/alias/profile边界和线程实际exit作为raw终态；writeQueue测试核map里原tracked promise而非save返回run；明确跑desktop-task-closure原拒绝以及raw无效保护拒绝。同步CAS/admission读不能顺便改成async，不扩大该片资格。接受BLOCK日志snapshot-protection-design-qoder-r1.log。

全量R1（build前置待补）CLI8033：7906pass/51fail/76pending；Desktop5617：5529pass/54fail/34pending。原未缩验收分母和完整失败JSON保留。此后collector真实ESM装载及worker/encoding原80项80/80。当前worktree的root node_modules原symlink引起D9闭图escape，改为原已安装依赖APFS独立clone，不联网安装或全局npm link；源码/锁SHA记录dependency-isolation.json。补当前源码test:sandbox:build完成，重新跑原编译入口失败集合。


## 第六片：安装controller启动失败的真实lifetime保留

实读 installed-controller.catch：注释要求关闭已创建component并retain lifetime，但retainLifetime只assertCurrent，不像正常close失败分支将lifetime放入强Set failedLifetimes。其它assembly/capacity/lifetime registry均WeakMap/WeakSet。原controller-owner.sqlite锁使用better-sqlite3真实native连接，失去强引用可能被GC关闭并释放，违背未知失败保留lifetime原要求。不是改回自动释放来满足旧4条startup测试。

catch进入清理前就failedLifetimes.add(lifetime)，保留原异常/原拒绝状态，全部cleanup仍逐项尝试，cleanup失败也不丢lifetime。不开新listener、不重新资格、不自动replay或unlock。与正常close失败共用现有强retainer，真正进程终止释放OS锁；不新增外部管理API。

测试仍走实际startInstalledVerificationController和closeInstalledControllerComponents，只mock部署/初始容量leaf。原mapping缺失正常maintenance仍成功close lifetime；integrity failure及normalassembly早期失败核原components关闭而lifetime未close。增加WeakRef+独立child强制GC（测试mockfactory不持返回结果）验证原startupfailed lifetime仍强保留，反例同时核原lifetime close计数0。该测试是真实productionretainer的组件行为，不冒root安装资格。先设计独立复审，再红测试，再一行retainer实现；其它stack构造unknown/cleanup失败与正常close重入测试全部保留。


### 第六片 R1 BLOCK 与完整兄弟修订

接受风险真实且无强root、两兄弟cleanup-close失败遗漏、原异常承诺矛盾、GC测试需负对照的BLOCK。

1. installed-controller startup catch开始把原lifetime放入既有failedLifetimes。原全部components仍逐项close；有未知drain时严格保留dependent finalizers原策略，不改成乱序全close。cleanup成功仍抛原startuperror；cleanup失败用AggregateError同时保留原error与cleanupError，cause为原error，不误报正常失败/成功释放。
2. installed-controller-lifetime构造catch先将精确{database,lock}放入既有failedConstructionLocks；实际database.close成功后才lock.close，两者全部成功才移除该同一retained条目。任一close失败均保留原objects并AggregateError含原construction和cleanup error/cause；不在db未知时继续释放dependent lifetime lock。
3. controller-lifetime-lock原初始化catch对db.close失败保留该真实原db于private强Set，并AggregateError保留原初始化和close失败；正常关闭成功仍原error，不新增路径或外部recoverAPI。

测试使用Vitest独立fork+仅测试VM强制GC（same isolate的真实collector）并有WeakRef无保留对象确实collected负对照；factory不是vi.fn，close故障是普通prototype wrapper（无spy.mock.contexts强root），仅保留WeakRef。startup fake lifetime包真实acquireControllerLifetimeLock，GC后实际第二owner仍BUSY；构造在实际lock返回后模拟key获取失败+wrapped lock.close失败，GC后第二owner仍拒；primitive在实际BEGIN EXCLUSIVE后真实syncDirectoryTreeStrict leaf故障、实际native.close wrapper故障，GC后原db仍held并拒第二owner。部署身份leaf可mock只为进入这两catch，实际临时目录SQLite锁保持，结果仅组件/native-lock资格不冒真实安装。清理用原实际close函数收回测试原锁；测试不强改用户源或原运行controller。

维护startup原mapping-missing成功close与所有4失败原components清理/不close lifetime测试，新增cleanup fail聚合原错误和dependent未关闭，保留正常close重入及receiver已有retainer。不能只把旧期望改绿。


### 第六片 R2 BLOCK 与全调用人口修订

接受R2三点：startup stack已返回后后续assembly构造失败必须在原components列表最后按正常close位置执行stack?.close；不能留下原stack。primitive强retainer同时覆盖返回lock.close失败（除初始化catch），因此所有3个真实调用者（controller/receiver/composite）无零成本绕过。receiver/composite构造catch的lock.close失败另AggregateError含原construction/cleanup及cause，不增加假解锁或新root。

GC负对照改为同一真实acquireControllerLifetimeLock在无retainer时完全放掉返回对象，强制GC确认WeakRef归空、同一路径第二OS owner确实可取得；正例仅WeakRef，无预存close闭包或spy上下文，GC后才deref清理实际锁。任何错误的负对照结果都令验收失败，不替换成普通对象。primitive.returned-close/初始化-close、controller启动/构造、receiver与egress/participant构造均纳入。当前尚未改该片production，R1/R2票均BLOCK原样保留。


## 第七片：CLI退出完成后普通/受保护会话仍owned

真实CLI单次成功后delete-session拒session_active，删除闸门本身正确。实际文件与生产函数确认：releaseNativeOwnership只处理有nativeContracts或native定义的ledger；普通/observation ledger跳过。interactive releaseSessionOwnershipForExit虽先release，compound/agent的后续dispose保存owned历史可复活它，最终helper再次因无native跳过。父要求所有真实writer完成后最终持久release。

同一退出清理链内先封新intent/skill/native请求并实际await所有skill、agent、compound coordinator、productObservation的dispose/retire写入；这些真实writer不能用runCleanupWithTimeout的2000ms返回作为已排空。其后对当前磁盘原ledger，如果仍exact CLI instance owner，使用新的仅内部user session execution authority（原root/session/owner/scope，真实SQLite lease）执行现有transitionIntentSessionOwnership action=release，并close该freshauthority。不用已经productObservation.dispose销毁的旧authority，不改FileSessionStore权限，不接受不匹配owner，不重签票或释放其它实例。终态release必须最后一笔session ledger写；非writer的adapter/memory/terminal资源依原合适清理策略。重复调用读released后不写，不要求新授权。

normal single-shot/interactive/slashExit/SIGINT/early provider/startup失败等所有当前finally/cleanup兄弟使用同一终态helper，native contract路径也不能改回缓存ledger，保留原完整expectedHash+StoreCAS/实际lease。不允许将未知dispose catch吞掉后假release；drain失败持owned并暴露cleanup失败。原退出文字/布局/ESC draft/abort语义保留，真实tmux/TTY退出与CLIsmoke必须跑。

已有真实red：CLIobservation delete-after status1、actualdeleteObservationSession报session_active；chat-interactive-runtime原slashExit期望released失败。增原smoke最终parentOwnership事实断言成功与provider失败均released（中途第二fetch仍owned），增加真实store delayed disposer超过2秒不提前release及后续release不复活。其它亲子ownership/当前native链全部保留。不把scope缩成仅删会话测试；protected-target service writer仍未完成。
