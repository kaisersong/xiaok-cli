# 协作空间两项 React 回归：R1

实际 React Doctor 原 full-r3 js-hoist-intl 与 no-static-element-interactions 两红，实际组件每 render new Intl.DateTimeFormat，30 cards 各 title Date.toLocaleString 原生另建formatter；wrapper static div持 onKeyDown。原组件、排序/数据/权限/归档/删除/原IPC不改。

先实测真正生产组件（测试 Main API仅供60 synthetic rooms/30 visible，开发React Profiler，不是安装app/UI）60真实category切换：original source SHA 7b40fb0c777cced596e867217013325539d3506eca323f085f90d3fd8c0c301e，基线r1 median5.482872ms；同 unchanged production source 候选what-if r2前段median4.395322ms，临时native title formatter cache后4.053381ms，7.78%（大于原5%）。候选阶段不是production已实现证明；改后必须新actual-production测量，收益不足5撤回缓存优化（A11y独立保），不能用candidate冒产品或安装UI资格。

生产用useMemo为当前locale/timeZone缓存两个Intl实例。pill options完全保原year numeric/month day2-digit/hour minute2-digit/hour12false；title显式year/month/day/hour/minute/second numeric，保locale默认hour12。ECMA402 Date.prototype.toLocaleString使用CreateDateTimeFormat required any defaults all，defaultall补六numeric，规范 https://tc39.es/ecma402/#sup-date.prototype.tolocalestring，不能用newIntl无参数只输出日期替旧完整时间。

时区不得因memo持旧值：复用当前 renderer shared/index.tsx getActiveTimeZone 原函数（Intl.DateTimeFormat().resolvedOptions().timeZone、catchUTC），原函数不改逻辑移到lib/time-zone.ts，shared旧出口reexport保兼容，组件direct import避免新增barrel。每次render原helper当前时区查询（一Intl实例）抵消原pill每render一实例，缓存title避免30个实例；useMemo依赖locale+真实timeZone，两种locale和系统TZ变化都刷新，不新增poller/持久状态/IPC。文本/seconds/hour12/dateTime属性不改。

把原wrapper onKeyDown逻辑提为typed React KeyboardEvent<HTMLElement> handleRoomMenuKeyDown，用原 menuRef.current 查询同owner的enabled menuitems；只绑定真实button trigger和role=menu，无给static wrapper塞role规避诊断。原Escape关闭/恢复原trigger焦点、ArrowUp/Down环绕、outside click/disabled状态和原确认/归档外部效果全部保，不新增自动删除。原事件只冒泡一次，不给menuitem再加重复监听。

评审后先真实组件新增zh/en完整title等价、nativeTZ变化时间输出、keyboard环绕/disabled/escapefocus回归和原ReactDoctor红，再production。原所有room renderer测试、ReactDoctor全9门禁、typecheck、rendererbuild与实际生产Profiler验证。baseline/candidate source SHA/测试输入环境清楚。父其余原scope/OS/84/99仍未授。


## R4 pure room view projection proposal after failed standalone cache

R3actualformatter-only收益3.36196%已撤回，不使用旧what-if7.78%授资格；原Intl Doctor零诊断门禁不改。新的独立候选是缓存同一原rooms数组的完整纯展示投影：原每次render sorting comparator反复activity/Date.parse，visible30每次newDate+format+toLocaleString。用useMemo([result?.rooms,locale,真实timeZone])一次建立各原room的activity、parsed排序key和完整pill/title，排序及active/archived分类；仅renderer局部派生值，不存durablestate、不memo权限/IPC/revision，原raw room引用留在view用于动作。locale/systemtimezone每次render仍由原getActiveTimeZone完整resolvedOptions真实核，变化重建所有投影；不能用UTCoffset代替zone、不假设永不变。原fallback lastActivityAt/updatedAt/createdAt、无合法日期unknown、descendingdate/roomIdtie、archiving分组、完整title默认6numeric/hour12locale、dateTime完整原字符串均保。formatter在useMemo内只依投影建，两个实例仍用R1原ECMA402等价选项；不能靠helper挪位置骗Doctor。旧getActiveTimeZone原函数移lib并旧shared出口reexport保。

冻结验证：候选前当前实际生产source相同60synthetic/30visible开发Profiler，warm10/测60 categoryswitch，不改原benchmark/assertions/样本规则/不择优；无并行heavytests时baseline跑一次、实际候选跑一次，SHA与raw samples记art。原旧3.36及whatif保留不作本片对照。候选category median相对该次真实baseline必须>=5%且p95不恶化>10%，否则按原字节撤回、不得反复测到阈值；初始loadedcommit durations另记录评估，超过baseline10%须查明回撤，不隐藏cold开销。不修改原9Doctor或UItests取绿，所有原locale/tz/keyboard/菜单权限/归档/delete/refresh/race回归都保，并补实际refresh返回room数组改变lastActivity/title/status/无效timestamp刷新投影。达到门槛才保留该独立投影方案，回归/type/build/同SHAcode票完整。它不是InstalledUI/真实用户room数据性能资格，父真实UI验收不变。

原合适cache只使用实际IPC新数组状态；调用端不可直接改React state数组。Date.now无参与排序、expiry权限仍动作原主事实核，不把原权限cached。原取得最新数组的实际load每次setResult(next)，staleversiongate全保。
