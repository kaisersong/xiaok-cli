# 原清理结果控制流与 lint R1

实际 unchanged主治理helper/oxlint1.86.0/原baseline在isolated root扫描1534files，17current
中的13new no-unsafe-finally：socket-peer 2、compound publication producer 1、compound
provider admission 1、Task snapshot store 2、subagent executor 1、controller metadata
capacity 1、migration marker 1、profile index 1、deployment egress config 1、Desktop
KSwarm task-source wrapper 2。这些finally内显式throw用于失败保护或保留原双失败聚合，
不能删除cleanup/throw、吞失败、刷baseline或用调用throw函数藏同一finally控制流。

本片只重排控制流，所有真实行为和原错误优先级保留（不声称原runtime错误已另修）：
新增纯 settled-outcome utility（src/runtime/settled-outcome.ts），capture sync/async原
work一次为{ok:true,value}或{ok:false,error}，异常包括throw undefined/null保持品牌/
identity，无错误文字过滤、getter遍历、freeze调用者值、cache、quota/authority/writer。
unwrap同一私有outcome：ok return原value，false throw原error。

每处将原目标try的整个body和原catch原样放入 capture回调；原finally全部body仍按原
顺序在capture后运行，只是位置移到try/finally外，不另延后释放或改cleanup顺序。
cleanup成功才unwrap bodyoutcome；cleanup失败原样reject/throw，原Task/KS wrapper
原failure变量/AggregateError精确message/cause/error顺序继续使用。原cleanup再嵌套
finally仍保（如closeProducer、close fd），其中原no-unsafe-finally的explicitthrow
在新的普通cleanup try/catch里，不通过禁用规则隐藏。主要body return从callback
产生outcome，不提前结束原方法；所有原accepted原Promise必须await真正cleanup后
才settle，不能outcome ok当排空证据。原source principal/fence/native/check/fsync/
unknown失败/closed状态/supervisionFailed/physicalwriterpopulation/新资格条件均不动。

每个真实body+cleanup异常矩阵：body success/failure×cleanup success/failure，原error
identity和既有双失败aggregate保持，body和cleanup各一次，throw undefined保；原结果
值/对象identity保持，sync cleanup须同turn，async真正cleanup前原method不settle。
新utility tests先真实缺API红；actuallint13红保留。所有原生产入口回归必须跑：actual
socket peer/nonblocking、compound publication/provider、Task snapshot store/source
route/physical drain、subagent executor/registrybindingcleanup、controller metadata
prepare/caprestore/sharedcapacity、migration/profile index/native filesystem发布、egress
install、Desktop task-source population与真实服务workwrapper。用原真实Gate/SQLite/
filesystem/NativeWorker；不把utility矩阵当所有生命周期通过。遇contextual generic
return type问题只保原annotatedreturn类型，禁止any消解TypeScript或改变DTO形状。

设计审后先tests再production；最后strictroot/Desktop类型/Main/renderer构建、actual
unchanged lint/architecture、全相关原case原时限，冻结SHA只读code审。父全部完整
metadata target/fullhistory/fourMain/allwriters/native retirement/chargedready、原99
15s/300s/1h及新84/四方总审、全部业务/容量/Intl/fullCLI/Desktop/OSUI/TTY/install/GH
条件仍保；本片不是全父完成票，不新权限或任意迁移callback。

## R2 接受并保留实际 R1 DESIGN BLOCK

Qoder实测反例：runTurn continuation原finally当场running=false，sibling reaction可
suspend；await额外captureAsync(callback)会使cleanup晚一个reaction，suspend反而拒。
R1没有生产实现，不借“仅type/refactor”标签跳过这个真实生命周期窗口。

R2取消所有额外async capture utility/callback和新utility API：在每个原async/sync
执行帧本地用私有{error:unknown}|undefined保存原body/catch错误，原try/catch外再执行
原finally内容，成功后throw原body错误或return原结果。没有额外await/Promise/
then/queueMicrotask或新函数调用来执行body/cleanup。

对有return的六目标，用原类型T/string/Readonly<MetadataCapacityAllocation>的本地
settledBodyResult保存return表达式，再break settledBody label；label只包原body/
catch，必须全部内层finally正常穿越执行。原catch内任何throw也被外层本地catch
保存，随后原cleanup总会执行。原return表达式中的await数量和位置原样保留，
最后实际return位于cleanup之后，因此原thenable结果的Promise assimilation仍在原
方法结束/cleanup之后，不通过额外callback提前读取then。原body内部loop continue/
break与nested函数return不改，label名字预先确认无冲突。原四void目标无return，不
添加强制return，cleanup/错误核完继续原后续语句（尤其profile index目录fsync及
readback），不能成功写temp后就提前退出。

原body/catch可变变量和既有failure/AggregateError逻辑全保，cleanup失败原优先级不变。
原cleanup自己nested finally仍保；explicitthrow退出原outerfinally后成为正常控制流，
不是让函数隐藏throw来骗lint。测试添加实际SubagentExecutor的review reaction反例，
原TaskStore与原capacity/fs publication真实成功及失败fixture时序/清理检查全保。原
13lint为pre-production gate，新增实际suspend原控制通过作为不可回归条件（不是假称
原代码functional失败）；红优先来自actual源码治理13条。完整原caller回归/原deadline/
SHA/stricttypes/build/代码审仍必须。R1 BLOCK不可覆盖，R2不得有任何新await边界。

实际13条诊断归并为10个原outer try（六有return、四void）；R2审文字“11目标”属计数笔误，不增加/移除入口。实现前逐AST确认每原诊断归于其唯一finally祖先，同一outertry的多诊断只重排一次。
