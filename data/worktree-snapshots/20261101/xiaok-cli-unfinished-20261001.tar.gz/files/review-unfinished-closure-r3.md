# 未完成开发收尾（2026-10-01）

用户要求先完成所有在途开发，ZCode 新需求后置。基线为已推送 master a89d7319 加当前未提交源码；隔离 worktree 为 ../xiaok-cli-unfinished-20261001，分支 dev/unfinished-closure-20261001。原目录不覆盖、不清理、不 npm link。初始文件 SHA 清单与日志保存在原 checkout .artifacts/unfinished-closure-20261001/。

## 完整范围与完成条件

逐项保留原 adoption plan、root-progress 和后续各设计的验收，不将测试变绿等同所有功能完成：

1. 实际来源盘点、native custody、完整历史 import 和受保护目标 writer；所有 family 与未解析历史不能丢失或伪造授权。
2. Loop 导出 controller journal：原 principal/current-set、retained session attribution、同库业务与容量事务、真实初始化、大 metadata 增长及兄弟 writer。
3. controller/maintenance 全执行和子进程排空；失败保留实际 lifetime；成功真实重启并重新取得资格。KSwarm shutdown/event/broker writer 同时检查。
4. Intent 父正常链、当前完成消费与完整 99 场景，保持原 15 秒/300 秒/1 小时限额。
5. Goal/Loop/TaskHost/KSwarm 等原全部消费者；50MiB 材料、100MiB 产物、512MiB 包和同 profile 共享容量、旧数据迁移。
6. 原实际 OS/native/VM/receiver 和跨平台资格；实际 unavailable 不能被 mock 或宽松拒绝替代。
7. 每片先设计与独立对抗评审、生产入口红测、实现与回归；最终同版本四方代码审及全功能之后的新 84 paired eval，保持旧 baseline。

完成后核对源码、自动化测试、真实进程/界面、实际安装资格与评测各层证据；不把未运行层称完成。构建产物从隔离源码重建，不复制原 dist 混合产物。临时/private 数据不进入交付。

## 第一片：Intent 首次登记与恢复分流

实测 tests/runtime/intent-delegation/native-contract-host-controller.test.ts 四场景和 publication-host-controller 两场景失败。源码 native-contract-host.run 已捕获 freshRequest，但未使用：reserved → enrolling 后无条件 recoverRequest。controller 的 recoverRequest 对不存在请求持久化 not_prepared 墓碑，首次显式 user advance 因而永远不进入 prepare/authorize。

复用 completion-client 的 prepareRequest/authorize/recoverRequest，不新建协议、store 或权限口。只有本次从 reserved 切 enrolling 且 requestSource=user 的新 advance 可以 prepareRequest，然后显式原 challenge 的 authorize；保存 committed 仍经过原 basis、authority lease 与同版本 Store CAS。输入 requestId、完整 registration/enrollment 固定于原 native record，不新生成请求 ID。

非 fresh（已有 enrolling 的 user advance、scheduler recover）只 recoverRequest，绝不重新 prepare/authorize、换 ID 或自动批准。prepare 已远端成功但丢回包后，同原 ID 恢复原未批准事实；authorize 已提交但丢回包后，恢复原 committed。退休原请求仅 explicit user retrySubject 追加新 request，已有历史不覆盖。close/取消/owner/contract 变化原 guard 必须贯穿 await 与实际持久提交；发生过远端操作的错误保留 enrolling，不假定撤销。

兄弟路径：CLI 的 native host 入口、publication host 对同 enrolled graph 的依赖、原 completion-client、Goal 与 Loop 首次 enrollment 都沿原服务边界审查；不改服务 default-deny，不让恢复入口承担 fresh 授权。

测试保留四个真实 signed controller + SQLite close/reopen 场景及 publication 两场景；另检查只有首次用户 advance 调 prepare/authorize，recover/重复 advance 仅查原请求；丢响应/取消不 replay；原 session-source gate 不因修测试放开。已有 ordinary-source 叶 mock 仅能证明 fixture 的局部协议，不能作为 protected writer 完成证据。

### 第一片 R1 BLOCK 与修订

Qoder 实读源码提出终态判断后重新取 ledger/lease 的竞态；接受该 BLOCK，不写 production。修订：从 enrolling 的完整 expected ledger 捕获开始，fresh 使用实际 direct-mutation lease，恢复用实际 recovery lease，远端 prepare/authorize/recover 和最终 advanceRecord 共用该一次 lease/trackInFlight。首次 prepare 返回后、authorize 前在该 lease 内重核原完整 expected/admission/source/owner。created:false 不 authorize，仅恢复。

savePhase 的终态计算移动到已经获取的实际 lease 内：重新读取 actual ledger，并与原 pre-await expected 全量 hash 和原业务 basis 比较；有 drift 则仅写 stale，native record 本身的 revision/request drift 则原 Store CAS 拒绝。不在 changed 判断之后重取另一个 ledger作为授权依据。原 lease admission callback 在提交阶段改为仅接受该实际 before 与精确 predicted after 两个完整 hash；所有 actual store lock 内检查仍走它。无新 store schema/IPC；不得申请嵌套 lease造成死锁。

原 reserved→enrolling 的持久 reservation 仍先完成，随后本次 fresh 只能在完整 expected 不变时进入 remote lease。两独立 host 同 reserved 竞争，后者原 Store revision CAS 拒，不可两次 native。prepare/authorize结果丢失仍保留 enrolling，恢复只读/退休原请求。终态阶段可能变为 stale，不将正常业务变化误写 enrolled/retired。

## 当前检查

- CLI 全 src strict typecheck 退出 0。
- KSwarm 实际 server shutdown 26/26 通过。
- CLI 全量回归运行中；Intent signed chain 6/6 失败，Loop receiver chain 1/1 失败；原错误日志保留。
- Loop receiver 的隐藏 service error 尚需实际分层定位；在根因确定前不修改 challenge 校验。

## 第二片：完成边界的 receiver 正向 handler

继续实读发现 completion-boundary.invoke 的 receiver-challenge/receiver-reply 分支只有 shape/tuple 检查，随后无条件落到 completion_method。challenge() 与 verifyReply 已定义但未使用。Loop publisher 的失败因此不能直接归因 challenge 生命周期；先恢复这个实际 handler 正向路径，不改变 journal 随机 challenge、upload 独立 challenge 或任何签名校验。

固定实现使用原 read scope：同原数据库 transaction 内核原 row/readGrant 的 owner/kernel principal/epoch/service/current clock，receiver-challenge 仅读既存 settlement challenge，重复读取必须稳定；不签发新 challenge。receiver-reply 以这份实际 fullTupleHash/challenge 调原固定 verifier，原 host.acceptReceiverReply 只接受其私票，再在实际 SQL 尾重核原 read scope，失败完整回滚 journal/其后继失效。返回原 accepted:true 普通事实，不发 mutation grant、不自动 authorize/commit、不宣称新业务执行。

复制/错 owner/错登录 session/旧 scope/无 settlement/伪造 reply 均拒绝；原合法 signed cancellation/committed/unknown/prepared 按 journal 现有状态机处理。verify 的 envelope 在入口已经 canonical clone，回调中不接受 caller 可变引用。所有兄弟 completion.inspect/settle/authorize 的 scope 检查保持，并检查 KSwarm owner fence 在 receiver SQL 尾无遗漏。

原 completion-boundary.test.ts 的稳定 challenge、read scope 不能 settle、伪造签名、合法 signed cancellation、SQL trigger 篡改 scope 后 journal 回滚均继续真实红测；增加 receiver 两 handler 的 wrong-owner/wrong-principal/旧 scope 与 missing settlement 反例。Loop published-candidate-controller 的真实 receiver/socket 链必须恢复绿，再跑相关 verification/publication/Goal/Intent/Loop 消费回归。

### 第二片 R2 BLOCK 与修订

接受 Qoder 两项 BLOCK：receiver-reply 入口显式拒绝 db.inTransaction，防 borrowed outer TX 回滚使 accepted:true 虚假；receiver-challenge 只读既存事实，可以在外层读取但不创造事实。两路径捕获原 readGrant 行与同一次 kswarmFence，末尾必须调用该原 fence，不能仅依赖 check() 内重新捕获的新基线。reply 末check和原fence均在同事务 rollback 域内。新增真实 borrowed-database 外层事务拒绝、原 KSwarm journal UPDATE trigger 改变 enrollment 快照后全回滚的红测。
