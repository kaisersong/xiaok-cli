# Original typed Session references in the private metadata graph

Observed actual readCapturedSessionDocument yields sessionReferences for all
compound operation/direct/delegation/provider/tombstone/tree root/allocation/
managed-turn records and original skill invocation/observation/feedback records.
Mapper/input slots enumerate these original refs, but the collector Session
function consumes only lineage and fork. Thus a real historical dispatch or
delegated child body can be absent from that Session's cost association.
Fix is a readonly original-reference join; no permissions/capacity/workflow
approval is inferred, no public arguments/constructors/target are added.

Consume every original sessionReferences entry and retain its complete original
relation/recordId/sessionIdentity/optional childStoreRoot in dependency scope.
Without childStoreRoot use the actual unique Session entity (existing global
identity ambiguity/missing rejection), never a raw string as AgentSession.
With childStoreRoot, require exact ORIGINAL canonical source directory string
from the approved capture source set and exactly one eligible physical Session
source (session-root or session-sqlite-v1). Do not resolve arbitrary relative
strings against process cwd, trim/case-fold names, guess paths or fallback to a
global Session when an explicit root is missing/foreign/ambiguous. Require one
actual Session definition of that identity inside that exact source with its
original storedSessionIdentity=present/direct physical identity. Missing/null/
absent/duplicate/root mismatch produces a specific unresolved original detail.
Multiple eligible Session databases in one directory remain ambiguous even if
only one presently contains the id; root alone cannot prove which DB was meant.
Edges follow original declared Session references; cycles terminate via existing
traversal seen set. Do not add source-wide sessions or reverse/sibling edges.

Every typedReferences declaration (prompt-snapshot/memory/approval/background-job)
stays its original namespace/id/scope and explicit unsupported-session-reference
gap until its actual semantic family is implemented. Never reinterpret one
because its id matches a Session filename. All original declarations/complex
gaps/complete source population and exact each-await/final native census/CHECK
remain. Native Intent/Stage/contracts still COPY source.direct and never traverse
Session dependencies: this extension must not pollute their physical attribution.

Regressions first: actual FileSessionStore/SQLiteSessionStore, actual compound
ledger/direct/delegation constructors and live CAS under SessionExecutionAuthority
lease, original skill-state producers; actual capture/broker/native helpers/mapper.
The route/lifetime/native enrollment SQL remain explicit component fixtures.
History A refers to B (B refs C) => exact A/B/C graph and native Task consumer;
cycle B->A terminates. A/B duplicated original physical source identities reject
unscoped refs but exact child root resolves its original B only. Child root wrong,
missing, relative, duplicate eligible DB roots, absent/null stored child identity
and no child Session remain unresolved with original scope, no global fallback.
Original root/child declarations retain every historical revoked/closed/live and
not_started/drained/unknown state, not interpret reference as execution approval.
Negative collision strings in prompt/memory/approval/job refs must not add Session.
Add a new Native Intent fixture on a Session with such dispatch refs, asserting
native intent still exactly physical A while ordinary Session graph reaches B.
Assert every original reference appears in dependencies, including duplicate ids
with different original records (not deduplicating away original occurrences).
Keep original known execution-lock source namespace fully closed before capture.
After actual semantic red, code, complete original source/capture regressions and
original compound/skill/mapper/store/native Intent siblings, strict root/Main and
actual frozen-SHA independent code review.

All parent requirements remain: other full semantic families/internal dependencies/
legacy custom roots/full closedU, actual target/four MainStore semantic proxies,
native explicit metadata retirement/drain/absence fsync/charged atomic ready,
complete Goal/TaskHost/KSwarm workflows/material/artifact/package capacities,
original 99 Intent time/body population and new 84 paired/final same-SHA reviews,
CLI full/Hook/IntlDoctor, OS/UI/TTY/install/download/integration/GitHub/release.
This component cannot substitute for full native source closure qualification.


## R2: same-permission sibling and legacy logical-container audit
R1 actual APPROVE retained. Self-review found unique('session',id) checks only
definition count, so an absent/null stored identity with lineage/fork/dispatch
could supply OTHER Sessions to a Task through a logical filename. Strengthen
that common private unique resolver: one actual definition AND exactly one
direct stored physical Session identity, otherwise session-identity-unresolved
on the original referring node and no targets. All callers (Task, Goal evidence,
Loop embedded/typed Task, lineage/fork, unscoped Session references, native
independent invocation Sessions) share it. Existing exactSession physical link
already requires direct.length=1; explicit child root uses the same invariant.
Native Intent source index/direct validation stays independently strict.

Add real absent/null Session A with lineage/fork to real B and original Task A
declaring A: Task A and native Task A must remain EMPTY, with original unresolved
identity detail; do not borrow B through logical A. Add absent/null child B with
real lineage C: root-scoped and unscoped dispatch cannot borrow C. Original
Session A/B entities still retain their own declared graph/gaps, but a referring
Task or Session cannot promote logical-container metadata into an AgentSession.
Regression assertions cover both native explicit identity and semantic Task
dependency siblings, original Loop consumers and Native Intent no-ancestor rule.
No ordinary persistence parsing/legacy ABI, native grant or source inventory
gate is changed; this only makes all readonly Session joins require actual
original physical identity uniformly. Complete original parent scope retained.


## Final R1 evidence
Actual Qoder design R1 APPROVE and R2 APPROVE (original logical-container sibling
audit added) retained. New 21 actual Store/constructor/CAS/lease/skill/delegation
cases produce real AssertionError red, including native Task A borrowing B via
absent/null A. Focused -t has 91 unselected cases, not a whole-suite skip claim.
Production follows. Complete original source/capture files 153/153/0pending;
original compound operation/direct/delegation/CAS/file+SQLiteStore/skill/native
Intent/Loop/Groups/mapper/capacity siblings 371/371/0pending. Strict root and
Desktop Main build exit 0. Actual Qoder code APPROVE, 19 original source/test
files frozen SHA before/after identical.

Every original reference occurrence retains its full exact scope. Root-bearing
child reference only matches the original capture's exact canonical unique
eligible Session source and actual direct identity; multi-DB same directory,
foreign/relative/missing roots or nil children remain unresolved, no global
fallback. Common unique Session resolver requires one original physical direct
identity for every semantic/native sibling. Prompt/memory/approval/background
references stay their own declarations with concrete unsupported gaps.
Cycles terminate, original transitive references preserved; Native Intent still
copies physical direct and excludes dispatch/lineage/fork Sessions. Original
unknown facts/gaps/complete census/current/CHECK/mapper-finalization remain.
Only component facts, not OS approval/capacity/native grant/full closedU/target
or workflow qualification. All original unfinished parent requirements retained.
