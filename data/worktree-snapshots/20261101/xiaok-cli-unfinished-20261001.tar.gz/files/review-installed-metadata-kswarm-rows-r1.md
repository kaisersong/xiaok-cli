# KSwarm 原始 SQLite 全实体行闭包 R1

现状：实际 captured-sqlite-kswarm 固定三个表/八 collections，校验完整原 schema、每个 state_json checksum 和原 lossless JSON，原所有历史行均捕获；installed-metadata-closure 却仅 unsupported-family 未构造 KSwarm 实体。本片补全 original entities，不授 KSwarm business enrollment、writer、capacity 或迁移 ready。兄弟来源 File/event log/review queue/roster/native manifest 不在此 SQLite 生产入口，继续保未解析且父全条件不变。

每个实际 family=kswarm、kind=row 的生产帧建立一个 kswarm-row，key=canonical [table,rowid]，sourceId、path=table[rowid] 和 COMPLETE 原始帧不变。包括 state_entities、state_entity_history（deleted 历史也不丢）和 state_meta。原 lossless SQL cells/state_json/checksum/revision/project_id 完整保留，不能 JSON.parse 到 Number 或选择最新历史替代原 body。未知/非法语义仍作为明确 gaps，不丢原 frame。零行来源仍完整 sources 向量。

本片只保存原 references 为 declaration-only dependencies；entity_key 不成为 Session/Task/Goal/project 名称权威，project_id 也不作为绑定。所有 kswarm-row sessions=[]，每个 state 实体/历史行有 kswarm-session-binding-required gap，state_meta 有 kswarm-metadata-semantics-required；不解开 mapper existing gaps，不使用同名 Session A/B、嵌套 JSON taskId/sessionId/任何字符串作会话授权。

独立第二遍只按 family=kswarm/kind=row 枚举原 immutable mapper.events 的全部 sourceId/path/完整 frame，并同 ACTUAL 构造的 kswarm-row entities 比较；缺/额外/改 body 在 collect 返回 opaque handle 前 installed_metadata_kswarm_population 拒。第二遍不与 builder 共享计数或者过滤 active 的条件；保旧 Source vector/hash 和所有其他族群 gates。

测试先用实际 sibling createSqlitePersistence + decomposeState 生成全部8 collections，连续 save 改 project/board 历史、删除 proposal，再 close；使用原 native capture、broker、installed importer、mapper、collector。fixture identity/IPC/lifetime 的 OS 权限明确仍为 fixture。原 DB 收集前 independent SELECT rowid,* 与 typeof class 等用来逐帧原行核验（包括历史 JSON/hash/revision，metadata）；原表 rows 一条不裁。另真实 copy SQLite 相同逻辑 project/task/session 字符串、多来源全保分开，空来源/空业务 rows 保 metadata/source；body 同名 session-A/B 不给 sessions。与原 mapper family rows 完全等值，未解析每实体及 parent legacy 不变。收集后 CHECK、lifetime/原 native census 变化拒仍旧条件。

真实 production mutation 单独省略一构造 node，原二遍 population gate 必须拒，无 handle；finally 恢复原 SHA。保旧完整 installed source/capture/census/mapper/kswarm/capacity 测试、root strict typecheck 与 Main build，同 SHA只读代码审。所有原99完整人口/15s/300s/1h、后新84paired/四方总审、native target/四 MainStore/明确 native retirement/absence fsync/allwriters/shared charged ready、全部业务/OS/UI/TTY/install/package/GH条件仍未完，不把本叶宣称 KSwarm 全工作流闭合。
