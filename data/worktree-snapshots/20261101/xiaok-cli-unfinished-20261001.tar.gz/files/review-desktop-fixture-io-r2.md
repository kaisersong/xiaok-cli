# 剩余 Desktop native fixture 扩面及 IO 人口更新 R2

原三 factory/workspace/service 已实际 35/35+171/171；worker helper 原真实全 src 独立 tsc 编译与 AST original URL 审计，实际 NativeWorker/options/workerData/exit 及全树 SHA 不动，原 source CPU/FIFO 19 项继续保。现另两文件 authorization-runtime 与 entrypoint 原六完成时限仍红（原 source protection worker 一次225ms，多次超原1000ms），只扩至其既有 exact delivery URL mapping 加 protection fixed URL，复用同一编译 helper，actual starts==exits，两树清理，保原1000/500与所有权限/效果/状态断言；如果仍失败必须逐个根治，不用 mapping 掩盖未知状态。只有这两原生 Node 编译入口的资格。

post-seal-io 原四红的两根因：D4 FIFO snapshot read 前新增真实 protection Worker，原30ms盲等时并未接纳 checkpoint read，提前 abort 后 finally 打开 writer 永远没有 reader。以 spy 原 node:fs/promises.readFile 启动原 Promise（完全不替换）记录目标 FIFO checkpoint 已接纳边界，保持原 30ms abort/outward 检查，原 checkpoint Promise 必须包含在 raw tracker 且 abort 后真实未结算、直到真实 writer 供原完整 checkpoint 后才结算。原 protection raw 也全部持有/结算，不能误将已结算 protection 算 pending checkpoint；真实固定 3000ms bounded 等进入（不增原测试5000ms）。若未接纳，不打开无 reader FIFO writer，失败保原错误而清 root。

其余三红：production completionEvidenceFlow 增加 current-completion 原效果，executeEffect trackPending 原 observeInstalledCompletion Promise，普通路由返回ordinary但也有一原 Promise。旧 unsupported URI raw0 应改：spy 原 observeInstalledCompletion 原对象，要求准确等于 tracker 的一个原 Promise，且 fs/promises access/open/stat/realpath/lstat 对 artifact 路径均零调用（原 sync guard 同样读取 current completion 的 installed metadata，不能说系统所有 IO 为零）。随后 localPaths 原 IO 回归和原结构warning全保；getter不同url无新读取。

D6 two FIFO 并发仍 native Worker真实exit/CPUheartbeat<500、500ms grace、拒第三 verifier_capacity、raw open 未结算原物理receipt不能成功。原每 attempt receipt+access+open 三人口增为 receipt+current-completion+access+open 四，前两 settled effect 总2 -> 总4，原 physical drain仍0/原 FIFO open仍pending；abort后 exact8 raw、原两个 Writer 打开关闭后全 raw drain并physical==2。final skip facts 仍 receipt1；不能把 current-completion称 new file read。ESPIPE案例仍实际 access/open/read/close 四全有、真实 ESPIPE与原 fail-open不变，再加 original current-completion准确一个=5，而非删旧 IO 条件。评审后先改 fixtures；不改任何生产。

父其它 tests、Source Worker未知 IO/保护安全、metadata writer、model physical owner、全量/OS/84/99继续未授资格。
