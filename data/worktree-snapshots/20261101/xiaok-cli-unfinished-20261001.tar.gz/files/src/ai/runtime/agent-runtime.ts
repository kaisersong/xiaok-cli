import {ModelStreamPhysicalOwner,type ModelStreamPhysicalRun} from './model-stream-physical-owner.js';
import {prepareCompoundRootIntentStageView} from '../../runtime/sol-pi/compound-provider-admission.js';
import { assertDelegatedObservationOwner } from '../../runtime/sol-pi/delegated-session-owner.js';
import { withObservationExecutionOwner } from '../../runtime/sol-pi/observation-execution-scope.js';
import { assertSemanticCompactionOwner, type SemanticCompactionOwner, type SemanticCompactionOutcome } from '../../runtime/sol-pi/semantic-compaction-owner.js';
import type { ObservationSessionOwner } from '../../runtime/sol-pi/observation-session-owner.js';
import { withObservationMetrics, measureToolResult } from '../../runtime/trace/observation-metrics.js';
import type { Message, MessageBlock, ModelAdapter, ToolCall, ToolExecutionContext } from '../../types.js';
import { join } from 'node:path';
import type { ToolRegistry } from '../tools/index.js';
import { isSuccessfulModelToolResult } from '../tools/index.js';
import type { PromptSnapshot } from '../prompts/types.js';
import { recoverModelStream } from './model-stream-recovery.js';
import { AgentRunController } from './controller.js';
import { createLogger } from '../../utils/logger.js';

const logger = createLogger('agent-runtime');
const MAX_COMPACT_MEMORY_REMINDER_CHARS = 8_000;
const COMPACT_MEMORY_REMINDER_PREFIX = '<system-reminder>\n[Memory restored after compact]\n';
const COMPACT_MEMORY_REMINDER_SUFFIX = '\n</system-reminder>';
import type { AgentRuntimeEvent, RuntimeActivity } from './events.js';
import {
  buildPromptCacheSegments,
  resolveModelCapabilities,
  type CapabilityAwareAdapter,
  type RunInvocationContext,
  type StreamOptions,
} from './model-capabilities.js';
import { resolveRegisteredStrictKimiK3Profile, requiresKimiK3HistoryMigration } from './model-harness-identity.js';
import { AgentSessionState } from './session.js';
import { estimateRequestOverheadTokens, estimateTokens, shouldCompact, truncateToolResult } from './usage.js';
import { decideCompactionCandidate, type CompactionCandidateDecision } from '../../runtime/sol-pi/compaction-policy.js';
import { CompactRunner } from './compact-runner.js';
import { executePortableCompaction } from './portable-compaction-executor.js';
import type { MemoryStore } from '../memory/store.js';
import { evaluateVerificationBeforeCompletionGuard } from '../../runtime/guards/verification-before-completion-guard.js';
import type { TraceBundleV1, TraceToolCall } from '../../runtime/trace/schema.js';
import { MODEL_OUTPUT_CAP, MODEL_OUTPUT_TRUNCATION_MARKER } from '../../shared/stream-safety/redact.js';
import type { ArtifactWorkspaceExecutionScope } from '../../runtime/task-host/types.js';
import {
  isStrictKimiK3Adapter,
  buildSynthesizedProviderContext,
  projectStrictToolExecutionContext,
} from './provider-private-projection.js';
import {
  streamCliChatTaskProviderConversation,
  streamCliSubagentProviderConversation,
  type ProviderConversationSurfaceKind,
} from './provider-conversation-authorization.js';

export interface AgentRuntimeOptions {
  /** Fixed host lifetime shared across actual Agent runtime replacements. */
  modelPhysicalOwner?: ModelStreamPhysicalOwner;
  semanticCompactionOwner?: SemanticCompactionOwner;
  onSemanticCompactionOutcome?: (outcome: SemanticCompactionOutcome) => void;
  /** Host-only; never constructed from agent input or restored authorization. */
  observationOwner?: ObservationSessionOwner;
  /** Host diagnostics only; cannot enable the semantic executor. */
  onSemanticCompactionDecision?: (decision: CompactionCandidateDecision) => void;
  onActivity?: (activity: RuntimeActivity) => void;
  takePendingInput?: () => string | undefined;
  adapter: ModelAdapter;
  registry: ToolRegistry;
  session: AgentSessionState;
  controller: AgentRunController;
  systemPrompt: string;
  promptSnapshot?: PromptSnapshot;
  maxIterations?: number;
  contextLimit?: number;
  compactThreshold?: number;
  compactPlaceholder?: string;
  memoryStore?: MemoryStore;
  taskId?: string;
  executionScope?: ArtifactWorkspaceExecutionScope;
  providerSurfaceKind?: Extract<
    ProviderConversationSurfaceKind,
    'cli-chat-task' | 'cli-subagent'
  >;
}

export class AgentRuntime {
  private readonly modelPhysicalOwner:ModelStreamPhysicalOwner;
  private readonly semanticCompactionOwner?: SemanticCompactionOwner;
  private readonly onSemanticCompactionOutcome?: (outcome: SemanticCompactionOutcome) => void;
  private readonly observationOwner?: ObservationSessionOwner;
  private pendingSubtaskBoundary = false;
  private readonly onSemanticCompactionDecision?: (decision: CompactionCandidateDecision) => void;

  /** Host-confirmed completion candidate; never exposed as an agent tool. */
  notifySubtaskBoundary(): void {
    this.pendingSubtaskBoundary = true;
  }

  private readonly onActivity?: (activity: RuntimeActivity) => void;
  private readonly takePendingInput?: () => string | undefined;
  private adapter: ModelAdapter;
  private readonly registry: ToolRegistry;
  private readonly session: AgentSessionState;
  private readonly controller: AgentRunController;
  private systemPrompt: string;
  private readonly maxIterations?: number;
  private readonly contextLimitOverride?: number;
  private readonly compactThresholdOverride?: number;
  private contextLimit: number;
  private compactThreshold: number;
  private supportsPromptCaching: boolean;
  private promptSnapshot?: PromptSnapshot;
  private compactRunner: CompactRunner;
  private readonly memoryStore?: MemoryStore;
  private readonly taskId?: string;
  private readonly executionScope?: ArtifactWorkspaceExecutionScope;
  private readonly providerSurfaceKind:
    | 'cli-chat-task'
    | 'cli-subagent';

  // 空响应自动重试配置
  private static readonly MAX_EMPTY_RETRIES = 2;

  constructor(options: AgentRuntimeOptions) {
    this.modelPhysicalOwner=options.modelPhysicalOwner??new ModelStreamPhysicalOwner();
    this.observationOwner = options.observationOwner;
    this.onSemanticCompactionDecision = options.onSemanticCompactionDecision;
    this.onActivity = options.onActivity;
    this.takePendingInput = options.takePendingInput;
    this.adapter = options.adapter;
    this.registry = options.registry;
    this.session = options.session;
    this.semanticCompactionOwner = options.semanticCompactionOwner;
    this.onSemanticCompactionOutcome = options.onSemanticCompactionOutcome;
    if (this.semanticCompactionOwner) assertSemanticCompactionOwner(this.semanticCompactionOwner, this.session);
    this.controller = options.controller;
    this.systemPrompt = options.systemPrompt;
    this.promptSnapshot = options.promptSnapshot;
    this.maxIterations = options.maxIterations;
    this.contextLimitOverride = options.contextLimit;
    this.compactThresholdOverride = options.compactThreshold;
    this.contextLimit = 200_000;
    this.compactThreshold = 0.85;
    this.supportsPromptCaching = false;
    this.refreshModelPolicy();
    this.compactRunner = new CompactRunner(this.adapter);
    this.memoryStore = options.memoryStore;
    this.taskId = options.taskId;
    this.executionScope = options.executionScope;
    this.providerSurfaceKind = options.providerSurfaceKind ?? 'cli-chat-task';
  }

  setAdapter(adapter: ModelAdapter): void {
    if (this.controller.hasActiveRun()) {
      throw new Error('cannot replace adapter while a run is active');
    }
    const currentProfile = resolveRegisteredStrictKimiK3Profile(this.adapter);
    const nextProfile = resolveRegisteredStrictKimiK3Profile(adapter);
    if (requiresKimiK3HistoryMigration(currentProfile, nextProfile, this.session.getMessages().length)) {
      if(prepareCompoundRootIntentStageView(this.session).active)throw Error('intent_stage_context_model_migration');
      const context = buildSynthesizedProviderContext('model-switch', this.session.getMessages());
      this.session.replaceMessages([{ role: 'user', content: [{ type: 'text', text:
        'Previous conversation context after a model switch. This is synthesized context, not a raw provider transcript. Recent visible history is retained within 40KB.\n' + context }] }]);
    }
    this.adapter = adapter;
    this.refreshModelPolicy();
    this.compactRunner = new CompactRunner(adapter);
  }

  setSystemPrompt(systemPrompt: string): void {
    this.systemPrompt = systemPrompt;
  }

  setPromptSnapshot(promptSnapshot: PromptSnapshot | undefined): void {
    this.promptSnapshot = promptSnapshot;
  }

  async run(
    input: string | MessageBlock[],
    onEvent: (event: AgentRuntimeEvent) => void,
    externalSignal?: AbortSignal,
    invocationContext?: RunInvocationContext,
  ): Promise<void> {
    externalSignal?.throwIfAborted();
    const physicalRun=this.modelPhysicalOwner.admit();
    try {
    if (this.observationOwner) {
      if (this.executionScope) throw new Error('SOL_PI_OBSERVATION_RESTRICTED_OWNER_NOT_READY');
      if (this.providerSurfaceKind === 'cli-subagent') assertDelegatedObservationOwner(this.observationOwner, this.session, this.registry);
      this.observationOwner.assertSession(this.session);
    } else if (this.session.getProtectedObservationClosure()) {
      throw new Error('SOL_PI_PROTECTED_OBSERVATION_REAUTHORIZATION_REQUIRED');
    }
    const signal=externalSignal?AbortSignal.any([externalSignal,this.modelPhysicalOwner.signal]):this.modelPhysicalOwner.signal;
    return await withObservationExecutionOwner(this.observationOwner, () =>
      withObservationMetrics(this.providerSurfaceKind === 'cli-subagent' ? 'cli-child' : 'cli',
        () => this.runMeasuredBody(input, onEvent, signal, invocationContext,physicalRun)));
    } finally {physicalRun.finish();}
  }

  private async runMeasuredBody(input: string | MessageBlock[], onEvent: (event: AgentRuntimeEvent) => void,
    externalSignal: AbortSignal | undefined, invocationContext: RunInvocationContext | undefined,physicalRun:ModelStreamPhysicalRun): Promise<void> {
    externalSignal?.throwIfAborted();

    const run = this.controller.startRun();
    const strictK3Run = this.isStrictK3Adapter(this.adapter);
    onEvent({ type: 'run_started', runId: run.runId });
    const mergedSignal = externalSignal
      ? AbortSignal.any([run.signal, externalSignal])
      : run.signal;

    let currentAssistantBlocks: MessageBlock[] = [];
    let assistantBlocksCommitted = false;
    let toolResults: MessageBlock[] = [];
    let executedToolIds = new Set<string>();

    try {
      mergedSignal.throwIfAborted();

      this.session.repairIncompleteToolCalls();

      if (typeof input === 'string') {
        this.session.appendUserText(input);
        if (this.memoryStore?.writeRawMessage) {
          const sessionKey = this.promptSnapshot?.id?.slice(0, 16) ?? 'cli';
          this.memoryStore.writeRawMessage(sessionKey, 'user', input).catch((err) => {
            logger.warn('writeRawMessage failed', { error: err instanceof Error ? err.message : String(err) });
          });
        }
      } else {
        this.session.appendUserBlocks(input);
      }

      let iteration = 0;
      let emptyRetries = 0;
      const verificationToolCalls: TraceToolCall[] = [];
      let codeMutatingToolSeen = false;
      let autoCompactionBlocked = false;
      let noReplacementRevision: number | undefined;
      while (true) {
        mergedSignal.throwIfAborted();
        currentAssistantBlocks = [];
        assistantBlocksCommitted = false;
        toolResults = [];
        executedToolIds = new Set<string>();

        // Check if we've reached the max iterations limit (Claude Code style)
        if (this.maxIterations !== undefined && iteration >= this.maxIterations) {
          onEvent({
            type: 'max_iterations_reached',
            runId: run.runId,
            maxIterations: this.maxIterations,
            currentIteration: iteration,
          });
          onEvent({ type: 'run_completed', runId: run.runId });
          return;
        }

        // Only drain at a complete conversation boundary, never inside a tool batch.
        const pendingInput = this.takePendingInput?.();
        if (pendingInput) this.session.appendUserText(pendingInput);

        const stageViewActive=prepareCompoundRootIntentStageView(this.session).active;
        if (this.pendingSubtaskBoundary && !stageViewActive) {
          // The host completion event can arrive inside tool.execute. Capture the
          // candidate only after the complete result batch and queued input exist.
          const sourceRevision = this.session.planCompaction().sourceRevision;
          this.pendingSubtaskBoundary = false;
          if (this.semanticCompactionOwner && !autoCompactionBlocked) {
            const outcome = await this.semanticCompactionOwner.tryCompact({invocationId:run.runId,sourceRevision,
              adapter:this.adapter,tools:this.registry.getToolDefinitions(),systemPrompt:this.systemPrompt,signal:mergedSignal});
            if(outcome.attempted)autoCompactionBlocked=true;
            try { this.onSemanticCompactionOutcome?.(outcome); } catch { /* Host diagnostics do not alter the result. */ }
            if(outcome.status==='compacted' && outcome.record)onEvent({type:'compact_triggered',runId:run.runId,summary:outcome.record.summary,compactionId:outcome.record.id});
            if(outcome.status==='failed')onEvent({type:'compact_failed',runId:run.runId,error:outcome.reason??'semantic_compaction_failed'});
          } else {
          const plan = this.session.planCompaction();
          const decision = decideCompactionCandidate({
            trigger: 'subtask_boundary', runtimeConfirmedCompletion: true,
            pendingApproval: false, pendingMailboxClaim: false, unpairedToolCalls: plan.invalidReason ? 1 : 0,
            sourceRevision, currentRevision: plan.sourceRevision, replaceableMessages: plan.replacedMessages,
            remainingBudget: autoCompactionBlocked ? 0 : 1,
            // No verified monetary/remaining-turn model or provider/anchor contract yet.
            remainingRequestsLowerBound: null, currency: '', savingsPerRequestLowerBound: null,
            summaryCostUpperBound: null, cacheRebuildCostUpperBound: null,
            recallCostUpperBound: null, uncertaintyMarginUpperBound: null,
            providerContractVerified: false, anchorsComplete: false,
          });
          try { this.onSemanticCompactionDecision?.(decision); } catch { /* Diagnostics cannot break a run. */ }
          }
        }

        if (
          !stageViewActive && !autoCompactionBlocked
          && decideCompactionCandidate({ trigger: 'threshold' }).action === 'delegate-existing-threshold'
          && shouldCompact(
            estimateTokens(this.session.getMessages())
              + estimateRequestOverheadTokens(this.systemPrompt, this.registry.getToolDefinitions()),
            this.contextLimit,
            this.compactThreshold,
          )
        ) {
          const plan = this.session.planCompaction();
          if (plan.sourceRevision === noReplacementRevision) {
            // The same frozen history still has no replaceable prefix.
          } else {
            const outcome = await executePortableCompaction(
              {
                plan,
                signal: mergedSignal,
                trigger: { kind: 'threshold' },
              },
              {
                summarizePrefix: (messages, signal) =>
                  this.compactRunner.run(
                    [...messages],
                    this.buildInvocationOptions(signal, invocationContext),
                    () => onEvent({type:'execution_progress',runId:run.runId}),
                  ),
                applyPlan: (frozenPlan, summaryText) =>
                  this.session.applyCompaction(frozenPlan, summaryText),
              },
            );

            if (
              outcome.summaryModelFailed
              && outcome.summaryFailureCode === 'portable_summary_failed'
            ) {
              onEvent({
                type: 'compact_failed',
                runId: run.runId,
                error: 'portable compaction summary failed',
              });
            }

            if (outcome.status === 'no_replacement') {
              noReplacementRevision = plan.sourceRevision;
            } else if (outcome.status === 'compacted') {
              autoCompactionBlocked = true;
              onEvent({
                type: 'compact_triggered',
                runId: run.runId,
                summary: outcome.record.summary,
                compactionId: outcome.record.id,
              });
              try {
                await this.injectMemoryAfterCompact();
              } catch (memoryError) {
                logger.warn('injectMemoryAfterCompact failed', {
                  error: memoryError instanceof Error ? memoryError.message : String(memoryError),
                });
              }
            } else {
              autoCompactionBlocked = true;
            }
          }
        }

        this.reportActivity({ phase: 'model' });
        const streamProviderConversation = this.providerSurfaceKind === 'cli-subagent'
          ? streamCliSubagentProviderConversation
          : streamCliChatTaskProviderConversation;
        let recoveryAttempt = 0;
        let toolProviderInvocationId: string | undefined;
        onEvent({ type: 'model_request_started', runId: run.runId });
        for await (const chunk of recoverModelStream({
          physicalRun,
          signal: mergedSignal,
          onRetry: (notice) => {
            const partial = currentAssistantBlocks.filter((block): block is Extract<MessageBlock, { type: 'text' }> => block.type === 'text').map(block => block.text).join('').slice(-12000);
            currentAssistantBlocks = [];
            if (partial) this.session.appendUserText('The previous model response was interrupted by a connection failure. This is synthesized partial visible output, not a completed answer or executed tool call. Continue from the completed tool results; do not repeat completed operations.\n' + JSON.stringify({ partialOutput: partial }));
            recoveryAttempt = notice.attempt;
            this.reportActivity({ phase: 'model' });
            onEvent({ type: 'model_recovery', runId: run.runId, ...notice });
          },
          open: (requestSignal) => {
            const runtime = this;
            return (async function* () {
              const logicalInvocationId = `${run.runId}:${iteration}:recovery-${recoveryAttempt}`;
              toolProviderInvocationId = logicalInvocationId;
              const tools = runtime.registry.getToolDefinitions();
              const view=prepareCompoundRootIntentStageView(runtime.session,logicalInvocationId);
              try {
              const messages=view.messages;
              const options = runtime.buildInvocationOptions(requestSignal, invocationContext,messages);
              const prepared = runtime.observationOwner?.prepareRequest
                ? await runtime.observationOwner.prepareRequest({ logicalInvocationId, messages, tools,
                    systemPrompt: runtime.systemPrompt, options,
                    requestPreview: runtime.adapter.getObservationRequestPreview?.bind(runtime.adapter) })
                : undefined;
              requestSignal.throwIfAborted();view.assertCurrent();
              yield* streamProviderConversation({ adapter: runtime.adapter as CapabilityAwareAdapter,
                messages: prepared?.messages ?? messages, tools, systemPrompt: runtime.systemPrompt,
                options: prepared?.providerDisclosure ? { ...options, providerDisclosure: prepared.providerDisclosure } : options,
                invocationId: logicalInvocationId });
              } finally {view.dispose();}
            })();
          },
        })) {
          this.reportActivity({ phase: chunk.type === 'thinking' ? 'thinking' : 'model' });
          if (chunk.type === 'usage') {
            const usage = this.session.updateUsage(chunk.usage);
            onEvent({ type: 'usage_updated', runId: run.runId, usage });
            continue;
          }

          mergedSignal.throwIfAborted();
          if (chunk.type === 'text') {
            // Merge consecutive text blocks to avoid fragmented storage
            const lastBlock = currentAssistantBlocks[currentAssistantBlocks.length - 1];
            if (lastBlock?.type === 'text') {
              lastBlock.text += chunk.delta;
            } else {
              currentAssistantBlocks.push({ type: 'text', text: chunk.delta });
            }
            onEvent({ type: 'assistant_text', runId: run.runId, delta: chunk.delta });
            continue;
          }

          if (chunk.type === 'thinking') {
            const lastBlock = currentAssistantBlocks[currentAssistantBlocks.length - 1];
            const reasoningSource = chunk.reasoningProvenance?.source ?? chunk.signature;
            if (
              lastBlock?.type === 'thinking'
              && lastBlock.reasoningSource === reasoningSource
              && JSON.stringify(lastBlock.reasoningProvenance)
                === JSON.stringify(chunk.reasoningProvenance)
            ) {
              lastBlock.thinking += chunk.delta;
            } else {
              currentAssistantBlocks.push({
                type: 'thinking',
                thinking: chunk.delta,
                ...(reasoningSource ? { reasoningSource } : {}),
                ...(chunk.reasoningProvenance
                  ? { reasoningProvenance: chunk.reasoningProvenance }
                  : {}),
              });
            }
            continue;
          }

          if (chunk.type === 'tool_use') {
            currentAssistantBlocks.push(chunk);
            continue;
          }

          if (chunk.type === 'done') {
            break;
          }
        }
        mergedSignal.throwIfAborted();

        const hasVisibleOutput = currentAssistantBlocks.some(
          (block) => block.type === 'text' || block.type === 'tool_use',
        );
        if (!hasVisibleOutput) {
          // 模型只返回了 thinking（无 text/tool_use），视为空响应自动重试
          if (emptyRetries < AgentRuntime.MAX_EMPTY_RETRIES) {
            emptyRetries++;
            continue;
          }
          throw new Error('模型未返回任何文本或工具调用（已重试 2 次）');
        }

        // 成功收到响应，重置空响应计数器
        emptyRetries = 0;

        this.session.appendAssistantBlocks(currentAssistantBlocks);
        assistantBlocksCommitted = true;

        const toolCalls = currentAssistantBlocks.filter((block): block is ToolCall => block.type === 'tool_use');
        if (toolCalls.length === 0) {
          // A message may arrive while the final response is streaming. Handle it in
          // this run after committing that response, without fabricating tool results.
          const lateInput = this.takePendingInput?.();
          if (lateInput) {
            this.session.appendUserText(lateInput);
            iteration += 1;
            continue;
          }
          this.emitVerificationGuardIfNeeded(input, verificationToolCalls, codeMutatingToolSeen, run.runId, onEvent);
          onEvent({ type: 'run_completed', runId: run.runId });
          return;
        }

        toolResults = [];
        const baseToolExecutionContext = this.buildToolExecutionContext(mergedSignal);
        for (const toolCall of toolCalls) {
          mergedSignal.throwIfAborted();
          this.reportActivity({ phase: 'tool', toolName: toolCall.name });
          onEvent({
            type: 'tool_started',
            runId: run.runId,
            toolName: toolCall.name,
            input: toolCall.input,
          });

          let observationProjectionFailure: { error: unknown } | undefined;
          const toolExecutionContext: ToolExecutionContext = {
            ...baseToolExecutionContext,
            toolInvocationId: toolCall.id,
            hostProviderInvocationId: toolProviderInvocationId,
            ...(this.observationOwner ? {
              observationCollector: this.observationOwner.collectorFor(toolCall.id),
              observationProvenance: () => this.observationOwner!.getResultProvenance(toolCall.id),
              projectObservationResult: async (nativeResult: string) => {
                try { return await this.observationOwner!.projectToolResult(toolCall.id, nativeResult); }
                catch (error) {
                  observationProjectionFailure = { error };
                  const ok = isSuccessfulModelToolResult(nativeResult);
                  return `${ok ? '' : 'Error: '}[tool execution ${ok ? 'completed' : 'failed'}; observation disclosure blocked]`;
                }
              },
            } : {}),
            runtimeFactSink: {
              emit: (fact) => onEvent({
                type: 'tool_execution_fact',
                runId: run.runId,
                ...fact,
              }),
            },
          };
          const result = await this.registry.executeTool(toolCall.name, toolCall.input, {...toolExecutionContext,
            onExecutionHealth: state => {this.reportActivity({phase:'tool',toolName:toolCall.name,executionHealth:state});onEvent({type:'execution_health',runId:run.runId,invocationId:toolCall.id,state});},
            executionProgress: {progress: () => {this.reportActivity({phase:'tool',toolName:toolCall.name});onEvent({type:'execution_progress',runId:run.runId});},wait:()=>{},resume:()=>{}},
          });
          // Registry guards cannot cover the microtask before this await resumes.
          // Reject cancellation before spilling or retaining a successful result.
          mergedSignal.throwIfAborted();
          const ok = isSuccessfulModelToolResult(result);
          const sessionSnapshot = this.session.exportSnapshot();
          if (observationProjectionFailure) {
            toolResults.push({ type: 'tool_result', tool_use_id: toolCall.id, content: result, is_error: !ok });
            executedToolIds.add(toolCall.id);
            throw observationProjectionFailure.error;
          }
          mergedSignal.throwIfAborted();
          const truncated = truncateToolResult(result, MODEL_OUTPUT_CAP + MODEL_OUTPUT_TRUNCATION_MARKER.length, {
            sessionId: sessionSnapshot.sessionId,
            toolCallId: toolCall.id,
            spillDir: join(sessionSnapshot.cwd, '.xiaok', 'spill'),
          });
          // Exact final history bytes; failure only makes this observation ineligible for P1-B.
          try { this.observationOwner?.finalizeToolResult(toolCall.id, truncated.content); } catch { /* provenance is optional; never replay a completed tool */ }
          measureToolResult('history_result', toolCall.id, toolCall.name, truncated.content);
          toolResults.push({ type: 'tool_result', tool_use_id: toolCall.id, content: truncated.content, is_error: !ok });
          mergedSignal.throwIfAborted();
          this.reportActivity({ phase: 'model' });
          executedToolIds.add(toolCall.id);
          verificationToolCalls.push({
            id: toolCall.id,
            name: toolCall.name,
            inputPreview: JSON.stringify(toolCall.input),
            outputPreview: result.slice(0, 10_000),
            startedAt: new Date().toISOString(),
            endedAt: new Date().toISOString(),
            ok,
          });
          codeMutatingToolSeen = codeMutatingToolSeen || isCodeMutatingToolCall(toolCall.name, toolCall.input);
          onEvent({
            type: 'tool_finished',
            runId: run.runId,
            invocationId: toolCall.id,
            toolName: toolCall.name,
            ok,
          });
        }

        this.session.appendUserToolResults(toolResults);
        toolResults = [];
        await this.registry.publishCompoundHistory?.();
        executedToolIds = new Set<string>();
        await this.observationOwner?.publishCurrentHistory?.({ strictPrivateProtocol: strictK3Run });
        iteration += 1;
      }
    } catch (error) {
      if (mergedSignal.aborted) {
        const partialSentinel = '\n\n[partial - interrupted by user]';
        const blocks = currentAssistantBlocks.map((block) => ({ ...block })) as MessageBlock[];

        if (!strictK3Run && !assistantBlocksCommitted && blocks.length > 0) {
          const lastTextIndex = blocks.map((block) => block.type).lastIndexOf('text');
          if (lastTextIndex >= 0) {
            const textBlock = blocks[lastTextIndex];
            if (textBlock.type === 'text') {
              blocks[lastTextIndex] = {
                ...textBlock,
                text: `${textBlock.text}${partialSentinel}`,
              };
            }
          }
          this.session.appendAssistantBlocks(blocks);
          assistantBlocksCommitted = true;
        }

        const seenToolResultIds = new Set(
          toolResults
            .filter((block): block is Extract<MessageBlock, { type: 'tool_result' }> => block.type === 'tool_result')
            .map((block) => block.tool_use_id),
        );
        const syntheticToolResults: MessageBlock[] = (
          strictK3Run && !assistantBlocksCommitted ? [] : blocks
        )
          .filter((block): block is ToolCall => block.type === 'tool_use')
          .filter((toolCall) => !executedToolIds.has(toolCall.id) && !seenToolResultIds.has(toolCall.id))
          .map((toolCall) => {
            seenToolResultIds.add(toolCall.id);
            measureToolResult('history_result', toolCall.id, toolCall.name, '[user-cancelled]');
            return {
              type: 'tool_result' as const,
              tool_use_id: toolCall.id,
              content: '[user-cancelled]',
              is_error: true,
            };
          });
        const mergedToolResults = strictK3Run && !assistantBlocksCommitted
          ? []
          : [...toolResults, ...syntheticToolResults];
        if (mergedToolResults.length > 0) {
          this.session.appendUserToolResults(mergedToolResults);
          toolResults = [];
        }

        const partialText = blocks
          .filter((block): block is Extract<MessageBlock, { type: 'text' }> => block.type === 'text')
          .map((block) => block.text)
          .join('');
        onEvent({ type: 'run_aborted', runId: run.runId, partialText });
        throw error;
      }

      const normalized = error instanceof Error ? error : new Error(String(error));
      if (assistantBlocksCommitted && toolResults.length > 0) {
        this.session.appendUserToolResults(toolResults);
      }
      this.session.repairIncompleteToolCalls();
      onEvent({ type: 'run_failed', runId: run.runId, error: normalized });
      throw normalized;
    } finally {
      try { await this.observationOwner?.publishCurrentHistory?.({ strictPrivateProtocol: strictK3Run }); }
      finally {
        this.pendingSubtaskBoundary = false;
        this.controller.completeRun(run.runId);
      }
    }
  }

  private reportActivity(activity: RuntimeActivity): void {
    try { this.onActivity?.(activity); } catch { /* Telemetry cannot break a run. */ }
  }

  private refreshModelPolicy(): void {
    const capabilities = resolveModelCapabilities(this.adapter);
    this.contextLimit = this.contextLimitOverride ?? capabilities.contextLimit;
    this.compactThreshold = this.compactThresholdOverride ?? capabilities.compactThreshold;
    this.supportsPromptCaching = capabilities.supportsPromptCaching;
  }

  private isStrictK3Adapter(adapter: ModelAdapter): boolean {
    return isStrictKimiK3Adapter(adapter);
  }

  private buildInvocationOptions(
    signal?: AbortSignal,
    invocationContext?: RunInvocationContext,
    messages: Message[] = this.session.getMessages(),
  ): StreamOptions | undefined {
    const options: StreamOptions = {
      ...(signal ? { signal } : {}),
      ...(invocationContext?.cacheKey
        ? { cacheKey: invocationContext.cacheKey }
        : {}),
    };

    if (!this.supportsPromptCaching) {
      return Object.keys(options).length > 0 ? options : undefined;
    }

    const toolDefinitions = this.registry.getToolDefinitions()
      .slice()
      .sort((left, right) => left.name.localeCompare(right.name));

    // Use segments for multi-block system prompt cache boundary if available.
    const snapshot = this.promptSnapshot;
    const systemSegments = snapshot?.segments
      .filter((seg) => seg.key !== 'memory_summary')
      .filter((seg) => seg.text)
      .map((seg) => ({ text: seg.text, cacheable: seg.cacheable }));

    const systemPromptInput = systemSegments && systemSegments.length >= 1
      ? systemSegments
      : this.systemPrompt;

    return {
      ...options,
      promptCache: buildPromptCacheSegments(
        systemPromptInput,
        toolDefinitions,
        messages,
      ),
    };
  }

  private buildToolExecutionContext(signal?: AbortSignal): ToolExecutionContext {
    const toolDefinitions = this.registry.getToolDefinitions()
      .slice()
      .sort((left, right) => left.name.localeCompare(right.name));

    const strictK3 = this.isStrictK3Adapter(this.adapter);
    const stageView=prepareCompoundRootIntentStageView(this.session);
    const messages = stageView.messages.map((message) => ({
      role: message.role,
      content: message.content
        .filter((block) => !strictK3 || block.type !== 'thinking')
        .map((block) => ({ ...block })),
    }));
    const session = this.session.exportSnapshot();
    if (strictK3 || stageView.active) {
      session.messages = structuredClone(messages);
    }
    const context: ToolExecutionContext = {
      taskId: this.taskId ?? session.sessionId,
      executionScope: this.executionScope,
      session,
      messages,
      systemPrompt: this.systemPrompt,
      toolDefinitions,
      promptSnapshot: this.promptSnapshot,
      ...(!strictK3 && this.supportsPromptCaching
        ? {
            promptCache: buildPromptCacheSegments(
              this.systemPrompt,
              toolDefinitions,
              messages,
            ),
          }
        : {}),
      signal,
    };
    return strictK3
      ? projectStrictToolExecutionContext(context)
      : context;
  }

  private emitVerificationGuardIfNeeded(
    input: string | MessageBlock[],
    toolCalls: TraceToolCall[],
    codeMutatingToolSeen: boolean,
    runId: string,
    onEvent: (event: AgentRuntimeEvent) => void,
  ): void {
    if (!codeMutatingToolSeen || !looksLikeCodeRequest(input)) {
      return;
    }

    const bundle = buildGuardTraceBundle(toolCalls);
    const decision = evaluateVerificationBeforeCompletionGuard({
      scope: { kind: 'code', confidence: 0.85 },
      bundle,
    });
    if (decision.ok) {
      return;
    }
    const event = decision.events[0];
    onEvent({
      type: 'guard_evaluated',
      runId,
      guardId: 'verification-before-completion',
      mode: decision.mode === 'block' ? 'blocked' : 'warned',
      category: typeof event?.data?.category === 'string' ? event.data.category : 'missing_verification',
      reason: decision.reason,
      action: decision.action,
    });
  }

  private async injectMemoryAfterCompact(): Promise<void> {
    if (!this.memoryStore) return;
    const snapshot = this.session.getPromptSnapshot();
    if (!snapshot?.memoryRefs?.length) return;

    const memories = await this.memoryStore.listRelevant({ cwd: snapshot.cwd, query: '' });
    const relevant = memories.filter((m) => snapshot.memoryRefs.includes(m.id));
    if (relevant.length === 0) return;

    const memText = relevant.map((m) => `- ${m.title}: ${m.summary}`).join('\n');
    const thresholdTokens = Math.floor(this.contextLimit * this.compactThreshold);
    const currentTokens = estimateTokens(this.session.getMessages());
    const headroomChars = Math.max(0, thresholdTokens - currentTokens) * 4;
    const reminderChars = Math.min(MAX_COMPACT_MEMORY_REMINDER_CHARS, headroomChars);
    const contentChars = reminderChars
      - COMPACT_MEMORY_REMINDER_PREFIX.length
      - COMPACT_MEMORY_REMINDER_SUFFIX.length;
    if (contentChars <= 0) return;

    const boundedMemory = memText.length > contentChars
      ? `${memText.slice(0, Math.max(0, contentChars - 1))}…`
      : memText;
    if (!boundedMemory) return;

    this.session.appendUserText(
      `${COMPACT_MEMORY_REMINDER_PREFIX}${boundedMemory}${COMPACT_MEMORY_REMINDER_SUFFIX}`,
    );
  }
}

function looksLikeCodeRequest(input: string | MessageBlock[]): boolean {
  const text = typeof input === 'string'
    ? input
    : input.map((block) => block.type === 'text' ? block.text : '').join('\n');
  return /(code|bug|test|tests|typescript|javascript|python|rust|go|编译|测试|代码|修复|修改|实现|src\/|\.ts\b|\.tsx\b|\.js\b|\.py\b)/iu.test(text);
}

function isCodeMutatingToolCall(toolName: string, input: Record<string, unknown>): boolean {
  const normalized = toolName.toLowerCase();
  if (normalized === 'edit' || normalized === 'write') {
    return typeof input.file_path === 'string' && /\.(ts|tsx|js|jsx|py|rs|go|java|kt|swift|c|cc|cpp|h|hpp|css|scss|json|ya?ml|toml|mjs|cjs)$/iu.test(input.file_path);
  }
  if (normalized === 'bash' && typeof input.command === 'string') {
    return /\b(apply_patch|sed\s+-i|perl\s+-pi|npm\s+run\s+build|tsc|cargo|go)\b/iu.test(input.command);
  }
  return false;
}

function buildGuardTraceBundle(toolCalls: TraceToolCall[]): TraceBundleV1 {
  const now = new Date().toISOString();
  return {
    schemaVersion: 1,
    bundleId: 'runtime_guard_verification',
    createdAt: now,
    source: { app: 'xiaok-cli' },
    scope: { kind: 'session', sessionId: 'runtime' },
    environment: {},
    turns: [],
    events: [],
    toolCalls,
    approvals: [],
    tasks: [],
    agents: [],
    artifacts: [],
    memoryRefs: [],
    skillEvidence: [],
    recovery: [],
    crashes: [],
    redactions: [],
    attachments: [],
    summary: { toolCallCount: toolCalls.length },
  };
}
