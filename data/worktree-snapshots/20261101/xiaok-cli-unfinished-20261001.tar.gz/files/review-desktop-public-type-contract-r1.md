# Desktop 公共类型边界修复 R1

actual main architecture checker/current policy+unchanged baseline 在 isolated root
有10条new跨层私有type import：preload-api 的 LoopRunObservationView、
AutomationRunHistoryItem、DesktopGoalNativeMutationProjection、GoalCompletionObservation、
GoalActivation/CreationInput/Input/State 与 renderer ChatShell/GoalBar/ObservationControls
的 Goal 与 Compound/Semantic 状态。原 syntax解析已修，本片只调整明确公共IPC数据
类型入口，不改任何业务值、runtime函数、调用、IPC channel 或durable state owner。

按已有 desktop/shared/task-types.ts 显式 type-reexport 原 canonical DTO 的相同方式，
新增 desktop/shared/host-observation-types.ts，只白名单 export type 原上述UI/IPC类型
及 GoalEvidenceKind，禁止 export *、runtime value、Host/Store/service/方法/authority类型。
这些原类型已在公开preload/rendererAPI使用，本片不扩字段/删字段/复制interface；
canonical所有者仍Main/CLI。preload-api 仍显式 re-export DesktopGoalNativeMutationProjection
以保现 consumer ABI，仅来源改shared。10条原imports精确改路径；其它现有baseline
privateimports不扩scope，不刷policy/publicTypeContracts/baseline/主checkout。

实际 architecture check --changed 原10条红已记录；设计审后加真实编译器回归：
对actual shared模块用实际 TypeScript transpileModule（原NodeNext/ESNext）验证emit没有
host require/import，只export{}；export类型名 exact白名单无runtime statements，actual
importer源码十处都经过shared且不新runtime导入。原 preload-contract/sandbox及真实
Goal/Loop/renderer既有回归保原数据形状/通道/控制条件。先测试缺模块真实红，再改生产。
root/Main/Desktop typecheck与Main/renderer构建、actualarchitecture同原baseline，
最终同SHA只读代码审。不是IPC行为变更/renderer持状态，也不授原父全完成。

全父闭包/target/四MainStore/allwriterdrain/native retirement/原shared ledger/99原时限/
新84paired/四方总审/IntlDoctor/fullCLI/Desktop/OSUI安装包/下载/集成/GH条件保留。

设计审实际 APPROVE，提出原preload内联 Compound/Semantic status import也是同权限兄弟类型入口，验收必须同时改为同一shared显式type imports，并保现API字段原类型；不能只修AST checker已发现的10条。实际typecheck和编译erasure共同验，不把transpileModule冒structural完整资格。
