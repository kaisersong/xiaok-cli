**BLOCK**

1. **启动失败仍可遗留 `owned`**  
   `src/commands/chat.ts:755-756` 已提交 resume/takeover ownership，但完整 finalizer 到 `src/commands/chat.ts:1367` 才安装。若其间如 `src/commands/chat.ts:819` Goal 文件加载失败，外层 finally 仅执行 `src/commands/chat.ts:361-370` 的简化 finalizer，不会调用 `releaseDrainedSessionOwnership()`（仅见 `src/commands/chat.ts:1393`）。  
   **反例**：带 native contract 的 session resume 成功后，损坏对应 Goal JSON；CLI 失败退出但 session 留在新实例 `owned`。  
   **修法**：首个 durable ownership 写之前建立增量 owner population/finalizer；任何 bootstrap checkpoint 失败都排空已登记资源，再执行 fresh-authority 最终 CAS。新增 transition 成功、完整 finalizer 安装前失败的真实进程测试。

2. **已结算 native writer 错误仍会被 UI 吞掉后释放 ownership**  
   五个 host 都在 settle 后删除原 Promise，close 只快照当时 active：  
   `native-contract-host.ts:48,126-132`、`publication-host.ts:87-88,301-307`、`verification-host.ts:37,73-79`、`receiver-publication-host.ts:43,84-91`、`chat-goal-native.ts:49-63,79`。  
   交互调用又吞掉 rejection：`chat.ts:2737-2741,3979-3993`。例如 receiver 在 `freezeIngress()` 的 abort（`chat.ts:1363`）后先 reject、清除 active、被 UI rejection handler 消费；随后 `chat.ts:1376-1378` close 看不到它，最终 `chat.ts:1393` 仍 release。commit-then-error 同样成立。现有测试只覆盖“close 时仍 active”的 late rejection，没有覆盖“先 settle，再 close”。  
   **修法**：host 或 chat owner 保留 admitted 原 Promise 的未知 rejection，直到 finalizer 聚合；仅按各 host 私有 close reason 对象 identity 排除自身取消。补五类 settled-before-close 与真实进程 owned/no-release 回归。

ALS 命令生命周期、Goal lease、InputReader 原 Promise、Goal publication 旧 generation 错误、factory physical→compound、compound→agent、fresh authority CAS 顺序本轮未发现新反例。

前票日志未在工作树找到；原 docs symlink 被权限模式阻止，但已实读仓库内同内容镜像 `review-unfinished-closure-r22.md:150-243`。未运行测试，且此结论不代表父验收通过。

