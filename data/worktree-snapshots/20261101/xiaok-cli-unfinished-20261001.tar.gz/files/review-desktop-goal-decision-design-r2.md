# 自动 Goal 准备与原 sealed decision 的私有同源许可 R2

实际当前 service.withGoalDecision 在 group.commands 原 ready 判定后加 goalDecisions fence，GoalCoordinator.handlePersistedTaskEvent 的第二个原 action 调用 prepareGoalTask→service.prepareRoot，两处 assertWritable 无区别拒绝自身准备，冻结 goal_settlement_failed。原 attachment provenance/自动continuation tests 真实失败；不能移准备出锁、删除fence或允许所有ALS内mutation。

只新增 service 私有 AsyncLocalStorage<opaque object> + WeakMap 的原决策事实。ready action 前，在 fence 仍持有时用 service 初始化的同一 actual host.inspectTask(taskId,{trackPending:trackRecovery})，read wrapper和底层raw均纳现有强人口；不在 group.commands 内等待IO。仅原 snapshot executionScope=goal_turn、taskId/marker与原 rootBinding exact match、context.threadId与binding.threadId匹配才能创建 token。普通任务决策仍调用原 action，但无任何prepare许可。read失败走原freezeGroup，finally总释放decision fence，不授unknown成本/read资格。重复读的source/permission/boot/rootEpoch在再次入queue同步核，不能把旧snapshot的scope当新source凭证。

捕获 token 在 prepareRoot 方法入口（避免group.commands callback异步上下文丢失）；只该入口把opaque token显式传入 assertWritable 第三私有参数，其余兄弟spawn/followup/interrupt/send/reset/user mutation不传，始终拒绝 goal_decision_pending。token事实要求 live、service同一WeakMap身份、同一host/thread/group/boot/currentRootEpoch/rootBinding/permissionRevision，实际新 input.executionScope.kind=goal_turn 且 origin=continuation、goalId/epoch/threadId同原snapshot scope、新goalTurnId非空且不同前驱。普通/root手工输入、wronggoal/epoch/thread/origin、伪造object、不同host均拒绝。newGoalTask绑定实际在prepareRoot返回后由GoalCoordinator.bindTask写入，故不伪称该newgoalTurnId已有binding证明；权限来源是Main私有实际ready-action的single-use token，不是caller JSON。模型/preload/IPC均没有withGoalDecision入口或token。

许可仅原一次 prepareRoot。第一queue检查通过后记录reserved taskId为唯一使用；第二queue仍需要同一live token+reservedtaskId，原host.prepareTask/authorizePreparation、execution授权/revoke/newRootmarker/排队lease/compensation一律保留。另一并发prepare同token不得抢占或复用；action settle先live=false、WeakMap delete，再原finally queue移fence。泄露/逃逸未await callback、action结束后晚rawstore回调不能得到新admission；原第一次已写marker但第二check失败走原补偿，未知raw不能假done。

回归先跑现有 source/provenance、multi-agent-goal、revocation 原失败，原时限/真实Worker/门槛保。新增real service+host+store：在原decisionaction里自动Goalcontinuation恰好一次成功、ordinaryroot及wronggoal/epoch/thread/origin拒绝且无新hosttask/RootBinding；同action sibling mutation仍拒；一次票重复和action退出后escaped准备拒；hold actualhost.prepareTask期间revoke、原permission/defaultdeny补偿保持。不改GoalCoordinator/UI protocol、Goal授权、metadata、原99Intent/84paired/OS父分母。仅修sealed决策自身准备矛盾。

## R1 BLOCK 后收窄，取代上述所有 ready action 都 mint 的表述

withGoalDecision 新增第三个仅 Main 内部可调用的可选 continuationInput:TaskCreateInput。第一次 settlement action 不传该参数、完全不mint token/ALS权限；同步 publishGoalChanged listener 即使重入、scope字段匹配也只能命中原 goal_decision_pending。普通ready action和negative state也无token。仅 GoalCoordinator 第二次已选定 nextContinuation 的 action 前，private buildGoalTaskInput 生成实际新scope+prompt/context/materials原具体输入，将这一个对象传为第三参数并作为 prepareGoalTask 的私有最后可选参数原样交给现有 taskHost.prepareTask。传入第三参数不是renderer/tool/IPC API：该service现有 withGoalDecision也仅Main coordinator/测试调用，preload和model没有注册这个方法；不得靠JSON的purpose标识开门。

withGoalDecision 方法开始、第一次await之前，structuredClone并递归Object.freeze捕获 continuationInput 完整plain TaskCreateInput（含scope/context/taskIds/materials/prompt等），同时保存原对象identity。只有ready才读原hostsnapshot、在source/revision检查后把这个具体输入和opaque facts加入WeakMap/ALS。prepareRoot捕获ALS token，并要求 input===private原对象identity；scope来自private冻结完整副本，不能调用者输入字段匹配就放行。entry同步对输入进行拷贝核对是否deepEqual初始冻结副本；若第三参数原对象在mint前被修改则拒绝。prepareRoot传给host.prepareTask的是同一私有完整冻结副本，第一检查后的caller原对象变化不会影响持久化scope/参数。第二检查使用私有facts及同一actualreservation taskId，不能因为原对象恢复内容就掩盖已持久化wrongscope。

buildGoalTaskInput 是现有 prepareGoalTask 中纯scope/prompt/context构造提取，保原prompt/材料/context审计；纯 helper在第二action创建之前生成，原权限/active/pending/native/protected历史检查仍位于 prepareGoalTask actualadmission，preparedsource/store.bindTask/ack/attach/publish不移动。不是第一 settlement 事件决定完成以后临时建票。second action的listener回调即使继承ALS，没有这个private具体input对象不能创建新root；实际taskHost adapter看到同一input是在原唯一次准备调用时，first queue立即消耗token reservation，之后所有callbacks/重复调用拒绝。

原 negative action finally 不得删除别人的 later ready fence：仅本次state==='ready'才删除；ready action的token先live=false/delete，再释放自己的原fence。本轮同时新增反例，negative action hold期间children变ready、第二 ready decision hold，放行negative不能开放兄弟mutation。原ready set在原queue依然排他，嵌套ready原goal_decision_pending。

测试加第一settlement listener重入拒绝、第三参数原object变化拒绝、第一admission后修改原scope/context再恢复也只能持久化原副本、wrongobject identity即使字段deepEqual也拒、sameexactobject一次成功/duplicate拒、negative-action不得解其它ready锁。原source/permission/revoke/escaped检查与96项原验收（88通过8失败的实际red）全保，不调时限。
