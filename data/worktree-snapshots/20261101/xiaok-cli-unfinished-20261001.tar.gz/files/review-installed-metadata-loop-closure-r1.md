# Installed Loop source closure expansion

Current production installed-metadata-closure.ts keeps the full Loop mapper
stream, but treats every frame as unsupported-family. LoopStore's captured
producer already validates each source/schema/full historical row, all
run/stage relationships, result hashes, publication basis and embedded Task
snapshots. It does not yet join these rows to actual captured Session objects.

This change extends the same private four-original-object collector, with no
new public input, iterable, checker, authority or writable target. All original
events, cells, parsed JSON, references and existing gaps remain byte-for-byte
in mapper.events. Unknown full rows and unknown semantics remain unresolved.
No source inventory, capacity/migration/ready/retirement gate is weakened.

Define loop, loop_run and loop_stage nodes from original validated rows,
using their original id and sourceId. Exact same-source parent links only:
Loop -> all historical runs whose original loop_id matches;
Run -> all original stages whose run_id and loop_id match.
No Stage -> Run or Run -> Loop ownership edge: sibling runs/stages must not
feed the narrower entity. active_run_id does not replace historical population.
No source-wide session union feeds entity traversal. Unknown/missing or
ambiguous parent remains unresolved, never first-match or guessed prefix.

For each stage's original typed Task reference, join the actual unique Task
definition and its actual original Session identities, as the existing file
Task collector does. Other original references are retained as declaration-only
and unresolved until their fixed semantic family is expanded; do not guess an
ownership edge from arbitrary JSON or path prefixes. Loop result rows with
validated embedded Tasks attach exact same-source/run/stage; consume the full
production Task declaration in an independent embedded-task node, not another
global Task definition that would shadow or duplicate the actual FileTask.
The embedded node joins actual unique Session definitions, retains Task/Goal
parent attachments as declaration-only, and keeps completion observations and
every existing mapper gap unresolved. Stage metadata must agree with the full
validated embedded snapshot (the original Loop producer already enforces it).

Other Loop tables/rows keep their full original stream frame and a concrete
unsupported-loop-record gap per original source/table/rowid. Transport/table
start/end/complete frames are enumeration, not new business entity or grants.
Zero-row sources still have the original source output. Native ownerKind loop
can resolve the exact unique Loop entity; loop_stage/loop_run use exact original
names. Unknown/ambiguous owner or no real Session remains unresolved. All
native profiles/enrollment rows and legacy-inventory-required still retained.

Tests use original LoopStore, CompletionEvidenceStore, both scanners and owner
group constructors with actual SQLite schemas, full native capture/import,
original broker and mapper plus the existing installed lifetime/IPC fixture.
Create two independent original runs/stages attached to FileTask A/B and actual
Session A/B; assert Loop union A/B, Run A only A, Stage A only A, and physical
source A/B. Preserve paused/history/empty Loop and unknown scanner/completion
rows, duplicate Task ambiguity and original fixture brand/final-CHECK tests.
Use genuine original producer result snapshots for embedded Task coverage;
never seed an invalid publication or fake a checker/iterator/complete event.

The parent remains the complete original unfinished-development scope:
all other families/rows, actual installed target/four MainStore semantic
proxies, full closedU/native explicit retirement/absence fsync/atomic ready,
all workflows/capacity/material/artifact/package gates, original 99 Intent
15s/300s/1h, new 84 paired after functionality, final same-SHA reviews,
CLI full/Hook/IntlDoctor, OS/UI/TTY/install/download/integration/GH/release.


## R2 accepted adversarial counterexamples
R1 BLOCK preserved. Add two sibling stages A/B inside the SAME run, plus a
historical run with A and an empty current run, so Stage A must exclude B while
the exact parent run includes both. A second actual SQLite source is copied
from the original closed production database, retains all SAME loop/run/stage
IDs, and is edited using production updateLoopStageMetadata to attach its
stages only to B. Per-source nodes/links must stay separate even with every
ID collision. Native Loop with duplicate physical definitions stays ambiguous.
Add a second actual FileSessionStore containing the same Session A identity;
all A joins (including embedded snapshots) stay ambiguous, B remains valid.
Use actual FileTaskSnapshotStore.recoverTask(A) as input to production
LoopPublicationProducer.recordTemplateExecution with genuine configuration,
basis and full result snapshot. Assert exactly one global file task A, a
separate loop-embedded-task retaining the full declaration/completion original,
and no added global Task definition. Stage attachment resolves the embedded
snapshot's exact original Session, without other sibling or source leakage.

R3: R2 BLOCK incorrect load API accepted. Exact actual recoverTask(A) production entry used; original FileTask save stores timestamps 4/5 for embedded fixture, raw recovered snapshot is passed unchanged to production recordTemplateExecution (run starts 3, stage starts 4, result 6). No test snapshot timestamp patch or fabricated producer body.
