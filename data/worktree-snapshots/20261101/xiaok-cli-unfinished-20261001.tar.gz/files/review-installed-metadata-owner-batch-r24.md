# R24 fresh owner batch validation at existing metadata checkpoints

The unchanged 5000ms growth gates failed at 6808/6574/5983ms in R20.
R16 actual V8 evidence attributes most worker time to native rows/prepare/
record/canonical generation. The ledger repeatedly rereads the identical
complete Source census for each physical and beneficiary handle. Current
attributeInTransaction validates the physical+beneficiary pair before and
after each INSERT; metadata admission/final checks also loop all handles.
These checkpoints and original population cannot be dropped.

Propose an explicit fresh batch read, never a cross-call facts cache. Source
batch captures a bounded ordinary dense array without invoking accessors,
Proxy or custom iterator, verifies every exact private owner WeakMap brand,
database and authority, then reads inventory once per actual Source object
and compares every handle's issued censusHash against its Source's fresh
full census. Preserve order and duplicates; return only existing identities.
No caller source facts, epoch/stamp substitutes, grant or partial census.
One snapshot covers the batch, including the caller's original write
transaction. Separate Source instances must each be inventoried freshly.

Shared capacity batch validates its exact authority and all existing bound
handles. Retain the actual authority-current validation for every handle
before reading fresh grouped native sources, validate database/authority as
in the scalar reader. Known shared bindings keep their existing identity
mapping; all missing bindings must be genuine native owner brands. Empty,
copied, Proxy/accessor/extra-key inputs follow explicit default-deny rules.

Ledger adds only a private ownersCurrent helper, captures its own token list,
checks each token's existing private ledger brand and lifetime/current ports,
calls the fresh shared batch reader, checks each returned identity against
the original binding, then uses original immutable identity references.
Use it for physical+beneficiary admission/post-INSERT and complete metadata
entry admission/final loops. Preserve every INSERT boundary, native current
callback, full Source census, original quota/schema/population assertions,
trigger checks and rollback. Scalar APIs and generic non-metadata methods
continue working; no new public ledger method or command protocol.

Tests first through production entry: scalar/batch byte-identical identities;
copy/foreign authority/foreign db/closed source rejects; repeated batch sees
INT64/BLOB/unknown raw-column changes and invalidates all old handles; two
Source instances grouped separately; hostile input never executes getters;
actual shared+ledger path, malicious lifetime callback on second owner and
mutation in real attribution INSERT trigger roll back; preserve all existing
metadata mutation/replacement/lease/quota gates and full 20-session growth
fixtures. Observe actual production inventory calls at checkpoints via spy,
not a reimplemented hash/oracle.

Measure original full growth gates sequentially without competing heavy jobs.
Require at least 5% actual end-to-end improvement and original 5000ms gates;
revert candidate if no benefit. Freeze same input for strict/Main/governance
and independent code review. All parent target/OS/Intent/Intl/release gates
remain independent. Namespace R23 fix is security work and remains even if
this candidate is rejected.

## R25 callback mutation across Source groups and after the last census

R24 component106/106, original growth gates3254/2984/2725ms (baseline
6529/6308/6358ms), legacy1226ms. No threshold or population changed.
Self-review identified that one SQLite snapshot still permits own connection
mutations by trusted fixture lifecycle callbacks. Two actual port regressions
now expose accepting different census epochs across Source groups, and a
last lifetime callback mutation after its native census. Real installed
lifetime.current is file/lock/key checks only, but the explicit batch boundary
must still reject these qualified test-port mutations.

Add a local before/after main.schema_version and exact BigInt total_changes
stamp around the whole fresh Source batch, including all lifetime callbacks.
Compare before returning any identities; on change throw existing
metadata_owner_census_changed. Keep every full per-Source inventory, no facts
cache or using a stamp instead of census. total_changes retains rolled-back
DML, schema_version tracks committed DDL; rollback-only DDL restoring the
same state is harmless, and raw writable_schema UPDATE changes total_changes.
Normal real lifetime has no SQLite writes; original ledger writes happen
outside each batch guard. Before SQL, validate all handle brands/database.
Tests assert real callback fired at the expected second/third check, not a
clock never reached by the entry. Re-run full suites and original5s gates.

## R26 full callback-free closing census, not stamp-only assurance

R25 design BLOCK correctly identified transactional DDL across lifecycle
callbacks: schema_version restored, no total_changes increment, while a
Source inventory was captured under temporary schema. Added two real tests:
mixed issued epochs and BOTH owners issued under the same temporary schema,
replaying SAVEPOINT/ALTER/ROLLBACK in actual Source current callbacks. Merely
requiring equal issued hashes would not close the second case.

Correction: retain all fresh per-Source inventories (including full native
population), then after every Source current callback returns, read one
additional readNativeEnrollmentCensus on this actual original connection
and transaction. This closing read has no Source/lifetime/authority callback.
Compare each captured complete population against the complete closing
population with isDeepStrictEqual; independently compare every issued hash.
Keep the whole-batch exact total_changes/main.schema_version guard to reject
rolled-back DML and final callback writes too; it never replaces the closing
census. No callback executes after closing capture or before result return.
All master rows/SQL/xinfo/ordered original cell tags remain compared; no
semantic fields or native facts omitted. Standard native driver SQL has no
caller projection/functions, native table gates reject views/virtual tables.
The batch validates private brands/database before touching connection SQL.
No new external authority, no cross-call cache. One extra full native census
may cost performance, so keep original 5000ms and >=5% acceptance, revert
candidate if it fails. Scalar APIs remain existing unchanged paths; this is
the new batch boundary guarantee. Two DML and two DDL tests must go green,
then full regression/typecheck/Main and independent code review.

## R27 actual virtual producer kinds

R26 review BLOCK correctly found type=table alone admits virtual tables.
Add a fixed internal Set of inventoryTables and scopedQueries.table. New
readonly assertNativeSqliteProducerTableKinds reads real PRAGMA main.table_list
and rejects any present fixed producer whose actual kind is not table
(including virtual/shadow). Unknown extra main schemas stay fully retained
in masterCells but never queried as producer data. Invoke this before any
index-list/xinfo/data query in createContext. Preserve existing absent,
corrupt-name, UTF/INTEGER/schema/anchor checks; no facts cached across calls.

Also invoke this same guard at the beginning of assertStorageOwnerSchema
(Source.current calls this before all semantic metadata reads), registry
profile() before identity query, and assertKSwarmSqlIntegrity before receipt
reads. These original Source/identity/KSwarm siblings otherwise read virtual
producer rows before their later Native census rejection. Retain every
existing namespace/trigger/writable_schema gate and original callbacks.
Native installed lifetime itself is readonly file/lock/key validation.

Five new real better-sqlite3 module cases: requests/profile/subject fixed
census, actual Source virtual profiles, and installed KSwarm snapshot plus
resolveOwnerKey/capacity/openOwner/completion.inspect virtual receipts. They
register genuine row generators and assert zero row callback executions,
not just an error after executing caller rows. Test uses local installed
driver's actual .table factory API, and verifies actual table_list kind.
This is security motivated, but full 5s and performance acceptance remain.
After approved guard, implement R26 callback-free closing whole census and
whole-batch stamp (R25 stamp alone was rejected, never implemented).

## R28 eponymous modules and generated producer columns

R27 review BLOCK identified eponymous-only module fallback when main table
is absent, generated-column function callbacks, and ASCII-case matching.
Extend fixed producer kind guard to real PRAGMA module_list: reject any
registered module with an ASCII-insensitive fixed producer name, even if a
main table also exists. Compare table_list names with SQLite ASCII folding
(replace A-Z only), reject virtual/shadow types before data.

Reject all hidden/generated producer columns before SELECT data: Native
census already captures full tagged xinfo metadata; require each hidden=0
before projecting original rows. Unknown plain stored columns remain fully
retained. Source inventory moves its existing whole enrollmentPopulation
capture before semantic queries (same original deferred transaction), so
generated fields in required tables are rejected before semantic reads.
StorageOwnerSchema checks its real PRAGMA main.table_xinfo(feature table)
before feature reads. Profile registry checks real PRAGMA main.table_xinfo
for its profiles/registered owners/invocations before identity reads.
KSwarm integrity checks real xinfo of its nine original scoped tables before
receipt/identity semantic reads. These PRAGMA forms do not select generated
values. Missing optional tables stay absent, and module guard closes their
eponymous fallback. Existing native xinfo/tag/cells/schema/anchor population
is retained unchanged for normal stored tables.

New actual regressions cover native generated column callback, actual
registry lower/uppercase eponymous profile module, uppercase virtual profiles,
and generated uid function. Reset counters after schema seeding and require
zero callbacks during actual reads, not just a late schema error. All R27
virtual data, R26 DDL and R25 DML regressions remain. Real installed main
connection has no caller module/function registration API; the closing
read has no Source/lifetime/authority callbacks and no computed producer
data. This does not claim arbitrary caller-owned SQLite connections cannot
override SQLite functions or pragma modules; such pure helper frames issue
no Source/capacity authority. Full scope still requires Native source brands.
R26 final full population compare/stamps and original performance gates stay.
