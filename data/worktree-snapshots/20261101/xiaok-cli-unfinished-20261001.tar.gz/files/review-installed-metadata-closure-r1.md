# 固定 installed 捕获 + 原 native census 闭包收集入口

落实2026-09-27 installed-metadata-closure父设计的首组Session/Task/Goal完整事实join。实际当前无collectInstalledMetadataClosure，mapper只对 supplied capture枚举，local捕获与callerSessionDTO不能假installed来源。现真实installed read/check、native固定census getter、原逐Goal关系已具备；本实现接这些固定production入口，接完仍继续真实target/fourMain/native审批/完整其它families与所有父验收，不把首组作为全迁移ready。

collectInstalledMetadataClosure(lifetime,captureOwner,token,nativeSourceHandle) exactly4原opaque，禁止自由iterable/checker/sessionDTO/callback。入口先固定installed capture品牌及nativefacts品牌，再原异步installedCHECK。原review authority/profile/uid/account必须与native authority及至少原native profile行一致；无native owner的profile需要原getter返回完整profile事实以便准确验证，不能因emptyowner滤掉profile。因此本片同时只读扩展native getter profiles真实全部已校验profile，不造新owner。原全部ownerSessions包含其它profile也保留，其capture缺失输出profile-not-captured，不能当完整global。

消费唯一实际iterateCapturedProfileDeclarations到底，完整family-fact/relations/gaps/原最后complete均原样保，sourcevector/hash/digest核原review全部sources，零行来源也输出。每个await前后核原installed binding object/native authority/physicalIdentity/writerGeneration/censusHash完整一致，任何关闭/throw/最后CHECK/iterator收尾失败没有结果。不重新capture、不延原deadline；同步read不冒新asyncCHECK，后续target仍须另排空和原native审批。

返回opaque frozen handle，私有WeakMap持原lifetime/capture owner/token/native source/完整冻结facts；readInstalledMetadataClosure(lifetime,handle)与checkInstalledMetadataClosure(lifetime,handle) exactly2opaque，严格identity/current原getter，后者实际await原installedCHECK前后核，copy/Proxy/extra callback拒且getter0。无ready/writer/nativeowner/cap/proof升级，原metadata prepare/commit仍defaultdeny。

事实join首组Session/File或SQLite的实际present stored identity单实体，物理键(sourceId,family,recordKind,originalRecordKey)，logicalcontainer/thread不能升AgentSession；相同id多个物理定义为ambiguous不取第一条，所有legacy null/absent及原external/nativeunknown/gaps保。Task逐taskId实体只读取原完整历史sessionIdentities，真实sidecar只凭原(taskSourceId,taskIds,sessionSourceId,sessionIdentity) exact facts，active alias原exact holderSource+holderId+canonicalSource+target记录另保存并可定位，不能由TaskRoot并集给单Task。Goal使用每个原goalAssociations.goalId completionTasks/evidenceOwners依赖，cycles visited；SQL taskBindings须完整capturedGoalTaskKey双向原Task executionScope同tuple实体唯一才连接，不凭taskId/thread匹配；contextTask明确是context依赖。未展开Loop/Groups/Codex/Artifact/KSwarm/Intent及nativeGoals等原事实保留明确unsupported-family/entity unresolved。原所有mappergap不通配删除，包括uri/metadata/legacyInventoryRequired。每source物理beneficiary为其实体确证session并集（包含A/B），只物理费用使用；不得用于外部某Goal选择单Task。每个nativeowner完整原row另保存，只同reviewprofile nativeowner与唯一captured实体精确匹配；原native显式session逐真实Session核保全，空原session仍unknown除非完整原实体关系给出已确认session，所有otherprofile缺捕获保unresolved。

实际回归在既有installed capture fixture上用真实FileTask A/B、FileSession A/B、历史Goal A/新Goal B与原SQLitecontrollerreceipt/fullnative census。serviceUID/IPC/approval/lifetime fixture明确不授OS，其nativehelpers、brokerregistry、固定importer/mapper/stores/SQLite皆真实。先missingentry真正红：Goal A仅A session，而物理TaskRoot包含A/B；全source及零行/所有原gaps保；local与copy/Proxy/extra args拒；nativecensus新增原receipt导致oldhandle过期；收集途中真实census变动/最后CHECK失败无结果；duplicate实体/session ambiguity/nativeempty/foreignprofile保unresolved；原readonly事实不改真实文件、不授capacity brand。独立原slot遗漏使完整collector拒。相关source/captured/native tests、strict/Main、同SHA代码审。先设计审，再tests，再production；原父完整分母保。

## R2 原 empty profile census 完整性

R1真实BLOCK：原inventorySnapshot仅hash(records)，无owner的profiles未进入records；全部profile扩展后该hash不锁empty profile。改原唯一inventorySnapshot的censusHash为hash({profiles,records})，profiles是本snapshot已原全部严格验证的完整canonicalSELECT(uid/account/profile/state)人口。返回profiles只读uid/accountId/profileId/stateactive，原所有getterABI字段保持，只新固定factsgetter新增profiles。其它getter原beneficiaryCensusHash也用同一个hash，实际metadatacapacity确认检查继承完整census，不能留下旧getter兄弟绕过。空profile增加/删除/账号或profile identity变更均改变原hash；损坏/非active/duplicate依原校验拒。原20session/foreignprofiles/fullcapacity/nativecomplete旧分母保。新增真实emptyprofile四种变动和ownerlessprofile输出断言、收集中实际emptyprofile变动拒/oldhandleread/check过期。

父设计read权限受docs外部symlink限制，因此此处完整复制供只读review，原文SHA256=e3722ca98140d6688a5b509d85a14b7c528a1c82564035e65e2a5722eb757951:

# Captured + native metadata closure — r1 draft

限定目标：唯一纯事实 join，将完整已捕获物理来源、原 typed 实体关系与实际 controller native owner/session census 对账。它不签发 writer、迁移、额度或完整 legacy 资格。P2 持有本模块；P3 目标 import/retirement/target writer 只消费此唯一结果。Root 仍持 controller source 原私有品牌与生命周期。

## 原事实和接口

拟 `collectInstalledMetadataClosure(captureOwner, token, nativeSourceHandle)`，三个参数均是现有 opaque 实例。内部唯一消费 `iterateCapturedProfileDeclarations`，禁止自由 fact iterable / checker / sessionIds DTO。前后原 capture CHECK；native source 只通过原 WeakMap 读取 actual inventory，并且首尾原 census hash、physical writer identity/generation 不变。任何错误、iterator.return 或关闭失败都无结果，不把 enumerationComplete 当完整归属。

需要原 installed-metadata-source 新增只读 `readInstalledMetadataSessionFacts(handle)`：从已有 source WeakMap 取 actual DB/authority，调用现 inventory/current；不接受裸 database、authorityId 重复参数或调用者提供列表。保留旧 getter ABI。这个 getter 仍只提供事实、不产生 owner/cap。由该文件当前持有者精确实现。

输出原 captured sourceId/snapshotHash 向量、mapper digest、native census identity/hash、按实体定位的 session 归属和逐项 unresolved。实体键为固定 `(sourceId, family, recordKind, originalRecordKey)`；`origin.path` 只作可定位证据，不允许用字符串前缀推所有权或把整个 source 当单一实体。每一个 full source 必须有输出，即使零业务行。session 定义仍要求 original Session producer 的实际身份；logical Goal container、threadId、Codex thread、Task UI session 等不能不经原 Session 定义核验自动升为 AgentSession。

## 第一组可闭合实体与精确边

1. Session（File/SQLite）：每一个原 `containerSessionId` 的独立实体；实际 stored identity=present 并且对应来源/物理 namespace 唯一。实际 lineage/fork 是显式引用边；缺失/重复不猜一条。session source 物理 beneficiary 是其中全部已确认 session 的并集，不把这个 source 并集用于外部某一个 Task/Goal 关系。
2. Task：每个原 `readCapturedTaskDeclarations.taskId` 单独建实体，完整 checkpoint/journal 历史 `sessionIdentities` 分别解析到 Session 定义；真实观察 sidecar 的 `(taskSourceId, taskIds, sessionSourceId, sessionIdentity)` 和 active canonical alias 的 exact physical facts另保留。UI Task session 与 canonical AgentSession 不相等是合法事实，不能强等也不能选择一个并丢其余历史。
3. Goal：每个实际 goalId 独立实体，logical container另域。SQLite 原 taskBindings 使用整个 `(taskId, kind=goal_turn, origin, goalId, epoch, goalTurnId, threadId)` 和真实 Task executionScopeDeclarations 双向对账，不能只凭 taskId 或同 thread。File Goal 仅有原 declaredTaskIds 时保留它的真实 typed 关系；不能凭它伪造 SQLite binding。原 context/历史引用按真实字段语义分别列举，不将同 TaskRoot 其他 task 的 session 混入。
4. Native owner facts：只原 source inventory 给出的 `(uid, accountId, profileId, ownerKind, ownerId, sessionIdentities)`；与上述唯一实体匹配并核各 session definition/真实物理 alias。原明确 native session 仍保留其身份，不要求其必在某任意目录存在；是否需要捕获实体以及完整迁移资格由显式 unresolved说明。空 native sessions 不等于空 owner。重复实体、账号/代际/来源不一致不取第一条。

其它 Loop、Groups、Codex、Artifact、KSwarm、Intent、material/evidence/native refs 仍按固定原 family producer schema 增量展开；未展开的原事实必须保留、输出具体 unresolved，不能用新标签假定全闭合。本轮不是这些关系全完成票。已确认边形成有限图，遍历用 visited，cycles不无限递归；typed key 索引仍随人口增长，未声明常量 RAM 或完整预算资格。

## 独立覆盖与不省略

- 消费完整 mapper 的全部 family-fact/relations/gaps/最后 complete；按原 sourceId/snapshotHash 对账一次，不因 family aggregate 漏/重复。
- 记录每个归属决策使用的 exact original fact/slot；未知字段和未处理 origin不得消失。不能仅以 namespace=session 的所有事件作为归属来源。
- mapper现通用 unsupported-semantic 只有在本固定 join 确实按原生产schema完整解析其 exact origin时才可被精确解决；无通配忽略。原外部 authority gap不因普通 JSON 同名而解决。
- `legacyInventoryRequired:true` 表示历史任意自定义 root仍未知；原 native CHECK仅证明传入完整set持有，不证明未列旧namespace不存在。此 gap始终保留，直到另一原协议真正给出完整历史来源事实；用户点击“完整”无此证明力。
- 新 service profile 是另一个从首笔登记/预算受控的固定 namespace 生命周期，不能借它隐藏旧用户历史。此 join 不创建新 profile、不迁移、不清 unknown。
- 无旧 Loop export journal 或 candidate-backed 完整输入可正常消费。原 journal可记录从未存在的 candidate且不含session，这类输入保持 unknown。原 clearLoopRunHistory 并不会级联删有candidate的历史：真实外键拒绝，原数据不丢；已保存这次错误推断和实测更正。

## 真实验证（实施前需有限独立审）

- 同一 TaskRoot 中真实 producer写入 A/B，Goal仅绑定 A；得到 A 对应 session，不混入 B，物理 TaskRoot的全量 beneficiary仍包含二者。
- 真实多历史 snapshot/journal/sidecar/activealias，Task UI session不同canonical；保留准确历史session与来源；复制/冲突 alias不得借最新source覆盖。
- 完整 goal-turn tuple任意 origin/epoch/task/turn/thread差异不闭合，重复Task定义ambiguity不取首。
- 真实 native source inventory owner→session，复制handle/foreign账号/原census变化/await时close拒；禁止 caller sessions替代。
- 全原source vector一次覆盖；early return/inner close失败/末CHECK失败无结果；完整 source有零行也由实际capture给出，不收空getter。
- 未登记legacy、原无candidate export、外部authority缺事实保持unresolved；有完整原关联的正常输入与上述未知输入分开验收。


## R3 原 enrollment 全人口及 pending/orphan 不省略

最终代码审 R1 真正 BLOCK：失败 enrollment 会在注册 owner 前提交 owner_enrollment_intents 的 committed=0 原 intent（owner-enrollment-authority.ts:632-638）；原 census 只 SELECT 注册 owner 对应 intent 的 registration_json/committed，孤立 intent 及原 loop_subject_json/intent_contract_json 不在 hash。不能把合法失败审计行删除或永远当 native owner；本轮补完整原人口，不修改 enrollment 生命周期。

唯一 inventorySnapshot 另外读取 required 六表的 SELECT * 全实际行（含每列）与原 authorizer 可存在的固定 optional 四原 subject/feature 表、owner_enrollment_challenges/requests 全实际行。表名为本模块固定白名单，无 caller SQL/列/过滤。每表按原 canonical row 完整字节排序，保 schema sqlite_master 与列定义事实，完整 row population 纳入 censusHash，与 profiles/原全部已验 records 一起 hash。不将 shared_capacity 或本 target prepare/replacement 表引入 native enrollment census，避免与合法自身容量操作成循环。

每一实际 owner_enrollment_intents 行若不对应原已注册 owner 的 exact logical tuple，作为 unresolvedEnrollment 原完整 raw row 保存在固定 opaque reader facts；registered 原 committed/receipt/schema/UID/account 校验不弱化。未注册 pending/failed/orphan 都只能产生 native-enrollment-unresolved，不 mint owner/session/cap，不把其空 session 当 empty owner 已解决。现有 old getter 仍 ABI 字段保且共用完整新 hash，兄弟路径都锁住全人口。孤立 intent 新增/修改/删除、committed 字段和 optional subject/contract/json 任一变化即过期，损坏 JSON/非法业务 data不升资格。实际 SQL6表 schema及原storage-owner seal始终校验，输出保 raw rows 不通过它们推授权。

回归先在真实 native SQLite新增有合法registration的 committed=0 未注册 intent，断言同一原Source所有getter hash 改变但既有 ownerSessions 不变、固定 facts 返回完整 unresolvedEnrollment；插入/删/修改 payload/commit/新增subject列值/optional subject表原行都验证原 census 变；固定collector 在实际mapper期间增加此真实 row必须拒，已收集原handle必须过期，重新收集事实必须明确该unresolved。不用扔掉失败审计行/假成功registered owner；包含原186容量及46 collector sibling不裁。仅这片全 native session census事实，不授全metadata pager drain/target/fulllegacy/fourMain/OS。
