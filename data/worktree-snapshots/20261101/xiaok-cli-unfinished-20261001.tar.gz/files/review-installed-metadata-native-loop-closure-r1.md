# Original native Loop subject to captured historical node

Observed: loopHostSubjectOwner maps run/stage to ownerKind=loop and a hashed
ownerId. The current collector instead searches ordinary Loop definition ids;
the real run/stage owner never joins. The hash omits loopId and stageKind, so
hash-only aliases or raw-id fallbacks would be wrong. This is a read-only fact
join, not enrollment authorization, closedU, capacity ownership or migration.

Expose the complete original enrollmentPopulation already read and hashed by
inventorySnapshot in readInstalledMetadataSessionFacts, from that same SQLite
snapshot, recursively frozen. Keep both original legacy getters unchanged and
all complete census/current/await checks. Original schema/columns/all rows of
fixed optional tables (including absent and empty) must remain lossless.

Native Loop lookup uses exact original logical key (uid/account generation/
kind/id) and exact owner key (profile/kind/id), unique receipt and unique intent,
committed=1, receipt.subject_json===intent.loop_subject_json, canonical parsed
LoopHostSubject and original shared owner mapping exactly matching the owner.
Registration must obey original extendsRegistration(receipt,current) contract:
same migrationEpoch/source and ordered prefix obligations, allowing a receipt
from an earlier committed append. Invalid/missing/duplicate/foreign data is a
specific unresolved gap retaining its original rows, never inferred approval.
Existing ordinary invocation enrollment without a subject remains unresolved
for the graph; its independent real Session identities are retained unchanged.

Private canonical whole-subject index is derived only from original decoded
Loop rows AFTER unique exact same-source parent validation. Run must have one
original Loop parent; Stage must have one original Run parent with same loopId
and that Run itself must have one original Loop parent. Full loopId/runId/stage
id/stageKind must match. No entity duplication, guessed prefixes or global raw
id aliases. Same subject from two physical sources is ambiguous. Historical
Run still aggregates its forward stages; Stage never inherits siblings.

Regression fixtures use actual LoopStore/scanners/CompletionEvidenceStore,
actual FileTask/Session Stores, native capture helpers, registry, importer and
mapper. Native lifetime/IPC/enrollment SQL are explicit component fixtures,
not OS approved native enrollment. Positive Run A, sibling Run AB, Stage A/B,
empty Run, historical append receipt; negatives missing/foreign receipt,
intent/subject mismatch, wrong loopId or stageKind with SAME mapped owner,
duplicate physical source and duplicate Session/Task. Assert original getter
population against pre-read independent SQLite rows/schema/columns, immutability,
and complete census rejection after receipt mutation at mapper/final CHECK.
First write regressions and observe actual missing joins/population before code.

All original parent requirements remain: other families/all rows/full closedU,
installed target/four MainStore semantic proxies, actual native explicit
retirement/drain/absence fsync/charged atomic ready, full workflows/capacities,
99 Intent original time/body limits, new 84 paired after functionality, final
same-SHA reviews, CLI full/Hook/IntlDoctor, OS/UI/TTY/install/download/integration/
GitHub/release. Never treat this component leaf as completion of the parent.


## R2: accepted real R1 BLOCK; original review preserved
Add wrong runId with the same hashed Stage owner, duplicate receipt population,
and duplicate intent rejection by the original inventory uniqueness guard.
Registration-prefix test explicitly uses receipt [A,B], current [B,A,C], all
otherwise valid original definitions: unordered membership must not pass.
Fix the existing native validateReceipt membership check in the shared inventory
to the ORIGINAL ordered prefix contract, with Invocation and Goal receipts
each tested for valid append and invalid reorder across all legacy getters and
the fixed native facts getter. Owner getter also must refuse the changed receipt
using a previously issued actual original beneficiary. No sibling can bypass
the same census function, no authorization/write/registration rules are relaxed.

R1 red fixture error retained: six owners reused one identical registered invocation tuple, violating the actual global profile/invocation uniqueness. R2 uses distinct original compound operation identities per native owner; original old fixture tuples unchanged. R1 invocation-only metadata_source_duplicate is NOT semantic red evidence. No production edit yet.


## Final R1 code evidence
Design R1 BLOCK retained; R2 original design APPROVE. Red R1 native invocation
fixture uniqueness failure retained and excluded from semantic evidence. Red
R2 after that fixture repair: 112 total, 91 passed, 21 AssertionError failures,
zero pending, including actual missing native Run/Stage sessions, native receipt
gap absence, original census population absence, and Invocation/Goal unordered
registration prefixes accepted by all original getters. Production followed.

Source/capture complete files 112/112/0pending; original mapper families,
Loop producers/query schema, native enrollment/review/host subject, metadata
attribution/integration/shared ledger brothers 479/479/0pending. Strict root
tsc and Desktop Main build exit 0. Actual Qoder code review APPROVE, 13 source
and regression file SHA frozen before/after, source unchanged throughout review.
Full original census now returned from the exact already-hashed snapshot,
all schema/columns/rows/absent/empty tables retained and recursively frozen.
Native Loop requires complete original receipt/intent/profile/account/logical
owner plus canonical subject and ordered historical registration prefix. Its
private whole-subject index requires every original same-source parent; exact
Stage only its own Task Session, historical Run forward siblings, double
physical sources ambiguous. Existing independent invocation Sessions retained.
Legacy Invocation/Goal receipts use the same original ordered prefix gate in
every inventory-based getter. No legacy ABI, source CHECK/mapper finalization,
unsupported facts/gaps, capacity, owner approval or migration gate is relaxed.

Evidence remains component-level: lifetime/IPC/native enrollment SQL are fixture;
original ordinary Stores, SQLite/native capture/broker/importer/mapper are real.
No OS installed/native enrollment approval/full closedU qualification is claimed.
All originally listed parent requirements remain outstanding until separately
implemented and verified; this is only the readonly original native Loop join.
