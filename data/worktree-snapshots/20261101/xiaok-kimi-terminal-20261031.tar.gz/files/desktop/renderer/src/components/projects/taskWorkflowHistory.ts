import type { KSwarmTask, KSwarmWorkflowRun } from '../../hooks/useKSwarmClient';

// Display-only counterpart of KSwarm's read-model predicate. Never change a
// run verdict or infer approval from task completion alone.
export function isHistoricalTaskWorkflowRun({ projectId, tasks, workflowRun: run, now = Date.now() }: {
  projectId: string;
  tasks: KSwarmTask[];
  workflowRun: KSwarmWorkflowRun | null | undefined;
  now?: number;
}): boolean {
  if (!projectId || run?.projectId !== projectId || run?.scope?.projectId !== projectId
    || run?.source !== 'po_generated' || run?.workflowId !== 'po-generated-task-workflow'
    || !['completed', 'blocked', 'failed', 'cancelled'].includes(run?.status)) return false;
  const id = run.scope.taskId;
  if (typeof id !== 'string' || !id.startsWith(`${projectId}__`)) return false;
  const matches = tasks.filter(task => task.id === id);
  if (matches.length !== 1) return false;
  const task = matches[0];
  if (task.projectId !== projectId || task.status !== 'done' || task.reviewResult?.passed !== true) return false;
  const validTime = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value > 0;
  const reviewedAt = task.reviewResult.reviewedAt;
  if (!validTime(now) || !validTime(reviewedAt) || reviewedAt > now
    || !validTime(run.createdAt) || !validTime(run.updatedAt)) return false;
  const times = [run.createdAt, run.updatedAt, run.startedAt, run.completedAt, run.cancelledAt,
    ...(Array.isArray(run.nodes) ? run.nodes.flatMap(node => [node.startedAt, node.completedAt, (node as { updatedAt?: unknown }).updatedAt]) : [])]
    .filter(value => value !== undefined && value !== null);
  return times.every(value => validTime(value) && value < reviewedAt);
}
