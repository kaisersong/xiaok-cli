import { afterEach, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { KanbanBoard } from '../../renderer/src/components/projects/KanbanBoard';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';
import { findWorkflowRunForTask } from '../../renderer/src/components/projects/workflowUtils';
import { buildDagFromProject } from '../../renderer/src/components/projects/dagGraphModel';

vi.mock('../../renderer/src/contexts/KSwarmContext', () => ({ useKSwarm: () => ({ agents: [], cancelTask: vi.fn(), markTaskDone: vi.fn(), humanAddTasks: vi.fn() }) }));
vi.mock('../../renderer/src/components/projects/TaskDetailDrawer', () => ({ TaskDetailDrawer: ({ workflowRun }: any) => <div data-testid="raw-history">{workflowRun?.status}:{workflowRun?.gateDecision?.status}</div> }));
afterEach(cleanup);

function fixture() {
  const task = { id: 'fixture__item-1', projectId: 'fixture', title: 'Accepted fixture', status: 'done', reviewResult: { passed: true, reviewedAt: 2000 }, execution: { strategy: 'workflow', workflowRunId: 'old' } };
  const run = { id: 'old', projectId: 'fixture', workflowId: 'po-generated-task-workflow', source: 'po_generated', scope: { projectId: 'fixture', taskId: task.id }, status: 'blocked', createdAt: 900, updatedAt: 1200,
    nodes: [{ id: 'reviewer', status: 'blocked', startedAt: 1100, completedAt: 1200 }], phases: [], gateDecision: { status: 'needs_rework' },
    summary: { total: 3, completed: 1, failed: 1, blocked: 1, running: 0, primaryMessage: 'Old attempt failure' } };
  return { task, run };
}
function board(tasks: any[], runs: any[]) {
  return render(<LocaleProvider><KanbanBoard project={{ id: 'fixture', name: 'Fixture', status: 'active', tasks } as any} workflowRuns={runs} /></LocaleProvider>);
}

it('three accepted cards show completion while their raw failed attempts remain in the drawer', () => {
  const f=fixture(), tasks=Array.from({length:3},(_,i)=>({...f.task,id:`fixture__item-${i+1}`,title:`Accepted ${i+1}`,execution:{...f.task.execution,workflowRunId:`old-${i}`}}));
  const runs=tasks.map((t,i)=>({...f.run,id:`old-${i}`,scope:{projectId:'fixture',taskId:t.id}}));
  board(tasks,runs);
  expect(within(screen.getByTestId('kanban-column-done')).getAllByRole('button')).toHaveLength(3);
  expect(screen.queryByText('Old attempt failure')).not.toBeInTheDocument();
  fireEvent.click(screen.getByText('Accepted 1'));
  expect(screen.getByTestId('raw-history')).toHaveTextContent('blocked:needs_rework');
});

it.each(['failed review','early review','future review','foreign task','invalid run time','running run','raw script','project wide'])('keeps pipeline visible for %s', kind => {
  const {task,run}=fixture();
  if(kind==='failed review')task.reviewResult.passed=false;
  if(kind==='early review')task.reviewResult.reviewedAt=1000;
  if(kind==='future review')task.reviewResult.reviewedAt=Date.now()+60000;
  if(kind==='foreign task')task.projectId='other';
  if(kind==='invalid run time')run.updatedAt=NaN;
  if(kind==='running run')run.status='running';
  if(kind==='raw script')run.source='script_generated';
  if(kind==='project wide')delete (run.scope as any).taskId;
  board([task],[run]);
  expect(screen.getByText('Old attempt failure')).toBeInTheDocument();
});

it('an old execution pointer does not mask a newer active or failed attempt', () => {
  const {task,run}=fixture();
  for(const status of ['running','failed']){
    const current={...run,id:'new',status,createdAt:2100,updatedAt:2200};
    expect(findWorkflowRunForTask(task as any,[run,current] as any,'fixture',[task] as any)?.id).toBe('new');
  }
});

it('project DAG keeps canonical tasks and excludes task-scoped attempt nodes', () => {
  const {task,run}=fixture();
  const graph=buildDagFromProject({project:{id:'fixture'},tasks:[task],workflowRuns:[run]} as any);
  expect(graph.nodes.some(n=>n.taskId===task.id&&n.status==='done')).toBe(true);
  expect(graph.nodes.some(n=>n.workflowNodeId==='reviewer')).toBe(false);
});
