# Kimi K3 工具上下文修复

适用 xiaokcode 1.5.5 / 1.5.6，Windows / macOS / Linux。
生成图片或调用 read、ask_user 时出现 tool_failed: KIMI_STRICT_TOOL_CONTEXT_REJECTED，
原因是内置 bash.description 使用 getter，K3 校验整份工具列表时拒绝这个 accessor。

本补丁只把 bash 描述在模块加载时计算成普通字符串。保留原平台文案和完整执行实现，
不放宽 K3 严格校验，不修改配置、key、session 或前两版补丁。

退出 xiaok，解压 ZIP，在包含 apply.mjs 的目录打开 PowerShell，执行：

```powershell
$pkg = Join-Path (npm root -g) "xiaokcode"
node .\apply.mjs $pkg
xiaok --auto
```

然后选择 Kimi K3，重试“生成一张xiaok的图片”。无需重新登录。
安装会备份原文件到 npm 包目录的 `.kimi-tool-context-backup-*`。
已安装会输出 `alreadyPatched: true`。正在运行的进程需重启才加载修复。

真实全量内置 ToolRegistry、实际注册 K3 adapter、真实 PromptBuilder/AgentRuntime 的
首次工具调用和后续完成已验证；只模拟模型响应和无副作用工具，没有调用付费图片服务。
源码严格校验与既有负向测试保持通过；Windows 与 POSIX 描述均验证为 data property。
Windows 真实生成图片仍需用户验证。
