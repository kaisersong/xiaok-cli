# Xiaok 1.5.6 Windows x64 启动修复

上一版 Coding Plan 登录补丁可以保留。此次错误发生在首次保存会话：npm 1.5.6
缺少 Windows 安装状态检查程序，导致 ordinary_source_route。这个包补齐所需 EXE
和校验 manifest，保留现有状态检查；同时补充安全的会话保存诊断。

## 在 Windows 上安装

退出正在运行的 xiaok，将 ZIP 解压，在含 apply.mjs 的目录打开 PowerShell：

```powershell
$pkg = Join-Path (npm root -g) "xiaokcode"
node .\apply.mjs $pkg
xiaok --auto
```

安装末尾应显示 `Windows installation check: ordinary`。不要重新输入 API key。
此包仅适用于 xiaokcode 1.5.6 和 Windows Node x64；不修改配置或 session。
安装会在 npm 包目录保存 `.windows-startup-backup-*` 备份。

如果安装自检显示 `installed` 或 `unavailable`，请提供该输出；不会绕过检测。
也可以直接运行只读检查程序：

```powershell
& (Join-Path $pkg "dist\runtime\verification\native\win32-x64\windows-installation-absence.exe")
```

如果启动仍失败，请提供新的 crash JSON。新报告会记录固定模块名、行号和
ordinary_source_route 标识，不记录 key、原始错误消息或绝对路径。

## 已验证与限制

真实 npm 1.5.6 发布包已复现原始保存失败；补齐文件后，通过真实 reader 和
FileSessionStore 的 Windows x64 分支保存、再次保存、loadLast；缺失/损坏/
超时/更换文件/installed/unavailable 的拒绝路径均通过。
Win32 API 用 SHGetKnownFolderPath 和 HKLM 64 位只读查询，不用环境变量定位。
检查程序由 MinGW-w64 交叉编译；PE x64 架构、摘要和 DLL 依赖已检查。
本机是 macOS，未执行 Windows EXE 实机测试；新增 Windows CI 未运行。
Windows 上安装时会自动执行真实本机检查。此包不宣称 ARM64 支持或正式发布就绪。
