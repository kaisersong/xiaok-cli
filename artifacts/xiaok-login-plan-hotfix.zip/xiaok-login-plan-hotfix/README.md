# xiaok Coding Plan 登录补丁

适用于 xiaokcode 1.5.5 / 1.5.6。只更新登录、套餐映射、崩溃报告模块，
并在现有 chat.js 的启动位置增加诊断阶段；保留现有 chat 开发功能与版本。
安装前自动备份原文件，不修改用户配置或会话。

在 Windows PowerShell 中解压此目录后运行：

```powershell
$pkg = Join-Path (npm root -g) "xiaokcode"
node .\apply.mjs $pkg
xiaok login --provider kimi --plan coding --set-default
xiaok --auto
```

GLM 使用 `--provider glm --plan coding`，MiniMax 使用
`--provider minimax --plan coding`。普通按量 Key 使用 `--plan api`。
也可以直接 `xiaok login`，依次选择 provider 和套餐；Key 隐藏输入。
国际服务和代理可通过 `--base-url <url>` 覆盖所选服务地址。

已通过构建、真实 TTY 登录后发消息测试，以及 Windows 分支的 raw 输入和 CUA
启动边界测试。此环境没有 Windows 实机；历史 UNCLASSIFIED_ERROR 报告无法还原
原始故障。如果 Windows 上仍在启动时退出，新报告将包含 startupPhase、可信模块的
行列位置、白名单 cause code 与实际版本，请提供新报告继续定位。

报告不会保存 Key、原始 message/stack、对话内容或绝对路径。
