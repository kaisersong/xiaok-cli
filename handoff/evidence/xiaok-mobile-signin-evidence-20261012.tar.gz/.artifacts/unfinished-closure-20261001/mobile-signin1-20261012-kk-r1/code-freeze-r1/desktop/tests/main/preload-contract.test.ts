import { registerMobileSignInIpc } from '../../electron/mobile-signin-typed-ipc.js';
import { registerServiceControlIpc } from '../../electron/service-control-typed-ipc.js';
import { registerMobileReadonlyIpc } from '../../electron/mobile-readonly-typed-ipc.js';
import { registerPluginCatalogIpc } from '../../electron/plugin-catalog-typed-ipc.js';
import { registerUpdaterIpc } from '../../electron/updater-typed-ipc.js';
import { registerRecorderWindowIpc } from '../../electron/recorder-window-typed-ipc.js';
import {registerConnectorsIpc} from '../../electron/connectors-typed-ipc.js';
import {registerScheduledTimedActionIpc} from '../../electron/scheduled-timed-action-typed-ipc.js';
import { registerKnowledgeIpc } from '../../electron/knowledge-typed-ipc.js';
import { registerPrinciplesIpc } from '../../electron/principles-typed-ipc.js';
import { registerDiagnosticsIpc } from '../../electron/diagnostics-typed-ipc.js';
import { registerModelProviderIpc } from '../../electron/model-provider-typed-ipc.js';
import { registerKSwarmProxy } from '../../electron/kswarm-ipc-proxy.js';
import { registerSemanticDesktopIpc } from '../../electron/semantic-ipc.js';
import { registerLoopManagementIpc } from '../../electron/loop-management-typed-ipc.js';
import { registerThreadMetadataIpc } from '../../electron/thread-metadata-typed-ipc.js';
import { registerDesktopSmallConfigIpc } from '../../electron/desktop-small-config-typed-ipc.js';
import {registerLoopOutputIpc} from '../../electron/loop-output-service.js';
import {registerLoopCurrentViewIpc} from '../../electron/loop-current-views.js';
import { registerConversationActivityIpc } from '../../electron/conversation-activity-ipc.js';
import Module, { createRequire } from 'node:module';
import { registerDesktopMultiAgentIpc } from '../../electron/desktop-multi-agent-ipc.js';
import { registerLoopPublicationIpc } from '../../electron/loop-publication-ipc.js';
import { registerRoomWorkspaceIpc } from '../../electron/room-workspace-ipc.js';
import { resolve } from 'node:path';
import { readFileSync } from 'node:fs';
import { describe, expect, it, vi } from 'vitest';
import {
  createPreloadApi,
  PRELOAD_API_KEYS,
  FULL_PRELOAD_KEYS,
  KSWARM_PROXY_KEYS,
  EXTRA_KEYS,
  THREAD_META_KEYS,
  EVENT_SUBSCRIPTION_KEYS,
  LOCAL_CONSTANT_KEYS,
  INVOKE_API_KEYS,
  INVOKE_CHANNEL_BY_KEY,
  KNOWN_UNROUTED_HANDLERS,
} from '../../electron/preload-api.js';
import {
  normalizeArtifactWorkspaceIpcError,
  sanitizeArtifactWorkspaceIpcInput,
} from '../../electron/ipc.js';

const ARTIFACT_WORKSPACE_API_KEYS = [
  'getArtifactWorkspaceSnapshot',
  'closeArtifactWorkspace',
  'readArtifactWorkspaceVersionPreview',
  'exportArtifactWorkspaceVersion',
  'createArtifactPlaceholder',
  'submitArtifactGeneration',
  'cancelArtifactGeneration',
  'retryArtifactGeneration',
  'preferArtifactVersion',
  'removeArtifactWorkspaceNode',
  'updateArtifactWorkspaceLayout',
  'saveArtifactWorkspaceViewport',
  'createArtifactWorkspaceCollection',
  'createArtifactWorkspaceNote',
  'updateArtifactWorkspaceNote',
  'createArtifactWorkspaceRelation',
  'setArtifactCollectionMembership',
  'recordArtifactWorkspaceEvent',
] as const;

const ARTIFACT_WORKSPACE_CHANNEL_BY_KEY = Object.fromEntries(
  ARTIFACT_WORKSPACE_API_KEYS.map((key) => [key, `desktop:artifactWorkspace:${key}`]),
);

describe('preload API contract', () => {
  it('exposes only task-semantic APIs', () => {
    expect(PRELOAD_API_KEYS).toEqual([
      'getModelConfig',
      'saveModelConfig',
      'updateModelRuntimeOptions',
      // SystemOne（Jev）辅助决策模型：独立于 providers/models 的一组键。
      'getSystemOneConfig',
      'saveSystemOneConfig',
      'createManagedXiaokAgent',
      'testProviderConnection',
      'listAvailableModelsForProvider',
      'deleteProvider',
      'deleteModel',
      'getMobilePairingInfo',
      // Relay credential state + the narrow sign-in opener (main derives the URL).
      'getMobileRelayStatus',
      'openMobileRelaySignIn',
      'readClipboardFilePaths',
      'readClipboardImage',
      'selectDirectory',
      'selectMaterials',
      'importMaterial',
      'prepareObservationTask',
      'createObservationTask',
      'stopObservationTask',
      'revokeObservationTask',
      'getObservationTaskStatus',
      'createTask',
      'createTaskWithFiles',
      'subscribeTask',
      'getConversationActivities',
      'getConversationActivityUnread',
      'markConversationActivitiesRead',
      'subscribeConversationActivityOverview',
      'subscribeConversationActivities',
      'getWorkActivity',
      'getMcpTaskInputs',
      'answerMcpTaskInput',
      'cancelMcpWork',
      'updateWorkReporting',
      'stopWorkWatch',
      'getMultiAgentSnapshot',
      'listMultiAgentGroups',
      'listMultiAgents',
      'getMultiAgentEvents',
      'getAgentContent',
      'getMultiAgentOperation',
      'getMultiAgentResources',
      'resolveMultiAgentResource',
      'resetMultiAgentGroup',
      'getMultiAgentThreadDeletion',
      'deleteMultiAgentThread',
      'sendAgentMessage',
      'followupAgent',
      'interruptAgent',
      'closeAgent',
      'subscribeMultiAgents',
      'unsubscribeMultiAgents',
      'getLocalExecutionAuthorization',
      'getLocalExecutionWorkspace',
      'getMultiAgentApproval',
      'decideMultiAgentApproval',
      'setLocalExecutionAuthorization',
      'getLocalExecutionAuthorizationOperation',
      'subscribeLocalExecutionAuthorization',
      'unsubscribeLocalExecutionAuthorization',
      'getGoal',
      'getGoalNativeMutation',
      'recoverGoalNativeMutation',
      'continueGoalNativeMutation',
      'cancelGoalNativeMutation',
      'createGoal',
      'pauseGoal',
      'resumeGoal',
      'recoverGoalPublication',
      'continueGoalPublication',
      'cancelGoal',
      'replaceGoal',
      'ackGoalTaskAttached',
      'setGoalUserQueuePending',
      'onGoalChanged',
      'onGoalTaskPrepared',
      'answerQuestion',
      'cancelTask',
      'getActiveTask',
      'recoverTask',
      'openArtifact',
      'openFileInSystemApp',
      'readFileContent',
      ...ARTIFACT_WORKSPACE_API_KEYS,
      'onArtifactWorkspaceChanged',
      'selectHtmlEditMedia',
      'listSkills',
      'installSkill',
      'uninstallSkill',
      'listChannels',
      'testChannel',
      'createChannel',
      'updateChannel',
      'deleteChannel',
      'listMCPInstalls',
      'createMCPInstall',
      'updateMCPInstall',
      'deleteMCPInstall',
      'listPluginMcpServers',
      'retryPluginComponent',
      'getComputerUseCapabilityStatus',
      'enableComputerUse',
      'reconnectComputerUse',
      'disableComputerUse',
      'openPluginDependencyPermissionSettings',
      'installPlugin',
      'listAvailablePlugins',
      'listPluginDependencyStatuses',
      'installPluginDependency',
      'updatePluginDependency',
      'diagnosePluginDependency',
      'cancelPluginDependencyTask',
      'getUpdateStatus',
      'checkForUpdates',
      'quitAndInstall',
      'onUpdateStatus',
      'onSkillsChanged',
      'createReminder',
      'listReminders',
      'cancelReminder',
      'getReminderStatus',
      'onReminder',
      'getSkillDebugConfig',
      'saveSkillDebugConfig',
      'getKswarmConfig',
      'saveKswarmConfig',
      'getSkillStats',
      'getServiceStatus',
      'restartRelatedService',
      'kswarmGetStatus',
      'kswarmStart',
      'kswarmStop',
      'kswarmRestart',
      'kswarmResumeWorkflowRun',
      'kswarmStartProjectPlanning',
      'getAssistantOverview',
      'activateAssistant',
      'pauseAssistant',
      'resumeAssistant',
      'acceptAssistantCandidate',
      'rejectAssistantCandidate',
      'planProjectTeam',
      'applyProjectTeamPlan',
      'getProjectTeamOperation',
      'createKSwarmProject',
      'updateKSwarmProjectExecutionMode',
      'deleteKSwarmProject',
      'createKSwarmAgent',
      'updateKSwarmAgent',
      'archiveKSwarmAgent',
      'startKSwarmAgent',
      'stopKSwarmAgent',
      'probeKSwarmAgent',
      'onKSwarmStatus',
      'onMobileRelayStatus',
      'exportTraceBundle',
      'diagnose',
      'getLoopDefinitions',
      'listUserLoopTemplates',
      'createUserLoopTemplate',
      'updateUserLoopTemplate',
      'deleteUserLoopTemplate',
      'clearLoopRunHistory',
      'createLoopSchedule',
      'getLoopScheduleBindings',
      'getAutomationOverviewSnapshot',
      'getAutomationRunHistory',
      'getAutomationsConfig',
      'setGlobalBackgroundAutoRun',
      'openLoopOutputDirectory',
      'readLoopOutputPreview',
      'readLoopTaskResult',
      'listLoopPublishedArtifacts',
      'getLoopRuns',
      'getLoopPublicationConfiguration',
      'getLoopPublicationState',
      'performLoopPublicationAction',
      'getEvidenceAnomalies',
      'runLoopNow',
      'listLoopConstraints',
      'setLoopConstraintActive',
      'confirmLoopConstraint',
      'onLoopConstraintAdded',
      'syncScheduledTasks',
      'getScheduledTasks',
      'createScheduledTask',
      'updateScheduledTask',
      'setScheduledTaskStatus',
      'cancelScheduledTask',
      'getTimedActions',
      'getTimedActionRuns',
      'approveTimedActionAuto',
      'revokeTimedActionAuto',
      'clearScheduledTaskRunHistory',
      'onScheduledTaskDue',
      'listMemories',
      'createMemory',
      'updateMemory',
      'deleteMemory',
      'importMemories',
      'memoryStats',
      'memoryCompact',
      'memoryPersonaTraits',
      'memoryListLayer',
      'memoryDeleteEntry',
      'memoryClearAll',
      'memoryGetModelId',
      'memorySetModelId',
      'getEmbeddingModels',
      'downloadEmbeddingModel',
      'setEmbeddingModel',
      'getConnectorsConfig',
      'saveConnectorsConfig',
      'listConnectorRuntimes',
      'testConnectorProvider',
      'kbListCollections',
      'kbCreateCollection',
      'kbDeleteCollection',
      'kbListSources',
      'kbAddSource',
      'kbDeleteSource',
      'kbGetCollectionState',
      'kbGetSourceContent',
      'kbSearch',
      'kbPickFiles',
      'meetingPickAudioFile',
      'meetingGetMicrophonePermission',
      'meetingRequestMicrophonePermission',
      'meetingGetAsrConfig',
      'meetingSaveAsrConfig',
      'meetingListModels',
      'meetingDownloadModel',
      'meetingUninstallModel',
      'meetingSaveRecordedAudio',
      'meetingTranscribePreview',
      'meetingStartLiveTranscription',
      'meetingPushLiveTranscriptionAudio',
      'meetingFinishLiveTranscription',
      'meetingCancelLiveTranscription',
      'meetingDraftRecording',
      'meetingProcessRecording',
      'meetingSaveTranscript',
      'meetingOpenRecorderWindow',
      'meetingSetRecorderWindowMode',
      'meetingSetRecorderSessionState',
      'meetingNotifyRecorderSummaryReady',
      'meetingNotifyRecordingSaved',
      'meetingCloseRecorderWindow',
      'onMeetingRecorderCloseRequested',
      'onMeetingRecordingSaved',
      'onMeetingLiveTranscriptionUpdate',
      'listCollaborationRooms',
      'getCollaborationRoom',
      'createCollaborationRoom',
      'archiveCollaborationRoom',
      'deleteCollaborationRoom',
      'updateCollaborationRoomMembers',
      'sendCollaborationRoomMessage',
      'markCollaborationRoomSeen',
      'cancelRoomDiscussion',
      'createProjectFromRoom',
      'createTaskFromRoomMessage',
      'onCollaborationRoomEvent',
      'getCollaborationRoomWorkspace', 'previewCollaborationRoomWorkspace', 'commitCollaborationRoomWorkspace',
      'cancelCollaborationRoomWorkspaceChange', 'listCollaborationRoomWorkspaceFiles', 'previewCollaborationRoomWorkspaceFile',
      'publishCollaborationRoomWorkspaceInstructions', 'confirmCollaborationRoomWorkspaceArtifact',
      'registerCollaborationRoomWorkspaceArtifact', 'mapCollaborationRoomWorkspaceProject', 'retryCollaborationRoomWorkspaceChange', 'setCollaborationRoomLocalCommands',
    ]);
  });

  it('does not expose raw fs, shell, or runtime event channels', () => {
    const ipcRenderer = {
      invoke: vi.fn(),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    expect(Object.keys(api).sort()).toEqual([...FULL_PRELOAD_KEYS].sort());
    expect(api).not.toHaveProperty('readFile');
    expect(api).not.toHaveProperty('readdir');
    expect(api).not.toHaveProperty('shell');
    expect(api).not.toHaveProperty('runPluginCommand');
    expect(api).not.toHaveProperty('rawRuntimeEvents');
    expect(api).not.toHaveProperty('insertEvidence');
    expect(api).not.toHaveProperty('completeLoopRun');
    expect(api).not.toHaveProperty('completeTask');
    expect(api).not.toHaveProperty('sql');
    expect(api).not.toHaveProperty('query');
    expect(api).not.toHaveProperty('execute');
    expect(api).not.toHaveProperty('fs');
    expect(api).not.toHaveProperty('reconcileArtifactWorkspace');
    expect(api).not.toHaveProperty('gcArtifactWorkspace');
    expect(api).not.toHaveProperty('renewArtifactWorkspaceLease');
    expect(api).not.toHaveProperty('updateArtifactWorkspace');
    expect(api).not.toHaveProperty('executeCanvasCommand');
  });

  it('routes exactly seventeen artifact workspace operations and strips main-owned identity fields', async () => {
    const successfulSnapshot = {
      ok: true,
      data: {
        workspace: { id: 'workspace-1', conversationId: 'conversation-1' },
        nodes: [],
        relations: [],
        versions: [],
      },
    };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(successfulSnapshot),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer) as unknown as Record<string, (input: unknown) => Promise<unknown>>;
    const maliciousInput = {
      conversationId: 'conversation-1',
      workspaceRootId: 'root-1',
      versionId: 'version-1',
      nodeId: 'node-1',
      requestSource: 'agent',
      viewKey: 'renderer-forged-view',
    };

    for (const key of ARTIFACT_WORKSPACE_API_KEYS) {
      await api[key]!(maliciousInput);
    }

    for (const key of ARTIFACT_WORKSPACE_API_KEYS) {
      expect(ipcRenderer.invoke).toHaveBeenCalledWith(
        ARTIFACT_WORKSPACE_CHANNEL_BY_KEY[key],
        expect.not.objectContaining({
          requestSource: expect.anything(),
          viewKey: expect.anything(),
        }),
      );
    }
    expect(JSON.parse(JSON.stringify(successfulSnapshot))).toEqual(successfulSnapshot);
  });

  it('preserves the stable artifact workspace IPC error envelope', async () => {
    const errorResult = {
      ok: false,
      error: {
        code: 'layout_revision_conflict',
        message: 'Layout revision conflict',
        canonical: { nodeId: 'node-1', x: 32, y: 48, layoutRevision: 3 },
      },
    };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(errorResult),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.updateArtifactWorkspaceLayout({
      conversationId: 'conversation-1',
      workspaceRootId: 'root-1',
      patches: [],
    })).resolves.toEqual(errorResult);
  });

  it('main sanitizes artifact workspace primitives and never trusts renderer-owned identity', () => {
    expect(sanitizeArtifactWorkspaceIpcInput('getArtifactWorkspaceSnapshot', {
      conversationId: 'conversation-1',
    })).toEqual({
      conversationId: 'conversation-1',
      workspaceRootId: 'desktop-artifact-workspace-v1',
    });
    expect(sanitizeArtifactWorkspaceIpcInput('submitArtifactGeneration', {
      conversationId: 'conversation-1',
      prompt: 'revise',
      selectedArtifact: {
        sourceTaskId: 'task-1', artifactId: 'artifact-1', kind: 'markdown',
        filePath: '/renderer/forbidden.md',
      },
      requestedKind: 'markdown',
      expectedStructureRevision: 0,
    })).toEqual({
      conversationId: 'conversation-1',
      workspaceRootId: 'desktop-artifact-workspace-v1',
      prompt: 'revise',
      selectedArtifact: { sourceTaskId: 'task-1', artifactId: 'artifact-1', kind: 'markdown' },
      requestedKind: 'markdown',
      expectedStructureRevision: 0,
    });

    expect(sanitizeArtifactWorkspaceIpcInput('saveArtifactWorkspaceViewport', {
      conversationId: 'conversation-1',
      workspaceRootId: 'root-1',
      viewport: { x: 10, y: 20, zoom: 1.25, injected: true },
      expectedViewRevision: 2,
      requestSource: 'agent',
      viewKey: 'renderer-forged-view',
      arbitrarySql: 'drop table workspaces',
    })).toEqual({
      conversationId: 'conversation-1',
      workspaceRootId: 'desktop-artifact-workspace-v1',
      viewport: { x: 10, y: 20, zoom: 1.25 },
      expectedViewRevision: 2,
    });

    expect(() => sanitizeArtifactWorkspaceIpcInput('updateArtifactWorkspaceLayout', {
      conversationId: 'conversation-1',
      workspaceRootId: 'root-1',
      patches: [{ nodeId: 'node-1', x: Number.NaN, y: 0, zIndex: 1, expectedLayoutRevision: 0 }],
    })).toThrow('Invalid artifact workspace layout field: x');
  });

  it('main normalizes service failures to one serializable error shape', () => {
    expect(normalizeArtifactWorkspaceIpcError({
      code: 'layout_revision_conflict',
      message: 'Layout revision conflict',
      canonicalNodes: [{ id: 'node-1', x: 4, y: 8 }],
      fileRef: '/private/app-data/version-1',
    })).toEqual({
      ok: false,
      error: {
        code: 'layout_revision_conflict',
        message: 'Layout revision conflict',
        canonical: [{ id: 'node-1', x: 4, y: 8 }],
      },
    });
    expect(normalizeArtifactWorkspaceIpcError(new Error('/private/path leaked'))).toEqual({
      ok: false,
      error: {
        code: 'runtime_unavailable',
        message: 'Artifact workspace operation failed',
      },
    });
  });

  it('routes loop diagnostics through semantic IPC channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue([]),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.getLoopDefinitions();
    await api.listUserLoopTemplates();
    await api.createUserLoopTemplate({
      loopId: 'user-loop-1',
      title: 'User Loop',
      kind: 'markdown_file',
      prompt: 'Write note',
      outputDirectory: '/tmp/xiaok-loop',
      outputFileName: 'note.md',
    });
    await api.createLoopSchedule({
      loopId: 'user-loop-1',
      title: 'User Loop Schedule',
      trigger: { kind: 'daily', hour: 9, minute: 0 },
    });
    await api.getLoopScheduleBindings();
    await api.getAutomationOverviewSnapshot();
    await api.getAutomationRunHistory();
    await api.getAutomationsConfig();
    await api.setGlobalBackgroundAutoRun({ enabled: false });
    await api.openLoopOutputDirectory('user-loop-1');
    await api.readLoopOutputPreview('user-loop-1');
    await api.getLoopRuns('artifact-evidence-regression');
    await api.getEvidenceAnomalies('artifact-evidence-regression');
    await api.runLoopNow('artifact-evidence-regression');

    await api.getLoopPublicationConfiguration('loop');
    await api.getLoopPublicationState('run');
    await api.performLoopPublicationAction({kind:'inspect',runId:'run'});
    await api.performLoopPublicationAction({kind:'reauthorizeNative',attemptId:'original',expectedRevision:7});
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:performPublicationAction',{kind:'reauthorizeNative',attemptId:'original',expectedRevision:7});
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:getPublicationConfiguration','loop');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:getPublicationState','run');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:performPublicationAction',{kind:'inspect',runId:'run'});
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:listDefinitions');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:listUserTemplates');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:createUserTemplate', {
      loopId: 'user-loop-1',
      title: 'User Loop',
      kind: 'markdown_file',
      prompt: 'Write note',
      outputDirectory: '/tmp/xiaok-loop',
      outputFileName: 'note.md',
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:createSchedule', {
      loopId: 'user-loop-1',
      title: 'User Loop Schedule',
      trigger: { kind: 'daily', hour: 9, minute: 0 },
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:getScheduleBindings');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:automations:getOverviewSnapshot');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:automations:getRunHistory');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:automations:getConfig');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:automations:setGlobalBackgroundAutoRun', { enabled: false });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:openOutputDirectory', 'user-loop-1');
    await api.listLoopPublishedArtifacts('user-loop-1',{offset:0,identity:null});
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:listPublishedArtifacts','user-loop-1',{offset:0,identity:null});
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:readOutputPreview', 'user-loop-1');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:listRuns', 'artifact-evidence-regression');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:listAnomalies', 'artifact-evidence-regression');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:loops:runNow', 'artifact-evidence-regression');
  });

  it('routes plugin dependency operations through semantic IPC channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ success: true }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.listPluginDependencyStatuses();
    await api.installPluginDependency({ pluginName: 'cua-computer-use', dependencyId: 'cua-driver', confirmed: true });
    await api.updatePluginDependency({ pluginName: 'cua-computer-use', dependencyId: 'cua-driver', confirmed: true });
    await api.diagnosePluginDependency({ pluginName: 'cua-computer-use', dependencyId: 'cua-driver' });
    await api.cancelPluginDependencyTask({ pluginName: 'cua-computer-use', dependencyId: 'cua-driver' });
    await api.retryPluginComponent({ componentId: 'cua-driver' });
    await api.getComputerUseCapabilityStatus();
    await api.enableComputerUse();
    await api.reconnectComputerUse();
    await api.disableComputerUse();
    await api.openPluginDependencyPermissionSettings({ permission: 'accessibility' });

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:listPluginDependencyStatuses');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:installPluginDependency', {
      pluginName: 'cua-computer-use',
      dependencyId: 'cua-driver',
      confirmed: true,
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:updatePluginDependency', {
      pluginName: 'cua-computer-use',
      dependencyId: 'cua-driver',
      confirmed: true,
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:diagnosePluginDependency', {
      pluginName: 'cua-computer-use',
      dependencyId: 'cua-driver',
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:cancelPluginDependencyTask', {
      pluginName: 'cua-computer-use', dependencyId: 'cua-driver',
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:retryPluginComponent', { componentId: 'cua-driver' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:getComputerUseCapabilityStatus');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:enableComputerUse');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:reconnectComputerUse');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:disableComputerUse');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:openPluginDependencyPermissionSettings', {
      permission: 'accessibility',
    });
  });

  it('routes provider connection test through semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ success: true, latencyMs: 150 }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.testProviderConnection({ providerId: 'anthropic' })).resolves.toEqual({ success: true, latencyMs: 150 });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:testProviderConnection', { providerId: 'anthropic' });
  });

  it('routes available models list through semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue([
        { modelId: 'anthropic-claude-opus-4-6', model: 'claude-opus-4-6', label: 'Claude Opus 4.6' },
      ]),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.listAvailableModelsForProvider('anthropic')).resolves.toEqual([
      { modelId: 'anthropic-claude-opus-4-6', model: 'claude-opus-4-6', label: 'Claude Opus 4.6' },
    ]);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:listAvailableModelsForProvider', 'anthropic');
  });

  it('keeps runtime metadata in the renderer available-model bridge contract', () => {
    const bridgeSource = readFileSync(resolve(process.cwd(), 'renderer', 'src', 'api', 'bridge.ts'), 'utf8');
    expect(bridgeSource).toContain(
      'async listAvailableModelsForProvider(providerId: string): Promise<AvailableModelView[]>',
    );
  });

  it('routes provider deletion through semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(undefined),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.deleteProvider('custom-provider');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:deleteProvider', 'custom-provider');
  });

  it('routes model deletion through semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(undefined),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.deleteModel('custom-model');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:deleteModel', 'custom-model');
  });

  it('routes material selection through a semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ filePaths: ['/tmp/a.pdf'] }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.selectMaterials()).resolves.toEqual({ filePaths: ['/tmp/a.pdf'] });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:selectMaterials');
  });

  it('routes directory selection through a semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ filePath: '/tmp/workspace' }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.selectDirectory()).resolves.toEqual({ filePath: '/tmp/workspace' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:selectDirectory');
  });

  it('routes model config reads and saves through semantic IPC channels', async () => {
    const snapshot = { defaultModelId: 'kimi-default', providers: [], models: [] };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(snapshot),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.getModelConfig()).resolves.toBe(snapshot);
    await expect(api.saveModelConfig({ providerId: 'kimi', apiKey: 'sk-kimi' })).resolves.toBe(snapshot);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:getModelConfig');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:saveModelConfig', { providerId: 'kimi', apiKey: 'sk-kimi' });
  });

  it('routes K3 runtime policy updates through the dedicated semantic IPC channel', async () => {
    const snapshot = { defaultModelId: 'kimi-default', providers: [], models: [] };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(snapshot),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);
    const input = {
      modelId: 'kimi-default',
      runtimeOptions: { contextLimit: 1_048_576, reasoningEffort: 'max' as const },
    };

    await expect(api.updateModelRuntimeOptions(input)).resolves.toBe(snapshot);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:updateModelRuntimeOptions', input);
  });

  it('routes managed xiaok agent creation through semantic IPC channel', async () => {
    const result = { ok: true, agent: { id: 'xiaok-po' } };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(result),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(api.createManagedXiaokAgent({ name: 'PO-Agent', roles: ['project_owner'] })).resolves.toBe(result);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:createManagedXiaokAgent', {
      name: 'PO-Agent',
      roles: ['project_owner'],
    });
  });

  it('routes assistant lifecycle and candidate decisions through fixed semantic IPC channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ ok: true }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.getAssistantOverview();
    await api.activateAssistant();
    await api.pauseAssistant();
    await api.resumeAssistant();
    await api.acceptAssistantCandidate({ candidateId: 'candidate-1', collectionId: 'collection-1', requestSource: 'agent' } as any);
    await api.rejectAssistantCandidate({ candidateId: 'candidate-2', requestSource: 'agent' } as any);

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:assistant:getOverview');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:assistant:activate');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:assistant:pause');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:assistant:resume');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:assistant:acceptCandidate', {
      candidateId: 'candidate-1',
      collectionId: 'collection-1',
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:assistant:rejectCandidate', { candidateId: 'candidate-2' });
  });

  it('routes KSwarm team and CRUD mutations through fixed semantic IPC channels without authority fields', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ ok: true }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.planProjectTeam({ projectId: 'project-1', token: 'forbidden' } as any);
    await api.applyProjectTeamPlan({
      projectId: 'project-1',
      planId: 'plan-1',
      projectRevision: 7,
      clientRequestKey: 'forbidden',
    } as any);
    await api.getProjectTeamOperation({ projectId: 'project-1', operationId: 'forbidden' } as any);
    await api.createKSwarmProject({ name: 'Demo', goal: 'Ship', poAgent: 'xiaok-po', members: [] });
    await api.updateKSwarmProjectExecutionMode({ projectId: 'project-1', executionMode: 'auto', requestSource: 'agent' } as any);
    await api.deleteKSwarmProject({ projectId: 'project-1', token: 'forbidden' } as any);
    await api.createKSwarmAgent({ name: 'Researcher', roles: ['worker'], apiKey: 'forbidden' } as any);
    await api.updateKSwarmAgent({ agentId: 'agent-1', patch: { name: 'Updated', provider: 'forbidden', fallbackToDesktopModel: true } as any });
    await api.archiveKSwarmAgent({ agentId: 'agent-1', requestSource: 'agent' } as any);
    await api.startKSwarmAgent({ agentId: 'agent-1', token: 'forbidden' } as any);
    await api.stopKSwarmAgent({ agentId: 'agent-1', token: 'forbidden' } as any);

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:team:plan', { projectId: 'project-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:team:apply', {
      projectId: 'project-1',
      planId: 'plan-1',
      projectRevision: 7,
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:team:getOperation', { projectId: 'project-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:project:create', {
      name: 'Demo', goal: 'Ship', poAgent: 'xiaok-po', members: [],
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:project:updateExecutionMode', {
      projectId: 'project-1', executionMode: 'auto',
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:project:delete', { projectId: 'project-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:agent:create', {
      name: 'Researcher', roles: ['worker'],
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:agent:update', {
      agentId: 'agent-1', patch: { name: 'Updated', fallbackToDesktopModel: true },
    });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:agent:archive', { agentId: 'agent-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:agent:start', { agentId: 'agent-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:agent:stop', { agentId: 'agent-1' });
  });

  it.each(['typed', 'runtime'])('preserves project model references and reset through the %s preload boundary', async (kind) => {
    const ipcRenderer = { invoke: vi.fn().mockResolvedValue({ ok: true }), on: vi.fn(), off: vi.fn() };
    const loaded = kind === 'runtime' ? loadRuntimePreloadApi() : { api: createPreloadApi(ipcRenderer), ipcRenderer };
    const api = loaded.api as ReturnType<typeof createPreloadApi>;
    await api.createKSwarmAgent({ name: 'Vision', runtimeType: 'xiaok', desktopModelId: 'vision' });
    await api.updateKSwarmAgent({ agentId: 'worker', patch: { desktopModelId: 'vision' } });
    await api.updateKSwarmAgent({ agentId: 'worker', patch: { desktopModelId: null } });
    expect(loaded.ipcRenderer.invoke).toHaveBeenNthCalledWith(1, 'desktop:kswarm:agent:create', { name: 'Vision', runtimeType: 'xiaok', desktopModelId: 'vision' });
    expect(loaded.ipcRenderer.invoke).toHaveBeenNthCalledWith(2, 'desktop:kswarm:agent:update', { agentId: 'worker', patch: { desktopModelId: 'vision' } });
    expect(loaded.ipcRenderer.invoke).toHaveBeenNthCalledWith(3, 'desktop:kswarm:agent:update', { agentId: 'worker', patch: { desktopModelId: null } });
  });

  it('routes createTask thread context through semantic IPC channel', async () => {
    const result = { taskId: 'task_test' };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(result),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);
    const input = {
      prompt: 'test',
      materials: [],
      context: { threadId: 'thread-a', taskIds: ['task_1'] },
    };

    await expect(api.createTask(input)).resolves.toBe(result);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:createTask', input);
  });

  it('routes createTaskWithFiles thread context through semantic IPC channel', async () => {
    const result = { taskId: 'task_test' };
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue(result),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);
    const input = {
      prompt: 'test',
      filePaths: ['/tmp/file.md'],
      context: { threadId: 'thread-a', taskIds: ['task_1'] },
    };

    await expect(api.createTaskWithFiles(input)).resolves.toBe(result);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:createTaskWithFiles', input);
  });

  it('routes independent meeting recorder window commands and events through semantic channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ ok: true }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer) as any;

    await api.meetingOpenRecorderWindow({ collectionId: 'col-1' });
    await api.meetingSetRecorderWindowMode({ mode: 'compact' });
    await api.meetingSetRecorderSessionState({ state: 'recording' });
    await api.meetingNotifyRecorderSummaryReady({ title: '需求讨论' });
    await api.meetingNotifyRecordingSaved({ collectionId: 'col-1' });
    await api.meetingCloseRecorderWindow();

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:meetingOpenRecorderWindow', { collectionId: 'col-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:meetingSetRecorderWindowMode', { mode: 'compact' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:meetingSetRecorderSessionState', { state: 'recording' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:meetingNotifyRecorderSummaryReady', { title: '需求讨论' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:meetingNotifyRecordingSaved', { collectionId: 'col-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:meetingCloseRecorderWindow');

    const closeListener = vi.fn();
    const savedListener = vi.fn();
    const unsubscribeClose = api.onMeetingRecorderCloseRequested(closeListener);
    const unsubscribeSaved = api.onMeetingRecordingSaved(savedListener);
    expect(ipcRenderer.on).toHaveBeenCalledWith('desktop:meetingRecorderCloseRequested', expect.any(Function));
    expect(ipcRenderer.on).toHaveBeenCalledWith('desktop:meetingRecordingSaved', expect.any(Function));
    unsubscribeClose();
    unsubscribeSaved();
    expect(ipcRenderer.off).toHaveBeenCalledWith('desktop:meetingRecorderCloseRequested', expect.any(Function));
    expect(ipcRenderer.off).toHaveBeenCalledWith('desktop:meetingRecordingSaved', expect.any(Function));
  });

  it('routes timed action review approve / revoke through semantic IPC channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ id: 'action-1' }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await api.approveTimedActionAuto('action-1');
    await api.revokeTimedActionAuto('action-1');

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:timedAction:approveAuto', 'action-1');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:timedAction:revokeAuto', 'action-1');
  });

  it('routes dynamic workflow direct resume through semantic IPC channel', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ restored: true, jobId: 'wf-script-job-run-1' }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer);

    await expect(
      api.kswarmResumeWorkflowRun({ projectId: 'proj-1', workflowRunId: 'run-1' }),
    ).resolves.toEqual({ restored: true, jobId: 'wf-script-job-run-1' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:resumeWorkflowRun', {
      projectId: 'proj-1',
      workflowRunId: 'run-1',
    });
  });

  it('FULL_PRELOAD_KEYS is the composition of PRELOAD_API_KEYS + KSWARM_PROXY_KEYS + EXTRA_KEYS + THREAD_META_KEYS', () => {
    const composed = [...PRELOAD_API_KEYS, ...KSWARM_PROXY_KEYS, ...EXTRA_KEYS, ...THREAD_META_KEYS];
    expect([...FULL_PRELOAD_KEYS].sort()).toEqual([...composed].sort());
  });

  it('createPreloadApi returns keys matching FULL_PRELOAD_KEYS', () => {
    const ipcRenderer = {
      invoke: vi.fn(),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer, 'test-user');
    const actualKeys = Object.keys(api).sort();
    expect(actualKeys).toEqual([...FULL_PRELOAD_KEYS].sort());
  });

  it('runtime preload.cjs exposes keys matching FULL_PRELOAD_KEYS', () => {
    const { api } = loadRuntimePreloadApi();
    expect(Object.keys(api).sort()).toEqual([...FULL_PRELOAD_KEYS].sort());
  });

  it('typed and runtime preload preserve Main-owned Goal completion observations', async () => {
    const runtime = loadRuntimePreloadApi();
    const typedIpc = { invoke: vi.fn(), on: vi.fn(), off: vi.fn() };
    const typed = createPreloadApi(typedIpc, 'test-user');
    for (const { api, ipcRenderer } of [runtime, { api: typed, ipcRenderer: typedIpc }]) {
      const projection = { state: { goalId: 'goal', status: 'complete' }, activation: 'disarmed',
        currentCompletion: { kind: 'protected', state: 'needs_revalidation' } };
      ipcRenderer.invoke.mockResolvedValue(projection);
      expect(await (api.getGoal as (id: string) => Promise<unknown>)('thread')).toEqual(projection);
      expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:goal:get', { threadId: 'thread' });
    }
  });

  it('runtime preload.cjs forwards K3 runtime policy updates unchanged', async () => {
    const { api, ipcRenderer } = loadRuntimePreloadApi();
    const input = {
      modelId: 'kimi-default',
      runtimeOptions: { contextLimit: 1_048_576, reasoningEffort: 'max' },
    };

    await (api.updateModelRuntimeOptions as (value: typeof input) => Promise<unknown>)(input);
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:updateModelRuntimeOptions', input);
  });

  it('routes kswarm proxy methods through semantic IPC channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ data: 'test' }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer, 'test-user');

    await api.kswarmProxyGet('/projects');
    await api.kswarmProxyPost('/tasks', { title: 'test' });
    await api.kswarmProxyDelete('/tasks/t1');

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:proxy:get', '/projects');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:proxy:post', '/tasks', { title: 'test' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:kswarm:proxy:delete', '/tasks/t1');
  });

  it('routes extra methods through semantic IPC channels', async () => {
    const ipcRenderer = {
      invoke: vi.fn().mockResolvedValue({ ok: true }),
      on: vi.fn(),
      off: vi.fn(),
    };
    const api = createPreloadApi(ipcRenderer, 'test-user');

    await api.showSaveDialog({ defaultPath: '/tmp/test.md' });
    await api.saveFile({ filePath: '/tmp/test.md', content: 'hello' });
    await (api as any).selectHtmlEditMedia({ kind: 'image' });
    await api.listPrinciples();
    await api.savePrinciple({ id: 'p1', content: 'test' } as never);
    await api.deletePrinciple('p1');

    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:showSaveDialog', { defaultPath: '/tmp/test.md' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:saveFile', { filePath: '/tmp/test.md', content: 'hello' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:selectHtmlEditMedia', { kind: 'image' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:listPrinciples');
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:savePrinciple', { id: 'p1', content: 'test' });
    expect(ipcRenderer.invoke).toHaveBeenCalledWith('desktop:deletePrinciple', 'p1');
  });
});

const HANDLER_REGISTRATION_FILES = [
  resolve(process.cwd(), 'electron', 'main.ts'),
  resolve(process.cwd(), 'electron', 'ipc.ts'),
  resolve(process.cwd(), 'electron', 'kswarm-ipc-proxy.ts'),
  resolve(process.cwd(), 'electron', 'semantic-ipc.ts'),
];

function extractRegisteredHandlerChannels(): Set<string> {
  const channels = new Set<string>();
  // This registrar deliberately generates semantic channels. Execute the real
  // registrar instead of duplicating its command table in this source scanner.
  const dispose = registerDesktopMultiAgentIpc({ handle: channel => { channels.add(channel); } }, null, { authorize: () => null });
  dispose();
  registerRoomWorkspaceIpc({ handle: channel => { channels.add(channel); } }, {} as never, () => false);
  registerSemanticDesktopIpc({handle:channel=>{channels.add(channel);}}, {assistant:{} as never,kswarm:{} as never,authorizeAssistant:()=>false});
  registerLoopPublicationIpc({ handle: channel => { channels.add(channel); } }, {} as never, () => false);
  registerLoopCurrentViewIpc({handle:channel=>{channels.add(channel);}},{} as never,()=>false);
  registerLoopManagementIpc({ handle: channel => { channels.add(channel); } });
  registerThreadMetadataIpc({ handle: channel => { channels.add(channel); } });
  registerDesktopSmallConfigIpc({ handle: channel => { channels.add(channel); } });
  registerModelProviderIpc({ handle: channel => { channels.add(channel); } });
  registerDiagnosticsIpc({ handle: channel => { channels.add(channel); } });
  registerPrinciplesIpc({ handle: channel => { channels.add(channel); } });
  registerKnowledgeIpc({ handle: channel => { channels.add(channel); } });
  registerScheduledTimedActionIpc({ handle: channel => { channels.add(channel); } });
  registerConnectorsIpc({ handle: channel => { channels.add(channel); } });
  registerRecorderWindowIpc({ handle: channel => { channels.add(channel); } }, new Map(), { isMainWindowSender: () => false, isRecorderWindowSender: () => false });
  registerUpdaterIpc({ handle: channel => { channels.add(channel); } }, new Map(), () => false);
  registerPluginCatalogIpc({ handle: channel => { channels.add(channel); } });
  registerMobileReadonlyIpc({ handle: channel => { channels.add(channel); } });
  registerServiceControlIpc({ handle: channel => { channels.add(channel); } });
  registerMobileSignInIpc({ handle: channel => { channels.add(channel); } });
  registerKSwarmProxy({ handle: channel => { channels.add(channel); } }, {} as never);
registerLoopOutputIpc({handle:channel=>{channels.add(channel);}},{} as never,()=>false);
  registerConversationActivityIpc({ handle: channel => { channels.add(channel); } }, null, () => null);
  for (const filePath of HANDLER_REGISTRATION_FILES) {
    const source = readFileSync(filePath, 'utf8');
    const re = /(?:(?:ipcMain|shutdownAwareIpc)\.handle|fileHandler)\(\s*'([^']+)'/g;
    let match: RegExpExecArray | null;
    while ((match = re.exec(source)) !== null) {
      channels.add(match[1]!);
    }
    // artifactHandler owns the fixed semantic prefix; actual registration and
    // consumer delivery are covered by artifact-workspace-ipc-registry.test.ts.
    for (const artifact of source.matchAll(/artifactHandler\(\s*'([^']+)'/g)) {
      channels.add(`desktop:artifactWorkspace:${artifact[1]}`);
    }
    for (const memory of source.matchAll(/memoryHandler\(\s*'([^']+)'/g)) {
      channels.add(`desktop:${memory[1]}`);
    }
  }
  return channels;
}

describe('IPC handler ↔ preload key parity', () => {
  it('three preload key categories are disjoint and cover FULL_PRELOAD_KEYS', () => {
    const eventSet = new Set<string>(EVENT_SUBSCRIPTION_KEYS);
    const localSet = new Set<string>(LOCAL_CONSTANT_KEYS);
    const invokeSet = new Set<string>(INVOKE_API_KEYS);

    // Disjoint
    for (const key of EVENT_SUBSCRIPTION_KEYS) {
      expect(localSet.has(key)).toBe(false);
      expect(invokeSet.has(key)).toBe(false);
    }
    for (const key of LOCAL_CONSTANT_KEYS) {
      expect(eventSet.has(key)).toBe(false);
      expect(invokeSet.has(key)).toBe(false);
    }

    // Cover
    const union = new Set<string>([...eventSet, ...localSet, ...invokeSet]);
    expect(union.size).toBe(FULL_PRELOAD_KEYS.length);
    for (const key of FULL_PRELOAD_KEYS) {
      expect(union.has(key)).toBe(true);
    }
  });

  it('INVOKE_CHANNEL_BY_KEY keys exactly match INVOKE_API_KEYS', () => {
    const mappedKeys = Object.keys(INVOKE_CHANNEL_BY_KEY).sort();
    const expectedKeys = [...INVOKE_API_KEYS].sort();
    expect(mappedKeys).toEqual(expectedKeys);
  });

  it('maps the artifact workspace API keys to the exact semantic IPC channels', () => {
    const mappings = Object.fromEntries(
      ARTIFACT_WORKSPACE_API_KEYS.map((key) => [key, INVOKE_CHANNEL_BY_KEY[key]]),
    );
    expect(mappings).toEqual(ARTIFACT_WORKSPACE_CHANNEL_BY_KEY);
  });

  it('every INVOKE_CHANNEL_BY_KEY channel is registered in main process source files', () => {
    const registeredChannels = extractRegisteredHandlerChannels();
    const orphanInvokes: Array<{ key: string; channel: string }> = [];
    for (const [key, channel] of Object.entries(INVOKE_CHANNEL_BY_KEY)) {
      if (!registeredChannels.has(channel)) {
        orphanInvokes.push({ key, channel });
      }
    }
    expect(orphanInvokes).toEqual([]);
  });

  it('every registered ipcMain.handle channel either maps to a preload key or is in KNOWN_UNROUTED_HANDLERS', () => {
    const registeredChannels = extractRegisteredHandlerChannels();
    const reverseMap = new Set(Object.values(INVOKE_CHANNEL_BY_KEY));
    // subscribeTask is hybrid: it triggers an invoke 'desktop:subscribeTask' but
    // is classified as event subscription. Add the invoke side here so it does
    // not appear orphaned.
    reverseMap.add('desktop:subscribeTask');
    reverseMap.add('desktop:subscribeMultiAgents');
    reverseMap.add('desktop:subscribeLocalExecutionAuthorization');
    const knownOrphans = new Set(KNOWN_UNROUTED_HANDLERS);

    const undeclaredOrphans: string[] = [];
    for (const channel of registeredChannels) {
      if (reverseMap.has(channel)) continue;
      if (knownOrphans.has(channel)) continue;
      undeclaredOrphans.push(channel);
    }
    expect(undeclaredOrphans).toEqual([]);
  });
});

function loadRuntimePreloadApi(): {
  api: Record<string, unknown>;
  ipcRenderer: { invoke: ReturnType<typeof vi.fn>; on: ReturnType<typeof vi.fn>; off: ReturnType<typeof vi.fn> };
} {
  const require = createRequire(import.meta.url);
  const preloadPath = resolve(process.cwd(), 'electron', 'preload.cjs');
  type ModuleLoader = (request: string, parent: unknown, isMain: boolean) => unknown;
  const originalLoad = (Module as unknown as { _load: ModuleLoader })._load;
  let exposedApi: Record<string, unknown> | null = null;
  const ipcRenderer = {
    invoke: vi.fn(),
    on: vi.fn(),
    off: vi.fn(),
  };

  delete require.cache[preloadPath];
  (Module as unknown as { _load: ModuleLoader })._load = ((request: string, parent: unknown, isMain: boolean) => {
    if (request === 'electron') {
      return {
        contextBridge: {
          exposeInMainWorld(name: string, api: Record<string, unknown>) {
            if (name === 'xiaokDesktop') exposedApi = api;
          },
        },
        ipcRenderer,
      };
    }
    if (request === 'os') {
      return { userInfo: () => ({ username: 'test-user' }) };
    }
    return originalLoad(request, parent, isMain);
  }) as ModuleLoader;

  try {
    require(preloadPath);
  } finally {
    (Module as unknown as { _load: ModuleLoader })._load = originalLoad;
    delete require.cache[preloadPath];
  }

  if (!exposedApi) {
    throw new Error('preload.cjs did not expose xiaokDesktop');
  }
  return { api: exposedApi, ipcRenderer };
}


describe('Loop management complete11 transport bridge contracts', () => {
  it.each(['typescript', 'sandbox-cjs'] as const)('keeps all11 actual %s names, payload arity and results', async implementation => {
    const port = { invoke: vi.fn().mockResolvedValue({ transportOnly: true }), on: vi.fn(), off: vi.fn() };
    const loaded = implementation === 'sandbox-cjs' ? loadRuntimePreloadApi() : null;
    const api = loaded?.api ?? createPreloadApi(port);
    const ipc = loaded?.ipcRenderer ?? port;
    ipc.invoke.mockResolvedValue({ transportOnly: true });
    const calls: Array<[string, string, unknown[]]> = [
      ['getLoopDefinitions', 'listDefinitions', []], ['listUserLoopTemplates', 'listUserTemplates', []],
      ['createUserLoopTemplate', 'createUserTemplate', [{ loopId: 'loop', kind: 'task_completion', title: 'title', prompt: 'prompt' }]],
      ['updateUserLoopTemplate', 'updateUserTemplate', ['loop', { prompt: 'updated' }]],
      ['deleteUserLoopTemplate', 'deleteUserTemplate', ['loop']], ['getEvidenceAnomalies', 'listAnomalies', ['loop']],
      ['runLoopNow', 'runNow', ['loop']], ['listLoopConstraints', 'listConstraints', ['loop']],
      ['setLoopConstraintActive', 'setConstraintActive', ['constraint', false]], ['confirmLoopConstraint', 'confirmConstraint', ['constraint']],
      ['clearLoopRunHistory', 'clearRunHistory', ['loop', ['failed', 'blocked']]],
    ];
    for (const [method, suffix, args] of calls) {
      ipc.invoke.mockClear();
      const value = await (api as unknown as Record<string, (...args: unknown[]) => Promise<unknown>>)[method]!(...args);
      expect(value).toEqual({ transportOnly: true });
      expect(ipc.invoke).toHaveBeenCalledExactlyOnceWith(`desktop:loops:${suffix}`, ...args);
      expect(ipc.invoke.mock.calls[0]).toHaveLength(1 + args.length);
    }
  });
});


describe('Thread metadata complete7 transport bridge contracts', () => {
  it.each(['typescript', 'sandbox-cjs'] as const)('keeps all7 actual %s tuples and the complete migration receipt', async implementation => {
    const receipt = { ok: false, degraded: true, migrated: false, reason: 'degraded' };
    const port = { invoke: vi.fn().mockResolvedValue(receipt), on: vi.fn(), off: vi.fn() };
    const loaded = implementation === 'sandbox-cjs' ? loadRuntimePreloadApi() : null;
    const api = loaded?.api ?? createPreloadApi(port), ipc = loaded?.ipcRenderer ?? port;
    ipc.invoke.mockResolvedValue(receipt);
    const calls: Array<[string, unknown[]]> = [
      ['getThreadLabels', []], ['setThreadLabel', ['线程', 'pinned']],
      ['unsetThreadLabel', ['线程', 'pinned']], ['moveThreadLabel', ['线程', 'inbox', 'todo']],
      ['getAppFlag', ['gtd-enabled']], ['setAppFlag', ['gtd-enabled', 'true']],
      ['migrateLegacyThreadMeta', [{ pinned: ['历史'], gtdEnabled: true }]],
    ];
    for (const [method, args] of calls) {
      ipc.invoke.mockClear();
      const value = await (api as unknown as Record<string, (...args: unknown[]) => Promise<unknown>>)[method]!(...args);
      expect(value).toBe(receipt);
      expect(ipc.invoke).toHaveBeenCalledExactlyOnceWith(`desktop:${method}`, ...args);
      expect(ipc.invoke.mock.calls[0]).toHaveLength(1 + args.length);
    }
  });
});

describe('Small configuration complete4 transport bridge contracts', () => {
  it.each(['typescript', 'sandbox-cjs'] as const)('preserves all4 actual %s tuples, complete replies and failure without retry', async implementation => {
    const port = { invoke: vi.fn(), on: vi.fn(), off: vi.fn() };
    const loaded = implementation === 'sandbox-cjs' ? loadRuntimePreloadApi() : null;
    const api = loaded?.api ?? createPreloadApi(port), ipc = loaded?.ipcRenderer ?? port;
    const calls: Array<[string, unknown[], unknown]> = [
      ['getSkillDebugConfig', [], { enabled: false }], ['saveSkillDebugConfig', [{ enabled: true }], { enabled: true }],
      ['getKswarmConfig', [], { maxConcurrentTasks: 3 }], ['saveKswarmConfig', [{ maxConcurrentTasks: 6.8 }], { maxConcurrentTasks: 7 }],
    ];
    for (const [method, args, receipt] of calls) {
      ipc.invoke.mockClear().mockResolvedValueOnce(receipt);
      expect(await (api as unknown as Record<string, (...args: unknown[]) => Promise<unknown>>)[method]!(...args)).toBe(receipt);
      expect(ipc.invoke).toHaveBeenCalledExactlyOnceWith(`desktop:${method}`, ...args);
      expect(ipc.invoke.mock.calls[0]).toHaveLength(1 + args.length);
    }
    const failure = Error('desktop_config_operation_unknown');
    ipc.invoke.mockClear().mockRejectedValueOnce(failure);
    await expect((api as unknown as Record<string, (...args: unknown[]) => Promise<unknown>>).saveSkillDebugConfig!({ enabled: false })).rejects.toBe(failure);
    expect(ipc.invoke).toHaveBeenCalledTimes(1);
  });
});
