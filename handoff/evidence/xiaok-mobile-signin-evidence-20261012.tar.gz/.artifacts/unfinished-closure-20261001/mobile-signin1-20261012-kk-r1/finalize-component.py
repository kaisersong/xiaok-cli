import datetime
import hashlib
import json
import os
from pathlib import Path

e = Path(__file__).resolve().parent
r = e.parents[2]
def read(name):
    return json.loads((e / name).read_text())
def write(name, value):
    (e / name).write_text(json.dumps(value, indent=2))
def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

assert 'APPROVE_CODE_SUPPLEMENT' in (e / 'signin-code-independent-r2.log').read_text()
freeze = read('signin-code-freeze-r2.json')
for item in freeze['files']:
    assert digest(item['source']) == digest(item['copy']) == item['sha256']
for label in ['signin-code-independent-r1', 'signin-code-independent-r2', 'signin-whole-r3', 'signin-strict-r3', 'signin-test-lint-r3', 'signin-gov-r1', 'signin-build-main-r1', 'signin-build-renderer-r1', 'native-signin-r1']:
    p = read(label + '-process.json')
    assert p['exit'] == 0 and p['actualWait'] and p['reaped'] and p['groupGone'] and not p['sourceDrift']
whole = read('signin-whole-r3.json')
assert whole['numTotalTests'] == whole['numPassedTests'] == 780
assert whole['numFailedTests'] == whole['numPendingTests'] == 0
assert len(whole['testResults']) == 69
strict = read('signin-strict-r3.json')
assert not strict['drift'] and all(not x['diagnostics'] and x['options']['noCheck'] is False for x in strict['results'])
audit = []
for path in sorted(e.glob('*-process.json')):
    p = json.loads(path.read_text())
    assert p['actualWait'] and p['reaped'] and p['groupGone'] and not p['sourceDrift']
    try:
        os.killpg(p['pid'], 0)
        gone = False
    except ProcessLookupError:
        gone = True
    assert gone, path.name
    audit.append({'file': path.name, 'pid': p['pid'], 'exit': p['exit'], 'actualWait': True, 'reaped': True, 'groupGoneAtWait': True, 'groupGoneNow': gone})
assert not (e / 'heavy-cpu-lease.lock').exists()
write('final-owned-process-audit-r1.json', {'processCount': len(audit), 'processes': audit, 'remainingOwnedGroups': 0, 'activeLease': False, 'foreignProcessesKilled': False})
final = {
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'original desktop:mobile:openRelaySignIn source component only',
    'channels': ['desktop:mobile:openRelaySignIn'],
    'addedToFormalCount': 1, 'previousAccepted': 213, 'currentAccepted': 214, 'originalTotal': 298, 'remaining': 84,
    'remainingByOwner': {'ipc': 76, 'main': 8, 'proxy': 0},
    'sourceFreeze': freeze,
    'independentCode': ['signin-code-independent-r1.log', 'signin-code-independent-r2.log'],
    'sourceDeltaAfterFullCode': 'only test fallback controls; all production SHA unchanged; fresh CODE supplement approved',
    'actualRed': {'files': 3, 'total': 44, 'pass': 10, 'fail': 34, 'pending': 0},
    'failedGreenRetained': 'green-r1 43/44 failed because test used wrong coordinator report field; original coordinator unchanged; actual 5s default/log/report corrected before green-r2',
    'fallbackContrast': {'oldActualMainCommit': freeze['baseCommit'], 'selected': 2, 'pass': 1, 'fail': 1, 'otherMainCasesExcludedOnlyForCausalContrast': 34, 'failure': 'old raw producer resolves ok:true instead of rejecting corrupt status getter', 'wholeQualificationUsesAllCases': True, 'noLiveBridgeFallbackClaim': True},
    'wholeRelated': {'files': 69, 'total': 780, 'pass': 780, 'fail': 0, 'pending': 0},
    'strict': [{'config': x['config'], 'sourceCount': x['sourceCount'], 'diagnostics': 0, 'noCheck': False} for x in strict['results']],
    'governance': {'lintScanned': 1699, 'oldLint': 4, 'newLint': 0, 'architectureScanned': 1553, 'oldArchitecture': 157, 'newArchitecture': 0, 'baselineChanged': False, 'currentSixTestsLint': 'signin-test-lint-r3-process.json'},
    'nativeComponent': {'actualElectron': True, 'cases': 5, 'ownedSuccess': 3, 'unownedDenied': 2, 'shellCalls': 3, 'gateOutstanding': 0, 'surrogateShellOnly': True, 'realBrowserOrCredentialsOrInstalledUi': False},
    'reviewNarrativeCorrections': 'code-review-wording-correction-r1.json; raw verdict retained, prose does not override raw receipts',
    'allOwnProcesses': len(audit), 'parentComplete': False, 'masterMerged': False, 'platformInterruptedTasksNotRetried': True,
    'allOriginalPopulationsDeadlinesFailuresAndParentGatesRetained': True,
    'conditionalMergeAuthorizedAfterAllOriginalWork': True,
    'nextOrdinaryGroup': 'automations config3 preflight/design only; no production or count increment',
}
write('mobile-signin-component-final-r1.json', final)
previous = r / '.artifacts/unfinished-closure-20261001/parent-complete-acceptance-queue-service-control-20261012-kk-r1.json'
queue = json.loads(previous.read_text())
assert queue['currentQualifiedOriginalIpc']['accepted'] == 213 and queue['parentComplete'] is False
remaining = queue['continuationServiceControlKk20261012']['currentOriginalRemainingChannels'].copy()
assert len(remaining) == 85
remaining.remove('desktop:mobile:openRelaySignIn')
assert len(remaining) == 84
queue['previousRecord'] = str(previous)
queue['previousRecordSHA'] = digest(previous)
queue['currentQualifiedOriginalIpc'] = {'accepted': 214, 'total': 298, 'remaining': 84, 'ipc': 76, 'main': 8, 'proxy': 0, 'source': str(e / 'mobile-signin-component-final-r1.json')}
queue['continuationMobileSignInKk20261012'] = {'at': final['at'], 'inheritsCompletePreviousQueue': str(previous), 'component': str(e / 'mobile-signin-component-final-r1.json'), 'increment': 1, 'currentOriginalRemainingChannels': remaining, 'parentComplete': False, 'masterMerged': False, 'allOriginalAcceptanceInherited': True, 'platformInterruptedTasksNotRetried': True, 'next': final['nextOrdinaryGroup'], 'conditionalUserMergeAuthorization': 'after ALL original unfinished work completes, merge latest trunk and test'}
(previous.parent / 'parent-complete-acceptance-queue-mobile-signin-20261012-kk-r1.json').write_text(json.dumps(queue, indent=2))
print(json.dumps({'accepted': 214, 'remaining': 84, 'whole': '69/780', 'ownGroupsReapedGone': len(audit), 'parentComplete': False, 'masterMerged': False}))
