import { app, BrowserWindow, ipcMain, screen } from 'electron';
import { writeFile } from 'node:fs/promises'; import { join, dirname } from 'node:path'; import { fileURLToPath } from 'node:url';
import { ShutdownAwareIpcMain, DesktopShutdownGate } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import { isTrustedDesktopRendererUrl, buildBrowserWindowOptions } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import { createMeetingRecorderWindowController } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import { registerMobileSignInIpc } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/mobile-signin-typed-ipc.js";
import { createMobileRelaySignInOwner } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/mobile-relay-signin.js";
import { captureIpcData } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/ipc-data-snapshot.js";
import { captureMobileRelayStatus } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/mobile-readonly-typed-ipc.js";
const __dirname = dirname(fileURLToPath(import.meta.url)), root = "/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-mobile-signin-probe-1DqyLA", rendererFile = "/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-mobile-signin-probe-1DqyLA/desktop/dist/renderer/index.html";
app.setPath('userData', join(root, 'electron-user-data')); let mainWindow = null, meetingRecorderController = null;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

const gate = new DesktopShutdownGate(), shutdownAwareIpc = new ShutdownAwareIpcMain(ipcMain, gate, authorizeDesktopInvoke);
let shellCalls = 0;
const loadMobileRelayConfig=()=>({relayUrl:'wss://owned.invalid/ws',relayJwt:'owned-surrogate-jwt'}), shell={openExternal(url){ if(url!=='https://owned.invalid/auth/login')throw Error('invalid_signin_target'); shellCalls++;return Promise.resolve(undefined); }}, debugMain=()=>{};
const mobileRelayConfig = loadMobileRelayConfig();
let latestMobileRelayStatus = mobileRelayConfig
    ? {
        running: false,
        connected: false,
        relayUrl: mobileRelayConfig.relayUrl,
        roomId: '',
        lastError: null,
        credentialState: 'ok',
        requiresUserReauth: false,
    }
    : {
        running: false,
        connected: false,
        relayUrl: '',
        roomId: '',
        lastError: 'no relay credentials found; sign in to enable mobile access',
        credentialState: 'missing',
        requiresUserReauth: true,
    };
const mobileSignInOwner = createMobileRelaySignInOwner({
    getRelayUrl: () => {
        try {
            return mobileRelayConfig
                ? captureIpcData(mobileRelayConfig, 'mobile_signin_operation_unknown').relayUrl
                : captureMobileRelayStatus(latestMobileRelayStatus).relayUrl;
        }
        catch {
            throw Error('mobile_signin_operation_unknown');
        }
    },
    openExternal: url => shell.openExternal(url),
    onOpened: () => debugMain('mobile-relay:sign-in-opened', { targetKind: 'relay-auth-login' }),
});

const mobileSignInProducers = new Map([
    ['desktop:mobile:openRelaySignIn', () => mobileSignInOwner.open('user')],
]);
registerMobileSignInIpc(shutdownAwareIpc, mobileSignInProducers);

const options = buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs", { platform: process.platform });
const results = [], methods = ['openMobileRelaySignIn'];
const invoke = async (role, window) => { for (const method of methods) results.push({ role, method, reply: await window.webContents.executeJavaScript('window.xiaokDesktop.' + method + '().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))') }); };
const verify = (condition, code) => { if (!condition) throw Error(code); };
app.whenReady().then(async () => { try {
  mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile);
  meetingRecorderController = createMeetingRecorderWindowController({ BrowserWindow, getMainWindow: () => mainWindow, notificationPort: { show: async () => ({ ok: true }) }, platform: process.platform, preloadPath: "/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs", rendererFile, screen });
  await invoke('main', mainWindow); await meetingRecorderController.open({ collectionId: 'owned-native-signin' });
  const recorder = BrowserWindow.getAllWindows().find(window => meetingRecorderController.ownsWebContents(window.webContents)); verify(!!recorder, 'actual_recorder_missing'); await invoke('recorder', recorder);
  const unknown = new BrowserWindow({ ...options, show: false }); await unknown.loadFile(rendererFile); await invoke('unknown-same-url', unknown);
  const old = mainWindow; mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile); await invoke('old-main', old); await invoke('replacement-main', mainWindow);
  for (const row of results) {
    if (['main', 'recorder', 'replacement-main'].includes(row.role)) {
      verify(row.reply.ok, row.role + ':' + row.method);
      verify(row.reply.value.ok === true && row.reply.value.url === 'https://owned.invalid/auth/login','signin_reply_changed');
    } else verify(!row.reply.ok && row.reply.error.includes('desktop_user_sender_forbidden'), 'unowned_mobile_admitted');
  }
  verify(shellCalls === 3, 'unowned_sender_reached_shell'); verify(gate.outstanding === 0, 'ipc_token_leak');
  await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/mobile-signin1-20261012-kk-r1/native-signin-r1.json", JSON.stringify({ actualElectron: true, actualProductionAuthorizer: true, actualProductionShutdownOwner: true, actualProductionRecorderController: true, actualProductionPreload: true, actualTypedSignInRegistrar: true, actualMainProducerBody: true, actualSignInOwner: true, ownedTemporaryRendererFixture: true, surrogateShellBoundaryOnly: true, realCredentialsRead: false, installedAppOrWholeUiAccepted: false, protectedNativeAuthorityClaim: false, results, shellCalls, gateOutstanding: gate.outstanding }, null, 2));
  meetingRecorderController.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.quit();
} catch (error) { console.error(error); meetingRecorderController?.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.exit(1); } }).catch(error => { console.error(error); app.exit(1); });
