# Relay 登录打开入口的完整合同

当前正式213/298、剩85；本设计待独立评审，未计数，不批准父任务或主干合并。

实际 Main 的 openRelaySignIn raw handler 从配置/状态派生 URL，已经不是通用 URL bridge；但无零参数tuple/fullDTO校验，void丢弃 shell.openExternal Promise后立即成功，OS打开失败或held动作不在原shutdown token内等待。MobilePane点击回调也是void，不处理失败/结果或busy。normalizeRelayWebSocketUrl仅转换http(s)并补/ws，不限制其它protocol或userinfo/query；字符串replace对带query、hash及自定义scheme可产生错误目标。此项是外部副作用正确性/安全校验，不主张性能收益。

所有同权限invoke（generic file/shell、mobile2、其它raw/typed/proxy）已有唯一Shutdown owner currentMain/currentRecorder/mainFrame/可信URL鉴别。本项沿用两窗口同用户权限域，不收窄Recorder、不另建raw owner；其它通用shell/file API原门仍保留。本票不声称全盘/SDK/agent/OS权限都已关闭；用户自己配置的HTTP(S)域名仍允许，不新增域名白名单或凭证续期业务。

共享contract：原channel desktop:mobile:openRelaySignIn，tuple([])；结果为全量passthrough判别union：{ok:true,url:string} 或 {ok:false,error:'relay_url_unknown'|'relay_url_invalid'}。旧unknown结果保留；invalid是派生目标不安全/无法解析的确定失败。shell失败/不合规返回值/异常/未知操作仍reject mobile_signin_operation_unknown或原producer异常，不resolve成成功error envelope。

Main新private应用UI owner/facade，open(requestSource)显式来源，缺失/agent/scheduler在读事实/外部副作用前default deny。来源仅由真实Main handler在公共鉴别后注入'user'，不能从IPC传。getRelayUrl读取配置前用captureIpcData捕获配置完整data；无config时用已审captureMobileRelayStatus捕获status后读relayUrl，不执行getter/proxy，不把敏感JWT写日志/wire。只把选出的URL标量交owner，不自动登录、不读取新credentials、不刷新JWT。

URL标量只接受非空string。空或缺失返回原unknown；其它类型/malformed/非ws,wss,http,https/userinfo/query/hash返回invalid并且零shell。用URL解析把ws→http、wss→https，http(s)保持，精确组合：prefix=url.pathname.replace(/\/+$/,'').replace(/\/ws$/,'')；url.pathname=`${prefix}/auth/login`。拒绝path内部含双斜杠的目标。/ws、/ws/、/都得/auth/login；/prefix/ws得/prefix/auth/login；/wsx得/wsx/auth/login，pathname恰一个/auth/login且无//。成功URL最后再经已审isAllowedShellExternalUrl检查http/https，不添加域名白名单。不把query/hash/用户名密码带到外部浏览器，也不静默截断含凭证target。所有输出URL由Main事实派生，renderer不提供target。

一Main owner singleflight：user source检查先于复用；正在打开时复用同一原操作Promise，不新开浏览器，不再读事实；fulfill/reject两路均清pending（各有回归），下一次用户明确点击可新开。每个invoke在registrar重新capture DTO，不共享可变返回对象；pending仅共享原操作，不是caller授权。shell边界与DTO构造分离：先assertStandardIpcPromise返回值（不允许isPromise短路接受非Promise），再captured intrinsic then等待，解析值必须严格===undefined，否则mobile_signin_operation_unknown；只有此后才用Main已校验URL标量构造{ok:true,url}。registrar单独capture+safeParse DTO。shell异常拒绝不制造ok:true。仅等待shell请求实际返回，ok:true不代表用户已经登录或JWT已更新。每个已准入invoke原shutdown token直到同一操作settle才释放，窗口销毁不提前释放；close后新调用拒绝，UI不取消业务或重新发送。

模块导出createMobileRelaySignInOwner工厂给Main创建唯一实例；AST编译的真实constructor指ShutdownAwareIpcMain及其Main绑定。新增独立shared/mobile-signin-ipc-contract.ts、electron/mobile-signin-typed-ipc.ts与Main mobileSignInProducers map，不并入MOBILE_READONLY族（原恰两条/round27测试不变）。typed registrar绑定真实Main producer map，替换并删除唯一raw注册，幂等/owner冲突、input/output capture+safeParse直接throw，防止production通用runtime错误信封当ACK；标准nativePromise/constructor/species守卫，getter/proxy/serializer/thenable拒绝。riskTags固定['shell-open']、sourceFile为desktop/electron/mobile-signin-typed-ipc.ts，registry测试核round29/tuple/tags。round29同步ipc-runtime两处联合类型；两具名census ipc-schema-coverage.test.ts/currentViewChannels 与 preload-contract.test.ts/extractRegisteredHandlerChannels执行新真实registrar，所有原断言保。TS/CJS原语义零参数ABI不变，TS结果type关联共享schema、rendererbridge转发一致。

MobilePane新增action-only lifetime/ref singleflight（不绑locale/read revision），只有显式点击执行，busy禁登录按钮。失败结果/throw都显示当前t本地化登录打开失败，unknown错误对象message不读；renderer对undefined/null/非对象/缺ok/缺成功url一律按失败处理，不依赖读取.ok制造TypeError；现有mobile-readonly-consistency点击正面用例mock改为合规{ok:true,url}并act等待，原调用次数与其余全部notCalled断言保留。成功只清action错误，不修改relay credentialState/pairing/QR。locale改变正在进行的动作仍busy，错误kind由当前t展示；卸载使旧回执失效而非取消shell。现有mobile2只读重试不会调用该动作；配对刷新/状态事件不能清登录动作失败；无自动mutation重试。locales三文件同步。

先独立DESIGN→真实入口RED→production。Main AST编译真实constructor/authorize/注册和真实owner/registrar，shell mock仅不可打开真实外部浏览器的边界（明确不是OS打开/实际登录证明）。控制合法Main/Recorder、unknown同URL/旧Main/subframe在输入getter/事实/shell前拒绝，零args/extra、配置getter与fallback statusgetter、原URL派生、ws/wss/http/https/prefix与恶意scheme/userinfo/query/hash、空URL、held/reject/nativePromiseconstructor getter、void malformed、singleflight和真实token/drain；实际MobilePane测试点击、失败DTO/throw、busy双击、locale/unmount、只读不触发/不清action错误及不伪credential更新。保原mobile2/relay/credentials/gateway/通用owner/preload/schema/service-control等完整相关回归，完整实际Main/renderer strict、新testlint、governance/changed、两实际build、fresh独立CODE后本条才加1至214。

所有原父条件完整继承service-control后继队列：298、176、351、99原15s/300s/3600s、14/Loop13、84paired、50/100/512MiB、全部writers/history/principals/migration/restart/retirement/adopt、Windows protectedNTFS/正常macOS安装、真实UI/TTY、同版无签名包/安装/运行/下载、latestmain与精确提交/liveCI；不增时限、减人口、改baseline或挑绿。原native/material/P4平台中断不改写重试。仅全部完成后按用户已授权条件合并主干并测试，普通操作不再次确认。

## R1 BLOCK 修正与细化

上文补齐shell Promise<void>→Main DTO的严格顺序、规范路径组合、renderer不合规结果与旧测试mock、独立新模块/注册/risk tags/每invoke detach。补充约束如下。

- 原生产ordinaryCleanupDeadlineMs未传，实际5秒界限保持。shell永不settle时原token仍未释放，协调器到5秒报告shutdown_ordinary_cleanup_timeout并store_close_deferred_to_process_exit；不能伪称清理完成、ok:true或自行延时、卸载释放token。测试真实DesktopShutdownCoordinator+gate、self held shell Promise、原5秒fake-clock推进核原失败报告和continuation，再释放仅测试自有Promise/await所有held任务；这不是OS浏览器完成或parent native资格。
- invalid/unknown路径不记录raw/derived URL，只可固定reason code；成功路径保留mobile-relay:sign-in-opened事件，字段仅targetKind:'relay-auth-login'，不记录URL、JWT或其它owner事实。shell错误日志也不能读任意Error.message或URL。
- 完整reject codes：mobile_signin_input_invalid、mobile_signin_operation_unknown、mobile_signin_request_source_forbidden、mobile_signin_runtime_unavailable、mobile_signin_registrar_owner_conflict；公共shutting_down/desktop_user_sender_forbidden不改。Main配置或fallback status capture故障统一转换mobile_signin_operation_unknown，无message/getter读取，不制造成功。业务unknown/invalid为确定失败DTO。
- config为null时实际无relay bridge，状态初始化missing+relayUrl空；fallback保旧表达式语义与防御边界，但不能把人为设置status的控制当生产活跃relay路径证明。没有新credential读或normalizer业务变更。
- shell无法完成/异常/unknown返回会让动作在5秒清理时限到达后转交既有进程退出路径；这是不伪造完成的限制，不是新增无限shutdown等待。成功也仅打开请求完成，不表示JWT重认证。
