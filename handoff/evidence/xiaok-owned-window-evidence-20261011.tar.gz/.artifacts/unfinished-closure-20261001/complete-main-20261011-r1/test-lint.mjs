import {checkLint} from '../../../scripts/governance/lint.mjs';
import {writeFileSync} from 'node:fs';
const result=checkLint({paths:["desktop/tests/main/desktop-invoke-admission.test.ts", "desktop/tests/main/ipc-registrar-contract.test.ts", "desktop/tests/main/meeting-service-permissions.test.ts"]});writeFileSync(process.argv[2],JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({files:result.files,diagnostics:result.diagnostics,newViolations:result.newDiagnostics.length}));process.exitCode=result.newDiagnostics.length?1:0;
