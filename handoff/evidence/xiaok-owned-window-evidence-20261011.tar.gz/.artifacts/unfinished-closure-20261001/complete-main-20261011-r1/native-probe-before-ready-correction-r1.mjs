import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {readFile,writeFile,rm} from 'node:fs/promises';import {join,dirname} from 'node:path';import {fileURLToPath} from 'node:url';import {compileFunction} from 'node:vm';import {extname} from 'node:path';
import {ShutdownAwareIpcMain,DesktopShutdownGate} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import {isTrustedDesktopRendererUrl,buildBrowserWindowOptions} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import {createMeetingRecorderWindowController} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
const __dirname=dirname(fileURLToPath(import.meta.url)), root="/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-native-invoke-GP8Ga5", rendererFile="/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-native-invoke-GP8Ga5/desktop/dist/renderer/index.html", file="/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-native-invoke-GP8Ga5/owned-surrogate.json", output="/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/complete-main-20261011-r1/native-admission-results-r1.json";
app.setPath('userData',join(root,'electron-user-data'));let mainWindow=null,meetingRecorderController=null;let reads=0;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

import {registerIpcHandler} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/ipc-runtime.js";
import {filePathInput,readFileResult} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/file-ipc-schemas.js";
const gate=new DesktopShutdownGate(), ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke);
compileFunction("const DATA_URL_MIME_BY_EXTENSION = new Map([\n    ['.pdf', 'application/pdf'],\n]);\nfunction getDataUrlMimeType(filePath) {\n    return DATA_URL_MIME_BY_EXTENSION.get(extname(filePath).toLowerCase()) ?? null;\n}\nconst fileHandler = (channel, input, output, riskTags, handler, rolloutRound = 1) => registerIpcHandler({\n    registrar: ipcMain, channel, input, output, riskTags, sourceFile: 'desktop/electron/ipc.ts', rolloutRound, handler,\n});\nfileHandler('desktop:readFileContent', filePathInput, readFileResult, ['fs-read'], async (input) => {\n    const filePath = input?.filePath;\n    log('info', 'readFileContent', { filePath });\n    try {\n        const dataUrlMimeType = getDataUrlMimeType(filePath);\n        if (dataUrlMimeType) {\n            const content = await readFile(filePath);\n            return { content: `data:${dataUrlMimeType};base64,${content.toString('base64')}` };\n        }\n        const content = await readFile(filePath, 'utf-8');\n        return { content };\n    }\n    catch (e) {\n        return { content: '', error: String(e) };\n    }\n});\n",['ipcMain','registerIpcHandler','filePathInput','readFileResult','extname','readFile','log'])(ipc,registerIpcHandler,filePathInput,readFileResult,extname,(...args)=>{reads++;return readFile(...args);},()=>{});
const options=buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",{platform:process.platform});
const results=[];const invoke=async win=>win.webContents.executeJavaScript('window.xiaokDesktop.readFileContent('+JSON.stringify(file)+').then(value=>({ok:true,content:value.content}),error=>({ok:false,error:String(error)}))');
const validate=(condition,reason)=>{if(!condition)throw Error(reason);};
try{await app.whenReady();mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:"/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",rendererFile,screen});
results.push({role:'main',reply:await invoke(mainWindow)});await meetingRecorderController.open({collectionId:'owned-native'});
const recorder=BrowserWindow.getAllWindows().find(w=>meetingRecorderController.ownsWebContents(w.webContents));validate(!!recorder,'real_recorder_missing');results.push({role:'recorder',reply:await invoke(recorder)});
const unknown=new BrowserWindow({...options,show:false});await unknown.loadFile(rendererFile);results.push({role:'unknown-same-url',reply:await invoke(unknown)});
const old=mainWindow;mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);results.push({role:'replaced-main',reply:await invoke(old)});results.push({role:'replacement-main',reply:await invoke(mainWindow)});
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role))validate(row.reply.ok&&row.reply.content==='owned-native-surrogate',row.role);else validate(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),row.role);}
validate(reads===3,'denied_sender_reached_io');validate(gate.outstanding===0,'token_not_released');
await writeFile(output,JSON.stringify({actualElectron:true,actualProductionAuthorizerBody:true,actualProductionShutdownOwner:true,actualProductionRecorderController:true,actualProductionPreload:true,ownedTemporaryRendererFixture:true,actualFsRead:true,actualProductionReaderBody:true,realCredentialsRead:false,installedAppOrWholeUiAccepted:false,results,reads,gateOutstanding:gate.outstanding},null,2));
meetingRecorderController.dispose();for(const win of BrowserWindow.getAllWindows())win.destroy();await rm(root,{recursive:true,force:true,maxRetries:5,retryDelay:50});app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const win of BrowserWindow.getAllWindows())win.destroy();await rm(root,{recursive:true,force:true,maxRetries:5,retryDelay:50});app.exit(1);}
