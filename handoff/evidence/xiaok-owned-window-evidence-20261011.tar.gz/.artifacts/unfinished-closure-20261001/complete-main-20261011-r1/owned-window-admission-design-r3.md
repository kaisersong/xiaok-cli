# Desktop invoke 的应用窗口鉴别

## 父范围与用户指示

用户明确：全部开发完成后合并主干进行测试。当前原 IPC 209/298，父完整验收未完成，不能现在合并。原176消费者、351测试文件、99签名链及15s/300s/3600s、14/Loop13、84paired、largebytes、全部writer/history/retirement、实际OS/UI/安装/包、最新main/提交/CI门都保留。本设计只处理 Electron invoke 的调用窗口来源，不重试此前平台中断的 native/material/performance 候选；不发行它们的授权票。

## 读码事实与需要先量的反例

`main.ts:180` 的 ShutdownAwareIpcMain 是唯一实际 raw ipcMain owner，全部生产 registrar 使用其窄接口。`shutdown-aware-ipc-main.ts:handle` 先取得原 shutdown token，再直接调用 listener，没有通用窗口/主frame/页面来源鉴别。各领域存在专用门但不覆盖全部通道。

配对实际含 mobileAccessToken（deepLink）、relayJwt 和 room secret。mobile raw2 尚无鉴别；通用 `ipc.ts:1175` readFileContent 只验证 absolute path，直接 readFile。只保护两个 mobile RPC 仍可从同权限文件读取绕过，不能称完整关闭。通用 save/open 等也在同一个 fileHandler 中；仅列一条 reader 不是完整同权限领域。

source census 的生产 Electron 窗口只有 current Main 与 meetingRecorderController 管理的 current Recorder（Main initial/replacement 两函数创建同一个逻辑 Main，不是新增 IPC owner）。Recorder 通过相同 preload.cjs 和 renderer/index.html 的 hash route `/meeting-recorder/...` 启动。`renderer/main.tsx` 对 Recorder 也挂全部 Auth/Locale/Theme/Appearance/ThreadList/KSwarm providers；KnowledgePage 使用正常知识库、ASR、录音等 RPC。不能把 Recorder 全部需求缩成它独有的5个生命周期命令，否则会破坏正常创建/录音/保存链。

既有 `security.ts:isTrustedDesktopRendererUrl` 严格比较 renderer file 或 dev-server URL，仅忽略 hash；Main multiAgentAuthorize 已真实复用同样的主frame/URL规则。不是允许任意 file: 或127.0.0.1 URL。

实施前先在 owned temp file 和纯自有 surrogate pairing 信息上调用真正 ShutdownAwareIpcMain + 真正生产 reader：证明未授权 sender 能进入 reader，admission callback 在当前2参 constructor 中实际未执行。禁止读取本机真实凭证、打开系统应用、启动真人网络/录音或把 fixture 当OS身份票。原作用域、时限和失败保留。

## 最小合同

给 ShutdownAwareIpcMain 增加第三个可选、同步 `(event) => void` admission callback。生产 Main 唯一 constructor 必须传真正的 Main 私有鉴别函数；原非生产/独立unit constructor 两参兼容，不作为生产授权证明。

每次 handler：原 gate.acquire → try 中同步鉴别 → 原 listener/await → 原 finally release。gate closed 优先保原 shutting_down；拒绝或鉴别 throw 也释放 token，payload/schema/producer 前零作用。admission 返回任何非 undefined 值拒绝固定 `desktop_invoke_authority_invalid`，不 await Promise、不将 true/false/null/thenable 视为 grant，不读返回值 getter。生产函数只成功 return undefined 或抛固定 `desktop_user_sender_forbidden`，不接受 wire grant/source/windowId。

Main 鉴别每次 fresh 检查：sender 存在且未 destroyed；senderFrame 存在且严格等于 sender.mainFrame；当前窗口事实是非 destroyed current Main 的同一 webContents，或 controller 当前 ownsWebContents(sender) 真；frame.url 必须通过既有精确 trusted-renderer helper。任意陌生窗口、旧Main replacement、已关Recorder、subframe、相同host但不同页面、任意本地HTML都拒绝。页面/窗口 getter 因 teardown 抛错也失败，不制造成功或默认授权。rendererFile 用 path.join 推导；devServer 取和既有 createInitial/replacement 相同的 Main 环境配置，不由 wire 指定。

Main 与 Recorder 是同一个用户拥有的应用 UI 权限域：公共读/配置/文件API仍允许两者；后继 mobile2 的敏感配对读取也必须遵循这一一致域，不虚称“只准Main读取秘密”而又准Recorder任意读取文件。既有每channel更细角色门照旧：例如 only-Main openRecorder/Updater，only-Recorder 五命令，MultiAgent/Publication 的来源/权限/生命周期仍不放宽。

该门包住唯一 raw owner 的所有注册，覆盖通用 fileHandler、全部 raw/typed/semantic/proxy invoke；不会因新增channel漏保护，不手工编制298条可绕过的列表。没有改渠道名、tuple/DTO、IPC计数、mutation权限、source authorizer、scheduler/poll owner 或durable schema。这个共同事实也不声称 trusted renderer/任意Node代码的文件沙箱、workspace路径约束或 native授权已完成。

## 必要验证与验收

独立 DESIGN APPROVE 后测试先行：真实 Main AST 提取鉴别函数，与真正 ShutdownAwareIpcMain、真正 registerIpcHandler/生产 readFileContent body 串接。原版未执行第三callback应真实 RED（reader仍读 surrogate）；新鉴别函数缺口也须诚实区分 missing-entry 与业务反例，不能只有 mock predicate 自证。新完整case涵盖 Main/Recorder/hash/dev正常、unknown/destroyed/current replacement/subframe/URL误匹配/Recorder retired、payload getter零读、非void callback不授权、throw/gateClosed/held原 token physical drain。

同权限兄弟测试包括任意新注册channel及 file reader/save/open/backup/revert/cleanup/watch/unwatch、clipboard与save dialog的实际 owner 外壳。调用拒绝时确认原真实IO/adapter无调用，不用测试版重新实现权限逻辑。正常 Main+Recorder 回归不裁provider/Knowledge/ASR/录音保存要求；原 Recorder6、Meeting6、Knowledge10、file8及原shutdown/owner全部人口保留。真实 Electron 两应用窗口 invoke、同版 Main/renderer严格/Gov/实际build、fresh独立CODE分别留证，unit/source票不替代实际UI/平台/安装层。

本共同门新增 typed IPC 计数0。仅它正式CODE后继续原 mobile readonly2 的完整输出/input/事件/UI/权限合同，不提前把2或其他89项算完。不以这一底座替代每个原IPC全组件的CODE与全部父验收。

## R3：接受 R2 独审 BLOCK 的生产绑定证明

`owned-window-admission-design-r2.log` 的 BLOCK 正确：原 `ipc-registrar-contract.test.ts:47-53` 固定生产两参 constructor，且原全部 owner 用例必须保留。只证明 callback 能鉴别，不足以证明生产绑定；不删除这项测试、raw-owner 数量断言或缩其人口。

生产使用明确的 Main module 私有 `function authorizeDesktopInvoke(event: Electron.IpcMainInvokeEvent): void`。唯一真实 constructor 精确传第三参数这个标识符，不是 undefined/空lambda/inline虚假grant。该函数声明 module-scope hoisted，constructor 创建时只捕获函数而不调用；实际 invoke 才 fresh 读取 `mainWindow`/`meetingRecorderController` 的 module let。不在构造阶段读取尚未初始化的窗口，不捕获 first Main，不使用 bootstrap 函数局部变量；每次以 `join(__dirname, '../../../renderer/index.html')` 和同一 Main `process.env['XIAOK_DESKTOP_DEV_SERVER']` 配置推导当前 trusted URL。

先写增强的原 owner case：用真正 TypeScript AST 找 module 顶层唯一 ShutdownAwareIpcMain constructor，核它的三个实参分别为原 ipcMain、原 desktopShutdownGate、真实 authorizeDesktopInvoke；核同一 module 顶层 FunctionDeclaration 同名、非 export、不是空函数，并与行为测试实际提取的同一函数 body 绑定。必须核真实 gate 中调用同一 admission 函数、没有 SourceWire 提供授权的通道；源码静态生产绑定与行为测试两层共同验收。原“其他模块不能 import raw Electron ipcMain”、所有 registrar narrow type、callback signatures、整个原用例继续保持。

原 main 中 `\bipcMain\b` token count 为2（Electron import及唯一构造参数），新增鉴别函数不引用 raw ipcMain，该计数仍必须精确2，不能改宽；原 constructor regex 改为严格三参命名函数形式，并用上述 AST 加强。原测试名/断言人口保留且加关键绑定/真实 body 断言，不换成弱 `includes()` 或只观察测试自己的 fake instance。旧测试 before、设计批准、原版 RED、新实现 GREEN 和 source SHA 均保留。
