import {readFileSync,writeFileSync,mkdtempSync,rmSync} from 'node:fs';
import {readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,extname} from 'node:path';
import {compileFunction} from 'node:vm';
import ts from '../../../desktop/node_modules/typescript/lib/typescript.js';
import {ShutdownAwareIpcMain,DesktopShutdownGate} from '../../../desktop/electron/shutdown-aware-ipc-main.ts';
import {registerIpcHandler,resetIpcSchemaRegistryForTests} from '../../../desktop/electron/ipc-runtime.ts';
import {filePathInput,readFileResult} from '../../../desktop/electron/file-ipc-schemas.ts';
const source=readFileSync(new URL('../../../desktop/electron/ipc.ts',import.meta.url),'utf8');
const ast=ts.createSourceFile('ipc.ts',source,ts.ScriptTarget.Latest,true);let fileHandler='',reader='',mime='',map='';
function visit(node:ts.Node){
 if(ts.isVariableDeclaration(node)&&node.name.getText(ast)==='fileHandler')fileHandler='const '+node.getText(ast)+';';
 if(ts.isVariableDeclaration(node)&&node.name.getText(ast)==='DATA_URL_MIME_BY_EXTENSION')map='const '+node.getText(ast)+';';
 if(ts.isFunctionDeclaration(node)&&node.name?.getText(ast)==='getDataUrlMimeType')mime=node.getText(ast);
 if(ts.isExpressionStatement(node)&&ts.isCallExpression(node.expression)&&node.expression.expression.getText(ast)==='fileHandler'&&node.expression.arguments[0]?.getText(ast)==="'desktop:readFileContent'")reader=node.getText(ast);
 ts.forEachChild(node,visit);
}visit(ast);if(!fileHandler||!reader||!mime||!map)throw Error('production_selection_missing');
const code=ts.transpileModule([map,mime,fileHandler,reader].join('\n'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
const root=mkdtempSync(join(tmpdir(),'xiaok-owned-admission-char-'));const path=join(root,'surrogate-identity.json');const surrogate=JSON.stringify({desktopId:'owned-surrogate',mobileAccessToken:'owned-surrogate-only'});writeFileSync(path,surrogate);resetIpcSchemaRegistryForTests();let authCalls=0,reads=0;const gate=new DesktopShutdownGate();const listeners=new Map();
const registrar=Reflect.construct(ShutdownAwareIpcMain,[{handle:(channel:string,listener:unknown)=>listeners.set(channel,listener)},gate,()=>{authCalls++;throw Error('owned_denied');}]);
try{
 compileFunction(code,['ipcMain','registerIpcHandler','filePathInput','readFileResult','extname','readFile','log'])(registrar,registerIpcHandler,filePathInput,readFileResult,extname,(...args:Parameters<typeof readFile>)=>{reads++;return Reflect.apply(readFile,undefined,args);},()=>{});
 const result=await listeners.get('desktop:readFileContent')({sender:{id:'unowned-surrogate'}},{filePath:path});
 const receipt={actualProductionSource:true,actualShutdownOwner:true,actualReaderBody:true,actualFsRead:true,sourceReimplementation:false,realCredentialsRead:false,ownedTempOnly:true,actualReturnedOwnedSurrogate:result.content===surrogate,admissionCalls:authCalls,actualReads:reads,tokenOutstandingAfter:gate.outstanding,expectedBeforeFix:'current constructor ignores third callback, unauthorized caller reaches same-domain file reader'};
 if(!receipt.actualReturnedOwnedSurrogate||authCalls!==0||reads!==1||gate.outstanding!==0)throw Error('characterization_changed');
 writeFileSync(process.argv[2],JSON.stringify(receipt,null,2),{flag:'wx'});console.log(JSON.stringify(receipt));
}finally{rmSync(root,{recursive:true,force:true});}
