import { app, BrowserWindow, ipcMain, screen } from 'electron';
import { writeFile } from 'node:fs/promises'; import { join, dirname } from 'node:path'; import { fileURLToPath } from 'node:url';
import { ShutdownAwareIpcMain, DesktopShutdownGate } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import { isTrustedDesktopRendererUrl, buildBrowserWindowOptions } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import { createMeetingRecorderWindowController } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import { registerMobileReadonlyIpc } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/mobile-readonly-typed-ipc.js";
import { buildMobilePairingPayload } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/mobile-gateway.js";
const __dirname = dirname(fileURLToPath(import.meta.url)), root = "/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-mobile-readonly-probe-oVGLB8", rendererFile = "/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-mobile-readonly-probe-oVGLB8/desktop/dist/renderer/index.html";
app.setPath('userData', join(root, 'electron-user-data')); let mainWindow = null, meetingRecorderController = null;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

const gate = new DesktopShutdownGate(), shutdownAwareIpc = new ShutdownAwareIpcMain(ipcMain, gate, authorizeDesktopInvoke);
const latestMobileRelayStatus = { running: true, connected: false, relayUrl: '', roomId: 'owned-native-room', lastError: null, credentialState: 'missing', requiresUserReauth: true };
const mobileRelayConfig = { relayUrl: 'wss://owned.invalid/ws', relayJwt: 'owned-native-surrogate-jwt' };
const mobileIdentity = { desktopId: 'owned-native-desktop', mobileAccessToken: 'owned-native-surrogate-token', mobileRelayRoomSecret: 'owned-native-surrogate-secret', createdAt: 'owned' };
let pairingReads = 0; const mobileGateway = { getStatus() { pairingReads++; return { running: true, host: '0.0.0.0', port: 47891, baseURL: 'http://127.0.0.1:47891', reachableURLs: ['http://192.168.1.2:47891'] }; } };
const mobileReadonlyProducers = new Map([
    ['desktop:mobile:getRelayStatus', () => latestMobileRelayStatus],
    ['desktop:mobile:getPairingInfo', () => buildMobilePairingPayload({
            desktopName: 'Xiaok Desktop',
            identity: mobileIdentity,
            gatewayStatus: mobileGateway.getStatus(),
            relayUrl: mobileRelayConfig?.relayUrl,
            relayJwt: mobileRelayConfig?.relayJwt,
        })],
]);
registerMobileReadonlyIpc(shutdownAwareIpc, mobileReadonlyProducers);

const options = buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs", { platform: process.platform });
const results = [], methods = ['getMobileRelayStatus', 'getMobilePairingInfo'];
const invoke = async (role, window) => { for (const method of methods) results.push({ role, method, reply: await window.webContents.executeJavaScript('window.xiaokDesktop.' + method + '().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))') }); };
const verify = (condition, code) => { if (!condition) throw Error(code); };
app.whenReady().then(async () => { try {
  mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile);
  meetingRecorderController = createMeetingRecorderWindowController({ BrowserWindow, getMainWindow: () => mainWindow, notificationPort: { show: async () => ({ ok: true }) }, platform: process.platform, preloadPath: "/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs", rendererFile, screen });
  await invoke('main', mainWindow); await meetingRecorderController.open({ collectionId: 'owned-native-mobile' });
  const recorder = BrowserWindow.getAllWindows().find(window => meetingRecorderController.ownsWebContents(window.webContents)); verify(!!recorder, 'actual_recorder_missing'); await invoke('recorder', recorder);
  const unknown = new BrowserWindow({ ...options, show: false }); await unknown.loadFile(rendererFile); await invoke('unknown-same-url', unknown);
  const old = mainWindow; mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile); await invoke('old-main', old); await invoke('replacement-main', mainWindow);
  for (const row of results) {
    if (['main', 'recorder', 'replacement-main'].includes(row.role)) {
      verify(row.reply.ok, row.role + ':' + row.method);
      if (row.method === 'getMobileRelayStatus') verify(row.reply.value.credentialState === 'missing' && row.reply.value.roomId === 'owned-native-room', 'status_changed');
      else { const value = row.reply.value, params = new URL(value.deepLink).searchParams; verify(value.relayJwt === mobileRelayConfig.relayJwt && value.relayRoomSecret === mobileIdentity.mobileRelayRoomSecret && params.get('token') === mobileIdentity.mobileAccessToken && params.get('relayJWT') === mobileRelayConfig.relayJwt && params.get('relayRoomSecret') === mobileIdentity.mobileRelayRoomSecret, 'sensitive_wire_fields_lost'); }
    } else verify(!row.reply.ok && row.reply.error.includes('desktop_user_sender_forbidden'), 'unowned_mobile_admitted');
  }
  verify(pairingReads === 3, 'unauthorized_pairing_producer_read'); verify(gate.outstanding === 0, 'ipc_token_leak');
  await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/mobile-readonly2-20261011-kk-r1/native-mobile-r1.json", JSON.stringify({ actualElectron: true, actualProductionAuthorizer: true, actualProductionShutdownOwner: true, actualProductionRecorderController: true, actualProductionPreload: true, actualTypedMobileRegistrar: true, actualMainProducerBody: true, actualPairingBuilder: true, ownedTemporaryRendererFixture: true, surrogateIdentityOnly: true, realCredentialsRead: false, installedAppOrWholeUiAccepted: false, protectedNativeAuthorityClaim: false, results, pairingReads, gateOutstanding: gate.outstanding }, null, 2));
  meetingRecorderController.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.quit();
} catch (error) { console.error(error); meetingRecorderController?.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.exit(1); } }).catch(error => { console.error(error); app.exit(1); });
