import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd(), desktop = resolve(root, 'desktop');
const ts = (await import(pathToFileURL(resolve(desktop, 'node_modules/typescript/lib/typescript.js')).href)).default;
const sha = value => createHash('sha256').update(value).digest('hex');
const firstReads = new Map();
const read = path => {
  let value;
  try { value = readFileSync(path, 'utf8'); } catch { return undefined; }
  if (!firstReads.has(path)) firstReads.set(path, sha(value));
  return value;
};
const mainTests = ['mobile-gateway', 'mobile-relay', 'mobile-relay-credentials', 'mobile-snapshot', 'mobile-readonly-main-controls', 'mobile-readonly-output-boundary', 'mobile-readonly-preload', 'desktop-invoke-admission', 'ipc-registrar-contract', 'meeting-service-permissions', 'updater', 'updater-handoff', 'updater-integration', 'updater-owner-state', 'updater-source-authority', 'updater-main-controls', 'updater-output-boundary', 'updater-preload', 'preload-contract', 'preload-sandbox', 'plugin-catalog-characterization', 'plugin-catalog-main-controls', 'plugin-catalog-preload', 'ipc-schema-coverage'];
const rendererTests = ['mobile-readonly-consistency', 'sidebar-update-reminder', 'desktop-settings-update-handoff', 'updater-read-failure', 'updater-sidebar-facts', 'plugin-catalog-read-errors', 'plugin-catalog-mcp-read-errors'];
const results = [];
for (const [config, additions] of [
  ['tsconfig.electron.json', mainTests.map(name => resolve(desktop, 'tests/main', name + '.test.ts'))],
  ['tsconfig.renderer.json', [resolve(desktop, 'tests/setup.ts'), resolve(desktop, 'renderer/src/components/settings/PluginsSettings.tsx'), ...rendererTests.map(name => resolve(desktop, 'tests/renderer', name + '.test.tsx'))]],
]) {
  const path = resolve(desktop, config);
  const loaded = ts.readConfigFile(path, read);
  const parsed = ts.parseJsonConfigFileContent(loaded.config, { ...ts.sys, readFile: read }, desktop, {}, path);
  const options = { ...parsed.options, noCheck: false, noEmit: true, incremental: false, allowImportingTsExtensions: config === 'tsconfig.electron.json' };
  const host = ts.createCompilerHost(options); host.readFile = read;
  const roots = [...new Set([...parsed.fileNames, ...additions])];
  const program = ts.createProgram({ rootNames: roots, options, host });
  const diagnostics = [...(loaded.error ? [loaded.error] : []), ...parsed.errors, ...ts.getPreEmitDiagnostics(program)];
  const messages = diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'));
  console.log(config, roots.length, program.getSourceFiles().length, 'diagnostics', diagnostics.length);
  if (diagnostics.length) console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCurrentDirectory: () => root, getCanonicalFileName: path => path, getNewLine: () => '\n' }));
  results.push({ config, rootCount: roots.length, sourceCount: program.getSourceFiles().length, additionalActualTestRoots: additions, options, diagnostics: messages });
}
const reads = [...firstReads].map(([path, before]) => ({ path, before, after: sha(readFileSync(path, 'utf8')) }));
const result = { actualSource: true, virtualOverlay: false, customModuleResolver: false, fullOriginalConfigRoots: true, results, reads, drift: reads.filter(row => row.before !== row.after) };
writeFileSync(process.argv[2], JSON.stringify(result, null, 2), { flag: 'wx' });
process.exitCode = results.some(row => row.diagnostics.length) || result.drift.length ? 1 : 0;
