# Mobile 两个只读入口与配对展示一致性

状态：设计待独立对抗性评审；不提前计入 209/298，不构成父任务完成或主干合并资格。

## 实际问题与边界

Main 当前直接注册 `desktop:mobile:getRelayStatus` 与 `desktop:mobile:getPairingInfo`，没有 tuple 输入或完整输出约束。配对输出包含实际使用的 relayJwt、room secret 与带 mobileAccessToken 的 deepLink，合法用户的这些字段不能删除或改成假值。移动桥、gateway、identity 文件与凭证续期策略仍由 Main 的现有服务拥有。

上轮独立批准的唯一 ShutdownAwareIpcMain owner 已对所有 invoke 验证当前 Main 或 Recorder 实际 webContents、主 frame、生产 renderer URL。两窗口共享同一用户 UI 权限域。未知同 URL 窗口、旧 Main、子 frame 不能通过通用 readFileContent 等同权限兄弟路径读取身份文件。此次沿用该入口，不新增 raw ipcMain owner、不宣称 renderer sandbox 或全盘路径约束。openRelaySignIn 是独立副作用入口，本轮不改业务，不把它计入两个只读入口的验收。

MobilePane 已有读取和手动刷新，但先 setPairing 再 await QRCode，造成旧 QR 和新 deepLink 混用；刷新错误隐藏最后有效二维码；初始错误缺少重试；Error.message 直接显示；held 初始 relay read 可覆盖更新事件；locale 更换或 unmount 后 held read/QR 可以继续发布。现有实现没有解决这些问题。目标是输出校验和展示正确性，不主张性能收益。

## 生产变更

新增共享 mobile-readonly-ipc-contract：两个方法均 z.tuple([])，完整状态与配对对象使用 passthrough 数据 schema；boolean/string/null、credentialState 全五枚举、reachableURLs string[]、optional expires/relay URL/JWT。保持字段的 optional、空字符串与 undefined 原 ABI，不加 URL 格式、日期合法性或字段关联的新业务限制。

新增 Main typed registrar，固定 round 27 和两条实际 mobile channel。绑定同一个 Main 创建的 producer map；重复同 owner 幂等，不同 producer owner 冲突。Main 生产 producer 保留当前 getStatus/buildMobilePairingPayload 调用和 latest status 事实，不捕获异常制造空成功。不新增文件写入、网络请求或后台轮询。

每次 transport capture 使用现有 captureIpcData，先拒绝 proxy、getter、toJSON、函数/符号、循环等不可传输数据，不执行自定义 serializer；schema 校验成功后返回 detached 全量快照，不把 zod 的去字段输出用于 wire。同步值以及标准 native Promise 均可；沿用 assertStandardIpcPromise 和 intrinsic then，拒绝自定义 thenable、Promise 子类与 constructor/species 污染。失败固定 mobile_input_invalid / mobile_projection_unavailable，producer 自身抛出仍 reject，绝不转 `{ok:false}` 成成功状态。Shutdown gate 在 capture/producer 之前完成共同 admission。

relay 状态事件也调用同一全量 capture helper 后 send；非法投影不发送，记录固定代码，不读异常 message。latestMobileRelayStatus 仍持有 owner 原事实：若该事实非法，新的 read reject；UI 保留 last-good 不能假装已读到新成功状态。Main 原 debug 与 reauth 业务保持不变，事件 snapshot 仅边界校验。

preload CJS 与 TS 保持现有语义零参数转发。TS DTO 关联共享 schema infer，renderer 保持语义 bridge 转发。schema coverage 的生产 registrar census 纳入新两条，所有原断言保持。

## Renderer 生命周期

pairing+QR 用一个原子 UI snapshot。每次 effect 生命周期有唯一 generation；同一生命周期最多一个读取/QR 任务，手动刷新中禁用按钮且 ref 同步拒绝重复触发，不自动重试或排队。新 effect（locale 更换/StrictMode remount）创建独立 generation，旧 generation cleanup 即失效，旧任务 finally 不清除新任务的 busy 状态。只有读取和 QR 都成功、generation 仍当前且 mounted 时发布 snapshot。读失败或 QR 失败保留最后有效 snapshot，显示本地化只读失败提示；无 last-good 的初始失败也提供只读重试。异常内容不显示，不能由 refresh 触发 signIn/install/network 业务。copy 仅复制当前已发布 snapshot.deepLink，不会与显示 QR 错配。

relay effect 每次生命周期持有 generation 与 mounted 标记，注册事件后读取；事件到达递增 read revision 并发布完整状态，held read 成功或失败都不能覆盖事件。初始 read 失败显示本地化 unavailable 提示和只读重试；手动 read 单飞，事件到达也可解除可见错误但不提前释放实际任务。cleanup 失效所有 callbacks 并取消订阅。无 durable state、轮询、locale 驱动业务请求或副作用重试。

## 验证与原验收继承

先 RED 后 production：测试从 Main TS AST 编译真实 module admission/constructor 和真实 mobile 注册片段，使用实际 ShutdownAwareIpcMain、registerIpcHandler 与实际 buildMobilePairingPayload（仅本测试拥有的身份字符串）；验证 Main/Recorder、同 URL unknown、旧 Main、子 frame 在 producer 与 payload getter 前拒绝，零副作用及 gate token 释放。完整敏感字段、owner alias detach、invalid tuple、malformed output、proxy/getter/toJSON/thenable/native promise、生产 NODE_ENV 分支都须覆盖。preload 两实现零参数实际 invoke，真实注册 metadata/census 与事件实际 Main callback也必须测试。

渲染实际 DesktopSettings/MobilePane，mock 仅 bridge、QR 异步边界；held read、held QR、刷新失败、locale effect、unmount、双击、relay read/event 排序与 readonly retry 控制。业务 API 反面断言没有 signIn。相关原 mobile gateway/relay/credentials/snapshot、preload、IPC/owner、renderer 回归全部保留；完整 strict Main/renderer configs、治理、增量架构、实际两侧 build、独立 CODE 审查通过后才可组件计数 +2。

父任务的 298 人口、176 consumers、351 broad files、99 signed-chain 原 deadline、14 与 Loop13 性能、84 paired、50/100/512MiB、各平台真正安装/原生读者/全部 writer、UI/TTY、无签名打包、latest-main 和 live CI 原条件全部继承。历史中断的 native/material-firstwrite/performance 不换名字重试；本轮普通 Mobile 功能验证不取代任何上述 gate。全部满足之后才按用户条件合并主干并测试。
