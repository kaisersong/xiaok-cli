import ts from '../../../desktop/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const repo = process.cwd(), evidence = dirname(fileURLToPath(import.meta.url));
const source = readFileSync(join(repo, 'desktop/electron/main.ts'), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
const auth = ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'authorizeDesktopInvoke');
let producers = '', registration = '';
const visit = node => {
  if (ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => declaration.name.getText(ast) === 'mobileReadonlyProducers')) producers = node.getText(ast);
  if (ts.isExpressionStatement(node) && ts.isCallExpression(node.expression) && node.expression.expression.getText(ast) === 'registerMobileReadonlyIpc') registration = node.getText(ast);
  ts.forEachChild(node, visit);
}; visit(ast);
if (!auth || !producers || !registration) throw Error('actual_mobile_entry_missing');
const transpile = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const root = realpathSync(mkdtempSync(join(tmpdir(), 'xiaok-mobile-readonly-probe-')));
const dir = join(root, 'desktop/dist/main/desktop/electron'), renderer = join(root, 'desktop/dist/renderer/index.html');
mkdirSync(dir, { recursive: true }); mkdirSync(dirname(renderer), { recursive: true });
writeFileSync(renderer, '<!doctype html><title>Owned Mobile readonly component probe</title><p>Owned Mobile readonly component probe</p>');
const emitted = name => JSON.stringify(pathToFileURL(join(repo, 'desktop/dist/main/desktop/electron', name + '.js')).href);
const preload = JSON.stringify(join(repo, 'desktop/electron/preload.cjs'));
const code = `import { app, BrowserWindow, ipcMain, screen } from 'electron';
import { writeFile } from 'node:fs/promises'; import { join, dirname } from 'node:path'; import { fileURLToPath } from 'node:url';
import { ShutdownAwareIpcMain, DesktopShutdownGate } from ${emitted('shutdown-aware-ipc-main')};
import { isTrustedDesktopRendererUrl, buildBrowserWindowOptions } from ${emitted('security')};
import { createMeetingRecorderWindowController } from ${emitted('meeting-recorder-window')};
import { registerMobileReadonlyIpc } from ${emitted('mobile-readonly-typed-ipc')};
import { buildMobilePairingPayload } from ${emitted('mobile-gateway')};
const __dirname = dirname(fileURLToPath(import.meta.url)), root = ${JSON.stringify(root)}, rendererFile = ${JSON.stringify(renderer)};
app.setPath('userData', join(root, 'electron-user-data')); let mainWindow = null, meetingRecorderController = null;
${transpile(auth.getText(ast))}
const gate = new DesktopShutdownGate(), shutdownAwareIpc = new ShutdownAwareIpcMain(ipcMain, gate, authorizeDesktopInvoke);
const latestMobileRelayStatus = { running: true, connected: false, relayUrl: '', roomId: 'owned-native-room', lastError: null, credentialState: 'missing', requiresUserReauth: true };
const mobileRelayConfig = { relayUrl: 'wss://owned.invalid/ws', relayJwt: 'owned-native-surrogate-jwt' };
const mobileIdentity = { desktopId: 'owned-native-desktop', mobileAccessToken: 'owned-native-surrogate-token', mobileRelayRoomSecret: 'owned-native-surrogate-secret', createdAt: 'owned' };
let pairingReads = 0; const mobileGateway = { getStatus() { pairingReads++; return { running: true, host: '0.0.0.0', port: 47891, baseURL: 'http://127.0.0.1:47891', reachableURLs: ['http://192.168.1.2:47891'] }; } };
${transpile(producers + '\n' + registration)}
const options = buildBrowserWindowOptions(${preload}, { platform: process.platform });
const results = [], methods = ['getMobileRelayStatus', 'getMobilePairingInfo'];
const invoke = async (role, window) => { for (const method of methods) results.push({ role, method, reply: await window.webContents.executeJavaScript('window.xiaokDesktop.' + method + '().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))') }); };
const verify = (condition, code) => { if (!condition) throw Error(code); };
app.whenReady().then(async () => { try {
  mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile);
  meetingRecorderController = createMeetingRecorderWindowController({ BrowserWindow, getMainWindow: () => mainWindow, notificationPort: { show: async () => ({ ok: true }) }, platform: process.platform, preloadPath: ${preload}, rendererFile, screen });
  await invoke('main', mainWindow); await meetingRecorderController.open({ collectionId: 'owned-native-mobile' });
  const recorder = BrowserWindow.getAllWindows().find(window => meetingRecorderController.ownsWebContents(window.webContents)); verify(!!recorder, 'actual_recorder_missing'); await invoke('recorder', recorder);
  const unknown = new BrowserWindow({ ...options, show: false }); await unknown.loadFile(rendererFile); await invoke('unknown-same-url', unknown);
  const old = mainWindow; mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile); await invoke('old-main', old); await invoke('replacement-main', mainWindow);
  for (const row of results) {
    if (['main', 'recorder', 'replacement-main'].includes(row.role)) {
      verify(row.reply.ok, row.role + ':' + row.method);
      if (row.method === 'getMobileRelayStatus') verify(row.reply.value.credentialState === 'missing' && row.reply.value.roomId === 'owned-native-room', 'status_changed');
      else { const value = row.reply.value, params = new URL(value.deepLink).searchParams; verify(value.relayJwt === mobileRelayConfig.relayJwt && value.relayRoomSecret === mobileIdentity.mobileRelayRoomSecret && params.get('token') === mobileIdentity.mobileAccessToken && params.get('relayJWT') === mobileRelayConfig.relayJwt && params.get('relayRoomSecret') === mobileIdentity.mobileRelayRoomSecret, 'sensitive_wire_fields_lost'); }
    } else verify(!row.reply.ok && row.reply.error.includes('desktop_user_sender_forbidden'), 'unowned_mobile_admitted');
  }
  verify(pairingReads === 3, 'unauthorized_pairing_producer_read'); verify(gate.outstanding === 0, 'ipc_token_leak');
  await writeFile(${JSON.stringify(join(evidence, 'native-mobile-r1.json'))}, JSON.stringify({ actualElectron: true, actualProductionAuthorizer: true, actualProductionShutdownOwner: true, actualProductionRecorderController: true, actualProductionPreload: true, actualTypedMobileRegistrar: true, actualMainProducerBody: true, actualPairingBuilder: true, ownedTemporaryRendererFixture: true, surrogateIdentityOnly: true, realCredentialsRead: false, installedAppOrWholeUiAccepted: false, protectedNativeAuthorityClaim: false, results, pairingReads, gateOutstanding: gate.outstanding }, null, 2));
  meetingRecorderController.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.quit();
} catch (error) { console.error(error); meetingRecorderController?.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.exit(1); } }).catch(error => { console.error(error); app.exit(1); });
`;
const script = join(dir, 'native-mobile.mjs'); writeFileSync(script, code); writeFileSync(join(evidence, 'native-mobile-script-r1.mjs'), code, { flag: 'wx' });
writeFileSync(join(evidence, 'native-mobile-script-r1.json'), JSON.stringify({ root, script, renderer, actualAuthorizerSource: auth.getText(ast), actualProducerSource: producers, actualRegistrationSource: registration }, null, 2), { flag: 'wx' });
console.log(script);
