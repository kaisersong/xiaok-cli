import ts from '../../../desktop/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const root = process.cwd(), evidence = dirname(fileURLToPath(import.meta.url));
const manifest = [];
for (const name of ['mobile-gateway', 'mobile-relay', 'mobile-snapshot']) {
  const path = resolve(root, 'desktop/tests/main', name + '.test.ts');
  const before = readFileSync(path, 'utf8');
  const ast = ts.createSourceFile(name + '.ts', before, ts.ScriptTarget.Latest, true);
  let after = before;
  if (name !== 'mobile-snapshot') {
    const edits = [];
    const visit = node => {
      if (ts.isPropertyAssignment(node) && node.name.getText(ast) === 'getSnapshot' && ts.isArrowFunction(node.initializer)) {
        const body = node.initializer.body;
        if (!ts.isParenthesizedExpression(body)) throw Error('unexpected_fixture_shape');
        edits.push({ pos: body.end - 1, text: ' as unknown as MobileSnapshot' });
      }
      ts.forEachChild(node, visit);
    }; visit(ast);
    if (edits.length !== 2) throw Error('unexpected_fixture_population');
    for (const edit of edits.sort((a, b) => b.pos - a.pos)) after = after.slice(0, edit.pos) + edit.text + after.slice(edit.pos);
    after = "import type { MobileSnapshot } from '../../electron/mobile-gateway.js';\n" + after;
  } else {
    const edits = [];
    const visit = node => {
      if (ts.isPropertyAssignment(node) && node.name.getText(ast) === 'userLoopTemplates' && ts.isArrayLiteralExpression(node.initializer)) edits.push({ pos: node.initializer.end, text: " as Parameters<typeof buildMobileSnapshotFromSources>[0]['userLoopTemplates']" });
      ts.forEachChild(node, visit);
    }; visit(ast);
    if (edits.length !== 1) throw Error('unexpected_legacy_template_population');
    for (const edit of edits) after = after.slice(0, edit.pos) + edit.text + after.slice(edit.pos);
    after = "import type { MobileProjectSummary } from '../../electron/mobile-snapshot.js';\n" + after;
    after = after.replace('project => project.name', 'project => (project as MobileProjectSummary).name');
    after = after.replace("function taskSnapshot(input: Partial<TaskSnapshot> & Pick<TaskSnapshot, 'taskId' | 'status' | 'prompt'>)", "function taskSnapshot(input: Omit<Partial<TaskSnapshot>, 'events'> & Pick<TaskSnapshot, 'taskId' | 'status' | 'prompt'> & { events?: (TaskSnapshot['events'][number] & { ts?: number })[] })");
  }
  const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, removeComments: true };
  const beforeJs = ts.transpileModule(before, { compilerOptions: options }).outputText;
  const afterJs = ts.transpileModule(after, { compilerOptions: options }).outputText;
  if (beforeJs !== afterJs) throw Error('fixture_js_changed:' + name);
  const sha = value => createHash('sha256').update(value).digest('hex');
  const beforePath = resolve(evidence, name + '-before.test.ts'), candidatePath = resolve(evidence, name + '-candidate.test.ts');
  writeFileSync(beforePath, before, { flag: 'wx' }); writeFileSync(candidatePath, after, { flag: 'wx' });
  manifest.push({ path, beforePath, candidatePath, beforeSourceSha: sha(before), candidateSourceSha: sha(after), beforeJsSha: sha(beforeJs), candidateJsSha: sha(afterJs), jsByteIdentical: true });
}
writeFileSync(resolve(evidence, 'legacy-type-candidates-r1.json'), JSON.stringify({ scope: 'test-only legacy fixture typing; no data, contract, behavior, assertions or population edits', manifest }, null, 2), { flag: 'wx' });
