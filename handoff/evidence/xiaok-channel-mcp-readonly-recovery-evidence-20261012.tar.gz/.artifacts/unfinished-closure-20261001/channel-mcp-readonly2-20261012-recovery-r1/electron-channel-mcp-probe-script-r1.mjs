import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {existsSync} from 'node:fs';
import {readFile as readFileAsync,writeFile} from 'node:fs/promises';import {join,dirname} from 'node:path';import {fileURLToPath} from 'node:url';import {types as skillNodeTypes} from 'node:util';
import {ShutdownAwareIpcMain,DesktopShutdownGate} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import {isTrustedDesktopRendererUrl,buildBrowserWindowOptions} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import {createMeetingRecorderWindowController} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import {registerChannelMcpReadonlyIpc} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/channel-mcp-readonly-typed-ipc.js";
import {readChannelViews,readMcpInstallViews} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/channel-mcp-readonly-data.js";
const root="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-channel-mcp-readonly-ipc-v6IZvr",rendererFile="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-channel-mcp-readonly-ipc-v6IZvr/desktop/dist/renderer/index.html",__dirname=dirname(fileURLToPath(import.meta.url));
app.setPath('userData',join(root,'electron-user-data'));const options={dataRoot:join(root,'data')};
let mainWindow=null,meetingRecorderController=null;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}
const services = { async listChannels() {
        return readChannelViews();
    }, async listMCPInstalls() {
        return readMcpInstallViews(options.dataRoot);
    } };

const gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];
const verify=(v,code)=>{if(!v)throw Error(code);};let counts=0;
registerChannelMcpReadonlyIpc(ipc,new Map([['desktop:listChannels',()=>{counts++;return services.listChannels();}],['desktop:listMCPInstalls',()=>{counts++;return services.listMCPInstalls();}]]));
const invoke=async(role,window)=>{for(const method of ['listChannels','listMCPInstalls'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await writeFile(join(root,'config/config.json'),JSON.stringify({schemaVersion:2,providers:{},models:[],channels:{owned:{name:'Owned channel',enabled:false,webhookUrl:'https://owned.invalid/hook'}}}));await writeFile(join(root,'data/mcp-installs.json'),JSON.stringify([{id:'owned',name:'Owned MCP',source:'future-source',command:'owned-command',args:['--owned',''],enabled:false,createdAt:0,future:{retained:true}}]));
const windowOptions=buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",{platform:process.platform});mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:"/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-skills-readonly'});const recorder=BrowserWindow.getAllWindows().find(w=>meetingRecorderController.ownsWebContents(w.webContents));verify(!!recorder,'recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...windowOptions,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);const old=mainWindow;mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_read_failed');if(row.method==='listChannels')verify(row.reply.value[0].name==='Owned channel'&&Object.keys(row.reply.value[0]).length===7,'complete_channels_changed');else verify(row.reply.value[0].future.retained===true&&row.reply.value[0].args.length===2,'complete_mcp_changed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted');}
for(const [file,method]of [['config/config.json','listChannels'],['data/mcp-installs.json','listMCPInstalls']]){await writeFile(join(root,file),'{');const failed=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');verify(!failed.ok,'bad_file_false_empty');results.push({role:'bad-json',method,reply:failed});}verify(!existsSync(join(root,'config/config.json.bak')),'readonly_repaired_bad_config');verify(gate.outstanding===0,'ipc_token_leak');verify(counts===8,'unowned_reader_called');
await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/channel-mcp-readonly2-20261012-recovery-r1/electron-channel-mcp-probe-r1.json",JSON.stringify({actualElectron:true,actualMainAuthorizer:true,actualExtractedServiceMethods:true,actualReadonlyFileHelpers:true,actualChannelConfigNormalizer:true,actualTypedRegistrars:true,actualRecorderController:true,actualPreloadCjs:true,ownedTemporaryRootOnly:true,normalInstalledOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,results,counts,gateOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1);});