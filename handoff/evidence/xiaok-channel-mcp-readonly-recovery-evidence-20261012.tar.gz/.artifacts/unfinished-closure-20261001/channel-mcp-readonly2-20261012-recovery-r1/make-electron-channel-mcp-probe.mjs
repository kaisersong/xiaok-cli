import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
const r = process.cwd(), e = resolve(r, '.artifacts/unfinished-closure-20261001/channel-mcp-readonly2-20261012-recovery-r1');
const ts = (await import(pathToFileURL(join(r, 'desktop/node_modules/typescript/lib/typescript.js')).href)).default;
const selected = {}, raw = {};
for (const file of ['main.ts', 'desktop-services.ts']) {
  const source = readFileSync(join(r, 'desktop/electron', file), 'utf8'), ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true);
  function visit(node) {
    const name = node.name?.getText(ast);
    if ((ts.isFunctionDeclaration(node) && ['authorizeDesktopInvoke'].includes(name)) || (ts.isMethodDeclaration(node) && ['listChannels', 'listMCPInstalls'].includes(name))) {
      if (selected[name]) throw Error('ambiguous_actual_source_' + name); selected[name] = node.getText(ast);
    }
    if (ts.isVariableStatement(node)) for (const d of node.declarationList.declarations) if (d.name.getText(ast) === 'EXEC_FILE') selected.EXEC_FILE = node.getText(ast);
    ts.forEachChild(node, visit);
  } visit(ast); raw[file] = source;
}
for (const name of ['authorizeDesktopInvoke','listChannels','listMCPInstalls']) if (!selected[name]) throw Error('missing_actual_source_' + name);
const js = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
const root = realpathSync(mkdtempSync(join(tmpdir(), 'xiaok-channel-mcp-readonly-ipc-'))), dir = join(root, 'desktop/dist/main/desktop/electron'), renderer = join(root, 'desktop/dist/renderer/index.html');
mkdirSync(dir, { recursive: true }); mkdirSync(join(root, 'desktop/dist/renderer'), { recursive: true }); mkdirSync(join(root, 'data')); mkdirSync(join(root,'config')); mkdirSync(join(root, '.xiaok/skills/owned-probe-skill'), { recursive: true });
writeFileSync(join(root, '.xiaok/skills/owned-probe-skill/SKILL.md'), '---\nname: owned-probe-skill\ndescription: Owned probe\n---\nOwned instruction body.\n');
writeFileSync(renderer, '<!doctype html><meta charset="utf-8"><title>Owned skills readonly IPC probe</title>');
const module = path => JSON.stringify(pathToFileURL(join(r, 'desktop/dist/main', path)).href), preload = JSON.stringify(join(r, 'desktop/electron/preload.cjs'));
const script = join(dir, 'skills-readonly-ipc.mjs');
const text = `import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {readFile as readFileAsync,writeFile} from 'node:fs/promises';import {join,dirname} from 'node:path';import {fileURLToPath} from 'node:url';import {types as skillNodeTypes} from 'node:util';
import {ShutdownAwareIpcMain,DesktopShutdownGate} from ${module('desktop/electron/shutdown-aware-ipc-main.js')};
import {isTrustedDesktopRendererUrl,buildBrowserWindowOptions} from ${module('desktop/electron/security.js')};
import {createMeetingRecorderWindowController} from ${module('desktop/electron/meeting-recorder-window.js')};
import {registerChannelMcpReadonlyIpc} from ${module('desktop/electron/channel-mcp-readonly-typed-ipc.js')};
import {readChannelViews,readMcpInstallViews} from ${module('desktop/electron/channel-mcp-readonly-data.js')};
const root=${JSON.stringify(root)},rendererFile=${JSON.stringify(renderer)},__dirname=dirname(fileURLToPath(import.meta.url));
app.setPath('userData',join(root,'electron-user-data'));const options={dataRoot:join(root,'data')};
let mainWindow=null,meetingRecorderController=null;
${js(selected.authorizeDesktopInvoke + '\nconst services={' + selected.listChannels + ',' + selected.listMCPInstalls + '};')}
const gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];
const verify=(v,code)=>{if(!v)throw Error(code);};let counts=0;
registerChannelMcpReadonlyIpc(ipc,new Map([['desktop:listChannels',()=>{counts++;return services.listChannels();}],['desktop:listMCPInstalls',()=>{counts++;return services.listMCPInstalls();}]]));
const invoke=async(role,window)=>{for(const method of ['listChannels','listMCPInstalls'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await writeFile(join(root,'config/config.json'),JSON.stringify({schemaVersion:2,providers:{},models:[],channels:{owned:{name:'Owned channel',enabled:false,webhookUrl:'https://owned.invalid/hook'}}}));await writeFile(join(root,'data/mcp-installs.json'),JSON.stringify([{id:'owned',name:'Owned MCP',source:'future-source',command:'owned-command',args:['--owned',''],enabled:false,createdAt:0,future:{retained:true}}]));
const windowOptions=buildBrowserWindowOptions(${preload},{platform:process.platform});mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:${preload},rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-skills-readonly'});const recorder=BrowserWindow.getAllWindows().find(w=>meetingRecorderController.ownsWebContents(w.webContents));verify(!!recorder,'recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...windowOptions,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);const old=mainWindow;mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_read_failed');if(row.method==='listChannels')verify(row.reply.value[0].name==='Owned channel'&&Object.keys(row.reply.value[0]).length===7,'complete_channels_changed');else verify(row.reply.value[0].future.retained===true&&row.reply.value[0].args.length===2,'complete_mcp_changed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted');}
for(const [file,method]of [['config/config.json','listChannels'],['data/mcp-installs.json','listMCPInstalls']]){await writeFile(join(root,file),'{');const failed=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');verify(!failed.ok,'bad_file_false_empty');results.push({role:'bad-json',method,reply:failed});}verify(gate.outstanding===0,'ipc_token_leak');verify(counts===8,'unowned_reader_called');
await writeFile(${JSON.stringify(join(e,'electron-channel-mcp-probe-r1.json'))},JSON.stringify({actualElectron:true,actualMainAuthorizer:true,actualExtractedServiceMethods:true,actualReadonlyFileHelpers:true,actualChannelConfigNormalizer:true,actualTypedRegistrars:true,actualRecorderController:true,actualPreloadCjs:true,ownedTemporaryRootOnly:true,normalInstalledOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,results,counts,gateOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1);});`;
writeFileSync(script,text);writeFileSync(join(e,'electron-channel-mcp-probe-script-r1.mjs'),text);writeFileSync(join(e,'electron-channel-mcp-probe-script-r1.json'),JSON.stringify({root,script,renderer,selected,limits:'component IPC source extraction; not full createDesktopServices startup/installed/native authority/whole UI'},null,2));
console.log(JSON.stringify({root,script}));
