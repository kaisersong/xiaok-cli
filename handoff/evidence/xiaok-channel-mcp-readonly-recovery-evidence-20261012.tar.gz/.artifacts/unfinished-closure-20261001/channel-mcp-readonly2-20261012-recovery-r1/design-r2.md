# Channel/MCP readonly2 前置草案（未评审/未实施）
原剩余两项 listChannels/listMCPInstalls，所属mutation7仍保父队列，不声称全族或权限完成。
已发现事实见 preflight-r1.json。下一步先盘点全部实际/冻结消费者及旧API关联，不能遗漏父人口或借死模块缩验收。
拟做 round32 tuple[]/full DTO passthrough arrays、source string ABI、complete row andargs metadata；sync/nativePromise output先capture/validate/reject，完整原Main+Recorder/frame/URL admission/普通5s shutdown不改；坏输入先于文件/producer。main/preload/CJS/renderer/types/census同步。
Channel现loadConfig对无权限返回默认且坏JSON会rename/repair。本票必须以复用normalizeConfig和cloneDefaultConfig的显式readonly helper得到真实事实；只有真实own-data ENOENT为absent default，解析/类型/版本/读取错误拒绝，不chmod/backup/write，保默认其它loadConfig的现有迁移/修复/写入语义。新helper需正常schema1/2结果等价和真实坏文件read-only bytes/mode/目录不变测试；不把全局write/migration事务作为本票。
MCP现file缺失合法[]，坏JSON/非数组/坏DTO/读取错误拒绝；不裁合法rows/unknownextras/现有字符串，不将命令/URL/env私有字段写日志。
ChannelsPane一个生命周期读owner，lastgood+局部本地化unknown/unavailable/readonlyretry、事件/manual合并最多一后继，unmount/locale作废；既有创建/更新/删除/test等用户mutation路径保持成功后refresh与独立error，不加确认或改source authority。
McpPane沿用原catalog2s owner，去install catch[]，独立install facts readstate/lastgood，plugins/dependency状态不混同；保现有heldtick忙跳/manual1后继/清timer/旧结果作废，避免新第二owner。此原2s与原父deadlines不改变。
先真实characterization/design独审→生产service/registerDesktopIpc与真实active UI/桥接/TS+CJS RED→窄源码。完整related/fullconfigs/newtestlint/gov/changed/mainrendererbuild/ownElectron IPCprobe/freshCODE才可计原2。全部父门和自动中断native/material/P4保持，未重试。


## 后继明确（以本节覆盖草案早期 helper 位置）
无需修改 Core loadConfig 或增 opt-in 修复分支。新增仅 Desktop 的 channel-mcp-readonly-data helper，复用 Core 的 getConfigPath、normalizeConfig、DEFAULT_CONFIG/isValidLegacyProvider；真实 sync read→JSON.parse→capture→同原 schema1/2合法检查→原 normalize。只有真实 own-data ENOENT代表未配置，不 existsSync吞错，不 chmod/backup/write。Core loadConfig/CLI/startup原行为保持；已有正常 schema1/2+创建/更新后事实等价，所有坏文件bytes/mode/bak不变由真实控制证明。读取整个Core配置只在Main内部，公开 projection仍原 Channel7字段，不泄漏其它配置字段。
MCP JSON 只读同理，真实ENONET为[]，其它读/解析/非数组/输出结构错拒绝；完整 normal rows/args/unknownextras 与旧真实create/update writer生产数据保持，timestamp number不增时限/正值限制，source/id/name/command保持空字符串和任意历史string ABI；readonlyview类型同步共享schema，mutation input enum/其它producer保持。
全部兄弟 mutation7/source actor债留原父队列，不把本两票说成全族security修复。现 Main/Recorder common sender权威保持，不新造SDK调用或任意fs路径端口。
实际runtime消费者是 App→AppLayout→DesktopSettings 中 ChannelsPane/McpPane，两条 bridge 方法已原样forwardreject。见 active-consumer-census-r1.json。legacy源码引用和未导出的独立HTTP API有独立债且没有从父原176/351裁掉；本票不重新接入旧SettingsModal/Settingsbarrel、不创造SDK成功stub。若 characterizations/独审发现它们是实际RPC消费者，须纳入真实源码控制，不能以此文档代替核查。
ChannelsPane 每lifetime一个owner，初始化/manual/成功mutation后的load复用；失败保lastgood并本地化unknown/unavailable与read-onlyretry，locale/unmount失效，显式busy排最多1，当前actionerror独立。旧用户输入/必填检查/confirm/test/create/update/delete成功链保原参数，不修改副作用authority。
McpPane 原2秒owner沿用、busy tick skip/manual至多1；把安装读取失败从catalog失败单独表达，lastgood和初始unknown，失败不清installs，不用[]吞错误；独立plugins/dependency事实/error保原逻辑。locale/unmount作废但timer不重复/不留，迟到finally不能重新排工作。普通成功create/update/delete后refresh仍走同owner，读取不触发任何mutation/安装/卸载。
Main/TS/CJS/preload/renderer/contracts/registry/两处round32联合类型同源；两个冻结census所有原断言保持。必须真实 registerDesktopIpc/createDesktopServices 条目和真实 current ChannelsPane/McpPane+directbridge RED→production；合法Main/Recorder、unknownsameURL/oldMain/subframe拒绝先于getter/文件，input tuple额外/proxy/accessor拒绝；全部output metadata/args/extras/empty正常/每invoke detach，getter/proxy/serializer/cycle/nativePromise constructor/species/ownthen/reject/同步throw；无producer retry/false[]/generic runtime resolved错误信封。
真实owned config/mcp文件 normal/missing/坏JSON/非数组/坏记录/EACCES/同版schema1/2、读取不写修复，旧writers normal output穿过新reader/schema。hold读与原ordinary5秒shutdowntoken真实待settle、不新deadline；UIloading/unknown/error/lastgood/retry/coalesced held/manual/poll/locale/unmount/actionerror及原用户mutation参数成功refresh保持。DESIGN独审后TDD，完整相关/两完整strict/noCheck:false/gov/changed/newtestlint/buildmainrenderer/own临时Electron IPC/freshCODE后才计2。所有原父条件和自动中断native/material/P4保持，parent false/master未合并。


## R2：独立 BLOCK 九项的明确关闭（本节覆盖前文歧义）

1. **破坏性兄弟债和产品文案**：`desktop-services.ts:3991-4001 createChannel`、`:4012-4034 update/deleteChannel` 仍用 Core loadConfig→saveConfig；坏文件可能 backupAndRemove→default→整份覆盖，含其它 providers/API Key。`:4041-4073 create/update/deleteMCPInstall` 的 loadJsonFile(path,[])→saveJsonFile 仍可覆盖坏历史文件。这些原 mutation7 不在本两票修复；“添加/更新/删除/test”等现有用户入口在读不可用时保持可用，与原授权/原用户路径一致，但这是已知未闭合的数据损失父债。新文案仅称“无法读取/无法确认内容”，不称“安全/受保护/已修复/没有数据”，不把本票叫全部权限或文件安全完成。原父范围保留后继 mutation7与allwriters验收。

2. **行形状和旧强制转换**：normalized config.channels 缺失或null由原 normalizeConfig 得到{}，正常未配置仍[]。非对象/数组 channels map拒整表；任一 channel row 非普通data对象/为null/数组/boolean/string拒整表；已存在 name/webhookUrl/sendMsgUrl 必须string，enabled必须boolean，否则整表unavailable，不单行跳过。字段缺失可保原默认；正常 empty name 的 `c.name || key`、空URL的 fallback、enabled缺失默认true、任意key/type与0 timestamps完全保持。其它存储字段未知extras仅留Main，不改变原normalizer，不进入公开projection。真实before字符化已明确null抛TypeError，string/false/array错误row被投影成enabled=true、name数字/URL数字直接透出；R2选择将这些非契约输入视为unavailable，必须先真实RED后实现。

3. **唯一注册替换**：删除 `ipc.ts:1306/1317` 两条 raw handle，不保留双注册。用独立 raw producer Map `channelMcpReadonlyProducers` 只收两条服务调用，交 `registerChannelMcpReadonlyIpc`，遵循现 skillListProducers 模式；已有 mutation7 raw handler不改/不偷计。registrar owner同Map重复幂等、不同Map拒冲突；无producer拒runtime_unavailable，不替换ShutdownAwareIpcMain外壳。

4. **精确文件和metadata**：`desktop/shared/channel-mcp-readonly-ipc-contract.ts`：两zero tuples、Channel严格7字段、MCP完整passthrough行与string源码ABI；`desktop/electron/channel-mcp-readonly-typed-ipc.ts`：`payloadMode:'tuple'`、`inputStage:'beforeHandler'`、`riskTags:['fs-read']`、`rolloutRound:32`、`sourceFile:'desktop/electron/channel-mcp-readonly-typed-ipc.ts'`，input先capture再tuple校验，失败 `channel_mcp_input_invalid`；output capture/schema/nativepromise失败 `channel_mcp_projection_unavailable`；缺producer `channel_mcp_runtime_unavailable`；owner冲突 `channel_mcp_registrar_owner_conflict`。`ipc-runtime.ts:30/:65` 两union各加32，其余轮次不动。helper `desktop/electron/channel-mcp-readonly-data.ts` 只读Core config/MCP文件，真实own-data ENOENT才absent，其它错误拒绝，无logger payload；schema/runtime同步native TS/CJS/preload/renderer contract及两个原census，原assertion不减。

5. **Locale位置/具体key**：顶层 `channelReadonlyUnknown`（通道信息未知/Channel information unknown）、`channelReadonlyUnavailable`（无法读取消息通道/Unable to read channels）、`mcpInstallsReadonlyUnknown`（MCP 安装信息未知/MCP installation information unknown）、`mcpInstallsReadonlyUnavailable`（无法读取 MCP 安装列表/Unable to read MCP installations）、`desktopReadonlyRetry`（重新读取/Read again）；同时编辑locale index类型、zh、en三文件。不新增hardcoded用户字符串，不update baseline。

6. **没有事件源**：两事实不新增preload事件，不出现onChannelsChanged/onMCPChanged。Channels合并只针对initial/manual/用户mutation成功后load；MCP仅现2s poll和同类manual/mutation后load，没有新增owner/poll/订阅源。前文事件刷新措辞撤为以上明确行为。

7. **读owner决定**：把已验收 `useSkillReadonly.ts` 的现 `useReadonly` 仅改名并export为 `useDesktopReadonly`，原useSkillListReadonly/useSkillStatsReadonly wrappers照旧调用同一实现/同一catalogEvents值，算法/Skills订阅/Stats行为不变；新 `renderer/src/hooks/useChannelReadonly.ts` 以稳定read函数+共享Channel schema调用该导出，catalogEvents=false（不订阅Skills事件）。ChannelsPane只一个hook owner，原load/mutation刷新都调用其refresh；不加第二owner/轮询。McpPane沿用自身原2s复合catalog owner，以同一generation/busy/manual状态对installs fact增加独立 ready/unavailable/schema验证；不再catch[]，并独立保plugins/dependency状态。触及已验收Skills hook必须保其所有原控制和完整关联人口当前1105，新增不得抵消旧失败。

8. **严格投影/日志**：Channel output schema **strict**7字段，禁止未来producer扩出其它config字段；仅原7字段公开，无unknown额外字段声称。MCP output行 **passthrough**，保原JSON args/合法extras；全数组不裁剪。仅在成功完整capture/validate之后可count-only记录，Channels/MCP均禁止name/URL/command/env/整份config/私有路径输出日志；推荐无新增log。schema错误不能由通用runtime造resolve成功信封，必须handler reject。

9. **Core零编辑与真实证据/门禁**：`src/utils/config.ts`、`src/types.ts`、`src/ai/providers/normalize.ts` 只import，CODE时对preflight SHA逐个比对不变，旧loadConfig/startup/tightenBestEffort/所有writerrepair行为不改。helper自行对DEFAULT_CONFIG JSON深克隆（不是复用私有cloneDefaultConfig或导出它），同现默认对象语义；同schema1/2/legacyprovider检查和normalizeConfig使用既有函数。真实before `characterization-current-r4.json/process/cleanup` 增合法schema1、坏channelrows、config parentEACCES和MCP EACCES假空、实际原createChannel/createMCPInstall的生产结果穿原reader，sourceSHA0drift/自有目录回收。r2的单文件chmod被Core自动tighten恢复，仍保原结果且不伪称EACCES；r3/r4用own parent无读权限才证明IO失败。当前正常channel writer ACK时间为Date.now但reader固定0是原ABI，不把二者强行改相等；其它正常public内容等价，新reader须保固定0。owned-temp旧writerchar不授agent/native/normalinstall权限。

完整 `hygiene:check` 在实施前/后（behind/foreign历史报错保留，不clean别人的WIP），governance/changed、新testlint、两完整原configs noCheck:false strict、Main/renderer build、97关联原人口+所有新增/CLI相关的当前输入、own临时Electron sourceprobe/freshCODE。已有 `desktop-settings-mcp-pane/tools-pane/systemone/model-settings-add-provider/plugin-catalog-mcp-read-errors` 的原assertions只扩展不删减（已列入相关清单；不得把不相容旧mock删case）。真实服务/rawregisteredMain/UI/bridge/TS+CJS RED必须闭环；其它所有父条件仍OPEN，CODE前219/298不变。
