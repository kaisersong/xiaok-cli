import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
const r=process.cwd(),e=resolve(r,'.artifacts/unfinished-closure-20261001/channel-mcp-readonly2-20261012-recovery-r1');
const ts=(await import(pathToFileURL(join(r,'desktop/node_modules/typescript/lib/typescript.js')).href)).default;
const source=readFileSync(join(r,'desktop/electron/desktop-services.ts'),'utf8'),ast=ts.createSourceFile('desktop-services.ts',source,ts.ScriptTarget.Latest,true),selected={};
function visit(n){if(ts.isMethodDeclaration(n)&&['listChannels','listMCPInstalls'].includes(n.name.getText(ast)))selected[n.name.getText(ast)]=n.getText(ast);ts.forEachChild(n,visit);}visit(ast);
if(Object.keys(selected).length!==2)throw Error('reader_census_changed');
const root=mkdtempSync(join(tmpdir(),'channel-mcp-readonly-characterization-')),data=join(root,'data'),config=join(root,'config');mkdirSync(data);mkdirSync(config);process.env.XIAOK_CONFIG_DIR=config;
const {loadConfig}=await import(pathToFileURL(join(r,'desktop/dist/main/src/utils/config.js')).href);const {DEFAULT_CONFIG}=await import(pathToFileURL(join(r,'desktop/dist/main/src/types.js')).href);
const code=ts.transpileModule('return {'+Object.values(selected).join(',')+'};',{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
const service=compileFunction(code,['loadConfig','readFileSync','join','options'])(loadConfig,readFileSync,join,{dataRoot:data});const results=[];
try{
 results.push({name:'genuine-missing',channels:await service.listChannels(),mcp:await service.listMCPInstalls()});
 const cfg={...structuredClone(DEFAULT_CONFIG),channels:{'future-channel':{name:'Owned name',webhookUrl:'https://owned.invalid/hook',enabled:false}}};writeFileSync(join(config,'config.json'),JSON.stringify(cfg));results.push({name:'complete-channel',value:await service.listChannels()});
 const rows=[{id:'',name:'',source:'future-source',command:'C:\\owned\\command',args:['--owned',''],enabled:false,createdAt:0,future:{preserved:['owned']}}];writeFileSync(join(data,'mcp-installs.json'),JSON.stringify(rows));results.push({name:'complete-mcp-with-extras',value:await service.listMCPInstalls()});
 for(const content of ['{','{}','[{}]']){writeFileSync(join(data,'mcp-installs.json'),content);results.push({name:'legacy-mcp-'+content,value:await service.listMCPInstalls()});}
 writeFileSync(join(config,'config.json'),'{');results.push({name:'legacy-invalid-channel-config',value:await service.listChannels(),originalExists:existsSync(join(config,'config.json')),backupExists:existsSync(join(config,'config.json.bak')),backupBytes:readFileSync(join(config,'config.json.bak'),'utf8')});
 writeFileSync(join(e,'characterization-current-r1.json'),JSON.stringify({actualExtractedMethods:true,actualLoadConfig:true,actualFileIo:true,ownedTemporaryRootOnly:true,notTypedOrAccepted:true,selected,results},null,2),{flag:'wx'});
}finally{rmSync(root,{recursive:true,force:true});writeFileSync(join(e,'characterization-current-cleanup-r1.json'),JSON.stringify({ownedRoot:root,removed:!existsSync(root)}),{flag:'wx'});}
console.log(JSON.stringify({cases:results.length,componentAccepted:false}));
