# Channel/MCP readonly2 前置草案（未评审/未实施）
原剩余两项 listChannels/listMCPInstalls，所属mutation7仍保父队列，不声称全族或权限完成。
已发现事实见 preflight-r1.json。下一步先盘点全部实际/冻结消费者及旧API关联，不能遗漏父人口或借死模块缩验收。
拟做 round32 tuple[]/full DTO passthrough arrays、source string ABI、complete row andargs metadata；sync/nativePromise output先capture/validate/reject，完整原Main+Recorder/frame/URL admission/普通5s shutdown不改；坏输入先于文件/producer。main/preload/CJS/renderer/types/census同步。
Channel现loadConfig对无权限返回默认且坏JSON会rename/repair。本票必须以复用normalizeConfig和cloneDefaultConfig的显式readonly helper得到真实事实；只有真实own-data ENOENT为absent default，解析/类型/版本/读取错误拒绝，不chmod/backup/write，保默认其它loadConfig的现有迁移/修复/写入语义。新helper需正常schema1/2结果等价和真实坏文件read-only bytes/mode/目录不变测试；不把全局write/migration事务作为本票。
MCP现file缺失合法[]，坏JSON/非数组/坏DTO/读取错误拒绝；不裁合法rows/unknownextras/现有字符串，不将命令/URL/env私有字段写日志。
ChannelsPane一个生命周期读owner，lastgood+局部本地化unknown/unavailable/readonlyretry、事件/manual合并最多一后继，unmount/locale作废；既有创建/更新/删除/test等用户mutation路径保持成功后refresh与独立error，不加确认或改source authority。
McpPane沿用原catalog2s owner，去install catch[]，独立install facts readstate/lastgood，plugins/dependency状态不混同；保现有heldtick忙跳/manual1后继/清timer/旧结果作废，避免新第二owner。此原2s与原父deadlines不改变。
先真实characterization/design独审→生产service/registerDesktopIpc与真实active UI/桥接/TS+CJS RED→窄源码。完整related/fullconfigs/newtestlint/gov/changed/mainrendererbuild/ownElectron IPCprobe/freshCODE才可计原2。全部父门和自动中断native/material/P4保持，未重试。


## 后继明确（以本节覆盖草案早期 helper 位置）
无需修改 Core loadConfig 或增 opt-in 修复分支。新增仅 Desktop 的 channel-mcp-readonly-data helper，复用 Core 的 getConfigPath、normalizeConfig、DEFAULT_CONFIG/isValidLegacyProvider；真实 sync read→JSON.parse→capture→同原 schema1/2合法检查→原 normalize。只有真实 own-data ENOENT代表未配置，不 existsSync吞错，不 chmod/backup/write。Core loadConfig/CLI/startup原行为保持；已有正常 schema1/2+创建/更新后事实等价，所有坏文件bytes/mode/bak不变由真实控制证明。读取整个Core配置只在Main内部，公开 projection仍原 Channel7字段，不泄漏其它配置字段。
MCP JSON 只读同理，真实ENONET为[]，其它读/解析/非数组/输出结构错拒绝；完整 normal rows/args/unknownextras 与旧真实create/update writer生产数据保持，timestamp number不增时限/正值限制，source/id/name/command保持空字符串和任意历史string ABI；readonlyview类型同步共享schema，mutation input enum/其它producer保持。
全部兄弟 mutation7/source actor债留原父队列，不把本两票说成全族security修复。现 Main/Recorder common sender权威保持，不新造SDK调用或任意fs路径端口。
实际runtime消费者是 App→AppLayout→DesktopSettings 中 ChannelsPane/McpPane，两条 bridge 方法已原样forwardreject。见 active-consumer-census-r1.json。legacy源码引用和未导出的独立HTTP API有独立债且没有从父原176/351裁掉；本票不重新接入旧SettingsModal/Settingsbarrel、不创造SDK成功stub。若 characterizations/独审发现它们是实际RPC消费者，须纳入真实源码控制，不能以此文档代替核查。
ChannelsPane 每lifetime一个owner，初始化/manual/成功mutation后的load复用；失败保lastgood并本地化unknown/unavailable与read-onlyretry，locale/unmount失效，显式busy排最多1，当前actionerror独立。旧用户输入/必填检查/confirm/test/create/update/delete成功链保原参数，不修改副作用authority。
McpPane 原2秒owner沿用、busy tick skip/manual至多1；把安装读取失败从catalog失败单独表达，lastgood和初始unknown，失败不清installs，不用[]吞错误；独立plugins/dependency事实/error保原逻辑。locale/unmount作废但timer不重复/不留，迟到finally不能重新排工作。普通成功create/update/delete后refresh仍走同owner，读取不触发任何mutation/安装/卸载。
Main/TS/CJS/preload/renderer/contracts/registry/两处round32联合类型同源；两个冻结census所有原断言保持。必须真实 registerDesktopIpc/createDesktopServices 条目和真实 current ChannelsPane/McpPane+directbridge RED→production；合法Main/Recorder、unknownsameURL/oldMain/subframe拒绝先于getter/文件，input tuple额外/proxy/accessor拒绝；全部output metadata/args/extras/empty正常/每invoke detach，getter/proxy/serializer/cycle/nativePromise constructor/species/ownthen/reject/同步throw；无producer retry/false[]/generic runtime resolved错误信封。
真实owned config/mcp文件 normal/missing/坏JSON/非数组/坏记录/EACCES/同版schema1/2、读取不写修复，旧writers normal output穿过新reader/schema。hold读与原ordinary5秒shutdowntoken真实待settle、不新deadline；UIloading/unknown/error/lastgood/retry/coalesced held/manual/poll/locale/unmount/actionerror及原用户mutation参数成功refresh保持。DESIGN独审后TDD，完整相关/两完整strict/noCheck:false/gov/changed/newtestlint/buildmainrenderer/own临时Electron IPC/freshCODE后才计2。所有原父条件和自动中断native/material/P4保持，parent false/master未合并。
