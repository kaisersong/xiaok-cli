import { cleanup, fireEvent, render, screen, waitFor, act } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
const mocks = vi.hoisted(() => ({ channels: vi.fn(), mcp: vi.fn(), plugins: vi.fn(), dependencies: vi.fn(), createChannel: vi.fn(), createMcp: vi.fn() }));
vi.mock('../../renderer/src/api/bridge', async importOriginal => {
  const actual = await importOriginal<typeof import('../../renderer/src/api/bridge')>();
  Object.assign(actual.api, { listChannels: mocks.channels, listMCPInstalls: mocks.mcp, listPluginMcpServers: mocks.plugins, listPluginDependencyStatuses: mocks.dependencies,
    createChannel: mocks.createChannel, createMCPInstall: mocks.createMcp, getServiceStatus: async () => ({services:[]}), getSkillDebugConfig: async () => ({enabled:false}), getKswarmConfig: async () => ({maxConcurrentTasks:3}) });
  return actual;
});
const channels = [{id:'owned',type:'telegram',name:'Owned channel',enabled:false,createdAt:0,updatedAt:0}];
const installs = [{id:'owned',name:'Owned MCP',source:'local',command:'owned-command',args:['--owned'],enabled:false,createdAt:0}];
function LocaleButton() { const { setLocale } = useLocale(); return <button onClick={() => setLocale('en')}>test-locale</button>; }
function mount(kind: 'channels'|'mcp') {
  const view = render(<MemoryRouter><LocaleProvider><LocaleButton /><DesktopSettings onClose={() => {}} /></LocaleProvider></MemoryRouter>);
  fireEvent.click(screen.getByRole('button', {name:kind==='channels'?'消息通道':'MCP 服务器'})); return view;
}
beforeEach(() => { localStorage.setItem('xiaok:locale','zh'); mocks.channels.mockReset().mockResolvedValue(channels); mocks.mcp.mockReset().mockResolvedValue(installs); mocks.plugins.mockReset().mockResolvedValue([]); mocks.dependencies.mockReset().mockResolvedValue([]); mocks.createChannel.mockReset(); mocks.createMcp.mockReset(); });
afterEach(() => { cleanup(); localStorage.removeItem('xiaok:locale'); vi.restoreAllMocks(); });
it.each(['channels','mcp'] as const)('shows %s read failure without declaring successful empty facts', async kind => {
  (kind==='channels'?mocks.channels:mocks.mcp).mockRejectedValue(Error('private-reader-failure')); mount(kind);
  expect(await screen.findByText(kind==='channels'?'无法读取消息通道':'无法读取 MCP 安装列表')).toBeInTheDocument();
  expect(screen.queryByText('private-reader-failure')).toBeNull(); expect(mocks.createChannel).not.toHaveBeenCalled(); expect(mocks.createMcp).not.toHaveBeenCalled();
});
it.each(['channels','mcp'] as const)('preserves %s last-good data when a manual retry fails', async kind => {
  mount(kind); await screen.findByText(kind==='channels'?'Owned channel':'Owned MCP');
  (kind==='channels'?mocks.channels:mocks.mcp).mockRejectedValueOnce(Error('private-reader-failure'));
  fireEvent.click(screen.getByRole('button', {name:'重新读取'}));
  expect(await screen.findByText(kind==='channels'?'无法读取消息通道':'无法读取 MCP 安装列表')).toBeInTheDocument();
  expect(screen.getByText(kind==='channels'?'Owned channel':'Owned MCP')).toBeInTheDocument();
  expect(mocks.createChannel).not.toHaveBeenCalled(); expect(mocks.createMcp).not.toHaveBeenCalled();
});
it.each(['channels','mcp'] as const)('drops late %s read after unmount and leaves no reread work', async kind => {
  let release!: (value: unknown) => void; const read=kind==='channels'?mocks.channels:mocks.mcp; read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));
  const view=mount(kind); view.unmount(); await act(async()=>release(kind==='channels'?channels:installs)); expect(read).toHaveBeenCalledTimes(1); expect(mocks.createChannel).not.toHaveBeenCalled(); expect(mocks.createMcp).not.toHaveBeenCalled();
});
