import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, existsSync, chmodSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
const r=process.cwd(),e=resolve(r,'.artifacts/unfinished-closure-20261001/channel-mcp-readonly2-20261012-recovery-r1');
const ts=(await import(pathToFileURL(join(r,'desktop/node_modules/typescript/lib/typescript.js')).href)).default;
const source=readFileSync(join(r,'desktop/electron/desktop-services.ts'),'utf8'),ast=ts.createSourceFile('desktop-services.ts',source,ts.ScriptTarget.Latest,true),selected={};
function visit(n){if(ts.isMethodDeclaration(n)&&['listChannels','listMCPInstalls','createChannel','createMCPInstall'].includes(n.name.getText(ast)))selected[n.name.getText(ast)]=n.getText(ast);ts.forEachChild(n,visit);}visit(ast);
if(Object.keys(selected).length!==4)throw Error('reader_census_changed');
const root=mkdtempSync(join(tmpdir(),'channel-mcp-readonly-characterization-')),data=join(root,'data'),config=join(root,'config');mkdirSync(data);mkdirSync(config);process.env.XIAOK_CONFIG_DIR=config;
const {loadConfig,saveConfig}=await import(pathToFileURL(join(r,'desktop/dist/main/src/utils/config.js')).href);const {DEFAULT_CONFIG}=await import(pathToFileURL(join(r,'desktop/dist/main/src/types.js')).href);
const helpers=[];function findHelper(n){if(ts.isFunctionDeclaration(n)&&['toMCPView','loadJsonFile','saveJsonFile'].includes(n.name?.text))helpers.push(n.getText(ast));ts.forEachChild(n,findHelper);}findHelper(ast);
const code=ts.transpileModule(helpers.join('\n')+'\nreturn {'+Object.values(selected).join(',')+'};',{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
const service=compileFunction(code,['loadConfig','saveConfig','readFileSync','writeFileSync','mkdirSync','join','crypto','options'])(loadConfig,saveConfig,readFileSync,writeFileSync,mkdirSync,join,globalThis.crypto,{dataRoot:data});const results=[];
const observe=async(name,read)=>{try{results.push({name,ok:true,value:await read()});}catch(error){results.push({name,ok:false,error:error instanceof Error?error.name:'unknown'});}};
try{
 results.push({name:'genuine-missing',channels:await service.listChannels(),mcp:await service.listMCPInstalls()});
 const cfg={...structuredClone(DEFAULT_CONFIG),channels:{'future-channel':{name:'Owned name',webhookUrl:'https://owned.invalid/hook',enabled:false}}};writeFileSync(join(config,'config.json'),JSON.stringify(cfg));results.push({name:'complete-channel',value:await service.listChannels()});
 const rows=[{id:'',name:'',source:'future-source',command:'C:\\owned\\command',args:['--owned',''],enabled:false,createdAt:0,future:{preserved:['owned']}}];writeFileSync(join(data,'mcp-installs.json'),JSON.stringify(rows));results.push({name:'complete-mcp-with-extras',value:await service.listMCPInstalls()});
 for(const content of ['{','{}','[{}]']){writeFileSync(join(data,'mcp-installs.json'),content);results.push({name:'legacy-mcp-'+content,value:await service.listMCPInstalls()});}
 writeFileSync(join(config,'config.json'),'{');results.push({name:'legacy-invalid-channel-config',value:await service.listChannels(),originalExists:existsSync(join(config,'config.json')),backupExists:existsSync(join(config,'config.json.bak')),backupBytes:readFileSync(join(config,'config.json.bak'),'utf8')});
 const legacy={schemaVersion:1,defaultModel:'openai',models:{openai:{apiKey:'owned-fixture-not-a-real-key'}},channels:{legacy:{name:'Owned legacy',enabled:true}}};writeFileSync(join(config,'config.json'),JSON.stringify(legacy));await observe('normal-schema1',()=>service.listChannels());
 for(const value of [null,'text',false,[],{name:7},{enabled:'bad'},{webhookUrl:7}]){writeFileSync(join(config,'config.json'),JSON.stringify({...cfg,channels:{owned:value}}));await observe('channel-row-'+JSON.stringify(value),()=>service.listChannels());}
 writeFileSync(join(config,'config.json'),JSON.stringify(cfg));chmodSync(config,0);try{await observe('config-parent-EACCES',()=>service.listChannels());}finally{chmodSync(config,0o700);}
 writeFileSync(join(data,'mcp-installs.json'),JSON.stringify(rows));chmodSync(join(data,'mcp-installs.json'),0);try{await observe('mcp-EACCES',()=>service.listMCPInstalls());}finally{chmodSync(join(data,'mcp-installs.json'),0o600);}
 writeFileSync(join(config,'config.json'),JSON.stringify({...structuredClone(DEFAULT_CONFIG),channels:{}}));const channelCreated=await service.createChannel({type:'future-writer',name:'Owned writer',webhookUrl:'https://owned.invalid/writer'});results.push({name:'real-current-channel-writer-read',created:channelCreated,read:await service.listChannels()});
 writeFileSync(join(data,'mcp-installs.json'),'[]');const mcpCreated=await service.createMCPInstall({name:'Owned writer',source:'local',command:'owned-command',args:['--owned','']});results.push({name:'real-current-mcp-writer-read',created:mcpCreated,read:await service.listMCPInstalls()});
 writeFileSync(join(e,'characterization-current-r4.json'),JSON.stringify({actualExtractedMethods:true,actualLoadConfig:true,actualFileIo:true,ownedTemporaryRootOnly:true,notTypedOrAccepted:true,selected,results},null,2),{flag:'wx'});
}finally{rmSync(root,{recursive:true,force:true});writeFileSync(join(e,'characterization-current-cleanup-r4.json'),JSON.stringify({ownedRoot:root,removed:!existsSync(root)}),{flag:'wx'});}
console.log(JSON.stringify({cases:results.length,componentAccepted:false}));
