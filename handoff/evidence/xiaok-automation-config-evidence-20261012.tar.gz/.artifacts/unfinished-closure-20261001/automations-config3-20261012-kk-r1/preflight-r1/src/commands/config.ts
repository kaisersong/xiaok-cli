import type { Command } from 'commander';
import type { ModelConfigEntry, ProviderConfig, ProviderModelVariant } from '../ai/providers/types.js';
import { loadConfig, saveConfig } from '../utils/config.js';
import { getProviderModelVariant, getProviderProfile, listProviderProfiles } from '../ai/providers/registry.js';
import {
  resolveSystemOneConfig,
  setSystemOneConfig,
  SYSTEM_ONE_DEFAULT_BASE_URL,
  SYSTEM_ONE_DEFAULT_MODEL,
} from '../ai/providers/system-one-config.js';
import { isOfficialKimiK3OpenAIEndpoint } from '../ai/providers/model-runtime-options.js';

function normalizeProviderId(value: string): string | null {
  if (value === 'claude') return 'anthropic';
  if (value === 'custom') return 'custom-default';
  // 白名单直接从 registry 派生，避免新增 first-party provider 时漏掉这里，
  // 导致 `config set model <provider>` 被拒、`config set api-key --provider <id>`
  // 把 Key 静默写到当前默认 provider 上。
  return getProviderProfile(value) ? value : null;
}

/**
 * Jev 已经不在推理 provider 注册表里，但 `config set model jev` 和
 * `config set api-key <key> --provider jev` 这两种写法在别处看起来很合理。
 * 直接说不认识会让人以为配置没生效，这里给出真正该用的入口。
 */
function systemOneMisdirectionHint(value: string): string | null {
  return value.trim().toLowerCase() === 'jev'
    ? 'Jev（System One）是辅助决策模型，不参与默认模型选择。'
      + '请改用: xiaok config set system-one-api-key <key>'
    : null;
}

function sanitizeModelIdPart(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function copyCatalogModelEntry(
  providerId: string,
  variant: ProviderModelVariant,
  providerConfig: ProviderConfig,
): ModelConfigEntry {
  const copyRuntimeOptions = variant.runtimeOptions && (
    providerId !== 'kimi'
    || variant.model !== 'k3'
    || (
      providerConfig.protocol === 'openai_legacy'
      && isOfficialKimiK3OpenAIEndpoint(providerConfig.baseUrl)
    )
  );
  return {
    provider: providerId,
    model: variant.model,
    label: variant.label,
    capabilities: variant.capabilities ? [...variant.capabilities] : undefined,
    ...(copyRuntimeOptions ? { runtimeOptions: { ...variant.runtimeOptions } } : {}),
  };
}

function ensureProviderConfig(
  cfg: Awaited<ReturnType<typeof loadConfig>>,
  providerId: string,
): void {
  if (cfg.providers[providerId]) {
    return;
  }

  if (providerId === 'custom-default') {
    cfg.providers[providerId] = {
      type: 'custom',
      protocol: 'openai_legacy',
    };
    return;
  }

  const profile = getProviderProfile(providerId);
  if (!profile) {
    throw new Error(`未知 provider: ${providerId}`);
  }

  cfg.providers[providerId] = {
    type: 'first_party',
    protocol: profile.protocol,
    baseUrl: profile.baseUrl,
    headers: profile.defaultHeaders,
  };
}

function ensureDefaultModelForProvider(
  cfg: Awaited<ReturnType<typeof loadConfig>>,
  providerId: string,
): string {
  const existing = Object.entries(cfg.models).find(([, model]) => model.provider === providerId);
  if (existing) {
    return existing[0];
  }

  if (providerId === 'custom-default') {
    const modelId = 'custom-default-model';
    cfg.models[modelId] = {
      provider: providerId,
      model: 'default',
      label: 'Custom Default',
    };
    return modelId;
  }

  const profile = getProviderProfile(providerId);
  if (!profile) {
    throw new Error(`未知 provider: ${providerId}`);
  }

  cfg.models[profile.defaultModel.modelId] = copyCatalogModelEntry(
    providerId,
    profile.defaultModel,
    cfg.providers[providerId],
  );
  return profile.defaultModel.modelId;
}

export function registerConfigCommands(program: Command): void {
  const config = program.command('config').description('管理 xiaok 工作台配置');

  const configSet = config.command('set').description('设置配置项');

  configSet
    .command('model <value>')
    .description('设置默认 AI 模型（provider、modelId 或 provider/model）')
    .option('--base-url <url>', '自定义模型 base URL（model=custom 时使用）')
    .option('--api-key <key>', '同时设置该模型的 API Key')
    .action(async (value: string, opts: { baseUrl?: string; apiKey?: string }) => {
      const cfg = await loadConfig();

      if (cfg.models[value]) {
        const model = cfg.models[value];
        cfg.defaultModelId = value;
        cfg.defaultProvider = model.provider;
        await saveConfig(cfg);
        console.log(`已设置默认模型为: ${value}`);
        return;
      }

      const normalizedProvider = normalizeProviderId(value);
      if (normalizedProvider) {
        ensureProviderConfig(cfg, normalizedProvider);
        if (opts.baseUrl) {
          cfg.providers[normalizedProvider].baseUrl = opts.baseUrl;
        }
        if (opts.apiKey) {
          cfg.providers[normalizedProvider].apiKey = opts.apiKey;
        }
        const modelId = ensureDefaultModelForProvider(cfg, normalizedProvider);
        cfg.defaultProvider = normalizedProvider;
        cfg.defaultModelId = modelId;
        await saveConfig(cfg);
        console.log(`已设置默认模型为: ${modelId}`);
        return;
      }

      const [providerValue, modelName] = value.split('/');
      const providerId = normalizeProviderId(providerValue);
      if (providerId && modelName) {
        ensureProviderConfig(cfg, providerId);
        if (providerId === 'custom-default' && !opts.baseUrl && !cfg.providers[providerId].baseUrl) {
          console.error('请先设置 baseUrl：xiaok config set model custom --base-url <url>');
          return;
        }
        if (opts.baseUrl) {
          cfg.providers[providerId].baseUrl = opts.baseUrl;
        }
        if (opts.apiKey) {
          cfg.providers[providerId].apiKey = opts.apiKey;
        }
        const modelId = `${providerId}-${sanitizeModelIdPart(modelName)}`;
        const catalogVariant = providerId === 'kimi' || providerId === 'glm' || providerId === 'deepseek'
          ? getProviderModelVariant(providerId, modelName)
          : undefined;
        cfg.models[modelId] = catalogVariant
          ? copyCatalogModelEntry(providerId, catalogVariant, cfg.providers[providerId])
          : {
              provider: providerId,
              model: modelName,
              label: modelName,
            };
        cfg.defaultProvider = providerId;
        cfg.defaultModelId = modelId;
        await saveConfig(cfg);
        console.log(`已设置默认模型为: ${modelId}`);
        return;
      }

      const hint = systemOneMisdirectionHint(value);
      if (hint) {
        console.error(hint);
        return;
      }

      console.error(`未知模型: ${value}。支持: modelId、provider、provider/model`);
    });

  configSet
    .command('api-key <key>')
    .description('设置 AI 模型 API Key')
    .option('--provider <provider>', '指定提供商（默认当前默认模型）')
    .action(async (key: string, opts: { provider?: string }) => {
      const cfg = await loadConfig();
      const requested = opts.provider?.trim();
      if (requested) {
        // 显式指定 provider 时必须认得它：以前这里会对不认识的 id 静默回退到
        // 当前默认 provider，把 Key 写到完全不相干的 provider 上。
        const misdirection = systemOneMisdirectionHint(requested);
        if (misdirection) {
          console.error(misdirection);
          return;
        }
        if (!normalizeProviderId(requested)) {
          console.error(
            `未知 provider: ${requested}。可用: ${listProviderProfiles().map((item) => item.id).join(', ')}`,
          );
          return;
        }
      }
      const provider = normalizeProviderId(requested ?? cfg.defaultProvider) ?? cfg.defaultProvider;
      ensureProviderConfig(cfg, provider);
      if (provider === 'custom-default' && !cfg.providers[provider].baseUrl) {
        console.error('请先设置 baseUrl：xiaok config set model custom --base-url <url>');
        return;
      }
      cfg.providers[provider].apiKey = key;
      const switched = provider !== cfg.defaultProvider;
      if (switched) {
        const modelId = ensureDefaultModelForProvider(cfg, provider);
        cfg.defaultProvider = provider;
        cfg.defaultModelId = modelId;
      }
      await saveConfig(cfg);
      console.log(`已为 ${provider} 设置 API Key${switched ? `，并切换为默认提供商` : ''}`);
    });

  // System One（Jev）是辅助决策模型，不走 providers/models，单独一组命令。
  configSet
    .command('system-one-api-key <key>')
    .description('设置 System One（Jev）辅助决策模型的 API Key（传空串可清除）')
    .action(async (key: string) => {
      const cfg = await loadConfig();
      setSystemOneConfig(cfg, { apiKey: key });
      await saveConfig(cfg);
      console.log(key.trim() ? '已设置 systemOne.apiKey' : '已清除 systemOne.apiKey');
    });

  configSet
    .command('system-one-model <model>')
    .description('设置 System One（Jev）模型名（传空串回退默认 jev-latest）')
    .action(async (model: string) => {
      const cfg = await loadConfig();
      setSystemOneConfig(cfg, { model });
      await saveConfig(cfg);
      console.log(model.trim()
        ? `已设置 systemOne.model = ${model.trim()}`
        : `已清除 systemOne.model（回退默认 ${SYSTEM_ONE_DEFAULT_MODEL}）`);
    });

  configSet
    .command('system-one-base-url <url>')
    .description('设置 System One（Jev）端点 base URL（传空串回退默认值）')
    .action(async (url: string) => {
      const cfg = await loadConfig();
      setSystemOneConfig(cfg, { baseUrl: url });
      await saveConfig(cfg);
      console.log(url.trim()
        ? `已设置 systemOne.baseUrl = ${url.trim()}`
        : `已清除 systemOne.baseUrl（回退默认 ${SYSTEM_ONE_DEFAULT_BASE_URL}）`);
    });

  configSet
    .command('default-model <modelId>')
    .description('设置默认模型 ID')
    .action(async (modelId: string) => {
      const cfg = await loadConfig();
      const model = cfg.models[modelId];
      if (!model) {
        console.error(`未知模型: ${modelId}`);
        return;
      }
      cfg.defaultModelId = modelId;
      cfg.defaultProvider = model.provider;
      await saveConfig(cfg);
      console.log(`已设置默认模型为: ${modelId}`);
    });

  configSet
    .command('yzj-webhook-url <url>')
    .description('设置云之家 webhookUrl')
    .action(async (url: string) => {
      const cfg = await loadConfig();
      cfg.channels = cfg.channels ?? {};
      cfg.channels.yzj = {
        ...(cfg.channels.yzj ?? {}),
        webhookUrl: url,
      };
      await saveConfig(cfg);
      console.log('已设置 channels.yzj.webhookUrl');
    });

  configSet
    .command('yzj-inbound-mode <mode>')
    .description('设置云之家入站模式（webhook / websocket）')
    .action(async (mode: string) => {
      if (mode !== 'webhook' && mode !== 'websocket') {
        console.error('inbound-mode 仅支持 webhook 或 websocket');
        return;
      }
      const cfg = await loadConfig();
      cfg.channels = cfg.channels ?? {};
      cfg.channels.yzj = {
        ...(cfg.channels.yzj ?? {}),
        inboundMode: mode,
      };
      await saveConfig(cfg);
      console.log(`已设置 channels.yzj.inboundMode = ${mode}`);
    });

  configSet
    .command('yzj-webhook-path <path>')
    .description('设置云之家 webhook 路径')
    .action(async (path: string) => {
      const cfg = await loadConfig();
      cfg.channels = cfg.channels ?? {};
      cfg.channels.yzj = {
        ...(cfg.channels.yzj ?? {}),
        webhookPath: path,
      };
      await saveConfig(cfg);
      console.log(`已设置 channels.yzj.webhookPath = ${path}`);
    });

  configSet
    .command('yzj-webhook-port <port>')
    .description('设置云之家 webhook 监听端口')
    .action(async (port: string) => {
      const parsed = Number(port);
      if (!Number.isInteger(parsed) || parsed <= 0) {
        console.error('webhook-port 必须是正整数');
        return;
      }
      const cfg = await loadConfig();
      cfg.channels = cfg.channels ?? {};
      cfg.channels.yzj = {
        ...(cfg.channels.yzj ?? {}),
        webhookPort: parsed,
      };
      await saveConfig(cfg);
      console.log(`已设置 channels.yzj.webhookPort = ${parsed}`);
    });

  configSet
    .command('yzj-secret <secret>')
    .description('设置云之家 webhook 签名 secret')
    .action(async (secret: string) => {
      const cfg = await loadConfig();
      cfg.channels = cfg.channels ?? {};
      cfg.channels.yzj = {
        ...(cfg.channels.yzj ?? {}),
        secret,
      };
      await saveConfig(cfg);
      console.log('已设置 channels.yzj.secret');
    });

  config
    .command('get <key>')
    .description('获取配置项（如 model）')
    .action(async (key: string) => {
      const cfg = await loadConfig();
      if (key === 'model') {
        const m = cfg.models[cfg.defaultModelId];
        console.log(`${cfg.defaultModelId}${m ? ` (${m.provider}/${m.model})` : ''}`);
      } else if (key === 'models') {
        console.log(JSON.stringify(cfg.models, null, 2));
      } else if (key === 'providers') {
        console.log(JSON.stringify(cfg.providers, null, 2));
      } else if (key === 'yzj') {
        console.log(JSON.stringify(cfg.channels?.yzj ?? null, null, 2));
      } else if (key === 'yzj.webhook-url') {
        console.log(cfg.channels?.yzj?.webhookUrl ?? '');
      } else if (key === 'yzj.inbound-mode') {
        console.log(cfg.channels?.yzj?.inboundMode ?? '');
      } else if (key === 'yzj.webhook-path') {
        console.log(cfg.channels?.yzj?.webhookPath ?? '');
      } else if (key === 'yzj.webhook-port') {
        console.log(cfg.channels?.yzj?.webhookPort ?? '');
      } else if (key === 'system-one' || key === 'systemOne') {
        // 永远不打印明文 Key，只回报来源与生效参数。
        const resolved = resolveSystemOneConfig(cfg);
        console.log(JSON.stringify({
          configured: resolved.configured,
          keySource: resolved.keySource,
          keyEnvVar: resolved.keyEnvVar,
          baseUrl: resolved.baseUrl,
          model: resolved.model,
        }, null, 2));
      } else {
        console.log(JSON.stringify((cfg as unknown as Record<string, unknown>)[key] ?? null, null, 2));
      }
    });
}
