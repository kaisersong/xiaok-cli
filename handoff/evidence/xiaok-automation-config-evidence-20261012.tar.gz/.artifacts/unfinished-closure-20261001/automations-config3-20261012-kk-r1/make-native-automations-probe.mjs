import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
const r = process.cwd(), e = resolve(r, '.artifacts/unfinished-closure-20261001/automations-config3-20261012-kk-r1');
const ts = (await import(pathToFileURL(join(r, 'desktop/node_modules/typescript/lib/typescript.js')).href)).default;
const source = readFileSync(join(r, 'desktop/electron/main.ts'), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
let auth; const selected = [];
function visit(node) {
  if (ts.isFunctionDeclaration(node) && node.name?.text === 'authorizeDesktopInvoke') auth = node.getText(ast);
  if (ts.isVariableStatement(node)) for (const d of node.declarationList.declarations) if (['globalBackgroundAutoRunEnabled', 'automationConfigOwner', 'automationConfigProducers'].includes(d.name.getText(ast))) selected.push(node.getText(ast));
  if (ts.isExpressionStatement(node) && ts.isCallExpression(node.expression) && ['registerAutomationConfigIpc', 'automationConfigProducers.set'].includes(node.expression.expression.getText(ast))) selected.push(node.getText(ast));
  ts.forEachChild(node, visit);
} visit(ast);
if (!auth || selected.length !== 5) throw Error('actual_main_automation_source_census_changed');
const js = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
const root = realpathSync(mkdtempSync(join(tmpdir(), 'xiaok-automations-probe-'))), dir = join(root, 'desktop/dist/main/desktop/electron'), renderer = join(root, 'desktop/dist/renderer/index.html');
mkdirSync(dir, { recursive: true }); mkdirSync(join(root, 'desktop/dist/renderer'), { recursive: true });
writeFileSync(renderer, '<!doctype html><meta charset="utf-8"><title>Owned automation component fixture</title>');
const module = path => JSON.stringify(pathToFileURL(join(r, 'desktop/dist/main', path)).href), preload = JSON.stringify(join(r, 'desktop/electron/preload.cjs'));
const script = join(dir, 'native-automations.mjs');
const text = `import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {writeFile,readFile} from 'node:fs/promises';import{join,dirname}from'node:path';import{fileURLToPath}from'node:url';
import{ShutdownAwareIpcMain,DesktopShutdownGate}from ${module('desktop/electron/shutdown-aware-ipc-main.js')};
import{isTrustedDesktopRendererUrl,buildBrowserWindowOptions}from ${module('desktop/electron/security.js')};
import{createMeetingRecorderWindowController}from ${module('desktop/electron/meeting-recorder-window.js')};
import{createAutomationConfigOwner}from ${module('desktop/electron/automation-config-owner.js')};
import{registerAutomationConfigIpc}from ${module('desktop/electron/automation-config-typed-ipc.js')};
import{buildAutomationOverviewSnapshot}from ${module('desktop/electron/automation-overview.js')};
import{loadConfig,saveConfig,updateGlobalBackgroundAutoRun as actualUpdate}from ${module('src/utils/config.js')};
import{DEFAULT_CONFIG}from ${module('src/types.js')};
const root=${JSON.stringify(root)},rendererFile=${JSON.stringify(renderer)},__dirname=dirname(fileURLToPath(import.meta.url));
process.env.XIAOK_CONFIG_DIR=join(root,'owned-config');app.setPath('userData',join(root,'electron-user-data'));
let mainWindow=null,meetingRecorderController=null;
${js(auth)}
const gate=new DesktopShutdownGate(),shutdownAwareIpc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke);
let writes=0;const updateGlobalBackgroundAutoRun=(enabled,source)=>{writes++;return actualUpdate(enabled,source);};
const loopRuntime={loopStore:{listLoopDefinitions:()=>[],listLoopRuns:()=>[],getAutomationStoreVersion:()=>1}},timedActionStore={listActions:()=>[],listRuns:()=>[],getAutomationStoreVersion:()=>2};
const results=[],verify=(condition,code)=>{if(!condition)throw Error(code);};
const invoke=async(role,window)=>{for(const method of ['getAutomationsConfig','getAutomationOverviewSnapshot','setGlobalBackgroundAutoRun'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'('+(method==='setGlobalBackgroundAutoRun'?'{enabled:false}':'')+').then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await saveConfig({...structuredClone(DEFAULT_CONFIG),ownedMarker:'retained'});
${js(selected.join('\n'))}
const options=buildBrowserWindowOptions(${preload},{platform:process.platform});mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:${preload},rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-automation'});
const recorder=BrowserWindow.getAllWindows().find(window=>meetingRecorderController.ownsWebContents(window.webContents));verify(!!recorder,'actual_recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...options,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);
const old=mainWindow;mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_automation_failed');verify(typeof row.reply.value.globalBackgroundAutoRunEnabled==='boolean','flag_contract_changed');if(row.method==='getAutomationOverviewSnapshot')verify(row.reply.value.sourceVersions.loopStore===1&&row.reply.value.sourceVersions.timedActionStore===2&&row.reply.value.recentFailures.length===0,'full_overview_changed');if(row.method==='setGlobalBackgroundAutoRun')verify(row.reply.value.globalBackgroundAutoRunEnabled===false,'mutation_ack_changed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_automation_admitted');}
const disk=JSON.parse(await readFile(join(root,'owned-config/config.json'),'utf8'));verify(writes===3,'unowned_reached_real_config_writer');verify(disk.automations.globalBackgroundAutoRunEnabled===false&&disk.ownedMarker==='retained','actual_config_write_changed');verify(gate.outstanding===0,'ipc_token_leak');
await writeFile(${JSON.stringify(join(e, 'native-automations-r1.json'))},JSON.stringify({actualElectron:true,actualMainAuthorizer:true,actualMainProducerStatements:true,actualShutdownOwner:true,actualRecorderController:true,actualPreloadCjs:true,actualConfigSemanticWriter:true,ownedTemporaryConfigOnly:true,surrogateReadonlyStoresOnly:true,realCredentialsRead:false,installedOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,results,writes,ownedMarkerPreserved:true,gateOutstanding:gate.outstanding},null,2));
meetingRecorderController.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1);});`;
writeFileSync(script, text); writeFileSync(join(e, 'native-automations-script-r1.mjs'), text);
writeFileSync(join(e, 'native-automations-script-r1.json'), JSON.stringify({ root, script, renderer, actualAuthorizerSource: auth, actualProducerStatements: selected, realConfigWriter: true, readonlyStoreBoundarySurrogates: true }, null, 2));
console.log(JSON.stringify({ root, script, actualSelectedStatements: selected.length }));
