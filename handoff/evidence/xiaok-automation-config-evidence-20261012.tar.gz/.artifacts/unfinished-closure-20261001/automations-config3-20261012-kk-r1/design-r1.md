# Automations config3 续跑设计 R1

范围为原 298 中的 `desktop:automations:getConfig`、`desktop:automations:getOverviewSnapshot`、`desktop:automations:setGlobalBackgroundAutoRun`。当前仅设计，未评审、未实现、未增加计数。此前被平台中断的 material/native/P4 不在此工作中重试。全部原父人口、时限、失败和最终安装/主干验收保留。

## 源码事实

Main 的 `globalBackgroundAutoRunEnabled` 是 scheduler 的当前读取事实；初始化使用既有 loadConfig 的 legacy/default 语义。set handler 在 saveConfig 完成前就改这个变量，写失败会让 scheduler 与持久配置分裂。两个并发 setter 可交错 load/save，没有顺序 owner。

AutomationsPage 同时发 overview 与 config 两个读取，任意旧读取可能覆盖较新的动作结果；读取失败制造 enabled=true 和零计数 snapshot。toggle 没有 catch 或同步 busy ref，不能向用户区分保存失败和结果未知。Overview 的两个清历史动作各自读取后直接覆盖 snapshot。WelcomePage 是第二个 overview 消费者，已有 error 状态，但没有完整契约验证。

src/utils/config.ts 的 loadConfig/saveConfig 声明 async，但内部 filesystem 全部同步。loadConfig 当前有默认值、坏 JSON 备份、normalization 与文件权限行为；saveConfig 先收紧旧文件，再写并检查权限。不得改这些既有输入语义或绕过原权限检查。保存可能已写磁盘、后置权限检查才失败，不能声称失败必然未写。

同权限 census：Main 是该字段的唯一语义 setter；desktop services 中模型/provider/preferences/connectors 等其它 saveConfig 调用也共享整个 config 文件。CLI config、generic write/bash 和 agent policy 仍是父 all-writer 边界，不能把本组 user facade 宣称为全局 config 保护。对用户正常设置路径不增加确认或 proposal-only 步骤。

逐文件写入口还包括 ipc.ts 的 meeting:saveAsrConfig、src/commands/config.ts 多个设置动作，以及 chat.ts、yzj.ts、login.ts 的配置保存。login 追踪原 saveConfig Promise 的 cancellation 语义必须保持；同步函数提取不能把原 async export 的 throw 变成同步 throw。generic write 调用 assertWorkspacePath，bash 走 risk policy；此清单是源码路径普查，不读取真实 config/Key，也不以测试替身宣称 OS 或这些其它写入口已经全局受控。

## 契约与 owner

新增独立 round30 registrar/producers map，三个 channel 替换旧 raw 注册而不重复注册。读取 input 为 tuple[]；setter 为 tuple[{enabled:boolean}]，先 capture 原数据再 schema 检查，不读 getter/proxy/toJSON。输出 config 完整 boolean DTO；overview 包含 generatedAt、两个 sourceVersions、global flag、六个 totals、完整 recentFailures（id/source/ownerId/title/status/message?/occurredAt/loopId?/loopOrigin?/actionId?/actionAvailableInSchedules?）。对象 passthrough 保留未知字段，数组保留全部项，不裁人口；数值有限，原空字符串与 optional 仍合法。输出在通用 IPC runtime 之前 capture+safeParse，失败抛固定 operation_unknown，不能用成功空 DTO 或 resolved error envelope 替代。

新 Main-owned config service 负责读取和 setter。setter 显式 requestSource，只允许 host user，缺失/agent/scheduler 在任何配置读取或写入之前拒绝；Main 的 user 注入必须在现有唯一 Main+Recorder/frame/URL admission 内，不接受 payload source。overview 继续调用原 buildAutomationOverviewSnapshot，不在测试或新 facade 重写统计逻辑。

持久化候选：把原 loadConfig/saveConfig 同步实现提为私有同步函数，原 async export 作为保持 ABI 的薄包装；新增只接受 boolean 和显式 requestSource 的同步语义 update 函数，缺失/agent/scheduler 在 filesystem 访问之前 default deny，只允许 user。fresh load → 修改唯一 automations 字段（保全部现有字段）→ 原 save 全部权限检查在同一 JS turn 完成。不在读写之间 await，不用异步排队的 stale whole config。这只避免本组 setter 主动跨 await 造成的交错，不宣称所有其它异步 read-modify-save writer 已实现全局事务，不改变磁盘原写入原子性或 all-writer 父条件。

service 只有在持久化函数确认标准 completion 后更新 Main 的 scheduler fact。若写或后置检查失败，保留上次已确认内存值并传播 operation_unknown，不进行重试/回滚/假 ACK；实际磁盘可能已变化，UI提示未知结果和仅只读刷新。读 config 的 snapshot 表达当前 Main 已确认值，避免失败的 load default 作为正常最新写回执。重启初始化沿原 loadConfig 语义单独验证。

## Renderer

AutomationPage 以完整 overview 作为首次读取 owner，不再并发用 config 读取重复同一 flag；config API 仍保留供独立调用者。初始 null/未知状态使 toggle 不可用，不能默认显示已启用或健康零计数。失败展示 t 文案和只读重试，保 last-good。

所有 overview 读取（首次、手动、两个清历史后的刷新）复用 singleflight owner；忙时显式刷新至多排一个，轮询不新增。mount lifetime、read generation 与动作 revision 防止 held initial/read 在 setter 成功后回写旧 flag；unmount 丢弃迟到完成。动作 ref 同步防双击、busy 禁按钮，locale 切换不使已授权动作重新发起或丢弃结果，错误 kind 使用当前 t。setter 返回完整 DTO 才更新 flag，同时推进 revision；reject/坏输出显示结果未知，保确认值，不自动重试，不因成功读取清动作未知。

overview 和 config 的所有 renderer/preload types 从 shared contract 推导，CJS 的 0/0/1 参数 ABI 保留。WelcomePage 维持既有 loading/error/ready 和导航，失败不能制造空成功；全部旧正面样本完整 shape，旧断言不得删除。

## 先 RED、后实现的控制

1. actual Main AST 入口：零参、坏 setter 输入、越权窗口、合法 Recorder、source default deny；getter/proxy/serializer、标准 Promise、完整输出/unknown extras/每次 detached snapshot。
2. 实际共享 config 临时目录：save 原权限/normalization/坏 JSON/default 行为不变；其它 config 字段保留；两个 setter 与其它原 writer 的实际交错明确记录，不能模拟出全局事务资格。
3. setter held save 时 scheduler 仍旧值；reject（包括写后检查失败）不发布新事实，原 shutdown token/5s default/未确认关闭行为保留。若同步持久化无法制造 held，held 只用于 service 合法异步 boundary negative control，不宣称生产同步 IO 可被同进程其它写入打断。
4. actual buildAutomationOverviewSnapshot 的原完整测试保留；store throw/坏完整输出拒绝，不隐藏失败项；完整数值/optional/unknown 数据保留。
5. actual AutomationsPage + WelcomePage：初始失败不显示启用或健康零值，last-good、重试、held read 不覆盖 setter、doubleclick 一次、locale/unmount、动作失败不 unhandled rejection、不读取任意 error.message；两个清历史动作刷新仍保原成功/拒绝与导航。
6. TS/CJS 真 ABI、两实际 census 原断言保留；相关整族与完整 Main/Renderer strict 原 configs、gov/changed/testlint、两构建；真实 Electron source probe只作组件证据，不充当正常安装/native/全UI。

设计独审必须先决定共享 config 同步提取是否必要且未改变原语义，以及同权限兄弟 census 是否充分。若要求全局事务改造，本组不得用缩范围消除原父 all-writer 条件；先记录 BLOCK 和必要后继范围，再做测试/生产。完整 CODE 后才可 +3，当前 +0；全部父门过后才按用户已授权合并主干测试。
