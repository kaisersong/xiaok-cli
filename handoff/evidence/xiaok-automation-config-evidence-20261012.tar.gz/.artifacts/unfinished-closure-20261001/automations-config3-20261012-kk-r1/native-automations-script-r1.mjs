import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {writeFile,readFile} from 'node:fs/promises';import{join,dirname}from'node:path';import{fileURLToPath}from'node:url';
import{ShutdownAwareIpcMain,DesktopShutdownGate}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import{isTrustedDesktopRendererUrl,buildBrowserWindowOptions}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import{createMeetingRecorderWindowController}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import{createAutomationConfigOwner}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/automation-config-owner.js";
import{registerAutomationConfigIpc}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/automation-config-typed-ipc.js";
import{buildAutomationOverviewSnapshot}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/automation-overview.js";
import{loadConfig,saveConfig,updateGlobalBackgroundAutoRun as actualUpdate}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/src/utils/config.js";
import{DEFAULT_CONFIG}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/src/types.js";
const root="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-automations-probe-cSMHte",rendererFile="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-automations-probe-cSMHte/desktop/dist/renderer/index.html",__dirname=dirname(fileURLToPath(import.meta.url));
process.env.XIAOK_CONFIG_DIR=join(root,'owned-config');app.setPath('userData',join(root,'electron-user-data'));
let mainWindow=null,meetingRecorderController=null;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

const gate=new DesktopShutdownGate(),shutdownAwareIpc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke);
let writes=0;const updateGlobalBackgroundAutoRun=(enabled,source)=>{writes++;return actualUpdate(enabled,source);};
const loopRuntime={loopStore:{listLoopDefinitions:()=>[],listLoopRuns:()=>[],getAutomationStoreVersion:()=>1}},timedActionStore={listActions:()=>[],listRuns:()=>[],getAutomationStoreVersion:()=>2};
const results=[],verify=(condition,code)=>{if(!condition)throw Error(code);};
const invoke=async(role,window)=>{for(const method of ['getAutomationsConfig','getAutomationOverviewSnapshot','setGlobalBackgroundAutoRun'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'('+(method==='setGlobalBackgroundAutoRun'?'{enabled:false}':'')+').then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await saveConfig({...structuredClone(DEFAULT_CONFIG),ownedMarker:'retained'});
let globalBackgroundAutoRunEnabled = (await loadConfig()).automations?.globalBackgroundAutoRunEnabled !== false;
const automationConfigOwner = createAutomationConfigOwner({
    getEnabled: () => globalBackgroundAutoRunEnabled,
    onCommitted: enabled => { globalBackgroundAutoRunEnabled = enabled; },
    persist: (enabled, source) => updateGlobalBackgroundAutoRun(enabled, source),
});
const automationConfigProducers = new Map([
    ['desktop:automations:getConfig', () => automationConfigOwner.getConfig()],
    ['desktop:automations:setGlobalBackgroundAutoRun', (_event, input) => automationConfigOwner.setEnabled(input, 'user')],
]);
registerAutomationConfigIpc(shutdownAwareIpc, automationConfigProducers);
automationConfigProducers.set('desktop:automations:getOverviewSnapshot', () => buildAutomationOverviewSnapshot({
    loopStore: loopRuntime.loopStore,
    timedActionStore,
    globalBackgroundAutoRunEnabled,
}));

const options=buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",{platform:process.platform});mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:"/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-automation'});
const recorder=BrowserWindow.getAllWindows().find(window=>meetingRecorderController.ownsWebContents(window.webContents));verify(!!recorder,'actual_recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...options,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);
const old=mainWindow;mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_automation_failed');verify(typeof row.reply.value.globalBackgroundAutoRunEnabled==='boolean','flag_contract_changed');if(row.method==='getAutomationOverviewSnapshot')verify(row.reply.value.sourceVersions.loopStore===1&&row.reply.value.sourceVersions.timedActionStore===2&&row.reply.value.recentFailures.length===0,'full_overview_changed');if(row.method==='setGlobalBackgroundAutoRun')verify(row.reply.value.globalBackgroundAutoRunEnabled===false,'mutation_ack_changed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_automation_admitted');}
const disk=JSON.parse(await readFile(join(root,'owned-config/config.json'),'utf8'));verify(writes===3,'unowned_reached_real_config_writer');verify(disk.automations.globalBackgroundAutoRunEnabled===false&&disk.ownedMarker==='retained','actual_config_write_changed');verify(gate.outstanding===0,'ipc_token_leak');
await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/automations-config3-20261012-kk-r1/native-automations-r1.json",JSON.stringify({actualElectron:true,actualMainAuthorizer:true,actualMainProducerStatements:true,actualShutdownOwner:true,actualRecorderController:true,actualPreloadCjs:true,actualConfigSemanticWriter:true,ownedTemporaryConfigOnly:true,surrogateReadonlyStoresOnly:true,realCredentialsRead:false,installedOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,results,writes,ownedMarkerPreserved:true,gateOutstanding:gate.outstanding},null,2));
meetingRecorderController.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1);});