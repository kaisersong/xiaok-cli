import hashlib,json,subprocess,zipfile
from pathlib import Path
r=Path.cwd(); package=r/'desktop/node_modules/electron'
archive=Path('/Users/kk/Library/Caches/electron/41a5d68646d956d50e13830e121ea0b3d6ab378b6a0ce422aefc1ff214707879/electron-v39.8.10-darwin-arm64.zip')
expected=json.loads((package/'checksums.json').read_text())[archive.name]
actual=hashlib.sha256(archive.read_bytes()).hexdigest()
assert actual==expected,(actual,expected)
with zipfile.ZipFile(archive) as z:
 for entry in z.infolist():
  assert not Path(entry.filename).is_absolute() and '..' not in Path(entry.filename).parts
 binary='Electron.app/Contents/MacOS/Electron'
 expectedBinary=hashlib.sha256(z.read(binary)).hexdigest()
 version=z.read('version').decode().strip().removeprefix('v')
assert version==json.loads((package/'package.json').read_text())['version']
subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(package/'dist')],check=True)
actualBinary=hashlib.sha256((package/'dist'/binary).read_bytes()).hexdigest()
assert actualBinary==expectedBinary
(package/'path.txt').write_text(binary)
result={'archive':str(archive),'archiveSHA':actual,'expectedArchiveSHA':expected,'version':version,'binarySHA':actualBinary,'expectedBinarySHA':expectedBinary,'dependencyOnly':True,'productSourceWrites':0,'method':'checksum-verified official archive extracted by macOS ditto; installer previously exited with incomplete dist'}
(r/'.artifacts/unfinished-closure-20261001/resume-kk-20261011/electron-install-verified-r1.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
