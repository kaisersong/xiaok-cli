import {checkLint} from '../../../scripts/governance/lint.mjs';
import {writeFileSync} from 'node:fs';
const result=checkLint({paths:["desktop/tests/main/plugin-catalog-characterization.test.ts", "desktop/tests/main/plugin-catalog-main-controls.test.ts", "desktop/tests/main/plugin-catalog-preload.test.ts", "desktop/tests/renderer/plugin-catalog-read-errors.test.tsx", "desktop/tests/renderer/plugin-catalog-mcp-read-errors.test.tsx", "desktop/tests/main/ipc-schema-coverage.test.ts", "desktop/tests/main/updater-main-controls.test.ts"]});
writeFileSync(process.argv[2],JSON.stringify(result,null,2),{flag:'wx'});
console.log(JSON.stringify({files:result.files,diagnostics:result.diagnostics,newViolations:result.newDiagnostics.length}));
process.exitCode=result.newDiagnostics.length?1:0;
