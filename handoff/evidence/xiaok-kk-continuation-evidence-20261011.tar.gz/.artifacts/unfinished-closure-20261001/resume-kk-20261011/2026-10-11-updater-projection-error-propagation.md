# Updater3 Main 投影失败传播：跨机器续接

范围为检查点 `bf1ad38c` 中 Updater3 的 R47 CODE BLOCK；不改变原298人口、原组件/父验收、状态机、安装权限或时限。

## 现状与根因

`desktop/electron/main.ts` 的 getUpdateStatus producer 捕获 owner 的所有同步异常，返回 checking/available/downloading/downloaded 全 false、progress=0 的成功 DTO。`updater.ts:getUpdateStatus` 在 production 模式调用 `captureUpdateStatus`；该边界拒绝坏投影并抛 `updater_projection_unavailable`。Main 的 catch 将此失败变成合法成功，typed registrar 无法识别。About/Sidebar 因成功读取覆盖 last-good，丢失已下载事实。

SDK 普通错误由 owner 自己记录在有效 UpdateStatus.error 中；开发模式也由 owner 返回正常错误状态。它们不是 owner 读取抛异常。现有坏 NaN 返回测试未覆盖 owner throw。

## 最小合同变化

删除这个只读 producer 的 catch，保持 `{ ...getUpdateStatus(), currentVersion: app.getVersion() }`。所有 owner 读取或当前版本读取异常沿现有 registrar/IPC rejection 传播，不检查异常 message，不读取任意异常对象 accessor，也不制造成功快照。合法的 SDK error 状态、开发模式状态、完整字段、无参数 tuple、主窗口认证、snapshot 脱别名、安装 ACK 与 checkForUpdates 的既有 void 合同不变。

这明确批准原 catch 中普通 throw 也拒绝的合同：抛异常没有可用事实，不能再将它视为成功读取。两个 renderer 已在拒绝时保存已知状态并显示 localized 错误，不新增自动重试、轮询或副作用。

## 对抗性评审问题与验证顺序

独立 QoderCLI 只读设计评审后，先在现有 actual Main AST/compileFunction fixture 增加 owner projection throw、普通 throw、异常 message getter 零读取，以及有效含 SDK error 的完整 snapshot 控制。新回归需先实际 RED；现有 About 已下载后 refresh reject 及 Sidebar 控制保留，调用真实组件。然后仅删上述 catch。

拒绝路径通过真正 registerUpdaterIpc 走 input/source/output 链，不在测试重新实现 producer。Main 的 throw 必须使 invoke reject；只断言日志或 mock API 拒绝不足以关闭 R47。全部原 Updater 文件/用例及新增控制、preload 两 contract、当前 Main/Renderer 类型、governance、实际 build 都在新 epoch 留原始日志；fresh 独立整组件 CODE 前正式计数仍203/298。安装/native/Windows/全部父验收另列，不能用这张源码票替代。

评审应检查：兄弟读事件 sendUpdateStatus 已丢弃坏投影而不发送空快照；check/install 是不同命令，不借本次改动吞/改写其错误；权限门仍在 payload 前；普通 SDK 错误仍有效 DTO；抛出的 getter-bearing 对象不能由 Main catch 读取；currentVersion 抛错同样不可成功；UI refresh 不清 last-good 或触发安装。
