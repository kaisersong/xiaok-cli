# 插件目录只读 IPC 3 设计 R1

范围仅原 desktop:listPluginMcpServers、desktop:listAvailablePlugins、desktop:listPluginDependencyStatuses；来源实际 ipc.ts:1319/1341/1342，尚无 typed registrar。保原人口298与其他已接受入口。不是安装、更新、诊断、CUA激活、ASR、权限操作或全native资格修复。

## 实际语义与字段

- desktop-services.ts:3112 返回 main 的 live pluginMcpServers 数组。字段 name/pluginName/toolCount/connected/enabled，optional lastError/lastErrorDetail。detail category 为 python_version_too_old/python_module_missing/null，message，optional detectedVersion/requiredVersion/command/missingModule。
- desktop-services.ts:3193 实际 fetch固定registry.json，!ok或任何catch返回[]，data.plugins||[] spread全部p字段并以本地plugin.json存在覆盖installed。sibling registry实际name/display_name/description/category/keywords/repo/path/version/dependencies，依赖内runtime/install/test；其它未知JSON字段也保留。5字段TypeScript注解不是实际wire5字段。网络失败继续[]兼容，不改为throw、不触发安装。
- desktop-services.ts:3206 Promise.all原pluginDependencies/getDependencyStatusView，后者:1225含pluginName/pluginInstalled、完整getPluginDependencyStatus输出和task（undefined或taskId/dependencyId/state running/cancelling）。状态ready/missing/needs_permission/degraded/unsupported，code当前10个业务值，resolvedBinary/version/detail optional，canInstall/canUpdate/canDiagnose。getPluginDependencyStatus:174会读binary/version/permissions；getDependencyStatusView在Windows读取native architecture与active private release，读取不授安装/激活。保原实现和错误传播，不改平台判定。

## 最小生产变更

增加shared/plugin-catalog-ipc-contract.ts与electron/plugin-catalog-typed-ipc.ts，原3handler换单一registerPluginCatalogIpc(ipcMain,services)。复用原IPC_SCHEMA_REGISTRY/registerIpcHandler；新增round26。三个入参z.tuple([])，保preload原3无参数调用与CJS字节。原3读取之前校验wire；仅新extra transport拒绝，不加requestSource/grant/新授权源。无新service poller。

返回先captureIpcData（preserveDataPrototype），再safeParse，成功返回完整snapshot而不是Zod parsed result。MCP与依赖以及lastErrorDetail/task全部passthrough；数值finite但不clamp；category/state保实际enum，code string保正常未来业务码；Available必需原5字段，category/keywords/repo/path/dependencies作为实际optional typed字段，passthrough保所有unknown JSON字段。数组/对象snapshot脱离owner，拒getter/proxy/非数据对象等沿原snapshot规则，不新增V8改写探针。只观察原标准Promise，复用assertStandardIpcPromise，捕获nativeThen/Reflect.apply，保业务同步throw/异步reject，不retry、不catch成空。

preload-api与renderer type引用共享DTO；MCP本地interface替换为共享type，PluginsSettings使用同type，不加通用通道。CJS3原tuple不变，contract测试实际执行TS/CJS。

## UI

PluginsSettings当前加载catch两数组清空；McpPane当前2s Promise.all逐catch[]清空。改为allSettled，对成功分支更新，相应失败保最近成功内容且显示t.desktopSettings.pluginsCatalogUnavailable，首失败显示错误+既有empty，不说已空目录。保持现2s timer与手工load，不新增poll owner。加当前load generation防旧响应覆盖新响应。PluginsSettings显式重试按钮走原loadData；MCP原下一2s读取可恢复。保 available service返回[]兼容（其网络失败仍是成功空）。loading/tools/connected/unavailable本次触及字符串全t，三个locale同步。安装动作原路径/逻辑保持。

## 验证

先真实生产method AST编译char：sibling完整registry字段+unknown extras/exists覆盖、!ok/throw/malformed[]、owner array别名基线、真实getDependencyStatus平台Windows unsupported/missing/ready与fulltask。只使用owned注入command返回，不执行任何真实依赖命令/安装。回归先RED生产新增registrar缺口、extraarg、完整DTO无别名、业务reject；UI读失败/晚到响应先RED。实现后真正actual registration来自ipc.ts AST的原生产调用；typed registry只此3且原preload channels/arity/名称不变。必要原desktop-services/plugin dependency/MCP panes/Plugins/UI/preload/parity相关人口保，不重复已绿无关。

完整Main/renderer strict、governance/changed、main/renderer build须当前同source epoch，由CPU O_EXCL lease ready-before-spawn，actual exit/wait/reap/groupGone之后sameowner/token release；源扫描before/after SHA与Model协调。所有artifact唯一wx，foreign WIP/index/merge/baseline/原时限不动。独立DESIGN先AP再production，fresh独立CODE后才新增3组件票，不授installed/native/fullparent。

## 当前真实 baseline R2

artifact catalog3-ipc-design-20261011-r1/actual-char-r2.json：原生产AST四项characterization全部通过，0 skip，worker exit/reap/groupGone，lease sameowner/token释放。original-census-r3.json逐项核原298 linkage，三项均在remaining而非oldcovered。当前hygiene exit1因branch behind71/no upstream/foreigndirty与sibling foreigndirty/untracked；不清理。CLI普通消费者 context/config 与 installer/probe独立读plugin配置，不走这3 Desktop IPC，全部原CLI人口保，不改。

## R2 Root 独审修正

generation不能每2s盲递增：version/permission或网络读取可能超过2s，盲丢stale会永久饥饿。MCP保原唯一2s timer，使用同owner singleflight（pending token），忙时跳过tick，不启动第二请求、不递增generation。首真实慢请求超过2s之后resolve仍可更新lastgood并退出loading。PluginsSettings手工load亦singleflight；retry在前请求已settle后才启动，不增加timer。卸载时generation失效且清本owner pending；旧finally只有token相同才清pending，不清后继读。Promise.allSettled保每分支lastgood；不新建轮询源。原r5“旧响应覆盖新timer结果”case确实揭示旧逻辑风险，但后继采用singleflight后该测试改为原held超过2s→tick不重叠→release更新；旧r5原始源码/RED在design-input-r6副本保留。

只在IPC传输边界进行capture/snapshot，desktop-services.ts listPluginMcpServers公共getter仍返回livearray（原char仍true），不夸所有service别名闭合。可用目录service仍保持catch[]原业务合同。共享preload/Settings/locales允许Updater合法后继，按精确hunk以current source核，不restore旧whole14freeze。

## R3 手工重读窄后继（Root消息授权）

Root允许busy明确手工load或安装success时只记一枚boolean，当前pending settle后最多一次新读取；卸载clear，旧finally不启动后继。Plugins retry/安装success都通过原loadData，busy时queue；MCP action success原load()同理queue，但2s timer明确load(false)，busy timer只skip。无并行读取、无新timer。实际held→manual→release回归先RED（actual-manual-queue-red-r13），后最小生产与green；原旧票保。
