# Catalog 原 schema 扫描失败的测试装配修正

检查点的 ipc-schema-coverage.test.ts 保留原4项与所有 expect，但它只从 ipcMain/shutdownAwareIpc/fileHandler 字面量枚举。Scheduled17 正式迁移后 main 原 loops:createSchedule 属于 scheduledIpc producer，真实 wire 注册由 registerScheduledTimedActionIpc 完成。扫描遗漏而非频道被删除。当前 Catalog 注册只是暴露了旧扫描缺口，不借此修改产品。

候选仅 import 并执行真正 registerScheduledTimedActionIpc，和原其余6个 typed registrar 一样传只接收频道的 registrar、不给 producer、不调用 handler，无伪 DTO/权限/运行。保留原全部4个用例、断言、人口和时限，额外 enumerate 该生产 registrar 原17频道。先新机原 RED，独立审确认实际 channel owner，后测试装配窄修，再相同6files/76用例后继及新增文件 lint/full类型。原75PASS/1FAIL历史仍保。源计数与父验收不因本修补提前改变。
