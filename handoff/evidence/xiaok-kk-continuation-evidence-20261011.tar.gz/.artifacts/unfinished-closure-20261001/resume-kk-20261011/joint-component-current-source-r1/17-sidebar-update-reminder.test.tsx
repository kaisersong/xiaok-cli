import React from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';

import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';
import { SidebarComponent } from '../../renderer/src/components/Sidebar';

const mockApi = vi.hoisted(() => ({
  listThreads: vi.fn(),
  getThread: vi.fn(),
  createThread: vi.fn(),
  updateThreadTaskId: vi.fn(),
  deleteThread: vi.fn(),
  updateThreadTitle: vi.fn(),
  getUpdateStatus: vi.fn(),
  checkForUpdates: vi.fn(),
  quitAndInstall: vi.fn(),
  onUpdateStatus: vi.fn(),
}));

const mockKSwarmState = vi.hoisted(() => ({
  projects: [] as Array<{ id: string; name: string; status: string }>,
}));

vi.mock('../../renderer/src/api', () => ({
  api: mockApi,
}));

vi.mock('../../renderer/src/contexts/KSwarmContext', () => ({
  useKSwarm: () => ({ projects: mockKSwarmState.projects }),
}));

const mockThreadList = vi.hoisted(() => ({
  threads: [] as unknown[],
  removeThread: vi.fn(),
  updateTitle: vi.fn(),
  loading: false,
}));

vi.mock('../../renderer/src/contexts/thread-list', () => ({
  useThreadList: () => mockThreadList,
}));

function LocationProbe() { return <output data-testid="sidebar-location">{useLocation().pathname}</output>; }

function renderSidebar(status: {
  checking: boolean;
  available: boolean;
  downloading: boolean;
  downloaded: boolean;
  installing?: boolean;
  progress: number;
  version?: string;
  currentVersion?: string;
  error?: string;
}, initialEntry = '/', threads: unknown[] = []) {
  mockThreadList.threads = threads;
  mockApi.listThreads.mockResolvedValue(threads);
  mockApi.getThread.mockResolvedValue(null);
  mockApi.createThread.mockResolvedValue({
    id: 'created-thread',
    title: null,
    currentTaskId: null,
    taskIds: [],
  });
  mockApi.updateThreadTaskId.mockResolvedValue(undefined);
  mockApi.getUpdateStatus.mockResolvedValue(status);
  mockApi.onUpdateStatus.mockReturnValue(() => {});
  mockApi.checkForUpdates.mockResolvedValue(undefined);
  mockApi.quitAndInstall.mockResolvedValue(undefined);

  render(
    <MemoryRouter initialEntries={[initialEntry]}>
      <LocaleProvider>
        <SidebarComponent onOpenSettings={() => {}} />
        <LocationProbe />
      </LocaleProvider>
    </MemoryRouter>,
  );
}

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.clearAllMocks();
  localStorage.clear();
  mockKSwarmState.projects = [];
  Object.defineProperty(window, 'xiaokDesktop', {
    value: undefined,
    configurable: true,
  });
});

describe('Sidebar update reminder', () => {
  it('keeps a conversation visible and reports pending cleanup when main refuses final deletion', async () => {
    mockApi.deleteThread.mockRejectedValueOnce(new Error('thread_deletion_pending'));
    renderSidebar({ checking: false, available: false, downloading: false, downloaded: false, progress: 0 }, '/', [{
      id: 'delete-thread', title: 'Delete safety', taskIds: [], currentTaskId: null, mode: 'work', status: 'idle', starred: false, createdAt: 1, updatedAt: 1,
    }]);
    const row = await screen.findByTestId('thread-item-delete-thread');
    const button = row.querySelectorAll('button')[row.querySelectorAll('button').length - 1];
    fireEvent.click(button); fireEvent.click(button);
    await waitFor(() => expect(mockApi.deleteThread).toHaveBeenCalledWith('delete-thread'));
    expect(await screen.findByRole('alert')).toHaveTextContent('仍有执行或资源尚未回收');
    expect(mockThreadList.removeThread).not.toHaveBeenCalled(); expect(row).toBeInTheDocument();
  });
  it('localizes the built-in assistant schedule names by stable id', async () => {
    Object.defineProperty(window, 'xiaokDesktop', {
      value: {
        getScheduledTasks: vi.fn().mockResolvedValue([
          { id: 'assistant:default-personal-assistant:morning', name: 'Personal assistant morning briefing', frequency: 'daily' },
          { id: 'assistant:default-personal-assistant:evening', name: 'Personal assistant evening reflection', frequency: 'daily' },
        ]),
        getTimedActionRuns: vi.fn().mockResolvedValue([]),
      },
      configurable: true,
    });

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    });

    fireEvent.click(screen.getByRole('tab', { name: '定时', exact: true } as Parameters<typeof screen.getByRole>[1]));
    expect(await screen.findByRole('button', { name: '每日助理晨间建议 daily' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '每日助理晚间整理 daily' })).toBeInTheDocument();
    expect(screen.queryByText('Personal assistant morning briefing')).not.toBeInTheDocument();
  });

  it('uses Automations as the top-level navigation entry for scheduled work', async () => {
    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/automations/schedules');

    expect(await screen.findByRole('button', { name: '自动化' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '定时任务' })).not.toBeInTheDocument();
  });

  it('opens a popover with a version comparison when the reminder is clicked', async () => {
    renderSidebar({
      checking: false,
      available: true,
      downloading: false,
      downloaded: false,
      progress: 0,
      version: '1.3.1',
      currentVersion: '1.3.0',
    });

    const button = await screen.findByRole('button', { name: '升级到 1.3.1' });
    expect(button).toBeInTheDocument();

    fireEvent.click(button);

    expect(await screen.findByText('v1.3.0')).toBeInTheDocument();
    expect(screen.getByText('v1.3.1')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /下载更新/ })).toBeInTheDocument();
  });

  it('starts auto-update download when the download button is clicked', async () => {
    const openSpy = vi.spyOn(window, 'open').mockReturnValue(null);

    renderSidebar({
      checking: false,
      available: true,
      downloading: false,
      downloaded: false,
      progress: 0,
      version: '1.3.1',
      currentVersion: '1.3.0',
    });

    const button = await screen.findByRole('button', { name: '升级到 1.3.1' });
    fireEvent.click(button);

    const downloadButton = await screen.findByRole('button', { name: /下载更新/ });
    fireEvent.click(downloadButton);

    expect(mockApi.checkForUpdates).toHaveBeenCalledTimes(1);
    expect(openSpy).not.toHaveBeenCalled();

    openSpy.mockRestore();
  });

  it('downloaded state shows restart-and-install button', async () => {
    vi.spyOn(window, 'open').mockReturnValue(null);

    renderSidebar({
      checking: false,
      available: true,
      downloading: false,
      downloaded: true,
      progress: 100,
      version: '1.3.1',
      currentVersion: '1.3.0',
    });

    const button = await screen.findByRole('button', { name: '升级到 1.3.1' });
    fireEvent.click(button);

    const installButton = await screen.findByRole('button', { name: /立即重启安装/ });
    fireEvent.click(installButton);

    expect(mockApi.quitAndInstall).toHaveBeenCalledTimes(1);
    expect(mockApi.checkForUpdates).not.toHaveBeenCalled();
  });

  it('shows handoff diagnostics even when the update is still downloaded', async () => {
    renderSidebar({ checking: false, available: true, downloading: false, downloaded: true,
      installing: false, progress: 100, version: '1.5.3', currentVersion: '1.5.2',
      error: 'update_install_handoff_unconfirmed' });
    fireEvent.click(await screen.findByRole('button', { name: '安装交接未确认' }));
    expect(screen.queryByRole('button', { name: /立即重启安装/ })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: /前往 GitHub 下载/ })).toBeInTheDocument();
    expect(screen.queryByText('update_install_handoff_unconfirmed')).not.toBeInTheDocument();
    expect(screen.getAllByText(/尚未确认系统接管安装，后台仍可能继续/)).toHaveLength(1);
  });

  it('shows a quiet manual download hint when update checks do not complete', async () => {
    const openSpy = vi.spyOn(window, 'open').mockReturnValue(null);

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
      currentVersion: '1.4.0',
      error: 'Cannot find latest-mac.yml',
    });

    const button = await screen.findByRole('button', { name: '检查更新未完成' });
    expect(button.className).not.toContain('border-amber');
    expect(button.className).not.toContain('bg-amber');
    expect(button.querySelector('svg')).toBeNull();

    fireEvent.click(button);

    expect(await screen.findAllByText('检查更新未完成')).toHaveLength(2);
    expect(screen.queryByText('更新检查失败')).not.toBeInTheDocument();
    expect(screen.getByText('v1.4.0')).toBeInTheDocument();
    expect(screen.getByText(/Cannot find latest-mac.yml/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /前往 GitHub 下载/ }));
    expect(openSpy).toHaveBeenCalledWith(
      'https://github.com/kaisersong/xiaok-cli/releases/latest',
      '_blank',
      'noopener,noreferrer',
    );

    openSpy.mockRestore();
  });

  it('lists scheduled tasks without a three-row nested scroll container on scheduled page', async () => {
    localStorage.setItem('xiaok:scheduled-tasks', JSON.stringify([
      { id: 'task-1', name: '定时任务 1', frequency: '每天' },
      { id: 'task-2', name: '定时任务 2', frequency: '每天' },
      { id: 'task-3', name: '定时任务 3', frequency: '每天' },
      { id: 'task-4', name: '定时任务 4', frequency: '每天' },
      { id: 'task-5', name: '定时任务 5', frequency: '每天' },
    ]));

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/scheduled');

    const lastTask = await screen.findByText('定时任务 5');
    const list = lastTask.closest('button')?.parentElement;

    expect(screen.getByText('定时任务 1')).toBeInTheDocument();
    expect(list).toBeTruthy();
    expect(list?.className).not.toContain('max-h-');
    expect(list?.className).toContain('overflow-y-auto');
  });

  it('lists active projects without a capped nested scroll container on projects page', async () => {
    mockKSwarmState.projects = [
      { id: 'project-1', name: '项目 1', status: 'active' },
      { id: 'project-2', name: '项目 2', status: 'planning' },
      { id: 'project-3', name: '项目 3', status: 'review' },
      { id: 'project-4', name: '项目 4', status: 'delivered' },
      { id: 'project-5', name: '项目 5', status: 'active' },
    ];

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/projects');

    const lastProject = await screen.findByText('项目 5');
    const list = lastProject.closest('button')?.parentElement;

    expect(screen.getByText('项目 1')).toBeInTheDocument();
    expect(list).toBeTruthy();
    expect(list?.className).not.toContain('max-h-');
    expect(list?.className).toContain('overflow-y-auto');
  });

  it('keeps sidebar project id and status hidden until the delayed hover details appear', async () => {
    mockKSwarmState.projects = [
      { id: 'proj-123e4567-e89b-42d3-a456-426614174000', name: '同名项目', status: 'active' },
      { id: 'proj-223e4567-e89b-42d3-a456-426614174001', name: '同名项目', status: 'planning' },
    ];

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/projects');

    const firstProjectButton = (await screen.findAllByText('同名项目'))[0].closest('button');
    expect(firstProjectButton).toBeTruthy();
    expect(screen.getAllByText('同名项目')).toHaveLength(2);
    expect(screen.queryByText('#123e4567')).not.toBeInTheDocument();
    expect(screen.queryByText('#223e4567')).not.toBeInTheDocument();
    expect(screen.queryByText('active')).not.toBeInTheDocument();
    expect(screen.queryByText('planning')).not.toBeInTheDocument();
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();

    vi.useFakeTimers();
    fireEvent.mouseEnter(firstProjectButton!);
    act(() => {
      vi.advanceTimersByTime(499);
    });
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();

    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(screen.getByRole('tooltip')).toHaveTextContent('active');
    expect(screen.getByRole('tooltip')).toHaveTextContent('同名项目');
    expect(screen.getByRole('tooltip')).toHaveTextContent('proj-123e4567-e89b-42d3-a456-426614174000');

    fireEvent.mouseLeave(firstProjectButton!);
    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();
  });

  it('shows delayed hover details for scheduled task instances', async () => {
    localStorage.setItem('xiaok:scheduled-tasks', JSON.stringify([
      {
        id: 'scheduled-task-1',
        name: '定时任务实例',
        frequency: '每天',
        threadId: 'thread-scheduled-1',
        runtimeTaskId: 'runtime-scheduled-1',
      },
    ]));

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/scheduled');

    const scheduledButton = (await screen.findByText('定时任务实例')).closest('button');
    expect(scheduledButton).toBeTruthy();
    expect(screen.queryByText('scheduled-task-1')).not.toBeInTheDocument();
    expect(screen.queryByText('thread-scheduled-1')).not.toBeInTheDocument();
    expect(screen.queryByText('runtime-scheduled-1')).not.toBeInTheDocument();

    vi.useFakeTimers();
    fireEvent.mouseEnter(scheduledButton!);
    act(() => {
      vi.advanceTimersByTime(500);
    });

    const tooltip = screen.getByRole('tooltip');
    expect(tooltip).toHaveTextContent('定时任务实例');
    expect(tooltip).toHaveTextContent('每天');
    expect(tooltip).toHaveTextContent('scheduled-task-1');
    expect(tooltip).toHaveTextContent('thread-scheduled-1');
    expect(tooltip).toHaveTextContent('runtime-scheduled-1');
  });

  it('shows delayed hover details for recent tasks', async () => {
    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/', [
      {
        id: 'thread-recent-1',
        title: '最近会话标题',
        status: 'running',
        mode: 'work',
        createdAt: 1,
        updatedAt: 2,
        starred: false,
        gtdBucket: null,
        pinnedAt: null,
        currentTaskId: 'task-current-1',
        taskIds: ['task-current-1', 'task-previous-1'],
      },
    ]);

    const recentButton = (await screen.findByText('最近会话标题')).closest('[role="button"]');
    expect(recentButton).toBeTruthy();
    expect(screen.queryByText('thread-recent-1')).not.toBeInTheDocument();
    expect(screen.queryByText('task-current-1')).not.toBeInTheDocument();

    vi.useFakeTimers();
    fireEvent.mouseEnter(recentButton!);
    act(() => {
      vi.advanceTimersByTime(500);
    });

    const tooltip = screen.getByRole('tooltip');
    expect(tooltip).toHaveTextContent('最近会话标题');
    expect(tooltip).toHaveTextContent('running');
    expect(tooltip).toHaveTextContent('thread-recent-1');
    expect(tooltip).toHaveTextContent('task-current-1');
    expect(tooltip).toHaveTextContent('task-previous-1');
  });

  it('cancels sidebar project details when hover leaves before the delay', async () => {
    mockKSwarmState.projects = [
      { id: 'proj-123e4567-e89b-42d3-a456-426614174000', name: '同名项目', status: 'active' },
    ];

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/projects');

    const projectButton = (await screen.findByText('同名项目')).closest('button');
    expect(projectButton).toBeTruthy();

    vi.useFakeTimers();
    fireEvent.mouseEnter(projectButton!);
    act(() => {
      vi.advanceTimersByTime(300);
    });
    fireEvent.mouseLeave(projectButton!);
    act(() => {
      vi.advanceTimersByTime(500);
    });

    expect(screen.queryByRole('tooltip')).not.toBeInTheDocument();
  });

  it('separates lists into ordered tabs without capped summaries', async () => {
    localStorage.setItem('xiaok:scheduled-tasks', JSON.stringify([
      { id: 'task-1', name: '主界面定时任务 1', frequency: '每天' },
      { id: 'task-2', name: '主界面定时任务 2', frequency: '每天' },
      { id: 'task-3', name: '主界面定时任务 3', frequency: '每天' },
      { id: 'task-4', name: '主界面定时任务 4', frequency: '每天' },
    ]));
    mockKSwarmState.projects = [
      { id: 'project-1', name: '主界面项目 1', status: 'active' },
      { id: 'project-2', name: '主界面项目 2', status: 'planning' },
      { id: 'project-3', name: '主界面项目 3', status: 'review' },
      { id: 'project-4', name: '主界面项目 4', status: 'delivered' },
    ];

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/');

    expect(screen.getAllByRole('tab').map(tab => tab.textContent)).toEqual(['任务', '定时', '项目', '协作']);
    expect(screen.queryByText('主界面定时任务 4')).toBeNull();
    expect(screen.queryByText('主界面项目 4')).toBeNull();
    fireEvent.click(screen.getByRole('tab', { name: '定时', exact: true } as Parameters<typeof screen.getByRole>[1]));
    const scheduledList = (await screen.findByText('主界面定时任务 4')).closest('button')?.parentElement;
    expect(scheduledList?.className).not.toContain('max-h-');
    expect(screen.queryByText('主界面项目 4')).toBeNull();
    fireEvent.click(screen.getByRole('tab', { name: '项目', exact: true } as Parameters<typeof screen.getByRole>[1]));
    expect(screen.getByTestId('sidebar-location')).toHaveTextContent('/');
    expect(await screen.findByText('主界面项目 4')).toBeVisible();
    expect(screen.queryByText('主界面定时任务 4')).toBeNull();
    fireEvent.keyDown(screen.getByRole('tab', { name: '项目', exact: true } as Parameters<typeof screen.getByRole>[1]), { key: 'Home' });
    expect(screen.getByRole('tab', { name: '任务', exact: true } as Parameters<typeof screen.getByRole>[1])).toHaveAttribute('aria-selected', 'true');
  });

  it('keeps every runtime thread for a scheduled task out of the recent list and shows the scheduled entry', async () => {
    const oldThread = {
      id: 'thread-old-dream',
      title: 'Dream',
      currentTaskId: 'task_old',
      taskIds: ['task_old'],
      createdAt: 1,
      updatedAt: 1,
    };
    const latestThread = {
      id: 'thread-latest-dream',
      title: 'Dream',
      currentTaskId: 'task_new',
      taskIds: ['task_new'],
      createdAt: 3,
      updatedAt: 3,
    };
    const normalThread = {
      id: 'thread-normal',
      title: '普通任务',
      currentTaskId: null,
      taskIds: [],
      createdAt: 2,
      updatedAt: 2,
    };
    localStorage.setItem('xiaok:scheduled-tasks', JSON.stringify([
      {
        id: 'scheduled-dream',
        name: 'Dream',
        frequency: 'daily',
        threadId: 'thread-old-dream',
        runtimeTaskId: 'task_old',
      },
    ]));
    mockApi.getThread.mockImplementation(async (id: string) => {
      if (id === oldThread.id) return oldThread;
      if (id === latestThread.id) return latestThread;
      if (id === normalThread.id) return normalThread;
      return null;
    });
    Object.defineProperty(window, 'xiaokDesktop', {
      value: {
        getScheduledTasks: vi.fn(async () => [
          {
            id: 'scheduled-dream',
            name: 'Dream',
            frequency: 'daily',
            status: 'active',
            createdAt: 1,
            updatedAt: 3,
            runtimeTaskId: 'task_new',
          },
        ]),
        getTimedActionRuns: vi.fn(async () => [
          { runtimeTaskId: 'task_new', startedAt: 300 },
          { runtimeTaskId: 'task_old', startedAt: 100 },
        ]),
      },
      configurable: true,
    });

    renderSidebar({
      checking: false,
      available: false,
      downloading: false,
      downloaded: false,
      progress: 0,
    }, '/', [latestThread, normalThread, oldThread]);

    expect(await screen.findByTestId('thread-item-thread-normal')).toBeInTheDocument();
    await waitFor(() => {
      expect(screen.queryByTestId('thread-item-thread-old-dream')).toBeNull();
      expect(screen.queryByTestId('thread-item-thread-latest-dream')).toBeNull();
    });
    fireEvent.click(screen.getByRole('tab', { name: '定时', exact: true } as Parameters<typeof screen.getByRole>[1]));
    expect(await screen.findByText('Dream')).toBeInTheDocument();
  });
});

it('lists collaboration rooms in their own tab and shows a retry for read failures', async () => {
  const listRooms = vi.fn().mockResolvedValueOnce({ ok: false }).mockResolvedValue({ ok: true, rooms: [{ roomId: 'room-a', title: 'Agentic Working 验证', status: 'active' }] });
  Object.defineProperty(window, 'xiaokDesktop', { configurable: true, value: { listCollaborationRooms: listRooms } });
  renderSidebar({ checking: false, available: false, downloading: false, downloaded: false, progress: 0 });
  fireEvent.click(screen.getByRole('tab', { name: '协作', exact: true } as Parameters<typeof screen.getByRole>[1]));
  expect(await screen.findByRole('alert')).toHaveTextContent('无法读取协作空间');
  fireEvent.click(screen.getByRole('button', { name: '重试', exact: true } as Parameters<typeof screen.getByRole>[1]));
  expect(await screen.findByRole('button', { name: 'Agentic Working 验证', exact: true } as Parameters<typeof screen.findByRole>[1])).toBeVisible();
  fireEvent.click(screen.getByRole('button', { name: 'Agentic Working 验证', exact: true } as Parameters<typeof screen.getByRole>[1]));
  expect(screen.getByTestId('sidebar-location')).toHaveTextContent('/collaboration/room-a');
  expect(screen.getByRole('tab', { name: '协作', exact: true } as Parameters<typeof screen.getByRole>[1])).toHaveAttribute('aria-selected', 'true');
});

it('keeps five primary destinations above instance tabs and navigates independently', async () => {
  renderSidebar({ checking: false, available: false, downloading: false, downloaded: false, progress: 0 });
  const nav = await screen.findByTestId('sidebar-main-navigation');
  expect(Array.from(nav.querySelectorAll('button')).map(button => button.textContent)).toEqual(['新建任务', '自动化', '项目', '协作空间', '知识库']);
  expect(nav.compareDocumentPosition(screen.getByRole('tablist')) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  for (const [label, path, tab] of [['自动化','/automations','定时'], ['项目','/projects','项目'], ['协作空间','/collaboration','协作'], ['知识库','/knowledge',null], ['新建任务','/','任务']] as const) {
    fireEvent.click(Array.from(nav.querySelectorAll('button')).find(button => button.textContent === label)!);
    expect(screen.getByTestId('sidebar-location')).toHaveTextContent(path);
    if (tab) expect(screen.getByRole('tab', { name: tab, exact: true } as Parameters<typeof screen.getByRole>[1])).toHaveAttribute('aria-selected', 'true');
  }
  fireEvent.click(screen.getByRole('tab', { name: '项目', exact: true } as Parameters<typeof screen.getByRole>[1]));
  expect(screen.getByTestId('sidebar-location').textContent).toBe('/');
  expect(nav.querySelectorAll('button')).toHaveLength(5);
});
