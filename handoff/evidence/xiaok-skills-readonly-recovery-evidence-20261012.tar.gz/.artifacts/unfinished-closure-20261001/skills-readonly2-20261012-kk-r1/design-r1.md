# Skills readonly2 续跑设计 R1

仅原 298 中 listSkills/getSkillStats 两条读入口。当前仅设计，+0。原安装/卸载的 Settings service、skill_install/skill_uninstall、builtin install_skill/uninstall_skill、write/bash 与 all-writer 权限工作完整保留，不把只读修复称为安装权限修复。此前 native/material/P4 中断不重命名重试；原全部父人口/时限/失败、最终主干条件保留。

## 当前源码事实

ipc.ts 的 listSkills raw handler 等待 service 后直接读 length 做日志，无零参/fullDTO；service 在 catalog.reload 后直接读 skill 字段投影。SkillsPane 初始列表和 skillsChanged 读取没有 singleflight/lifetime，失败吞掉，显示安装数0；stats 初始失败也吞掉。

getSkillStats 已在 Diagnostics3 round19 中，但 input 明确标 legacy-ignored-arguments、z.unknown，完整组件未接受。文件 reader 遇坏 JSON/非数组/权限失败都返回[]；service 聚合异常返回[]；typed registrar 同步 throw/Promise reject也改为[]。三层空成功无法区别“无记录”和“不可用”。service 的2000ms定时器在 await load、同步 aggregate 完成之后才创建，race 的 stats 已完成；它不是实际文件读取 deadline，正常请求仍遗留2秒timer。不能把它当原有效I/O限时或增时限/缩原父15s/300s/3600s、5s/30s验收。

既有 diagnostics business 用例明确保留历史不完整记录所产生的 NaN/Infinity 等 number，以及 multi-skill、cancelled、unknown 聚合行为。后继不重写 aggregate、不收紧 historicalNumber、不裁数组或新加记录字段要求。坏 JSON/非数组/导致原聚合 throw 的坏记录改为 unavailable，既有案例数据保留，仅失败断言按已审错误传播更新；能聚合出的历史非有限数值仍穿过完整 DTO。

## 契约与来源

listSkills 新独立 round31 registrar/producers，tuple[]，完整 DTO 数组{name,aliases:string[],description,source,tier}，字符串保空值、source/tier 保现有 string ABI，对象passthrough/数组全量。原 source builtin/global/project、tier system/user/project 不无故收窄。替换唯一 raw 注册，Main common Main+Recorder/frame/URL admission不变，不新建 raw owner。service 的完整 catalog facts 先 capture，再投影已有五字段；不将 content/path/其它私有资源字段写日志或 wire。Main 日志仅在输出 capture/validate 后读 count。

getSkillStats 保 Diagnostics3 的三条名称与原 output schema/round19/sourceFile，单独将该方法 input qualification 改为 qualified-zero-tuple、tuple[]，其它 diagnose/trace 的 legacy input/所有人口继续 unqualified。registrar 单独分支执行真实 service，失败传播 fixed diagnostics_projection_unavailable，capture+safeParse 在通用 runtime 前抛错，不制造生产 resolve error envelope。不能移除其它两个 family 成员以取得“整族通过”。

两个入口同步/标准 nativePromise 都用既有标准 Promise/intrinsic then 与 getter/proxy/serializer/循环数据 guard，每次 detach；raw producer throw、Promise reject、坏输出都拒绝而非[]。服务 reader 仅真实 ENOENT 代表无记录[]；其它错误、JSON解析错误、非数组拒绝。error code 用 own data descriptor，不读任意 message/code getter。JSON数组先完整 capture 后交原 aggregate，不新增字段/有限数值限制。

移除无效的 post-aggregation timeout/race 与 catch-empty，仅 await 真实读取/聚合并传播 unknown；这保持原实际执行顺序，消除失实空成功和遗留timer，不主张性能收益或新2秒deadline资格。原 Main ordinary shutdown5秒与真实读 token 等到settle保持；held读取超过5秒仍报告未drain、不伪释放，不改变原限时。

reader/aggregate 目前仅 getSkillStats 消费，appendExecRecord 的500截断和 catch/write 行为不在本组改造，不声称日志 writer 已安全或所有历史文件修复。正常没有文件/空数组仍[]成功，历史缺字段且可聚合的 NaN案例不变。

## 实际 UI 消费者

SkillsPane 的列表与 stats 是两种独立只读事实，各一个 lifetime/singleflight owner；列表 owner 复用于初始、skillsChanged、安装/卸载成功后的只读刷新，忙事件跳过或合并至多一个后继，显式手动刷新最多排1。stats 同样单飞，失败不清旧 map。不引入新poll/第二owner。

列表未取得事实用unknown/loading，不用[]伪装已安装0；失败保lastgood、当前t的局部只读重试。stats未取得/失败展示unknown/unavailable，不能默认为零使用。已有历史NaN等保原DTO，仅无法解释的显示值用本地化unknown，不伪造0或健康指标。

读生命周期随unmount/locale失效，迟到结果不得写新页面；事件取消订阅、queued read丢弃。仅刷新不能安装/卸载。已有用户安装/卸载路径仍直接按原 service 执行、成功仍刷新并保原 catalog version广播，不加确认/proposal-only、不在这张只读票改变 mutation ABI/source权威；其错误/unknown结果不得用新的只读刷新清掉。若需要处理同权限 mutation安全，保持在原未完成父组而不偷计本票。

API/TS/CJS 保零参数 ABI、类型关联共享schema；两个实际 census 保所有原断言。现有 Diagnostics3 source/output partial票保历史，只有 getStats 这张新完整源码票可 +1，不使其它两条变成完整 CODE。

## 验收矩阵

先独立 DESIGN→真实 registerDesktopIpc/service/readonly producer 与真实 SkillsPane RED→production。必须覆盖合法 Main/Recorder、unknown同URL/旧Main/subframe拒绝先于getter/文件/SDK；零参/extra/proxy/getter/toJSON/nativePromiseconstructor/species；完整metadata/十个stats字段、unknown extras/empty/NaN、多技能/cancelled/unknown、每invoke detach。

实际自有 catalog/skill-exec.json：missing/empty成功、坏 JSON/非数组/权限/aggregate throw失败，旧能聚合出的缺字段NaN仍原样；真实原 aggregator不重实现。真实service错误到typed与UI一贯unavailable，不有任一层空成功；无遗留timer；held读/原5秒shutdown与自身promise回收。

实际页面 initial/read failure、lastgood、event held/queue、manual单飞、locale/unmount、statsunknown/非有限显示、读不调用安装/卸载、成功安装/卸载后的原刷新/broadcast断言完整保。旧 diagnostics characterization/biz 案例不删，资格描述和错误传播变更需独审候选后更新失败断言；trace/diagnose历史正面/错误/敏感输出/未知input全保。

完整相关技能/diagnostics/CLI loader/catalog与原其余已接受关联回归、完整 Main/Renderer configs strict、gov/changed/newtestlint、两build、freshCODE；source Electron probe仅自有临时目录，不冒充真实全UI/正常安装/native/agent权限。完整CODE后才可 +2 到219/298，原父所有条件仍开放；全部原范围完成后按已授权合并最新主干测试。
