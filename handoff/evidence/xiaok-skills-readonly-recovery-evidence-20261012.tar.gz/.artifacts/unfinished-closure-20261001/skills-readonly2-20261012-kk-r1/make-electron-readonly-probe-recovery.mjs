import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
const r = process.cwd(), e = resolve(r, '.artifacts/unfinished-closure-20261001/skills-readonly2-20261012-kk-r1');
const ts = (await import(pathToFileURL(join(r, 'desktop/node_modules/typescript/lib/typescript.js')).href)).default;
const selected = {}, raw = {};
for (const file of ['main.ts', 'desktop-services.ts']) {
  const source = readFileSync(join(r, 'desktop/electron', file), 'utf8'), ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true);
  function visit(node) {
    const name = node.name?.getText(ast);
    if ((ts.isFunctionDeclaration(node) && ['authorizeDesktopInvoke', 'loadExecRecords', 'aggregateStats'].includes(name)) || (ts.isMethodDeclaration(node) && ['listSkills', 'getSkillStats'].includes(name))) {
      if (selected[name]) throw Error('ambiguous_actual_source_' + name); selected[name] = node.getText(ast);
    }
    if (ts.isVariableStatement(node)) for (const d of node.declarationList.declarations) if (d.name.getText(ast) === 'EXEC_FILE') selected.EXEC_FILE = node.getText(ast);
    ts.forEachChild(node, visit);
  } visit(ast); raw[file] = source;
}
for (const name of ['authorizeDesktopInvoke', 'loadExecRecords', 'aggregateStats', 'listSkills', 'getSkillStats', 'EXEC_FILE']) if (!selected[name]) throw Error('missing_actual_source_' + name);
const js = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
const root = realpathSync(mkdtempSync(join(tmpdir(), 'xiaok-skills-readonly-ipc-'))), dir = join(root, 'desktop/dist/main/desktop/electron'), renderer = join(root, 'desktop/dist/renderer/index.html');
mkdirSync(dir, { recursive: true }); mkdirSync(join(root, 'desktop/dist/renderer'), { recursive: true }); mkdirSync(join(root, 'data')); mkdirSync(join(root, '.xiaok/skills/owned-probe-skill'), { recursive: true });
writeFileSync(join(root, '.xiaok/skills/owned-probe-skill/SKILL.md'), '---\nname: owned-probe-skill\ndescription: Owned probe\n---\nOwned instruction body.\n');
writeFileSync(renderer, '<!doctype html><meta charset="utf-8"><title>Owned skills readonly IPC probe</title>');
const module = path => JSON.stringify(pathToFileURL(join(r, 'desktop/dist/main', path)).href), preload = JSON.stringify(join(r, 'desktop/electron/preload.cjs'));
const script = join(dir, 'skills-readonly-ipc.mjs');
const text = `import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {readFile as readFileAsync,writeFile} from 'node:fs/promises';import {join,dirname} from 'node:path';import {fileURLToPath} from 'node:url';import {types as skillNodeTypes} from 'node:util';
import {ShutdownAwareIpcMain,DesktopShutdownGate} from ${module('desktop/electron/shutdown-aware-ipc-main.js')};
import {isTrustedDesktopRendererUrl,buildBrowserWindowOptions} from ${module('desktop/electron/security.js')};
import {createMeetingRecorderWindowController} from ${module('desktop/electron/meeting-recorder-window.js')};
import {registerSkillListIpc} from ${module('desktop/electron/skill-list-typed-ipc.js')};
import {registerDiagnosticsIpc} from ${module('desktop/electron/diagnostics-typed-ipc.js')};
import {captureSkillReadonlyPromise,captureSkillListServiceResult} from ${module('desktop/electron/skill-readonly-data.js')};
import {captureIpcData} from ${module('desktop/electron/ipc-data-snapshot.js')};
import {createSkillCatalog} from ${module('src/ai/skills/loader.js')};
const root=${JSON.stringify(root)},rendererFile=${JSON.stringify(renderer)},__dirname=dirname(fileURLToPath(import.meta.url));
app.setPath('userData',join(root,'electron-user-data'));const options={dataRoot:join(root,'data')};
let mainWindow=null,meetingRecorderController=null;
${js(selected.authorizeDesktopInvoke + '\n' + selected.EXEC_FILE + '\n' + selected.loadExecRecords + '\n' + selected.aggregateStats + '\nconst services={' + selected.listSkills + ',' + selected.getSkillStats + '};')}
const gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];
const verify=(v,code)=>{if(!v)throw Error(code);};let counts=0;
registerSkillListIpc(ipc,new Map([['desktop:listSkills',()=>captureSkillListServiceResult(services.listSkills(),()=>{counts++;})]]));registerDiagnosticsIpc(ipc,services);
const invoke=async(role,window)=>{for(const method of ['listSkills','getSkillStats'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await writeFile(join(root,'data/skill-exec.json'),JSON.stringify([{id:'owned',skillNames:['owned-probe-skill'],startTime:1,endTime:2,durationMs:3,status:'success',inputTokens:4,outputTokens:5}]));
const windowOptions=buildBrowserWindowOptions(${preload},{platform:process.platform});mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:${preload},rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-skills-readonly'});const recorder=BrowserWindow.getAllWindows().find(w=>meetingRecorderController.ownsWebContents(w.webContents));verify(!!recorder,'recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...windowOptions,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);const old=mainWindow;mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_read_failed');if(row.method==='listSkills')verify(row.reply.value.some(s=>s.name==='owned-probe-skill'),'owned_catalog_missing');else verify(row.reply.value[0].totalCalls===1&&Object.keys(row.reply.value[0]).length===10,'complete_stats_changed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted');}
await writeFile(join(root,'data/skill-exec.json'),'{');const failed=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.getSkillStats().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');verify(!failed.ok,'bad_file_false_empty');results.push({role:'bad-json',method:'getSkillStats',reply:failed});verify(gate.outstanding===0,'ipc_token_leak');verify(counts===3,'unowned_catalog_read');
await writeFile(${JSON.stringify(join(e,'electron-readonly-probe-recovery-r1.json'))},JSON.stringify({actualElectron:true,actualMainAuthorizer:true,actualExtractedServiceMethods:true,actualSourceReaderAggregator:true,actualCatalogLoader:true,actualTypedRegistrars:true,actualRecorderController:true,actualPreloadCjs:true,ownedTemporaryRootOnly:true,normalInstalledOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,results,counts,gateOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1);});`;
writeFileSync(script,text);writeFileSync(join(e,'electron-readonly-probe-script-recovery-r1.mjs'),text);writeFileSync(join(e,'electron-readonly-probe-script-recovery-r1.json'),JSON.stringify({root,script,renderer,selected,limits:'component IPC source extraction; not full createDesktopServices startup/installed/native authority/whole UI'},null,2));
console.log(JSON.stringify({root,script}));
