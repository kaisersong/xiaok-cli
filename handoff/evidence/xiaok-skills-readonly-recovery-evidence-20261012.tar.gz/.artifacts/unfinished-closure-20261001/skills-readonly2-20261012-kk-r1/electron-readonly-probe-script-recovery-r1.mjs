import {app,BrowserWindow,ipcMain,screen} from 'electron';
import {readFile as readFileAsync,writeFile} from 'node:fs/promises';import {join,dirname} from 'node:path';import {fileURLToPath} from 'node:url';import {types as skillNodeTypes} from 'node:util';
import {ShutdownAwareIpcMain,DesktopShutdownGate} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import {isTrustedDesktopRendererUrl,buildBrowserWindowOptions} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import {createMeetingRecorderWindowController} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import {registerSkillListIpc} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/skill-list-typed-ipc.js";
import {registerDiagnosticsIpc} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/diagnostics-typed-ipc.js";
import {captureSkillReadonlyPromise,captureSkillListServiceResult} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/skill-readonly-data.js";
import {captureIpcData} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/ipc-data-snapshot.js";
import {createSkillCatalog} from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/src/ai/skills/loader.js";
const root="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-skills-readonly-ipc-8xY8Eb",rendererFile="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-skills-readonly-ipc-8xY8Eb/desktop/dist/renderer/index.html",__dirname=dirname(fileURLToPath(import.meta.url));
app.setPath('userData',join(root,'electron-user-data'));const options={dataRoot:join(root,'data')};
let mainWindow=null,meetingRecorderController=null;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}
const EXEC_FILE = 'skill-exec.json';
async function loadExecRecords(dataRoot) {
    let raw;
    try {
        raw = await captureSkillReadonlyPromise(readFileAsync(join(dataRoot, EXEC_FILE), 'utf-8'), 'diagnostics_projection_unavailable');
    }
    catch (error) {
        if (error && typeof error === 'object' && !skillNodeTypes.isProxy(error) && Object.getOwnPropertyDescriptor(error, 'code')?.value === 'ENOENT')
            return [];
        throw error;
    }
    if (typeof raw !== 'string')
        throw Error('diagnostics_projection_unavailable');
    const parsed = captureIpcData(JSON.parse(raw), 'diagnostics_projection_unavailable', { preserveDataPrototype: true });
    if (!Array.isArray(parsed))
        throw Error('diagnostics_projection_unavailable');
    return parsed;
}
function aggregateStats(records) {
    const bySkill = new Map();
    for (const r of records) {
        const names = r.skillNames.length > 0 ? r.skillNames : ['unknown'];
        for (const name of names) {
            const entry = bySkill.get(name) ?? { durations: [], successes: 0, errors: 0, calls: 0, inputTokens: 0, outputTokens: 0, firstAt: r.startTime, lastAt: r.endTime };
            entry.calls++;
            if (r.status === 'success')
                entry.successes++;
            if (r.status === 'error')
                entry.errors++;
            entry.durations.push(r.durationMs);
            entry.inputTokens += r.inputTokens;
            entry.outputTokens += r.outputTokens;
            if (r.startTime < entry.firstAt)
                entry.firstAt = r.startTime;
            if (r.endTime > entry.lastAt)
                entry.lastAt = r.endTime;
            bySkill.set(name, entry);
        }
    }
    return Array.from(bySkill.entries()).map(([skillName, e]) => {
        const sorted = [...e.durations].sort((a, b) => a - b);
        const p95Idx = Math.min(Math.floor(sorted.length * 0.95), sorted.length - 1);
        return {
            skillName,
            totalCalls: e.calls,
            successCount: e.successes,
            errorCount: e.errors,
            avgDurationMs: e.calls > 0 ? Math.round(e.durations.reduce((a, b) => a + b, 0) / e.calls) : 0,
            p95DurationMs: sorted[p95Idx] ?? 0,
            totalInputTokens: e.inputTokens,
            totalOutputTokens: e.outputTokens,
            lastCalledAt: e.lastAt,
            firstCalledAt: e.firstAt,
        };
    });
}
const services = { async listSkills() {
        let incomplete = false;
        const catalog = createSkillCatalog(undefined, process.cwd(), { onDiscoveryIssue: () => { incomplete = true; } });
        const skills = await captureSkillReadonlyPromise(catalog.reload(), 'skill_list_projection_unavailable');
        if (incomplete || !Array.isArray(skills))
            throw Error('skill_list_projection_unavailable');
        return skills.map(s => ({
            name: s.name,
            aliases: s.aliases ?? [],
            description: s.description,
            source: s.source,
            tier: s.tier,
        }));
    }, async getSkillStats() {
        const records = await loadExecRecords(options.dataRoot);
        return aggregateStats(records);
    } };

const gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];
const verify=(v,code)=>{if(!v)throw Error(code);};let counts=0;
registerSkillListIpc(ipc,new Map([['desktop:listSkills',()=>captureSkillListServiceResult(services.listSkills(),()=>{counts++;})]]));registerDiagnosticsIpc(ipc,services);
const invoke=async(role,window)=>{for(const method of ['listSkills','getSkillStats'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await writeFile(join(root,'data/skill-exec.json'),JSON.stringify([{id:'owned',skillNames:['owned-probe-skill'],startTime:1,endTime:2,durationMs:3,status:'success',inputTokens:4,outputTokens:5}]));
const windowOptions=buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",{platform:process.platform});mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:"/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-skills-readonly'});const recorder=BrowserWindow.getAllWindows().find(w=>meetingRecorderController.ownsWebContents(w.webContents));verify(!!recorder,'recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...windowOptions,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);const old=mainWindow;mainWindow=new BrowserWindow({...windowOptions,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_read_failed');if(row.method==='listSkills')verify(row.reply.value.some(s=>s.name==='owned-probe-skill'),'owned_catalog_missing');else verify(row.reply.value[0].totalCalls===1&&Object.keys(row.reply.value[0]).length===10,'complete_stats_changed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted');}
await writeFile(join(root,'data/skill-exec.json'),'{');const failed=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.getSkillStats().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');verify(!failed.ok,'bad_file_false_empty');results.push({role:'bad-json',method:'getSkillStats',reply:failed});verify(gate.outstanding===0,'ipc_token_leak');verify(counts===3,'unowned_catalog_read');
await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/skills-readonly2-20261012-kk-r1/electron-readonly-probe-recovery-r1.json",JSON.stringify({actualElectron:true,actualMainAuthorizer:true,actualExtractedServiceMethods:true,actualSourceReaderAggregator:true,actualCatalogLoader:true,actualTypedRegistrars:true,actualRecorderController:true,actualPreloadCjs:true,ownedTemporaryRootOnly:true,normalInstalledOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,results,counts,gateOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1);});