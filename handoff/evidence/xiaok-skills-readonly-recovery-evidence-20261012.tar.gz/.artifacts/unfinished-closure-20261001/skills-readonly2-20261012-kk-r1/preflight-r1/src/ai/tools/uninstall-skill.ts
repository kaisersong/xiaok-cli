import { existsSync, readdirSync, readFileSync, rmSync } from 'fs';
import { join } from 'path';
import type { Tool } from '../../types.js';
import type { CapabilityRegistry } from '../../platform/runtime/capability-registry.js';
import { getConfigDir } from '../../utils/config.js';

export interface UninstallSkillToolOptions {
  cwd?: string;
  configDir?: string;
  capabilityRegistry?: CapabilityRegistry;
  onUninstall?: (info: { name: string; path: string; scope: 'project' | 'global' }) => Promise<void> | void;
}

interface SkillCandidate {
  name: string;
  path: string;
  removePath: string;
  scope: 'project' | 'global';
}

function parseSkillName(raw: string): string | null {
  const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (!match) return null;

  for (const line of match[1].split('\n')) {
    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;
    const key = line.slice(0, colonIdx).trim();
    const value = line.slice(colonIdx + 1).trim();
    if (key === 'name' && value) {
      return value;
    }
  }

  return null;
}

function findSkillCandidates(dir: string, scope: 'project' | 'global'): SkillCandidate[] {
  if (!existsSync(dir)) {
    return [];
  }

  return readdirSync(dir)
    .flatMap((entry) => {
      const entryPath = join(dir, entry);
      if (entry.endsWith('.md')) {
        const name = parseSkillName(readFileSync(entryPath, 'utf8'));
        if (!name) {
          return [];
        }
        return [{
          name,
          path: entryPath,
          removePath: entryPath,
          scope,
        }];
      }

      const skillPath = join(entryPath, 'SKILL.md');
      if (!existsSync(skillPath)) {
        return [];
      }

      const name = parseSkillName(readFileSync(skillPath, 'utf8'));
      if (!name) {
        return [];
      }

      return [{
        name,
        path: skillPath,
        removePath: entryPath,
        scope,
      }];
    })
    .filter((entry): entry is SkillCandidate => Boolean(entry));
}

export function createUninstallSkillTool(options: UninstallSkillToolOptions = {}): Tool {
  const cwd = options.cwd ?? process.cwd();
  const configDir = options.configDir ?? getConfigDir();

  return {
    permission: 'write',
    definition: {
      name: 'uninstall_skill',
      description: '按名称从 project/global scope 卸载已安装的 skill',
      inputSchema: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            description: '要卸载的 skill 名称（按 frontmatter 的 name 匹配）',
          },
          scope: {
            type: 'string',
            enum: ['project', 'global'],
            description: '卸载范围。省略时按 project -> global 顺序查找',
          },
        },
        required: ['name'],
      },
    },
    async execute(input) {
      const { name, scope } = input as { name: string; scope?: 'project' | 'global' };
      const normalizedName = name.trim();
      if (!normalizedName) {
        return 'Error: 缺少 skill 名称';
      }

      const projectDir = join(cwd, '.xiaok', 'skills');
      const globalDir = join(configDir, 'skills');
      const searchOrder: Array<'project' | 'global'> = scope
        ? [scope]
        : ['project', 'global'];

      const matches = searchOrder
        .flatMap((targetScope) => findSkillCandidates(targetScope === 'project' ? projectDir : globalDir, targetScope))
        .filter((candidate) => candidate.name === normalizedName);

      const match = matches[0];
      if (!match) {
        return `Error: 未找到 skill "${normalizedName}"`;
      }

      rmSync(match.removePath, { force: true, recursive: true });
      await options.onUninstall?.({
        name: match.name,
        path: match.path,
        scope: match.scope,
      });
      options.capabilityRegistry?.unregister(match.name);

      return [
        `已卸载 skill "${match.name}"`,
        `范围: ${match.scope}`,
        `路径: ${match.path}`,
      ].join('\n');
    },
  };
}

export const uninstallSkillTool = createUninstallSkillTool();
