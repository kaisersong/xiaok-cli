# 类型声明恢复补丁（技能只读2前置）
仅修复上一轮 full original configs strict 的剩余声明错误，不新增功能、不更新 baseline、不宣称 mutation/API 已实现。
bridge.ts 候选将已有无条件 throw 的 GitHub/upload stub 签名对齐唯一 SkillsSettingsContent 真实消费者的原参数/结果；stub body 与错误保持。MarketSkill 增加实际 consumer 已读取的可选 metadata，SkillImportCandidate 的已有 path，ApiErrorLike 的可选 code/details。ViewSkill.platform_status 接收现有 InstalledSkill/PlatformSkillItem 的 string ABI，label/style 已有 exact equality fallback，不改变 runtime。
InstalledSkillsView 外部目录 key 从不存在的 skill.path 修为已有 instruction_path；该字段是发现服务的技能身份/文件路径。先补真实外部目录 UI 控制测试再改。不造 path DTO、不更改 RPC ABI。另以既有 fileBasename 取名，保持路径可跨 Windows。
Main getSkillStats tuple overload 与测试 each as const 已由旧session修复，先重跑 strict 后再按实际新错误调整。不减任何真实测试断言。
请独审声明候选与现有生产消费者、文件身份对应。明确 APPROVE_TYPING_ONLY 或 BLOCK。此票不接受技能只读2组件或父范围。
