import { useState, useRef, useEffect, useCallback, type KeyboardEvent } from 'react';
import { Send, Square, X, Plus } from 'lucide-react';
import { api } from '../api';
import { useLocale } from '../contexts/LocaleContext';
import { ChatModelPicker } from './ChatModelPicker';
import { toFileUrl, fileBasename as basename, normalizeClipboardFilePath, filePathIdentity, isAbsoluteFilePath } from '../lib/file-path';

export interface AttachedFile {
  filePath: string;
  name: string;
  isImage?: boolean;
}

export interface MentionItem {
  id: string;
  label: string;
}

interface SkillItem {
  name: string;
  aliases: string[];
  description: string;
  source: string;
  tier: string;
}

interface ChatInputProps {
  value?: string;
  onChange?: (value: string) => void;
  onSubmit: (text: string, files: AttachedFile[]) => void | boolean | Promise<void | boolean>;
  onQueue?: (text: string, files: AttachedFile[]) => void;
  queuedText?: string | null;
  onCancelQueue?: () => void;
  placeholder?: string;
  disabled?: boolean;
  isRunning?: boolean;
  onStop?: () => void;
  autoFocus?: boolean;
  initialFiles?: AttachedFile[];
  mentionItems?: MentionItem[];
  mentionAllLabel?: string;
}

const TEXTAREA_MAX_HEIGHT = 220;

function appendUniqueFiles(prev: AttachedFile[], next: AttachedFile[]): AttachedFile[] {
  const seen = new Set(prev.map(f => filePathIdentity(f.filePath)));
  const added = next.filter(f => {
    if (seen.has(filePathIdentity(f.filePath))) return false;
    seen.add(filePathIdentity(f.filePath));
    return true;
  });
  return added.length > 0 ? [...prev, ...added] : prev;
}

interface MentionTrigger {
  start: number;
  end: number;
  query: string;
}

function resolveMentionTrigger(value: string, caret: number, enabled: boolean): MentionTrigger | null {
  if (!enabled) return null;
  const prefix = value.slice(0, caret);
  const match = prefix.match(/(?:^|\s)@([^\s@]*)$/u);
  if (!match) return null;
  const tokenLength = match[1].length + 1;
  return { start: caret - tokenLength, end: caret, query: match[1].toLowerCase() };
}

export function ChatInput({ value, onChange, onSubmit, onQueue, queuedText, onCancelQueue, placeholder, disabled, isRunning, onStop, autoFocus, initialFiles, mentionItems = [], mentionAllLabel }: ChatInputProps) {
  const { t } = useLocale();
  const resolvedPlaceholder = placeholder ?? t.chatInput.replyPlaceholder;
  const [internalValue, setInternalValue] = useState(value ?? '');
  const [files, setFiles] = useState<AttachedFile[]>(initialFiles ?? []);
  const [focused, setFocused] = useState(false);
  const [skills, setSkills] = useState<SkillItem[]>([]);
  const [showSlashMenu, setShowSlashMenu] = useState(false);
  const [mentionTrigger, setMentionTrigger] = useState<MentionTrigger | null>(null);
  const [slashQuery, setSlashQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const slashMenuRef = useRef<HTMLDivElement>(null);
  const pastePathsRef = useRef<string[] | null>(null);
  const pasteHandlerRef = useRef<((e: ClipboardEvent) => void) | null>(null);
  const compositionStartHandlerRef = useRef<(() => void) | null>(null);
  const compositionEndHandlerRef = useRef<(() => void) | null>(null);
  const isComposingRef = useRef(false);
  // Set to true when keydown Cmd+V starts a readClipboardFilePaths fetch,
  // so the paste event handler skips its own hasFileItems branch.
  const finderFilesPendingRef = useRef(false);

  const textareaCallbackRef = useCallback((el: HTMLTextAreaElement | null) => {
    const previousEl = textareaRef.current;
    if (previousEl) {
      if (pasteHandlerRef.current) previousEl.removeEventListener('paste', pasteHandlerRef.current);
      if (compositionStartHandlerRef.current) previousEl.removeEventListener('compositionstart', compositionStartHandlerRef.current);
      if (compositionEndHandlerRef.current) previousEl.removeEventListener('compositionend', compositionEndHandlerRef.current);
    }
    (textareaRef as React.MutableRefObject<HTMLTextAreaElement | null>).current = el;
    if (!el) {
      pasteHandlerRef.current = null;
      compositionStartHandlerRef.current = null;
      compositionEndHandlerRef.current = null;
      isComposingRef.current = false;
      return;
    }

    const compositionStartHandler = () => {
      isComposingRef.current = true;
    };
    const compositionEndHandler = () => {
      isComposingRef.current = false;
    };
    const handler = (e: ClipboardEvent) => {
      if (isComposingRef.current) return;

      const clipItems = Array.from(e.clipboardData?.items ?? []);

      // File path paste takes priority over image paste.
      // Copying a file in Finder puts both the file path (text/plain) and an
      // image preview (image/tiff) on the clipboard; we must check paths first
      // so we don't mistake a copied image file for a screenshot paste.
      const plainText = e.clipboardData?.getData('text/plain') ?? '';
      const lines = plainText.split(/\r?\n/).flatMap(l => { const t = l.trim(); return t ? [t] : []; });
      const pathLines = lines.filter(l => isAbsoluteFilePath(normalizeClipboardFilePath(l)));
      const allLinesArePaths = pathLines.length > 0 && pathLines.length === lines.length;
      const hasFileItems = clipItems.some(item => item.kind === 'file');
      const hasImage = clipItems.some(item => item.type.startsWith('image/'));

      // A Cmd+V keydown preflight owns this paste. Consume the flag here — not
      // when the preflight IPC resolves — so an early-resolving preflight still
      // blocks this paste from inserting Finder display names (basenames) or
      // fetching a duplicate batch of attachment chips.
      if (finderFilesPendingRef.current) {
        finderFilesPendingRef.current = false;
        if (hasFileItems || hasImage || allLinesArePaths || (!plainText && clipItems.length === 0)) {
          e.preventDefault();
          return;
        }
        // Plain text paste: fall through to default handling.
      }

      if (allLinesArePaths) {
        pastePathsRef.current = pathLines;
        return;
      }

      // Finder NSFilenamesPboardType / file-item paste without a keydown preflight,
      // such as context-menu paste events.
      if (hasFileItems && window.xiaokDesktop?.readClipboardFilePaths) {
        e.preventDefault();
        window.xiaokDesktop.readClipboardFilePaths().then(fp => {
          if (fp.length > 0) {
            const newFiles = fp.map(p => {
              const name = basename(p);
              const isImage = /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(name);
              return { filePath: p, name, isImage };
            });
            setFiles(prev => appendUniqueFiles(prev, newFiles));
            return;
          }
          if (hasImage && window.xiaokDesktop?.readClipboardImage) {
            void window.xiaokDesktop.readClipboardImage().then(imagePath => {
              if (imagePath) {
                const name = basename(imagePath) || 'clipboard-image.png';
                setFiles(prev => appendUniqueFiles(prev, [{ filePath: imagePath, name, isImage: true }]));
              }
            }).catch(() => {});
          }
        }).catch(() => {});
        return;
      }

      // Image paste (screenshot / raw image data, no file path).
      if (hasImage && window.xiaokDesktop?.readClipboardImage) {
        e.preventDefault();
        window.xiaokDesktop.readClipboardImage().then(imagePath => {
          if (imagePath) {
            const name = basename(imagePath) || 'clipboard-image.png';
            setFiles(prev => appendUniqueFiles(prev, [{ filePath: imagePath, name, isImage: true }]));
          }
        }).catch(() => {});
        return;
      }

    };
    pasteHandlerRef.current = handler;
    compositionStartHandlerRef.current = compositionStartHandler;
    compositionEndHandlerRef.current = compositionEndHandler;
    el.addEventListener('compositionstart', compositionStartHandler);
    el.addEventListener('compositionend', compositionEndHandler);
    el.addEventListener('paste', handler);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    api.listSkills().then(list => setSkills(list)).catch(() => {});
    const unsubscribe = api.onSkillsChanged?.(() => {
      api.listSkills().then(list => setSkills(list)).catch(() => {});
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (autoFocus && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [autoFocus]);

  useEffect(() => {
    if (value !== undefined) setInternalValue(value);
  }, [value]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, TEXTAREA_MAX_HEIGHT)}px`;
    }
  }, [internalValue]);

  // Show slash menu when input starts with /. Mention selection takes priority.
  useEffect(() => {
    if (!mentionTrigger && internalValue.startsWith('/')) {
      const query = internalValue.slice(1).toLowerCase();
      setSlashQuery(query);
      setShowSlashMenu(true);
      setSelectedIndex(0);
    } else {
      setShowSlashMenu(false);
    }
  }, [internalValue, mentionTrigger]);

  const matchedSkills = skills.filter(s =>
    s.name.toLowerCase().includes(slashQuery) ||
    s.aliases.some(a => a.toLowerCase().includes(slashQuery))
  );

  const matchedMentions = mentionTrigger
    ? [
        { id: 'all', label: mentionAllLabel ?? 'all' },
        ...mentionItems,
      ].filter(item => (
        item.id.toLowerCase().includes(mentionTrigger.query)
        || item.label.toLowerCase().includes(mentionTrigger.query)
      ))
    : [];

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const v = e.target.value;
    // If paste detected file paths, strip them from the textarea and add as chips
    if (pastePathsRef.current) {
      const rawPaths = pastePathsRef.current;
      const paths = rawPaths.map(normalizeClipboardFilePath);
      pastePathsRef.current = null;
      // Strip the pasted path text from the new value
      let stripped = v;
      for (const p of rawPaths) stripped = stripped.replace(p, '');
      stripped = stripped.replace(/\n+/g, '\n').trimEnd();
      const newFiles = paths.map(p => {
        const name = basename(p);
        const isImage = /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(name);
        return { filePath: p, name, isImage };
      });
      setFiles(prev => appendUniqueFiles(prev, newFiles));
      setInternalValue(stripped);
      onChange?.(stripped);
      setMentionTrigger(resolveMentionTrigger(stripped, stripped.length, mentionItems.length > 0));
      // Try NSFilenamesPboardType to get canonical paths
      if (window.xiaokDesktop?.readClipboardFilePaths) {
        window.xiaokDesktop.readClipboardFilePaths().then(fp => {
          if (fp.length > 0) {
            setFiles(prev => {
              const pastedPathSet = new Set(paths);
              const base = prev.filter(f => !pastedPathSet.has(f.filePath));
              return appendUniqueFiles(base, fp.map(p => {
                const name = basename(p);
                const isImage = /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(name);
                return { filePath: p, name, isImage };
              }));
            });
          }
        }).catch(() => {});
      }
      return;
    }
    setInternalValue(v);
    onChange?.(v);
    const trigger = resolveMentionTrigger(v, e.target.selectionStart ?? v.length, mentionItems.length > 0);
    setMentionTrigger(trigger);
    if (trigger) {
      setShowSlashMenu(false);
      setSelectedIndex(0);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    // Intercept Cmd+V to catch Finder file copies where clipboard has no text/plain path.
    // readClipboardFilePaths reads NSFilenamesPboardType which Finder always populates.
    if (e.key.toLowerCase() === 'v' && (e.metaKey || e.ctrlKey) && !e.shiftKey && !e.altKey && !e.repeat && !isComposingRef.current && !finderFilesPendingRef.current && window.xiaokDesktop?.readClipboardFilePaths) {
      const valueBeforePaste = internalValue;
      finderFilesPendingRef.current = true;
      // The flag is consumed by the matching paste event. If that event never
      // arrives, clear it so a later unrelated paste is not swallowed.
      setTimeout(() => { finderFilesPendingRef.current = false; }, 1500);
      window.xiaokDesktop.readClipboardFilePaths().then(fp => {
        if (fp.length > 0) {
          // Finder file copy: add chips and restore textarea value
          const newFiles = fp.map(p => {
            const name = basename(p);
            const isImage = /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(name);
            return { filePath: p, name, isImage };
          });
          setFiles(prev => appendUniqueFiles(prev, newFiles));
          setInternalValue(valueBeforePaste);
          onChange?.(valueBeforePaste);
        } else if (window.xiaokDesktop?.readClipboardImage) {
          // No file paths — could be a screenshot. The paste handler has
          // already prevented the browser's default image paste while the
          // Finder-file preflight was pending, so attach the image here.
          window.xiaokDesktop.readClipboardImage().then(imagePath => {
            if (imagePath) {
              const name = basename(imagePath) || 'clipboard-image.png';
              setFiles(prev => appendUniqueFiles(prev, [{ filePath: imagePath, name, isImage: true }]));
            }
          }).catch(() => {});
        }
      }).catch(() => { finderFilesPendingRef.current = false; });
    }
    if (mentionTrigger && matchedMentions.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(i => Math.min(i + 1, matchedMentions.length - 1));
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(i => Math.max(i - 1, 0));
        return;
      }
      if (e.key === 'Tab' || e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        selectMention(matchedMentions[selectedIndex]);
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setMentionTrigger(null);
        return;
      }
    }
    if (showSlashMenu && matchedSkills.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(i => Math.min(i + 1, matchedSkills.length - 1));
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(i => Math.max(i - 1, 0));
        return;
      }
      if (e.key === 'Tab' || e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        selectSkill(matchedSkills[selectedIndex]);
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setShowSlashMenu(false);
        return;
      }
    }
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      if (isRunning && onQueue && (internalValue.trim() || files.length > 0)) {
        onQueue(internalValue.trim() || t.chatInput.processFiles, files);
        setInternalValue('');
        onChange?.('');
        setFiles([]);
        return;
      }
      // Allow submit with text OR files
      if (internalValue.trim() || files.length > 0) {
        void submit();
      }
    }
  };

  const selectSkill = (skill: SkillItem) => {
    const newValue = `/${skill.name} `;
    setInternalValue(newValue);
    onChange?.(newValue);
    setShowSlashMenu(false);
    textareaRef.current?.focus();
  };

  const selectMention = (mention: MentionItem) => {
    if (!mentionTrigger) return;
    const newValue = `${internalValue.slice(0, mentionTrigger.start)}@${mention.id === 'all' ? 'all' : mention.label} ${internalValue.slice(mentionTrigger.end)}`;
    setInternalValue(newValue);
    onChange?.(newValue);
    setMentionTrigger(null);
    setSelectedIndex(0);
    queueMicrotask(() => textareaRef.current?.focus());
  };

  const submit = async () => {
    const hasText = internalValue.trim();
    const hasFiles = files.length > 0;
    if ((hasText || hasFiles) && !submitting) {
      try {
        const outcome = onSubmit(internalValue.trim() || t.chatInput.processFiles, files);
        if (outcome && typeof (outcome as Promise<void | boolean>).then === 'function') {
          setSubmitting(true);
          if (await outcome === false) return;
        } else if (outcome === false) {
          return;
        }
      } catch {
        return;
      } finally {
        setSubmitting(false);
      }
      setInternalValue('');
      onChange?.('');
      setFiles([]);
      setMentionTrigger(null);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleAttach = async () => {
    try {
      const result = await api.selectMaterials();
      if (result.filePaths.length > 0) {
        const newFiles = result.filePaths.map(path => {
          const name = basename(path);
          const isImage = /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(name);
          return { filePath: path, name, isImage };
        });
        setFiles(prev => [...prev, ...newFiles]);
      }
    } catch (e) {
      console.error('[ChatInput] selectMaterials error:', e);
    }
  };

  return (
    <div className="w-full relative">
      {mentionTrigger && matchedMentions.length > 0 && (
        <div className="absolute bottom-full left-0 right-0 z-50 mb-2 overflow-hidden rounded-lg border border-[var(--c-border)] bg-[var(--c-bg-card)] shadow-lg">
          <div className="border-b border-[var(--c-border)] p-2 text-xs text-[var(--c-text-secondary)]">
            {t.chatInput.mentionHint}
          </div>
          <div className="max-h-[220px] overflow-y-auto">
            {matchedMentions.map((mention, index) => (
              <button
                key={mention.id}
                type="button"
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => selectMention(mention)}
                className={`flex w-full items-center gap-2 px-3 py-2 text-left text-sm ${index === selectedIndex ? 'bg-[var(--c-accent)]/10' : 'hover:bg-[var(--c-bg-deep)]'}`}
              >
                <span className="truncate text-[var(--c-accent)]">@{mention.id === 'all' ? 'all' : mention.label}</span>
                {mention.id === 'all' ? <span className="truncate text-[var(--c-text-secondary)]">{mention.label}</span> : null}
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Slash command menu */}
      {showSlashMenu && matchedSkills.length > 0 && (
        <div
          ref={slashMenuRef}
          className="absolute bottom-full left-0 right-0 mb-2 rounded-lg border border-[var(--c-border)] bg-[var(--c-bg-card)] shadow-lg overflow-hidden z-50"
          style={{ maxWidth: '100%' }}
        >
          <div className="p-2 text-xs text-[var(--c-text-secondary)] border-b border-[var(--c-border)]">
            {t.chatInput.skillCommandHint}
          </div>
          <div className="max-h-[200px] overflow-y-auto">
            {matchedSkills.map((skill, i) => (
              <button
                key={skill.name}
                type="button"
                onClick={() => selectSkill(skill)}
                className={`w-full px-3 py-2 text-left text-sm flex items-center gap-2 ${
                  i === selectedIndex ? 'bg-[var(--c-accent)]/10' : 'hover:bg-[var(--c-bg-deep)]'
                }`}
              >
                <span className="text-[var(--c-accent)] font-mono shrink-0">/{skill.name}</span>
                <span className="text-[var(--c-text-secondary)] truncate">{skill.description?.slice(0, 50) || ''}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Attachment grid */}
      {files.length > 0 && (
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '8px',
            padding: '12px 16px 8px',
          }}
        >
          {files.map((f, i) => (
            f.isImage ? (
              <div
                key={i}
                style={{ position: 'relative', display: 'inline-block' }}
              >
                <img
                  src={toFileUrl(f.filePath)}
                  alt={f.name}
                  title={f.filePath}
                  style={{
                    width: '64px',
                    height: '64px',
                    objectFit: 'cover',
                    borderRadius: '8px',
                    display: 'block',
                    border: '0.5px solid var(--c-border-subtle)',
                  }}
                />
                <button
                  type="button"
                  onClick={() => removeFile(i)}
                  style={{
                    position: 'absolute',
                    top: '-6px',
                    right: '-6px',
                    width: '18px',
                    height: '18px',
                    borderRadius: '50%',
                    background: 'var(--c-text-secondary)',
                    border: 'none',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: 0,
                  }}
                >
                  <X size={10} style={{ color: '#fff' }} />
                </button>
              </div>
            ) : (
              <div
                key={i}
                className="flex items-center gap-2 rounded-lg px-3 py-1.5"
                style={{
                  background: 'var(--c-bg-deep)',
                  border: '0.5px solid var(--c-border-subtle)',
                  maxWidth: '280px',
                }}
              >
                <span className="text-sm text-[var(--c-text-primary)] truncate" title={f.filePath}>{f.name}</span>
                <button
                  type="button"
                  onClick={() => removeFile(i)}
                  className="flex items-center justify-center rounded-md hover:bg-[rgba(0,0,0,0.05)] flex-shrink-0"
                  style={{ width: '18px', height: '18px', border: 'none', background: 'transparent', cursor: 'pointer', padding: 0 }}
                >
                  <X size={12} style={{ color: 'var(--c-text-secondary)' }} />
                </button>
              </div>
            )
          ))}
        </div>
      )}

      {/* Queued message banner */}
      {queuedText && (
        <div
          className="flex items-center gap-2 rounded-lg px-3 py-2 mb-2"
          style={{
            background: 'var(--c-bg-deep)',
            border: '0.5px solid var(--c-border-subtle)',
          }}
        >
          <span className="text-xs text-[var(--c-text-secondary)] shrink-0">{t.chatInput.queued}</span>
          <span className="text-sm text-[var(--c-text-primary)] truncate flex-1" title={queuedText}>{queuedText}</span>
          {onCancelQueue && (
            <button
              type="button"
              onClick={onCancelQueue}
              className="flex items-center justify-center rounded-md hover:bg-[rgba(0,0,0,0.05)]"
              style={{ width: '20px', height: '20px', border: 'none', background: 'transparent', cursor: 'pointer', padding: 0 }}
            >
              <X size={14} style={{ color: 'var(--c-text-secondary)' }} />
            </button>
          )}
        </div>
      )}

      {/* Input container - pill shaped with shadow */}
      <div
        role="presentation"
        className={[
          focused && 'is-focused',
        ].filter(Boolean).join(' ')}
        style={{
          borderWidth: '0.5px',
          borderStyle: 'solid',
          borderColor: focused ? 'var(--c-input-border-color-focus)' : 'var(--c-input-border-color)',
          borderRadius: '20px',
          boxShadow: focused ? 'var(--c-input-shadow-focus)' : 'var(--c-input-shadow)',
          transition: 'border-color 0.2s ease, box-shadow 0.2s ease',
          background: 'var(--c-bg-card)',
          cursor: 'default',
        }}
        onClick={(e) => {
          const tag = (e.target as HTMLElement).tagName;
          if (tag !== 'BUTTON' && tag !== 'TEXTAREA' && tag !== 'INPUT' && tag !== 'SVG' && tag !== 'PATH') {
            textareaRef.current?.focus();
          }
        }}
        onKeyDown={(e) => { if (e.key === 'Enter') textareaRef.current?.focus(); }}
      >
        <form
          onSubmit={(e) => { e.preventDefault(); void submit(); }}
          style={{ padding: '10px 12px 8px' }}
        >
          {/* Textarea */}
          <div style={{ position: 'relative', marginBottom: '8px' }}>
            <textarea aria-label={resolvedPlaceholder}
              ref={textareaCallbackRef}
              rows={1}
              className="w-full resize-none bg-transparent outline-none"
              value={internalValue}
              onChange={handleChange}
              onKeyDown={handleKeyDown}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              placeholder={resolvedPlaceholder}
              disabled={disabled}
              style={{
                fontFamily: 'inherit',
                fontSize: '16px',
                fontWeight: 310,
                lineHeight: 1.45,
                color: 'var(--c-text-primary)',
                letterSpacing: '-0.16px',
                maxHeight: `${TEXTAREA_MAX_HEIGHT}px`,
                overflowY: 'auto',
              }}
            />
          </div>

          {/* Bottom row */}
          <div
            className="flex items-center"
            style={{ gap: '8px', minHeight: '32px', width: '100%', minWidth: 0 }}
          >
            {!isRunning && (
              <button
                type="button"
                aria-label={t.chatInput.attachFiles}
                onClick={handleAttach}
                className="flex size-[33.5px] flex-shrink-0 items-center justify-center rounded-lg bg-[var(--c-bg-deep)] text-[var(--c-text-secondary)] transition-[opacity,background] duration-[60ms] hover:bg-[var(--c-bg-deep)] hover:opacity-100 opacity-70"
              >
                <Plus size={18} />
              </button>
            )}
            <ChatModelPicker />
            <div style={{ flex: 1, minWidth: 0 }} />

            {isRunning ? (
              <button
                type="button"
                onClick={onStop}
                className="flex size-[33.5px] flex-shrink-0 items-center justify-center rounded-lg bg-[var(--c-bg-deep)] text-[var(--c-text-secondary)] transition-[opacity,background] duration-[60ms] hover:bg-[var(--c-bg-deep)] hover:opacity-100 opacity-70"
              >
                <Square size={14} />
              </button>
            ) : (
              <button
                type="submit"
                aria-label={t.chatInput.send}
                disabled={disabled || submitting || (!internalValue.trim() && files.length === 0)}
                className="flex size-[33.5px] flex-shrink-0 items-center justify-center rounded-lg bg-[var(--c-accent-send)] text-[var(--c-accent-send-text)] transition-[background-color,opacity] duration-[60ms] hover:bg-[var(--c-accent-send-hover)] active:opacity-[0.75] active:scale-[0.93] disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Send size={18} />
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
