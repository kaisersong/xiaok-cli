# Actual unchanged dependencies and complete model service

## FULL desktop/electron/meeting-model-service.ts SHA256 8249ef57a24c962b75964468ed14d6e829d882cfc2b48ffcb126c81c52f18a33
```typescript
import { execFile as execFileCallback } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, truncateSync, type WriteStream } from 'node:fs';
import type { ClientRequest, IncomingMessage } from 'node:http';
import { get as httpGet } from 'node:http';
import { get as httpsGet } from 'node:https';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { promisify, types as nodeTypes } from 'node:util';

export type MeetingModelCheckReason = 'ready' | 'missing' | 'size_mismatch' | 'hash_mismatch';
export type MeetingModelDownloadStatus = 'downloaded' | 'not_downloaded' | 'incomplete' | 'corrupt';
export type MeetingModelPackageState = 'missing' | 'downloading' | 'incomplete' | 'verified' | 'corrupt';
export type MeetingModelPackageType = 'single-file' | 'directory';
export type MeetingModelCapability = 'asr' | 'punctuation' | 'vad' | 'speaker';

export interface MeetingModelDefinition {
  id: string;
  capability?: MeetingModelCapability;
  fileName: string;
  url: string;
  mirrors?: readonly string[];
  expectedSizeBytes: number;
  expectedSha256: string;
  engineId?: string;
  packageId?: string;
  packageType?: MeetingModelPackageType;
  archiveFileName?: string;
  requiredFiles?: readonly string[];
  runtimeAutoDownloadAllowed?: false;
}

export interface MeetingModelInfo {
  id: string;
  fileName: string;
  sizeBytes: number;
  sizeLabel: string;
  cacheDir: string;
  path: string;
  downloaded: boolean;
  status: MeetingModelDownloadStatus;
  capability: MeetingModelCapability;
  engineId: string;
  packageId: string;
  packageType: MeetingModelPackageType;
  packageState: MeetingModelPackageState;
  manifestTrusted: boolean;
  runtimeAutoDownloadAllowed: false;
  localSizeBytes?: number;
  localSizeLabel?: string;
}

export interface MeetingModelCheckInput {
  path: string;
  expectedSizeBytes: number;
  expectedSha256: string;
}

export type MeetingModelCheckResult =
  | { ready: true; reason: 'ready' }
  | { ready: false; reason: Exclude<MeetingModelCheckReason, 'ready'> };

export interface MeetingModelService {
  checkModelFile(input: MeetingModelCheckInput): MeetingModelCheckResult;
  listModels(): MeetingModelInfo[];
  downloadModel(modelId: string): Promise<{ ok: true; model: MeetingModelInfo }>;
  uninstallModel(modelId: string): { ok: true; model: MeetingModelInfo };
}

export interface MeetingModelDownloadOptions {
  expectedSizeBytes: number;
  expectedSha256: string;
}

export type MeetingModelDownloadFile = (url: string, destination: string, options: MeetingModelDownloadOptions) => Promise<void>;
export type MeetingModelExtractArchive = (archivePath: string, destinationDir: string, model: MeetingModelDefinition) => Promise<void>;

const MEETING_MODEL_DOWNLOAD_MAX_ATTEMPTS = 20;
const execFileAsync = promisify(execFileCallback);

export interface MeetingModelServiceOptions {
  readonlyIoPolicy?: 'truthful';
  cacheDir?: string;
  env?: NodeJS.ProcessEnv;
  models?: readonly MeetingModelDefinition[];
  downloadFile?: MeetingModelDownloadFile;
  extractArchive?: MeetingModelExtractArchive;
}

export function sha256File(filePath: string): string {
  return createHash('sha256').update(readFileSync(filePath)).digest('hex');
}

export function checkMeetingModelFile(input: MeetingModelCheckInput): MeetingModelCheckResult {
  if (!existsSync(input.path)) {
    return { ready: false, reason: 'missing' };
  }
  const stat = statSync(input.path);
  if (stat.size !== input.expectedSizeBytes) {
    return { ready: false, reason: 'size_mismatch' };
  }
  if (sha256File(input.path) !== input.expectedSha256) {
    return { ready: false, reason: 'hash_mismatch' };
  }
  return { ready: true, reason: 'ready' };
}

export const MEETING_TRANSCRIBER_MODEL_REGISTRY: readonly MeetingModelDefinition[] = [
  {
    id: 'sherpa-onnx-paraformer-zh-small-2024-03-09',
    capability: 'asr',
    engineId: 'sherpa-onnx-paraformer',
    packageId: 'sherpa-onnx-paraformer-zh-small-2024-03-09',
    packageType: 'directory',
    fileName: 'sherpa-onnx-paraformer-zh-small-2024-03-09',
    archiveFileName: 'sherpa-onnx-paraformer-zh-small-2024-03-09.tar.bz2',
    url: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-paraformer-zh-small-2024-03-09.tar.bz2',
    expectedSizeBytes: 77_920_048,
    expectedSha256: 'da92b3db5218c5be53aad53e57d1b6e63e7fc98a0e054fbdd6dbe18e9c6b1450',
    requiredFiles: ['model.int8.onnx', 'tokens.txt'],
    runtimeAutoDownloadAllowed: false,
  },
  {
    id: 'sherpa-onnx-punct-ct-transformer-zh-en-vocab272727-int8',
    capability: 'punctuation',
    engineId: 'sherpa-onnx-punctuation',
    packageId: 'sherpa-onnx-punct-ct-transformer-zh-en-vocab272727-int8',
    packageType: 'directory',
    fileName: 'sherpa-onnx-punct-ct-transformer-zh-en-vocab272727-2024-04-12-int8',
    archiveFileName: 'sherpa-onnx-punct-ct-transformer-zh-en-vocab272727-2024-04-12-int8.tar.bz2',
    url: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/punctuation-models/sherpa-onnx-punct-ct-transformer-zh-en-vocab272727-2024-04-12-int8.tar.bz2',
    expectedSizeBytes: 64_717_756,
    expectedSha256: 'c0d5aa5f8eeb686032345e180bedf39319dc2e0556781c6264bcadba8328a6e1',
    requiredFiles: ['model.int8.onnx'],
    runtimeAutoDownloadAllowed: false,
  },
  {
    id: 'base',
    fileName: 'base.pt',
    url: 'https://openaipublic.azureedge.net/main/whisper/models/ed3a0b6b1c0edf879ad9b11b1af5a0e6ab5db9205f891f668f8b0e6c6326e34e/base.pt',
    expectedSizeBytes: 145_262_807,
    expectedSha256: 'ed3a0b6b1c0edf879ad9b11b1af5a0e6ab5db9205f891f668f8b0e6c6326e34e',
  },
  {
    id: 'small',
    fileName: 'small.pt',
    url: 'https://openaipublic.azureedge.net/main/whisper/models/9ecf779972d90ba49c06d968637d720dd632c55bbf19d441fb42bf17a411e794/small.pt',
    expectedSizeBytes: 483_617_219,
    expectedSha256: '9ecf779972d90ba49c06d968637d720dd632c55bbf19d441fb42bf17a411e794',
  },
  {
    id: 'medium',
    fileName: 'medium.pt',
    url: 'https://openaipublic.azureedge.net/main/whisper/models/345ae4da62f9b3d59415adc60127b97c714f32e89e936602e85993674d08dcb1/medium.pt',
    expectedSizeBytes: 1_528_008_539,
    expectedSha256: '345ae4da62f9b3d59415adc60127b97c714f32e89e936602e85993674d08dcb1',
  },
  {
    id: 'large',
    fileName: 'large-v3.pt',
    url: 'https://openaipublic.azureedge.net/main/whisper/models/e5b1a55b89c1367dacf97e3e19bfd829a01529dbfdeefa8caeb59b3f1b81dadb/large-v3.pt',
    expectedSizeBytes: 3_087_371_615,
    expectedSha256: 'e5b1a55b89c1367dacf97e3e19bfd829a01529dbfdeefa8caeb59b3f1b81dadb',
  },
  {
    id: 'turbo',
    fileName: 'large-v3-turbo.pt',
    url: 'https://openaipublic.azureedge.net/main/whisper/models/aff26ae408abcba5fbf8813c21e62b0941638c5f6eebfb145be0c9839262a19a/large-v3-turbo.pt',
    expectedSizeBytes: 1_617_941_637,
    expectedSha256: 'aff26ae408abcba5fbf8813c21e62b0941638c5f6eebfb145be0c9839262a19a',
  },
];

export function resolveMeetingWhisperCacheDir(env: NodeJS.ProcessEnv = process.env): string {
  const explicit = env.XIAOK_MEETING_WHISPER_CACHE?.trim();
  if (explicit) return explicit;
  const baseCacheDir = env.XDG_CACHE_HOME?.trim() || join(homedir(), '.cache');
  return join(baseCacheDir, 'whisper');
}

export function formatMeetingModelSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B';
  if (bytes < 1_000) return `${bytes} B`;
  if (bytes < 1_000_000) return `${Math.round(bytes / 1_000)} KB`;
  if (bytes < 1_000_000_000) return `${Math.round(bytes / 1_000_000)} MB`;
  return `${(bytes / 1_000_000_000).toFixed(1)} GB`;
}

function truthfulModelPathExists(path: string): boolean {
  try { statSync(path); return true; }
  catch(error) { if(error && typeof error==='object' && !nodeTypes.isProxy(error) && Object.getOwnPropertyDescriptor(error,'code')?.value==='ENOENT')return false;throw error; }
}

export function createMeetingModelService(options: MeetingModelServiceOptions = {}): MeetingModelService {
  const env = options.env ?? process.env;
  const cacheDir = options.cacheDir ?? resolveMeetingWhisperCacheDir(env);
  const models = options.models ?? MEETING_TRANSCRIBER_MODEL_REGISTRY;
  const downloadFile = options.downloadFile ?? downloadMeetingModelFile;
  const extractArchive = options.extractArchive ?? extractMeetingModelArchive;

  function findModel(modelId: string): MeetingModelDefinition {
    const model = models.find(item => item.id === modelId);
    if (!model) throw new Error(`unknown_meeting_model:${modelId}`);
    return model;
  }

  function getModelInfo(model: MeetingModelDefinition, truthful = false): MeetingModelInfo {
    const pathExists = truthful ? truthfulModelPathExists : existsSync;
    const modelPath = join(cacheDir, model.fileName);
    const baseInfo = buildModelPackageInfo(model);
    if ((model.packageType ?? 'single-file') === 'directory') {
      return getDirectoryModelInfo(model, modelPath, baseInfo, pathExists);
    }
    if (!pathExists(modelPath)) {
      return {
        id: model.id,
        fileName: model.fileName,
        sizeBytes: model.expectedSizeBytes,
        sizeLabel: formatMeetingModelSize(model.expectedSizeBytes),
        cacheDir,
        path: modelPath,
        downloaded: false,
        status: 'not_downloaded',
        packageState: 'missing',
        ...baseInfo,
      };
    }

    const localSizeBytes = statSync(modelPath).size;
    // The truthful reader must not re-enter existsSync, which hides access errors.
    const check: MeetingModelCheckResult = truthful
      ? localSizeBytes !== model.expectedSizeBytes
        ? { ready: false, reason: 'size_mismatch' }
        : sha256File(modelPath) !== model.expectedSha256
          ? { ready: false, reason: 'hash_mismatch' }
          : { ready: true, reason: 'ready' }
      : checkMeetingModelFile({
        path: modelPath,
        expectedSizeBytes: model.expectedSizeBytes,
        expectedSha256: model.expectedSha256,
      });
    const downloaded = check.ready;
    const status = downloaded ? 'downloaded' : check.reason === 'hash_mismatch' ? 'corrupt' : 'incomplete';
    const packageState: MeetingModelPackageState = downloaded
      ? 'verified'
      : status === 'corrupt'
        ? 'corrupt'
        : 'incomplete';
    return {
      id: model.id,
      fileName: model.fileName,
      sizeBytes: model.expectedSizeBytes,
      sizeLabel: formatMeetingModelSize(model.expectedSizeBytes),
      cacheDir,
      path: modelPath,
      downloaded,
      status,
      packageState,
      ...baseInfo,
      localSizeBytes,
      localSizeLabel: formatMeetingModelSize(localSizeBytes),
    };
  }

  return {
    checkModelFile: checkMeetingModelFile,
    listModels() {
      return models.map(model => getModelInfo(model, options.readonlyIoPolicy === 'truthful'));
    },
    async downloadModel(modelId) {
      const model = findModel(modelId);
      if ((model.packageType ?? 'single-file') === 'directory') {
        return downloadDirectoryModelPackage(model, cacheDir, downloadFile, extractArchive, getModelInfo);
      }
      mkdirSync(cacheDir, { recursive: true });
      const modelPath = join(cacheDir, model.fileName);
      await downloadModelFromMirrors(model, modelPath, downloadFile);
      let check = this.checkModelFile({
        path: modelPath,
        expectedSizeBytes: model.expectedSizeBytes,
        expectedSha256: model.expectedSha256,
      });
      if (!check.ready && check.reason === 'hash_mismatch') {
        rmSync(modelPath, { force: true });
        await downloadModelFromMirrors(model, modelPath, downloadFile);
        check = this.checkModelFile({
          path: modelPath,
          expectedSizeBytes: model.expectedSizeBytes,
          expectedSha256: model.expectedSha256,
        });
      }
      if (!check.ready) {
        throw new Error(check.reason);
      }
      return { ok: true, model: getModelInfo(model) };
    },
    uninstallModel(modelId) {
      const model = findModel(modelId);
      const isDirectoryPackage = (model.packageType ?? 'single-file') === 'directory';
      rmSync(join(cacheDir, model.fileName), { recursive: isDirectoryPackage, force: true });
      if (isDirectoryPackage) {
        rmSync(join(cacheDir, model.archiveFileName ?? `${model.fileName}.tar.bz2`), { force: true });
      }
      return { ok: true, model: getModelInfo(model) };
    },
  };
}

function getDirectoryModelInfo(
  model: MeetingModelDefinition,
  modelPath: string,
  baseInfo: Pick<
    MeetingModelInfo,
    'engineId' | 'packageId' | 'packageType' | 'manifestTrusted' | 'runtimeAutoDownloadAllowed' | 'capability'
  >,
  pathExists: (path: string) => boolean = existsSync,
): MeetingModelInfo {
  if (!pathExists(modelPath)) {
    return {
      id: model.id,
      fileName: model.fileName,
      sizeBytes: model.expectedSizeBytes,
      sizeLabel: formatMeetingModelSize(model.expectedSizeBytes),
      cacheDir: dirname(modelPath),
      path: modelPath,
      downloaded: false,
      status: 'not_downloaded',
      packageState: 'missing',
      ...baseInfo,
    };
  }

  const localSizeBytes = calculateLocalPackageSize(modelPath, pathExists);
  const stat = statSync(modelPath);
  const requiredFiles = model.requiredFiles ?? [];
  const hasRequiredFiles = stat.isDirectory()
    && requiredFiles.every(requiredFile => pathExists(join(modelPath, requiredFile)));
  return {
    id: model.id,
    fileName: model.fileName,
    sizeBytes: model.expectedSizeBytes,
    sizeLabel: formatMeetingModelSize(model.expectedSizeBytes),
    cacheDir: dirname(modelPath),
    path: modelPath,
    downloaded: hasRequiredFiles,
    status: hasRequiredFiles ? 'downloaded' : 'incomplete',
    packageState: hasRequiredFiles ? 'verified' : 'incomplete',
    ...baseInfo,
    localSizeBytes,
    localSizeLabel: formatMeetingModelSize(localSizeBytes),
  };
}

function calculateLocalPackageSize(path: string, pathExists: (path: string) => boolean = existsSync): number {
  if (!pathExists(path)) return 0;
  const stat = statSync(path);
  if (!stat.isDirectory()) return stat.size;
  return readdirSync(path, { withFileTypes: true }).reduce((total, entry) => {
    const childPath = join(path, entry.name);
    if (entry.isDirectory()) return total + calculateLocalPackageSize(childPath, pathExists);
    if (entry.isFile()) return total + statSync(childPath).size;
    return total;
  }, 0);
}

async function downloadDirectoryModelPackage(
  model: MeetingModelDefinition,
  cacheDir: string,
  downloadFile: MeetingModelDownloadFile,
  extractArchive: MeetingModelExtractArchive,
  getModelInfo: (model: MeetingModelDefinition) => MeetingModelInfo,
): Promise<{ ok: true; model: MeetingModelInfo }> {
  mkdirSync(cacheDir, { recursive: true });
  const archivePath = join(cacheDir, model.archiveFileName ?? `${model.fileName}.tar.bz2`);
  const modelPath = join(cacheDir, model.fileName);
  await downloadModelFromMirrors(model, archivePath, downloadFile);
  let check = checkMeetingModelFile({
    path: archivePath,
    expectedSizeBytes: model.expectedSizeBytes,
    expectedSha256: model.expectedSha256,
  });
  if (!check.ready && check.reason === 'hash_mismatch') {
    rmSync(archivePath, { force: true });
    await downloadModelFromMirrors(model, archivePath, downloadFile);
    check = checkMeetingModelFile({
      path: archivePath,
      expectedSizeBytes: model.expectedSizeBytes,
      expectedSha256: model.expectedSha256,
    });
  }
  if (!check.ready) {
    throw new Error(check.reason);
  }

  rmSync(modelPath, { recursive: true, force: true });
  await extractArchive(archivePath, modelPath, model);
  rmSync(archivePath, { force: true });
  const info = getModelInfo(model);
  if (!info.downloaded) {
    throw new Error('model_package_incomplete');
  }
  return { ok: true, model: info };
}

async function extractMeetingModelArchive(
  archivePath: string,
  destinationDir: string,
  _model: MeetingModelDefinition,
): Promise<void> {
  mkdirSync(dirname(destinationDir), { recursive: true });
  await execFileAsync('tar', ['-xjf', archivePath, '-C', dirname(destinationDir)], {
    timeout: 10 * 60 * 1000,
  });
}

function buildModelPackageInfo(model: MeetingModelDefinition): Pick<
  MeetingModelInfo,
  'capability' | 'engineId' | 'packageId' | 'packageType' | 'manifestTrusted' | 'runtimeAutoDownloadAllowed'
> {
  return {
    capability: model.capability ?? 'asr',
    engineId: model.engineId ?? 'whisper',
    packageId: model.packageId ?? `whisper-${model.id}`,
    packageType: model.packageType ?? 'single-file',
    manifestTrusted: true,
    runtimeAutoDownloadAllowed: false,
  };
}

async function downloadModelFromMirrors(
  model: MeetingModelDefinition,
  modelPath: string,
  downloadFile: MeetingModelDownloadFile,
): Promise<void> {
  let lastError: unknown;
  for (const url of [model.url, ...(model.mirrors ?? [])]) {
    try {
      await downloadFile(url, modelPath, {
        expectedSizeBytes: model.expectedSizeBytes,
        expectedSha256: model.expectedSha256,
      });
      return;
    } catch (error) {
      lastError = error;
      rmSync(modelPath, { force: true });
    }
  }
  throw lastError instanceof Error ? lastError : new Error('download_failed');
}

async function downloadMeetingModelFile(url: string, destination: string, options: MeetingModelDownloadOptions): Promise<void> {
  let lastError: unknown;
  for (let attempt = 0; attempt < MEETING_MODEL_DOWNLOAD_MAX_ATTEMPTS; attempt += 1) {
    try {
      await downloadMeetingModelFileOnce(url, destination, options);
      return;
    } catch (error) {
      lastError = error;
      if (!isRetriableDownloadError(error)) {
        throw error;
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error('download_failed:retry_exhausted');
}

function downloadMeetingModelFileOnce(url: string, destination: string, options: MeetingModelDownloadOptions): Promise<void> {
  const existingSize = existsSync(destination) ? statSync(destination).size : 0;
  if (existingSize >= options.expectedSizeBytes) {
    rmSync(destination, { force: true });
  }
  const startByte = existingSize > 0 && existingSize < options.expectedSizeBytes ? existingSize : 0;

  return new Promise((resolve, reject) => {
    const request = (href: string, rangeStart: number) => {
      const getter = selectHttpGetter(href);
      const headers = rangeStart > 0 ? { Range: `bytes=${rangeStart}-` } : undefined;
      let requestHandle: ClientRequest | null = null;
      requestHandle = getter(href, { headers }, (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          const next = res.headers.location.startsWith('/') ? new URL(res.headers.location, href).href : res.headers.location;
          res.resume();
          request(next, rangeStart);
          return;
        }
        if (res.statusCode === 416 && rangeStart > 0) {
          res.resume();
          rmSync(destination, { force: true });
          request(href, 0);
          return;
        }
        if (res.statusCode !== 200 && res.statusCode !== 206) {
          reject(new Error(`download_failed:${res.statusCode ?? 'unknown'}`));
          return;
        }
        const append = res.statusCode === 206 && rangeStart > 0;
        const file = createWriteStream(destination, { flags: append ? 'a' : 'w' });
        let settled = false;
        const fail = (error: Error) => settleDownloadAttempt({
          error,
          file,
          reject,
          request: requestHandle,
          response: res,
          settled,
          setSettled: () => { settled = true; },
        });
        res.on('aborted', () => fail(new Error('aborted')));
        res.on('error', fail);
        file.on('error', fail);
        res.pipe(file);
        file.on('finish', () => {
          if (settled) return;
          settled = true;
          file.close((error) => {
            if (error) {
              reject(error);
              return;
            }
            clampMeetingModelDownloadSize(destination, options.expectedSizeBytes);
            resolve();
          });
        });
      }).on('error', (error) => {
        reject(error);
      });
    };
    request(url, startByte);
  });
}

function settleDownloadAttempt(input: {
  error: Error;
  file: WriteStream;
  reject: (error: Error) => void;
  request: ClientRequest | null;
  response: IncomingMessage;
  settled: boolean;
  setSettled: () => void;
}): void {
  if (input.settled) return;
  input.setSettled();
  input.response.unpipe(input.file);
  input.response.destroy();
  input.request?.destroy();
  input.file.destroy();
  input.reject(input.error);
}

function clampMeetingModelDownloadSize(destination: string, expectedSizeBytes: number): void {
  if (!existsSync(destination)) return;
  if (statSync(destination).size > expectedSizeBytes) {
    truncateSync(destination, expectedSizeBytes);
  }
}

function selectHttpGetter(href: string): typeof httpGet {
  const protocol = new URL(href).protocol;
  if (protocol === 'http:') return httpGet;
  if (protocol === 'https:') return httpsGet;
  throw new Error(`unsupported_download_protocol:${protocol}`);
}

function isRetriableDownloadError(error: unknown): boolean {
  if (!(error instanceof Error)) return false;
  if (error.message.startsWith('download_failed:') || error.message.startsWith('unsupported_download_protocol:')) {
    return false;
  }
  const code = (error as NodeJS.ErrnoException).code;
  return code === 'ECONNRESET'
    || code === 'ETIMEDOUT'
    || code === 'EAI_AGAIN'
    || code === 'ENOTFOUND'
    || error.message === 'aborted'
    || error.message === 'socket hang up';
}

```

## FULL desktop/electron/meeting-asr-config.ts SHA256 8dff6fe7d67b71f7c2bd6a07f94f9bb089e8061565611c3428d11d390487da13
```typescript
import type { Config } from '../../src/types.js';

export type MeetingAsrProviderId = 'sherpa-onnx-paraformer' | 'whisper' | 'volcengine-asr' | 'aliyun-asr';

export interface MeetingAsrProviderStatus {
  configured: boolean;
  appKeyConfigured: boolean;
  endpoint?: string;
}

export interface MeetingVolcengineAsrStatus extends MeetingAsrProviderStatus {
  accessKeyConfigured: boolean;
  resourceId: string;
}

export interface MeetingAliyunAsrStatus {
  configured: boolean;
  apiKeyConfigured: boolean;
  baseUrl: string;
  model: string;
}

export interface MeetingAsrConfigSnapshot {
  defaultProvider: MeetingAsrProviderId;
  volcengine: MeetingVolcengineAsrStatus;
  aliyun: MeetingAliyunAsrStatus;
}

export interface MeetingSaveAsrConfigInput {
  defaultProvider?: MeetingAsrProviderId;
  volcengine?: {
    appKey?: string;
    accessKey?: string;
    endpoint?: string;
    resourceId?: string;
    clearAppKey?: boolean;
    clearAccessKey?: boolean;
  };
  aliyun?: {
    apiKey?: string;
    baseUrl?: string;
    model?: string;
    clearApiKey?: boolean;
  };
}

export interface MeetingVolcengineAsrCredentials {
  appKey: string;
  accessKey?: string;
  endpoint: string;
  resourceId: string;
}

export interface MeetingAliyunAsrCredentials {
  apiKey: string;
  baseUrl: string;
  model: string;
}

const DEFAULT_PROVIDER: MeetingAsrProviderId = 'sherpa-onnx-paraformer';
const PROVIDERS = new Set<MeetingAsrProviderId>(['sherpa-onnx-paraformer', 'whisper', 'volcengine-asr', 'aliyun-asr']);
const LEGACY_VOLCENGINE_ENDPOINT = 'https://openspeech.bytedance.com/api/v3/auc/bigmodel/recognize/flash';
const LEGACY_VOLCENGINE_RESOURCE_ID = 'volc.bigasr.auc_turbo';
const DEFAULT_VOLCENGINE_ENDPOINT = 'wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_async';
const DEFAULT_VOLCENGINE_RESOURCE_ID = 'volc.seedasr.sauc.duration';
const DEFAULT_ALIYUN_BASE_URL = 'https://dashscope.aliyuncs.com';
const DEFAULT_ALIYUN_MODEL = 'fun-asr';

export function createMeetingAsrConfigSnapshot(config: Config): MeetingAsrConfigSnapshot {
  const asr = config.meeting?.asr;
  const defaultProvider = asr?.defaultProvider && PROVIDERS.has(asr.defaultProvider)
    ? asr.defaultProvider
    : DEFAULT_PROVIDER;
  const volcengine = asr?.volcengine ?? {};
  const aliyun = asr?.aliyun ?? {};
  const volcAppKeyConfigured = Boolean(volcengine.appKey?.trim());
  const volcAccessKeyConfigured = Boolean(volcengine.accessKey?.trim());
  const aliyunApiKeyConfigured = Boolean((aliyun.apiKey ?? aliyun.appKey)?.trim());

  return {
    defaultProvider,
    volcengine: {
      configured: volcAppKeyConfigured,
      appKeyConfigured: volcAppKeyConfigured,
      accessKeyConfigured: volcAccessKeyConfigured,
      endpoint: normalizeVolcengineEndpoint(volcengine.endpoint),
      resourceId: normalizeVolcengineResourceId(volcengine.resourceId),
    },
    aliyun: {
      configured: aliyunApiKeyConfigured,
      apiKeyConfigured: aliyunApiKeyConfigured,
      baseUrl: normalizeEndpoint(aliyun.baseUrl ?? aliyun.endpoint) || DEFAULT_ALIYUN_BASE_URL,
      model: normalizeOptionalString(aliyun.model) || DEFAULT_ALIYUN_MODEL,
    },
  };
}

export function applyMeetingAsrConfigUpdate(config: Config, input: MeetingSaveAsrConfigInput): Config {
  config.meeting = {
    ...(config.meeting ?? {}),
    asr: {
      ...(config.meeting?.asr ?? {}),
    },
  };
  const asr = config.meeting.asr!;
  if (input.defaultProvider && PROVIDERS.has(input.defaultProvider)) {
    asr.defaultProvider = input.defaultProvider;
  }

  if (input.volcengine) {
    asr.volcengine = { ...(asr.volcengine ?? {}) };
    applySecretField(asr.volcengine, 'appKey', input.volcengine.appKey, input.volcengine.clearAppKey);
    applySecretField(asr.volcengine, 'accessKey', input.volcengine.accessKey, input.volcengine.clearAccessKey);
    applyPlainField(asr.volcengine, 'endpoint', input.volcengine.endpoint);
    applyPlainField(asr.volcengine, 'resourceId', input.volcengine.resourceId);
  }

  if (input.aliyun) {
    asr.aliyun = { ...(asr.aliyun ?? {}) };
    applySecretField(asr.aliyun, 'apiKey', input.aliyun.apiKey, input.aliyun.clearApiKey);
    applyPlainField(asr.aliyun, 'baseUrl', input.aliyun.baseUrl === undefined ? undefined : normalizeEndpoint(input.aliyun.baseUrl));
    applyPlainField(asr.aliyun, 'model', input.aliyun.model);
  }

  return config;
}

export function resolveMeetingVolcengineAsrCredentials(config: Config): MeetingVolcengineAsrCredentials {
  const provider = config.meeting?.asr?.volcengine;
  const appKey = normalizeOptionalString(provider?.appKey);
  if (!appKey) throw new Error('volcengine_asr_not_configured');
  return {
    appKey,
    accessKey: normalizeOptionalString(provider?.accessKey),
    endpoint: normalizeVolcengineEndpoint(provider?.endpoint),
    resourceId: normalizeVolcengineResourceId(provider?.resourceId),
  };
}

export function resolveMeetingAliyunAsrCredentials(config: Config): MeetingAliyunAsrCredentials {
  const provider = config.meeting?.asr?.aliyun;
  const apiKey = normalizeOptionalString(provider?.apiKey ?? provider?.appKey);
  if (!apiKey) throw new Error('aliyun_asr_not_configured');
  return {
    apiKey,
    baseUrl: normalizeEndpoint(provider?.baseUrl ?? provider?.endpoint) || DEFAULT_ALIYUN_BASE_URL,
    model: normalizeOptionalString(provider?.model) || DEFAULT_ALIYUN_MODEL,
  };
}

function applySecretField<T extends Record<string, unknown>>(target: T, key: keyof T & string, value?: string, clear?: boolean): void {
  if (clear) {
    delete target[key];
    return;
  }
  const normalized = normalizeOptionalString(value);
  if (normalized) {
    target[key] = normalized as T[keyof T & string];
  }
}

function applyPlainField<T extends Record<string, unknown>>(target: T, key: keyof T & string, value?: string): void {
  if (value === undefined) return;
  const normalized = normalizeOptionalString(value);
  if (normalized) {
    target[key] = normalized as T[keyof T & string];
  } else {
    delete target[key];
  }
}

function normalizeEndpoint(value?: string): string {
  const normalized = normalizeOptionalString(value);
  if (!normalized) return '';
  return normalized.replace(/\/+$/, '');
}

function normalizeVolcengineEndpoint(value?: string): string {
  const endpoint = normalizeEndpoint(value);
  return !endpoint || endpoint === LEGACY_VOLCENGINE_ENDPOINT ? DEFAULT_VOLCENGINE_ENDPOINT : endpoint;
}

function normalizeVolcengineResourceId(value?: string): string {
  const resourceId = normalizeOptionalString(value);
  return !resourceId || resourceId === LEGACY_VOLCENGINE_RESOURCE_ID ? DEFAULT_VOLCENGINE_RESOURCE_ID : resourceId;
}

function normalizeOptionalString(value?: string): string {
  return typeof value === 'string' ? value.trim() : '';
}

```

## FULL desktop/electron/meeting-audio-permission.ts SHA256 78440af28bae453e40aaca5b65f516ab85caeda477f3e01f5fc73eff03633b1e
```typescript
export type MeetingMicrophonePermissionStatus = 'granted' | 'denied' | 'prompt' | 'restricted' | 'unknown' | 'unsupported';

export interface MeetingAudioPermissionResult {
  status: MeetingMicrophonePermissionStatus;
}

export interface MeetingAudioPermissionDeps {
  platform: NodeJS.Platform | string;
  getMediaAccessStatus?: (mediaType: 'microphone') => string;
  askForMediaAccess?: (mediaType: 'microphone') => Promise<boolean>;
}

function normalizeMediaAccessStatus(status: string | undefined): MeetingMicrophonePermissionStatus {
  switch (status) {
    case 'granted':
      return 'granted';
    case 'denied':
      return 'denied';
    case 'restricted':
      return 'restricted';
    case 'not-determined':
      return 'prompt';
    case undefined:
      return 'unknown';
    default:
      return 'unknown';
  }
}

export function createMeetingAudioPermissionService(deps: MeetingAudioPermissionDeps) {
  const supportsSystemPrompt = deps.platform === 'darwin'
    && typeof deps.getMediaAccessStatus === 'function'
    && typeof deps.askForMediaAccess === 'function';

  async function getStatus(): Promise<MeetingAudioPermissionResult> {
    if (!supportsSystemPrompt) return { status: 'unknown' };
    return { status: normalizeMediaAccessStatus(deps.getMediaAccessStatus?.('microphone')) };
  }

  async function requestPermission(): Promise<MeetingAudioPermissionResult> {
    if (!supportsSystemPrompt) return { status: 'unknown' };
    const current = normalizeMediaAccessStatus(deps.getMediaAccessStatus?.('microphone'));
    if (current === 'denied' || current === 'restricted' || current === 'granted') {
      return { status: current };
    }

    const granted = await deps.askForMediaAccess?.('microphone');
    if (granted) return { status: 'granted' };
    return { status: normalizeMediaAccessStatus(deps.getMediaAccessStatus?.('microphone')) };
  }

  return { getStatus, requestPermission };
}

```

## FULL desktop/electron/ipc-runtime.ts SHA256 4bd8a4ce979f6f42219f4b88b917b2a41340fc771349518c97b19526e213e80d
```typescript
import type { IpcMainInvokeEvent } from 'electron';
import type { IpcHandleRegistrar } from './shutdown-aware-ipc-main.js';
import type { ZodSchema } from 'zod';

export type RiskTag =
  | 'fs-read'
  | 'fs-write'
  | 'fs-delete'
  | 'fs-watch'
  | 'shell-open'
  | 'exec'
  | 'network'
  | 'clipboard'
  | 'dialog'
  | 'long-subscription'
  | 'external-process'
  | 'capability-token'
  | 'issues-token'
  | 'internal-mutation'
  | 'fs-write-userData';

export interface IpcSchemaEntry {
  channel: string;
  input: ZodSchema;
  output: ZodSchema;
  sourceFile: string;
  payloadMode: 'single' | 'tuple';
  inputStage: 'beforeHandler' | 'afterHostAuthorization';
  wireInput?: ZodSchema;
  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
  riskTags: RiskTag[];
}

export const IPC_SCHEMA_REGISTRY = new Map<string, IpcSchemaEntry>();

let registrations = new WeakMap<IpcHandleRegistrar, Map<string, IpcSchemaEntry>>();

let ipcMainImpl: IpcHandleRegistrar | null = null;

export function setIpcMainImpl(impl: IpcHandleRegistrar): void {
  ipcMainImpl = impl;
}

export function setIpcMainForTests(fake: IpcHandleRegistrar): void {
  ipcMainImpl = fake;
}

export function resetIpcSchemaRegistryForTests(): void {
  IPC_SCHEMA_REGISTRY.clear();
  registrations = new WeakMap();
}

export interface IpcStageHelpers<I> {
  parseInput(snapshot: unknown): I;
  onFailure(cleanup: () => void): void;
  fail(error: unknown): never;
}
export interface IpcCleanupFailure { channel: string; originalError: unknown; cleanupError: unknown }
export interface IpcRegistrationOptions<I, O> {
  registrar?: IpcHandleRegistrar;
  channel: string;
  input: ZodSchema<I>;
  output: ZodSchema<O>;
  sourceFile: string;
  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
  riskTags?: RiskTag[];
  handler: (input: I, event: IpcMainInvokeEvent, helpers?: IpcStageHelpers<I>) => Promise<O>;
  /** Main-owned adapters preserve domain error envelopes without granting caller authority. */
  inputError?: (error: unknown) => O;
  outputError?: (error: unknown) => O;
  /** Host-only opt-in: default single consumes the first transport payload. */
  payloadMode?: 'single' | 'tuple';
  inputStage?: 'afterHostAuthorization';
  wireInput?: ZodSchema<I>;
  beforeInput?: (event: IpcMainInvokeEvent) => undefined;
  beforeOutput?: (event: IpcMainInvokeEvent) => undefined;
  captureOutput?: (result: O) => O;
  outputCheck?: (result: O) => undefined;
  cleanupFailureReporter?: (failure: IpcCleanupFailure) => void;
}
export function registerIpcHandler<I extends unknown[], O>(opts: Omit<IpcRegistrationOptions<I, O>, 'payloadMode'> & { payloadMode: 'tuple' }): void;
export function registerIpcHandler<I, O>(opts: Omit<IpcRegistrationOptions<I, O>, 'payloadMode'> & { payloadMode?: 'single' }): void;
export function registerIpcHandler<I, O>(opts: IpcRegistrationOptions<I, O>): void {
  if (opts.inputStage && !opts.wireInput) throw new Error('ipc_staged_wire_schema_required');
  const registrar = opts.registrar ?? ipcMainImpl;
  if (!registrar) {
    throw new Error('ipcMainImpl not set. Call setIpcMainImpl(ipcMain) before registering handlers.');
  }
  const owned = registrations.get(registrar) ?? new Map<string, IpcSchemaEntry>();
  if (owned.has(opts.channel)) {
    throw new Error(
      `IPC channel "${opts.channel}" registered twice (existing: ${owned.get(opts.channel)!.sourceFile})`,
    );
  }
  const entry: IpcSchemaEntry = {
    channel: opts.channel,
    input: opts.input,
    output: opts.output,
    sourceFile: opts.sourceFile,
    payloadMode: opts.payloadMode ?? 'single',
    inputStage: opts.inputStage ?? 'beforeHandler',
    ...(opts.wireInput ? { wireInput: opts.wireInput } : {}),
    rolloutRound: opts.rolloutRound,
    riskTags: opts.riskTags ?? [],
  };
  const validateOutput = (result: O): O | { ok: false; error: string } => {
    if (process.env.NODE_ENV !== 'production') {
      try {
        opts.output.parse(result);
      } catch (error) {
        if (!opts.outputError) throw error;
        const fallback = opts.outputError(error);
        opts.output.parse(fallback);
        return fallback;
      }
    } else {
      const checked = opts.output.safeParse(result);
      if (!checked.success) {
        if (!opts.outputError) return { ok: false, error: 'ipc_contract_violation' };
        const fallback = opts.outputError(checked.error);
        opts.output.parse(fallback);
        return fallback;
      }
    }
    return result;
  };
  registrar.handle(opts.channel, async (event: IpcMainInvokeEvent, ...rawArgs: unknown[]) => {
    const raw = opts.payloadMode === 'tuple' ? rawArgs : rawArgs[0];
    const cleanups: Array<() => void> = [];
    let failed = false, parsedFull = false;
    const report = (originalError: unknown, cleanupError: unknown) => {
      const failure = { channel: opts.channel, originalError, cleanupError };
      try {
        if (opts.cleanupFailureReporter) opts.cleanupFailureReporter(failure);
        else console.error('[ipc] owned cleanup failed', failure);
      } catch (reporterError) {
        console.error('[ipc] cleanup diagnostic failed', failure, reporterError);
      }
    };
    const runFailure = (error: unknown): void => {
      if (failed) return;
      failed = true;
      for (const cleanup of cleanups) {
        try { cleanup(); } catch (cleanupError) { report(error, cleanupError); }
      }
    };
    const helpers: IpcStageHelpers<I> = {
      parseInput(snapshot) {
        if (!opts.inputStage || parsedFull) throw new Error('ipc_staged_input_invalid');
        const result = opts.input.parse(snapshot); parsedFull = true; return result;
      },
      onFailure(cleanup) { if (failed) throw new Error('ipc_failed_scope'); cleanups.push(cleanup); },
      fail(error): never { runFailure(error); throw error; },
    };
    try {
      if (opts.beforeInput && opts.beforeInput(event) !== undefined) throw new Error('ipc_admission_must_be_synchronous');
      let parsed: I;
      try {
        parsed = (opts.inputStage ? opts.wireInput! : opts.input).parse(raw);
      } catch (error) {
        if (!opts.inputError) throw error;
        return validateOutput(opts.inputError(error));
      }
      const result = opts.inputStage ? await opts.handler(parsed, event, helpers) : await opts.handler(parsed, event);
      if (opts.inputStage && !parsedFull) throw new Error('ipc_staged_input_not_validated');
      if (opts.beforeOutput && opts.beforeOutput(event) !== undefined) throw new Error('ipc_output_admission_must_be_synchronous');
      const captured = opts.captureOutput ? opts.captureOutput(result) : result;
      if (opts.outputCheck && opts.outputCheck(captured) !== undefined) throw new Error('ipc_output_check_must_be_synchronous');
      return validateOutput(captured);
    } catch (error) {
      runFailure(error); throw error;
    }
  });
  owned.set(opts.channel, entry);
  registrations.set(registrar, owned);
  IPC_SCHEMA_REGISTRY.set(opts.channel, entry);
}

```

## FULL desktop/electron/ipc-data-snapshot.ts SHA256 64ef3e413c324642523bad12070e58b44e7ef04b63f40c60521917ae2eab976c
```typescript
import { types } from 'node:util';
const isProxy = types.isProxy;
const arrayIsArray = Array.isArray;
const getDescriptors = Object.getOwnPropertyDescriptors;
const getPrototype = Object.getPrototypeOf;
const ownKeys = Reflect.ownKeys;
const define = Object.defineProperty;
const hasOwn = Object.hasOwn;
const objectPrototype = Object.prototype;
/** Host-side IPC data capture. Never invokes accessors or custom serializers. */
export function captureIpcData<T>(value: T, errorCode = 'ipc_contract_violation', options?: { preserveDataPrototype?: boolean }): T {
  const memo = new WeakMap<object, object>(), active = new WeakSet<object>();
  const fail = (): never => { throw new Error(errorCode); };
  const visit = (raw: unknown): unknown => {
    if (raw === null || raw === undefined || ['string', 'number', 'boolean', 'bigint'].includes(typeof raw)) return raw;
    if (typeof raw !== 'object' || isProxy(raw)) return fail();
    if (active.has(raw)) return fail();
    const prior = memo.get(raw); if (prior) return prior;
    const array = arrayIsArray(raw);
    const prototype = array ? undefined : getPrototype(raw);
    if (!array && prototype !== objectPrototype && prototype !== null) return fail();
    const descriptors = getDescriptors(raw);
    const length = array ? descriptors.length?.value : 0;
    // Room's canonical storage protocol distinguishes plain and null objects.
    // Only its fixed host adapter opts in; all existing callers keep the old ABI.
    const result: Record<string, unknown> | unknown[] = array ? new Array(length)
      : Object.create(options?.preserveDataPrototype === true ? prototype : null);
    active.add(raw); memo.set(raw, result);
    try {
      for (const key of ownKeys(descriptors)) {
        if (typeof key !== 'string') return fail();
        if (array && key === 'length') continue;
        const descriptor = descriptors[key];
        if (!descriptor.enumerable || !hasOwn(descriptor, 'value')) return fail();
        if (array && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) >= length)) return fail();
        define(result, key, { __proto__: null, value: visit(descriptor.value), writable: true, configurable: true, enumerable: true } as PropertyDescriptor);
      }
    } finally { active.delete(raw); }
    return result;
  };
  return visit(value) as T;
}

```

## FULL desktop/electron/ipc-native-promise.ts SHA256 69ad5daffa7adaed0ad6109a044c6916226962811e45abde742e29827df3fa31
```typescript
import { types } from 'node:util';
const isPromise = types.isPromise, isProxy = types.isProxy;
const ownDescriptor = Object.getOwnPropertyDescriptor, prototypeOf = Object.getPrototypeOf;
const nativePromise = Promise, promisePrototype = nativePromise.prototype;
const species = Symbol.species;
const initialSpecies = ownDescriptor(nativePromise, species);
/** Main-only precondition immediately before applying intrinsic Promise.then. */
export function assertStandardIpcPromise(value: unknown, error: string): asserts value is Promise<unknown> {
  if (!isPromise(value) || isProxy(value) || prototypeOf(value) !== promisePrototype) throw Error(error);
  const own = ownDescriptor(value, 'constructor'), inherited = ownDescriptor(promisePrototype, 'constructor');
  const currentSpecies = ownDescriptor(nativePromise, species);
  if (!inherited || !('value' in inherited) || inherited.value !== nativePromise
    || own && (!('value' in own) || own.value !== nativePromise)
    || !initialSpecies || !currentSpecies || 'value' in currentSpecies || 'value' in initialSpecies
    || currentSpecies.get !== initialSpecies.get || currentSpecies.set !== initialSpecies.set
    || currentSpecies.enumerable !== initialSpecies.enumerable || currentSpecies.configurable !== initialSpecies.configurable) throw Error(error);
}

```

## FULL desktop/electron/shutdown-aware-ipc-main.ts SHA256 d7c6d9de51611e9dad094045e002c1d1bfeef9348f2cd3659cb7ae5373b56632
```typescript
/**
 * DesktopShutdownGate + ShutdownAwareIpcMain (design v58 §5.5, R17-03, R18-01, R19-01).
 *
 * Why a gate instead of a hand-maintained mutation allowlist: production has
 * 206 `ipcMain.handle()` registrations across `main.ts` (53), `ipc.ts` (141) and
 * `kswarm-ipc-proxy.ts` (12), plus the currently caller-less migration shim in
 * `ipc-runtime.ts`. Enumerating "the mutating ones" by hand guarantees a missed
 * entry point, so every invoke — reads included — takes a token and releases it
 * in `finally`.
 *
 * Only `ShutdownAwareIpcMain` may hold the raw Electron `ipcMain`; every other
 * registration surface receives the narrow `IpcHandleRegistrar` interface.
 */

// Type-only import: this module is the sole holder of the raw ipcMain object,
// and the erased type keeps every registrar signature identical to production.
import type { IpcMainInvokeEvent } from 'electron';

// Mirrors Electron's own `ipcMain.handle` signature so every existing handler
// assigns unchanged; `any[]` is deliberate and matches the upstream typing.
/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
export type IpcHandlerListener = (event: IpcMainInvokeEvent, ...args: any[]) => unknown;

/** The narrow surface every registration site receives. */
export interface IpcHandleRegistrar {
  handle(channel: string, listener: IpcHandlerListener): void;
}

/** Minimal shape of the raw Electron ipcMain we depend on. */
export interface RawIpcMainLike {
  handle(channel: string, listener: IpcHandlerListener): void;
}

export type ShutdownTokenKind =
  | 'ipc'
  | 'task_execution'
  | 'bootstrap_queue'
  | 'external';

export interface ShutdownToken {
  readonly id: number;
  readonly kind: ShutdownTokenKind;
  readonly label: string;
  release(): void;
}

export class ShuttingDownError extends Error {
  readonly code = 'shutting_down';

  constructor(label: string) {
    super(`shutting_down: ${label}`);
    this.name = 'ShuttingDownError';
  }
}

export class DesktopShutdownGate {
  private open = true;

  private seq = 0;

  private readonly tokens = new Map<number, { kind: ShutdownTokenKind; label: string }>();

  private drainWaiters: Array<() => void> = [];

  get isOpen(): boolean {
    return this.open;
  }

  get outstanding(): number {
    return this.tokens.size;
  }

  outstandingByKind(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const { kind } of this.tokens.values()) out[kind] = (out[kind] ?? 0) + 1;
    return out;
  }

  /** Closed synchronously in shutdown phase ①. */
  close(): void {
    this.open = false;
  }

  /**
   * Acquires a token or throws `shutting_down`. Callers must release in
   * `finally`; an outer IPC token only covers its own callback, never work that
   * keeps running after the callback returns.
   */
  acquire(kind: ShutdownTokenKind, label: string): ShutdownToken {
    if (!this.open) throw new ShuttingDownError(label);
    this.seq += 1;
    const id = this.seq;
    this.tokens.set(id, { kind, label });
    let released = false;
    return {
      id,
      kind,
      label,
      release: () => {
        if (released) return;
        released = true;
        this.tokens.delete(id);
        if (this.tokens.size === 0) {
          const waiters = this.drainWaiters;
          this.drainWaiters = [];
          for (const w of waiters) w();
        }
      },
    };
  }

  /** Resolves true when every token drained inside the deadline. */
  async drain(deadlineMs: number, setTimer: typeof setTimeout = setTimeout): Promise<boolean> {
    if (this.tokens.size === 0) return true;
    return new Promise<boolean>((resolve) => {
      let settled = false;
      const timer = setTimer(() => {
        if (settled) return;
        settled = true;
        resolve(this.tokens.size === 0);
      }, deadlineMs);
      this.drainWaiters.push(() => {
        if (settled) return;
        settled = true;
        clearTimeout(timer as ReturnType<typeof setTimeout>);
        resolve(true);
      });
    });
  }

  /** Diagnostic snapshot for `store_close_deferred_to_process_exit`. */
  describeOutstanding(): string[] {
    return [...this.tokens.values()].map(({ kind, label }) => `${kind}:${label}`);
  }
}

/**
 * The only holder of the raw Electron `ipcMain`. Every channel registered
 * through it takes a gate token for the duration of the handler.
 */
export class ShutdownAwareIpcMain implements IpcHandleRegistrar {
  private readonly channels = new Set<string>();

  constructor(
    private readonly rawIpcMain: RawIpcMainLike,
    private readonly gate: DesktopShutdownGate,
    private readonly admitInvoke?: (event: IpcMainInvokeEvent) => void,
  ) {}

  /** Every registered channel, used by the contract test to prove coverage. */
  registeredChannels(): string[] {
    return [...this.channels].sort();
  }

  handle(channel: string, listener: IpcHandlerListener): void {
    if (this.channels.has(channel)) {
      throw new Error(`duplicate ipc channel registration: ${channel}`);
    }
    this.channels.add(channel);
    this.rawIpcMain.handle(channel, (async (event: IpcMainInvokeEvent, ...args: unknown[]) => {
      const token = this.gate.acquire('ipc', channel);
      try {
        if (this.admitInvoke && this.admitInvoke(event) !== undefined) {
          throw new Error('desktop_invoke_authority_invalid');
        }
        return await listener(event, ...args);
      } finally {
        token.release();
      }
    }) as never);
  }
}

```

## FULL desktop/renderer/src/hooks/useSkillReadonly.ts SHA256 7b7c3ebcda323b2d9cb3b45da20f5c595c0d85ccfa7a6c882da99eede2823997
```typescript
import { useCallback, useEffect, useRef, useState } from 'react';
import type { ZodType } from 'zod';
import { api } from '../api';
import { useLocale } from '../contexts/LocaleContext';
import { SKILL_LIST_OUTPUT_SCHEMA } from '../../../shared/skill-list-ipc-contract';
import { DIAGNOSTICS_OUTPUT_SCHEMAS } from '../../../shared/desktop-diagnostics-ipc-contract';
import type { DesktopSkillStats } from '../../../shared/desktop-diagnostics-ipc-contract';
import type { SkillListDto } from '../../../shared/skill-list-ipc-contract';
const readList = () => api.listSkills(), readStats = () => api.getSkillStats();
export function useDesktopReadonly<T>(read: () => Promise<T>, schema: ZodType<T>, catalogEvents: boolean) {
  const { locale } = useLocale();
  const [data, setData] = useState<T | null>(null), [failed, setFailed] = useState(false), [reading, setReading] = useState(true);
  type Waiter = { resolve(value: T): void; reject(error: unknown): void };
  type Owner = { active: boolean; busy: boolean; waiters: Waiter[] };
  const life = useRef<Owner | null>(null);
  const runRef = useRef<(owner: Owner, waiters: Waiter[]) => void>(() => {});
  const run = useCallback((owner: Owner, waiters: Waiter[]) => {
    owner.busy = true; setReading(true);
    void (async () => {
      try {
        const value = await read();
        if (!owner.active || life.current !== owner) throw Error('skill_readonly_lifetime_expired');
        const parsed = schema.safeParse(value);
        if (!parsed.success) throw Error('skill_readonly_projection_unavailable');
        setData(parsed.data); setFailed(false);
        for (const waiter of waiters) waiter.resolve(parsed.data);
      } catch (error) {
        if (owner.active && life.current === owner) setFailed(true);
        for (const waiter of waiters) waiter.reject(error);
      }
      finally {
        if (owner.active && life.current === owner) {
          owner.busy = false; setReading(false);
          if (owner.waiters.length) { const queued = owner.waiters.splice(0); runRef.current(owner, queued); }
        }
      }
    })();
  }, [read, schema]);
  runRef.current = run;
  const reload = useCallback((): Promise<T> => new Promise((resolve, reject) => {
    const owner = life.current;
    if (!owner?.active) { reject(Error('skill_readonly_lifetime_expired')); return; }
    const waiter = { resolve, reject };
    if (owner.busy) { owner.waiters.push(waiter); return; }
    runRef.current(owner, [waiter]);
  }), []);
  const refresh = useCallback(() => { void reload().catch(() => {}); }, [reload]);
  useEffect(() => {
    const owner: Owner = { active: true, busy: false, waiters: [] }; life.current = owner; refresh();
    const unsubscribe = catalogEvents ? api.onSkillsChanged?.(() => { if (owner.active && life.current === owner) refresh(); }) : undefined;
    return () => {
      owner.active = false;
      for (const waiter of owner.waiters.splice(0)) waiter.reject(Error('skill_readonly_lifetime_expired'));
      unsubscribe?.();
    };
  }, [locale, refresh, catalogEvents]);
  return { data, failed, reading, refresh, reload };
}
export function useSkillListReadonly() { return useDesktopReadonly<SkillListDto>(readList, SKILL_LIST_OUTPUT_SCHEMA, true); }
export function useSkillStatsReadonly() { return useDesktopReadonly<DesktopSkillStats[]>(readStats, DIAGNOSTICS_OUTPUT_SCHEMAS.getSkillStats, false); }

```
