import {app,BrowserWindow,ipcMain,screen,systemPreferences as actualPreferences} from 'electron';
import{readFileSync,existsSync,chmodSync}from'node:fs';import{writeFile}from'node:fs/promises';import{join,dirname}from'node:path';import{fileURLToPath}from'node:url';
import{ShutdownAwareIpcMain,DesktopShutdownGate}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import{isTrustedDesktopRendererUrl,buildBrowserWindowOptions}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import{createMeetingRecorderWindowController}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import{createMeetingAudioPermissionService}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-audio-permission.js";
import{registerMeetingReadonlyIpc}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-readonly-typed-ipc.js";
import{readMeetingAsrReadonly}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-readonly-data.js";
const root="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-meeting-readonly-ipc-7EGLiN",cache="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-meeting-readonly-ipc-7EGLiN/cache",rendererFile="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-meeting-readonly-ipc-7EGLiN/desktop/dist/renderer/index.html",__dirname=dirname(fileURLToPath(import.meta.url));
app.setPath('userData',join(root,'electron-user-data'));let mainWindow=null,meetingRecorderController=null,queries=0,asks=0,counts=0;
const systemPreferences={getMediaAccessStatus(type){queries++;return actualPreferences.getMediaAccessStatus(type)},askForMediaAccess(){asks++;throw Error('readonly_must_not_prompt')}};
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

const meetingAudioPermissionService = createMeetingAudioPermissionService({
    platform: process.platform,
    getMediaAccessStatus: (mediaType) => systemPreferences.getMediaAccessStatus(mediaType),
    askForMediaAccess: (mediaType) => systemPreferences.askForMediaAccess(mediaType),
});

const meetingReadonlyProducers = new Map([
    ['desktop:meeting:getMicrophonePermission', () => meetingAudioPermissionService.getStatus()],
    ['desktop:meeting:getAsrConfig', () => readMeetingAsrReadonly()],
    ['desktop:meeting:listModels', async () => { const { createMeetingModelService } = await import("file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-model-service.js"); return createMeetingModelService({ readonlyIoPolicy: 'truthful' }).listModels(); }],
]);

const gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];
const counted=new Map([...meetingReadonlyProducers].map(([channel,producer])=>[channel,(...args)=>{counts++;return producer(...args)}]));registerMeetingReadonlyIpc(ipc,counted);
const verify=(value,reason)=>{if(!value)throw Error(reason)};
const invoke=async(role,window)=>{for(const method of ['meetingGetMicrophonePermission','meetingGetAsrConfig','meetingListModels'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await writeFile(join(root,'config/config.json'),JSON.stringify({schemaVersion:2,providers:{},models:[],meeting:{asr:{defaultProvider:'aliyun-asr',aliyun:{apiKey:'owned-fake-key',baseUrl:'https://owned.invalid',model:'owned-model'}}}}));
const options=buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",{platform:process.platform});mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:"/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-meeting-readonly'});const recorder=BrowserWindow.getAllWindows().find(window=>meetingRecorderController.ownsWebContents(window.webContents));verify(!!recorder,'recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...options,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);const old=mainWindow;mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_read_failed');if(row.method==='meetingListModels')verify(row.reply.value.length===7&&row.reply.value.every(item=>item.runtimeAutoDownloadAllowed===false&&item.packageState==='missing'),'model_metadata_changed');if(row.method==='meetingGetAsrConfig')verify(row.reply.value.aliyun.configured&&JSON.stringify(row.reply).indexOf('owned-fake-key')<0,'credential_projection_failed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted');}
const malformed='owned-fake-credential-marker-asr';await writeFile(join(root,'config/config.json'),malformed);const badAsr=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.meetingGetAsrConfig().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');verify(!badAsr.ok&&readFileSync(join(root,'config/config.json'),'utf8')===malformed&&!existsSync(join(root,'config/config.json.bak')),'bad_config_repaired');verify(badAsr.error.includes('meeting_readonly_projection_unavailable')&&!badAsr.error.includes('owned-fake'),'parse_credential_fragment_leaked');results.push({role:'bad-config',method:'meetingGetAsrConfig',reply:badAsr});
chmodSync(cache,0);let badModels;try{badModels=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.meetingListModels().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');}finally{chmodSync(cache,0o700);}verify(!badModels.ok,'cache_access_false_missing');results.push({role:'owned-cache-access-denied',method:'meetingListModels',reply:badModels});
verify(gate.outstanding===0&&counts===11&&asks===0,'token_or_producer_or_prompt_leak');
await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/meeting-readonly3-20261012-recovery-r1/electron-meeting-probe-r2.json",JSON.stringify({actualElectron:true,actualExtractedMainAuthorizer:true,actualExtractedProductionProducerMap:true,actualExtractedPermissionDependencies:true,actualDarwinStatusQueries:queries,asks,actualTypedRegistrar:true,actualReadonlyFileHelpers:true,actualRecorderController:true,actualSandboxCjsPreload:true,actualOsPromptAcceptance:false,normalInstalledOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,ownedTemporaryRootOnly:true,results,counts,gateOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1)});