# 设计评审 r1 — meeting readonly3（P0/P1）

**结论：BLOCK_DESIGN**（3 个精确阻塞点；r2 各用一句钉死即可复审，不需要重写整体方案）

记录：按本 handoff 流程指定的评审模型标识为 GLM5.3；执行方 Qoder，只读评审，未改任何文件。

---

## 阻塞点（需 r2 钉死，勿由评审发明实现）

**P0-1｜readonly ASR config reader 的文件归属/依赖方向未决**
design-draft-r1.md:11 自身明文 “Decide how to share existing channel readonly primitives without making ASR depend on channel-row validation”——这是未做的决策。同句 “Core3 remain byteunchanged” 冻结 `loadConfig/saveConfig/normalizeConfig`（src/utils/config.ts:62,102），则新 helper 必须指定宿主文件与依赖方向；r2 需给出明确文件名 + 不依赖 channel-row 校验的边界，否则 RED 无处落笔。

**P0-2｜错误信封形状与行级/整体失败边界未定**
r1 只有语义分类（trueENOENT vs access/stat/read/directory），无具体错误码/DTO 形状。且现状任何 `statSync/readdirSync` 抛错使整个 `listModels` reject（meeting-model-service.ts:222,319,343）；r1 说 “all model rows” 保留，但**单行 stat 失败时是行级错误态还是整体 reject 未钉死**。“opt-in listing reader” 的挂点（service options 新字段 vs 独立函数）也未定形。

**P1-3｜config.json 真 ENOENT 的输出语义需一句钉死**
现状缺席→默认快照（config.ts:71 `cloneDefaultConfig`；characterization asr-default；DesktopSettings.tsx:397-419 首装渲染）。建议 r2 显式写 “真 ENOENT → 默认快照（保现状），访问/解析失败 → reject”，避免 “absent only true ENOENT” 被误读为缺席报错而改变首装行为。

---

## 已核实证据（关闭 r1 的开放普查，非阻塞）

- **三通道 raw 注册唯一**：ipc.ts:1815-1817（getStatus 直返）/1823-1827（loadConfig+快照）/1837-1840（listModels 直返）；grep 全 desktop/ 无第二注册点。
- **权限 owner**：ipc.ts:506-510（systemPreferences 注入）；`getStatus` 只读不 prompt（meeting-audio-permission.ts:35-38）；requestPermission 独立父变更（40-50）；非 darwin→unknown（31-36）。注意类型含 `'unsupported'`（line 1）但从未产生（13-28）——输出 schema 须容纳全枚举。
- **ASR 快照无凭据字符串**：meeting-asr-config.ts:76-95 仅布尔+endpoint/resourceId/baseUrl/model。
- **loadConfig 读路径 chmod/修复/默认**：config.ts:69-70,32（chmod）、84/90/95（backupAndRemove 写修复）、71/76-77（默认吞错）——r1 依据全部成立。
- **existsSync 掩盖访问失败**：meeting-model-service.ts:94,207,303；sha256 全文件同步读（89-91）；registry 7 行（107-171）。
- **UI 失败行为属实**：清空/置 null（KnowledgePage.tsx:641,705；DesktopSettings.tsx:418,430）；单动作队列（KnowledgePage.tsx:649,670；DesktopSettings.tsx:521,538）；requestMicrophonePermission 仅用户触发（KnowledgePage.tsx:1049-1050）。
- **getMicrophonePermission 零 renderer 消费者**：renderer grep 无调用；preload 暴露（preload.cjs:470；preload-api.ts:689,1962）；契约测试锁定通道（tests/main/meeting-ui-ipc.test.ts:30,121-122）。
- **VoiceSettings 非运行时消费者**：仅被导出（components/settings/index.ts:24），无任何导入/渲染点；其 catch-ignore（VoiceSettings.tsx:619）不在活图内。
- **模型服务兄弟调用者（r1 未点名，r2 应补）**：meeting-punctuation-service.ts:70、meeting-sherpa-onnx-transcriber.ts:42、meeting-local-transcriber.ts:37——opt-in reader 不得改动其默认路径。

## 保全核对

父变更（request/download/uninstall/save）不在范围；MainRecorder/5s/512MiB 等 ipc.ts:1852-1899 未触碰；无性能/超时/基线/源数声明；PR37 open、founder merge、full HEAD 未跑——与 preflight-r1.json 一致，均成立。

**下一步**：r2 钉死 P0-1/P0-2/P1-3 三点并点名三个兄弟文件后提交复审；随后按流程 supervisor 写 RED。