import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,realpathSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
const repo=process.cwd(), evidence=resolve(repo,'.artifacts/unfinished-closure-20261001/meeting-readonly3-20261012-recovery-r1');
const ts=(await import(pathToFileURL(join(repo,'desktop/node_modules/typescript/lib/typescript.js')).href)).default;
const selected={};
for(const file of ['main.ts','ipc.ts']) {
 const source=readFileSync(join(repo,'desktop/electron',file),'utf8'),ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true);
 const visit=node=>{if(ts.isFunctionDeclaration(node)&&node.name?.text==='authorizeDesktopInvoke')selected.authorizer=node.getText(ast);if(ts.isVariableStatement(node))for(const d of node.declarationList.declarations)if(['meetingAudioPermissionService','meetingReadonlyProducers'].includes(d.name.getText(ast)))selected[d.name.getText(ast)]=node.getText(ast);ts.forEachChild(node,visit);};visit(ast);
}
for(const key of ['authorizer','meetingAudioPermissionService','meetingReadonlyProducers'])if(!selected[key])throw Error('missing_actual_source_'+key);
const js=text=>ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
const root=realpathSync(mkdtempSync(join(tmpdir(),'xiaok-meeting-readonly-ipc-'))),dir=join(root,'desktop/dist/main/desktop/electron'),renderer=join(root,'desktop/dist/renderer/index.html'),cache=join(root,'cache');
for(const path of [dir,join(root,'desktop/dist/renderer'),join(root,'config'),cache])mkdirSync(path,{recursive:true});
writeFileSync(renderer,'<!doctype html><meta charset="utf-8"><title>Owned meeting readonly component probe</title>');
const module=p=>JSON.stringify(pathToFileURL(join(repo,'desktop/dist/main/desktop/electron',p+'.js')).href),preload=JSON.stringify(join(repo,'desktop/electron/preload.cjs'));
const producers=js(selected.meetingReadonlyProducers).replace("'./meeting-model-service.js'",module('meeting-model-service'));
const script=join(dir,'meeting-readonly-ipc.mjs');
const text=`import {app,BrowserWindow,ipcMain,screen,systemPreferences as actualPreferences} from 'electron';
import{readFileSync,existsSync,chmodSync}from'node:fs';import{writeFile}from'node:fs/promises';import{join,dirname}from'node:path';import{fileURLToPath}from'node:url';
import{ShutdownAwareIpcMain,DesktopShutdownGate}from ${module('shutdown-aware-ipc-main')};
import{isTrustedDesktopRendererUrl,buildBrowserWindowOptions}from ${module('security')};
import{createMeetingRecorderWindowController}from ${module('meeting-recorder-window')};
import{createMeetingAudioPermissionService}from ${module('meeting-audio-permission')};
import{registerMeetingReadonlyIpc}from ${module('meeting-readonly-typed-ipc')};
import{readMeetingAsrReadonly}from ${module('meeting-readonly-data')};
const root=${JSON.stringify(root)},cache=${JSON.stringify(cache)},rendererFile=${JSON.stringify(renderer)},__dirname=dirname(fileURLToPath(import.meta.url));
app.setPath('userData',join(root,'electron-user-data'));let mainWindow=null,meetingRecorderController=null,queries=0,asks=0,counts=0;
const systemPreferences={getMediaAccessStatus(type){queries++;return actualPreferences.getMediaAccessStatus(type)},askForMediaAccess(){asks++;throw Error('readonly_must_not_prompt')}};
${js(selected.authorizer)}
${js(selected.meetingAudioPermissionService)}
${producers}
const gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];
const counted=new Map([...meetingReadonlyProducers].map(([channel,producer])=>[channel,(...args)=>{counts++;return producer(...args)}]));registerMeetingReadonlyIpc(ipc,counted);
const verify=(value,reason)=>{if(!value)throw Error(reason)};
const invoke=async(role,window)=>{for(const method of ['meetingGetMicrophonePermission','meetingGetAsrConfig','meetingListModels'])results.push({role,method,reply:await window.webContents.executeJavaScript('window.xiaokDesktop.'+method+'().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))')});};
app.whenReady().then(async()=>{try{
await writeFile(join(root,'config/config.json'),JSON.stringify({schemaVersion:2,providers:{},models:[],meeting:{asr:{defaultProvider:'aliyun-asr',aliyun:{apiKey:'owned-fake-key',baseUrl:'https://owned.invalid',model:'owned-model'}}}}));
const options=buildBrowserWindowOptions(${preload},{platform:process.platform});mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);
meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:${preload},rendererFile,screen});
await invoke('main',mainWindow);await meetingRecorderController.open({collectionId:'owned-meeting-readonly'});const recorder=BrowserWindow.getAllWindows().find(window=>meetingRecorderController.ownsWebContents(window.webContents));verify(!!recorder,'recorder_missing');await invoke('recorder',recorder);
const unknown=new BrowserWindow({...options,show:false});await unknown.loadFile(rendererFile);await invoke('unknown-same-url',unknown);const old=mainWindow;mainWindow=new BrowserWindow({...options,show:false});await mainWindow.loadFile(rendererFile);await invoke('old-main',old);await invoke('replacement-main',mainWindow);
for(const row of results){if(['main','recorder','replacement-main'].includes(row.role)){verify(row.reply.ok,'owned_read_failed');if(row.method==='meetingListModels')verify(row.reply.value.length===7&&row.reply.value.every(item=>item.runtimeAutoDownloadAllowed===false&&item.packageState==='missing'),'model_metadata_changed');if(row.method==='meetingGetAsrConfig')verify(row.reply.value.aliyun.configured&&JSON.stringify(row.reply).indexOf('owned-fake-key')<0,'credential_projection_failed');}else verify(!row.reply.ok&&row.reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted');}
const malformed='owned-fake-credential-marker-asr';await writeFile(join(root,'config/config.json'),malformed);const badAsr=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.meetingGetAsrConfig().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');verify(!badAsr.ok&&readFileSync(join(root,'config/config.json'),'utf8')===malformed&&!existsSync(join(root,'config/config.json.bak')),'bad_config_repaired');verify(badAsr.error.includes('meeting_readonly_projection_unavailable')&&!badAsr.error.includes('owned-fake'),'parse_credential_fragment_leaked');results.push({role:'bad-config',method:'meetingGetAsrConfig',reply:badAsr});
chmodSync(cache,0);let badModels;try{badModels=await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.meetingListModels().then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))');}finally{chmodSync(cache,0o700);}verify(!badModels.ok,'cache_access_false_missing');results.push({role:'owned-cache-access-denied',method:'meetingListModels',reply:badModels});
verify(gate.outstanding===0&&counts===11&&asks===0,'token_or_producer_or_prompt_leak');
await writeFile(${JSON.stringify(join(evidence,'electron-meeting-probe-r2.json'))},JSON.stringify({actualElectron:true,actualExtractedMainAuthorizer:true,actualExtractedProductionProducerMap:true,actualExtractedPermissionDependencies:true,actualDarwinStatusQueries:queries,asks,actualTypedRegistrar:true,actualReadonlyFileHelpers:true,actualRecorderController:true,actualSandboxCjsPreload:true,actualOsPromptAcceptance:false,normalInstalledOrWholeUiAccepted:false,protectedNativeAuthorityClaim:false,ownedTemporaryRootOnly:true,results,counts,gateOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.quit();
}catch(error){console.error(error);meetingRecorderController?.dispose();for(const window of BrowserWindow.getAllWindows())window.destroy();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1)});`;
writeFileSync(script,text);writeFileSync(join(evidence,'electron-probe-script-r2.mjs'),text);writeFileSync(join(evidence,'electron-probe-script-r2.json'),JSON.stringify({root,script,renderer,cache,selected,limits:'Source-extracted component IPC; not full startup, installed app, native protected authority, OS prompt or whole UI'},null,2));console.log(JSON.stringify({root,script}));
