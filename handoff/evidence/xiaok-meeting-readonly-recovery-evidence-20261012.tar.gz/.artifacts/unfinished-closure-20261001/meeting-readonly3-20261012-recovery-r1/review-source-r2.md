# Actual final meeting3 source changes

All tracked changes are the complete git diff against b9a54811bed2639d4ed2d988ec53c192aae74f73; every new file is complete. Actual function excerpts have file SHA and source lines. Unchanged surrounding source can be read at original paths if needed. No approval claimed for historical whole PR.

## Complete tracked diff
```diff
diff --git a/desktop/electron/ipc-runtime.ts b/desktop/electron/ipc-runtime.ts
index 5d01b18d..789d1631 100644
--- a/desktop/electron/ipc-runtime.ts
+++ b/desktop/electron/ipc-runtime.ts
@@ -27,7 +27,7 @@ export interface IpcSchemaEntry {
   payloadMode: 'single' | 'tuple';
   inputStage: 'beforeHandler' | 'afterHostAuthorization';
   wireInput?: ZodSchema;
-  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32;
+  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
   riskTags: RiskTag[];
 }
 
@@ -62,7 +62,7 @@ export interface IpcRegistrationOptions<I, O> {
   input: ZodSchema<I>;
   output: ZodSchema<O>;
   sourceFile: string;
-  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32;
+  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
   riskTags?: RiskTag[];
   handler: (input: I, event: IpcMainInvokeEvent, helpers?: IpcStageHelpers<I>) => Promise<O>;
   /** Main-owned adapters preserve domain error envelopes without granting caller authority. */
diff --git a/desktop/electron/ipc.ts b/desktop/electron/ipc.ts
index b0b34f7f..fe4c2e7d 100644
--- a/desktop/electron/ipc.ts
+++ b/desktop/electron/ipc.ts
@@ -1,3 +1,5 @@
+import { registerMeetingReadonlyIpc } from './meeting-readonly-typed-ipc.js';
+import { readMeetingAsrReadonly } from './meeting-readonly-data.js';
 import { registerChannelMcpReadonlyIpc } from './channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from './skill-list-typed-ipc.js';
 import { captureIpcData } from './ipc-data-snapshot.js';
@@ -1812,20 +1814,10 @@ export async function registerDesktopIpc(
     return result.filePaths[0] ?? null;
   });
 
-  ipcMain.handle('desktop:meeting:getMicrophonePermission', async () => (
-    meetingAudioPermissionService.getStatus()
-  ));
-
   ipcMain.handle('desktop:meeting:requestMicrophonePermission', async () => (
     meetingAudioPermissionService.requestPermission()
   ));
 
-  ipcMain.handle('desktop:meeting:getAsrConfig', async () => {
-    const { loadConfig } = await import('../../src/utils/config.js');
-    const { createMeetingAsrConfigSnapshot } = await import('./meeting-asr-config.js');
-    return createMeetingAsrConfigSnapshot(await loadConfig());
-  });
-
   ipcMain.handle('desktop:meeting:saveAsrConfig', async (_event, input) => {
     const { loadConfig, saveConfig } = await import('../../src/utils/config.js');
     const { applyMeetingAsrConfigUpdate, createMeetingAsrConfigSnapshot } = await import('./meeting-asr-config.js');
@@ -1834,10 +1826,12 @@ export async function registerDesktopIpc(
     return createMeetingAsrConfigSnapshot(config);
   });
 
-  ipcMain.handle('desktop:meeting:listModels', async () => {
-    const { createMeetingModelService } = await import('./meeting-model-service.js');
-    return createMeetingModelService().listModels();
-  });
+  const meetingReadonlyProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:meeting:getMicrophonePermission', () => meetingAudioPermissionService.getStatus()],
+    ['desktop:meeting:getAsrConfig', () => readMeetingAsrReadonly()],
+    ['desktop:meeting:listModels', async () => { const { createMeetingModelService } = await import('./meeting-model-service.js'); return createMeetingModelService({ readonlyIoPolicy: 'truthful' }).listModels(); }],
+  ]);
+  registerMeetingReadonlyIpc(ipcMain, meetingReadonlyProducers);
 
   ipcMain.handle('desktop:meeting:downloadModel', async (_event, modelId: string) => {
     const { createMeetingModelService } = await import('./meeting-model-service.js');
diff --git a/desktop/electron/meeting-model-service.ts b/desktop/electron/meeting-model-service.ts
index c7e1b083..2a95dbbf 100644
--- a/desktop/electron/meeting-model-service.ts
+++ b/desktop/electron/meeting-model-service.ts
@@ -6,7 +6,7 @@ import { get as httpGet } from 'node:http';
 import { get as httpsGet } from 'node:https';
 import { homedir } from 'node:os';
 import { dirname, join } from 'node:path';
-import { promisify } from 'node:util';
+import { promisify, types as nodeTypes } from 'node:util';
 
 export type MeetingModelCheckReason = 'ready' | 'missing' | 'size_mismatch' | 'hash_mismatch';
 export type MeetingModelDownloadStatus = 'downloaded' | 'not_downloaded' | 'incomplete' | 'corrupt';
@@ -79,6 +79,7 @@ const MEETING_MODEL_DOWNLOAD_MAX_ATTEMPTS = 20;
 const execFileAsync = promisify(execFileCallback);
 
 export interface MeetingModelServiceOptions {
+  readonlyIoPolicy?: 'truthful';
   cacheDir?: string;
   env?: NodeJS.ProcessEnv;
   models?: readonly MeetingModelDefinition[];
@@ -185,6 +186,11 @@ export function formatMeetingModelSize(bytes: number): string {
   return `${(bytes / 1_000_000_000).toFixed(1)} GB`;
 }
 
+function truthfulModelPathExists(path: string): boolean {
+  try { statSync(path); return true; }
+  catch(error) { if(error && typeof error==='object' && !nodeTypes.isProxy(error) && Object.getOwnPropertyDescriptor(error,'code')?.value==='ENOENT')return false;throw error; }
+}
+
 export function createMeetingModelService(options: MeetingModelServiceOptions = {}): MeetingModelService {
   const env = options.env ?? process.env;
   const cacheDir = options.cacheDir ?? resolveMeetingWhisperCacheDir(env);
@@ -198,13 +204,14 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
     return model;
   }
 
-  function getModelInfo(model: MeetingModelDefinition): MeetingModelInfo {
+  function getModelInfo(model: MeetingModelDefinition, truthful = false): MeetingModelInfo {
+    const pathExists = truthful ? truthfulModelPathExists : existsSync;
     const modelPath = join(cacheDir, model.fileName);
     const baseInfo = buildModelPackageInfo(model);
     if ((model.packageType ?? 'single-file') === 'directory') {
-      return getDirectoryModelInfo(model, modelPath, baseInfo);
+      return getDirectoryModelInfo(model, modelPath, baseInfo, pathExists);
     }
-    if (!existsSync(modelPath)) {
+    if (!pathExists(modelPath)) {
       return {
         id: model.id,
         fileName: model.fileName,
@@ -220,11 +227,18 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
     }
 
     const localSizeBytes = statSync(modelPath).size;
-    const check = checkMeetingModelFile({
-      path: modelPath,
-      expectedSizeBytes: model.expectedSizeBytes,
-      expectedSha256: model.expectedSha256,
-    });
+    // The truthful reader must not re-enter existsSync, which hides access errors.
+    const check: MeetingModelCheckResult = truthful
+      ? localSizeBytes !== model.expectedSizeBytes
+        ? { ready: false, reason: 'size_mismatch' }
+        : sha256File(modelPath) !== model.expectedSha256
+          ? { ready: false, reason: 'hash_mismatch' }
+          : { ready: true, reason: 'ready' }
+      : checkMeetingModelFile({
+        path: modelPath,
+        expectedSizeBytes: model.expectedSizeBytes,
+        expectedSha256: model.expectedSha256,
+      });
     const downloaded = check.ready;
     const status = downloaded ? 'downloaded' : check.reason === 'hash_mismatch' ? 'corrupt' : 'incomplete';
     const packageState: MeetingModelPackageState = downloaded
@@ -251,7 +265,7 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
   return {
     checkModelFile: checkMeetingModelFile,
     listModels() {
-      return models.map(getModelInfo);
+      return models.map(model => getModelInfo(model, options.readonlyIoPolicy === 'truthful'));
     },
     async downloadModel(modelId) {
       const model = findModel(modelId);
@@ -299,8 +313,9 @@ function getDirectoryModelInfo(
     MeetingModelInfo,
     'engineId' | 'packageId' | 'packageType' | 'manifestTrusted' | 'runtimeAutoDownloadAllowed' | 'capability'
   >,
+  pathExists: (path: string) => boolean = existsSync,
 ): MeetingModelInfo {
-  if (!existsSync(modelPath)) {
+  if (!pathExists(modelPath)) {
     return {
       id: model.id,
       fileName: model.fileName,
@@ -315,11 +330,11 @@ function getDirectoryModelInfo(
     };
   }
 
-  const localSizeBytes = calculateLocalPackageSize(modelPath);
+  const localSizeBytes = calculateLocalPackageSize(modelPath, pathExists);
   const stat = statSync(modelPath);
   const requiredFiles = model.requiredFiles ?? [];
   const hasRequiredFiles = stat.isDirectory()
-    && requiredFiles.every(requiredFile => existsSync(join(modelPath, requiredFile)));
+    && requiredFiles.every(requiredFile => pathExists(join(modelPath, requiredFile)));
   return {
     id: model.id,
     fileName: model.fileName,
@@ -336,13 +351,13 @@ function getDirectoryModelInfo(
   };
 }
 
-function calculateLocalPackageSize(path: string): number {
-  if (!existsSync(path)) return 0;
+function calculateLocalPackageSize(path: string, pathExists: (path: string) => boolean = existsSync): number {
+  if (!pathExists(path)) return 0;
   const stat = statSync(path);
   if (!stat.isDirectory()) return stat.size;
   return readdirSync(path, { withFileTypes: true }).reduce((total, entry) => {
     const childPath = join(path, entry.name);
-    if (entry.isDirectory()) return total + calculateLocalPackageSize(childPath);
+    if (entry.isDirectory()) return total + calculateLocalPackageSize(childPath, pathExists);
     if (entry.isFile()) return total + statSync(childPath).size;
     return total;
   }, 0);
diff --git a/desktop/electron/preload-api.ts b/desktop/electron/preload-api.ts
index d3fad701..d1292e8a 100644
--- a/desktop/electron/preload-api.ts
+++ b/desktop/electron/preload-api.ts
@@ -1,3 +1,4 @@
+import type { MeetingReadonlyPermission, MeetingReadonlyAsr, MeetingReadonlyModels } from '../shared/meeting-readonly-ipc-contract.js';
 import type { ChannelReadonlyView, McpInstallReadonlyView } from '../shared/channel-mcp-readonly-ipc-contract.js';
 import type { SkillListDto } from '../shared/skill-list-ipc-contract.js';
 import type { AutomationConfigDto, AutomationOverviewDto } from '../shared/automation-config-ipc-contract.js';
@@ -1395,11 +1396,11 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   kbSearch(input?: KnowledgeSearchInput | null): Promise<KnowledgeSearchResultDto[]>;
   kbPickFiles(): Promise<string[]>;
   meetingPickAudioFile(): Promise<string | null>;
-  meetingGetMicrophonePermission(): Promise<unknown>;
+  meetingGetMicrophonePermission(): Promise<MeetingReadonlyPermission>;
   meetingRequestMicrophonePermission(): Promise<unknown>;
-  meetingGetAsrConfig(): Promise<MeetingAsrConfigSnapshot>;
+  meetingGetAsrConfig(): Promise<MeetingReadonlyAsr>;
   meetingSaveAsrConfig(input: MeetingSaveAsrConfigInput): Promise<MeetingAsrConfigSnapshot>;
-  meetingListModels(): Promise<unknown[]>;
+  meetingListModels(): Promise<MeetingReadonlyModels>;
   meetingDownloadModel(modelId: string): Promise<unknown>;
   meetingUninstallModel(modelId: string): Promise<unknown>;
   meetingSaveRecordedAudio(input: unknown): Promise<unknown>;
@@ -1959,11 +1960,11 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     kbSearch: (input) => ipcRenderer.invoke('desktop:kb:search', input) as Promise<KnowledgeSearchResultDto[]>,
     kbPickFiles: () => ipcRenderer.invoke('desktop:kb:pickFiles') as Promise<string[]>,
     meetingPickAudioFile: () => ipcRenderer.invoke('desktop:meeting:pickAudioFile') as Promise<string | null>,
-    meetingGetMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:getMicrophonePermission') as Promise<unknown>,
+    meetingGetMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:getMicrophonePermission') as Promise<MeetingReadonlyPermission>,
     meetingRequestMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:requestMicrophonePermission') as Promise<unknown>,
-    meetingGetAsrConfig: () => ipcRenderer.invoke('desktop:meeting:getAsrConfig') as Promise<MeetingAsrConfigSnapshot>,
+    meetingGetAsrConfig: () => ipcRenderer.invoke('desktop:meeting:getAsrConfig') as Promise<MeetingReadonlyAsr>,
     meetingSaveAsrConfig: (input) => ipcRenderer.invoke('desktop:meeting:saveAsrConfig', input) as Promise<MeetingAsrConfigSnapshot>,
-    meetingListModels: () => ipcRenderer.invoke('desktop:meeting:listModels') as Promise<unknown[]>,
+    meetingListModels: () => ipcRenderer.invoke('desktop:meeting:listModels') as Promise<MeetingReadonlyModels>,
     meetingDownloadModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:downloadModel', modelId) as Promise<unknown>,
     meetingUninstallModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:uninstallModel', modelId) as Promise<unknown>,
     meetingSaveRecordedAudio: (input) => ipcRenderer.invoke('desktop:meeting:saveRecordedAudio', input) as Promise<unknown>,
diff --git a/desktop/renderer/src/components/DesktopSettings.tsx b/desktop/renderer/src/components/DesktopSettings.tsx
index db5a93ba..8af02990 100644
--- a/desktop/renderer/src/components/DesktopSettings.tsx
+++ b/desktop/renderer/src/components/DesktopSettings.tsx
@@ -1,3 +1,4 @@
+import { useMeetingModelsReadonly, useMeetingAsrReadonly } from '../hooks/useMeetingReadonly';
 import { useChannelReadonly } from '../hooks/useChannelReadonly';
 import { MCP_INSTALLS_READONLY_OUTPUT_SCHEMA } from '../../../shared/channel-mcp-readonly-ipc-contract';
 import { useSkillListReadonly, useSkillStatsReadonly } from '../hooks/useSkillReadonly';
@@ -348,7 +349,8 @@ function VoicePane() {
   const [engine, setEngine] = useState<MeetingTranscriberEngine>(readStoredMeetingTranscriberEngine);
   const [model, setModel] = useState<MeetingTranscriberModel>(() => readStoredMeetingTranscriberModel(readStoredMeetingTranscriberEngine()));
   const [language, setLanguage] = useState<MeetingTranscriberLanguage>(readStoredMeetingTranscriberLanguage);
-  const [asrConfig, setAsrConfig] = useState<MeetingAsrConfigSnapshot | null>(null);
+  const modelFacts = useMeetingModelsReadonly(), asrFacts = useMeetingAsrReadonly();
+  const asrConfig = asrFacts.data;
   const [asrDraft, setAsrDraft] = useState({
     volcAppKey: '',
     volcAccessKey: '',
@@ -360,8 +362,8 @@ function VoicePane() {
   const [saving, setSaving] = useState(false);
   const [saved, setSaved] = useState(false);
   const [saveError, setSaveError] = useState('');
-  const [modelStatuses, setModelStatuses] = useState<MeetingModelStatusSnapshot[]>([]);
-  const [modelStatusesLoading, setModelStatusesLoading] = useState(false);
+  const modelStatuses = modelFacts.data ?? [];
+  const modelStatusesLoading = modelFacts.reading;
   const [modelStatusesError, setModelStatusesError] = useState('');
   const [modelAction, setModelAction] = useState<MeetingModelActionState | null>(null);
 
@@ -394,11 +396,12 @@ function VoicePane() {
     },
   ].filter(group => group.models.length > 0);
 
-  const loadMeetingAsrConfig = useCallback(async () => {
-    if (!desktop?.meetingGetAsrConfig) return;
-    try {
-      const snapshot = await desktop.meetingGetAsrConfig() as MeetingAsrConfigSnapshot;
-      setAsrConfig(snapshot);
+  const loadMeetingModelStatuses = useCallback(async () => {
+    await modelFacts.reload().catch(() => {});
+  }, [modelFacts.reload]);
+  useEffect(() => {
+    const snapshot = asrFacts.data;
+    if (!snapshot) return;
       setAsrDraft(prev => ({
         ...prev,
         volcEndpoint: snapshot.volcengine?.endpoint ?? '',
@@ -414,30 +417,7 @@ function VoicePane() {
       setEngine(nextEngine);
       setModel(nextModel);
       setLanguage(nextLanguage);
-    } catch {
-      setAsrConfig(null);
-    }
-  }, [desktop]);
-
-  const loadMeetingModelStatuses = useCallback(async () => {
-    if (!desktop?.meetingListModels) return;
-    setModelStatusesLoading(true);
-    setModelStatusesError('');
-    try {
-      const result = await desktop.meetingListModels();
-      setModelStatuses(normalizeMeetingModelStatuses(result));
-    } catch (error) {
-      setModelStatuses([]);
-      setModelStatusesError(t.knowledge.meetingModelStatusLoadFailed(error instanceof Error ? error.message : 'unknown'));
-    } finally {
-      setModelStatusesLoading(false);
-    }
-  }, [desktop, t]);
-
-  useEffect(() => {
-    void loadMeetingAsrConfig();
-    void loadMeetingModelStatuses();
-  }, [loadMeetingAsrConfig, loadMeetingModelStatuses]);
+  }, [asrFacts.data]);
 
   const persistTranscriberChoice = (nextEngine: MeetingTranscriberEngine, nextModel: MeetingTranscriberModel, nextLanguage = language) => {
     try {
@@ -499,7 +479,7 @@ function VoicePane() {
         : { defaultProvider: engine };
     try {
       const snapshot = await desktop.meetingSaveAsrConfig(input) as MeetingAsrConfigSnapshot;
-      setAsrConfig(snapshot);
+      await asrFacts.reload().catch(() => {});
       setAsrDraft(prev => ({
         ...prev,
         volcAppKey: '',
@@ -553,7 +533,7 @@ function VoicePane() {
 
   const renderProviderStatus = (configured?: boolean) => (
     <span className={`rounded-full border px-2 py-0.5 text-[11px] ${configured ? 'border-green-200 bg-green-50 text-green-700' : 'border-[var(--c-border)] bg-[var(--c-bg-page)] text-[var(--c-text-tertiary)]'}`}>
-      {configured ? ds.meetingAsrConfigured : ds.meetingAsrNotConfigured}
+      {asrConfig === null ? t.meetingAsrReadonlyUnknown : configured ? ds.meetingAsrConfigured : ds.meetingAsrNotConfigured}
     </span>
   );
 
@@ -642,6 +622,9 @@ function VoicePane() {
 
   return (
     <div className="space-y-6">
+      {modelFacts.failed && <p role="alert">{t.meetingModelsReadonlyUnavailable}</p>}
+      {asrFacts.failed && <p role="alert">{t.meetingAsrReadonlyUnavailable}</p>}
+      <button type="button" onClick={() => { modelFacts.refresh(); asrFacts.refresh(); }}>{t.desktopReadonlyRetry}</button>
       <Section>
         <SectionHeader icon={Mic}>{ds.meetingRecordingSettingsTitle}</SectionHeader>
         <p className="mb-4 text-sm leading-6 text-[var(--c-text-secondary)]">{ds.meetingRecordingSettingsDesc}</p>
@@ -699,9 +682,8 @@ function VoicePane() {
             <p className="text-sm text-[var(--c-text-secondary)]">{t.knowledge.meetingModelDownloadStatusTitle}</p>
             {modelStatusesLoading && <span className="text-xs text-[var(--c-text-tertiary)]">{t.knowledge.meetingModelStatusLoading}</span>}
           </div>
-          {modelStatusesError ? (
-            <p className="text-xs leading-5 text-red-600">{modelStatusesError}</p>
-          ) : groupedModelStatuses.length > 0 ? (
+          {modelStatusesError && <p className="text-xs leading-5 text-red-600">{modelStatusesError}</p>}
+          {groupedModelStatuses.length > 0 ? (
             <div className="space-y-4">
               {groupedModelStatuses.map(group => (
                 <div key={group.id} className="space-y-2">
@@ -711,7 +693,7 @@ function VoicePane() {
               ))}
             </div>
           ) : (
-            <p className="text-xs leading-5 text-[var(--c-text-tertiary)]">{t.knowledge.meetingModelStatusUnavailable}</p>
+            <p className="text-xs leading-5 text-[var(--c-text-tertiary)]">{modelFacts.data === null ? t.meetingModelsReadonlyUnknown : t.knowledge.meetingModelStatusUnavailable}</p>
           )}
         </Card>
       </Section>
diff --git a/desktop/renderer/src/locales/en.ts b/desktop/renderer/src/locales/en.ts
index c71df7c2..e7871ea1 100644
--- a/desktop/renderer/src/locales/en.ts
+++ b/desktop/renderer/src/locales/en.ts
@@ -3042,6 +3042,10 @@ export const en: LocaleStrings = {
   skillsReadonlyListFailed: 'Unable to read skills. Retry.',
   skillsReadonlyStatsFailed: 'Unable to read skill statistics. Retry.',
   skillsReadonlyRetry: 'Refresh skill information',
+  meetingModelsReadonlyUnknown: 'Meeting model information unknown',
+  meetingModelsReadonlyUnavailable: 'Unable to read meeting models',
+  meetingAsrReadonlyUnknown: 'Speech configuration unknown',
+  meetingAsrReadonlyUnavailable: 'Unable to read speech configuration',
   channelReadonlyUnknown: 'Channel information unknown',
   channelReadonlyUnavailable: 'Unable to read channels',
   mcpInstallsReadonlyUnknown: 'MCP installation information unknown',
diff --git a/desktop/renderer/src/locales/index.ts b/desktop/renderer/src/locales/index.ts
index 5ec3541e..1ea700d4 100644
--- a/desktop/renderer/src/locales/index.ts
+++ b/desktop/renderer/src/locales/index.ts
@@ -2929,6 +2929,10 @@ export interface LocaleStrings {
   skillsReadonlyListFailed: string;
   skillsReadonlyStatsFailed: string;
   skillsReadonlyRetry: string;
+  meetingModelsReadonlyUnknown: string;
+  meetingModelsReadonlyUnavailable: string;
+  meetingAsrReadonlyUnknown: string;
+  meetingAsrReadonlyUnavailable: string;
   channelReadonlyUnknown: string;
   channelReadonlyUnavailable: string;
   mcpInstallsReadonlyUnknown: string;
diff --git a/desktop/renderer/src/locales/zh.ts b/desktop/renderer/src/locales/zh.ts
index 20c65097..0b9cfa90 100644
--- a/desktop/renderer/src/locales/zh.ts
+++ b/desktop/renderer/src/locales/zh.ts
@@ -3022,6 +3022,10 @@ export const zh: LocaleStrings = {
   skillsReadonlyListFailed: '无法读取技能列表。请重试。',
   skillsReadonlyStatsFailed: '无法读取技能统计。请重试。',
   skillsReadonlyRetry: '刷新技能信息',
+  meetingModelsReadonlyUnknown: '\u4f1a\u8bae\u6a21\u578b\u4fe1\u606f\u672a\u77e5',
+  meetingModelsReadonlyUnavailable: '\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b',
+  meetingAsrReadonlyUnknown: '\u8bed\u97f3\u914d\u7f6e\u672a\u77e5',
+  meetingAsrReadonlyUnavailable: '\u65e0\u6cd5\u8bfb\u53d6\u8bed\u97f3\u914d\u7f6e',
   channelReadonlyUnknown: '通道信息未知',
   channelReadonlyUnavailable: '无法读取消息通道',
   mcpInstallsReadonlyUnknown: 'MCP 安装信息未知',
diff --git a/desktop/tests/main/ipc-native-promise-sibling.test.ts b/desktop/tests/main/ipc-native-promise-sibling.test.ts
index 9d893d75..499146ad 100644
--- a/desktop/tests/main/ipc-native-promise-sibling.test.ts
+++ b/desktop/tests/main/ipc-native-promise-sibling.test.ts
@@ -1,3 +1,4 @@
+import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 // @vitest-environment node
 import {it,expect} from 'vitest';
@@ -14,6 +15,10 @@ import {registerPrinciplesIpc} from '../../electron/principles-typed-ipc.ts';
 import {registerSkillListIpc} from '../../electron/skill-list-typed-ipc.ts';
 import {registerDiagnosticsIpc} from '../../electron/diagnostics-typed-ipc.ts';
 const cases=[
+{name:'meetingpermission',channel:'desktop:meeting:getMicrophonePermission',args:[],error:'meeting_readonly_projection_unavailable',register:(ipc:IpcHandleRegistrar,produce:()=>Promise<unknown>)=>registerMeetingReadonlyIpc(ipc,new Map([['desktop:meeting:getMicrophonePermission',produce]]))},
+{name:'meetingmodels',channel:'desktop:meeting:listModels',args:[],error:'meeting_readonly_projection_unavailable',register:(ipc:IpcHandleRegistrar,produce:()=>Promise<unknown>)=>registerMeetingReadonlyIpc(ipc,new Map([['desktop:meeting:listModels',produce]]))},
+{name:'meetingasr',channel:'desktop:meeting:getAsrConfig',args:[],error:'meeting_readonly_projection_unavailable',register:(ipc:IpcHandleRegistrar,produce:()=>Promise<unknown>)=>registerMeetingReadonlyIpc(ipc,new Map([['desktop:meeting:getAsrConfig',produce]]))},
+
 {name:'channelsreadonly',channel:'desktop:listChannels',args:[],error:'channel_mcp_projection_unavailable',register:(ipc:IpcHandleRegistrar,produce:()=>Promise<unknown>)=>registerChannelMcpReadonlyIpc(ipc,new Map([['desktop:listChannels',produce]]))},
 {name:'mcplistreadonly',channel:'desktop:listMCPInstalls',args:[],error:'channel_mcp_projection_unavailable',register:(ipc:IpcHandleRegistrar,produce:()=>Promise<unknown>)=>registerChannelMcpReadonlyIpc(ipc,new Map([['desktop:listMCPInstalls',produce]]))},
 {name:'skills',channel:'desktop:listSkills',args:[],error:'skill_list_projection_unavailable',register:(ipc:IpcHandleRegistrar,produce:()=>Promise<unknown>)=>registerSkillListIpc(ipc,new Map([['desktop:listSkills',produce]]))},
@@ -39,7 +44,7 @@ expect(calls).toBe(1);expect(reads).toBe(0);
 if(c.name==='room')expect(reply).toEqual({ok:false,code:c.error});else expect((failure as Error)?.message).toBe(c.error);
 });
 
-const normal:Record<string,unknown>={channelsreadonly:[],mcplistreadonly:[],skills:[],smallconfig:{enabled:false},thread:{gtdEnabled:false,inbox:[],todo:[],waiting:[],someday:[],archived:[],pinned:[]},team:{planId:'p',projectId:'owned',projectRevision:0,outcome:'no_change',summary:'existing',items:[]},projectagent:{agentId:'owned',runtimeType:null,healthy:false,callability:'unavailable',durationMs:0},assistant:{profile:{id:'default-personal-assistant',status:'needs_consent',locale:'zh',timeZone:'UTC',eveningTime:'18:00',morningTime:'08:00',workdays:[],quietHours:{start:'23:00',end:'07:00'},dataScopes:[],createdAt:1,updatedAt:1},suggestions:[],pendingCandidateCount:0,candidates:[]},room:{ok:true,rooms:[]},loop:[],model:{configPath:'owned',defaultProvider:'p',defaultModelId:'m',providers:[],models:[],providerProfiles:[]},principles:[],diagnostics:[]};
+const normal:Record<string,unknown>={meetingpermission:{status:'unsupported'},meetingmodels:[],meetingasr:{defaultProvider:'whisper',volcengine:{configured:false,appKeyConfigured:false,accessKeyConfigured:false,resourceId:'owned'},aliyun:{configured:false,apiKeyConfigured:false,baseUrl:'owned',model:'owned'}},channelsreadonly:[],mcplistreadonly:[],skills:[],smallconfig:{enabled:false},thread:{gtdEnabled:false,inbox:[],todo:[],waiting:[],someday:[],archived:[],pinned:[]},team:{planId:'p',projectId:'owned',projectRevision:0,outcome:'no_change',summary:'existing',items:[]},projectagent:{agentId:'owned',runtimeType:null,healthy:false,callability:'unavailable',durationMs:0},assistant:{profile:{id:'default-personal-assistant',status:'needs_consent',locale:'zh',timeZone:'UTC',eveningTime:'18:00',morningTime:'08:00',workdays:[],quietHours:{start:'23:00',end:'07:00'},dataScopes:[],createdAt:1,updatedAt:1},suggestions:[],pendingCandidateCount:0,candidates:[]},room:{ok:true,rooms:[]},loop:[],model:{configPath:'owned',defaultProvider:'p',defaultModelId:'m',providers:[],models:[],providerProfiles:[]},principles:[],diagnostics:[]};
 for(const c of cases)for(const kind of ['normal','ownThen','ownConstructor','rejection'])it(c.name+' preserves '+kind+' original promise behavior without reading then',async()=>{
  let calls=0,reads=0;const business=Error('actual-producer-business-error');const value=normal[c.name];const raw=kind==='rejection'?Promise.reject(business):Promise.resolve(value);
  if(kind==='ownThen')Object.defineProperty(raw,'then',{configurable:true,get(){reads++;throw Error('own then executed')}});
diff --git a/desktop/tests/main/ipc-schema-coverage.test.ts b/desktop/tests/main/ipc-schema-coverage.test.ts
index d6f1e756..bdd51a18 100644
--- a/desktop/tests/main/ipc-schema-coverage.test.ts
+++ b/desktop/tests/main/ipc-schema-coverage.test.ts
@@ -1,3 +1,4 @@
+import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from '../../electron/skill-list-typed-ipc.js';
 import { registerAutomationConfigIpc } from '../../electron/automation-config-typed-ipc.js';
@@ -22,6 +23,7 @@ registerMobileSignInIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerAutomationConfigIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerSkillListIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerChannelMcpReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
+registerMeetingReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerServiceControlIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerMobileReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerPluginCatalogIpc({handle:channel=>{currentViewChannels.push(channel);}});
diff --git a/desktop/tests/main/meeting-punctuation-worker.test.ts b/desktop/tests/main/meeting-punctuation-worker.test.ts
index 2bcb18c9..5ead3077 100644
--- a/desktop/tests/main/meeting-punctuation-worker.test.ts
+++ b/desktop/tests/main/meeting-punctuation-worker.test.ts
@@ -4,7 +4,7 @@ import { runPunctuationWorkerRequest } from '../../electron/meeting-punctuation-
 describe('meeting punctuation worker', () => {
   it('uses sherpa-onnx OfflinePunctuation with ctTransformer and addPunct', async () => {
     const addPunct = vi.fn((text: string) => `${text}。`);
-    const OfflinePunctuation = vi.fn(function OfflinePunctuation(this: { addPunct: typeof addPunct }, config: unknown) {
+    const construct = vi.fn((config: unknown) => {
       expect(config).toEqual({
         model: {
           ctTransformer: '/models/punctuation/model.int8.onnx',
@@ -12,8 +12,11 @@ describe('meeting punctuation worker', () => {
           provider: 'cpu',
         },
       });
-      this.addPunct = addPunct;
     });
+    class OfflinePunctuation {
+      addPunct = addPunct;
+      constructor(config: unknown) { construct(config); }
+    }
 
     const result = await runPunctuationWorkerRequest({
       text: '我们都是木头人不会说话不会动',
@@ -22,7 +25,7 @@ describe('meeting punctuation worker', () => {
       loadRuntime: async () => ({ OfflinePunctuation }),
     });
 
-    expect(OfflinePunctuation).toHaveBeenCalledTimes(1);
+    expect(construct).toHaveBeenCalledTimes(1);
     expect(addPunct).toHaveBeenCalledWith('我们都是木头人不会说话不会动');
     expect(result).toEqual({
       ok: true,
diff --git a/desktop/tests/main/preload-contract.test.ts b/desktop/tests/main/preload-contract.test.ts
index 0f6413d6..0b246332 100644
--- a/desktop/tests/main/preload-contract.test.ts
+++ b/desktop/tests/main/preload-contract.test.ts
@@ -1,3 +1,4 @@
+import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from '../../electron/skill-list-typed-ipc.js';
 import { registerAutomationConfigIpc } from '../../electron/automation-config-typed-ipc.js';
@@ -1071,6 +1072,7 @@ function extractRegisteredHandlerChannels(): Set<string> {
   registerAutomationConfigIpc({ handle: channel => { channels.add(channel); } });
   registerSkillListIpc({ handle: channel => { channels.add(channel); } });
   registerChannelMcpReadonlyIpc({ handle: channel => { channels.add(channel); } });
+registerMeetingReadonlyIpc({ handle: channel => { channels.add(channel); } });
   registerKSwarmProxy({ handle: channel => { channels.add(channel); } }, {} as never);
 registerLoopOutputIpc({handle:channel=>{channels.add(channel);}},{} as never,()=>false);
   registerConversationActivityIpc({ handle: channel => { channels.add(channel); } }, null, () => null);

```

## FULL desktop/electron/meeting-readonly-data.ts SHA256 decfe435da99a3949181c37ffabc56071041e6fd300fc238c61e980c7baa9d87
```typescript
import { readFileSync } from 'node:fs';
import { types } from 'node:util';
import { z } from 'zod';
import { getConfigPath } from '../../src/utils/config.js';
import { DEFAULT_CONFIG, isValidLegacyProvider, type Config, type LegacyConfig } from '../../src/types.js';
import { normalizeConfig } from '../../src/ai/providers/normalize.js';
import { createMeetingAsrConfigSnapshot } from './meeting-asr-config.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { MEETING_ASR_OUTPUT_SCHEMA } from '../shared/meeting-readonly-ipc-contract.js';

const provider = z.object({
  appKey: z.string().optional(), accessKey: z.string().optional(), apiKey: z.string().optional(),
  endpoint: z.string().optional(), resourceId: z.string().optional(),
  baseUrl: z.string().optional(), model: z.string().optional(),
}).passthrough();
const storedMeeting = z.object({ asr: z.object({
  defaultProvider: MEETING_ASR_OUTPUT_SCHEMA.shape.defaultProvider.optional(),
  volcengine: provider.optional(), aliyun: provider.optional(),
}).passthrough().optional() }).passthrough();

export function readMeetingAsrReadonly() {
  let raw: string | undefined;
  try { raw = readFileSync(getConfigPath(), 'utf8'); }
  catch (error) {
    if (!(error && typeof error === 'object' && !types.isProxy(error)
      && Object.getOwnPropertyDescriptor(error, 'code')?.value === 'ENOENT')) throw error;
  }
  let config: Config;
  if (raw === undefined) config = JSON.parse(JSON.stringify(DEFAULT_CONFIG)) as Config;
  else {
    let decoded: unknown;
    try { decoded = JSON.parse(raw); }
    catch { throw Error('meeting_readonly_projection_unavailable'); }
    const snapshot = captureIpcData(decoded, 'meeting_readonly_projection_unavailable', { preserveDataPrototype: true });
    if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) throw Error('meeting_readonly_projection_unavailable');
    const obj = snapshot as Record<string, unknown>;
    if (obj.schemaVersion !== 1 && obj.schemaVersion !== 2) throw Error('meeting_readonly_projection_unavailable');
    if (obj.schemaVersion === 1 && obj.defaultModel !== undefined && !isValidLegacyProvider(obj.defaultModel)) throw Error('meeting_readonly_projection_unavailable');
    if (obj.meeting !== undefined && !storedMeeting.safeParse(obj.meeting).success) throw Error('meeting_readonly_projection_unavailable');
    config = normalizeConfig(obj as unknown as Config | LegacyConfig);
  }
  const dto = captureIpcData(createMeetingAsrConfigSnapshot(config), 'meeting_readonly_projection_unavailable');
  const parsed = MEETING_ASR_OUTPUT_SCHEMA.safeParse(dto);
  if (!parsed.success) throw Error('meeting_readonly_projection_unavailable');
  return parsed.data;
}

```

## FULL desktop/electron/meeting-readonly-typed-ipc.ts SHA256 8cf29e4fd617fdf2ee95513a88743395a2673ead8bd4ac19d1bb53d26ba76b8b
```typescript
import { types } from 'node:util';
import { z } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { MEETING_READONLY_METHODS, MEETING_READONLY_INPUT_SCHEMA, MEETING_READONLY_OUTPUT_SCHEMAS } from '../shared/meeting-readonly-ipc-contract.js';
const isPromise=types.isPromise,NativePromise=Promise,nativeThen=Promise.prototype.then,apply=Reflect.apply;
const owners=new WeakMap<IpcHandleRegistrar,ReadonlyMap<string,IpcHandlerListener>|null>();
export function registerMeetingReadonlyIpc(ipc:IpcHandleRegistrar,rawProducers?:ReadonlyMap<string,IpcHandlerListener>):void {
 const producers=rawProducers??null;
 if(owners.has(ipc)){if(owners.get(ipc)!==producers)throw Error('meeting_readonly_registrar_owner_conflict');return;}
 for(const method of MEETING_READONLY_METHODS){
  const channel='desktop:meeting:'+method,output=MEETING_READONLY_OUTPUT_SCHEMAS[method];
  const capture=(raw:unknown)=>{const value=captureIpcData(raw,'meeting_readonly_projection_unavailable');if(!output.safeParse(value).success)throw Error('meeting_readonly_projection_unavailable');return value;};
  registerIpcHandler<unknown[],unknown>({registrar:ipc,channel,input:z.custom<unknown[]>(()=>true).transform(raw=>{const value=captureIpcData(raw,'meeting_readonly_input_invalid');if(!MEETING_READONLY_INPUT_SCHEMA.safeParse(value).success)throw Error('meeting_readonly_input_invalid');return value;}),output,payloadMode:'tuple',rolloutRound:33,riskTags:['fs-read'],sourceFile:'desktop/electron/meeting-readonly-typed-ipc.ts',handler:async(args,event)=>{
   const producer=producers?.get(channel);if(!producer)throw Error('meeting_readonly_runtime_unavailable');const result=producer(event,...args);
   if(!isPromise(result))return capture(result);assertStandardIpcPromise(result,'meeting_readonly_projection_unavailable');
   return new NativePromise((resolve,reject)=>apply(nativeThen,result,[(value:unknown)=>{try{resolve(capture(value));}catch(error){reject(error);}},reject]));
  }});
 }
 owners.set(ipc,producers);
}

```

## FULL desktop/renderer/src/hooks/useMeetingReadonly.ts SHA256 5285c6e81d849a1669fad47a2df206f67e20dc3cf5361d6cdf1fe44b6984f21d
```typescript
import { getDesktopApi } from '../shared/desktop';
import { useDesktopReadonly } from './useSkillReadonly';
import { MEETING_ASR_OUTPUT_SCHEMA, MEETING_MODELS_OUTPUT_SCHEMA } from '../../../shared/meeting-readonly-ipc-contract';
const readModels = async () => {
  const desktop = getDesktopApi();
  if (!desktop?.meetingListModels) throw Error('meeting_readonly_runtime_unavailable');
  return desktop.meetingListModels();
};
const readAsr = async () => {
  const desktop = getDesktopApi();
  if (!desktop?.meetingGetAsrConfig) throw Error('meeting_readonly_runtime_unavailable');
  return desktop.meetingGetAsrConfig();
};
export function useMeetingModelsReadonly() { return useDesktopReadonly(readModels, MEETING_MODELS_OUTPUT_SCHEMA, false); }
export function useMeetingAsrReadonly() { return useDesktopReadonly(readAsr, MEETING_ASR_OUTPUT_SCHEMA, false); }

```

## FULL desktop/shared/meeting-readonly-ipc-contract.ts SHA256 91c4b326fc6ff711715d69f9d82d5df8a0a3b62d4cc31a07c95ca1817adda857
```typescript
import {z}from'zod';
export const MEETING_READONLY_METHODS=['getMicrophonePermission','getAsrConfig','listModels']as const;
export const MEETING_READONLY_INPUT_SCHEMA=z.tuple([]);
export const MEETING_PERMISSION_OUTPUT_SCHEMA=z.object({status:z.enum(['granted','denied','prompt','restricted','unknown','unsupported'])}).strict();
export const MEETING_ASR_OUTPUT_SCHEMA=z.object({defaultProvider:z.enum(['sherpa-onnx-paraformer','whisper','volcengine-asr','aliyun-asr']),volcengine:z.object({configured:z.boolean(),appKeyConfigured:z.boolean(),accessKeyConfigured:z.boolean(),endpoint:z.string().optional(),resourceId:z.string()}).strict(),aliyun:z.object({configured:z.boolean(),apiKeyConfigured:z.boolean(),baseUrl:z.string(),model:z.string()}).strict()}).strict();
export const MEETING_MODELS_OUTPUT_SCHEMA=z.array(z.object({id:z.string(),fileName:z.string(),sizeBytes:z.number(),sizeLabel:z.string(),cacheDir:z.string(),path:z.string(),downloaded:z.boolean(),status:z.enum(['downloaded','not_downloaded','incomplete','corrupt']),capability:z.enum(['asr','punctuation','vad','speaker']),engineId:z.string(),packageId:z.string(),packageType:z.enum(['single-file','directory']),packageState:z.enum(['missing','downloading','incomplete','verified','corrupt']),manifestTrusted:z.boolean(),runtimeAutoDownloadAllowed:z.literal(false),localSizeBytes:z.number().optional(),localSizeLabel:z.string().optional()}).passthrough());
export const MEETING_READONLY_OUTPUT_SCHEMAS={getMicrophonePermission:MEETING_PERMISSION_OUTPUT_SCHEMA,getAsrConfig:MEETING_ASR_OUTPUT_SCHEMA,listModels:MEETING_MODELS_OUTPUT_SCHEMA}as const;
export type MeetingReadonlyPermission=z.infer<typeof MEETING_PERMISSION_OUTPUT_SCHEMA>;
export type MeetingReadonlyAsr=z.infer<typeof MEETING_ASR_OUTPUT_SCHEMA>;
export type MeetingReadonlyModels=z.infer<typeof MEETING_MODELS_OUTPUT_SCHEMA>;

```

## FULL desktop/tests/main/meeting-readonly-controls.test.ts SHA256 d52665b8fd67d2a5221e898fc5a89159b423be9aea7ea3e2ea30ee1d5d6cf16b
```typescript
import { createMeetingAsrConfigSnapshot } from '../../electron/meeting-asr-config.js';
import { DEFAULT_CONFIG } from '../../../src/types.js';
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'skills-readonly-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}


it.each(['meeting:getMicrophonePermission','meeting:getAsrConfig','meeting:listModels']as const)('rejects %s extra transport input before producer work',async channel=>{
 const f=await fixture();await expect(async()=>f.invoke(channel,{})).rejects.toThrow('meeting_readonly_input_invalid');
});
it('bad actual owned ASR configuration rejects without repairing the file',async()=>{
 const f=await fixture(),config=join(f.root,'config');mkdirSync(config,{recursive:true});const path=join(config,'config.json');writeFileSync(path,'{');await expect(async()=>f.invoke('meeting:getAsrConfig')).rejects.toThrow();expect(readFileSync(path,'utf8')).toBe('{');expect(existsSync(path+'.bak')).toBe(false);
});
it.each(['unknown','old-main','subframe'])('denies %s before the real meeting readonly payload getter',async kind=>{
 const f=await fixture(),old=f.sender;if(kind==='old-main')f.authority.setMain({webContents:{mainFrame:f.frame,isDestroyed:()=>false},isDestroyed:()=>false});const sender=kind==='unknown'?{mainFrame:f.frame,isDestroyed:()=>false}:old,frame=kind==='subframe'?{url:f.frame.url}:f.frame;let getters=0;const input=Object.defineProperty({},'owned',{enumerable:true,get(){getters++;return 0}});await expect(async()=>Reflect.apply(f.listeners.get('desktop:meeting:getAsrConfig')!,undefined,[{sender,senderFrame:frame},input])).rejects.toThrow('desktop_user_sender_forbidden');expect(getters).toBe(0);
});
it('preserves actual valid ASR public flags and excludes stored credentials',async()=>{
 const f=await fixture(),config=join(f.root,'config');mkdirSync(config,{recursive:true});writeFileSync(join(config,'config.json'),JSON.stringify({schemaVersion:2,providers:{},models:[],meeting:{asr:{defaultProvider:'aliyun-asr',aliyun:{apiKey:'owned-test-not-real-key',baseUrl:'https://owned.invalid',model:'owned-model'}}}}));const dto=await f.invoke('meeting:getAsrConfig');expect(dto.defaultProvider).toBe('aliyun-asr');expect(dto.aliyun).toMatchObject({configured:true,apiKeyConfigured:true,baseUrl:'https://owned.invalid',model:'owned-model'});expect(JSON.stringify(dto)).not.toContain('owned-test-not-real-key');
});

it.each([{meeting:[]},{meeting:{asr:[]}},{meeting:{asr:{defaultProvider:'invented'}}},{meeting:{asr:{volcengine:[]}}},{meeting:{asr:{aliyun:{apiKey:42}}}},{meeting:{asr:{volcengine:{endpoint:false}}}}])('rejects malformed stored ASR shape without normalizing it to default facts: %j',async stored=>{
 const f=await fixture(),config=join(f.root,'config');mkdirSync(config,{recursive:true});const path=join(config,'config.json'),raw=JSON.stringify({schemaVersion:2,providers:{},models:[],...stored});writeFileSync(path,raw);await expect(async()=>f.invoke('meeting:getAsrConfig')).rejects.toThrow('meeting_readonly_projection_unavailable');expect(readFileSync(path,'utf8')).toBe(raw);expect(existsSync(path+'.bak')).toBe(false);
});

it('true ENOENT returns the precise original default ASR snapshot without creating a config file',async()=>{const f=await fixture();expect(await f.invoke('meeting:getAsrConfig')).toEqual(createMeetingAsrConfigSnapshot(JSON.parse(JSON.stringify(DEFAULT_CONFIG))));expect(existsSync(join(f.root,'config/config.json'))).toBe(false);});
it('actual owned ASR file permission failure rejects without chmod or backup',async()=>{const f=await fixture(),dir=join(f.root,'config');mkdirSync(dir);const path=join(dir,'config.json');writeFileSync(path,JSON.stringify({schemaVersion:2,providers:{},models:[]}));chmodSync(path,0);try{await expect(async()=>f.invoke('meeting:getAsrConfig')).rejects.toThrow();}finally{chmodSync(path,0o600);}expect(existsSync(path+'.bak')).toBe(false);});

it('does not expose credential fragments from actual malformed ASR JSON through IPC rejection',async()=>{
 const f=await fixture(),dir=join(f.root,'config');mkdirSync(dir);const path=join(dir,'config.json'),raw='{"meeting":{"asr":{"aliyun":{"apiKey":owned-fake-credential-marker-asr}}}}';writeFileSync(path,raw);const error=await Promise.resolve().then(()=>f.invoke('meeting:getAsrConfig')).catch((value:unknown)=>value);expect(error).toBeInstanceOf(Error);expect((error as Error).message).toBe('meeting_readonly_projection_unavailable');expect(String(error)).not.toContain('owned-fake');expect(readFileSync(path,'utf8')).toBe(raw);expect(existsSync(path+'.bak')).toBe(false);
});

```

## FULL desktop/tests/main/meeting-readonly-model-io.test.ts SHA256 6e9a396eff633c1647840d41941345a311c35e5a7c21147bd2e4145598c433f7
```typescript
// @vitest-environment node
import {mkdtempSync,mkdirSync,writeFileSync,rmSync,chmodSync} from 'node:fs';
import{tmpdir}from'node:os';import{join}from'node:path';import{createHash}from'node:crypto';
import{afterEach,expect,it,vi}from'vitest';
import{createMeetingModelService,type MeetingModelServiceOptions}from'../../electron/meeting-model-service.js';
const roots:string[]=[];afterEach(()=>{for(const r of roots.splice(0))rmSync(r,{recursive:true,force:true});});
function fixture(){const root=mkdtempSync(join(tmpdir(),'meeting-readonly-owned-'));roots.push(root);const cache=join(root,'cache');mkdirSync(cache);const data=Buffer.from('owned model'),sha=createHash('sha256').update(data).digest('hex'),download=vi.fn(async()=>{throw Error('readonly_must_not_download')});const options={cacheDir:cache,models:[{id:'owned',fileName:'owned.pt',url:'https://owned.invalid',expectedSizeBytes:data.length,expectedSha256:sha}],downloadFile:download};return{root,cache,data,download,options,strict:createMeetingModelService({...options,readonlyIoPolicy:'truthful'}as MeetingModelServiceOptions)};}
it('truthful listing rejects an actual access failure instead of claiming missing models',()=>{
 const f=fixture();writeFileSync(join(f.cache,'owned.pt'),f.data);chmodSync(f.cache,0);try{expect(()=>f.strict.listModels()).toThrow();}finally{chmodSync(f.cache,0o700);}expect(f.download).not.toHaveBeenCalled();
});
it('preserves complete absent and verified model metadata without downloading',()=>{
 const f=fixture();expect(f.strict.listModels()[0]).toMatchObject({id:'owned',downloaded:false,status:'not_downloaded',packageState:'missing',runtimeAutoDownloadAllowed:false});writeFileSync(join(f.cache,'owned.pt'),f.data);expect(f.strict.listModels()[0]).toMatchObject({id:'owned',downloaded:true,status:'downloaded',packageState:'verified',localSizeBytes:f.data.length});expect(f.download).not.toHaveBeenCalled();
});
it('default service retains its original tolerant existence decision',()=>{
 const f=fixture();writeFileSync(join(f.cache,'owned.pt'),f.data);chmodSync(f.cache,0);try{expect(createMeetingModelService(f.options).listModels()[0]).toMatchObject({status:'not_downloaded'});}finally{chmodSync(f.cache,0o700);}
});

```

## FULL desktop/tests/main/meeting-readonly-output-boundary.test.ts SHA256 1c0b3b495b0d79b31e2eb36f6eec5e2092c3e5f983bf6e223668960bd182dbff
```typescript
// @vitest-environment node
import {expect,it,vi,afterEach}from'vitest';
import{registerMeetingReadonlyIpc}from'../../electron/meeting-readonly-typed-ipc.js';
import{DesktopShutdownGate,ShutdownAwareIpcMain,type IpcHandlerListener}from'../../electron/shutdown-aware-ipc-main.js';
const row={id:'owned',fileName:'owned.pt',sizeBytes:10,sizeLabel:'10 B',cacheDir:'/owned',path:'/owned/owned.pt',downloaded:false,status:'not_downloaded',capability:'asr',engineId:'whisper',packageId:'owned',packageType:'single-file',packageState:'missing',manifestTrusted:true,runtimeAutoDownloadAllowed:false};
function fixture(method:string,produce:()=>unknown){const handlers=new Map<string,IpcHandlerListener>(),gate=new DesktopShutdownGate(),ipc=new ShutdownAwareIpcMain({handle:(name,fn)=>handlers.set(name,fn)},gate);const producers=new Map([['desktop:meeting:'+method,produce]]);registerMeetingReadonlyIpc(ipc,producers);return{gate,ipc,producers,invoke:(...args:unknown[])=>handlers.get('desktop:meeting:'+method)!({}as never,...args)};}
afterEach(()=>vi.useRealTimers());
it.each(['granted','denied','prompt','restricted','unknown','unsupported'])('preserves complete permission status %s',async status=>{const f=fixture('getMicrophonePermission',()=>({status}));expect(await f.invoke()).toEqual({status});expect(f.gate.outstanding).toBe(0);});
it.each(['accessor','proxy','serializer','cycle','malformed'])('rejects %s output without executing user hooks or retrying',async kind=>{
 let reads=0;let value:unknown=[row];if(kind==='accessor')value=Object.defineProperty({...row},'status',{enumerable:true,get(){reads++;return'downloaded'}});if(kind==='proxy')value=new Proxy(row,{ownKeys(){reads++;return[]}});if(kind==='serializer')value={...row,toJSON(){reads++;return row}};if(kind==='cycle'){const object:typeof row & {cycle?:unknown}={...row};object.cycle=object;value=object;}if(kind==='malformed')value={};const produce=vi.fn(()=>[value]);const f=fixture('listModels',produce);await expect(f.invoke()).rejects.toThrow('meeting_readonly_projection_unavailable');expect(reads).toBe(0);expect(produce).toHaveBeenCalledTimes(1);expect(f.gate.outstanding).toBe(0);
});
it('detaches full model metadata including future nested fields',async()=>{const rows=[{...row,future:{items:['owned']}}],f=fixture('listModels',()=>rows);const a=await f.invoke(),b=await f.invoke();expect(a).toEqual(rows);expect(a).not.toBe(rows);expect(a).not.toBe(b);expect((a as typeof rows)[0]!.future.items).not.toBe(rows[0]!.future.items);});
it('keeps the original 5s drain token until the real producer settles',async()=>{vi.useFakeTimers();let release!:(value:unknown)=>void;const produce=vi.fn(()=>new Promise(resolve=>{release=resolve})),f=fixture('listModels',produce);const result=f.invoke();await vi.advanceTimersByTimeAsync(0);expect(f.gate.outstanding).toBe(1);f.gate.close();await expect(f.invoke()).rejects.toThrow('shutting_down');try{const drain=f.gate.drain(5000);await vi.advanceTimersByTimeAsync(5001);expect(await drain).toBe(false);expect(f.gate.outstanding).toBe(1);}finally{release([]);await result;}expect(f.gate.outstanding).toBe(0);expect(produce).toHaveBeenCalledTimes(1);});
it('keeps one registrar owner and rejects another producer map',()=>{const f=fixture('listModels',()=>[]);expect(()=>registerMeetingReadonlyIpc(f.ipc,f.producers)).not.toThrow();expect(()=>registerMeetingReadonlyIpc(f.ipc,new Map())).toThrow('meeting_readonly_registrar_owner_conflict');});

```

## FULL desktop/tests/main/meeting-readonly-preload.test.ts SHA256 0df7bca9f97fde6523c859385dd93a0f7f442d770727a1e9762712a9f618ea02
```typescript
// @vitest-environment node
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import * as os from 'node:os';
import { expect, it, vi } from 'vitest';
import { createPreloadApi } from '../../electron/preload-api.js';
function port() { return { invoke: vi.fn(async (_channel: string, ..._args: unknown[]) => []), on: vi.fn(), off: vi.fn(), removeListener: vi.fn(), send: vi.fn() }; }
async function check(api: ReturnType<typeof createPreloadApi>, ipc: ReturnType<typeof port>) {
  for (const method of ['meetingGetMicrophonePermission', 'meetingGetAsrConfig', 'meetingListModels'] as const) {
    ipc.invoke.mockClear(); expect(await api[method]()).toEqual([]); expect(ipc.invoke).toHaveBeenCalledExactlyOnceWith({meetingGetMicrophonePermission:'desktop:meeting:getMicrophonePermission',meetingGetAsrConfig:'desktop:meeting:getAsrConfig',meetingListModels:'desktop:meeting:listModels'}[method]);
    const error = Error('owned_read_failure'); ipc.invoke.mockRejectedValueOnce(error); await expect(api[method]()).rejects.toBe(error);
  }
  expect(ipc.invoke.mock.calls.every(call => ['desktop:meeting:getMicrophonePermission','desktop:meeting:getAsrConfig','desktop:meeting:listModels'].includes(call[0]))).toBe(true);
}
it('actual TS preload preserves all three readonly zero tuples and rejection', async () => { const ipc = port(); await check(createPreloadApi(ipc), ipc); });
it('actual CJS sandbox preload preserves all three readonly zero tuples and rejection', async () => {
  const ipc = port(); let api!: ReturnType<typeof createPreloadApi>;
  runInNewContext(readFileSync(new URL('../../electron/preload.cjs', import.meta.url), 'utf8'), {
    require(name: string) {
      if (name === 'electron') return { ipcRenderer: ipc, contextBridge: { exposeInMainWorld(_key: string, value: ReturnType<typeof createPreloadApi>) { api = value; } } };
      if (name === 'os') return os; throw Error('unexpected dependency ' + name);
    },
  }); await check(api, ipc);
});

```

## FULL desktop/tests/renderer/meeting-readonly-bridge.test.ts SHA256 206652b6c6b5498d05e40c95084175b5c2ad505394d3dca477b84e91880e5345
```typescript
import {afterEach,expect,it,vi}from'vitest';
import{getDesktopApi,_resetDesktopApiCache}from'../../renderer/src/shared/desktop';
const original=window.xiaokDesktop;
afterEach(()=>{window.xiaokDesktop=original;_resetDesktopApiCache();vi.restoreAllMocks();});
it.each(['meetingGetMicrophonePermission','meetingGetAsrConfig','meetingListModels']as const)('actual desktop bridge preserves %s zero tuple and rejection identity',async method=>{
 const error=Error('owned-business-failure'),produce=vi.fn().mockRejectedValue(error);window.xiaokDesktop={...original,[method]:produce};_resetDesktopApiCache();await expect(getDesktopApi()![method]()).rejects.toBe(error);expect(produce).toHaveBeenCalledExactlyOnceWith();
});

```

## FULL desktop/tests/renderer/meeting-readonly-consumers.test.tsx SHA256 a849e3c99a36a4d306fe42cdc27217ae4be2b5e88bedadd3f274e0a51ac27b9f
```typescript
import {cleanup,fireEvent,render,screen,waitFor,act} from '@testing-library/react';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {MemoryRouter} from 'react-router-dom';
import {DesktopSettings} from '../../renderer/src/components/DesktopSettings';
import {LocaleProvider,useLocale} from '../../renderer/src/contexts/LocaleContext';
import {zh} from '../../renderer/src/locales/zh';
const mocks=vi.hoisted(()=>({models:vi.fn(),asr:vi.fn(),download:vi.fn(),save:vi.fn(),available:true}));
vi.mock('../../renderer/src/shared/desktop',()=>({getDesktopApi:()=>mocks.available?({meetingListModels:mocks.models,meetingGetAsrConfig:mocks.asr,meetingDownloadModel:mocks.download,meetingSaveAsrConfig:mocks.save}):null}));
const rows=[{id:'owned',fileName:'owned.pt',sizeBytes:10,sizeLabel:'10 B',cacheDir:'/owned',path:'/owned/owned.pt',downloaded:false,status:'not_downloaded',capability:'asr',engineId:'whisper',packageId:'owned',packageType:'single-file',packageState:'missing',manifestTrusted:true,runtimeAutoDownloadAllowed:false}];
const asr={defaultProvider:'aliyun-asr',volcengine:{configured:true,appKeyConfigured:true,accessKeyConfigured:false,endpoint:'wss://owned.invalid',resourceId:'owned'},aliyun:{configured:true,apiKeyConfigured:true,baseUrl:'https://owned.invalid',model:'owned'}};
function LocaleButton(){const{setLocale}=useLocale();return <button onClick={()=>setLocale('en')}>test-locale</button>;}
function mount(){const view=render(<MemoryRouter><LocaleProvider><LocaleButton/><DesktopSettings onClose={()=>{}}/></LocaleProvider></MemoryRouter>);fireEvent.click(screen.getByRole('button',{name:zh.desktopSettings.voice}));return view;}
beforeEach(()=>{mocks.available=true;localStorage.setItem('xiaok:locale','zh');mocks.models.mockReset().mockResolvedValue(rows);mocks.asr.mockReset().mockResolvedValue(asr);mocks.download.mockReset();mocks.save.mockReset();});
afterEach(()=>{cleanup();localStorage.clear();vi.restoreAllMocks();});
it.each(['models','asr']as const)('shows %s failed facts without leaking private errors',async kind=>{mocks[kind].mockRejectedValue(Error('private-reader-failure'));mount();expect(await screen.findByText(kind==='models'?'\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b':'\u65e0\u6cd5\u8bfb\u53d6\u8bed\u97f3\u914d\u7f6e')).toBeInTheDocument();expect(screen.queryByText(/private-reader-failure/)).toBeNull();expect(mocks.download).not.toHaveBeenCalled();expect(mocks.save).not.toHaveBeenCalled();});
it('keeps last-good rows and ASR facts through failed manual retries',async()=>{mount();await screen.findByText('owned.pt');await screen.findByDisplayValue('https://owned.invalid');mocks.models.mockRejectedValueOnce(Error('private-reader-failure'));mocks.asr.mockRejectedValueOnce(Error('private-reader-failure'));fireEvent.click(screen.getByRole('button',{name:'\u91cd\u65b0\u8bfb\u53d6'}));await screen.findByText('\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b');expect(screen.getByText('owned.pt')).toBeInTheDocument();expect(screen.getByDisplayValue('https://owned.invalid')).toBeInTheDocument();expect(mocks.download).not.toHaveBeenCalled();expect(mocks.save).not.toHaveBeenCalled();});
it('rejects malformed successful results before publishing facts',async()=>{mocks.models.mockResolvedValue([{}]);mocks.asr.mockResolvedValue({});mount();await screen.findByText('\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b');await screen.findByText('\u65e0\u6cd5\u8bfb\u53d6\u8bed\u97f3\u914d\u7f6e');});
it('coalesces held manual retries and leaves no successor after unmount',async()=>{mount();await screen.findByText('owned.pt');let release!:(value:unknown)=>void;mocks.models.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));const retry=screen.getByRole('button',{name:'\u91cd\u65b0\u8bfb\u53d6'});fireEvent.click(retry);fireEvent.click(retry);fireEvent.click(retry);expect(mocks.models).toHaveBeenCalledTimes(2);await act(async()=>release(rows));await waitFor(()=>expect(mocks.models).toHaveBeenCalledTimes(3));cleanup();expect(mocks.download).not.toHaveBeenCalled();expect(mocks.save).not.toHaveBeenCalled();});
it('expires the old locale read and retains current locale failure',async()=>{let release!:(value:unknown)=>void;mocks.models.mockReturnValueOnce(new Promise(resolve=>{release=resolve})).mockRejectedValueOnce(Error('new-scope-failure'));mount();fireEvent.click(screen.getByRole('button',{name:'test-locale'}));await screen.findByText('Unable to read meeting models');await act(async()=>release(rows));expect(screen.queryByText('owned.pt')).toBeNull();expect(screen.getByText('Unable to read meeting models')).toBeInTheDocument();});

it('initial held reads stay unknown and unmount expires all queued successors',async()=>{let models!:(value:unknown)=>void,config!:(value:unknown)=>void;mocks.models.mockReturnValueOnce(new Promise(resolve=>{models=resolve}));mocks.asr.mockReturnValueOnce(new Promise(resolve=>{config=resolve}));const view=mount();expect(screen.getByText('\u4f1a\u8bae\u6a21\u578b\u4fe1\u606f\u672a\u77e5')).toBeInTheDocument();expect(screen.getAllByText('\u8bed\u97f3\u914d\u7f6e\u672a\u77e5')).toHaveLength(2);fireEvent.click(screen.getByRole('button',{name:'\u91cd\u65b0\u8bfb\u53d6'}));view.unmount();await act(async()=>{models(rows);config(asr)});expect(mocks.models).toHaveBeenCalledTimes(1);expect(mocks.asr).toHaveBeenCalledTimes(1);expect(mocks.download).not.toHaveBeenCalled();expect(mocks.save).not.toHaveBeenCalled();});
it('absent desktop preload remains unavailable instead of successful empty facts',async()=>{mocks.available=false;mount();await screen.findByText('\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b');await screen.findByText('\u65e0\u6cd5\u8bfb\u53d6\u8bed\u97f3\u914d\u7f6e');expect(mocks.models).not.toHaveBeenCalled();expect(mocks.asr).not.toHaveBeenCalled();});
it('readonly manual retry preserves the user download error without repeating the action',async()=>{mocks.download.mockResolvedValue({ok:false,error:'owned-action-error'});mount();await screen.findByText('owned.pt');fireEvent.click(screen.getByRole('button',{name:zh.knowledge.meetingModelDownloadAria('owned.pt')}));await screen.findByText(/owned-action-error/);fireEvent.click(screen.getByRole('button',{name:'\u91cd\u65b0\u8bfb\u53d6'}));await waitFor(()=>expect(mocks.models).toHaveBeenCalledTimes(3));expect(screen.getByText(/owned-action-error/)).toBeInTheDocument();expect(mocks.download).toHaveBeenCalledExactlyOnceWith('owned');expect(mocks.save).not.toHaveBeenCalled();});

```

## Actual desktop/renderer/src/components/DesktopSettings.tsx:345 VoicePane full function; full-file SHA256 02b338c19143c7a9f6c5fb850ecb641c67f5f7f10715ab44cd53aa0690ee60ff
```typescript
function VoicePane() {
  const { t } = useLocale();
  const ds = t.desktopSettings;
  const desktop = getDesktopApi();
  const [engine, setEngine] = useState<MeetingTranscriberEngine>(readStoredMeetingTranscriberEngine);
  const [model, setModel] = useState<MeetingTranscriberModel>(() => readStoredMeetingTranscriberModel(readStoredMeetingTranscriberEngine()));
  const [language, setLanguage] = useState<MeetingTranscriberLanguage>(readStoredMeetingTranscriberLanguage);
  const modelFacts = useMeetingModelsReadonly(), asrFacts = useMeetingAsrReadonly();
  const asrConfig = asrFacts.data;
  const [asrDraft, setAsrDraft] = useState({
    volcAppKey: '',
    volcAccessKey: '',
    volcEndpoint: '',
    volcResourceId: '',
    aliyunApiKey: '',
    aliyunBaseUrl: '',
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState('');
  const modelStatuses = modelFacts.data ?? [];
  const modelStatusesLoading = modelFacts.reading;
  const [modelStatusesError, setModelStatusesError] = useState('');
  const [modelAction, setModelAction] = useState<MeetingModelActionState | null>(null);

  const engineLabels: Record<MeetingTranscriberEngine, string> = {
    'sherpa-onnx-paraformer': t.knowledge.meetingSpeechEngineSherpaOnnxParaformer,
    whisper: t.knowledge.meetingSpeechEngineWhisperFallback,
    'volcengine-asr': t.knowledge.meetingSpeechEngineVolcengineAsr,
    'aliyun-asr': t.knowledge.meetingSpeechEngineAliyunAsr,
  };
  const languageLabels: Record<MeetingTranscriberLanguage, string> = {
    zh: t.knowledge.meetingLanguageZh,
    auto: t.knowledge.meetingLanguageAuto,
    en: t.knowledge.meetingLanguageEn,
  };

  const modelStatusById = new Map(modelStatuses.map(status => [status.id, status]));
  const visibleModelOptions = MEETING_TRANSCRIBER_MODEL_OPTIONS.filter(option => (
    meetingTranscriberEngineForModel(option) === engine
  ));
  const groupedModelStatuses = [
    {
      id: 'asr',
      title: t.knowledge.meetingSpeechModelsStatusTitle,
      models: modelStatuses.filter(item => (item.capability ?? 'asr') === 'asr'),
    },
    {
      id: 'punctuation',
      title: t.knowledge.meetingPunctuationModelsStatusTitle,
      models: modelStatuses.filter(item => item.capability === 'punctuation'),
    },
  ].filter(group => group.models.length > 0);

  const loadMeetingModelStatuses = useCallback(async () => {
    await modelFacts.reload().catch(() => {});
  }, [modelFacts.reload]);
  useEffect(() => {
    const snapshot = asrFacts.data;
    if (!snapshot) return;
      setAsrDraft(prev => ({
        ...prev,
        volcEndpoint: snapshot.volcengine?.endpoint ?? '',
        volcResourceId: snapshot.volcengine?.resourceId ?? '',
        aliyunBaseUrl: snapshot.aliyun?.baseUrl ?? '',
      }));
      const fallback = snapshot.defaultProvider && MEETING_TRANSCRIBER_ENGINE_OPTIONS.includes(snapshot.defaultProvider)
        ? snapshot.defaultProvider
        : 'sherpa-onnx-paraformer';
      const nextEngine = readStoredMeetingTranscriberEngine(fallback);
      const nextModel = readStoredMeetingTranscriberModel(nextEngine);
      const nextLanguage = readStoredMeetingTranscriberLanguage();
      setEngine(nextEngine);
      setModel(nextModel);
      setLanguage(nextLanguage);
  }, [asrFacts.data]);

  const persistTranscriberChoice = (nextEngine: MeetingTranscriberEngine, nextModel: MeetingTranscriberModel, nextLanguage = language) => {
    try {
      localStorage.setItem('meeting-transcriber-engine', nextEngine);
      localStorage.setItem('meeting-transcriber-model', nextModel);
      localStorage.setItem('meeting-transcriber-language', nextLanguage);
    } catch {
      // best effort only
    }
  };

  const updateEngine = (value: MeetingTranscriberEngine) => {
    const nextModel = meetingTranscriberEngineForModel(model) === value ? model : defaultMeetingTranscriberModelForEngine(value);
    setEngine(value);
    setModel(nextModel);
    setSaved(false);
    persistTranscriberChoice(value, nextModel);
  };

  const updateModel = (value: MeetingTranscriberModel) => {
    const nextEngine = meetingTranscriberEngineForModel(value);
    setEngine(nextEngine);
    setModel(value);
    setSaved(false);
    persistTranscriberChoice(nextEngine, value);
  };

  const updateLanguage = (value: MeetingTranscriberLanguage) => {
    setLanguage(value);
    setSaved(false);
    persistTranscriberChoice(engine, model, value);
  };

  const handleSaveMeetingAsrConfig = async () => {
    if (!desktop?.meetingSaveAsrConfig || saving) return;
    setSaving(true);
    setSaved(false);
    setSaveError('');
    persistTranscriberChoice(engine, model, language);
    const input = engine === 'volcengine-asr'
      ? {
          defaultProvider: engine,
          volcengine: {
            appKey: asrDraft.volcAppKey,
            accessKey: asrDraft.volcAccessKey,
            endpoint: asrDraft.volcEndpoint,
            resourceId: asrDraft.volcResourceId,
          },
        }
      : engine === 'aliyun-asr'
        ? {
          defaultProvider: engine,
          aliyun: {
              apiKey: asrDraft.aliyunApiKey,
              baseUrl: asrDraft.aliyunBaseUrl,
              model: 'fun-asr',
            },
          }
        : { defaultProvider: engine };
    try {
      const snapshot = await desktop.meetingSaveAsrConfig(input) as MeetingAsrConfigSnapshot;
      await asrFacts.reload().catch(() => {});
      setAsrDraft(prev => ({
        ...prev,
        volcAppKey: '',
        volcAccessKey: '',
        aliyunApiKey: '',
        volcEndpoint: snapshot.volcengine?.endpoint ?? prev.volcEndpoint,
        volcResourceId: snapshot.volcengine?.resourceId ?? prev.volcResourceId,
        aliyunBaseUrl: snapshot.aliyun?.baseUrl ?? prev.aliyunBaseUrl,
      }));
      setSaved(true);
    } catch (error) {
      setSaveError(t.knowledge.meetingOnlineAsrSaveFailed(error instanceof Error ? error.message : 'unknown'));
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadMeetingModel = async (modelId: string) => {
    if (!desktop?.meetingDownloadModel || modelAction) return;
    setModelAction({ modelId, kind: 'download' });
    setModelStatusesError('');
    try {
      const result = await desktop.meetingDownloadModel(modelId) as { ok?: boolean; reason?: string; error?: string };
      await loadMeetingModelStatuses();
      if (result?.ok === false) {
        setModelStatusesError(t.knowledge.meetingModelActionFailed(result.reason ?? result.error ?? 'unknown'));
      }
      setModelAction(null);
    } catch (error) {
      setModelStatusesError(t.knowledge.meetingModelActionFailed(error instanceof Error ? error.message : 'unknown'));
      setModelAction(null);
    }
  };

  const handleUninstallMeetingModel = async (modelId: string) => {
    if (!desktop?.meetingUninstallModel || modelAction) return;
    setModelAction({ modelId, kind: 'uninstall' });
    setModelStatusesError('');
    try {
      const result = await desktop.meetingUninstallModel(modelId) as { ok?: boolean; reason?: string; error?: string };
      await loadMeetingModelStatuses();
      if (result?.ok === false) {
        setModelStatusesError(t.knowledge.meetingModelActionFailed(result.reason ?? result.error ?? 'unknown'));
      }
      setModelAction(null);
    } catch (error) {
      setModelStatusesError(t.knowledge.meetingModelActionFailed(error instanceof Error ? error.message : 'unknown'));
      setModelAction(null);
    }
  };

  const renderProviderStatus = (configured?: boolean) => (
    <span className={`rounded-full border px-2 py-0.5 text-[11px] ${configured ? 'border-green-200 bg-green-50 text-green-700' : 'border-[var(--c-border)] bg-[var(--c-bg-page)] text-[var(--c-text-tertiary)]'}`}>
      {asrConfig === null ? t.meetingAsrReadonlyUnknown : configured ? ds.meetingAsrConfigured : ds.meetingAsrNotConfigured}
    </span>
  );

  const renderModelStatusRow = (item: MeetingModelStatusSnapshot) => {
    const actionRunning = modelAction?.modelId === item.id;
    const downloading = actionRunning && modelAction.kind === 'download';
    const statusLabel = downloading
      ? t.knowledge.meetingModelStatusDownloading
      : item.status === 'downloaded'
        ? t.knowledge.meetingModelStatusDownloaded
        : item.status === 'incomplete'
          ? t.knowledge.meetingModelStatusIncomplete
          : item.status === 'corrupt'
            ? t.knowledge.meetingModelStatusCorrupt
            : t.knowledge.meetingModelStatusNotDownloaded;
    const statusClassName = downloading
      ? 'border-blue-200 bg-blue-50 text-blue-700'
      : item.status === 'downloaded'
        ? 'border-green-200 bg-green-50 text-green-700'
        : item.status === 'incomplete'
          ? 'border-amber-200 bg-amber-50 text-amber-700'
          : item.status === 'corrupt'
            ? 'border-red-200 bg-red-50 text-red-700'
            : 'border-[var(--c-border)] bg-[var(--c-bg-page)] text-[var(--c-text-tertiary)]';
    const actionLabel = item.status === 'downloaded'
      ? t.knowledge.meetingModelUninstallAria(item.fileName)
      : item.status === 'incomplete' || item.status === 'corrupt'
        ? t.knowledge.meetingModelRedownloadAria(item.fileName)
        : t.knowledge.meetingModelDownloadAria(item.fileName);
    const actionTitle = item.status === 'downloaded'
      ? t.knowledge.meetingModelUninstall
      : item.status === 'incomplete' || item.status === 'corrupt'
        ? t.knowledge.meetingModelRedownload
        : t.knowledge.meetingModelDownload;
    return (
      <div key={item.id} className="rounded-lg border border-[var(--c-border)] px-3 py-2">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-xs font-medium text-[var(--c-text-primary)]">{item.fileName}</p>
            <p className="mt-0.5 text-[11px] text-[var(--c-text-tertiary)]">{item.sizeLabel}</p>
          </div>
          <div data-testid={`voice-model-status-${item.id}`} className="flex shrink-0 items-center gap-1.5">
            <span className={`rounded-full border px-2 py-0.5 text-[11px] ${statusClassName}`}>
              {statusLabel}
            </span>
            <button
              type="button"
              onClick={() => item.status === 'downloaded' ? void handleUninstallMeetingModel(item.id) : void handleDownloadMeetingModel(item.id)}
              disabled={Boolean(modelAction)}
              aria-label={actionLabel}
              title={actionRunning ? t.knowledge.meetingModelActionRunning : actionTitle}
              className="inline-flex size-7 items-center justify-center rounded-md border border-[var(--c-border)] text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)] disabled:opacity-50"
            >
              {item.status === 'downloaded' ? (
                <Trash2 size={13} aria-hidden="true" />
              ) : item.status === 'incomplete' || item.status === 'corrupt' ? (
                <RotateCcw size={13} aria-hidden="true" />
              ) : (
                <Download size={13} aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
        {(item.status === 'incomplete' || item.status === 'corrupt') && item.localSizeLabel && (
          <p className="mt-1 text-[11px] text-[var(--c-text-tertiary)]">
            {t.knowledge.meetingModelStatusLocalSize(item.localSizeLabel, item.sizeLabel)}
          </p>
        )}
      </div>
    );
  };

  const modelOptionLabel = (modelId: MeetingTranscriberModel) => {
    const status = modelStatusById.get(modelId);
    const displayModel = modelId === MEETING_SHERPA_ONNX_PARA_MODEL
      ? t.knowledge.meetingSpeechModelSherpaOnnxParaformerSmall
      : modelId;
    return t.knowledge.meetingSpeechModelOption(
      status?.engineId === 'sherpa-onnx-paraformer'
        ? t.knowledge.meetingSpeechEngineSherpaOnnxName
        : t.knowledge.meetingSpeechEngineWhisperName,
      displayModel,
      status?.sizeLabel,
    );
  };

  return (
    <div className="space-y-6">
      {modelFacts.failed && <p role="alert">{t.meetingModelsReadonlyUnavailable}</p>}
      {asrFacts.failed && <p role="alert">{t.meetingAsrReadonlyUnavailable}</p>}
      <button type="button" onClick={() => { modelFacts.refresh(); asrFacts.refresh(); }}>{t.desktopReadonlyRetry}</button>
      <Section>
        <SectionHeader icon={Mic}>{ds.meetingRecordingSettingsTitle}</SectionHeader>
        <p className="mb-4 text-sm leading-6 text-[var(--c-text-secondary)]">{ds.meetingRecordingSettingsDesc}</p>
        <Card>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="block">
              <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrDefaultProvider}</span>
              <select
                value={engine}
                onChange={event => updateEngine(event.target.value as MeetingTranscriberEngine)}
                aria-label={ds.meetingAsrDefaultProvider}
                className={inputCls}
              >
                {MEETING_TRANSCRIBER_ENGINE_OPTIONS.map(option => (
                  <option key={option} value={option}>{engineLabels[option]}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{t.knowledge.meetingLanguageLabel}</span>
              <select
                value={language}
                onChange={event => updateLanguage(event.target.value as MeetingTranscriberLanguage)}
                aria-label={t.knowledge.meetingLanguageLabel}
                className={inputCls}
              >
                {MEETING_TRANSCRIBER_LANGUAGE_OPTIONS.map(option => (
                  <option key={option} value={option}>{languageLabels[option]}</option>
                ))}
              </select>
            </label>
          </div>
          {isLocalMeetingTranscriberEngine(engine) && (
            <label className="mt-4 block">
              <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{t.knowledge.meetingSpeechModelLabel}</span>
              <select
                value={model}
                onChange={event => updateModel(event.target.value as MeetingTranscriberModel)}
                aria-label={t.knowledge.meetingSpeechModelLabel}
                className={inputCls}
              >
                {visibleModelOptions.map(option => (
                  <option key={option} value={option}>{modelOptionLabel(option)}</option>
                ))}
              </select>
            </label>
          )}
        </Card>
      </Section>

      <Section>
        <SectionHeader icon={Package}>{ds.meetingRecordingLocalModelsTitle}</SectionHeader>
        <Card>
          <div className="mb-3 flex items-center justify-between gap-3">
            <p className="text-sm text-[var(--c-text-secondary)]">{t.knowledge.meetingModelDownloadStatusTitle}</p>
            {modelStatusesLoading && <span className="text-xs text-[var(--c-text-tertiary)]">{t.knowledge.meetingModelStatusLoading}</span>}
          </div>
          {modelStatusesError && <p className="text-xs leading-5 text-red-600">{modelStatusesError}</p>}
          {groupedModelStatuses.length > 0 ? (
            <div className="space-y-4">
              {groupedModelStatuses.map(group => (
                <div key={group.id} className="space-y-2">
                  <p className="text-xs font-medium text-[var(--c-text-tertiary)]">{group.title}</p>
                  {group.models.map(renderModelStatusRow)}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs leading-5 text-[var(--c-text-tertiary)]">{modelFacts.data === null ? t.meetingModelsReadonlyUnknown : t.knowledge.meetingModelStatusUnavailable}</p>
          )}
        </Card>
      </Section>

      <Section>
        <SectionHeader icon={Server}>{ds.meetingRecordingOnlineProvidersTitle}</SectionHeader>
        <Card>
          <div className="space-y-5">
            <div className="rounded-lg border border-[var(--c-border)] p-3">
              <div className="mb-3 flex items-center justify-between gap-3">
                <p className="text-sm font-medium text-[var(--c-text-primary)]">{ds.meetingAsrVolcengineTitle}</p>
                {renderProviderStatus(asrConfig?.volcengine?.configured)}
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <label className="block">
                  <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrAppKey}</span>
                  <input
                    type="password"
                    value={asrDraft.volcAppKey}
                    onChange={event => setAsrDraft(prev => ({ ...prev, volcAppKey: event.target.value }))}
                    aria-label={`${ds.meetingAsrVolcengineTitle} ${ds.meetingAsrAppKey}`}
                    placeholder={asrConfig?.volcengine?.appKeyConfigured ? ds.meetingAsrConfigured : ds.meetingAsrAppKey}
                    className={inputCls}
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrAccessKey}</span>
                  <input
                    type="password"
                    value={asrDraft.volcAccessKey}
                    onChange={event => setAsrDraft(prev => ({ ...prev, volcAccessKey: event.target.value }))}
                    aria-label={`${ds.meetingAsrVolcengineTitle} ${ds.meetingAsrAccessKey}`}
                    placeholder={asrConfig?.volcengine?.accessKeyConfigured ? ds.meetingAsrConfigured : ds.meetingAsrAccessKey}
                    className={inputCls}
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrEndpoint}</span>
                  <input
                    value={asrDraft.volcEndpoint}
                    onChange={event => setAsrDraft(prev => ({ ...prev, volcEndpoint: event.target.value }))}
                    aria-label={`${ds.meetingAsrVolcengineTitle} ${ds.meetingAsrEndpoint}`}
                    className={inputCls}
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrResourceId}</span>
                  <input
                    value={asrDraft.volcResourceId}
                    onChange={event => setAsrDraft(prev => ({ ...prev, volcResourceId: event.target.value }))}
                    aria-label={`${ds.meetingAsrVolcengineTitle} ${ds.meetingAsrResourceId}`}
                    className={inputCls}
                  />
                </label>
              </div>
            </div>

            <div className="rounded-lg border border-[var(--c-border)] p-3">
              <div className="mb-3 flex items-center justify-between gap-3">
                <p className="text-sm font-medium text-[var(--c-text-primary)]">{ds.meetingAsrAliyunTitle}</p>
                {renderProviderStatus(asrConfig?.aliyun?.configured)}
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <label className="block">
                  <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrApiKey}</span>
                  <input
                    type="password"
                    value={asrDraft.aliyunApiKey}
                    onChange={event => setAsrDraft(prev => ({ ...prev, aliyunApiKey: event.target.value }))}
                    aria-label={`${ds.meetingAsrAliyunTitle} ${ds.meetingAsrApiKey}`}
                    placeholder={asrConfig?.aliyun?.apiKeyConfigured ? ds.meetingAsrConfigured : ds.meetingAsrApiKey}
                    className={inputCls}
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-xs text-[var(--c-text-secondary)]">{ds.meetingAsrBaseUrl}</span>
                  <input
                    value={asrDraft.aliyunBaseUrl}
                    onChange={event => setAsrDraft(prev => ({ ...prev, aliyunBaseUrl: event.target.value }))}
                    aria-label={`${ds.meetingAsrAliyunTitle} ${ds.meetingAsrBaseUrl}`}
                    className={inputCls}
                  />
                </label>
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between gap-3">
            <div className="min-w-0">
              {saved && <p className="text-xs text-green-700">{ds.meetingAsrSaved}</p>}
              {saveError && <p className="text-xs text-red-600">{saveError}</p>}
            </div>
            <button type="button" onClick={() => void handleSaveMeetingAsrConfig()} disabled={saving} className={btnPrimary}>
              {saving ? ds.meetingAsrSaving : ds.meetingAsrSave}
            </button>
          </div>
        </Card>
      </Section>
    </div>
  );
}
```

## Actual desktop/electron/main.ts:190 authorizeDesktopInvoke full function; full-file SHA256 38f63f6ca5a6523b1c32ea3289cfdc9429254a03d988f5db597e89f37b410996
```typescript
function authorizeDesktopInvoke(event: Electron.IpcMainInvokeEvent): void {
  try {
    const sender = event.sender;
    if (!sender || sender.isDestroyed()) throw new Error('desktop_user_sender_forbidden');
    const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
    if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
      throw new Error('desktop_user_sender_forbidden');
    }
    const frame = event.senderFrame;
    if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
      rendererFile: join(__dirname, '../../../renderer/index.html'),
      devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
    })) throw new Error('desktop_user_sender_forbidden');
  } catch {
    // Teardown failures are unavailable caller facts, never an admission grant.
    throw new Error('desktop_user_sender_forbidden');
  }
}
```
