核对完成：r2 源/依赖 packet 与磁盘实际文件逐字一致(两个新 main 文件、ipc.ts:1829-1834、model-service truthful 路径、hook、preload.cjs:470-476 均已抽查)，消费面 census 独立复核通过。

## APPROVE_CODE

无阻断发现。关键核验：

- **解析修复(RED 闭环)**:`desktop/electron/meeting-readonly-data.ts:32-33` 仅 `JSON.parse` 被 catch 并替换为固定 `meeting_readonly_projection_unavailable`,无凭据片段外泄(controls 测试断言 `String(error)` 不含 owned-fake);`:25-26` 非 ENOENT 读错误与其余业务异常保持原始 reject 身份，无 repair/chmod/.bak。
- **auth 先于输入**:ShutdownAwareIpcMain admitInvoke 先于 listener 输入解析，controls 测试 getter 计数 0;tuple0(`z.tuple([])`),超参 → `meeting_readonly_input_invalid`,输入捕获不执行 accessor。
- **每 invoke 完整 DTO**:`meeting-readonly-typed-ipc.ts:15-19` captureIpcData 逐次深拷贝 + `assertStandardIpcPromise` + 原生 then,业务 rejection 直通;producer 缺失 → `meeting_readonly_runtime_unavailable`。
- **真 ENOENT 精确默认**(`:29`,不创建 config 文件)；truthful 仅用于 listModels(`ipc.ts:1832`),download/uninstall/saveAsrConfig 保留默认容忍语义；SHA 全读、requiredFiles、future 元数据(passthrough)保留；权限枚举含 unsupported,getStatus 无 prompt。
- **Core3 零字节改动**：六文件 SHA 与 b9a54811 一致；preload 仅类型改动，CJS 零 ABI。
- **消费面**：VoicePane 实际挂载(`DesktopSettings.tsx:304`);KnowledgePage `loadMeetingAsrConfig`(:699)与 handleDownload/Uninstall(:648/:669)确认无调用点，LegacyMeetingRecorderDialog 未挂载，未新增自动读取；共享 useDesktopReadonly(未改动)的 null-unknown/last-good/单队列 retry/locale 过期/unmount 过期/动作错误独立均有 consumers 测试覆盖。
- **gate drain 5000 原样**，token 仅在真实 settle 后释放；punctuation-worker 换真实 class+construct spy,原 config/计数/addPunct/result 断言全保留；rolloutRound 33 与 ipc-runtime 类型扩展一致。

## 残余限制

- Windows ACL 故障夹具未做(现有 chmod 夹具 POSIX-only),按约定继续 OPEN,不作 Windows 验收。
- `normalizeConfig` 对非 meeting 段的异常身份可能回显字段值——存量行为，本次改动未扩大暴露面(反而前置捕获+schema 校验收窄了触发面)。
- 共享 hook 内部错误码仍叫 `skill_readonly_projection_unavailable`(渲染器内部、不外显)，仅命名瑕疵。
- 本次以 gates 摘要 + 磁盘抽查为准，未重跑测试、未整读 Vitest JSON;2 个 pending 为原始条件性真实转写 E2E 跳过，不作验收。
- PR37 全 HEAD 质量 NOT RUN;SOURCE 221→+3 仅在全部 meeting gate 批准后生效；合并决定权在 founder。