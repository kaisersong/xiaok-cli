# Meeting 三个只读 IPC 合同（2026-10-12 恢复）

本组只覆盖原 298 人口中的 `getMicrophonePermission`、`getAsrConfig`、`listModels`，round33。当前源码累计为 224/298、剩余 74：DESIGN 与最终 fresh CODE R2 均由明确指定的 GLM-5.3 通过。编码模型为 GPT-6。PR37 是完整历史 unfinished 快照，本组审批不等于最终完整 PR HEAD 质量通过；创始人决定合并，代理不合并。

三个输入均为严格零参数 tuple，先快照再校验；保留真实 Main/Recorder、frame/url 与 shutdown wrapper 许可，标准 Promise 检查、完整输出校验和每次调用独立 DTO。投影、访问、解析失败沿 reject 传播，不能改成成功空列表或默认配置。读取不调用麦克风授权、下载、卸载、保存或转录动作。

麦克风只保留原平台语义：Darwin 查询系统状态，not-determined 映射 prompt，未来状态映射 unknown，其他平台保留 unknown；完整输出 enum 包含原有 unsupported。没有新增自动权限请求。ASR 复用原 snapshot 与 normalizer，Desktop 专用 reader 只把真实 ENOENT 视为初始默认，其余访问、版本及自身 meeting/asr 结构失败拒绝；不 chmod、repair 或备份，不返回凭证字符串。Core config/types/normalize 三文件字节相同。

模型服务增加仅 listModels 启用的 `readonlyIoPolicy: 'truthful'`；stat/read/目录访问异常整体拒绝，真实缺失保持原 missing。原注册表七行、完整 DTO、单文件 SHA 全量读取、目录 required-files 行为保留。目录 verified 继续表示原所需文件存在，不代表签名/native 包资格。默认 check/download/uninstall 与三个标点/Sherpa/local 兄弟生产文件字节相同。

实际挂载消费位置是 `DesktopSettings.tsx:304` 的 VoicePane；KnowledgePage 的 `loadMeetingAsrConfig:699` 和 `LegacyMeetingRecorderDialog:2574` 在当前 AST 只有声明，两个模型操作 handler 也只有声明，未给这些旧代码新增自动读取。定位证据为 `consumer-census-r1.json`（完整 SHA、行号和语法位置）。VoicePane 每事实一个读取 owner，初始未知、失败固定本地化提示，保留 last-good；手动刷新合并一个后继，locale/unmount 使旧回执失效，读取刷新不重放下载或清掉动作错误。

本轮原始记录目录为 `.artifacts/unfinished-closure-20261001/meeting-readonly3-20261012-recovery-r1`。主进程 RED 5 个失败、UI RED 6 个失败、存储结构 RED 6 个失败均保留。whole-r1 中错误的 IPC 结果超时断言已修正为实际 `gate.drain(5000)`；未延长期限。一个知识搜索测试首轮失败后完整重跑通过，源码和该测试未修改。标点 worker 旧 fixture 的构造器类型改为真实 class 加 construct spy，原配置、单次构造、addPunct 与结果断言均保留。

当前相关 whole-r4：124 文件，1348 通过，原真实转录 E2E 两项条件跳过未计通过；strict-r5：Main 397 roots/1838 sources、renderer 35 roots/2061 sources，noCheck:false、诊断 0。Gov/增量架构/最终十测试 lint 无新问题，实际 Main 和 renderer 构建 exit0。Electron 组件探针 17 调用、11 次 producer、3 次真实 Darwin 状态查询、请求授权 0、token0；未知同 URL 窗口与旧 Main 拒绝，实际损坏配置和自有缓存 EACCES 拒绝。仅自有临时目录，进程真实 wait/reap/groupGone 后已删除。

自查用当前 Node 24.16.0 实证 JSON.parse 错误会反射凭证片段；真实 Main IPC RED 16pass/1fail 后，reader 仅捕获解析错误并返回固定 `meeting_readonly_projection_unavailable`，原 I/O 拒绝语义保留。首轮 CODE 仍在运行时仅终止记录的自有组，actual exit143/wait/reap/groupGone/零漂移，没有审批结论。完整复验和新 Electron 错误通道控制已通过；最终完整组件 fresh CODE R2 APPROVE_CODE，实际 exit0/wait/reap/groupGone/零漂移，实际 init model=GLM-5.3。错误的探针生成器路径替换也保留失败记录，未启动 Electron，只删除内容和仓库路径精确匹配的自有临时根。

未跑或未完成：正常安装、全 UI、真实转录、Windows ACL/受保护 NTFS、native 父资格、全部 writer、最新主干及兄弟集成、最终完整 PR HEAD 质量、同 SHA Desktop tag/CLI 包发布链。新增 POSIX chmod 故障 fixture 仍需要实际 Windows ACL 对照，不能跳过或当成 Windows 验收。原 meeting 人口 17 包括本组只读 3，源码组件通过后仍有 14 个操作入口；这些入口包括动作、对话框与生命周期，并非统一为破坏性 writer。

原父 176/351/99、15s RPC/300s roundtrip/3600s、14/Loop13 失败、84 paired、50/100/512MiB、all-writers/history/principals/migration/restart/retirement/adopt、真实 CLI/UI/TTY/安装/包/latest-main/live-CI 全部保留。原 native R46/R47、materials firstwrite 和 performance P4 自动中断动作不改名重试。用户最新规则立即生效：先分支再 PR，精确 stage，提交前检查两个 diff stat；不同实际模型审查 P0/P1，最终完整 HEAD 质量由完整 SHA 定位；创始人合并，代理不合并。

正式源码提交：`4772d6d4e47b3ed44b1a86853a8a12b85c427a18`。已检查 diff stat 与 cached stat，精确提交 22 源码/测试文件；dist/build-info 和原 foreign handoff-migration 未纳入。32 个本组自有 supervisor 进程均实际回收，重建不替代父安装/包资格。完整 PR HEAD 在证据提交后另行记录，整 PR 质量仍未跑。
