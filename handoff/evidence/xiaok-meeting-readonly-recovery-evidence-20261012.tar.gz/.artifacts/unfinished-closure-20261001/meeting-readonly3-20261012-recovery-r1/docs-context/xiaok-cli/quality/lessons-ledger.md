# 工程经验台账（由 CTO 维护，每周复盘第一项过一遍）

规则：一条经验只有挂上「执行机制」才算记录完成。只写在某个人的记忆或聊天里的，不算。
执行机制可以是：CI 检查、自动化测试、发版清单里的一行、PR 模板里的一项、仓库 AGENTS.md 里的一条规则。

| # | 日期 | 发生了什么 | 根因 | 规则 | 执行机制 | 负责人 | 状态 |
|---|---|---|---|---|---|---|---|
| 1 | 2026-10-10 | 66 条测试失败被当成环境问题，CI 却是绿的 | CI 根本不跑那 5 个聊天与异步任务测试文件 | 「CI 是绿的」不能当证据，发版前这些测试必须在 CI 里真跑过并通过 | 发版门槛第 5 项；那 5 个文件加入 CI | CTO | 待推 |
| 2 | 2026-10-10 | 1.5.11 已发布，才发现权限、环境变量、空闲退出三项加固没进版本 | 验证对象是源码和 PR，不是发布产物 | 发版门槛要在已发布的安装包和 tgz 上复验，不按源码推断 | 发版清单加「发布产物复验」一节 | 质量 | 待写 |
| 3 | 2026-10-10 | 测试用 `tmux kill-server` 可能误杀同机其他人的会话 | 共用同一台机器 | tmux 只用独立 socket（`tmux -L qa`），只关自己的会话 | AGENTS.md 里的测试收尾规则 | 质量 | 待写 |
| 4 | 2026-10-10 | 全量测试泄漏 59 个后台进程，占约 13.6 GB 内存 | 后台进程没有空闲退出，测试不回收 | 测试收尾必须回收自己起的进程并报数量 | 测试 teardown + 收尾清单 | 开发 | #23 修空闲退出，测试 PR 待开 |
| 5 | 2026-10-10 | 说「文件已放好」「评论已发」，实际没写成功 | 发消息和写文件在同一步，没有先核对 | 汇报「已完成」之前先核对结果真的存在 | 各助手长期记忆；交付前核对清单 | 全员 | 已记 |
| 6 | 2026-10-10 | 递归收紧权限会把共享目录里的可执行脚本改成 600 | 数据根目录与 Desktop 共享 | 权限收紧只作用于自己创建的专用子目录，不递归共享目录，不跟随链接 | #23 验收用例 | 开发 | 复验中 |
| 7 | 2026-10-10 | GLM 反复「卡住」，起初被记成「大输入无响应」，实际是 5 小时额度用完（错误码 1308），xiaok 还在无限重试 | 没有先看接口返回就下了结论 | 模型调用异常先直接调接口看错误码，再定性；额度类错误码要立刻提示并切换模型，不重试 | 降级 PR 的 1308 用例；缺陷记录里必须写接口返回原文 | 开发 | 降级 PR 待开 |
| 8 | 2026-10-10 | 引擎最低版本只写 `>=22`，CI 只测最新补丁版，22.12 到 22.13 上崩溃或段错误没被发现 | 测试矩阵没覆盖声明的最低版本 | CI 矩阵必须包含 `engines` 声明的最低版本 | CI 加 Node 22.12 / 22.14 矩阵（待 #23 合并后推） | CTO | 待推 |
| 9 | 2026-10-10 | 创始人提前发了 1.5.11，计划中的加固没进版本 | 发版范围和时点变化没有同步到流程 | 发版范围在发版前由质量对着「发版门槛」逐项确认；创始人决定提前发时，我们当场出一份「已知未覆盖项」 | 发版门槛清单；周复盘检查 | CTO、质量 | 待写 |
| 10 | 2026-10-10 | 更新定时任务时误把原提示词整个覆盖了，只能凭复盘文件重写 | 没先读原文就执行，且把「读」和「改」并行调用 | 修改定时任务前先取到完整原文并留档；读取和修改不能放在同一批并行调用里 | 定时任务提示词备份到 mydocs；各助手长期记忆 | CTO | 已记 |

| 11 | 2026-10-10 | 机器被恢复后，复验报告里混入了没有实测的数字（误把对话摘要里的数据当成本轮结果） | 恢复后原始日志丢失，用记忆里的数字补空 | 报告里的每个数字必须对应一份原始日志；机器恢复后不能用对话摘要当证据，要重测 | 复验报告模板加「原始日志路径」一列；周复盘抽查 | 质量 | 待写 |

| 12 | 2026-10-10 | 清理自己的后台进程时用 `kill $(pgrep -f "daemon serve")`，误杀了同机质量的 4 个进程 | 按命令名匹配，不区分谁起的 | 只按自己记录的 pid 或自己的工作目录路径清理进程，不按命令名批量杀；起进程时把 pid 记到自己的文件里 | AGENTS.md 测试收尾规则（待 #25 追加）；测试脚本用 pid 文件清理 | 开发 | 待写 |

| 13 | 2026-10-10 | 「`critical_only` 没有行为」一句话从估算传到 PRD、缺陷表、设计稿和 CTO 的架构文档，差点据此隐藏一个有效选项，还登记了一条误报缺陷 | 各方转引别人写的「现在没有/不生效」，没人自己读码核实，CTO 的审计也把它写成了「无行为」 | 凡写「现在没有行为 / 不生效 / 不存在」的结论，必须附写者自己读到的 `文件:行号` 或运行结果；转引他人结论要标「转引、未核实」 | 缺陷登记模板加必填「依据」字段（质量）；PRD、设计稿评审清单加一行（产品经理、设计师）；PR 模板加一项（开发） | 全员，CTO 抽查 | 已挂（待 #25 合并后开发项生效）：产品经理（PRD 第 21 节）、设计师（界面稿评审清单）、质量（缺陷表「依据」必填，已同步 mydocs）、开发（AGENTS.md 与 PR 模板，在 #25 内） |

| 14 | 2026-10-11 | 2 秒轮询若每个 tick 都递增 generation，超过 2 秒的有效响应会一直被丢弃；singleflight 后手工刷新又可能丢失 | 把定时读取与明确刷新请求使用了同一套重叠处理 | 一个读取 owner 保持 singleflight；忙时定时 tick 跳过，明确手工刷新最多排一次，卸载使旧回执失效 | `desktop/tests/renderer/plugin-catalog-mcp-read-errors.test.tsx` 的 held 超过 2 秒回归；`desktop/tests/renderer/plugin-catalog-read-errors.test.tsx` 的 held 后手工重读回归。原始日志：`catalog3-ipc-design-20261011-r1/actual-manual-queue-green-r15.json`；新机完整 10files91 项及独审见 `resume-kk-20261011/catalog-complete-green-r1.log`、`joint-formal-code-supplement-r2.log` | 开发 | 源码组件 CODE 已通过；父验收、实际安装/native 层仍未完成 |

| 15 | 2026-10-11 | Updater owner 的投影异常被 Main catch 包装成全零成功 DTO，导致 UI 覆盖 last-good | 把读取失败与成功空状态混在同一返回合同，原 NaN 返回测试没覆盖实际 throw 路径 | 投影读取 throw 沿 IPC reject 传播；合法 error 状态仍成功；读取失败保留已知事实，不读取任意异常对象 getter | `desktop/tests/main/updater-main-controls.test.ts` 的真实 Main throw/零 message 读取/版本读取/合法 SDK error 控制；原始 RED 与完整 14files148 项 GREEN：`resume-kk-20261011/updater-main-red-r1.log`、`updater-whole-green-r3.log` | 开发 | 独立 DESIGN/CODE 通过，源码组件关闭原 R47 BLOCK；父验收未完成 |

| 16 | 2026-10-11 | 只给敏感 mobile RPC 加门仍可从同权限文件读取绕过；限制 Recorder 为5生命周期命令又会破坏其完整 provider/Knowledge/ASR 用户链 | 来源闸门未覆盖唯一 raw owner，窗口权限人口只按局部命令估计 | 同权限全部 invoke 在唯一 owner 的原 shutdown token 内鉴别真实 current应用窗口/mainFrame/精确renderer URL；保留合法Recorder完整入口和更细权限，生产绑定必须有源AST证明 | `desktop/tests/main/desktop-invoke-admission.test.ts`、原 `ipc-registrar-contract.test.ts` 精确raw2与实名三参绑定；原始 RED/47files454与真实Electron5：`complete-main-20261011-r1/owned-window-red-r1.log`、`owned-window-whole-r2.log`、`native-admission-results-r3.json` | 开发 | 共同底座独立CODE通过；typed新增0，mobile2与父实际UI/安装/Windows验收未完成 |


| 17 | 2026-10-11 | 配对刷新先切 deepLink 再生成 QR，导致画面与复制内容错配；held 状态读取覆盖新事件；事件日志先读原 getter | 异步数据和衍生图像分开发布，读取与事件缺少时序，校验晚于日志 | 配对与 QR 原子发布，失败保 last-good；lifetime 单飞与 event revision 阻止旧回执；capture 必须先于任何 debug 字段读取 | `desktop/tests/main/mobile-readonly-main-controls.test.ts` 真实 Main/owner/事件 getter 与完整敏感 DTO；`desktop/tests/renderer/mobile-readonly-consistency.test.tsx` 真实页面 held QR/read、失败、locale/unmount 与只读重试。原始 RED36=13/23、整55files540/540、native10 surrogate IPC 与独审见 `mobile-readonly2-20261011-kk-r1/` | 开发 | 独立 DESIGN/CODE 通过，只关闭原 Mobile readonly2；父验收与 legacy projection 债务未完成 |


| 18 | 2026-10-12 | SDK未知服务id落到Broker重启，bridge初始化前重启为空成功，production输出违约信封可成为void假ACK；旧drain fault已被新SDKcatch吞掉 | raw目标无约束、placeholder成功、依赖通用输出兜底；旧测试不再真正触发拒绝 | Main UI facade验证目标与来源、placeholder拒绝、输出边界直接reject；读取和action错误/lifetime独立；失败测试必须真的令原准入工作reject | `service-control-main-controls/facade/sdk-characterization/preload` 与真实 GeneralPane `service-control-read-errors`；原SDK/drain修正独审票与66files726/726、严格完整types及native12 surrogate IPC见 `service-control2-20261012-kk-r1/` | 开发 | 独立 DESIGN/TEST_FIX/CODE通过，仅service-control2源码关闭；父平台/native/实际sidecar与全部父验收未完成 |

| 19 | 2026-10-12 | Relay 登录丢弃 OS Promise 后立即成功，错误 URL 路径/凭证可进入浏览器；原设计 fallback getter 测试遗漏 | 外部副作用 ACK 早于事实完成，未知返回当成功，测试矩阵未逐项闭合 | nativePromise<void> 严格确认后构造 DTO；事实先 capture、user 来源门、单飞/原 shutdown token；UI 独立动作错误；CODE 通过仍核原设计验收，不以非阻塞建议放弃条件 | `mobile-signin-main-controls/contract/action`、旧 Main fallback 两目标真实因果 RED、完整69files780/780及完整strict0、CODE+supplement见 `mobile-signin1-20261012-kk-r1/` | 开发 | 仅原 signIn1 源码组件关闭；OS 打开/真实登录/安装与全部父门未完成；独审文字错误另作事实更正且保原票 |

| 20 | 2026-10-12 | 自动运行开关保存失败前已更新 Main，UI读失败造 enabled=true/健康零状态，旧读取回写新动作结果 | 持久化完成与事实发布混同，重复读取缺代际，旧 mock/源码断言未跟真实契约 | 同 JS turn semantic 编辑、确认后发布；其它 writer 债务真实保留；一 read owner/lastgood/动作 revision/独立错误；原测试修正须独审，不放宽输入/删负例 | 真实 Main/UI RED55→55green、相关83/905与CLI7/143、完整strict0/native15自有config写；旧样本/源码断言及纯type修正独审见 automations-config3-20261012-kk-r1 | 开发 | 仅原 config3 源码关闭；全局事务/allwriters/native/安装/完整父门开放，独审计数文字错误另作事实更正 |

| 21 | 2026-10-12 | 技能页面读取失败测试全绿，但实际 bridge 仍 catch 成空数组；Windows 外部技能名与周统计/详情 NaN 也漏测 | 页面测试在 API 层替换生产 bridge，未把 IPC 拒绝穿过真实 adapter；卡片局部保护未覆盖完整消费者 | UI mock 测试须配真实 bridge/preload 拒绝控制；读取 unavailable 与真实空值分开；历史非有限 DTO 保留，所有显示消费者用本地化 unknown | `skills-readonly-bridge/preload/consumers` 与恢复真 RED 119=111/8→119/119；97files1105、CLI12files187、严格 configs0、两构建与 own Electron source IPC11，独审见 skills-readonly2-20261012-kk-r1 recovery 证据 | 开发 | 独立 fresh CODE R2通过，仅原 readonly2源码关闭，219/298；全部父门开放 |

| 22 | 2026-10-12 | 通道读取坏配置会 chmod/backup 后返默认；MCP坏JSON假空，非数组能进页面map崩溃；normalizer还把坏channels数组消成空对象 | 只验证投影DTO不足以判定数据源正常，读取与修复/破坏性writer混同；会话hygiene未归入组件证据 | Main独立纯读取、真ENOENT-only缺失、normalize前后行规则整表拒绝、只读与动作错误独立；before/after gate原始失败照实留票 | real RED24=7/17→24，坏数组174=173/1→174；全部104files1204、完整strict0、nativeIPC12和CODE+SUP；Core3 SHA不变，hygiene before/after exit1/sibling债保父门 | 开发 | 仅readonly2源码关闭，221/298；mutation7/allwriter/正常安装/Windows/全部父门开放 |

## 使用方式
1. 每条缺陷关闭、每次发版复盘，都要问一句「有没有经验要写进台账」，PR 模板加这一项。
2. 每周的 AI Native 工程复盘第一项：过一遍台账，凡是「执行机制」还空着的，当周必须挂上或明确放弃。
3. 所有助手开工前读本台账和仓库的 AGENTS.md；派出子任务时把相关条目带进去。

| 23 | 2026-10-12 | ASR 读取沿真实 reject 传播后，Node JSON.parse 错误会反射损坏配置中的凭证片段；页面固定提示不能保护 IPC 错误通道 | 只检查成功 DTO 不含凭证，漏了真实解析异常字符串 | 成功 DTO 与实际错误通道都测凭证片段；解析失败固定投影错误码，I/O 与业务拒绝保持事实；发现问题先留真 RED 再审最终源 | `meeting-readonly-controls.test.ts` 真实 Main RED16/1、whole-r4 124files1348pass2原条件跳过、Electron R2 错误通道固定码/no owned-fake、严格0/两build0/fresh GLM-5.3 CODE R2；原日志与手动过时审查 exit143 保留 | 开发 | 仅源码 readonly3 关闭，224/298；Windows ACL、安装/全部 UI/native/全部父门开放，创始人决定合并 |
