import { mkdtempSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join,resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import {createHash} from 'node:crypto';
const r=process.cwd(),e=resolve(r,'.artifacts/unfinished-closure-20261001/meeting-readonly3-20261012-recovery-r1');
const {createMeetingAudioPermissionService}=await import(pathToFileURL(join(r,'desktop/dist/main/desktop/electron/meeting-audio-permission.js')).href);
const {createMeetingModelService}=await import(pathToFileURL(join(r,'desktop/dist/main/desktop/electron/meeting-model-service.js')).href);
const {createMeetingAsrConfigSnapshot}=await import(pathToFileURL(join(r,'desktop/dist/main/desktop/electron/meeting-asr-config.js')).href);
const {DEFAULT_CONFIG}=await import(pathToFileURL(join(r,'desktop/dist/main/src/types.js')).href);
const root=mkdtempSync(join(tmpdir(),'meeting-readonly-characterization-')),results=[];let asks=0,downloads=0;
try{
 for(const platform of ['darwin','win32'])for(const status of ['granted','denied','restricted','not-determined','future-status']){
  const owner=createMeetingAudioPermissionService({platform,getMediaAccessStatus:()=>status,askForMediaAccess:async()=>{asks++;throw Error('readonly_must_not_prompt')}});results.push({kind:'permission',platform,inputStatus:status,result:await owner.getStatus()});
 }
 const data=Buffer.from('owned model'),hash=createHash('sha256').update(data).digest('hex');const service=createMeetingModelService({cacheDir:root,models:[{id:'owned',fileName:'owned.pt',url:'https://owned.invalid/model',expectedSizeBytes:data.length,expectedSha256:hash}],downloadFile:async()=>{downloads++;throw Error('readonly_must_not_download')}});
 results.push({kind:'model-missing',result:service.listModels()});writeFileSync(join(root,'owned.pt'),data);results.push({kind:'model-ready',result:service.listModels()});writeFileSync(join(root,'owned.pt'),'x');results.push({kind:'model-size-mismatch',result:service.listModels()});writeFileSync(join(root,'owned.pt'),'wrong model');results.push({kind:'model-hash-mismatch',result:service.listModels()});
 results.push({kind:'asr-default',result:createMeetingAsrConfigSnapshot(structuredClone(DEFAULT_CONFIG))});
 writeFileSync(join(e,'characterization-current-r1.json'),JSON.stringify({actualCompiledProductionServices:true,ownTemporaryModelOnly:true,OSDependencySurrogates:true,actualOSPermissionNotClaimed:true,asks,downloads,results,sourceOnlyNotAccepted:true},null,2),{flag:'wx'});
}finally{rmSync(root,{recursive:true,force:true});writeFileSync(join(e,'characterization-cleanup-r1.json'),JSON.stringify({root,removed:!existsSync(root)}),{flag:'wx'});}
console.log(JSON.stringify({cases:results.length,asks,downloads,increment:0}));
