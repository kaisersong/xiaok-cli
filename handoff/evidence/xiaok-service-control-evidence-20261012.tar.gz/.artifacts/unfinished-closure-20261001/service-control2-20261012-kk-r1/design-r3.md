# 服务状态/重启两个入口的完整合同

设计待独立评审；当前正式211/298、剩87。此组未计数，父任务与条件主干合并仍未放行。

## 实际源码事实

Main 直接注册 `desktop:services:getStatus` 和 `desktop:services:restart`。getStatus await KSwarm SDK snapshot 后先 spread 对象及 services 数组，再追加 Runtime Bridge；owner getter 可以在任何 transport 校验之前执行。两个 raw handler 都无 tuple/full DTO 校验。restart 的 serviceId 任意值除 runtime-bridge 外直接传 SDK；SDK restartRelatedService 的实际实现是 kswarm 分支，否则 stopOwnedBroker/ensureBroker，故未知 id 会产生 Broker 重启副作用。Runtime Bridge 的 Main callback 初始为 async 空函数，赋值真正 stop/start 函数以前，重启会成功空返回。

GeneralPane 已有状态、加载提示、错误与10秒读取，不假装缺少这些功能。实际缺陷：读取可重叠且旧结果覆盖新结果；卸载/locale effect 旧 finally 可清新 loading；读取和重启共用错误且定时读会清除重启失败；任意异常 message 显示；首次失败无只读重试。restartingService 是异步 state、只禁一个 row，用户可在同一帧/不同 row 触发多个指令。

同权限 SDK/transport census：Main raw kswarm getStatus/start/stop/restart/resumeWorkflowRun 五条、services 两条、proxy 内项目操作；所有 invoke 都经已独审唯一 Shutdown owner 的 current Main/current Recorder/mainFrame/可信 URL gate。两窗口是同一应用用户权限域，不收窄 Recorder。不新增 raw owner、caller token 或从 IPC 接受 requestSource。其余五条与 proxy 不被此票冒领，未资格仍在原298剩余；本设计是完整 transport 合同和错误展示，不宣称全局 SDK、agent、OS/native 或全盘权限已经修复。Skills 写入族的 Desktop/custom/builtin/write/bash 同权限问题另列原队列，不以此替代。

## Main 与共享协议

共享 service-control-ipc-contract：getStatus z.tuple([])，restart z.tuple([z.enum(['kswarm','intent-broker','runtime-bridge'])])。snapshot 完整 checkedAt finite number、services array；每项 id 原三枚举、label/string、running/reachable boolean、port finite number、pid nullable finite number、restartCount optional finite、lastError nullable string、detail optional string，所有对象 passthrough，不额外加 PID/端口/日期范围或新业务关联限制。restart 输出严格 void；未知/malformed 输出拒绝，不能当成功 ACK。

明确删除并替换 main.ts 两条原 raw handle，不保留重复注册。把原 let runtimeBridgeStarted=false 与 const runtimeBridgeClients: Array<{ start(): Promise<void>; stop(): void }>=[] 的两个声明（原 main.ts:1452-1453）原样前移到 facade 创建前，删除原后置声明，唯一 owner/类型/初值/后续写入保持；不会在创建时调用 getter。restartRuntimeBridgeService 原初始化声明与后来真正 stop/start 赋值保持相同逻辑位置，只把初始空 body 改固定throw。fact/getRestart 通过 fresh closure getter 注入，真实赋值函数不能缓存为旧placeholder。新增 Main-owned facade，真实 Main 创建并持有，getStatus 调实际 SDK 并用现有 captureIpcData+完整 schema 捕获基础 snapshot，捕获成功以后才 spread/append Runtime Bridge facts。元信息仍由 Main 的当前 runtimeBridgeStarted/clients getter产生，不产生新 owner 或轮询。SDK 原 getter/reference 保留；wire snapshot detached，不向 owner 写新默认状态。SDK promise 在 await/then assimilation 以前用现有 assertStandardIpcPromise 验标准 native promise/constructor/species，并用 captured intrinsic then 等待，原 producer throw/reject继续失败，不编造 empty success。

facade.restart(serviceId, requestSource) 显式服务来源参数，缺失/agent/scheduler 一律在 SDK或 bridge调用前拒绝；只允许由 Main 已鉴别的 handler 注入'user'，同时内部再验证 id，拒绝未知 id 与 prototype/flag式输入，避免 SDK 的 otherwise-Broker 分支。这是 Main 私有应用 UI facade 的来源合同；底层 SDK 其它 public lifecycle/bootstrap 路径与所有 agent/Native writer资格不因它改变或关闭。保持 SDK内原 ingress、owned PID/restart/timeout/Windows launch 逻辑，不重写或绕过此前中断的 native任务。

Runtime Bridge callback 初始抛固定 service_runtime_unavailable，不再成功空操作；后赋值实际 stopRuntimeBridge/startRuntimeBridge body与现有注册时序原样保留，facade调用fresh函数 getter，不缓存初始 placeholder。成功 void仅表示原重启调用返回，不等于随后所有 sidecar/clients 均已健康；健康状态仍从新 snapshot 展示。

typed registrar绑定真实Main producer map，幂等/owner冲突、标准 native promise、capture输入/输出全量快照；两个方法在 wrapper 内先 captureIpcData+完整output schema safeParse，失败直接抛对应固定错误，然后才交通用 ipc-runtime validateOutput。禁止依赖后者 production 默认 resolve {ok:false,error:ipc_contract_violation} 信封，restart RED必须断言reject且无假 ACK。不读 getter/proxy/toJSON/cycle/thenable。固定 round28，同步 ipc-runtime两处联合类型与两个具名census：desktop/tests/main/ipc-schema-coverage.test.ts 的 currentViewChannels、desktop/tests/main/preload-contract.test.ts 的 extractRegisteredHandlerChannels，均执行真实新registrar，所有原断言不删改。固定错误：service_input_invalid / service_projection_unavailable / service_operation_unknown / service_runtime_unavailable / service_request_source_forbidden。Main产出的异常传递；UI不直接显示未知异常 message。preload TS DTO关联共享schema，CJS/TS现有0参/1参语义API保持，不加source/grant参数。

## Renderer 原 owner 与异常路径

保留原10秒interval（不能改成另一时限或重启轮询）。一个 effect lifetime/ref 管读取：singleflight；定时 tick忙时跳过，明确手工只读刷新最多排一次；读取/旧finally仅在当前active lifetime发布或清busy，卸载/locale新life使旧回执失效。读取失败保last-good，不渲染成功空状态，locales三个文件加明确read unavailable和只读retry。初始失败也可retry，retry不触发任何restart。

读错误与重启结果未知分开状态：定时读取不能自动清除 mutation未知提示。显式重启调用使用同步ref防同帧双击，一个页面一次操作期间禁全部重启row；其后只刷新状态一次（通过同一读取owner），不自动重新执行重启。拒绝/丢ACK显示本地化未知结果与只读刷新，不把任何状态read当作原重启成功证明；用户后续显式新重启仍是新指令。action lifetime 与 read lifetime 分开：action只在组件卸载时失效，locale切换不取消同一页面正在进行的真实指令或丢掉其busy状态；action错误仅存固定kind并用当前t渲染，避免旧locale字符串写入。read lifetime的locale更换仍使旧read/finally失效；action成功后的读刷新只通过当时current read owner，不能复活旧读life。页面卸载后旧action不写新UI，业务动作不由renderer取消或重复发送。既有成功状态label、lastError/detail业务事实保留，不把它们全删掉。

此处不新增 backend SDK生命周期队列或“至多一次”承诺；并发窗口/CLI/bootstrap的生命周期、原 PID/retirement/history/allwriters 与真实签名链仍是父验收，不能用单页面busy证明。所有指令仍由原Main shutdown token和SDK ingress覆盖，测试必须明确hold直到实际producer settle，不提前释放或借UI timer替代。

## RED、完整回归与独审

先独立DESIGN，再RED，才production。Main AST编译真实constructor/authorize/注册代码；真实新facade/typed register/标准runtime。旧状态getter、错tuple/unknown-id触发Broker、初始化bridge虚假成功、source非user、completeDTO/detach、各种输出污染，须在真实入口红→绿。真正Main/Recorder均成功；unknown同URL/旧Main/subframe在getter/producer前拒；真实 gate held restart 后window消失仍hold直到settle。部分测试 mock仅不可执行的 SDK/process边界，不冒充真实安装或实际sidecar重启资格。

调用生产KSwarm SDK getServiceStatus/restartRelatedService实际函数或 AST 做原业务输出/分支表征；不在测试重写分支。保原全部kswarm-service、diagnostics、runtime-bridge、instance-drain、shutdown/preload/schema及旧GeneralPane服务状态用例；新增真实GeneralPane held>10秒、手工queue、失败last-good、locale/unmount、双击、多row与未知ACK/readonly重读。完整实际Main/renderer configs noCheckfalse、测试lint、governance/changed、两实际build、fresh独立CODE都通过后，此组件才能加2到213。

全体原父人口与时限完整继承 mobile后继父队列：298、176 consumers、351 broad files、99原15s/300s/3600s、14/Loop13、84paired、50/100/512MiB、全部writer/history/principals/migration/restart/retirement/adopt、Windows protectedNTFS/正常macOS安装、真实UI/TTY、无签名打包/安装/运行/下载、latest-main与最终精确提交/liveCI。原失败不覆盖，不改变baseline，不重试此前平台中断任务。最终全部做完才按已授权条件合并主干并测试，普通操作不再询问。

## R1 BLOCK 修正

明确替换两raw注册；原const clients与let started两个声明原样提前到facade创建之前、fresh getters与真实callback赋值时序保持；wrapper自身capture+schema直接reject而非通用production resolve信封；两census具名并保原断言。另明确action life不随locale取消、错误kind由当前locale展示，防止旧finally导致busy永久遗留。原BLOCK票与hygiene失败保留。
