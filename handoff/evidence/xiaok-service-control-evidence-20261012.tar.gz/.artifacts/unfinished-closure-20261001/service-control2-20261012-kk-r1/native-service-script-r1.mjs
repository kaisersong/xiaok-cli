import { app, BrowserWindow, ipcMain, screen } from 'electron';
import { writeFile } from 'node:fs/promises'; import { join, dirname } from 'node:path'; import { fileURLToPath } from 'node:url';
import { ShutdownAwareIpcMain, DesktopShutdownGate } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";
import { isTrustedDesktopRendererUrl, buildBrowserWindowOptions } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";
import { createMeetingRecorderWindowController } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import { registerServiceControlIpc } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/service-control-typed-ipc.js";
import { createDesktopServiceControl } from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/desktop-service-control.js";
const __dirname = dirname(fileURLToPath(import.meta.url)), root = "/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-service-control-probe-4qsuAP", rendererFile = "/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-service-control-probe-4qsuAP/desktop/dist/renderer/index.html";
app.setPath('userData', join(root, 'electron-user-data')); let mainWindow = null, meetingRecorderController = null;
function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

const gate = new DesktopShutdownGate(), shutdownAwareIpc = new ShutdownAwareIpcMain(ipcMain, gate, authorizeDesktopInvoke);
let statusReads = 0, restarts = 0;
const kswarmService = { getServiceStatus() { statusReads++; return Promise.resolve({ checkedAt: 123, services: [{ id: 'kswarm', label: 'Owned KSwarm', running: true, reachable: true, port: 4400, pid: 1, lastError: null, future: ['preserved'] }] }); }, restartRelatedService(id) { if (id !== 'kswarm') throw Error('unexpected_surrogate_target'); restarts++; return Promise.resolve(undefined); } };
const runtimeBridgeClients = [];
let runtimeBridgeStarted = false;
let restartRuntimeBridgeService = async () => { throw Error('service_runtime_unavailable'); };
const serviceControl = createDesktopServiceControl({
    getSdkSnapshot: () => kswarmService.getServiceStatus(),
    restartSdk: serviceId => kswarmService.restartRelatedService(serviceId),
    getRuntimeBridgeFacts: () => ({ started: runtimeBridgeStarted, clients: runtimeBridgeClients.length }),
    getRuntimeBridgeRestart: () => restartRuntimeBridgeService,
});

const serviceControlProducers = new Map([
    ['desktop:services:getStatus', () => serviceControl.getStatus()],
    ['desktop:services:restart', (_event, serviceId) => serviceControl.restart(serviceId, 'user')],
]);
registerServiceControlIpc(shutdownAwareIpc, serviceControlProducers);

const options = buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs", { platform: process.platform });
const results = [], methods = ['getServiceStatus', 'restartRelatedService'];
const invoke = async (role, window) => { for (const method of methods) results.push({ role, method, reply: await window.webContents.executeJavaScript('window.xiaokDesktop.' + method + (method === 'restartRelatedService' ? '("kswarm")' : '()') + '.then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))') }); };
const verify = (condition, code) => { if (!condition) throw Error(code); };
app.whenReady().then(async () => { try {
  mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile);
  meetingRecorderController = createMeetingRecorderWindowController({ BrowserWindow, getMainWindow: () => mainWindow, notificationPort: { show: async () => ({ ok: true }) }, platform: process.platform, preloadPath: "/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs", rendererFile, screen });
  await invoke('main', mainWindow); await meetingRecorderController.open({ collectionId: 'owned-native-services' });
  const recorder = BrowserWindow.getAllWindows().find(window => meetingRecorderController.ownsWebContents(window.webContents)); verify(!!recorder, 'actual_recorder_missing'); await invoke('recorder', recorder);
  const unknown = new BrowserWindow({ ...options, show: false }); await unknown.loadFile(rendererFile); await invoke('unknown-same-url', unknown);
  const old = mainWindow; mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile); await invoke('old-main', old); await invoke('replacement-main', mainWindow);
  for (const row of results) {
    if (['main', 'recorder', 'replacement-main'].includes(row.role)) {
      verify(row.reply.ok, row.role + ':' + row.method);
      if (row.method === 'getServiceStatus') verify(row.reply.value.checkedAt === 123 && row.reply.value.services[0].future[0] === 'preserved' && row.reply.value.services[1].id === 'runtime-bridge', 'status_changed');
      else verify(row.reply.value === undefined, 'false_restart_ack');
    } else verify(!row.reply.ok && row.reply.error.includes('desktop_user_sender_forbidden'), 'unowned_mobile_admitted');
  }
  for (const id of ['unknown-id','runtime-bridge']) { const reply = await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.restartRelatedService('+JSON.stringify(id)+').then(value=>({ok:true}),error=>({ok:false,error:String(error)}))'); verify(!reply.ok && reply.error.includes(id === 'unknown-id' ? 'service_input_invalid' : 'service_runtime_unavailable'), 'false_uninitialized_or_unknown_ack'); results.push({role:'main',method:'restartRelatedService',target:id,reply}); }
  verify(statusReads === 3 && restarts === 3, 'denied_control_reached_sdk'); verify(gate.outstanding === 0, 'ipc_token_leak');
  await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/service-control2-20261012-kk-r1/native-service-r1.json", JSON.stringify({ actualElectron: true, actualProductionAuthorizer: true, actualProductionShutdownOwner: true, actualProductionRecorderController: true, actualProductionPreload: true, actualTypedServiceRegistrar: true, actualMainProducerBody: true, actualMainFacade: true, ownedTemporaryRendererFixture: true, surrogateSdkBoundaryOnly: true, realCredentialsRead: false, installedAppOrWholeUiAccepted: false, protectedNativeAuthorityClaim: false, results, statusReads, restarts, gateOutstanding: gate.outstanding }, null, 2));
  meetingRecorderController.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.quit();
} catch (error) { console.error(error); meetingRecorderController?.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.exit(1); } }).catch(error => { console.error(error); app.exit(1); });
