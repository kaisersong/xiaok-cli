import type { PromptInjectionTexts } from "../shared/components/prompt-injection";
import type { RoomWorkspaceLabels } from './room-workspace';
import { zh } from "./zh";
import { en } from "./en";
import type { GuardFailure, HostDeliveryRecord } from '../../../../src/runtime/task-host/delivery-types';

export type Locale = "zh" | "en";

export interface LocaleStrings {
  loopPublication: import('./loop-publication').LoopPublicationLabels;
  observation: {enable:string;ready:string;cancel:string;stop:string;revoke:string;active:string;recallOnly:string;revokedStopping:string;revoked:string;unavailable:string;closed:string;failed:string;filesUnsupported:string;
    compoundExperiment:string;compoundStep:Record<'not_started'|'pending'|'denied'|'succeeded'|'failed'|'cancelled'|'unknown',string>;compoundEdit:(status:string)=>string;compoundValidation:(status:string)=>string;compoundUnknown:(count:number)=>string;
    semanticState:Record<'waiting'|'compacted'|'skipped'|'failed',string>;semanticReason:Record<'economics'|'changed'|'no-gain'|'budget'|'unavailable',string>;
    semanticBudget:(attempts:number,maximum:number,reserved:string,budget:string)=>string;semanticExperiment:string};
  diffView: { showFull: string };
  roomWorkspace: RoomWorkspaceLabels;
  localCodex: string;
  executionHealth: Record<'running' | 'waiting' | 'recovering' | 'cleanup_pending', string>;
  multiAgent: {
    approvals: { title: string; pending: (count: number) => string; approve: string; approveForTask: string; taskScope: string; details: string; deny: string; query: string;
      viewInput: string; nextInput: string; inputLoading: string; inputFailed: string; metadataFailed: string; retryMetadata: string;
      failure: string; deadline: (seconds: number) => string; unknown: string; received: string; currentPending: (count: number) => string;
      inputProgress: (start: number, read: number, total: number) => string; statuses: Record<string, string> };
    authorization: { workspaceLabel: string; title: string; scope: string; warning: string; pathUnavailable: string; unavailable: string;
      unknown: string; allowed: string; denied: string; operationUnknown: string; query: string; restore: string;
      pause: string; grant: string; confirmPause: string; confirmGrant: string; openSettings: string };
    executionCompleted: string; deliveryCleanupPending: string; deliveryFollowup: string; deliveryHistory: (sourceTaskId: string) => string;
    deliveryStatuses: Record<HostDeliveryRecord['status'], string>; deliveryReasons: Record<GuardFailure['code'], string>;
    alias: (ordinal: number) => string; mainAgent: string; assignment: (task: string) => string; turnLabel: (turn: number) => string;
    toolSummary: (completed: number, failed: number) => string; toolsRecorded: (count: number) => string;
    toolsUnrecorded: string; toolsIncomplete: string; otherTools: (count: number) => string; settling: string;
    taskTab: string; agentsTab: string; agentsHistoryEntry: string; executionState: string; canvasTab: string; closePanel: string; openPanel: (name: string, count: number) => string;
    loading: string; empty: string; unavailable: string; retry: string; history: string; currentGroup: string; historical: string;
    moreAgents: string; earlierEvents: string; selectAgent: string; message: string; send: string; followup: string; interrupt: string;
    closeAgent: string; confirmClose: string; cancel: string; usage: (input: number, output: number) => string; unread: (count: number) => string;
    elapsed: (seconds: number) => string; sent: string; queued: string; unknown: string; actionFailed: string; cleanupPending: string;
    released: string; resident: string; resourcesInUse: string; stopped: string; blocked: string; previewTruncated: string; loadContent: string;
    contentLoading: string; contentReadFailed: string; savedContentTruncated: (byteLength: number) => string;
    contentSegmented: string; contentSegment: (current: number, total: number) => string;
    previousContentSegment: string; nextContentSegment: string;
    queuedReceipt: (agentId: string, expectedTurn?: number) => string;
    checkOperation: string; userSender: string; finalContentUnavailable: string; moreGroups: string;
    resources: string; resourcesEmpty: string; moreResources: string; keepResource: string; retryCleanup: string; resourceConfirmation: string;
    confirmKeep: string; keepExplanation: string; newGroup: string; confirmReset: string; resetExplanation: string; resetPending: string;
    resourceStates: Record<string, string>;
    statuses: Record<'pending' | 'running' | 'completed' | 'failed' | 'interrupted' | 'closed', string>;
    phases: Record<string, string>; eventKinds: Record<string, string>;
    activityAnnouncement: (running: number, completed: number) => string; failureAnnouncement: (name: string) => string;
  };
  // sidebar
  newChat: string;
  chats: string;
  searchChats: string;
  searchTasks: string;
  projects: string;
  // design §12：失败路径与用户文案原则——协作空间 gate 相关扁平 key（沿用
  // 该功能既有的扁平命名风格，不引入新命名空间，避免把顶层 projects: string
  // 改成 object 引发类型/运行时冲突）。
  collaborationRoomStartExecution: string;
  collaborationRoomContextIncomplete: string;
  projectExecutionCompleted: string;
  projectVerificationPassed: string;
  projectVerificationBlocked: string;
  projectVerificationWaitingEvidence: string;
  projectLegacyGateRules: string;
  projectWaitingIndependentReviewer: string;
  projectFinalApprovalRequired: string;
  projectOpenConditionsCount: (count: number) => string;
  retrieve: string;
  legal: string;
  recents: string;
  recentsEmpty: string;
  untitled: string;
  loading: string;
  connectionFailed: string;
  retryConnection: string;
  collaborationRoomLoading: string;
  collaborationRoomError: string;
  collaborationRoomDegraded: string;
  collaborationRoomArchived: string;
  collaborationRoomEmpty: string;
  collaborationRoomComposerPlaceholder: string;
  collaborationRoomMentionAll: string;
  collaborationRoomsTitle: string;
  collaborationRoomsSubtitle: string;
  collaborationRoomGoalLabel: string;
  collaborationRoomGoalPlaceholder: string;
  collaborationRoomAiDefaultsHint: string;
  collaborationRoomAdvanced: string;
  collaborationRoomAiCreating: string;
  collaborationRoomsCreate: string;
  collaborationRoomsEmptyTitle: string;
  collaborationRoomMore: string;
  collaborationRoomsActive: string;
  collaborationRoomsArchived: string;
  collaborationRoomArchiving: string;
  collaborationRoomLastActive: string;
  collaborationRoomTimeUnknown: string;
  collaborationRoomsCategoryEmpty: string;
  collaborationRoomDelete: string;
  collaborationRoomDeleteBody: string;
  collaborationRoomDeleting: string;
  collaborationRoomDeleteFailed: string;
  collaborationRoomDeletePending: string;
  collaborationRoomDeleteConflict: string;
  collaborationRoomsEmptyBody: string;
  collaborationRoomTitleLabel: string;
  collaborationRoomDescriptionLabel: string;
  collaborationRoomMembersLabel: string;
  collaborationRoomSaveMembers: string;
  collaborationRoomAliasLabel: (name: string) => string;
  collaborationRoomAliasHint: string;
  collaborationRoomAliasPlaceholder: string;
  collaborationRoomAliasFailed: string;
  collaborationRoomMentionUnknown: string;
  collaborationRoomCreateSubmit: string;
  collaborationRoomCancel: string;
  collaborationRoomSend: string;
  collaborationRoomSending: string;
  collaborationRoomWaitingForReplies: (count: number) => string;
  collaborationRoomRepliesPartiallyFailed: (count: number) => string;
  collaborationRoomExecutionWorker: string;
  collaborationRoomExecutionDiscussion: string;
  collaborationRoomExecutionUnavailable: string;
  collaborationRoomExecutionUnknown: string;
  collaborationRoomExecutionObservers: string;
  collaborationRoomExecutionReason: (reason: string) => string;
  collaborationRoomUnavailableMembers: (names: string) => string;
  collaborationRoomRefresh: string;
  collaborationRoomArchive: string;
  collaborationRoomTeamDiscussion: string;
  collaborationRoomNormalReply: string;
  collaborationRoomMentionReply: string;
  collaborationRoomSelectForProject: string;
  collaborationRoomAddToProjectBackground: string;
  collaborationRoomRemoveFromProjectBackground: string;
  collaborationRoomCreateProject: string;
  collaborationRoomCopyMessage: string;
  collaborationRoomCopiedMessage: string;
  collaborationRoomCopyFailed: string;
  collaborationRoomSaveToKnowledge: string;
  collaborationRoomSavedToKnowledge: string;
  collaborationRoomKnowledgeSaving: string;
  collaborationRoomKnowledgeNoCollections: string;
  collaborationRoomKnowledgeSaveFailed: string;
  collaborationRoomKnowledgeTitle: (sender: string, excerpt: string) => string;
  collaborationRoomMessageExcerpt: string;
  collaborationRoomProjectName: string;
  collaborationRoomProjectGoal: string;
  collaborationRoomProjectOwner: string;
  collaborationRoomProjectMembers: string;
  collaborationRoomNoMembers: string;
  collaborationRoomLinkedProjects: string;
  collaborationRoomMessageByYou: string;
  collaborationRoomScheduledTrigger: string;
  collaborationRoomScheduledReply: string;
  collaborationRoomActivityNotice: string;
  collaborationRoomSystemMessage: string;
  collaborationRoomCreateFailed: string;
  collaborationRoomActionFailed: string;
  collaborationRoomBackToList: string;

  enterprisePlan: string;
  // sidebar grouping
  sidebarGrouping: string;
  sidebarGroupingDesc: string;
  sidebarGroupingNormal: string;
  sidebarGroupingGtd: string;
  folderMore: string;
  // GTD buckets
  gtdInbox: string;
  gtdTodo: string;
  gtdWaiting: string;
  gtdSomeday: string;
  gtdArchived: string;
  gtdActive: string;
  // GTD actions
  gtdMoveToInbox: string;
  gtdMoveToTodo: string;
  gtdMoveToWaiting: string;
  gtdMoveToSomeday: string;
  gtdMoveToArchived: string;
  gtdMoveToActive: string;
  // pin
  pinThread: string;
  unpinThread: string;
  pinnedSection: string;
  dragToPin: string;
  letGo: string;
  // project view
  projectUnassigned: string;
  // settings nav
  nav: {
    account: string;
    appearance: string;
    settings: string;
    tools: string;
    skills: string;
    credits: string;
    models: string;
    agents: string;
    channels: string;
    connection: string;
    updates: string;
  };
  // settings
  getHelp: string;
  submitSuggestion: string;
  suggestionTitle: string;
  suggestionPlaceholder: string;
  suggestionSubmit: string;
  suggestionSuccess: string;
  comingSoon: string;
  requestFailed: string;
  sessionExpired: string;
  runInterrupted: string;
  sseReconnectNotice: string;
  failedRunTitle: string;
  retryAction: string;
  resetAction: string;
  logout: string;
  language: string;
  appearance: string;
  themeSystem: string;
  themeLight: string;
  themeDark: string;
  // appearance tab
  fontSection: string;
  fontBody: string;
  fontCode: string;
  fontSize: string;
  fontSizeCompact: string;
  fontSizeNormal: string;
  fontSizeRelaxed: string;
  themePresetSection: string;
  themePresetDefault: string;
  themeColorEditor: string;
  colorGroupBackgrounds: string;
  colorGroupText: string;
  colorGroupBorders: string;
  colorGroupAccent: string;
  colorGroupStatus: string;
  colorGroupCode: string;
  colorGroupInteractive: string;
  colorGroupInput: string;
  colorGroupWork: string;
  editColors: string;
  resetToDefault: string;
  saveAsCustom: string;
  customThemeName: string;
  customThemeNamePlaceholder: string;
  importTheme: string;
  exportTheme: string;
  deleteCustomTheme: string;
  myThemes: string;
  skills: {
    title: string;
    subtitle: string;
    searchPlaceholder: string;
    searchPlaceholderMarketplace: string;
    registryTab: string;
    localTab: string;
    officialOnly: string;
    officialOnlyShort: string;
    officialUnconfigured: string;
    marketUnconfiguredTitle: string;
    marketUnconfiguredBody: string;
    marketLoading: string;
    add: string;
    addFromUpload: string;
    addFromSkillsmp: string;
    addFromSkillsmpDesc: string;
    addFromGitHub: string;
    addFromGitHubDesc: string;
    createWithXiaok: string;
    createWithXiaokHint: string;
    uploadTitle: string;
    githubTitle: string;
    officialImportTitle: string;
    localSectionTitle: string;
    localSectionDesc: string;
    emptyTitle: string;
    emptyDesc: string;
    emptyBodyNoMarket: string;
    sourceOfficial: string;
    sourceCustom: string;
    sourceGitHub: string;
    sourcePlatform: string;
    sourceBuiltin: string;
    installed: string;
    notInstalled: string;
    enabledByDefault: string;
    manualAvailable: string;
    install: string;
    installing: string;
    remove: string;
    removing: string;
    update: string;
    viewDetail: string;
    more: string;
    updatedAt: (value: string) => string;
    importFailed: string;
    repositoryMissing: string;
    loadFailed: string;
    officialSearchFailed: string;
    uploadFileLabel: string;
    uploadFileHint: string;
    uploadImmediateInstall: string;
    uploadAction: string;
    uploading: string;
    githubUrlLabel: string;
    githubRefLabel: string;
    githubAction: string;
    githubInvalidUrl: string;
    githubSkillNotFound: string;
    importing: string;
    importOfficialAction: string;
    noResults: string;
    searchResults: (count: number) => string;
    deleteConflict: string;
    candidatesTitle: string;
    chooseCandidate: string;
    installSuccess: (name: string) => string;
    removeSuccess: (name: string) => string;
    updateSuccess: (name: string) => string;
    importSuccess: (name: string) => string;
    updateFailed: string;
    updateBadge: string;
    descriptionFallback: string;
    githubLabel: string;
    githubUrlRequired: string;
    githubUrlPlaceholder: string;
    githubRefPlaceholder: string;
    githubDialogTitle: string;
    githubDialogSubtitle: string;
    uploadDialogTitle: string;
    uploadDialogSubtitle: string;
    uploadArchive: string;
    uploadArchiveDesc: string;
    uploadFolder: string;
    uploadFolderDesc: string;
    uploadSelect: string;
    uploadSelected: (count: number) => string;
    officialDialogTitle: string;
    officialDialogSubtitle: string;
    officialDialogHintTitle: string;
    officialDialogHintBody: string;
    scanStatusLabel: (status: string) => string;
    riskConfirm: (name: string, status: string, summary?: string) => string;
    cancelAction: string;
    trySkill: string;
    download: string;
    replace: string;
    disable: string;
    disableFailed: string;
    detailTitle: string;
    trySkillPrompt: (skillKey: string) => string;
    detailVersion: string;
    detailSource: string;
    detailUpdatedAt: string;
    detailDescription: string;
    noDescription: string;
    installedTab: string;
    marketplaceTab: string;
    builtinTab: string;
    builtinTitle: string;
    builtinEmpty: string;
    restore: string;
    backToSkills: string;
    externalTab: string;
    externalTitle: string;
    externalEmpty: string;
    externalNoSkills: string;
    externalAddDir: string;
    externalAddPlaceholder: string;
    externalRemoveDir: string;
    externalLoadFailed: string;
    externalSaveFailed: string;
    externalRemoveFailed: string;
    statsWeekSummary: (calls: number, avgSec: string, successRate: string) => string;
    statsCardLine: (calls: number, avgSec: string, successRate: string) => string;
    statsDetailCalls: string;
    statsDetailAvgDuration: string;
    statsDetailSuccessRate: string;
    statsDetailTokens: string;
    statsDetailCallsValue: (n: number) => string;
    statsDetailDurationValue: (ms: number) => string;
    statsDetailSuccessValue: (success: number, total: number) => string;
    statsDetailTokensValue: (tokens: number) => string;
  };
  // invite code
  inviteCode: string;
  inviteCodeDesc: string;
  inviteCodeCopy: string;
  inviteCodeCopied: string;
  inviteCodeReset: string;
  inviteCodeResetting: string;
  inviteCodeUses: (used: number, max: number) => string;
  inviteCodeResetCooldown: string;
  // credits
  creditsBalance: string;
  creditsBalanceUnit: string;
  creditsRedeem: string;
  creditsRedeemPlaceholder: string;
  creditsRedeemBtn: string;
  creditsRedeemSuccess: (value: string) => string;
  creditsRedeemError: (code: string) => string;
  creditsUsage: string;
  creditsUsageQuery: string;
  creditsHistoryDetails: string;
  creditsHistoryDate: string;
  creditsHistoryCreditChange: string;
  creditsHistoryEmpty: string;
  creditsHistoryRecent: string;
  creditsHistoryMonthly: string;
  creditsTxTypeLabel: (type: string) => string;
  // auth
  loginMode: string;
  registerMode: string;
  identityPlaceholder: string;
  enterUsername: string;
  enterEmail: string;
  enterPassword: string;
  enterInviteCode: string;
  enterInviteCodeOptional: string;
  editProfile: string;
  continueBtn: string;
  orDivider: string;
  githubLogin: string;
  noAccount: string;
  hasAccount: string;
  useEmailOtpHint: string;
  creatingAccountHint: string;
  enterYourPasswordTitle: string;
  fieldIdentity: string;
  fieldPassword: string;
  registerPasswordHint: string;
  backBtn: string;
  editIdentity: string;
  // profile editing
  profileTitle: string;
  profileName: string;
  profileUsername: string;
  profileUserId: string;
  profileSave: string;
  profileSaved: string;
  profileEmail: string;
  timezone: string;
  timezoneUseDevice: string;
  timezoneUseAccountDefault: string;
  emailUnverified: string;
  emailVerified: string;
  emailVerifySend: string;
  emailVerifySent: string;
  emailVerifyCodePlaceholder: string;
  emailVerifyConfirmBtn: string;
  emailVerifySuccess: string;
  emailVerifyFailed: string;
  emailVerifyGoToApp: string;
  // EmailVerificationGate
  emailGateTitle: string;
  emailGateDesc: (email: string) => string;
  emailGateResend: string;
  emailGateResent: string;
  emailGateUseOtp: string;
  emailGateAlreadyVerified: string;
  otpLoginTab: string;
  passwordLoginTab: string;
  otpEmailPlaceholder: string;
  otpCodePlaceholder: string;
  otpSendBtn: string;
  otpSendingCountdown: (s: number) => string;
  otpVerifyBtn: string;
  emailNotVerifiedHint: string;
  newChatTitle: string;
  chatPlaceholder: string;
  welcomeGreeting: {
    merryChristmas: (name: string | null) => string;
    happyNewYear: (name: string | null) => string;
    happyLunarNewYear: (name: string | null) => string;
    mondayMorning: (name: string | null) => string;
    fridayAfternoon: (name: string | null) => string;
    lateNight: (name: string | null) => string;
    morning: (name: string | null) => string[];
    afternoon: (name: string | null) => string[];
    evening: (name: string | null) => string[];
    generic: (name: string | null) => string[];
  };
  // notifications
  notificationsTitle: string;
  notificationsEmpty: string;
  notificationsMarkRead: string;
  // free plan badge
  freePlan: string;
  freeTrial: string;
  freeTrialDesc: string;
  // chat input menu
  addFromLocal: string;
  addFromGitHub: string;
  learningMode: string;
  planMode: string;
  planModePlaceholders: string[];
  dragToAttach: string;
  // chats search modal
  searchChatsPlaceholder: string;
  searchNoResults: string;
  searchToday: string;
  searchYesterday: string;
  searchLastWeek: string;
  searchEarlier: string;
  // incognito
  incognitoMode: string;
  incognitoHistoryNote: string;
  youAreIncognito: string;
  enableIncognito: string;
  disableIncognito: string;
  incognitoThreadNote: string;
  incognitoLabel: string;
  thisThreadIsIncognito: string;
  toggleIncognito: string;
  componentUpdatesAvailable: string;
  updateSkipped: string;
  goToDownload: string;
  incognitoForkDivider: string;
  // mode switch
  modeChat: string;
  modeWork: string;
  // work mode sidebar
  newTask: string;
  tasks: string;
  tasksEmpty: string;
  workGreeting: string;
  // thread context menu
  starThread: string
  unstarThread: string
  shareThread: string
  renameThread: string
  deleteThread: string
  deleteThreadPending: string
  deleteThreadUnknown: string
  deleteThreadUnavailable: string
  deleteThreadFailed: string
  deleteThreadConfirmTitle: string
  deleteThreadConfirmBody: string
  deleteThreadConfirm: string
  deleteThreadInlineConfirm: string
  deleteThreadCancel: string
  // share
  shareTitle: string
  sharePublic: string
  sharePassword: string
  sharePasswordPlaceholder: string
  shareCreate: string
  shareCreating: string
  shareCopyLink: string
  shareCopied: string
  shareRevoke: string
  shareRevoking: string
  shareRevokeConfirm: string
  shareCurrentLink: string
  shareNoLink: string
  shareLiveUpdate: string
  shareFrozen: string
  shareTurnCount: (n: number) => string
  shareCreateNew: string
  shareListEmpty: string
  shareLinkCopied: string
  // share page
  sharePageLogin: string
  sharePageRegister: string
  sharePagePasswordTitle: string
  sharePagePasswordPlaceholder: string
  sharePagePasswordSubmit: string
  sharePagePasswordWrong: string
  sharePageNotFound: string
  sharePagePoweredBy: string
  // report
  reportButton: string
  reportTitle: string
  reportSubtitle: string
  reportInaccurate: string
  reportOutOfDate: string
  reportTooShort: string
  reportTooLong: string
  reportHarmful: string
  reportWrongSources: string
  reportFeedbackPlaceholder: string
  reportFeedbackLabel: string
  reportSubmit: string
  reportSubmitting: string
  reportCancel: string
  reportSuccess: string
  // shell execution
  shellRan: string
  shellRanCommand: string
  shellSuccess: string
  shellFailed: string
  shellCompleted: string
  shellNoOutput: string
  shellRunning: string
  shellRanShort: string
  todoListTitle: string
  todoListProgress: (completed: number, total: number) => string
  todoChangeCompleted: (completed: number, total: number) => string
  todoChangeStarted: (position: number, total: number) => string
  todoChangeCancelled: (position: number, total: number) => string
  todoChangeUpdated: (position: number, total: number) => string
  // sub-agent
  agentSubAgent: string
  agentSpawning: string
  agentRunning: string
  agentCompleted: string
  agentFailed: string
  agentClosed: string
  agentInput: string
  agentOutput: string
  agentNoOutput: string
  // pasted content
  pastedContent: string
  pastedLines: (n: number) => string
  // user input card
  userInput: {
    dismiss: string
    submit: string
    submitting: string
    next: string
    back: string
  }
  // document panel
  documentPanel: {
    preview: string
    source: string
    download: string
    previewUnsupported: string
    downloadFile: string
    loadFailed: (detail: string) => string
  }
  // message actions
  copyAction: string
  editAction: string
  assistantCopDefaultTitle: string
  /** Enter 后、首条可见输出前，流式区占位（与 COP 默认标题区分） */
  assistantStreamThinkingPlaceholder: string
  /** CopTimeline：流式未完结、按代码/工具条目计数时的标题 */
  copTimelineLiveProgress: string
  /** CopTimeline：仅 thinking、已结束且无计时时 */
  copTimelineThinkingDoneNoDuration: string
  /** CopTimeline：仅 thinking、已结束且有时长（秒） */
  copTimelineThoughtForSeconds: (sec: number) => string
  copTimelineThinkingForSeconds: (sec: number) => string
  copTimelineShowMoreSources: (count: number) => string
  copTimelineShowFewerSources: string
  copThinkShowMore: string
  copThinkShowLess: string
  /** COP 时间轴：thinking 折叠行左侧标签 */
  copThinkingInlineTitle: string
  /** COP thinking 卡片顶栏（流式中） */
  copThinkCardTitle: string
  copThinkingHints: readonly string[]
  copThinkingDone: string
  // model config
  models: {
    addProvider: string
    editProvider: string
    deleteProvider: string
    deleteProviderConfirm: string
    providerName: string
    providerVendor: string
    apiKey: string
    apiKeyPlaceholder: string
    baseUrl: string
    baseUrlPlaceholder: string
    save: string
    saving: string
    cancel: string
    noProviders: string
    noProvidersDesc: string
    modelsSection: string
    importAll: string
    importing: string
    noModels: string
    deleteModel: string
    addModel: string
    modelName: string
    modelNamePlaceholder: string
    loadFailed: string
    saveFailed: string
    deleteFailed: string
    vendorOpenaiResponses: string
    vendorOpenaiChatCompletions: string
    vendorAnthropicMessage: string
    vendorGemini: string
    vendorKimi: string
    vendorDeepseek: string
    vendorGlm: string
    vendorMinimax: string
    applyToAll: string
    applyingToAll: string
    applyDone: string
    deleteAll: string
    deleteAllConfirmTitle: string
    deleteAllConfirmDesc: string
    testModel: string
    searchPlaceholder: string
    showInPicker: string
    hideFromPicker: string
    embeddingTagAdd: string
    embeddingTagRemove: string
    modelOptionsTitle: string
    modelOptionsFor: string
    modelCapabilities: string
    modelType: string
    modelTypeChat: string
    modelTypeEmbedding: string
    modelTypeImage: string
    modelTypeAudio: string
    modelTypeModeration: string
    modelTypeOther: string
    vision: string
    imageOutput: string
    embedding: string
    toolCalling: string
    reasoning: string
    contextWindow: string
    maxOutputTokens: string
    defaultTemperature: string
    providerOptionsJson: string
    providerOptionsHint: string
    reset: string
    invalidJson: string
    invalidNumber: string
    availableFetchFailed: string
    noModelsAvailable: string
    visionBridgeHint: string
    addModelTitle: string
  }
  // agent settings
  agentSettings: {
    title: string
    subtitle: string
    reasoningMode: string
    temperature: string
    maxOutputTokens: string
    noPersonas: string
    saveFailed: string
    resetAll: string
    resetDone: string
    reasoningModes: {
      default: string
      enabled: string
      disabled: string
    }
    spawnProfileTitle: string
    spawnProfileSubtitle: string
    spawnProfileFollowCurrentChat: string
    spawnProfilePlatformDefault: string
    spawnProfileExplore: string
    spawnProfileExploreDesc: string
    imageGenerativeTitle: string
    imageGenerativeDesc: string
    imageGenerativeUnset: string
    spawnProfileTask: string
    spawnProfileTaskDesc: string
    spawnProfileStrong: string
    spawnProfileStrongDesc: string
    streamThinking: string
  }
  // channels
  channels: {
    title: string
    subtitle: string
    platform: string
    botToken: string
    botTokenPlaceholder: string
    tokenAlreadyConfigured: string
    allowedUsers: string
    allowedUsersPlaceholder: string
    accessControl: string
    allowedServerIds: string
    allowedServerIdsPlaceholder: string
    allowedChannelIds: string
    allowedChannelIdsPlaceholder: string
    telegramPrivateChatAccess: string
    telegramAllowEveryone: string
    telegramSpecificUsersOnly: string
    telegramGroupChatAccess: string
    telegramAllowAllGroups: string
    telegramSpecificGroupsOnly: string
    telegramAllowedGroupsPlaceholder: string
    telegramAllowedGroupsHint: string
    telegramAllowedGroupsLabel: string
    persona: string
    personaDefault: string
    webhookUrl: string
    webhookUrlCopy: string
    webhookUrlCopied: string
    active: string
    inactive: string
    addChannel: string
    save: string
    saving: string
    cancel: string
    delete: string
    deleteConfirm: string
    noChannels: string
    noChannelsDesc: string
    saveFailed: string
    deleteFailed: string
    loadFailed: string
    personaRequired: string
	    telegram: string
	    discord: string
	    feishu: string
	    feishuAppID: string
	    feishuAppIDPlaceholder: string
	    feishuAppIDRequired: string
	    feishuAppSecret: string
	    feishuAppSecretPlaceholder: string
	    feishuVerificationToken: string
	    feishuVerificationTokenPlaceholder: string
	    feishuEncryptKey: string
	    feishuEncryptKeyPlaceholder: string
	    feishuCredentialsRequired: string
	    feishuDomain: string
	    feishuDomainFeishu: string
	    feishuDomainLark: string
	    feishuAllowedUsers: string
	    feishuAllowedUsersPlaceholder: string
	    feishuAllowedChats: string
	    feishuAllowedChatsPlaceholder: string
	    feishuTriggerKeywords: string
	    feishuTriggerKeywordsPlaceholder: string
	    bindingsTitle: string
    bindingsEmpty: string
    generateCode: string
    generating: string
    bindCode: string
    bindCodeHint: string
    unbind: string
    unbinding: string
    unbindConfirm: string
    unbindFailed: string
    bindingBotAdmin: string
    bindingOwner: string
    bindingAdmin: string
    setOwner: string
    heartbeatEnabled: string
    heartbeatInterval: string
    heartbeatModel: string
    heartbeatDesc: string
    heartbeatCardTitle: string
    heartbeatCardDesc: string
    heartbeatCardHint: string
    ownerUnbindBlocked: string
    botTokenHint: string
    allowedUsersHint: string
    discordTokenHint: string
    discordServerIdHint: string
    bindCodeInGroupHint: string
    qq: string
    qqOneBot: string
    qqBotAppID: string
    qqBotAppIDPlaceholder: string
    qqBotAppIDRequired: string
    qqBotClientSecret: string
    qqBotClientSecretPlaceholder: string
    qqBotClientSecretRequired: string
    qqBotOfficialIntro: string
    qqBotOfficialPortal: string
    qqBotSetupSteps: string[]
    qqBotAllowedUsers: string
    qqBotAllowedUsersPlaceholder: string
    qqBotAllowedGroups: string
    qqBotAllowedGroupsPlaceholder: string
    qqChannelCreateHint: string
    qqSetup: string
    qqFetchingInfo: string
    qqDownloading: string
    qqExtracting: string
    qqStarting: string
    qqStopping: string
    qqScanToLogin: string
    qqLoggedIn: string
    qqRefreshQR: string
    qqQuickLogin: string
    qqScanNewAccount: string
    qqAllowedUsers: string
    qqAllowedUsersPlaceholder: string
    qqAllowedGroups: string
    qqAllowedGroupsPlaceholder: string
    qqAutoLogin: string
    qqAutoLoginNone: string
    qqAutoLoginDesc: string
    qqLogs: string
    qqOneBotTitle: string
    qqOneBotWSUrl: string
    qqOneBotWSUrlPlaceholder: string
    qqOneBotHTTPUrl: string
    qqOneBotHTTPUrlPlaceholder: string
    qqOneBotToken: string
    qqOneBotTokenPlaceholder: string
    qqOneBotAutoFilled: string
    qqExternalOneBotHint: string
    weixin: string
    weixinScanQR: string
    weixinLoggedIn: string
    weixinRelogin: string
    weixinQRExpired: string
    weixinScanning: string
    weixinBotTokenHint: string
    weixinAllowedUsersHint: string
    weixinAllowedGroupsHint: string
  }
  // model picker (chat input)
  modelPicker: {
    defaultLabel: string
    addProviderFirst: string
    addApiKey: string
    byokSection: string
    noByok: string
    searchPlaceholder: string
    moreModels: string
    thinking: string
    effort: string
    effortOff: string
    effortMinimal: string
    effortLow: string
    effortMedium: string
    effortHigh: string
    effortMax: string
    options: string
  }
  // work right panel
  work: {
    progress: string;
    progressEmpty: string;
    workingFolder: string;
    workingFolderEmpty: string;
    workingFolderLoading: string;
    workingFolderError: string;
    workingFolderEmptyDir: string;
    workingFolderSelectFile: string;
    context: string;
    contextDesc: string;
    contextEmpty: string;
    stepComplete: string;
    stepInProgress: string;
    stepPending: string;
    toolsCalled: string;
    filesReferenced: string;
    agents: string;
    agentsEmpty: string;
    agentSpawning: string;
    agentRunning: string;
    agentCompleted: string;
    agentFailed: string;
    agentClosed: string;
  };
  // chat page
  checkInPlaceholder: string;
  replyPlaceholder: string;
  followUpPlaceholder: string;
  // connection settings (desktop only)
  connection: {
    title: string;
    local: string;
    localDesc: string;
    saas: string;
    saasDesc: string;
    selfHosted: string;
    selfHostedDesc: string;
    baseUrl: string;
    status: string;
    running: string;
    stopped: string;
    starting: string;
    crashed: string;
    restart: string;
    currentPort: string;
    portMode: string;
    portModeAuto: string;
    portModeManual: string;
    advanced: string;
    advancedDesc: string;
    manualPort: string;
    manualPortHint: string;
    restoreAutoPort: string;
    runtimeError: string;
    testConnection: string;
    connected: string;
    failed: string;
    save: string;
  };

  security: PromptInjectionTexts & Record<string, string> & {
    title: string;
    description: string;
    tabLayers: string;
    tabAudit: string;
    auditLoading: string;
  };

  // desktop settings navigation
  desktopSettings: {
    backToChat: string;
    settingsTitle: string;
    // section headers
    mainSection: string;
    desktopSection: string;
    // nav items
    general: string;
    appearance: string;
    providers: string;
    routing: string;
    personas: string;
    channels: string;
    skills: string;
    mcp: string;
    connectors: string;
    searchFetch: string;
    tools: string;
    connection: string;
    chat: string;
    voice: string;
    advanced: string;
    about: string;
    aboutDesc: string;
    promptInjection: string;
    extensions: string;
    developer: string;
    agentCoreHeader: string;
    managementHeader: string;
    // general settings
    profileSection: string;
    localModeLabel: string;
    appearanceSection: string;
    // placeholder pages
    mcpTitle: string;
    mcpDesc: string;
    mcpPage: {
      add: string;
      refresh: string;
      scan: string;
      close: string;
      cancel: string;
      enable: string;
      disable: string;
      scanning: string;
      saving: string;
      empty: string;
      loading: string;
      formTitleCreate: string;
      formTitleEdit: string;
      scanTitle: string;
      externalTitle: string;
      fieldName: string;
      fieldTransport: string;
      fieldHost: string;
      fieldUrl: string;
      fieldCommand: string;
      fieldArgs: string;
      fieldCwd: string;
      fieldEnv: string;
      fieldHeaders: string;
      fieldBearer: string;
      fieldTimeout: string;
      fieldSourceKind: string;
      fieldSourceUri: string;
      fieldSyncMode: string;
      fieldDiscoveryPath: string;
      placeholderFilePath: string;
      enabled: string;
      disabled: string;
      save: string;
      create: string;
      delete: string;
      edit: string;
      recheck: string;
      import: string;
      scanAction: string;
      installable: string;
      needsAttention: string;
      discoveryEmpty: string;
      errRequired: string;
      errUrlRequired: string;
      errCommandRequired: string;
      errEnvInvalid: string;
      errHeadersInvalid: string;
      errTimeoutInvalid: string;
      toastLoadFailed: string;
      toastSaveFailed: string;
      toastDeleteFailed: string;
      toastToggleFailed: string;
      toastCheckFailed: string;
      toastDiscoverFailed: string;
      toastImportFailed: string;
      toastSaved: string;
      toastDeleted: string;
      toastChecked: string;
      toastImported: string;
    };
    connectorsTitle: string;
    connectorsDesc: string;
    extensionsTitle: string;
    extensionsDesc: string;
    modules: string;
    modulesTitle: string;
    modulesDesc: string;
    modulesOffline: string;
    sandboxTitle: string;
    sandboxDesc: string;
    memoryTitle: string;
    memoryDesc: string;
    searchTitle: string;
    searchDesc: string;
    crawlerTitle: string;
    crawlerDesc: string;
    browserTitle: string;
    browserDesc: string;
    developerTitle: string;
    developerDesc: string;
    debugMode: string;
    debugModeDesc: string;
    logLevel: string;
    logLevelInfo: string;
    logLevelDebug: string;
    logLevelWarn: string;
    logLevelError: string;
    pipelineTrace: string;
    pipelineTraceDesc: string;
    promptCacheDebug: string;
    promptCacheDebugDesc: string;
    showRunEvents: string;
    showRunEventsDesc: string;
    showDebugPanel: string;
    showDebugPanelDesc: string;
    viewRunDetail: string;
    runDetailTitle: string;
    runDetailOverview: string;
    runDetailConversation: string;
    runDetailEvents: string;
    runDetailNoEvents: string;
    runDetailLoadError: string;
    resetOnboarding: string;
    resetOnboardingDesc: string;
    resetOnboardingBtn: string;
    appVersion: string;
    // nav items (full labels for settings sidebar)
    navGeneral: string;
    navMobile: string;
    navModel: string;
    navSkills: string;
    navChannels: string;
    navMcp: string;
    navTools: string;
    navAppearance: string;
    navData: string;
    navMemory: string;
    navAbout: string;
    // channels pane
    channelsTitle: string;
    channelsDesc: string;
    channelsAdd: string;
    channelsNameLabel: string;
    channelsNamePlaceholder: string;
    channelsTypeLabel: string;
    channelsCreateBtn: string;
    channelsCancelBtn: string;
    channelsEmpty: string;
    channelsCreatedAt: string;
    channelsTestSuccess: (latencyMs: number) => string;
    channelsTestFailed: string;
    channelsTestBtn: string;
    channelsEnabled: string;
    channelsDisabled: string;
    channelsDeleteConfirm: string;
    channelsFieldRequired: (label: string) => string;
    // channel types
    channelTypeYunzhijia: string;
    channelTypeFeishu: string;
    channelTypeDiscord: string;
    channelTypeWeixin: string;
    channelTypeQQ: string;
    channelTypeTelegram: string;
    // channel field placeholders
    channelFieldAppId: string;
    channelFieldAppSecret: string;
    channelFieldToken: string;
    channelFieldFeishuAppId: string;
    channelFieldFeishuAppSecret: string;
    channelFieldDiscordChannelId: string;
    channelFieldWeixinAppId: string;
    channelFieldWeixinToken: string;
    channelFieldQQAppId: string;
    channelFieldTelegramChatId: string;
    // back button
    back: string;
    // mobile pairing
    mobilePairingTitle: string;
    mobileRelayStateOk: string;
    mobileRelayStateOffline: string;
    mobileRelayStateExpired: string;
    mobileRelayStateRejected: string;
    mobileRelayStateMissing: string;
    mobileRelayStateUnparseable: string;
    mobileRelayExpiredAt: string;
    mobileRelaySignInAction: string;
    mobileRelayReauthHint: string;
    mobilePairingLoading: string;
    mobileRelayReadUnavailable: string;
    mobileRelayReadRetry: string;
    mobilePairingLoadFailed: string;
    mobilePairingQrAlt: string;
    mobilePairingCopyLink: string;
    mobilePairingRefresh: string;
    mobilePairingCopied: string;
    mobilePairingCopyFailed: string;
    mobilePairingScanTitle: string;
    mobilePairingScanDesc: string;
    mobilePairingDesktopId: string;
    mobilePairingLanAddress: string;
    mobilePairingNoLanAddress: string;
    mobilePairingRelay: string;
    mobilePairingRelayReady: string;
    mobilePairingRelayMissing: string;
    mobilePairingReachableCount: string;
    mobilePairingReachableCountValue: (count: number) => string;
    mobilePairingSecurityNote: string;
    // general pane - profile
    profileTitle: string;
    changeAvatar: string;
    enterYourName: string;
    save: string;
    cancelAction: string;
    clickToSetName: string;
    nameCallHint: string;
    // general pane - language
    languageTitle: string;
    languageDesc: string;
    langZh: string;
    langZhSub: string;
    langEn: string;
    langEnSub: string;
    // general pane - service status
    serviceStatusTitle: string;
    serviceStatusChecking: string;
    serviceStatusReadRetry: string;
    serviceRestartUnknown: string;
    serviceStatusLoadError: string;
    serviceRestartFailed: string;
    serviceStatusRunning: string;
    serviceStatusAbnormal: string;
    serviceStatusUnavailable: string;
    serviceRestartCount: string;
    serviceRestart: string;
    // general pane - task concurrency
    taskConcurrencyTitle: string;
    taskConcurrencyDesc: string;
    taskConcurrencyAria: string;
    taskConcurrencyMin: string;
    taskConcurrencyMax: string;
    // general pane - stage debug
    configLoadFailed: string;
    configSaveFailed: string;
    configOperationUnknown: string;
    modelConfigOperationUnknown: string;
    modelConfigInputInvalid: string;
    modelConfigUnavailable: string;
    stageDebugTitle: string;
    stageDebugDesc: string;
    stageDebugOn: string;
    stageDebugOff: string;
    stageDebugToggleAria: string;
    // general pane - app info
    appInfoTitle: string;
    appInfoVersion: string;
    appInfoBuild: string;
    appInfoDataPath: string;
    avatarTooLarge: string;
    memoryPaneTitle: string;
    memoryPaneDesc: string;
    // voice settings
    voiceTitle: string;
    voiceDesc: string;
    voiceEnableLabel: string;
    voiceEnableDesc: string;
    voiceLangLabel: string;
    voiceLangAuto: string;
    voiceCredsTitle: string;
    voiceCredsAdd: string;
    voiceCredsEdit: string;
    voiceCredsEmpty: string;
    voiceCredsDefault: string;
    voiceCredsSetDefault: string;
    voiceCredsDelete: string;
    voiceCredsDeleteConfirm: string;
    voiceCredsLoadError: string;
    voiceCredsAddTitle: string;
    voiceCredsEditTitle: string;
    voiceCredsName: string;
    voiceCredsNamePlaceholder: string;
    voiceCredsProvider: string;
    voiceCredsModel: string;
    voiceCredsApiKey: string;
    voiceCredsApiKeyPlaceholder: string;
    voiceCredsIsDefault: string;
    voiceCredsSave: string;
    voiceCredsSaving: string;
    voiceCredsCancel: string;
    meetingAsrSettingsTitle: string;
    meetingAsrSettingsDesc: string;
    meetingRecordingSettingsTitle: string;
    meetingRecordingSettingsDesc: string;
    meetingRecordingLocalModelsTitle: string;
    meetingRecordingOnlineProvidersTitle: string;
    meetingAsrDefaultProvider: string;
    meetingAsrVolcengineTitle: string;
    meetingAsrAliyunTitle: string;
    meetingAsrConfigured: string;
    meetingAsrNotConfigured: string;
    meetingAsrAppKey: string;
    meetingAsrAccessKey: string;
    meetingAsrAccessToken: string;
    meetingAsrApiKey: string;
    meetingAsrBaseUrl: string;
    meetingAsrModel: string;
    meetingAsrEndpoint: string;
    meetingAsrResourceId: string;
    meetingAsrSave: string;
    meetingAsrSaving: string;
    meetingAsrSaved: string;
    runsHistory: string;
    runsHistoryDesc: string;
    runsHistoryEmpty: string;
    runsHistoryLoading: string;
    runsHistoryLoadError: string;
    runsHistoryRefresh: string;
    runsHistoryColId: string;
    runsHistoryColModel: string;
    runsHistoryColStatus: string;
    runsHistoryColTokens: string;
    runsHistoryColTime: string;
    runsHistoryOpen: string;
    runsHistoryPrev: string;
    runsHistoryNext: string;
    loopsTab: string;
    userLoops: string;
    userLoopsDesc: string;
    userLoopsLoading: string;
    userLoopsEmpty: string;
    newMarkdownLoop: string;
    newLoop: string;
    userLoopKindLabel: string;
    userLoopKindTaskCompletion: string;
    userLoopKindMarkdownFile: string;
    createLoop: string;
    creatingLoop: string;
    cancel: string;
    userLoopTitleLabel: string;
    userLoopPromptLabel: string;
    userLoopOutputDirectoryLabel: string;
    userLoopOutputFileNameLabel: string;
    userLoopOutputPath: string;
    userLoopArtifactsOpen: string;
    userLoopArtifactsLoading: string;
    userLoopArtifactsUnavailable: string;
    userLoopArtifactsEmpty: string;
    userLoopArtifactsPrevious: string;
    userLoopArtifactsNext: string;
    userLoopArtifactsPage: (first:number,last:number,total:number)=>string;
    userLoopArtifactBytes: (size:number)=>string;
    userLoopWorkspaceNavigationHint: string;
    userLoopOpenOutputDirectory: string;
    userLoopPreviewOutputFile: string;
    userLoopViewTaskResult: string;
    userLoopTaskResult: string;
    userLoopTaskResultUnavailable: string;
    userLoopOutputPreview: string;
    userLoopOutputPreviewUnavailable: string;
    userLoopScheduleSingle: string;
    userLoopScheduleMultiple: string;
    userLoopScheduleActive: string;
    userLoopOpenSchedules: string;
    userLoopCreateMissingFields: string;
    userLoopCreateSuccess: string;
    userLoopCreateFailed: string;
    loopDiagnostics: string;
    loopDiagnosticsDesc: string;
    loopDiagnosticsRefresh: string;
    loopDiagnosticsRunNow: string;
    loopDiagnosticsCopyLabels: {loop:string;status:string;history:string;observation:string;finishedAt:string;openAnomalies:string;owner:string;seen:string;suggestedAction:string;logs:string;none:string};
    loopDiagnosticsVerifiedAt: (time: string) => string;
    loopDiagnosticsPublicationPending: string;
    loopDiagnosticsRunning: string;
    loopDiagnosticsAlreadyRunning: string;
    loopDiagnosticsLastRun: string;
    loopDiagnosticsOpenAnomalies: string;
    loopDiagnosticsNoRuns: string;
    loopDiagnosticsLoading: string;
    loopDiagnosticsLoadError: string;
    loopDiagnosticsRunFailed: string;
    loopDiagnosticsSuggestedAction: string;
    loopDiagnosticsLogPath: string;
    loopDiagnosticsCopy: string;
    loopDiagnosticsCopied: string;
    loopDiagnosticsCopyFailed: string;
    chatSectionTitle: string;
    chatCompactCardTitle: string;
    chatCompactEnableLabel: string;
    chatCompactEnableDesc: string;
    chatCompactThresholdLabel: string;
    chatCompactThresholdEarly: string;
    chatCompactThresholdLate: string;
    chatCompactKeepLabel: string;
    chatCompactKeepDesc: string;
    chatCompactSave: string;
    chatCompactSaving: string;
    chatCompactSaved: string;
    chatCompactSaveError: string;
    chatCompactLoading: string;
    chatCompactBannerRunning: string;
    chatCompactBannerDone: string;
    chatCompactBannerTrim: string;
    chatCompactBannerLlmFailed: string;
    chatCompactExecutionModeLabel: string;
    chatCompactExecutionModeTerminal: string;
    chatCompactExecutionModeSandbox: string;
    // desktop connectors section
    desktopConnectorsTitle: string;
    desktopConnectorsDesc: string;
    fetchConnectorTitle: string;
    fetchConnectorDesc: string;
    searchConnectorTitle: string;
    searchConnectorDesc: string;
    providerLabel: string;
    apiKeyLabel: string;
    apiKeyOptionalLabel: string;
    baseUrlLabel: string;
    connectorSaveBtn: string;
    connectorSaving: string;
    connectorSaved: string;
    connectorSaveTimeout: string;
    connectorDefaultModel: string;
    connectorDefaultModelPlaceholder: string;
    connectorRegenerateCode: string;
    connectorVerify: string;
    connectorVerifying: string;
    connectorVerifyOk: string;
    connectorVerifyFail: string;
    connectorRestarting: string;
    connectorFreeTier: string;
    connectorConfigured: string;
    connectorNotConfigured: string;
    fetchProviderJina: string;
    fetchProviderBasic: string;
    fetchProviderFirecrawl: string;
    searchProviderDuckduckgo: string;
    searchProviderTavily: string;
    searchProviderSearxng: string;
    searchProviderDuckduckgoDesc: string;
    searchProviderTavilyDesc: string;
    searchProviderSearxngDesc: string;
    fetchProviderJinaDesc: string;
    fetchProviderBasicDesc: string;
    fetchProviderFirecrawlDesc: string;
    // memory settings tab
    memory: string;
    memorySettingsTitle: string;
    memorySettingsDesc: string;
    memoryLocalProvider: string;
    memoryLocalProviderDesc: string;
    memoryOpenvikingProvider: string;
    memoryOpenvikingProviderDesc: string;
    memoryOpenvikingNote: string;
    memoryNowledgeProvider: string;
    memoryNowledgeProviderDesc: string;
    memoryNoBackendHint: string;
    memoryNowledgeGuide: string;
    memoryNowledgeDocs: string;
    memoryNowledgeDetect: string;
    memoryNowledgeDetected: string;
    memoryNowledgeNotFound: string;
    memoryNowledgeApiKeyHint: string;
    memoryEntriesTitle: string;
    memoryEmptyTitle: string;
    memoryEmptyDesc: string;
    memoryClearAll: string;
    memoryClearAllConfirm: string;
    memoryDeleteConfirm: string;
    memoryLocalTitle: string;
    memoryCompact: string;
    memoryCompactDone: string;
    memoryClear: string;
    memoryClearConfirmTitle: string;
    memoryClearConfirmDesc: string;
    memoryClearConfirmBtn: string;
    memoryCancel: string;
    memoryCompactionModel: string;
    memoryCompactionModelDefault: string;
    memoryLayerL0: string;
    memoryLayerL1: string;
    memoryLayerL2: string;
    memoryLayerL3: string;
    memoryNoEntries: string;
    memoryPrev: string;
    memoryNext: string;
    memoryAdd: string;
    memoryImport: string;
    memorySearch: string;
    memoryAddPlaceholder: string;
    memoryTagsPlaceholder: string;
    memorySave: string;
    memoryImportDesc: string;
    memoryImportPlaceholder: string;
    memoryImportBtn: string;
    memoryImported: (imported: number, deduped: number) => string;
    memoryParseHint: string;
    memoryNoMatch: string;
    memoryEmpty: string;
    memorySnapshotTitle: string;
    memoryRebuildSnapshot: string;
    memorySnapshotEmpty: string;
    memorySnapshotViewEdit: string;
    memoryImpressionTitle: string;
    memoryImpressionUpdatedAgo: string;
    memoryImpressionEmpty: string;
    memoryImpressionViewEdit: string;
    memoryImpressionRebuild: string;
    memoryImpressionModalTitle: string;
    memoryEnabled: string;
    memoryEnabledDesc: string;
    memorySummarizeSectionTitle: string;
    memoryAutoSummarizeLabel: string;
    memoryAutoSummarizeDesc: string;
    memorySystem: string;
    memorySystemSimple: string;
    memorySystemSimpleDesc: string;
    memorySystemOpenViking: string;
    memorySystemOpenVikingDesc: string;
    memoryModuleNotInstalled: string;
    memoryModuleRunning: string;
    memoryModuleStopped: string;
    memoryModuleInstalling: string;
    memoryModuleInstall: string;
    memoryModuleStart: string;
    memoryModuleStop: string;
    memoryModuleRestart: string;
    memoryModuleDisconnected: string;
    memoryModulePending: string;
    memoryModuleError: string;
    memoryModuleChecking: string;
    memoryModuleDockerUnavailable: string;
    memoryRetryModuleList: string;
    memoryConfigureTimeout: string;
    memoryToolModel: string;
    memoryToolModelDesc: string;
    memoryEmbeddingModel: string;
    memoryEmbeddingModelDesc: string;
    memoryEmbeddingProvider: string;
    memoryEmbeddingModelName: string;
    memoryEmbeddingApiKey: string;
    memoryEmbeddingApiBase: string;
    memoryEmbeddingDimension: string;
    memoryOpenvikingRootApiKey: string;
    memoryOpenvikingRootApiKeyDesc: string;
    memoryRerankModel: string;
    memoryRerankModelDesc: string;
    memoryRerankOptional: string;
    memoryConfigureSave: string;
    memoryConfiguring: string;
    memoryConfigured: string;
    memoryConfigureError: string;
    memoryConfigureMissingModels: string;
    memoryNowledgeBaseUrl: string;
    memoryNowledgeApiKey: string;
    memoryNowledgeTimeout: string;
    memoryNowledgeTimeoutMs: string;
    memoryNowledgeTimeoutHint: string;
    memoryNowledgeMissingBaseUrl: string;
    memoryNowledgeSaved: string;
    memorySelectModel: string;
    memoryNoCompatibleModels: string;
    memoryProviderActivated: string;
    memoryNoEmbeddingModels: string;
    memoryProviderNotebook: string;
    memoryProviderOpenviking: string;
    memoryProviderNowledge: string;
    // notebook settings tab
    notebook: string;
    notebookSettingsTitle: string;
    notebookSettingsDesc: string;
    notebookAddPlaceholder: string;
    notebookAddButton: string;
    notebookSearchPlaceholder: string;
    notebookViewEdit: string;
    notebookModalTitle: string;
    notebookEntries: (count: number) => string;
    // memory config modal
    memoryConfigureButton: string;
    memoryActivate: string;
    memoryInUse: string;
    memoryConfigureModalTitle: string;
    memoryNotConfiguredHint: string;
    memoryRecentErrors: string;
    memoryErrorsModalTitle: string;
    // tool model
    toolModel: string;
    toolModelDesc: string;
    toolModelPlatformDefault: string;
    toolModelSameAsChat: string;
    toolModelAutoHint: string;
    toolModelAutoSuffix: string;
    advancedTitle: string;
    advancedDesc: string;
    advancedOverview: string;
    advancedOverviewDesc: string;
    advancedData: string;
    advancedDataDesc: string;
    advancedNetwork: string;
    advancedNetworkDesc: string;
    advancedUsage: string;
    advancedUsageDesc: string;
    advancedLogs: string;
    advancedLogsDesc: string;
    advancedModules: string;
    advancedModulesDesc: string;
    advancedExtensions: string;
    advancedExtensionsDesc: string;
    advancedConfigPath: string;
    advancedDataDir: string;
    advancedLogsDir: string;
    advancedDatabasePath: string;
    advancedUpdateCenter: string;
    advancedUpdateCenterDesc: string;
    advancedUsageSnapshot: string;
    advancedUsageCost: string;
    advancedUsageMessages: string;
    advancedUsageInput: string;
    advancedUsageOutput: string;
    advancedUsageCacheRead: string;
    advancedUsageCacheWrite: string;
    advancedUsageCacheSaved: string;
    advancedUsageMonth: string;
    advancedUsageByModel: string;
    advancedUsageDaily: string;
    advancedUsageModel: string;
    advancedUsageTokens: string;
    advancedUsageCache: string;
    advancedUsageDate: string;
    advancedUsageEmpty: string;
    advancedUsageHeatmap: string;
    advancedUsageModelAnalysis: string;
    advancedUsageSpendDist: string;
    advancedUsageTrend: string;
    advancedUsageModelDist: string;
    advancedUsageTrendHourly: string;
    advancedUsageTrendDaily: string;
    advancedLogsAllSources: string;
    advancedLogsMain: string;
    advancedLogsSidecar: string;
    advancedLogsAllLevels: string;
    advancedLogsSearchPlaceholder: string;
    advancedLogsEmpty: string;
    advancedChooseFolder: string;
    advancedExport: string;
    advancedImport: string;
    advancedExportTitle: string;
    advancedExportDesc: string;
    advancedExportSelectAll: string;
    advancedExportClearAll: string;
    advancedExportCanceled: string;
    advancedImportCanceled: string;
    advancedCancel: string;
    advancedExportSettings: string;
    advancedExportProviders: string;
    advancedExportHistory: string;
    advancedExportPersonas: string;
    advancedExportProjects: string;
    advancedExportMcp: string;
    advancedExportThemes: string;
    advancedSelectedFolder: string;
    advancedExportDone: string;
    advancedImportDone: string;
    advancedNetworkProxyEnable: string;
    advancedNetworkProxyUrl: string;
    advancedNetworkTimeout: string;
    advancedNetworkRetry: string;
    advancedNetworkUserAgent: string;
    advancedEnabled: string;
    advancedDisabled: string;
    advancedSave: string;
    advancedSaving: string;
    advancedSaved: string;
    advancedRefresh: string;
    checkForUpdates: string;
    appUpdateTitle: string;
    appUpdateVersion: string;
    appUpdateUnsupported: string;
    appUpdateChecking: string;
    appUpdateAvailable: string;
    appUpdateLatest: string;
    appUpdateViewDetails: string;
    appUpdateSkipOnce: string;
    appUpdateSkipVersion: string;
    appUpdateDownloading: string;
    appUpdateReady: string;
    appUpdateError: string;
    appUpdateDownload: string;
    appUpdateInstall: string;
    componentUpdateTitle: string;
    componentNotInstalled: string;
    // ModelPane
    modelProviders: string;
    currentModel: string;
    configured: string;
    notConfigured: string;
    protocol: string;
    testConnection: string;
    updateKey: string;
    setKey: string;
    latencyMs: (ms: number) => string;
    deleteLabel: string;
    saveLabel: string;
    configuredModels: string;
    defaultBadge: string;
    setAsDefault: string;
    deleteModel: string;
    addModel: string;
    customModelPlaceholder: string;
    addLabel: string;
    addModelProvider: string;
    apiKeyUpdated: (name: string) => string;
    connectionSuccessLatency: (ms: number) => string;
    connectionFailed: string;
    kimiK3ConnectionErrorAdvice: string;
    modelAdded: (label: string) => string;
    customModelAdded: (name: string) => string;
    modelSwitched: (label: string) => string;
    kimiK3RuntimeTitle: string;
    kimiK3ContextLabel: string;
    kimiK3Context262k: string;
    kimiK3Context1m: string;
    kimiK3EffortLabel: string;
    kimiK3EffortLow: string;
    kimiK3EffortHigh: string;
    kimiK3EffortMax: string;
    kimiK3AllegrettoHint: string;
    kimiK3SaveRuntimeOptions: string;
    kimiK3RuntimeOptionsSaved: string;
    kimiK3NewSessionHint: string;
    confirmDeleteModel: string;
    modelDeleted: string;
    confirmDeleteProvider: string;
    providerDeleted: string;
    providerAdded: string;
    // AddProviderCard
    customNameRequired: string;
    customBaseUrlRequired: string;
    selectProvider: string;
    selectProviderPlaceholder: string;
    alreadyConfigured: string;
    customOpenaiCompatible: string;
    providerName: string;
    availableModels: string;
    defaultModelAfterAdd: (label: string) => string;
    addingProvider: string;
    addProvider: string;
    // SkillsPane
    confirmUninstallSkill: (name: string) => string;
    installedSkills: (count: number) => string;
    skillsDesc: string;
    installSkill: string;
    skillName: string;
    installCommand: string;
    skillNamePlaceholder: string;
    installing: string;
    confirmInstall: string;
    cancelLabel: string;
    noInstalledSkills: string;
    noInstalledSkillsHint: string;
    skillStats: (calls: number, avgSeconds: number) => string;
    uninstall: string;
    skillSources: string;
    skillSourcesDesc: string;
    skillSourcesSearch: string;
    skillSourcesInstall: string;
    skillSourcesUninstall: string;
    skillSourcesList: string;
    skillNameExample: string;
    // loops - user loops section
    quickStartFromTemplate: string;
    categoryBusiness: string;
    categoryCode: string;
    useThisTemplate: string;
    createdFromTemplate: (title: string) => string;
    createFromTemplateFailed: string;
    createScheduleForLoop: string;
    lastRunBlocked: string;
    lastRunFailed: string;
    loopEditCancel: string;
    loopEditSaving: string;
    loopEditSave: string;
    deleteLoopConfirm: string;
    deleteLoopFailed: string;
    saveLoopFailed: string;
    // data pane
    clearDataConfirm: string;
    dataCleared: string;
    clearFailed: (detail: string) => string;
    localData: string;
    dataStorageLocation: string;
    dataStorageIndexedDb: string;
    dataStorageLocalStorage: string;
    configPath: string;
    dangerZone: string;
    clearAllData: string;
    clearAllDataDesc: string;
    clearing: string;
    clearData: string;
    // about pane
    aboutTitle: string;
    aboutLocalMode: string;
    aboutAppDesc: string;
    softwareUpdate: string;
    aboutInstalling: string;
    aboutUpdateReady: string;
    aboutDownloading: string;
    aboutNewVersion: string;
    aboutCurrentVersion: string;
    aboutInstallingVersion: (version: string) => string;
    aboutDownloadedVersion: (version: string) => string;
    aboutDownloadProgress: (progress: number) => string;
    aboutVersionAvailable: (version: string) => string;
    updaterProjectionUnavailable: string;
    updaterOperationUnknown: string;
    updaterInputInvalid: string;
    updaterRefreshData: string;
    aboutChecking: string;
    aboutInstallRestart: string;
    aboutInstallProgress: string;
    aboutCheckUpdates: string;
    aboutCheckingUpdates: string;
    coreFeatures: string;
    featureIntentRecognition: string;
    featureIntentRecognitionDesc: string;
    featureToolCalling: string;
    featureToolCallingDesc: string;
    featureSkillExtension: string;
    featureSkillExtensionDesc: string;
    featureMcp: string;
    featureMcpDesc: string;
    supportedProviders: string;
    versionInfo: string;
    versionLabel: string;
    buildLabel: string;
    // McpPane (supplemental)
    mcpServersTitle: string;
    mcpCreatedAtLabel: string;
    // mcp pane
    mcpPluginDeps: string;
    mcpPluginMcpServices: string;
    mcpPluginMcpServicesDesc: string;
    mcpServersDesc: string;
    mcpAddServer: string;
    mcpNameLabel: string;
    mcpNamePlaceholder: string;
    mcpCommandLabel: string;
    mcpArgsLabel: string;
    mcpCreateBtn: string;
    mcpCancelBtn: string;
    mcpEmpty: string;
    mcpSourceLabel: string;
    mcpConnected: string;
    mcpDisconnected: string;
    mcpInstallFailed: string;
    mcpCancelTask: string;
    mcpCancellingTask: string;
    mcpPluginInstallFailed: string;
    mcpUpdateFailed: string;
    mcpDiagnoseFailed: string;
    mcpInstallConfirm: (name: string) => string;
    mcpSetupConfirm: (title: string, name: string) => string;
    mcpUpdateConfirm: (name: string) => string;
    mcpOpenAccessibility: string;
    mcpOpenScreenRecording: string;
    mcpEnableComputerUse: string;
    mcpConnectMcp: string;
    mcpReconnectMcp: string;
    mcpInstallAndEnable: string;
    mcpInstallDriver: string;
    mcpUpdate: string;
    mcpDiagnose: string;
    // plugin dependency status
    mcpDepNeedsInstall: (name: string) => string;
    mcpDepNeedsAccessibility: string;
    mcpDepNeedsScreenRecording: string;
    mcpDepNeedsUpdate: string;
    mcpDepNotEnabled: string;
    mcpDepAvailable: string;
    mcpDepUnsupported: string;
    mcpDepNeedsAttention: string;
    // plugin dependency layer labels
    mcpLayerPlugin: string;
    mcpLayerInstalled: string;
    mcpLayerNotInstalled: string;
    mcpLayerPermission: string;
    mcpLayerServiceConn: string;
    mcpLayerTools: string;
    // driver layer status
    mcpDriverUnsupported: string;
    mcpDriverNotInstalled: string;
    mcpDriverNeedsUpdate: string;
    mcpDriverInstalledUnavailable: string;
    mcpDriverUnconfirmed: string;
    // permission layer status
    mcpPermAccessibilityMissing: string;
    mcpPermScreenMissing: string;
    mcpPermVerifyAfterEnable: string;
    mcpPermGranted: string;
    mcpPermNotChecked: string;
    mcpPermUnconfirmed: string;
    // mcp layer status
    mcpLayerNotRegistered: string;
    // tool layer status
    mcpToolUnavailable: string;
    mcpToolWaitRegister: string;
    mcpToolWaitEnable: string;
    mcpToolMcpDisconnected: string;
    mcpToolWrapperRegistered: string;
    mcpToolRawNotHidden: string;
    // connectors pane
    connectorSaveFailedNoDesktop: string;
    connectorConfigParseError: string;
    connectorProjectionUnavailable: string;
    connectorOperationUnknown: string;
    connectorInputInvalid: string;
    connectorRefreshData: string;
    connectorStatusDecryptFailed: string;
    connectorLoadFailed: string;
    networkTools: string;
    networkToolsDesc: string;
    searchProviderTitle: string;
    fetchProviderTitle: string;
    searchDuckduckgoDesc: string;
    searchFirecrawlDesc: string;
    searchTavilyDesc: string;
    searchBraveDesc: string;
    fetchBasicDesc: string;
    fetchJinaDesc: string;
    fetchFirecrawlDesc: string;
    firecrawlApiKeyPlaceholder: string;
    jinaApiKeyPlaceholder: string;
    tavilyApiKeyPlaceholder: string;
    braveApiKeyPlaceholder: string;
    connectorStatusReady: string;
    connectorStatusInactive: string;
    connectorStatusMissingConfig: string;
    connectorStatusInvalidConfig: string;
    connectorStatusNotImplemented: string;
    connectorChangeKey: string;
    connectorCancelEdit: string;
    connectorTestConnection: string;
    // System One decision model (tools pane)
    systemOneTitle: string;
    systemOneDesc: string;
    jevKeyName: string;
    jevKeyDesc: string;
    jevKeySteps: string;
    jevKeyEndpoint: string;
    jevKeyEndpointValue: (baseUrl: string) => string;
    jevKeyModel: string;
    jevKeyModelValue: (model: string) => string;
    jevKeyAuth: string;
    jevKeyIsolationNote: string;
    jevKeyFromEnv: (envVar: string) => string;
    jevApiKeyPlaceholder: string;
    jevKeyConfigured: (masked: string) => string;
    jevKeyNotConfigured: string;
    jevSaveBtn: string;
    jevClearBtn: string;
    jevClearEnvHint: string;
    systemOneLoadFailed: string;
    // embedding model settings
    embeddingModelTitle: string;
    embeddingModelDesc: string;
    embeddingModelDims: (dims: number) => string;
    embeddingModelDownloading: string;
    embeddingModelDownloaded: string;
    embeddingModelClickToDownload: string;
    embeddingModelManualGuideTitle: string;
    embeddingModelManualStep1: string;
    embeddingModelManualStep2: string;
    embeddingModelManualStep3: string;
    embeddingModelSwitchTitle: string;
    embeddingModelDownloadAndSwitchTitle: string;
    embeddingModelSwitchConfirm: (name: string) => string;
    embeddingModelDownloadAndSwitchConfirm: (name: string, size: string) => string;
    embeddingModelCancel: string;
    embeddingModelConfirm: string;
    // McpErrorRemediation
    mcpPythonVersionTooOld: (serverName: string, version: string) => string;
    mcpPythonDetected: (version: string) => string;
    mcpPythonUpgradeHint: string;
    mcpPythonOfficialDownload: string;
    mcpPythonCopyBrew: string;
    mcpPythonCopyPyenv: string;
    mcpPythonCopied: string;
    mcpPythonModuleMissing: (moduleName: string) => string;
    mcpPythonModuleMissingDesc: string;
    mcpPythonCopyCommand: string;
    // PluginsSettings
    pluginsInstalledTitle: string;
    pluginsInstalledEmpty: string;
    pluginsAvailableTitle: string;
    pluginsInstalling: string;
    pluginsInstall: string;
    pluginsInstallFailed: string;
    pluginsRestartHint: string;
    pluginsCatalogUnavailable: string;
    pluginsCatalogRetry: string;
    pluginsCatalogLoading: string;
    pluginsCatalogToolCount: (count: number) => string;
    // LocalMemoryStatsCard
    relativeTimeJustNow: string;
    relativeTimeMinutesAgo: (n: number) => string;
    relativeTimeHoursAgo: (n: number) => string;
    relativeTimeDaysAgo: (n: number) => string;
    memoryImportedCount: (n: number) => string;
    memoryImportFailed: string;
    memoryEditTitle: string;
    // GeneralSettings
    profileSave: string;
    profileCancel: string;
    profileAvatarTooLarge: string;
    profileChangeAvatar: string;
    // ProvidersSettings
    baseUrlHttpsHint: string;
    // UpdateSettings
    appUpdateInstalling: string;
    // DeveloperSettings
    designTokensView: string;
    // VoiceSettings
    voiceLangZh: string;
  };

  // admin providers/models settings (ported from console-lite)
  adminProviders: {
    title: string;
    addProvider: string;
    editProvider: string;
    deleteProvider: string;
    deleteProviderConfirm: string;
    providerName: string;
    providerNamePlaceholder: string;
    vendor: string;
    apiKey: string;
    apiKeyPlaceholder: string;
    apiKeyHint: string;
    apiKeyHintOpenAI: string;
    apiKeyHintAnthropic: string;
    apiKeyHintGemini: string;
    baseUrl: string;
    baseUrlPlaceholder: string;
    save: string;
    saving: string;
    cancel: string;
    noProviders: string;
    noProvidersDesc: string;
    modelsSection: string;
    addModel: string;
    editModel: string;
    deleteModel: string;
    importModels: string;
    importing: string;
    importDone: (count: number) => string;
    modelName: string;
    modelNamePlaceholder: string;
    priority: string;
    isDefault: string;
    tags: string;
    tagsPlaceholder: string;
    noModels: string;
    loadFailed: string;
    saveFailed: string;
    deleteFailed: string;
    vendorOpenai: string;
    vendorOpenaiChat: string;
    vendorAnthropic: string;
    vendorGemini: string;
    vendorKimi: string;
    vendorDeepseek: string;
    vendorGlm: string;
    vendorMinimax: string;
    openVikingBackend: string;
    openVikingBackendHint: string;
    openVikingBackendOpenAI: string;
    openVikingBackendAzure: string;
    openVikingBackendVolcengine: string;
    openVikingBackendLiteLLM: string;
    advancedConfig: string;
    searchProviders: string;
    testModel?: string;
    deleteAll?: string;
    deleteAllConfirmTitle?: string;
    deleteAllConfirmDesc?: string;
    importAll?: string;
    modelOptionsTitle?: string;
    modelOptionsFor?: string;
    modelCapabilities?: string;
    modelType?: string;
    modelTypeChat?: string;
    modelTypeEmbedding?: string;
    modelTypeImage?: string;
    modelTypeAudio?: string;
    modelTypeModeration?: string;
    modelTypeOther?: string;
    vision?: string;
    imageOutput?: string;
    embedding?: string;
    toolCalling?: string;
    reasoning?: string;
    contextWindow?: string;
    maxOutputTokens?: string;
    defaultTemperature?: string;
    providerOptionsJson?: string;
    providerOptionsHint?: string;
    reset?: string;
    invalidJson?: string;
    invalidNumber?: string;
  };
  // admin agents settings (ported from console-lite)
  adminAgents: {
    title: string;
    subtitle: string;
    addAgent: string;
    editAgent: string;
    deleteAgent: string;
    deleteAgentConfirm: string;
    displayName: string;
    displayNamePlaceholder: string;
    personaKey: string;
    model: string;
    modelPlaceholder: string;
    noModel: string;
    active: string;
    inactive: string;
    builtIn: string;
    custom: string;
    promptTab: string;
    overviewTab: string;
    toolsTab: string;
    prompt: string;
    promptPlaceholder: string;
    reasoningMode: string;
    reasoningDefault: string;
    reasoningEnabled: string;
    reasoningDisabled: string;
    temperature: string;
    maxOutputTokens: string;
    toolSelectionInherit: string;
    toolSelectionCustom: string;
    toolsInheritDesc: string;
    toolsCustomDesc: string;
    enableAll: string;
    disableAll: string;
    noAgents: string;
    saveFailed: string;
    noTools: string;
    toolSearch: string;
    streamThinking: string;
  };
  // admin tools/connectors settings (ported from console-lite)
  adminTools: {
    title: string;
    subtitle: string;
    activate: string;
    deactivate: string;
    runtimeAvailable: string;
    runtimeUnavailable: string;
    providerConfigStatus: string;
    runtimeReady: string;
    runtimeInactive: string;
    runtimeMissingConfig: string;
    runtimeDecryptFailed: string;
    runtimeInvalidConfig: string;
    configActive: string;
    configInactive: string;
    configured: string;
    unconfigured: string;
    editCredentials: string;
    clearCredentials: string;
    clearCredentialsConfirm: string;
    apiKey: string;
    apiKeyPlaceholder: string;
    baseUrl: string;
    baseUrlPlaceholder: string;
    save: string;
    saving: string;
    cancel: string;
    noProviders: string;
    toolDescriptions: string;
    editDescription: string;
    resetDescription: string;
    enableTool: string;
    disableTool: string;
    descriptionOverride: string;
    configSection: string;
    applyConfig: string;
    applying: string;
    applied: string;
  };

  // scheduled jobs
  scheduledJobs: string;
  scheduledJobsTitle: string;
  scheduledJobsCreate: string;
  scheduledJobsEdit: string;
  scheduledJobsEmpty: string;
  scheduledJobsLoadFailed: string;
  scheduledJobsSaveFailed: string;
  scheduledJobsDeleteFailed: string;
  scheduledJobsName: string;
  scheduledJobsDescription: string;
  scheduledJobsPersona: string;
  scheduledJobsSelectPersona: string;
  scheduledJobsDefaultPersona: string;
  scheduledJobsPrompt: string;
  scheduledJobsModel: string;
  scheduledJobsSelectModel: string;
  scheduledJobsDefaultModel: string;
  scheduledJobsThinking: string;
  scheduledJobsEffortMinimal: string;
  scheduledJobsEffortLow: string;
  scheduledJobsEffortMedium: string;
  scheduledJobsEffortHigh: string;
  scheduledJobsEffortMax: string;
  scheduledJobsInferredFromThread: string;
  scheduledJobsThreadId: string;
  scheduledJobsNewThread: string;
  scheduledJobsSchedule: string;
  scheduledJobsInterval: string;
  scheduledJobsDaily: string;
  scheduledJobsWeekdays: string;
  scheduledJobsWeekly: string;
  scheduledJobsMonthly: string;
  scheduledJobsIntervalMinutes: string;
  scheduledJobsDailyTime: string;
  scheduledJobsMonthlyDay: string;
  scheduledJobsMonthlyTime: string;
  scheduledJobsWeeklyDay: string;
  scheduledJobsSunday: string;
  scheduledJobsMonday: string;
  scheduledJobsTuesday: string;
  scheduledJobsWednesday: string;
  scheduledJobsThursday: string;
  scheduledJobsFriday: string;
  scheduledJobsSaturday: string;
  scheduledJobsTimezone: string;
  scheduledJobsAdvanced: string;
  scheduledJobsWorkDir: string;
  scheduledJobsSave: string;
  scheduledJobsSaving: string;
  scheduledJobsCancel: string;
  scheduledJobsEnabled: string;
  scheduledJobsDisabled: string;
  scheduledJobsNextRun: string;
  scheduledJobsStatus: string;
  scheduledJobsDeleteConfirm: (name: string) => string;
  scheduledJobsAt: string;
  scheduledJobsCron: string;
  scheduledJobsFireAt: string;
  scheduledJobsCronExpr: string;
  scheduledJobsDeleteAfterRun: string;
  scheduledJobsTimeout: string;

  // onboarding wizard (desktop)
  onboarding: {
    welcomeDesc: string;
    getStarted: string;
    modeTitle: string;
    modeDesc: string;
    saasTitle: string;
    saasDesc: string;
    localTitle: string;
    localDesc: string;
    selfHostTitle: string;
    selfHostDesc: string;
    saasLoginHint: string;
    localDownloading: string;
    localDownloadFailed: string;
    localRetryDownload: string;
    localDownloadComplete: string;
    localStarting: string;
    localProviderTitle: string;
    localProviderDesc: string;
    localProviderVendor: string;
    localProviderApiKey: string;
    localProviderApiKeyPlaceholder: string;
    localProviderBaseUrl: string;
    localProviderBaseUrlPlaceholder: string;
    localProviderVerify: string;
    localProviderVerifying: string;
    localProviderVerified: string;
    localProviderFailed: string;
    localProviderSkip: string;
    localProviderSkipConfig: string;
    localImportModels: string;
    localImportModelsDesc: string;
    localSelectModels: string;
    localAddModel: string;
    localManualModelPlaceholder: string;
    localImportingModels: string;
    localModelsImported: string;
    localNoModels: string;
    localNoImportableModels: string;
    localConfiguredModels: string;
    localNoConfiguredModels: string;
    localSearchModels: string;
    localModelsShowing: (total: number, enabled: number) => string;
    localModulesTitle: string;
    localModulesDesc: string;
    localModulesInstallerOffline: string;
    localModulesContinue: string;
    localModulesSkip: string;
    localModulesRecommended: string;
    localModulesInstalled: string;
    localModulesInstalling: string;
    localModulesDependsOn: string;
    localModulesSandboxTitle: string;
    localModulesSandboxDesc: string;
    localModulesMemoryTitle: string;
    localModulesMemoryDesc: string;
    localModulesSearchTitle: string;
    localModulesSearchDesc: string;
    localModulesCrawlerTitle: string;
    localModulesCrawlerDesc: string;
    localModulesBrowserTitle: string;
    localModulesBrowserDesc: string;
    importTitle: string;
    importDesc: string;
    importDetectedAt: (path: string) => string;
    importAgentIdentity: string;
    importAgentIdentityHermesDesc: string;
    importAgentIdentityOpenClawDesc: string;
    importSkills: string;
    importSkillsDesc: (count: number) => string;
    importMcpServers: string;
    importMcpServersDesc: (servers: string) => string;
    importLlmProviders: string;
    importLlmProvidersDesc: (providers: string) => string;
    importSkip: string;
    importSelected: string;
    importFrom: (source: string) => string;
    selfHostUrlLabel: string;
    selfHostUrlPlaceholder: string;
    selfHostTest: string;
    selfHostTesting: string;
    selfHostConnected: string;
    selfHostFailed: string;
    completionTitle: string;
    completionDesc: string;
    completionModulesHint: string;
    startChatting: string;
    back: string;
    next: string;
    skip: string;
    stepOf: (current: number, total: number) => string;
    comingSoon: string;
    greeting: string;
    appearanceTitle: string;
    appearanceDesc: string;
    languageLabel: string;
  };

  // projects - kanban
  projectsKanbanPending: string;
  projectsKanbanActive: string;
  projectsKanbanReview: string;
  projectsKanbanDone: string;
  projectsKanbanStopped: string;
  projectsKanbanNoTasks: string;
  projectsKanbanAddRequirement: string;
  projectsKanbanRequirementPlaceholder: string;
  projectsKanbanAutoAssign: string;
  projectsKanbanAddRow: string;
  projectsKanbanMarkDone: string;
  projectsKanbanCancel: string;
  projectsKanbanSave: string;
  projectsKanbanAddTaskFailed: string;

  // projects - detail page
  projectsDetailPlan: string;
  projectsDetailKanban: string;
  projectsDetailActivity: string;
  projectsDetailDeliverables: string;
  projectsDetailApprove: string;
  projectsDetailDispatch: string;
  projectsDetailDeliver: string;
  projectsDetailConfirmDone: string;
  projectsDetailExport: string;

  // projects - page
  projectsPageTitle: string;
  projectsPageAgents: string;
  projectsPageNewProject: string;
  projectsPageNewAgent: string;
  projectsPageEmpty: string;
  projectsPageEmptyDesc: string;
  projectsPageCreateFirst: string;
  projectsPageOffline: string;

  // projects - knowledge and rules tab
  projectsPrinciplesOperationUnknown: string;
  projectsPrinciplesInputInvalid: string;
  projectsPrinciplesProjectionUnavailable: string;
  projectsPrinciplesRefresh: string;
  projectsPrinciplesTab: string;
  projectsPrinciplesAdd: string;
  projectsPrinciplesImportMemory: string;
  projectsPrinciplesEmpty: string;
  projectsPrinciplesEmptyDesc: string;
  projectsKnowledgeTab: string;
  projectsRulesTab: string;
  projectsKnowledgeBuiltin: string;
  projectsKnowledgeDefault: string;
  projectsKnowledgeMine: string;
  projectsKnowledgeWorkspace: string;
  projectsKnowledgeConflicts: string;
  projectsKnowledgeReadOnly: string;
  projectsKnowledgeNoConflicts: string;
  projectsRulesBuiltin: string;
  projectsRulesMine: string;
  projectsRulesWorkspace: string;
  projectsKnowledgeAdd: string;
  projectsRuleAdd: string;
  projectsKnowledgeCreateTab: string;
  projectsRuleCreateTab: string;
  projectsKnowledgeDocumentLabel: string;
  projectsRuleItemLabel: string;
  projectsKnowledgeUpload: string;
  projectsRuleContentPlaceholder: string;
  projectsRuleContentTooLong: string;
  projectsRuleSeverity: string;
  projectsRuleSeverityHard: string;
  projectsRuleSeveritySoft: string;
  projectsKnowledgeView: string;
  projectsKnowledgeClose: string;
  projectsKnowledgeExtractRules: string;
  projectsKnowledgeExtracting: string;
  projectsKnowledgeExtractedRules: string;
  projectsKnowledgeSaveRules: string;
  projectsKnowledgeRulesSaved: string;
  projectsKnowledgeExtractEmpty: string;
  projectsKnowledgeExtractFailed: string;
  projectsKnowledgeSaveFailed: string;
  projectsPrinciplesSource: string;
  projectsPrinciplesSourceManual: string;
  projectsPrinciplesSourceMemory: string;
  projectsPrinciplesEdit: string;
  projectsPrincipleMoveToRules: string;
  projectsPrinciplesDelete: string;
  projectsPrinciplesDeleteConfirm: string;
  projectsPrinciplesDeleteConfirmBody: string;
  projectsPrinciplesDeleteCancel: string;
  projectsPrinciplesEnabled: string;
  projectsPrinciplesDisabled: string;
  projectsPrinciplesScenarioPlanning: string;
  projectsPrinciplesScenarioExecution: string;
  projectsPrinciplesScenarioReview: string;
  projectsPrinciplesScenarioDelivery: string;
  projectsPrinciplesEditTitle: string;
  projectsPrinciplesEditTitleNew: string;
  projectsPrinciplesEditContent: string;
  projectsPrinciplesEditContentPlaceholder: string;
  projectsPrinciplesEditScenarios: string;
  projectsPrinciplesEditScenariosHint: string;
  projectsPrinciplesEditEnabled: string;
  projectsPrinciplesEditSave: string;
  projectsPrinciplesEditCancel: string;
  projectsPrinciplesImportTitle: string;
  projectsPrinciplesImportSearch: string;
  projectsPrinciplesImportEmpty: string;
  projectsPrinciplesImportBtn: string;
  projectsPrinciplesImportSuccess: (count: number) => string;
  projectsPrinciplesLimitReached: string;
  projectsPrinciplesContentTooLong: string;
  projectsPrinciplesInjectHint: (planning: number, execution: number) => string;

  // projects - create project modal
  projectsCreateTitle: string;
  projectsCreateName: string;
  projectsCreateGoal: string;
  projectsCreateRequirements: string;
  projectsCreatePoAgent: string;
  projectsCreateWorkerAgent: string;
  projectsCreateWorkDir: string;
  projectsCreateCancel: string;
  projectsCreateCreating: string;
  projectsCreateSubmit: string;

  // projects - summary
  projectsSummaryEnable: string;
  projectsSummaryTitle: string;

  // projects - create agent modal
  projectsAgentTypeTitle: string;
  projectsAgentTypeWorker: string;
  projectsAgentTypePo: string;
  projectsAgentTypeAll: string;
  projectsAgentName: string;
  projectsAgentCreating: string;
  projectsAgentCreate: string;

  // projects - edit agent modal
  projectsEditAgentTitle: string;
  projectsEditAgentName: string;
  projectsEditAgentModel: string;
  projectsEditAgentModelHint: string;
  projectsEditAgentInstructions: string;
  projectsEditAgentClose: string;
  projectsEditAgentSaving: string;
  projectsEditAgentSave: string;
  projectsEditAgentFallbackToDesktopModel: string;
  projectsEditAgentFallbackToDesktopModelHint: string;
  projectsAgentModelFollowCurrent: string;
  projectsAgentModelUnavailable: string;
  projectsAgentModelVision: string;
  projectsAgentModelNoVision: string;
  projectsAgentModelFallbackHint: string;
  projectsAgentModelLoadFailed: string;
  projectsEditAgentAlreadyUsesDesktopModel: string;

  // projects - agents tab
  projectsAgentStatusIdle: string;
  projectsAgentStatusWorking: string;
  projectsAgentStatusBlocked: string;
  projectsAgentStatusError: string;
  projectsAgentStatusOffline: string;
  projectsAgentRoleAll: string;
  projectsAgentRolePo: string;
  projectsAgentRoleWorker: string;
  projectsAgentRoleUniversal: string;
  projectsAgentNoAgents: string;
  projectsAgentStart: string;
  projectsAgentStop: string;
  projectsAgentConfig: string;
  projectsAgentConfirm: string;
  projectsAgentArchive: string;
  projectsAgentCheckAll: string;
  projectsAgentCheckingAll: (done: number, total: number) => string;
  projectsAgentCheckSummary: (total: number, available: number, limited: number, unavailable: number) => string;
  projectsAgentProbeAvailable: string;
  projectsAgentProbeUnavailable: string;
  projectsAgentProbeLimited: string;
  projectsAgentProbeUntested: string;

  // projects - activity timeline
  projectsActivityCreated: string;
  projectsActivityPoAssigned: string;
  projectsActivityApproved: string;
  projectsActivityDispatched: string;
  projectsActivityInProgress: string;
  projectsActivitySubmitted: string;
  projectsActivityDone: string;
  projectsActivityRework: string;
  projectsActivityFailed: string;
  projectsActivityCancelled: string;
  projectsActivityEmpty: string;

  // projects - card status
  projectsStatusDraft: string;
  projectsStatusPlanning: string;
  projectsStatusCreated: string;
  projectsStatusActive: string;
  projectsStatusReview: string;
  projectsStatusDelivered: string;
  projectsStatusClosed: string;

  // projects - card
  projectsCardJustNow: string;
  projectsCardMinutesAgo: string;
  projectsCardHoursAgo: string;
  projectsCardDeleteConfirm: string;

  // projects - deliverables
  projectsDeliverableTitle: string;
  projectsDeliverableEmpty: string;
  projectsDeliverablePreview: string;
  projectsDeliverableDownload: string;
  projectsDeliverableDeliveredAt: string;
  projectsDeliverableUnknownType: string;

  // projects - plan view
  projectsPlanEmpty: string;
  projectsPlanNoTasks: string;
  projectsPlanAnalysis: string;
  projectsPlanCriteria: string;

  // projects - artifact preview
  projectsArtifactNoPath: string;
  projectsArtifactLoadFailed: string;
  projectsArtifactUnsupported: string;
  projectsArtifactEmpty: string;
  projectsDiscussPrefix: (name: string) => string;
  projectsCreateAgentNamePlaceholder: string;
  projectsCreateAgentInstructionsPlaceholder: string;
  projectsCreateProjectNamePlaceholder: string;
  projectsCreateProjectGoalPlaceholder: string;
  projectsCreateProjectRequirementsPlaceholder: string;
  projectsInterventionNeedsAttention: string;

  // sidebar - desktop
  sidebarSearch: string;
  sidebarCategories: string;
  sidebarTabTasks: string;
  sidebarTabScheduled: string;
  sidebarTabProjects: string;
  sidebarTabCollaboration: string;
  sidebarAllProjects: string;
  sidebarAllRooms: string;
  sidebarEmptyScheduled: string;
  sidebarEmptyProjects: string;
  sidebarEmptyRooms: string;
  sidebarRoomsUnavailable: string;
  sidebarRetry: string;
  sidebarAutomations: string;
  sidebarScheduled: string;
  sidebarProjects: string;
  sidebarCollaboration: string;
  sidebarNewTask: string;
  sidebarRecent: string;
  sidebarNoResults: string;
  sidebarNoRecent: string;
  sidebarRename: string;
  sidebarKnowledge: string;
  // sidebar - update popover
  sidebarUpdateNewVersion: string;
  sidebarUpdateCheckIncomplete: string;
  sidebarUpdateUpgradeTo: (version: string) => string;
  sidebarUpdateFoundNewVersion: string;
  sidebarUpdateCheckIncompleteHint: string;
  sidebarUpdateFoundVersionHint: (version: string) => string;
  sidebarUpdateClosePopover: string;
  sidebarUpdateClose: string;
  sidebarUpdateAutoCheckFailed: string;
  sidebarUpdateHandoffUnconfirmed: string;
  sidebarUpdateHandoffUnconfirmedHint: string;
  sidebarUpdateInstallNotReady: string;
  sidebarUpdateManualDownload: string;
  sidebarUpdateGoToGithub: string;
  sidebarUpdateDownloadHint: string;
  sidebarUpdateDownloading: string;
  sidebarUpdateReadyToInstall: string;
  sidebarUpdateDownloadNow: string;
  sidebarUpdateInstallNow: string;
  sidebarUpdateInstalling: string;
  // sidebar - tooltip labels
  sidebarTooltipProject: string;
  sidebarTooltipStatus: string;
  sidebarTooltipProjectId: string;
  sidebarTooltipScheduledTask: string;
  sidebarTooltipFrequency: string;
  sidebarTooltipTaskId: string;
  sidebarTooltipThreadId: string;
  sidebarTooltipRuntimeTaskId: string;
  sidebarTooltipRecentTask: string;
  sidebarTooltipCurrentTaskId: string;

  // welcome page
  welcome: {
    brandName: string;
    greetingSuffix: string;
    inputPlaceholder: string;
    goalQuickPrompt: string;
    subagentQuickPrompt: string;
    subagentPrompt: string;
    quickPrompts: readonly string[];
    conversationSubtitle: string;
    overviewTitle: string;
    readOnlySummary: string;
    activeProjects: string;
    needsAttention: string;
    activeAutomations: string;
    recentlyCompleted: string;
    continueWork: string;
    topItemsOnly: string;
    noAttention: string;
    automationLoading: string;
    automationUnavailable: string;
    projectsUnavailable: string;
    nextStep: (value: string) => string;
    statusNeedsAction: string;
    statusFailed: string;
    openAttentionItem: (title: string, status: string, reason?: string, nextStep?: string) => string;
  };

  assistant: {
    operationUnknown: string;
    refreshStatus: string;
    title: string;
    morningScheduleName: string;
    eveningScheduleName: string;
    loading: string;
    unavailable: string;
    consentDescription: string;
    activeDescription: (eveningTime: string, morningTime: string) => string;
    pausedTitle: string;
    pausedDescription: string;
    activate: string;
    pause: string;
    resume: string;
    noSuggestions: string;
    pendingCandidates: (count: number) => string;
    openDetails: string;
    detailTitle: string;
    closeDetails: string;
    detailSchedule: (eveningTime: string, morningTime: string) => string;
    candidatesTitle: string;
    candidateCount: (count: number) => string;
    noCandidates: string;
    candidateKind: (kind: 'memory' | 'knowledge' | 'follow_up') => string;
    confidence: (value: number) => string;
    evidence: (kind: string, id: string) => string;
    candidateStatusStaged: string;
    candidateStatusPending: string;
    candidateStatusAccepting: string;
    candidateStatusAccepted: string;
    candidateStatusRejected: string;
    candidateStatusSuperseded: string;
    candidateStatusAcceptFailed: string;
    acceptCandidate: string;
    rejectCandidate: string;
    acceptCandidateLabel: (title: string) => string;
    rejectCandidateLabel: (title: string) => string;
    knowledgeCollection: string;
    selectKnowledgeCollection: string;
    noKnowledgeCollections: string;
    knowledgeCollectionLabel: (title: string) => string;
  };

  projectSmartTeam: {
    title: string;
    description: string;
    planAction: string;
    planning: string;
    proposalTitle: string;
    summaryAnalyzed: (count: number) => string;
    summaryNoChange: string;
    summaryManualScope: string;
    projectRevision: (revision: number) => string;
    actionKeep: string;
    actionReuse: string;
    actionCreate: string;
    reasonExistingMatch: string;
    reasonCapabilityGap: string;
    reasonPolicyDecision: string;
    applyAction: string;
    applying: string;
    manualAction: string;
    operationPending: string;
    operationRunning: string;
    operationCompleted: string;
    operationFailed: string;
    operationDefaultMessage: string;
    operationId: (operationId: string) => string;
    planFailed: string;
    applyFailed: string;
    restoreFailed: string;
  };

  // knowledge page
  knowledge: {
    projectionUnavailable: string;
    operationUnknown: string;
    inputInvalid: string;
    refreshData: string;

    loading: string;
    pageTitle: string;
    emptyTitle: string;
    emptyDesc: string;
    emptyPrivacy: string;
    createFirstCollection: string;
    newCollection: string;
    deleteCollectionConfirm: string;
    defaultPasteTitle: string;
    privacyNotice: string;
    privacyDismiss: string;
    chunkCount: (count: number) => string;
    selectCollection: string;
    searchPlaceholder: string;
    searching: string;
    searchBtn: string;
    searchResultsTitle: (count: number) => string;
    pageLabel: (page: number) => string;
    dropToAdd: string;
    pickFiles: string;
    pasteText: string;
    addUrl: string;
    meetingImport: string;
    meetingImportTitle: string;
    meetingRecordQuickStart: string;
    meetingRecorderTitle: string;
    meetingDefaultTitle: string;
    meetingRecordingDefaultTitle: (timestamp: string) => string;
    meetingTitleLabel: string;
    meetingRecordingTitleLabel: string;
    meetingTitlePlaceholder: string;
    meetingAudioLabel: string;
    meetingPickAudio: string;
    meetingRecordStart: string;
    meetingRecordStop: string;
    meetingRecordPause: string;
    meetingRecordResume: string;
    meetingAudioLevelLabel: string;
    meetingLatestTranscriptTitle: string;
    meetingRecorderTranscriptTitle: string;
    meetingRecorderHighlightsTitle: string;
    meetingRecorderHighlightsEmpty: string;
    meetingRecorderMinimize: string;
    meetingRecorderExpand: string;
    meetingRecorderSummaryTab: string;
    meetingRecorderTranscriptTab: string;
    meetingRecorderEditSummary: string;
    meetingRecorderFinishEditing: string;
    meetingRecorderProcessingTitle: string;
    meetingRecorderProcessingHint: string;
    meetingRecorderInputInvalid: string;
    meetingRecorderOperationUnknown: string;
    meetingRecorderSavedFollowupFailed: string;
    meetingRecorderNewDraftUnsaved: string;
    meetingRecorderCloseBlocked: string;
    meetingSettings: string;
    meetingControlPanelTitle: string;
    meetingLiveTranscriptTitle: string;
    meetingSummaryDraftTitle: string;
    meetingSummaryDraftLabel: string;
    meetingSummaryDraftPlaceholder: string;
    meetingSpeechEngineLabel: string;
    meetingSpeechEngineSherpaOnnxParaformer: string;
    meetingSpeechEngineWhisperFallback: string;
    meetingSpeechEngineVolcengineAsr: string;
    meetingSpeechEngineAliyunAsr: string;
    meetingSpeechEngineSherpaOnnxName: string;
    meetingSpeechEngineWhisperName: string;
    meetingSpeechModelOption: (engineName: string, modelId: string, sizeLabel?: string) => string;
    meetingSpeechModelSherpaOnnxParaformerSmall: string;
    meetingSpeechModelLabel: string;
    meetingLanguageLabel: string;
    meetingLanguageZh: string;
    meetingLanguageAuto: string;
    meetingLanguageEn: string;
    meetingScenarioLabel: string;
    meetingScenarioDiscussion: string;
    meetingScenarioMeeting: string;
    meetingScenarioSales: string;
    meetingModelDownloadStatusTitle: string;
    meetingSpeechModelsStatusTitle: string;
    meetingPunctuationModelsStatusTitle: string;
    meetingModelStatusLoading: string;
    meetingModelStatusDownloaded: string;
    meetingModelStatusNotDownloaded: string;
    meetingModelStatusIncomplete: string;
    meetingModelStatusCorrupt: string;
    meetingModelStatusDownloading: string;
    meetingModelStatusUnavailable: string;
    meetingModelStatusLocalSize: (localSize: string, expectedSize: string) => string;
    meetingModelStatusLoadFailed: (reason: string) => string;
    meetingModelDownload: string;
    meetingModelRedownload: string;
    meetingModelUninstall: string;
    meetingModelActionRunning: string;
    meetingModelDownloadAria: (fileName: string) => string;
    meetingModelRedownloadAria: (fileName: string) => string;
    meetingModelUninstallAria: (fileName: string) => string;
    meetingModelActionFailed: (reason: string) => string;
    meetingOnlineAsrConfigTitle: string;
    meetingOnlineAsrConfigured: (providerName: string) => string;
    meetingOnlineAsrNotConfigured: (providerName: string) => string;
    meetingOnlineAsrSaveFailed: (reason: string) => string;
    meetingRecording: string;
    meetingRecordingPaused: string;
    meetingRecordingReady: string;
    meetingRecordingSaving: string;
    meetingNoAudioSelected: string;
    meetingTranscriptLabel: string;
    meetingTranscriptPlaceholder: string;
    meetingTranscriptPreviewLabel: string;
    meetingTranscriptPreviewEmpty: string;
    meetingListening: string;
    meetingSave: string;
    meetingSaving: string;
    meetingPickFailed: string;
    meetingRecordUnavailable: string;
    meetingPermissionDenied: string;
    meetingRecordedAudioSaved: string;
    meetingTranscribing: string;
    meetingDraftReady: string;
    meetingRecordFailed: (reason: string) => string;
    meetingLiveTranscriptionFailed: (reason: string) => string;
    meetingProcessError: (reason: string) => string;
    meetingImportSaved: string;
    meetingImportError: (reason: string) => string;
    openSource: (title: string) => string;
    sourceContentTitle: string;
    sourceContentLoading: string;
    sourceContentEmpty: string;
    sourceOpenFailed: (reason: string) => string;
    close: string;
    orDragFiles: string;
    titleOptional: string;
    pasteContentPlaceholder: string;
    cancel: string;
    addSource: string;
    addUrlBtn: string;
    emptyCollection: string;
    emptyCollectionHint: string;
    statusParsed: string;
    statusPending: string;
    statusParsing: string;
    statusFailed: string;
    createCollectionTitle: string;
    collectionNamePlaceholder: string;
    createBtn: string;
  };

  // automations page
  automationsTitle: string;
  automationsSubtitle: string;
  automationsOverview: string;
  automationsSchedules: string;
  automationsLoops: string;
  automationsDiagnostics: string;
  automationsOverviewTitle: string;
  automationsOverviewDesc: string;
  automationsSchedulesDesc: string;
  automationsLoopsDesc: string;
  automationsDiagnosticsDesc: string;
  automationsGlobalAutoRunEnabled: string;
  automationsGlobalAutoRunDisabled: string;
  automationsGlobalAutoRunPause: string;
  automationsGlobalAutoRunEnable: string;
  automationsGlobalAutoRunDesc: string;
  automationsOverviewRecentFailures: string;
  automationsOverviewNoRecentFailures: string;
  automationsOverviewLoopsCount: string;
  automationsOverviewSchedulesCount: string;
  automationsOverviewFailuresCount: string;

  // automation constraints (loop self-improving feedback)
  automationsConstraints: string;
  automationsConstraintsDesc: string;
  automationsConstraintsEmpty: string;
  automationsConstraintsLoopFilterAll: string;
  automationsConstraintsActive: string;
  automationsConstraintsPending: string;
  automationsConstraintsArchived: string;
  automationsConstraintsSourceLLM: string;
  automationsConstraintsSourceRule: string;
  automationsConstraintsSourceManual: string;
  automationsConstraintsHits: (count: number) => string;
  automationsConstraintsConfirm: string;
  automationsConstraintsActivate: string;
  automationsConstraintsDeactivate: string;
  automationsConstraintsDeactivationReasonStale: string;
  automationsConstraintsDeactivationReasonIneffective: string;
  automationsConstraintsDeactivationReasonOverflow: string;
  automationsConstraintsDeactivationReasonSuperseded: string;
  automationsConstraintsDeactivationReasonUser: string;
  automationsConstraintsCreatedAt: string;
  automationsConstraintsFromFailure: string;
  automationsConstraintsToastConfirmed: string;
  automationsConstraintsToastDeactivated: string;
  automationsConstraintsToastReactivated: string;
  automationsConstraintsToastFailed: string;
  automationsConstraintsNewBadge: string;

  // scheduled page
  scheduledProjectionUnavailable: string;
  scheduledOperationUnknown: string;
  scheduledInputInvalid: string;
  scheduledRefreshData: string;
  scheduledMutationNotApplied: string;
  scheduledTitle: string;
  scheduledSubtitle: string;
  scheduledNew: string;
  scheduledEmpty: string;
  scheduledEmptyDesc: string;
  scheduledCreateFirst: string;
  scheduledCreateTitle: string;
  scheduledEditTitle: string;
  scheduledName: string;
  scheduledDescription: string;
  scheduledInstructions: string;
  scheduledFrequency: string;
  scheduledInterval: string;
  scheduledRunAt: string;
  scheduledDayOfWeek: string;
  scheduledManual: string;
  scheduledHourly: string;
  scheduledEvery30Sec: string;
  scheduledEveryMinute: string;
  scheduledEvery5Min: string;
  scheduledEvery30Min: string;
  scheduledEveryHour: string;
  scheduledEvery2Hours: string;
  scheduledEvery3Hours: string;
  scheduledEvery4Hours: string;
  scheduledEvery6Hours: string;
  scheduledEvery8Hours: string;
  scheduledEvery12Hours: string;
  scheduledDaily: string;
  scheduledWeekdays: string;
  scheduledWeekly: string;
  scheduledSun: string;
  scheduledMon: string;
  scheduledTue: string;
  scheduledWed: string;
  scheduledThu: string;
  scheduledFri: string;
  scheduledSat: string;
  scheduledActive: string;
  scheduledPaused: string;
  scheduledRun: string;
  scheduledView: string;
  scheduledPause: string;
  scheduledResume: string;
  scheduledDeleteConfirm: string;
  scheduledDeleteTitle: string;
  scheduledDeleteBody: string;
  scheduledDeleteInstanceConfirm: string;
  scheduledDeleteInstanceTitle: string;
  scheduledDeleteInstanceBody: string;
  scheduledLastRun: string;
  scheduledNextRun: string;
  scheduledSave: string;
  scheduledSaving: string;
  scheduledCancel: string;
  scheduledPlanModeBadge: string;
  scheduledPlanModeHint: string;
  scheduledApproveAuto: string;
  scheduledApproveAutoTitle: string;
  scheduledApproveAutoNeedsReview: string;
  scheduledRevokeAuto: string;
  scheduledRevokeAutoTitle: string;
  scheduledAutoExecCreatedNotice: string;
  scheduledHighFreqConfirmBody: string;
  scheduledStaleConflict: string;
  scheduledLinkedLoop: string;

  // chatView
  conversationActivity: {
    submitInput: string; declineInput: string; cancelWork: string; cancelRequested: string; unsupportedInput: string;
    title: string; stopped: string; unavailable: string; projectClosed: string; historyGap: string; details: string; lastUpdate: string; lastProgress: string; nextReport: string;
    frequency: string; normal: string; criticalOnly: string; quiet: string; stop: string; stopHint: string; noProgress: string; error: string;
    report: (state: string, time: string) => string;
    unread: (count: number) => string;
    sources: Record<'kswarm' | 'task_host' | 'agent_group' | 'mcp', string>;
    states: Record<'accepted' | 'queued' | 'running' | 'blocked' | 'input_required' | 'completed' | 'failed' | 'cancelled', string>;
  };
  chatView: {
    executionSyncing: string;
    executionDisconnected: string;
    executionQueued: string;
    executionApproval: string;
    executionRunning: string;
    executionFinishing: string;
    copyTitle: string;
    saveToKbTitle: string;
    chatExcerpt: string;
    addedToKb: string;
    noCollections: string;
    titleOptional: string;
    cancel: string;
    saving: string;
    save: string;
    needsComputerUse: string;
    cuDefaultMessage: string;
    cuProcessing: string;
    cuEnabled: string;
    enableComputerUse: string;
    cuDismiss: string;
    taskFailed: string;
    scrollToBottom: string;
    conversationIndexLabel: string;
    conversationIndexItem: (index: number, preview: string) => string;
    conversationIndexUntitled: string;
    inputPlaceholder: string;
    replyPlaceholder: string;
    artifact: string;
    addToKb: string;
    added: string;
    taskResult: string;
    open: string;
    a2uiLoadFailed: string;
    a2uiLoading: string;
  };

  goalBar: {
    verificationDefinition: string;
    verificationDefinitionHelp: string;
    verificationDefinitionInvalid: string;
    nativePending: string;
    recoverNative: string;
    continueNative: string;
    cancelNative: string;
    nativeRetired: string;

    statusVerificationUnavailable: string;
    statusNeedsRevalidation: string;
    statusPublicationPending: string;
    statusBindingPending: string;
    statusBindingRequired: string;
    statusBindingMismatch: string;
    statusVerifiedComplete: string;
    createGoal: string;
    goal: string;
    completionCriterion: string;
    evidence: string;
    evidenceAnswer: string;
    evidenceFile: string;
    evidenceCommand: string;
    evidenceProject: string;
    turnBudget: string;
    confirmCreate: string;
    close: string;
    pause: string;
    recoverPublication: string;
    continuePublication: string;
    resume: string;
    retry: string;
    cancelGoal: string;
    replaceGoal: string;
    newTurnBudget: string;
    increaseBudgetAndResume: string;
    turns: (used: number, limit: number) => string;
    tokens: (tokens: number) => string;
    tokensUnknown: string;
    statusActive: string;
    waitingChildren: string;
    childrenNeedAttention: string;
    statusPaused: string;
    statusBlocked: string;
    statusComplete: string;
    statusCancelled: string;
    statusDisarmed: string;
    budgetExhausted: string;
    showDetails: string;
    hideDetails: string;
  };

  // chatInput
  chatInput: {
    replyPlaceholder: string;
    processFiles: string;
    skillCommandHint: string;
    queued: string;
    attachFiles: string;
    send: string;
    mentionHint: string;
    modelPicker: {
      empty: string;
      tooltip: string;
      activeBadge: string;
      effortLabel: string;
      effortDefault: string;
      effortHint: string;
      effortNone: string;
      effortMinimal: string;
      effortLow: string;
      effortMedium: string;
      effortHigh: string;
      effortXhigh: string;
      effortMax: string;
    };
  };

  // chatShell
  chatShell: {
    attachmentLabel: string;
    cuUnavailable: string;
    historyUnavailable: (taskIds: string) => string;
    historyRecovered: (taskId: string) => string;
    taskCreateFailed: string;
    goalAttachmentQuerying: string;
    goalAttachmentUnknown: string;
    taskExecutionFailed: (reason: string) => string;
    modelAuthFailed: string;
    modelServiceFailed: string;
    modelConnectionFailed: string;
    modelUsageLimitReached: (resetAt?: string) => string;
    cuProcessing: string;
    cuSettingsOpened: string;
    cuReady: string;
    cuActionUnsupported: string;
    cuConnectedNoTarget: string;
    cuConnectFailed: string;
    cuDismissed: string;
  };

  // scheduled page (hardcoded strings)
  scheduledEveryNMinutes: (n: number) => string;
  scheduledLoopCreated: string;
  scheduledLoopCreateFailed: (detail: string) => string;
  scheduledLoopAlreadyRunning: string;
  scheduledLoopPaused: string;
  scheduledLoopMissing: string;
  scheduledLoopDeleted: string;
  scheduledLoopStarted: string;
  scheduledLoopBlockedOrFailed: (status: string) => string;
  scheduledLastRunLabel: string;
  scheduledNextLabel: string;
  scheduledNamePlaceholder: string;
  scheduledDescPlaceholder: string;
  scheduledPromptPlaceholder: string;

  // app layout
  appLayoutBack: string;
  appLayoutForward: string;
  appLayoutExpandSidebar: string;
  appLayoutCollapseSidebar: string;

  // canvas preview
  canvasPreviewUnsupported: string;
  canvasPreviewOpenSystem: string;
  canvasPreviewDownload: string;
  canvasPreviewRefresh: string;
  canvasPreviewPdfLabel: (fileName: string) => string;
  canvasPreviewPdfRendering: string;
  canvasPreviewPdfFailed: string;
  canvasPreviewPdfLoading: string;
  canvasPreviewUnavailable: string;

  // canvas panel
  canvasPanelCollapseCanvas: string;
  canvasPanelExpandCanvas: string;
  artifactWorkspace: {
    title: string;
    close: string;
    panelClose: string;
    previewTab: string;
    canvasTab: string;
    workspaceTab: string;
    toolsTab: string;
    workspaceFilesEmpty: string;
    previewEmpty: string;
    previewLoadFailed: string;
    toolsEmpty: string;
    loading: string;
    empty: string;
    retry: string;
    readOnly: string;
    compareVersions: string;
    compareTitle: string;
    closeCompare: string;
    preferred: string;
    missing: string;
    setPreferred: string;
    download: string;
    createRevision: string;
    reviseWithAnnotations: string;
    useAsReference: string;
    addToCollection: string;
    continueFromHere: string;
    generationFailed: string;
    generationCancelled: string;
    recoveryRequired: string;
    placeholderDraft: string;
    placeholderGenerating: string;
    nodeRemoved: string;
    zoomIn: string;
    zoomOut: string;
    fitView: string;
    removeTitle: string;
    removeBody: string;
    cancel: string;
    remove: string;
    detailTitle: string;
    previewFrameTitle: string;
    newCollection: string;
    newNote: string;
    collectionTitle: string;
    noteText: string;
    saveCollection: string;
    saveNote: string;
    selectCollection: string;
    annotationPrompt: (versionId: string) => string;
    referencePrompt: (versionId: string) => string;
    continuePrompt: (versionId: string) => string;
    statusLabel: (status: string) => string;
  };

  // document panel
  documentPanelAddToKb: string;
  documentPanelLoading: string;

  // task panel
  taskPanelProgress: string;
  taskPanelResults: string;

  // mermaid block
  mermaidEmpty: string;
  mermaidRendering: string;

  // artifact toolbar
  artifactFinishRevision: string;
  artifactStartRevision: string;
  artifactRevision: string;
  artifactRefreshPreview: string;
  artifactRevertChanges: string;
  artifactRevert: string;
  artifactFinishEditing: string;
  artifactFinish: string;
  artifactWaitingAgent: string;
  artifactAgentNotResponding: string;
  artifactDirectEdit: string;
  artifactHtmlEdit: string;
  artifactHtmlStopEditing: string;
  artifactHtmlSave: string;
  artifactHtmlApply: string;
  artifactHtmlUndo: string;
  artifactHtmlRedo: string;
  artifactHtmlInspectorTitle: string;
  artifactHtmlSelectHint: string;
  artifactHtmlNoSelection: string;
  artifactHtmlTextLabel: string;
  artifactHtmlLinkTextLabel: string;
  artifactHtmlHrefLabel: string;
  artifactHtmlDeleteComponent: string;
  artifactHtmlStyleSection: string;
  artifactHtmlColorLabel: string;
  artifactHtmlFontSizeLabel: string;
  artifactHtmlFontFamilyLabel: string;
  artifactHtmlFontWeightLabel: string;
  artifactHtmlApplyStyle: string;
  artifactHtmlMediaSection: string;
  artifactHtmlImageUrlLabel: string;
  artifactHtmlImageAltLabel: string;
  artifactHtmlImageCaptionLabel: string;
  artifactHtmlChooseImageFile: string;
  artifactHtmlInsertImage: string;
  artifactHtmlSvgSourceLabel: string;
  artifactHtmlChooseSvgFile: string;
  artifactHtmlInsertSvg: string;
  artifactHtmlDirtyStatus: string;
  artifactHtmlSavedStatus: string;
  artifactHtmlApplyFailed: string;
  artifactHtmlSaveFailed: string;
  artifactHtmlUnsavedConfirm: string;
  artifactMarkdownTextLabel: string;
  artifactMarkdownPreview: string;
  artifactMarkdownSaving: string;

  // memory action block
  memoryActionWrite: string;
  memoryActionEdit: string;
  memoryActionSearch: string;
  memoryActionRead: string;
  memoryActionForget: string;
  memoryActionNotebookWrite: string;
  memoryActionNotebookRead: string;
  memoryActionNotebookEdit: string;
  memoryActionNotebookForget: string;
  memoryActionBlockTitle: string;

  // error callout
  errorCalloutClose: string;
  errorCalloutCollapse: string;
  errorCalloutExpand: string;

  // local memory stats
  localMemoryStatsLoading: string;
  localMemoryStatsCount: (n: number) => string;
  localMemoryStatsL0: string;
  localMemoryStatsL1: string;
  localMemoryStatsL2: string;
  localMemoryStatsL3: string;
  localMemoryStatsRefresh: string;
  localMemoryStatsLoadFailed: (detail: string) => string;
  localMemoryStatsEmpty: string;
  localMemoryStatsSource: (source: string) => string;

  // a2ui
  a2uiLoadFailed: string;
  a2uiLoading: string;
  a2uiRenderError: string;

  // sub-agent
  subAgentCompletedNoOutput: string;

  // email verification gate
  emailGateSendFailed: string;

  // run detail panel
  runDetailThreadLabel: string;
  runDetailExecutionLabel: string;

  // chat tool result messages
  chatWorkflowCompleted: string;
  chatWorkflowBlockedOrFailed: (status: string, reason: string) => string;
  chatWorkflowStarted: string;
  chatWorkflowProjectId: string;

  // automations page
  automationsRelativeJustNow: string;
  automationsRelativeMinutesAgo: (n: number) => string;
  automationsRelativeHoursAgo: (n: number) => string;
  automationsViewLoopDetail: string;
  automationsViewScheduleDetail: string;
  automationsClearRecord: string;
  loopOperationResultUnknown: string;
  loopProjectionUnavailable: string;
  loopInputInvalid: string;
  automationsClearConfirm: (title: string) => string;

  // user loop starter templates
  loopTemplateDailyWorkSummary: string;
  loopTemplateDailyWorkSummaryDesc: string;
  loopTemplateIndustryNewsDaily: string;
  loopTemplateIndustryNewsDailyDesc: string;
  loopTemplateRepoChangesWatch: string;
  loopTemplateRepoChangesWatchDesc: string;
  loopTemplateScheduleHintEvening: string;
  loopTemplateScheduleHintMorning: string;

  // projects - workflow status strip
  projectsWorkflowStatusAwaitingApproval: string;
  projectsWorkflowStatusRunning: string;
  projectsWorkflowStatusBlocked: string;
  projectsWorkflowStatusCompleted: string;
  projectsWorkflowStatusFailed: string;
  projectsWorkflowStatusCancelled: string;
  projectsDiagnoseStatusAwaitingApproval: string;
  projectsDiagnoseStatusRunning: string;
  projectsDiagnoseStatusBlocked: string;
  projectsDiagnoseStatusCompleted: string;
  projectsDiagnoseStatusFailed: string;
  projectsDiagnoseStatusCancelled: string;
  projectsWorkflowIdle: string;
  projectsWorkflowIdleHint: string;
  projectsWorkflowRunBtn: string;
  projectsWorkflowRunningBtn: string;
  projectsWorkflowUnavailableBtn: string;
  projectsWorkflowRunAriaLabel: string;
  projectsWorkflowMenuAriaLabel: string;
  projectsWorkflowQuickDiagnose: string;
  projectsWorkflowQuickDiagnoseDesc: string;
  projectsWorkflowAgentReview: string;
  projectsWorkflowAgentReviewDesc: string;
  projectsWorkflowCancelRun: string;
  projectsWorkflowDialogDefault: string;
  projectsWorkflowDialogAgentReview: string;
  projectsWorkflowDiagnosisDialog: string;
  projectsWorkflowConfirmTitle: string;
  projectsWorkflowConfirmCancel: string;
  projectsWorkflowConfirmRun: string;
  projectsWorkflowAgentReviewName: string;
  projectsWorkflowPoTaskName: string;
  projectsWorkflowExecLabel: string;
  projectsWorkflowAgentLabel: string;
  projectsWorkflowCloseDialogPrefix: string;
  projectsWorkflowCompletedAwaitingDelivery: string;
  projectsWorkflowKswarmView: string;
  projectsWorkflowBuiltinSource: string;
  projectsWorkflowExecSource: string;
  projectsWorkflowNoAgentSource: string;
  projectsWorkflowGoalLabel: string;
  projectsWorkflowTaskLabel: string;
  projectsWorkflowPoGenHint: string;
  projectsWorkflowAcceptanceLabel: string;
  projectsWorkflowMachineCheck: string;
  projectsWorkflowReviewerCheck: string;
  projectsWorkflowAssumptions: string;
  projectsWorkflowPhases: string;
  projectsWorkflowPhaseNodes: (count: number) => string;
  projectsWorkflowDiagProjectStatus: string;
  projectsWorkflowDiagHealthState: string;
  projectsWorkflowDiagTasks: string;
  projectsWorkflowDiagBlocked: string;
  projectsWorkflowDiagWaiting: string;
  projectsWorkflowDiagDispatchable: string;
  projectsWorkflowDiagGate: string;
  projectsWorkflowDiagSuggestion: string;
  projectsWorkflowDiagBlockedTasks: string;
  projectsWorkflowDiagTaskBlocked: string;
  projectsWorkflowDiagEvidence: string;
  projectsWorkflowDiagCompactTasks: (count: number) => string;
  projectsWorkflowDiagNoBlocker: string;
  projectsWorkflowDiagBlockerCount: (count: number) => string;
  projectsWorkflowStrategyLabel: string;
  projectsWorkflowReasonLabel: string;
  projectsWorkflowPublicProgress: string;
  projectsWorkflowCurrentPhase: string;
  projectsWorkflowRecoverySuggestion: string;
  projectsWorkflowRecoveryLabel: string;
  projectsWorkflowLatestProgress: string;
  projectsWorkflowScriptCheckpoint: string;
  projectsWorkflowCheckpointWaiting: string;
  projectsWorkflowCheckpointFailed: string;
  projectsWorkflowParallelOrch: string;
  projectsWorkflowPolicy: string;
  projectsWorkflowBranch: string;
  projectsWorkflowBlockingFailures: string;
  projectsWorkflowCompletedCount: (done: number, total: number) => string;
  projectsWorkflowParallelBranch: string;

  // projects - workflow node status labels
  projectsNodeStatusPending: string;
  projectsNodeStatusReady: string;
  projectsNodeStatusRunning: string;
  projectsNodeStatusCompleted: string;
  projectsNodeStatusFailed: string;
  projectsNodeStatusBlocked: string;
  projectsNodeStatusCancelled: string;

  // projects - workflow progress labels
  projectsWorkflowProgressRunning: (progress: string) => string;
  projectsWorkflowProgressBlocked: (progress: string) => string;
  projectsWorkflowProgressFailed: (progress: string) => string;
  projectsWorkflowProgressCancelled: (progress: string) => string;
  projectsWorkflowProgressCompleted: (progress: string) => string;

  // projects - workflow failure policy labels
  projectsFailurePolicyRequiredAll: string;
  projectsFailurePolicyCollectErrors: string;
  projectsFailurePolicyFailFast: string;
  projectsFailurePolicyQuorum: string;
  projectsFailurePolicyDefault: string;

  // projects - workflow recovery labels
  projectsRecoveryResumeCompleted: string;
  projectsRecoveryWaitRuntime: string;
  projectsRecoveryRerunFromStart: string;
  projectsWorkflowCacheSaved: (count: number) => string;

  // projects - project status in workflow context
  projectsLabelStatusActive: string;
  projectsLabelStatusCreated: string;
  projectsLabelStatusDraft: string;
  projectsLabelStatusPlanning: string;
  projectsLabelStatusReview: string;
  projectsLabelStatusDelivered: string;
  projectsLabelStatusClosed: string;
  projectsLabelStatusUnknown: string;

  // projects - health state labels in workflow context
  projectsHealthIdle: string;
  projectsHealthHealthy: string;
  projectsHealthRunning: string;
  projectsHealthDispatchable: string;
  projectsHealthWaiting: string;
  projectsHealthNeedsReview: string;
  projectsHealthBlocked: string;
  projectsHealthFailed: string;
  projectsHealthComplete: string;
  projectsHealthClosed: string;
  projectsHealthUnknown: string;

  // projects - detail page (additional)
  projectsDetailAgentsTab: string;
  projectsDetailGraphTab: string;
  projectsDetailGraphLoading: string;
  projectsDetailGraphEmptyNoTasks: string;
  projectsDetailGraphEmptyTaskBoardNoDeps: string;
  projectsDetailGraphEmptyWorkflowNotStarted: string;
  projectsDetailGraphEmptyTooLarge: (count: number) => string;
  projectsDetailGraphReturnToBoard: string;
  projectsDetailGraphPartialBanner: string;
  projectsDetailGraphStatusPending: string;
  projectsDetailGraphStatusReady: string;
  projectsDetailGraphStatusRunning: string;
  projectsDetailGraphStatusReview: string;
  projectsDetailGraphStatusDone: string;
  projectsDetailGraphStatusFailed: string;
  projectsDetailGraphStatusBlocked: string;
  projectsDetailGraphStatusCancelled: string;
  projectsDetailGraphSkip: string;
  projectsDetailGraphReplay: string;
  projectsDetailGraphPoPlanLabel: string;
  projectsDetailGraphNodeKindWorkflow: string;
  projectsDetailGraphNodeKindTask: string;
  projectsDetailGraphDrawerClose: string;
  projectsDetailGraphDrawerTimeline: string;
  projectsDetailGraphDrawerStartedAt: string;
  projectsDetailGraphDrawerCompletedAt: string;
  projectsDetailGraphDrawerDuration: string;
  projectsDetailGraphDrawerError: string;
  projectsDetailGraphDrawerRenderError: string;
  projectsDetailGraphDrawerWorkflowMeta: string;
  projectsDetailGraphDrawerStageIndex: string;
  projectsDetailGraphDrawerParallelGroup: string;
  projectsDetailGraphDrawerAttempt: string;
  projectsDetailGraphDrawerProducerAgent: string;
  projectsDetailGraphDrawerCache: string;
  projectsDetailGraphDrawerInput: string;
  projectsDetailGraphDrawerOutput: string;
  projectsDetailGraphDrawerReview: string;
  projectsDetailGraphDrawerTaskMeta: string;
  projectsDetailGraphDrawerAcceptance: string;
  projectsDetailGraphDrawerArtifacts: string;
  projectsDetailGraphDrawerOpenInBoard: string;
  projectsDetailGraphDrawerPoPlan: string;
  projectsDetailGraphDrawerProjectGoal: string;
  projectsDetailGraphDrawerAnalysis: string;
  projectsDetailGraphDrawerSuccessCriteria: string;
  projectsDetailGraphDrawerPhases: string;
  projectsDetailGraphDrawerRelations: string;
  projectsDetailGraphDrawerUpstream: string;
  projectsDetailGraphDrawerDownstream: string;
  projectsDetailExecutionModeLabel: string;
  projectsDetailExecutionModeGroup: string;
  projectsDetailExecDirect: string;
  projectsDetailExecAuto: string;
  projectsDetailExecWorkflowPreferred: string;
  projectsDetailProjectNotFound: string;
  projectsDetailBackToProjects: string;
  projectsDetailProjectInstanceId: string;
  projectsDetailFilesCount: (count: number) => string;
  projectsDetailCloseProject: string;
  projectsDetailPlanInterrupted: string;
  projectsDetailWaitingPoPlan: string;
  projectsDetailPlanReady: (version: number) => string;
  projectsDetailNoAgents: string;
  projectsDetailWorkflowLabel: string;
  projectsDetailSummaryCollapse: string;
  projectsDetailSummaryExpand: string;
  projectsDetailTaskScores: string;
  projectsDetailDispatchableLabel: string;
  projectsDetailBlockedLabel: string;
  projectsDetailWaitingLabel: string;
  projectsDetailNeedsAction: string;
  projectsDetailRetryBusy: string;
  projectsDetailRetryCooling: string;
  projectsDetailRetryPlan: string;
  // toast / notice messages
  projectsDetailApproveFailedNotReady: string;
  projectsDetailApproveSuccess: string;
  projectsDetailDispatchFailed: string;
  projectsDetailDispatchWorkflowStarted: string;
  projectsDetailDispatchTasksDispatched: (count: number) => string;
  projectsDetailDispatchNone: string;
  projectsDetailExecModeSwitched: (label: string) => string;
  projectsDetailExecModeFailed: string;
  projectsDetailCloseSuccess: string;
  projectsDetailCloseFailed: string;
  projectsDetailRetryNotifying: string;
  projectsDetailRetryReassigned: (agent: string) => string;
  projectsDetailRetrySuccess: string;
  projectsDetailRetryFailed: string;
  projectsDetailExportSuccess: string;
  projectsDetailExportFailed: string;
  projectsDetailDiagnoseSuccess: string;
  projectsDetailDiagnoseFailed: string;
  projectsDetailAgentReviewFailed: string;
  projectsDetailTaskWorkflowFailed: string;
  projectsDetailWorkflowTaskStarted: string;
  projectsDetailWorkflowAgentStarted: string;
  projectsDetailWorkflowTaskStartFailed: string;
  projectsDetailWorkflowAgentStartFailed: string;
  projectsDetailWorkflowCancelSuccess: string;
  projectsDetailWorkflowCancelFailed: string;
  projectsDetailContinueMissingWorkflowId: string;
  projectsDetailContinueResumedWorkflow: string;
  projectsDetailContinueNoScript: string;
  projectsDetailContinueKswarmUnavailable: string;
  projectsDetailContinueResumeFailed: string;
  projectsDetailContinueResumeFailedRetry: string;
  projectsDetailContinueNotifiedPo: string;
  projectsDetailContinueNotifyFailed: string;
  projectsDetailContinueNotifyUnavailable: string;
  projectsDetailContinueSubmittedReview: string;
  projectsDetailContinueProjectAdvanced: string;
  projectsDetailContinueStateChanged: string;
  projectsDetailContinueNoRecoverableArtifacts: string;
  projectsDetailContinueNeedsDiagnose: string;
  projectsDetailContinueNeedsConfirm: string;
  projectsDetailContinueFailed: string;
  projectsDetailAskXiaokFailed: string;
  projectsDetailWorkflowServiceOutdated: string;
  projectsDetailAskXiaokThreadTitle: (projectName: string) => string;

  // projects - task detail drawer
  projectsTaskDetailTitle: string;
  projectsTaskStatusPending: string;
  projectsTaskStatusDispatched: string;
  projectsTaskStatusAccepted: string;
  projectsTaskStatusInProgress: string;
  projectsTaskStatusSubmitted: string;
  projectsTaskStatusReview: string;
  projectsTaskStatusDone: string;
  projectsTaskStatusFailed: string;
  projectsTaskStatusBlocked: string;
  projectsTaskStatusCancelled: string;
  projectsTaskWorkflowExec: string;
  projectsTaskDirectExec: string;
  projectsTaskCreated: string;
  projectsTaskStarted: string;
  projectsTaskCompleted: string;
  projectsTaskWorkflowProgress: string;
  projectsTaskNodeDetails: string;
  projectsTaskParallelGroups: string;
  projectsTaskReviewResult: string;
  projectsTaskArtifacts: string;
  projectsTaskBlockedReason: string;
  projectsTaskFailureReason: string;
  projectsTaskUnknownReason: string;
  projectsTaskStartWorkflow: string;

  // projects - kanban board (additional)
  projectsKanbanStartTime: string;
  projectsKanbanCompleteTime: string;
  projectsKanbanExecWorkflow: string;
  projectsKanbanExecDirect: string;
  projectsKanbanExecAutoSelect: string;
  projectsKanbanExecHighQuality: string;
  projectsKanbanReasonDeliveryReview: string;
  projectsKanbanReasonQualityGate: string;
  projectsKanbanReasonEvidenceChain: string;
  projectsKanbanReasonRetryAfterFailure: string;
  projectsKanbanReasonReworkReview: string;
  projectsKanbanReasonBlockedDiagnose: string;
  projectsKanbanReasonHighQuality: string;
  projectsKanbanReasonManualWorkflow: string;
  projectsKanbanSuspended: string;
  projectsKanbanWaitRetry: string;
  projectsKanbanBlocked: string;
  projectsKanbanCancelled: string;
  projectsKanbanFailed: string;
  projectsKanbanCompleted: string;
  projectsKanbanTaskDone: string;
  projectsKanbanUseWorkflow: string;
  projectsKanbanDeleteProject: string;
  projectsKanbanNodeCount: (count: string) => string;

  // projects - activity timeline (additional)
  projectsActivityPoCreatedTasks: string;
  projectsActivityHumanAddedTasks: string;
  projectsActivityTaskAccepted: string;
  projectsActivityTaskQualityReview: string;
  projectsActivityTaskBlocked: string;
  projectsActivityProjectDelivered: string;
  projectsActivityProjectClosed: string;
  projectsActivityApprovalPending: string;
  projectsActivityPlanSubmitted: string;
  projectsActivityPlanRevised: string;
  projectsActivityTaskReviewed: string;
  projectsActivityWorkflowStarted: string;
  projectsActivityWorkflowCompleted: string;
  projectsActivityWorkflowCancelled: string;
  projectsActivityWorkflowGateCompleted: string;
  projectsActivityWorkflowNodeSubmitted: string;
  projectsActivityWorkflowNodeReviewed: string;
  projectsActivityWorkflowNodeBlocked: string;
  projectsActivityHumanActionsTitle: string;
  projectsActivityWorkflowRunName: (id: string) => string;
  projectsActivityDiagnoseRun: string;

  // projects - create agent (additional)
  projectsAgentTypeWorkerDesc: string;
  projectsAgentTypePoDesc: string;
  projectsAgentTypeAllDesc: string;
  projectsAgentConfigTitle: string;
  projectsAgentNextStep: string;
  projectsAgentBack: string;
  projectsAgentRuntimeTitle: string;
  projectsAgentXiaokBuiltin: string;
  projectsAgentRecommended: string;
  projectsAgentNotInstalled: string;
  projectsAgentNotSupported: string;
  projectsAgentUsesPlatformConfig: (platform: string) => string;
  projectsAgentXiaokRunDesc: string;
  projectsAgentXiaokRunSubDesc: string;
  projectsAgentProviderLabel: string;
  projectsAgentFollowPlatform: string;
  projectsAgentFollowPlatformHint: string;
  projectsAgentModelLabel: string;
  projectsAgentSelectModel: string;
  projectsAgentModelDefault: string;
  projectsAgentInstructionsLabel: string;
  projectsAgentInstructionsOptional: string;
  projectsAgentCreateFirstAgent: string;
  projectsAgentCreateHint: string;
  projectsAgentCountLabel: (count: number) => string;
  projectsAgentCreateAgentTabHint: string;

  // projects - edit agent (additional)
  projectsEditAgentProviderLabel: string;
  projectsEditAgentSelectModel: string;
  projectsEditAgentSystemPromptPlaceholder: string;
  projectsEditAgentApiKeyNotConfigured: string;

  // projects - intervention
  projectsInterventionDefaultHeadline: string;
  projectsInterventionBusy: string;
  projectsInterventionContinueDefault: string;
  projectsInterventionAskXiaokDefault: string;
  projectsInterventionViewReason: string;
  projectsInterventionReasonTitle: string;
  projectsInterventionTaskLabel: string;
  projectsInterventionCurrentJudgment: string;
  projectsInterventionDefaultJudgment: string;
  projectsInterventionFailureReasonLabel: string;
  projectsInterventionFeedbackLabel: string;
  projectsInterventionImpact: (count: number) => string;
  projectsInterventionSystemSuggestion: string;
  projectsInterventionStrategyRecoverSubmission: string;
  projectsInterventionStrategyRetryRepair: string;
  projectsInterventionStrategyCompleteRetry: string;
  projectsInterventionStrategyRestartRetry: string;
  projectsInterventionStrategyNeedsConversation: string;
  projectsInterventionStrategyDefault: string;
  projectsInterventionUnknownTask: string;

  // projects - inline card
  projectsInlineAgentCount: (count: number) => string;
  projectsInlineWorkflowRunning: string;
  projectsInlineWorkflowCompleted: string;
  projectsInlineWorkflowBlocked: string;
  projectsInlineWorkflowFailed: string;
  projectsInlineWorkflowExec: string;
  projectsInlinePoDecomposing: string;

  // projects - artifact preview (additional)
  projectsArtifactAddToKb: string;
  projectsArtifactKbAdded: string;
  projectsArtifactKb: string;
  projectsArtifactDiscuss: string;
  projectsArtifactSendToChat: string;
  projectsArtifactExitFullscreen: string;
  projectsArtifactFullscreen: string;
  projectsArtifactDownload: string;

  // projects - deliverable view (additional)
  projectsDeliverableGenerated: string;
  projectsDeliverableProjectFiles: string;
  projectsDeliverableProjectWorkspace: string;
  projectsDeliverableProjectDeliverable: string;
  projectsDeliverableTaskOutputs: string;

  // projects - progress card (additional)
  projectsProgressDone: string;
  projectsProgressDoneStopped: (done: number, stopped: number) => string;
  projectsProgressTasks: (done: number, total: number) => string;

  // projects - card (additional)
  projectsCardTaskProgress: (done: number, total: number) => string;
  projectsCardTaskProgressStopped: (done: number, stopped: number) => string;
  projectsCardDeleteTitle: string;

  // projects - create project (additional)
  projectsCreateNoAgents: string;
  projectsCreateWorkerOptional: string;
  projectsCreateWorkDirOptional: string;
  projectsCreateSelectDir: string;
  projectsCreateAgentOffline: string;

  // projects - export markdown labels
  projectsExportStatus: string;
  projectsExportCreatedAt: string;
  projectsExportUpdatedAt: string;
  projectsExportDeliveredAt: string;
  projectsExportClosedAt: string;
  projectsExportGoal: string;
  projectsExportRequirements: string;
  projectsExportWorkspace: string;
  projectsExportWorkspacePath: string;
  projectsExportWorkspaceFiles: (count: number) => string;
  projectsExportPlan: string;
  projectsExportAnalysis: string;
  projectsExportSuccessCriteria: string;
  projectsExportPhases: string;
  projectsExportPhaseLabel: (id: string) => string;
  projectsExportAcceptanceCriteria: string;
  projectsExportPlanVersion: (version: number) => string;
  projectsExportTasks: string;
  projectsExportTaskStatus: string;
  projectsExportTaskAssignee: string;
  projectsExportTaskDescription: string;
  projectsExportTaskPhase: string;
  projectsExportTaskResult: string;
  projectsExportTaskArtifacts: string;
  projectsExportAgents: string;
  projectsExportActivityLog: string;
  projectsExportDeliverables: string;
  projectsExportDeliveryNote: string;
  projectsExportProjectSummary: string;
  projectsExportScore: string;

  // projects - workflow run status labels (for ActivityTimeline)
  projectsWorkflowRunAwaitingApproval: string;
  projectsWorkflowRunRunning: string;
  projectsWorkflowRunBlocked: string;
  projectsWorkflowRunCompleted: string;
  projectsWorkflowRunFailed: string;
  projectsWorkflowRunCancelled: string;

  // projects - task workflow progress bar
  projectsTaskProgressNodes: (done: string, total: string) => string;

  // project status labels (used by kswarmStatus.ts)
  projectHealthBlocked: string;
  projectHealthFailed: string;
  projectHealthWaiting: string;
  projectHealthNeedsReview: string;
  projectHealthRunning: string;
  projectHealthHealthy: string;
  projectHealthUnknown: string;
  projectHealthBlockedShort: string;
  projectHealthFailedShort: string;
  projectHealthWaitingShort: string;
  projectHealthNeedsReviewShort: string;
  projectHealthRunningShort: string;
  projectHealthHealthyShort: string;
  projectHealthUnknownShort: string;
  projectHealthMsgNeedsReview: string;
  projectHealthMsgWaiting: string;
  projectHealthMsgBlocked: string;
  projectHealthMsgFailed: string;
  agentStatusWaiting: string;
  agentStatusWorking: string;
  agentStatusBlocked: string;
  agentStatusFailed: string;
  agentStatusError: string;
  agentStatusCompleted: string;
  agentStatusOffline: string;
  agentStatusIdle: string;

  // connection settings
  connectionPortRange: (label: string) => string;

  // code execution panel
  codeExecutionCode: string;
  codeExecutionOutput: string;
  codeExecutionNoOutput: string;

  // citation badge
  citationSourcesCount: (n: number) => string;

  // common
  commonConfirm: string;
  commonCancel: string;
  commonSave: string;
  commonDelete: string;
  commonEdit: string;
  commonClose: string;
  commonLoading: string;
  commonBaseUrl: string;
  commonApiKey: string;
  commonNoConfig: string;
}

export const locales: Record<Locale, LocaleStrings> = { zh, en };
