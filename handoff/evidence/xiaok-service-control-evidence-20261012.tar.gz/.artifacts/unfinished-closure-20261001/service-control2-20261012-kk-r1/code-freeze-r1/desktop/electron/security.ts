import type { BrowserWindowConstructorOptions } from 'electron';
import { fileURLToPath, pathToFileURL } from 'node:url';

interface BrowserWindowBuildOptions {
  platform?: NodeJS.Platform;
  iconPath?: string;
}

interface TrustedDesktopRendererUrlOptions {
  devServer?: string;
  rendererFile: string;
}

export function buildBrowserWindowOptions(
  preloadPath: string,
  options: BrowserWindowBuildOptions = {},
): BrowserWindowConstructorOptions {
  const { platform = process.platform, iconPath } = options;

  return {
    width: 1280,
    height: 820,
    minWidth: 980,
    minHeight: 680,
    backgroundColor: '#f7f7f2',
    title: 'xiaok',
    titleBarStyle: 'hiddenInset',
    ...(iconPath ? { icon: iconPath } : {}),
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false, // preload.cjs uses require()
    },
  };
}

export function isAllowedNavigationUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl);
    if (url.protocol === 'file:') {
      return true;
    }
    return url.protocol === 'http:' && url.hostname === '127.0.0.1';
  } catch {
    return false;
  }
}

export function isTrustedDesktopRendererUrl(
  rawUrl: string,
  options: TrustedDesktopRendererUrlOptions,
): boolean {
  try {
    const actual = new URL(rawUrl);
    const expected = options.devServer
      ? new URL(options.devServer)
      : pathToFileURL(options.rendererFile);
    actual.hash = '';
    expected.hash = '';
    return actual.href === expected.href;
  } catch {
    return false;
  }
}

export function isAllowedShellExternalUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

export function resolveLocalFileOpenPath(rawUrl: string): string | null {
  try {
    const url = new URL(rawUrl);
    if (url.protocol !== 'file:') return null;
    if (/^\/[a-zA-Z]:\//.test(url.pathname)) {
      return decodeURIComponent(url.pathname.slice(1)).replace(/\//g, '\\');
    }
    return fileURLToPath(url);
  } catch {
    return null;
  }
}
