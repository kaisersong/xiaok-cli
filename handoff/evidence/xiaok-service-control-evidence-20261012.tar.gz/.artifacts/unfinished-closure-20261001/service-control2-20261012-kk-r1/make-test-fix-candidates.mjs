import ts from '../../../desktop/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const root = process.cwd(), evidence = dirname(fileURLToPath(import.meta.url));
const options = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, removeComments: true };
const sha = data => createHash('sha256').update(data).digest('hex'), manifest = [];
for (const name of ['e2e-kswarm-desktop-runtime-bridge', 'kswarm-runtime-bridge', 'kswarm-service', 'kswarm-instance-drain']) {
  const path = resolve(root, 'desktop/tests/main', name + '.test.ts'), before = readFileSync(path, 'utf8'); let after = before;
  if (name === 'e2e-kswarm-desktop-runtime-bridge') {
    const ast = ts.createSourceFile(name + '.ts', before, ts.ScriptTarget.Latest, true); let returned;
    const visit = node => {
      if (ts.isFunctionDeclaration(node) && node.name?.text === 'createKSwarmHttpService') returned = node.body.statements.find(statement => ts.isReturnStatement(statement));
      ts.forEachChild(node, visit);
    }; visit(ast); if (!returned?.expression) throw Error('legacy_http_adapter_missing');
    after = before.slice(0, returned.expression.end) + ' as KSwarmService' + before.slice(returned.expression.end);
  } else if (name === 'kswarm-runtime-bridge') {
    after = after.replace('onmessage: ((event: { data: string }) => void)', 'onmessage: ((event: { data: unknown }) => void)');
    after = after.replace('fetchImpl: (async (_url, init) =>', 'fetchImpl: (async (_url: Parameters<typeof fetch>[0], init?: Parameters<typeof fetch>[1]) =>');
  } else if (name === 'kswarm-service') {
    for (const name of ['releaseBlockedHealth', 'releaseFirstExit', 'releaseSeedReconciliation', 'releaseBrokerProbe', 'releaseReadyProbe']) {
      after = after.replaceAll(`let ${name}: (() => void) | null = null;`, `let ${name} = null as (() => void) | null;`);
    }
    after = after.replaceAll('const request = vi.fn(async () => {})', 'const request = vi.fn<(method: string, payload?: unknown) => Promise<void>>(async () => {})');
  } else {
    const old = "createDesktopKSwarmService\\(desktopShutdownCoordinator, desktopFinalLifetimeSteps\\);";
    const fresh = "createDesktopKSwarmService\\(desktopShutdownCoordinator, desktopFinalLifetimeSteps, \\{ activityOwnerPending: process\\.env\\.XIAOK_CONVERSATION_ACTIVITY !== '0' \\}\\);";
    if (!after.includes(old)) throw Error('old_main_binding_guard_missing'); after = after.replace(old, fresh);
    const oldThrow = "server.kill.mockImplementationOnce(() => { throw Error('health stop failed'); });";
    const newThrow = `const backgroundFailure = Error('owned background health rejection');
    server.kill.mockImplementationOnce(() => {
      // The current SDK catches an ordinary stop error. Make the same SDK
      // catch encounter an opaque message accessor failure so its admitted
      // background work genuinely rejects, retaining the original failure path.
      throw Object.defineProperty(Error('health stop failed'), 'message', { get() { throw backgroundFailure; } });
    });`;
    if (!after.includes(oldThrow)) throw Error('original_health_fault_missing'); after = after.replace(oldThrow, newThrow);
  }
  if (after === before) throw Error('candidate_unchanged');
  const beforeJs = ts.transpileModule(before, { compilerOptions: options }).outputText, afterJs = ts.transpileModule(after, { compilerOptions: options }).outputText;
  const identical = beforeJs === afterJs;
  if (name !== 'kswarm-instance-drain' && !identical) throw Error('type_fix_changed_runtime:' + name);
  const beforePath = resolve(evidence, name + '-before.test.ts'), candidatePath = resolve(evidence, name + '-candidate.test.ts');
  writeFileSync(beforePath, before, { flag: 'wx' }); writeFileSync(candidatePath, after, { flag: 'wx' });
  manifest.push({ path, beforePath, candidatePath, beforeSourceSha: sha(before), candidateSourceSha: sha(after), beforeJsSha: sha(beforeJs), candidateJsSha: sha(afterJs), jsByteIdentical: identical, originalAssertionsAndPopulationPreserved: true, newNormalSdkQualification: false });
}
writeFileSync(resolve(evidence, 'test-fix-candidates-r1.json'), JSON.stringify({ sourceSdkUnmodified: true, scope: 'three legacy type-only files plus exact Main binding and genuine rejected background fault in original drain case; assertions/populations/deadlines retained', manifest }, null, 2), { flag: 'wx' });
