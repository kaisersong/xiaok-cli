import ts from '../../../desktop/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const repo = process.cwd(), evidence = dirname(fileURLToPath(import.meta.url));
const source = readFileSync(join(repo, 'desktop/electron/main.ts'), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
const auth = ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'authorizeDesktopInvoke');
let producers = '', registration = ''; const controlDeclarations = [];
const visit = node => {
  if (ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => ['runtimeBridgeClients','runtimeBridgeStarted','restartRuntimeBridgeService','serviceControl'].includes(declaration.name.getText(ast)))) controlDeclarations.push(node.getText(ast));
  if (ts.isVariableStatement(node) && node.declarationList.declarations.some(declaration => declaration.name.getText(ast) === 'serviceControlProducers')) producers = node.getText(ast);
  if (ts.isExpressionStatement(node) && ts.isCallExpression(node.expression) && node.expression.expression.getText(ast) === 'registerServiceControlIpc') registration = node.getText(ast);
  ts.forEachChild(node, visit);
}; visit(ast);
if (!auth || !producers || !registration) throw Error('actual_mobile_entry_missing');
const transpile = text => ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText;
const root = realpathSync(mkdtempSync(join(tmpdir(), 'xiaok-service-control-probe-')));
const dir = join(root, 'desktop/dist/main/desktop/electron'), renderer = join(root, 'desktop/dist/renderer/index.html');
mkdirSync(dir, { recursive: true }); mkdirSync(dirname(renderer), { recursive: true });
writeFileSync(renderer, '<!doctype html><title>Owned service control component probe</title><p>Owned service control component probe</p>');
const emitted = name => JSON.stringify(pathToFileURL(join(repo, 'desktop/dist/main/desktop/electron', name + '.js')).href);
const preload = JSON.stringify(join(repo, 'desktop/electron/preload.cjs'));
const code = `import { app, BrowserWindow, ipcMain, screen } from 'electron';
import { writeFile } from 'node:fs/promises'; import { join, dirname } from 'node:path'; import { fileURLToPath } from 'node:url';
import { ShutdownAwareIpcMain, DesktopShutdownGate } from ${emitted('shutdown-aware-ipc-main')};
import { isTrustedDesktopRendererUrl, buildBrowserWindowOptions } from ${emitted('security')};
import { createMeetingRecorderWindowController } from ${emitted('meeting-recorder-window')};
import { registerServiceControlIpc } from ${emitted('service-control-typed-ipc')};
import { createDesktopServiceControl } from ${emitted('desktop-service-control')};
const __dirname = dirname(fileURLToPath(import.meta.url)), root = ${JSON.stringify(root)}, rendererFile = ${JSON.stringify(renderer)};
app.setPath('userData', join(root, 'electron-user-data')); let mainWindow = null, meetingRecorderController = null;
${transpile(auth.getText(ast))}
const gate = new DesktopShutdownGate(), shutdownAwareIpc = new ShutdownAwareIpcMain(ipcMain, gate, authorizeDesktopInvoke);
let statusReads = 0, restarts = 0;
const kswarmService = { getServiceStatus() { statusReads++; return Promise.resolve({ checkedAt: 123, services: [{ id: 'kswarm', label: 'Owned KSwarm', running: true, reachable: true, port: 4400, pid: 1, lastError: null, future: ['preserved'] }] }); }, restartRelatedService(id) { if (id !== 'kswarm') throw Error('unexpected_surrogate_target'); restarts++; return Promise.resolve(undefined); } };
${transpile(controlDeclarations.join('\n'))}
${transpile(producers + '\n' + registration)}
const options = buildBrowserWindowOptions(${preload}, { platform: process.platform });
const results = [], methods = ['getServiceStatus', 'restartRelatedService'];
const invoke = async (role, window) => { for (const method of methods) results.push({ role, method, reply: await window.webContents.executeJavaScript('window.xiaokDesktop.' + method + (method === 'restartRelatedService' ? '(\"kswarm\")' : '()') + '.then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))') }); };
const verify = (condition, code) => { if (!condition) throw Error(code); };
app.whenReady().then(async () => { try {
  mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile);
  meetingRecorderController = createMeetingRecorderWindowController({ BrowserWindow, getMainWindow: () => mainWindow, notificationPort: { show: async () => ({ ok: true }) }, platform: process.platform, preloadPath: ${preload}, rendererFile, screen });
  await invoke('main', mainWindow); await meetingRecorderController.open({ collectionId: 'owned-native-services' });
  const recorder = BrowserWindow.getAllWindows().find(window => meetingRecorderController.ownsWebContents(window.webContents)); verify(!!recorder, 'actual_recorder_missing'); await invoke('recorder', recorder);
  const unknown = new BrowserWindow({ ...options, show: false }); await unknown.loadFile(rendererFile); await invoke('unknown-same-url', unknown);
  const old = mainWindow; mainWindow = new BrowserWindow({ ...options, show: false }); await mainWindow.loadFile(rendererFile); await invoke('old-main', old); await invoke('replacement-main', mainWindow);
  for (const row of results) {
    if (['main', 'recorder', 'replacement-main'].includes(row.role)) {
      verify(row.reply.ok, row.role + ':' + row.method);
      if (row.method === 'getServiceStatus') verify(row.reply.value.checkedAt === 123 && row.reply.value.services[0].future[0] === 'preserved' && row.reply.value.services[1].id === 'runtime-bridge', 'status_changed');
      else verify(row.reply.value === undefined, 'false_restart_ack');
    } else verify(!row.reply.ok && row.reply.error.includes('desktop_user_sender_forbidden'), 'unowned_mobile_admitted');
  }
  for (const id of ['unknown-id','runtime-bridge']) { const reply = await mainWindow.webContents.executeJavaScript('window.xiaokDesktop.restartRelatedService('+JSON.stringify(id)+').then(value=>({ok:true}),error=>({ok:false,error:String(error)}))'); verify(!reply.ok && reply.error.includes(id === 'unknown-id' ? 'service_input_invalid' : 'service_runtime_unavailable'), 'false_uninitialized_or_unknown_ack'); results.push({role:'main',method:'restartRelatedService',target:id,reply}); }
  verify(statusReads === 3 && restarts === 3, 'denied_control_reached_sdk'); verify(gate.outstanding === 0, 'ipc_token_leak');
  await writeFile(${JSON.stringify(join(evidence, 'native-service-r1.json'))}, JSON.stringify({ actualElectron: true, actualProductionAuthorizer: true, actualProductionShutdownOwner: true, actualProductionRecorderController: true, actualProductionPreload: true, actualTypedServiceRegistrar: true, actualMainProducerBody: true, actualMainFacade: true, ownedTemporaryRendererFixture: true, surrogateSdkBoundaryOnly: true, realCredentialsRead: false, installedAppOrWholeUiAccepted: false, protectedNativeAuthorityClaim: false, results, statusReads, restarts, gateOutstanding: gate.outstanding }, null, 2));
  meetingRecorderController.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.quit();
} catch (error) { console.error(error); meetingRecorderController?.dispose(); for (const window of BrowserWindow.getAllWindows()) window.destroy(); app.exit(1); } }).catch(error => { console.error(error); app.exit(1); });
`;
const script = join(dir, 'native-service.mjs'); writeFileSync(script, code); writeFileSync(join(evidence, 'native-service-script-r1.mjs'), code, { flag: 'wx' });
writeFileSync(join(evidence, 'native-service-script-r1.json'), JSON.stringify({ root, script, renderer, actualAuthorizerSource: auth.getText(ast), actualProducerSource: producers, actualRegistrationSource: registration }, null, 2), { flag: 'wx' });
console.log(script);
