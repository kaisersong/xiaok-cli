import { acquireHeavyCpuLease, releaseHeavyCpuLease } from '../heavy-cpu-lease.mjs';
import { spawn } from 'node:child_process';
import { openSync, closeSync, writeFileSync } from 'node:fs';
const [label, cwd, ...args] = process.argv.slice(2);
const owner='catalog3-'+label; let token;
try { token=acquireHeavyCpuLease(owner); } catch(error) { console.log(String(error));process.exitCode=75; }
if(token){
 let child, exit, gone=false;const started=Date.now();const log=new URL('./'+label+'.log',import.meta.url), receipt=new URL('./'+label+'-process.json',import.meta.url);
 const fd=openSync(log,'wx',0o600);
 try {
  child=spawn(process.execPath,args,{cwd,detached:true,stdio:['ignore',fd,fd]});
  exit=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});
  try {process.kill(-child.pid,0);}catch(error){if(error.code==='ESRCH')gone=true;else throw error;}
  writeFileSync(receipt,JSON.stringify({owner,token,pid:child.pid,args,cwd,started,elapsedMs:Date.now()-started,exit,actualWait:true,reaped:true,groupGone:gone},null,2),{flag:'wx'});
  if(!gone)throw Error('owned_group_still_alive');
 } finally {closeSync(fd);if(gone)releaseHeavyCpuLease(owner,token);}
 process.exitCode=exit.code??1;console.log(JSON.stringify({label,exit,elapsedMs:Date.now()-started,groupGone:gone}));
}
