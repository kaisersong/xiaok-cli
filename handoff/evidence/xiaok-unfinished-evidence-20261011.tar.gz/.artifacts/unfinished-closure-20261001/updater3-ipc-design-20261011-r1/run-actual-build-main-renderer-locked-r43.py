import subprocess,pathlib,json,os,time,sys,hashlib
A=pathlib.Path(__file__).parent;root=pathlib.Path('/Users/kai/projects/xiaok-cli-unfinished-integration-20261005');sys.path.insert(0,str(A.parent));from heavy_cpu_lease import acquire_heavy_cpu_lease,release_heavy_cpu_lease
owner='model_continue_1011';token=acquire_heavy_cpu_lease(owner);p=None
try:
 paths=[pathlib.Path(x['path'])for x in json.loads((A/'current-readonly-source-freeze-r1.json').read_text())['files']];paths += list((root/'desktop').glob('**/updater-*.ts'));before={str(x):hashlib.sha256(x.read_bytes()).hexdigest()for x in paths}
 for label in ['main','renderer']:
  with (A/('actual-build-'+label+'-r43.log')).open('x')as log:
   t=time.monotonic();p=subprocess.Popen(['npm','run','build:'+label],cwd=root/'desktop',stdout=log,stderr=subprocess.STDOUT,start_new_session=True);print(json.dumps({'label':label,'pid':p.pid,'pgid':os.getpgid(p.pid)}),flush=True);code=p.wait(timeout=180)
   try:os.killpg(p.pid,0);gone=False
   except ProcessLookupError:gone=True
   receipt={'label':label,'exitCode':code,'reaped':True,'groupGone':gone,'pid':p.pid,'elapsedSeconds':time.monotonic()-t,'actualPackageScript':True,'noSigning':True,'beforeSHA':before,'sourceDrift':[str(x)for x in paths if hashlib.sha256(x.read_bytes()).hexdigest()!=before[str(x)]]}
   with (A/('actual-build-'+label+'-process-r43.json')).open('x')as out:json.dump(receipt,out,indent=2)
   print(json.dumps({k:v for k,v in receipt.items()if k!='beforeSHA'}),flush=True)
finally:
 if p is not None and p.poll()is None:os.killpg(p.pid,15);p.wait(timeout=10)
 if p is not None:
  try:os.killpg(p.pid,0);gone=False
  except ProcessLookupError:gone=True
  if not gone:raise RuntimeError('heavy_cpu_lease_retained_live_group:'+str(p.pid))
 release_heavy_cpu_lease(owner,token)
