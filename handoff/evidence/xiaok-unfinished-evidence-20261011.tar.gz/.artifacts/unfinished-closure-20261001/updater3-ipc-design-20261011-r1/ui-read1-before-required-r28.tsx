import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';

const mocks = vi.hoisted(() => ({
  getUpdateStatus: vi.fn(), quitAndInstall: vi.fn(),
}));
vi.mock('../../renderer/src/api/bridge', () => ({ api: {
  getSkillDebugConfig: vi.fn().mockResolvedValue({ enabled: false }),
  getKswarmConfig: vi.fn().mockResolvedValue({ maxConcurrentTasks: 3 }),
  getUpdateStatus: mocks.getUpdateStatus, quitAndInstall: mocks.quitAndInstall,
  onUpdateStatus: vi.fn(() => () => {}), checkForUpdates: vi.fn().mockResolvedValue(undefined),
} }));
afterEach(() => { cleanup(); vi.clearAllMocks(); });


describe('actual About update read failures', () => {
  it('reports unavailable initial update facts instead of current-version success', async () => {
    Object.assign(globalThis, { __APP_VERSION__: '1.5.2', __APP_BUILD__: 'fixture' });
    mocks.getUpdateStatus.mockRejectedValueOnce(Error('owned_read_failure'));
    render(<MemoryRouter><LocaleProvider><DesktopSettings onClose={() => {}} /></LocaleProvider></MemoryRouter>);
    fireEvent.click(screen.getByRole('button', { name: '关于' }));
    expect(await screen.findByRole('alert')).toBeInTheDocument();
    expect(screen.queryByText('当前版本')).not.toBeInTheDocument();
    expect(mocks.quitAndInstall).not.toHaveBeenCalled();
  });
});
