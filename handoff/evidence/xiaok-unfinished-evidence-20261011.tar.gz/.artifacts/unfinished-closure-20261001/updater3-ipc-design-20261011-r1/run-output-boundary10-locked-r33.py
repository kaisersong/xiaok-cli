import subprocess,pathlib,json,os,time,sys,hashlib
A=pathlib.Path(__file__).parent;root=pathlib.Path('/Users/kai/projects/xiaok-cli-unfinished-integration-20261005');sys.path.insert(0,str(A.parent));from heavy_cpu_lease import acquire_heavy_cpu_lease,release_heavy_cpu_lease
paths=[pathlib.Path(x['path'])for x in json.loads((A/'current-readonly-source-freeze-r1.json').read_text())['files']]+[root/'desktop/tests/renderer/updater-read-failure.test.tsx'];before={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths};owner='model_continue_1011';token=acquire_heavy_cpu_lease(owner);p=None
try:
 commands=[('ui-read-green',[str(root/'desktop/node_modules/.bin/vitest'),'run','tests/main/updater-output-boundary.test.ts','--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(A/'actual-ui-read-green-characterization-r33.json')])]
 for label,cmd in commands:
  with(A/('actual-'+label+'-green-r33.log')).open('x')as log:
   t=time.monotonic();p=subprocess.Popen(cmd,cwd=root/'desktop',stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'RECORDER_PHASE':'GREEN_AFTER_DESIGN_AP_PRODUCTION'});print(json.dumps({'label':label,'pid':p.pid,'pgid':os.getpgid(p.pid)}),flush=True);code=p.wait(timeout=60)
   try:os.killpg(p.pid,0);gone=False
   except ProcessLookupError:gone=True
   result={'label':label,'exitCode':code,'reaped':True,'groupGone':gone,'pid':p.pid,'elapsedSeconds':time.monotonic()-t,'beforeSHA':before,'sourceDrift':[str(x)for x in paths if hashlib.sha256(x.read_bytes()).hexdigest()!=before[str(x)]]}
   with(A/('actual-'+label+'-green-process-r33.json')).open('x')as f:json.dump(result,f,indent=2)
   print(json.dumps({k:v for k,v in result.items()if k!='beforeSHA'}),flush=True)
finally:
 if p is not None and p.poll()is None:os.killpg(p.pid,15);p.wait(timeout=10)
 if p is not None:
  try:os.killpg(p.pid,0);gone=False
  except ProcessLookupError:gone=True
  if not gone:raise RuntimeError('heavy_cpu_lease_retained_live_group:'+str(p.pid))
 release_heavy_cpu_lease(owner,token)
