import sys
sys.path.insert(0,str(__import__('pathlib').Path(__file__).parent.parent))
from heavy_cpu_lease import acquire_heavy_cpu_lease,release_heavy_cpu_lease
owner='model_continue_1011';token=acquire_heavy_cpu_lease(owner);p=None
try:
 import subprocess,pathlib,time,json,os
 A=pathlib.Path(__file__).parent
 for label,script in [('strict','check-current-updater-strict-r44.cjs'),('governance','check-current-updater-governance-r44.mjs')]:
  with (A/('current-'+label+'-r44.log')).open('x') as log:
   t=time.monotonic();p=subprocess.Popen(['node',str(A/script)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);print(json.dumps({'label':label,'pid':p.pid,'pgid':os.getpgid(p.pid)}),flush=True);code=p.wait(timeout=60)
   try:os.killpg(p.pid,0);gone=False
   except ProcessLookupError:gone=True
   receipt={'exitCode':code,'pid':p.pid,'reaped':True,'groupGone':gone,'elapsedSeconds':time.monotonic()-t}
   with (A/('current-'+label+'-process-r44.json')).open('x') as f:json.dump(receipt,f,indent=2)
   print(json.dumps(receipt),flush=True)
finally:
 if p is not None and p.poll() is None:os.killpg(p.pid,15);p.wait(timeout=10)
 if p is not None:
  try:os.killpg(p.pid,0);gone=False
  except ProcessLookupError:gone=True
  if not gone:raise RuntimeError('heavy_cpu_lease_retained_live_group:'+str(p.pid))
 release_heavy_cpu_lease(owner,token)
