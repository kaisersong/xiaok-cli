import { EventEmitter } from 'node:events';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const fixture = vi.hoisted(() => ({ updater: null as any }));
vi.mock('electron-updater', () => ({ get autoUpdater() { return fixture.updater; } }));
vi.mock('node:fs', async (importOriginal) => {
  const original = await importOriginal<typeof import('node:fs')>();
  return { ...original, default: { ...original, existsSync: () => true }, existsSync: () => true };
});

describe('configured updater state and maintenance owner', () => {
  const originalResourcesPath = Object.getOwnPropertyDescriptor(process, 'resourcesPath');
  let subject: typeof import('../../electron/updater.js');
  let updater: EventEmitter & Record<string, any>;
  beforeEach(async () => {
    vi.resetModules();
    vi.useFakeTimers();
    vi.stubEnv('NODE_ENV', 'production');
    vi.stubEnv('XIAOK_DESKTOP_DEV_SERVER', '');
    Object.defineProperty(process, 'resourcesPath', { value: '/fixture/resources', configurable: true });
    updater = Object.assign(new EventEmitter(), {
      checkForUpdates: vi.fn().mockResolvedValue({}),
      checkForUpdatesAndNotify: vi.fn().mockResolvedValue({}),
      quitAndInstall: vi.fn(),
    });
    fixture.updater = updater;
    subject = await import('../../electron/updater.js');
    await Reflect.apply(subject.setupAutoUpdater, undefined, [{ isDestroyed: () => false, webContents: { send: vi.fn() } }, undefined, { requestSource: 'scheduler' }]);
  });
  afterEach(() => {
    vi.clearAllTimers(); vi.useRealTimers(); vi.unstubAllEnvs();
    if (originalResourcesPath) Object.defineProperty(process, 'resourcesPath', originalResourcesPath);
    else delete (process as unknown as { resourcesPath?: string }).resourcesPath;
  });



  it('rebinds a replacement window without another startup check or four-hour poller', async () => {
    const before = vi.getTimerCount(); const startup = updater.checkForUpdatesAndNotify.mock.calls.length;
    const window = { isDestroyed: () => false, webContents: { send: vi.fn() } };
    await Reflect.apply(subject.setupAutoUpdater, undefined, [window, undefined, { requestSource: 'scheduler' }]);
    expect(vi.getTimerCount()).toBe(before); expect(updater.checkForUpdatesAndNotify).toHaveBeenCalledTimes(startup);
    updater.emit('update-available', { version: 'owned-next' });
    expect(window.webContents.send).toHaveBeenCalledWith('desktop:updateStatus', expect.objectContaining({ version: 'owned-next' }));
  });
  it('returns detached status and state-machine snapshots', () => {
    updater.emit('update-downloaded', { version: 'owned-next' });
    const status = subject.getUpdateStatus(); status.progress = 39;
    expect(subject.getUpdateStatus().progress).toBe(100);
    const handoff = subject.createUpdaterHandoff('darwin');
    Reflect.apply(handoff.begin, handoff, [{ requestSource: 'user' }]);
    const snapshot = handoff.snapshot(); Object.assign(snapshot, { kind: 'idle' });
    expect(handoff.snapshot().kind).toBe('pending');
  });
  it('keeps known flags and progress while reporting malformed SDK progress without throwing', () => {
    updater.emit('update-downloaded', { version: 'owned-next' });
    const before = subject.getUpdateStatus();
    expect(() => updater.emit('download-progress', { percent: Number.NaN })).not.toThrow();
    expect(subject.getUpdateStatus()).toMatchObject({ downloaded: before.downloaded, version: before.version, progress: before.progress, error: 'updater_projection_unavailable' });
  });
  it('does not invoke an SDK update-info getter and keeps previous data', () => {
    updater.emit('update-available', { version: 'owned-next' }); let reads = 0;
    const raw = Object.defineProperty({}, 'version', { enumerable: true, get() { reads++; return 'bad'; } });
    expect(() => updater.emit('update-downloaded', raw)).not.toThrow();
    expect(reads).toBe(0); expect(subject.getUpdateStatus().version).toBe('owned-next');
    expect(subject.getUpdateStatus().downloaded).toBe(false);
  });
  it('does not authorize manual install from SDK downloaded flags for an agent source', () => {
    updater.emit('update-downloaded', { version: 'owned-next' });
    expect(() => Reflect.apply(subject.quitAndInstall, undefined, [{ requestSource: 'agent' }])).toThrow(/updater_request_source_/);
    expect(updater.quitAndInstall).not.toHaveBeenCalled();
  });
});
