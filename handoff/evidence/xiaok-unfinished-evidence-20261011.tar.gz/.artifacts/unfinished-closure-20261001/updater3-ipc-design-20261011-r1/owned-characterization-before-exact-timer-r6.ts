import { writeFileSync } from 'node:fs';
import { EventEmitter } from 'node:events';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const fixture = vi.hoisted(() => ({ updater: null as any }));
vi.mock('electron-updater', () => ({ get autoUpdater() { return fixture.updater; } }));
vi.mock('node:fs', async (importOriginal) => {
  const original = await importOriginal<typeof import('node:fs')>();
  return { ...original, default: { ...original, existsSync: () => true }, existsSync: () => true };
});

describe('updater original owner cold characterization', () => {
  const originalResourcesPath = Object.getOwnPropertyDescriptor(process, 'resourcesPath');
  let subject: typeof import('../../electron/updater.js');
  let updater: EventEmitter & Record<string, any>;
  beforeEach(async () => {
    vi.resetModules();
    vi.useFakeTimers();
    vi.stubEnv('NODE_ENV', 'production');
    vi.stubEnv('XIAOK_DESKTOP_DEV_SERVER', '');
    Object.defineProperty(process, 'resourcesPath', { value: '/fixture/resources', configurable: true });
    updater = Object.assign(new EventEmitter(), {
      checkForUpdates: vi.fn().mockResolvedValue({}),
      checkForUpdatesAndNotify: vi.fn().mockResolvedValue({}),
      quitAndInstall: vi.fn(),
    });
    fixture.updater = updater;
    subject = await import('../../electron/updater.js');
    await subject.setupAutoUpdater({ isDestroyed: () => false, webContents: { send: vi.fn() } } as any);
  });
  afterEach(() => {
    vi.clearAllTimers(); vi.useRealTimers(); vi.unstubAllEnvs();
    if (originalResourcesPath) Object.defineProperty(process, 'resourcesPath', originalResourcesPath);
    else delete (process as unknown as { resourcesPath?: string }).resourcesPath;
  });


  it('records actual first and replacement-window setup effects without requesting or installing real updates', async () => {
    const startupBefore = updater.checkForUpdatesAndNotify.mock.calls.length;
    const timersBefore = vi.getTimerCount();
    const listenersBefore = updater.listenerCount('update-downloaded');
    const replacement = { isDestroyed: () => false, webContents: { send: vi.fn() } };
    await subject.setupAutoUpdater(replacement as any);
    const status = subject.getUpdateStatus();
    const sameStatusAlias = subject.getUpdateStatus() === status;
    const savedProgress = status.progress;
    status.progress = 39;
    const readObservedAliasMutation = subject.getUpdateStatus().progress;
    status.progress = savedProgress;
    updater.emit('update-downloaded', { version: 'owned-fixture-next' });
    const handoff = subject.createUpdaterHandoff('darwin');
    const before = handoff.begin();
    const repeated = handoff.begin();
    const projection = handoff.projection();
    const committed = handoff.commitHandoffOnBeforeQuit();
    const fact = { fixtureBoundary: 'existing managed native-updater and window ports, no network/install/real-app claim',
      startupBefore, startupAfter: updater.checkForUpdatesAndNotify.mock.calls.length,
      timersBefore, timersAfter: vi.getTimerCount(), listenersBefore, listenersAfter: updater.listenerCount('update-downloaded'),
      sameStatusAlias, readObservedAliasMutation, latestWindowReceived: replacement.webContents.send.mock.calls.length,
      begin: before, repeated, projection, committed, wrapperCalls: updater.quitAndInstall.mock.calls.length };
    expect(startupBefore).toBe(1); expect(fact.startupAfter).toBe(2);
    expect(timersBefore).toBe(1); expect(fact.timersAfter).toBeGreaterThanOrEqual(2);
    expect(fact.listenersAfter).toBe(listenersBefore);
    expect(sameStatusAlias).toBe(true); expect(readObservedAliasMutation).toBe(39);
    expect(before).toEqual({ status: 'pending' }); expect(repeated).toEqual({ status: 'already_pending' });
    expect(committed.committed).toBe(true); expect(fact.wrapperCalls).toBe(1);
    writeFileSync('/Users/kai/projects/xiaok-cli/.artifacts/unfinished-closure-20261001/updater3-ipc-design-20261011-r1/actual-updater-owner-normal-facts-r3.json', JSON.stringify(fact, null, 2), { flag: 'wx' });
  });
});
