import sys,json,subprocess,os,time,errno
from pathlib import Path
base=Path(__file__).parent;sys.path.insert(0,str(base.parent))
from heavy_cpu_lease import acquire_heavy_cpu_lease,release_heavy_cpu_lease
owner='performance_fresh_1011'
def execution_hashes():
 paths=set()
 manifest=json.loads((base/'private-contract-reuse-production-fullroots-emit-r1.json').read_text())
 for path,digest in manifest['firstReads'].items():
  if not Path(path).is_file() or __import__('hashlib').sha256(Path(path).read_bytes()).hexdigest()!=digest:raise RuntimeError('candidate_compile_epoch_not_current')
  paths.add(path)
 out=Path(json.loads((base/'private-contract-reuse-production-owned-output-r1.json').read_text())['output'])
 for entry in manifest['outputs']:
  if __import__('hashlib').sha256(Path(entry['path']).read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('candidate_emitted_js_drift')
 paths.update(str(p) for p in out.rglob('*') if p.is_file())
 w=Path('/Users/kai/projects/xiaok-cli-unfinished-integration-20261005')
 paths.update(str(w/p) for p in ['vitest.sandbox.config.mjs','tests/support/vite-net-use-patch.cjs','tests/support/profile-account.global.mjs','tests/support/profile-account.setup.mjs'])
 paths.add(str(base/'vitest.private-contract-reuse-production.config.mjs'))
 paths.add(str(base/'original14-private-contract-production-command-r1.json'))
 paths.add(str(Path(__file__).resolve()))
 for entry in json.loads((base/'private-contract-reuse-native-sdk-probe-r1.json').read_text())['nativeFiles']:
  if __import__('hashlib').sha256(Path(entry['path']).read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('actual_sdk_drift')
  paths.add(entry['path'])
 f=base/'private-contract-reuse-implementation-r1'
 for entry in json.loads((f/'code-review-request-r1.json').read_text())['allInputs']:
  if __import__('hashlib').sha256(Path(entry['path']).read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('formal_implementation_input_drift')
  paths.add(entry['path'])
 return {p:__import__('hashlib').sha256(Path(p).read_bytes()).hexdigest() for p in sorted(paths)}
command=json.loads((base/'original14-private-contract-production-command-r1.json').read_text())
if not isinstance(command,list) or not command or not all(isinstance(value,str) for value in command):raise RuntimeError('invalid_supervisor_argv')
if command[0]!='python3' or not Path(command[1]).is_file() or command[command.index('--bound-ms')+1]!='180000':raise RuntimeError('invalid_exact_supervisor_bound')
frozen_before=execution_hashes()
try:token=acquire_heavy_cpu_lease(owner)
except RuntimeError as error:print(str(error),flush=True);raise SystemExit(75)
closed=False
spawned=False
try:
 (base/'original14-private-contract-production-lease-r1.json').open('x').write(json.dumps({'owner':owner,'token':token,'supervisorPid':os.getpid()},indent=2)+'\n')

 (base/'original14-private-contract-production-before-r1.json').open('x').write(json.dumps(frozen_before,indent=2)+'\n')
 os.environ['SOLPI_INTENT_POPULATION']='1'
 parent=subprocess.Popen(command)
 spawned=True
 (base/'original14-private-contract-production-supervisor-pid-r1.json').open('x').write(json.dumps({'pid':parent.pid,'owner':owner,'command':command},indent=2)+'\n')
 exit_code=parent.wait()
 r=json.loads((base/'original14-private-contract-production-wall-r1.json').read_text());closed=r.get('parentReaped')and r.get('ownedGroupGone')
 if not closed and r.get('parentReaped') and r.get('pid'):
  pg=r['ownedProcessGroup']
  try:os.killpg(pg,0)
  except ProcessLookupError:closed=True;(base/'original14-private-contract-production-post-reap-audit-r1.json').open('x').write(json.dumps({'ownedGroup':pg,'actualProbe':'ESRCH','parentReaped':True,'runnerBoundQualification':r.get('boundQualified')},indent=2)+'\n')
 if not closed:raise RuntimeError('actual_owned_group_not_proved_closed; keep_mutex')
 frozen_after=execution_hashes()
 if frozen_after!=frozen_before:raise RuntimeError('security_input_or_output_drift')
 (base/'original14-private-contract-production-after-r1.json').open('x').write(json.dumps(frozen_after,indent=2)+'\n')
 raise SystemExit(exit_code)
finally:
 if closed or not spawned:release_heavy_cpu_lease(owner,token)
