全部核对完成。以下为独立 P0/P1 DESIGN 批审 + channel-mcp fixture TEST_FIX 结论（审阅基准：batch-design-r1.md 全文、四域 result manifest、候选模块/patch 全读、关键源码行逐一亲证；未跑任何测试/构建，符合本审只读边界）。

---

## 逐域裁定

### runtime-status 2 — **APPROVE_DESIGN**
前次 BLOCK 两项均已用真实证据闭合：
- 消费者：`ProjectDetailPage.tsx:435` 于 `:439` 解构 `serviceStatus`，`:1010-1012` 实际渲染 `projectsDetailWorkflowServiceOutdated` banner，与 caller-census 一致；banner 正常/已知错误/初始读失败/最新事件兼容回归为强制项。
- locale：选 MOUNT-ONLY（保留原 `effect []` 语义，不加 locale 依赖，带 locale-NO-reread/resubscribe 回归）。`KSwarmContext.tsx:27` 的无守卫初始读、迟到覆盖、迟到卸载发布均被 active-owner + 事件代际计数设计精确针对。
- 数据保真：`kswarm-service.ts:774-785` 亲证全 8 字段透传、未来 metadata passthrough、state 自由字符串、数值仅 TYPE 校验（含继承非有限值，无虚构 finite/非负边界）；`main.ts:660-662` 亲证 service 为空时注册缺失语义保留；双 registrar 各自 WeakMap owner、capture-before-schema、nativePromise、无急切构造，均与已批 readonly2 原语一致。

### skills 2 — **APPROVE_DESIGN**（附应用条件）
- literal main-owned `'user'`：producer map 字面注入，`desktop-skill-mutation.ts:11` 捕获后 `!== 'user'` default-deny，wire 不能自授来源；agent 兄弟链（desktop-services.ts:2964-3029）显式保留为父债，无全局授权宣称。
- 名称 512/路径/盘符/选项前缀拒绝为已声明行为增量，依据 argv-operand 语义且保留 Unicode/内部空格；输出 passthrough、无 false/true 兜底、异常 identity 保留、失败零 bump 原语义。
- 市场 adapter false→throw 与 deleteSkill 同型；亲证三个调用点全部在 try/catch 内（SkillsSettingsContent.tsx:211,281,318），失败后默认技能写入被阻断，方向正确；完整 UI 生命周期/本地化验证留 owner 队列。
- cross-spawn 7.0.6 已在 `desktop/package.json:39`；60/30s 同步阻塞原样保留不恶化。

### channelMCP 7 — **APPROVE_DESIGN**（附应用条件）
- literal main-owned `'user'`：proposal ipc.ts producer map 字面注入；`channel-mcp-mutation-owner.ts:15` admission default-deny（缺/agent/scheduler 一律拒绝，副作用前）。red.test.ts 亲证为真生产接线（真 registrar/service + AST 提取 `authorizeDesktopInvoke`，磁盘/网络前拒绝断言），非自造逻辑。
- 表单人口完整覆盖亲证：`DesktopSettings.tsx:2032-2078` 六种通道字段键恰为 appId/appSecret/token/botToken/chatId + type/name，strict schema 无人口误伤；`channelsDeleteConfirm` locale 键已存在，channel delete confirm（`:2130`）保留，MCP delete confirm + aria-label + 三 locale 键为已声明增量。
- 凭证落盘为已声明决策：0600 config、mutation ACK 不回显（strict 输出）、存量 stored schema passthrough 亲证（`channel-mcp-readonly-ipc-contract.ts:11-13`）保存后读写不破；不宣称运行时消费。
- strict ENOENT-only 读、不修复坏文件、同 JS turn 读→改→写、0600 MCP 写、重复 id 拒绝、missing 幂等不写、testChannel 仅 http(s) 无 userinfo/固定网络码/HTTP 业务失败保留——全部与设计矩阵一致且逐项声明。
- 条件：proposal 内两处 `ipc-runtime.ts` union 扩至 34（@@ -27,7 / @@ -62,7）由 owner 恰好应用一次；跨进程/部分写回滚/Windows ACL·NTFS·symlink、凭证错误通道脱敏、全 writer 父债继续 OPEN。

### meeting 4 — **APPROVE_DESIGN**（附应用条件）
- literal main-owned `'user'`：proposal ipc.ts producer map 字面注入；`meeting-mutation-service.ts:15` authorize default-deny；模型 ID 注册表校验、不再 String 强转（已声明增量）。
- saveAsrConfig：truthful 读→语义编辑→同步 save 同 turn（两 writer 竞态在本路径修复）；`[]/[null]/[undefined]/[{}]` 经 union schema + `?? {}` 保留；投影先验证后落盘——存量带凭证 URL 保存前失败是**已批准的兼容性决策**（读侧仍可见，便于修正）；`src/utils/config.ts:112-113` 写后 tighten 部分持久化如实保留为父债。
- 下载 lease：进程级、resolve+win32 小写键、`return await` + finally 覆盖 transfer/hash 重试/解压至 settle，uninstall busy reject，不同模型并发保留（proposal hunk 亲证）；传输 aborted ≠ 用户取消、shutdown token 等真实 settlement，不造取消 ACK。
- 麦克风权限：同 pending 单飞、不缓存完成结果、拒绝不伪造 granted，原平台分支保留。
- 条件：活跃转录/标点模型占用 lease、用户取消/退出策略、symlink 别名/跨进程、`VoiceSettings.tsx:667-690` 保存路由归属核实——全部 OPEN 且未隐瞒；占用 lease 缺失与现生产行为持平（非回归），须 owner 后续决策 + 真实 held-consumer 控制。

---

## TEST_FIX：channel-mcp `fixture-source.patch` — **APPROVE_TEST_FIX**
- 仅触及两个既有测试文件；14+1 处调用与全库独立 grep 结果完全一致（无其他接收者名/文件遗漏，`testChannel` 无既有 fixture 调用者）——覆盖完整。
- 逐 hunk 亲读：仅追加字面 `'user'`（与 proposal 新签名 `requestSource?:` 位置匹配），无一处 assertion/测试名/population/`'not found'` 字符串改动，空行保留；`git apply --check` 对当前 HEAD exit 0（patch-check.json）。非缩样本、非强造绿；RED 候选在未应用 HEAD 原样运行。

## 共享边界总评 — **批准整批放行，条件如下**
1. **Round 34 统一**：skills `skill-mutation-typed-ipc.ts:20` 与 meeting `meeting-mutation-typed-ipc.ts:28` 仍为 33，应用时 owner 改为 34（union 由 channel-mcp proposal 一次扩展）；skills 新 metadata 测试期望 33→34 适配不得删原断言。
2. 三份 proposal 共享文件（ipc.ts/preload-api.ts/bridge.ts/DesktopSettings.tsx/locales/desktop-services.ts）分属不同 hunk，owner 顺序集成、禁止盲 apply；worker 仅隔离 artifact，现状合规（无生产应用、无 commit/push、语法/apply-check 级检查、`handoff-migration/` 原样）。
3. **全父验收保持 OPEN**：224/298 剩 74 不变；本批为组件资格裁定，不构成整父发布宣称；RED 9 文件/248/87 过/161 败仅为 source-before 证据非资格；native/material/P4 不重试；PR37 full-HEAD 质量 NOT RUN，founder 决定合并；原人口/期限/baseline/失败票据全部保留。
4. 各域 OPEN 残债（兄弟 agent 工具、全 writer/saveFile 旁路、跨进程/部分写、Windows 物理验证、clawhub 安装物理证据、凭证错误通道、活跃模型占用、取消/退出策略）均已在设计中原地披露，不得被组件级声明掩盖。

无 BLOCK 项；四域 + TEST_FIX 全部放行，批准的不相交路径可并行推进，无需再启 leaf 审查。