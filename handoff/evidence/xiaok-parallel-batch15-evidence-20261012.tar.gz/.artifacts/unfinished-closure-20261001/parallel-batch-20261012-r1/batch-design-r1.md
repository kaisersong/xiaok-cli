# Combined P0/P1 DESIGN batch1:15 original targets, no production applied

Owner uses exact existing Main+Recorder/frame/URL admission, capture/nativePromise/shutdown primitives; no new generic authority/lifecycle foundation. Original count224/298 remaining74. Existing PR37 HEAD b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1, final wholePRquality NOT RUN, foundermergeonly. Latestuser authorized3parallelworkers and batchedthirdpartyreview; former no-subagents revoked. WorkerIDs/writeownership: ownership-plan-r2.json. Inputs below are actual code-backed drafts/candidates, not promises already implemented.

Batch decisions: all15 new semantic registrations use one rolloutRound34 (not33, not different leafrounds); owner extends two unions once. Skills candidate's new metadata test expectation33 will be correctedto34 as partofnewtest adaptation, no originalassertion cuts. Existing Main/IPC/preload/service/bridge/DesktopSettings/locales shared files owneronly; workers artifactscandidates remainisolated. Runtime status lifecycle now MOUNTONLY: preserve original effect[] locale behavior, nolocale read/resubscribe; current ProjectDetailPage435/439/1010-12 is existingconsumer, oldzeroUI statement wasfalse and preserved withBLOCK. Testexistingbannercompatibility is mandatory.

Honest scope: typedIPC/input/output/source-defaultdeny wherepresent, truthfulreading/edit ACK/lifecycle/lastgood within specifiedboundaries. ALL original parentallwriters/installed/native/security/Windows goals remainopen; literal main-owned'user' doesnotgrant arbitraryMaininternals/cannotclose siblingtool/genericfile bypass. Agent defaultsdeny and readonlyfacts donotprove fullglobal purpose/principal safety. Name512/colon/path restrictions, newcredential/URL policies/confirm/rawschema1/upsert/lease/actor service parameters are intentionalbehaviorchanges that MUST be concretely approvedorblocked from code-backed callerpopulation, not silentlycalled no behavior. Core3 remainbyteunchanged. Unknown partialwrite outcomes not rollback/atomicglobaltransaction; normalpaths/legitresolveddomainfalse preserved.

Physicalgates: single integrationowner executed source-beforebatch RED9files248tests:87pass161fail0pending; rawlog/process/JSON present. Those include actualoldproduction behavior and someproposednewfeatures, not qualification. Oldstatecontext RED had3unhandlednew-callback-absent errors; correctedtest probes missingAPI explicitly; originalreceipt preserved. No productionmodule applied. Eachworker syntax-only/applycheck isnot behavior pass. Sourcebefore testdependency instrumentation is explicitlymocked OSprocess/SDKactor/network but actualregistrar/service/authorizer bodies; no constructor/normalSDK/native/installedclaim. NormalCorefailures from tests retained, no retryoldnative/material/P4.

Review instructions: approve/block EACH clear domain and shared decisions with preciseactionablefile:line, allowing approvedindependentpaths to advance whileblockedonesfixedparallel; one batchresponse, no separateleafreviewstartups. TEST_FIX portion channel-mcp fixture-source.patch addsmain-owned'user' only to actualexisting fixtures; assertions/names/populations unchanged, judge actualpatch notclaim. Read4designsbelow, result manifests/targetedproposalmodule source asneeded, avoid entiregiantSDK/Corefiles or giantVitestJSON. Do not cut gates just to approve.

---
## DOMAIN runtime-status2 (complete draft)
Source /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/runtime-status-readonly2-20261012-recovery-r1/design-r2.md SHA256 7e24a748cdcd5bc2976155be4a262a63ae9f806335b07214a87efed44ba252e4

# Runtime status readonly2: DESIGN draft, not applied

Current approved originalsource224/298, remaining74; next two ORIGINAL channels only: desktop:getComputerUseCapabilityStatus (ipc.ts:1336) and desktop:kswarm:getStatus (main.ts:662). Current PR37 fullHEAD b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1 is Draft, wholequality NOT RUN. DocsDraftPR4. CodingGPT6, actual independentreviewerGLM5.3. No sourcechanges/count yet. No native/material/performance rejectedaction retry. Existing code/approval packets and original parentgate populations/deadlines/failures remainpreserved.

Actualcached producers:
- DesktopServices getter closure desktop-services.ts:1776-1804/public3182: state free string, mcpConnected boolean, wrapperReady boolean, lastError optional string; it observes already initialized in-memory plugin/backend state and never enables/reconnects/openssettings. Keep state string futurevalues, no invented enum/healthy fallback. Actualtype preload-api.ts:899. Bridge actual passthrough at860-861. Current renderer search finds no method caller outside bridge; explicit AST/caller proof beforezeroUIclaim.
- Actual KSwarm getStatus kswarm-service.ts:774-785 returns all8 fields: running,port,pid,restartCount,lastError,terminalDegraded,persistenceFailStopCount,lastPersistenceFailStop. Core interface330 has optional last3 but preload interface919 onlydescribes first5; no clipping runtime8. Preserve terminaldegraded/failstop data and futuremetadata. Constructor is separate lifecycle, mayloadOrCreateRoomSecrets; read methoddoesnotstart/stop/restart. No constructor on read. Main current getter registered ONLY after actual servicefactory nonnull (`if(!kswarmService)returnwindow` main.ts660); retain registrationabsence when unavailable rather than creating/gettingSDKor reorderingwhole lifecycle.

Fixed sourcehosting/dependency direction:
1. New desktop/shared/runtime-status-readonly-ipc-contract.ts: stricttuple0, capability/fullSDK schemas (both passthrough futuremetadata), knownoptionalSDK3 explicit; state string, exactexisting nullable/optional data, no newdefaults/no successerrorenvelope. Inferred outputtypes replace preload return typing; CJS exactexisting zeroABI unchanged.
2. New desktop/electron/runtime-status-readonly-typed-ipc.ts: export registerComputerUseCapabilityReadonlyIpc(ipc,producer?) and registerKswarmStatusReadonlyIpc(ipc,producer?). Shared private helper registers exactlyone fixed channel. Separate WeakMap owner perexport records producerfunctionidentity (undefined valid onlyforcensus/test unavailable); same owner idempotent, changedowner reject runtime_status_registrar_owner_conflict. StandardnativePromise + capture-before-schema + eachinvoke detachedfullDTO; zeroargs capturedbeforeproducer. Absentproducer runtime_status_runtime_unavailable. Input/output fixed errors runtime_status_input_invalid/runtime_status_projection_unavailable. Raw syncbusiness/IOthrow and native rejection identity preserved. No credential reflection formatter added; genuine SDKerror/lastError is validexistingdomain data. RiskTags[] because these two getters observe cachedmemory, no source-sideFS/network/exec effect. rolloutRound34 union extended, oldruntimeJS mustremainidentical.
3. ipc.ts replaces ONLY raw capability registration with narrowexport+late ()=>services.getComputerUseCapabilityStatus; main.ts replaces ONLY rawstatus after existingnonnullguard with narrowexport+late ()=>kswarmService.getStatus. No rawduplicate, no eagergetter/serviceconstruction, no KSW lifecycle/source/backend/sidecar modifications. All capabilities/actions/observation remainparentdebt. Core/defaultsiblings byteunchanged. Both original frozen census tests invoke two new registrars with the same collectors, no assertion/populationcuts. Nativepromise siblingcases include both+fullall8normalpositive.

Actual renderer ownership:
KSwarmProvider is actually mounted in renderer/src/main.tsx:33. KSwarmContext.tsx:27 currently unguarded initialread.then(setState).catchnoop, eventsetState, onlyunsubcleanup: lateinitialresponse canoverwrite newSDKevent and lateunmount canpublish; validatefullread/event data beforepublishing. Actual existing consumer: ProjectDetailPage.tsx:435 destructures serviceStatus from useKSwarm at439, and1010-1012 displays t.projectsDetailWorkflowServiceOutdated when lastError includes dynamic workflows (caller-census-r1.log itself records it). Capability method has no static renderer call outside bridge860-861. DesktopSettings serviceStatus is a DIFFERENT fact. Preserve initialnull and failedinitialread null/banner behavior; later failedreads retain lastgood domainfacts, validlatestevents publish unchanged, invalidevents now retainlastgood instead ofpublishingbad payload. New readFailed/reading/reload context fields are additive and this existingbanner doesnotconsume them. No newbadge/control; add explicit actualconsumer regression for banner normal/knownerror/initialreadfailure and latestevent-vs-staleread compatibility.
New useKswarmStatusReadonly hook in renderer/src/hooks/useKswarmStatusReadonly.ts owns that provider servicefact: null initialunknown, booleanfailed/reading, fullvalidated lastgooddata, retry callback exposed as context reloadServiceStatus():void + serviceStatusReadFailed:boolean (distinct fromclientnetwork error), optional serviceStatusReading:boolean; preserve existing serviceStatus property and all useKSwarmClient behavior. Fixedmodulelevel read, serviceeventsubscription onlyexisting onKSwarmStatus, no polling/autostart/reconnect/newserverevent. Lifecycle MOUNT-ONLY (effect dependencies exclude locale; preserve existing [] mount read/subscription semantics), eventgenerationcounter increments on each event; validlatestevent updates full data, invalidlatestevent marks unavailable retainslastgood. A read publishes only if activeowner/currentlifetime and eventgeneration unchanged since its start, so stale success/failure cannot overwrite a newer valid/invalid event. Explicitmanualrequests busyqueue atmostone successor; ordinaryinitialread one perlife, cleanup removes ONLY own subscription, marksinactive, and blocks queued successors/lateevents/lateinitialread; no SDKshutdown/agentaction from reads. Null API/preload rejects asunavailable; no catchhealthyzero. Event malformedvalues do not erase lastgood. KSW service domain error snapshot remains knownsuccess (runningfalse/lastError etc), separate from readunavailable. No newproduct UIneeded; context adds factstate so futurecurrent consumers can distinguish knownsnapshot/null/unavailable. Hookerrors privatefixed, no rawmessage display. API/getDesktopApi actualbridge/preload identitytests required, not mockedUIonly.

Gates before+2 possible226:
Independent DESIGN first; actualRED on realwrapper/authorizer/status producers and context lifecycle: extra/accessor/proxyinput, badoutputs/businessidentity/stdPromise/species/detach/full8/futurestate/futuremeta/missingproducer/idempotence/5sdrain tokens/Main+Recorder/unknown+old+subframe deny-before-getter; contextinitialunknown/readfailure/invalidread/events/full8/lastgood/manualsinglequeue/locale-NO-reread-or-resubscribe/unmount/events-vs-read/staleerror/noaction/noautostart. Real SDK getStatus ownconstructor fixture must isolate config/token/data paths and NOT startsidecar; do not log generatedsecrets; alternatively truthful explicitsurrogate status actor plus actualgetStatus sourcebeforechar withlimits, no normalSDK claim. Capability actualcreateDesktopServices ownroot getter, teardown ownwriters/dispose and mockeddriver unavailable/normalfixtures preserveoriginal cases.
Original related124files + current KSW/CUA/actualcontext tests (do NOT remove originals/conditional skips), strictactualfullconfigs/noCheckfalse + newtests/context roots, fullgov/changed/newtestlint, actualmain/rendererbuild, sourceextractedOWN Electron actualproducerMap/authorizer/CJS/Recorder probe, fresh explicitGLM5.3 CODE, sourcehashcontinuity, precisebranchcommit/PRfinalSHA. FullHEADquality still separateNOTRUN and founder decides merge. One heavy taskatime, actualwait/reap/groupGone, onlyownPIDs. No baselinemasks, retrycaps/timerextensions, dtypeclipping or fakehealthy defaults. All originalparent176/351/99+deadlines/14Loop13failures/84/largefixtures/allwriters/history/principals/migration/restart/retirement/adopt/normalinstall/WindowsNTFS/actualUI-CLI-TTY/sameSHArelease/latestmain+siblings/liveCI stayopen.

Actual source-before characterization completed: characterization-before-r1.json has actualextracted cachedgetter and rawhandler bodies, explicitsurrogate cache bindings (constructorNOTRUN),3SDKstates(full8)+5capabilitystates+2rawextraignoredcases=10,starts/actions0; own supervisor exit0/actualwait/reap/groupGone/no source drift. Doesnotprove normal SDKconstructor/sidecar/driver/native/installed/UI. caller-census-r1.log records current sourcefilelines; no newUI invented. Runtime status numeric fields preserve original TYPE-only number (including nonfinite inherited state where applicable), no invented finite/nonnegative bounds; renderer context preservesfullfact rather than inventing zero. Only typedstatus RPC is beingadded, not validating the complete Core writer/lifecycle.

R2 blocker closure: original false zero-UI assertion preserved in R1/BLOCK; exact ProjectDetailPage consumer and banner compatibility now explicit. Lifecycle chosen option(b) mount-only, locale switch doesnotread/resubscribe and receives regression; no useLocale dependency is added. Batchreview will combine this corrected design with sidecar skills2/channelMCP7/meetingconfig4, not another leafdesign startup.

---
## DOMAIN skills2 (complete draft)
Source /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/design.md SHA256 96561dd6b80906733aebe4e5f6f55b76253a83b8e26d8a3f66e11aa2243c323d

# skills mutation2 候选设计（未审、未应用）

基于完整 head `b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1`。仅 `desktop:installSkill` / `desktop:uninstallSkill`。224/298、剩74、Draft PR37及原验收人口/期限/baseline/失败票/native/material/P4自动拒绝均不改。集成owner `01a12dcb-8ce2-7392-be2e-2ea1a5fedcc5` 统一安排不同模型 DESIGN/CODE 审、应用及重型验证；worker 未启动 GLM/Qoder、子代理、commit/push/合并/发布。

## 亲读事实与真实调用链

| 边界 | 当前代码证据（本worker亲读） | 结论 |
|---|---|---|
| 设置页真实入口 | `desktop/renderer/src/components/DesktopSettings.tsx:1809-1848` | install trim名称；uninstall先confirm；两者检查success、成功刷新、catch显示动作错误。 |
| 市场页caller | `desktop/renderer/src/components/SkillsSettingsContent.tsx:177-184`；`desktop/renderer/src/api/bridge.ts:1404-1410` | 安装adapter直接返回false；caller未检查就执行默认技能启用。delete已有false→throw。导入stub当前拒绝（`bridge.ts:1413-1422`），不能夸称市场真实安装链已验收。 |
| preload | `desktop/electron/preload-api.ts:1258-1259,1735-1736`；`desktop/electron/preload.cjs:168-169` | 原单字符串调用及 `{success,message}` DTO保留；不传renderer自称来源/路径。 |
| Main registrar | `desktop/electron/ipc.ts:1296-1306`；日志实现`:608-611` | 未做这两条的tuple/schema/capture；日志先读输入及输出success。异常对象getter/toJSON会被直接读取。 |
| service/实际副作用 | `desktop/electron/desktop-services.ts:3262-3292` | 直接同步clawhub install/uninstall；60/30秒、cwd=process.cwd()；error/nonzero返回false，status0才bump。此处没有安装文件存在/删除事实的后置核对，也没有service内requestSource限制。退出码成功不能单独证明安装目录进入catalog。 |
| catalog失效/广播 | `desktop/electron/skill-catalog-invalidation.ts:8-23`；`desktop/electron/main.ts:1733-1736` | bump版本并同步listener；listener异常不改变命令结果；Main窗口存活才广播，不是全窗口广播。 |
| runner reload | `desktop/electron/desktop-services.ts:8030-8032,8096-8109` | 非受限下一任务版本不同才reload；reload失败也推进版本，当前任务保持原目录。非“安装完成即全runner同步reload”。 |
| root可见性 | `src/ai/skills/loader.ts:541-542`；`desktop/electron/desktop-services.ts:3266,3282,8030` | loader使用global/project .xiaok roots，runner另有extraRoots；服务未传clawhub安装root。真实clawhub解析目标是否对齐尚需安装环境证据，不以推测写成不存在。 |
| 已审底座 | `desktop/electron/main.ts:188-207`；`desktop/electron/shutdown-aware-ipc-main.ts:168-179`；`desktop/electron/ipc-data-snapshot.ts:10-40`；`desktop/electron/skill-list-typed-ipc.ts:15-45` | 当前Main/Recorder/mainFrame/URL来源准入先于payload；同一个shutdown token包围handler，复用capture/nativePromise/runtime。 |
| 兄弟路径 | `desktop/electron/desktop-services.ts:2964-3029`；`src/ai/tools/uninstall-skill.ts:79-95`；`src/ai/tools/install-skill.ts:197-222` | Desktop agent工具仍permission=safe且直接spawnSync；CLI另有filesystem/git写链。本候选不改它们，不声称全部技能mutation权限已关闭。 |

优先复用已实现自动reload设计 `docs/design/2026-07-28-desktop-skill-install-auto-reload.md`，该文“现状缺口”是历史描述，以上代码才是本次事实；未找到本两条mutation独立批准票的证明，不能借readonly2批准视为本设计批准。复用readonly2现有capture/registrar模式，不引入通用基础新owner。

## 候选实现与风险

1. 新shared contract只限定原名称字符串的一参tuple；拒绝多参（包括伪造source/root）、getter/serializer、空/外边空白、路径分隔符/控制字符/盘符/`.`/`..`/开头option及>512名称。不限定ASCII slug，Unicode、内部空格、namespace均保留。512上限及盘符样式名称拒绝仍是行为增量，须审确认原caller人口，不通过缩人口拿资格。
2. 新typed registrar复用现有runtime/capture/nativePromise；先capture输入再调用producer；返回原DTO并保未知data extras；producer异常保持identity，非法ACK拒绝，不造false/true兜底。原payload/结果日志移除，避免capture前触发getter。合法Main与Recorder原人口保留。round33只是现有union可用的候选值，owner审核分配；不改runtime两处union，不改typed计数。
3. service显式要求main-owned `{requestSource:'user'}`（缺失/agent/scheduler拒绝），即使绕IPC也先验证名称；新domain module执行原流程。IPC固定注入来源，renderer不可自授来源。它不取代真实sender闸门，也不能防有能力伪造user的其他Main内部caller；agent兄弟路径未闭合必须保留风险。
4. 复用已安装cross-spawn 7.0.6的sync处理Windows .cmd（`desktop/package.json:39`），不手拼shell。保持命令、cwd、60/30秒、failure message优先级与500截断、成功时一次bump。没有改成异步/换根/重试/自动回滚。
5. 市场安装adapter像既有delete一样对业务false抛错，阻止启用默认技能。设置页继续用原DTO分支；preload/type/CJS传参返回不变，所以只增加真实双入口contract controls。

## 边界矩阵（已写候选，全部未跑）

| 控制 | 实际被调入口/外部替身 | 预期 |
|---|---|---|
| success命令/deadline/cwd | 真service+registrar；只替换OS process primitive | 参数原样；version+1；执行真实Main广播registration回调一次 |
| error/ENOENT/timeout/signal/nonzero | 同上 | false、bounded stderr/stdout优先级；零bump/广播/token泄漏 |
| missing/extra/伪来源/path/option/getter/toJSON | 真registrar+直接service | 副作用前拒绝；getter零读取 |
| direct service来源缺失/agent/scheduler/accessor | 真service | 默认拒绝；合法user路径仍成功 |
| unknown ACK/getter/toJSON/thenable | 真registrar调用可故障注入service | capture先于getter；固定边界错误；合法false+extras脱离引用 |
| service throw/reject | 真registrar | 保持原错误identity、token归零 |
| unknown/旧Main/subframe/坏URL | 真Main authorize函数+真实ShutdownAwareIpcMain | source拒绝早于payload；合法Recorder保留 |
| held/shutdown | 真registrar+held service Promise | 原5秒drain仍false、token保留，settle释放，新invoke拒绝 |
| renderer adapter业务false/transport reject | 真bridge | 安装false不能继续默认启用；delete原行为与success保留 |
| TS/CJS preload与事件dispose | 两个实际preload | 单字符串原tuple、不传source；false/reject保留；unsubscribe |

测试仅在OS process primitive替身下验证协议和因果；Main broadcaster与authorize通过AST读取真实生产语句后执行，不在测试重写其逻辑。既有runner源码扫描、catalog机制/readonly消费者controls保留，但本包不能把它们替代真实安装/native/Windows/全UI验收。

## 未闭合控制与审查重点

- 外部clawhub执行目标root、installed包可发现、卸载后确实不可用、重复安装/不存在卸载、权限拒绝、partial write后失败、symlink/Windows ACL/正常安装包：均需owner自有sandbox物理控制。服务只看exit0，无文件后验（证据见3262-3292）；不宣称已有这些保证。
- sync阻塞Main达60/30秒保留；此时UI/quit事件调度不能等价held Promise测试。Windows cross-spawn候选只有接线，尚缺真实.cmd shim/argv特殊字符/环境PATH控制。cwd root安全策略仍旧，没有偷偷改成dataRoot。
- 原工具兄弟链可绕此service；本次仅2条IPC资格，不能关闭全mutation授权。permission=safe及CLI脚本行为需父票风险保留。
- stdout/stderr原样可能含路径/凭证；候选刻意保留失败文案语义，敏感错误投影需审决策，尚缺真实错误通道秘密控制。未知DTO拒绝不等于错误脱敏。
- 市场adapter改善失败传播，仍缺实际SkillsSettingsContent失败后默认技能零写入/完整UI生命周期与本地化错误验证；现有stub不构成真实市场安装证明。
- 成功broadcast仅Main，销毁窗口跳过；listener throw被吞；runner reload失败推进version旧语义保留，需完整真实任务/多runner控制而非假绿重写。

## owner运行顺序与命令

先集中DESIGN审（P0/P1 Codex写、不同模型审）；owner将文件复制到以下实际目录，先在未应用head留RED日志，再审、应用patch。只允许owner执行这些写生产动作。

```sh
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/red.test.ts desktop/tests/main/skill-mutation-controls.test.ts
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/bridge.red.test.ts desktop/tests/renderer/skill-mutation-bridge.test.ts
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/preload.control.test.ts desktop/tests/main/skill-mutation-preload.test.ts
npm --prefix desktop run test -- --run tests/main/skill-mutation-controls.test.ts tests/main/skill-mutation-preload.test.ts tests/renderer/skill-mutation-bridge.test.ts
# 审批后由owner应用，不由worker执行：
git apply .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/proposal.patch
# 集中关联队列：
npm --prefix desktop run test -- --run tests/main/skill-mutation-controls.test.ts tests/main/skill-mutation-preload.test.ts tests/renderer/skill-mutation-bridge.test.ts tests/main/skill-reload-on-install.test.ts tests/main/skill-catalog-invalidation.test.ts tests/main/skills-readonly-controls.test.ts tests/renderer/skills-readonly-consumers.test.tsx tests/main/ipc-registrar-contract.test.ts tests/main/preload-contract.test.ts
```

worker实际只执行TypeScript syntax parse与`git apply --check`，均通过；没有运行上述测试/build/typecheck/governance/hygiene/native、没有production应用。hygiene及其它gate移交集中队列；foreign WIP `?? handoff-migration/`保留。P0/P1设计/代码批审未开始，不能宣称RED已实测或2项已关闭。

---
## DOMAIN channel-mcp7 (complete draft)
Source /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/channel-mcp/design.md SHA256 9bc362c9fe4f153bdf370421ceae7cbc5451327962f668e4a1a056eff6098790

# Channel/MCP mutation7：未审、未应用候选

事实基准：b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1；224/298、剩74、Draft PR37 原样保留。只有本目录写入；无 commit/push/生产应用/子代理/GLM/Qoder。集成与 DESIGN/TEST_FIX/CODE 独立异模型评审 owner：01a12dcb-8ce2-7392-be2e-2ea1a5fedcc5。原验收人口、期限、baseline、失败、foreign WIP 与 native/material/P4 自动拒绝全保留；本交付不计任何关闭。

## 已亲读事实与复用

- 根 AGENTS.md、CONTEXT.md、desktop-architecture/agent-tools/verification/evidence-and-design guidance、docs/quality/lessons-ledger.md 全文已读。遵循台账 #13/#16/#22/#23；只写候选是用户最新明确授权。
- 七项 raw handler 直接调用 service，未加 typed tuple/projection 校验：`desktop/electron/ipc.ts:1314-1326`。不是“没有来源准入”：唯一 raw owner 已在 `shutdown-aware-ipc-main.ts:160-169` 准入、持有原 token；生产绑定 `main.ts:188-205` 检查 current Main/Recorder、mainFrame 和 URL。直接复用，不重设 runtime 状态2。
- 已关闭 readonly2 的批准范围及排除项：`.artifacts/unfinished-closure-20261001/channel-mcp-readonly2-20261012-recovery-r1/component-final-r1.json:7-13,30`（其历史计数不作当前计数）。复用 `channel-mcp-readonly-ipc-contract.ts:5-13` 存储/公开 schemas、`channel-mcp-readonly-typed-ipc.ts:15-19` capture/intrinsic Promise 方式，`ipc-data-snapshot.ts` 与 `ipc-native-promise.ts:8-16`；不改 Core3/readonly实现。
- 三个通道 writer/test 均调用 repair-capable loadConfig：`desktop-services.ts:3955,3980,4001,4017`；坏JSON备份移除→默认 `src/utils/config.ts:80-96`，I/O fallback默认 `:73-78`；写入整份配置 `:106-113`。MCP三个 writer catch-all默认 [] `desktop-services.ts:4030,4046,4058,5116-5122`。没有 durable MCP 安装/执行动作：这三个方法完整体 `:4028-4059` 仅写 JSON/投影；“安装成功”不能据此推断进程已运行。

## 真实 caller / owner / contract 矩阵

| IPC | 真实 Desktop UI/bridge | Main owner 与候选边界 | 正常结果、错误、lifecycle |
|---|---|---|---|
| createChannel | DesktopSettings:2104-2125；api/bridge:761-762 | strict `[input]`；支持当前表单 appId/appSecret/token/botToken/chatId + type/name/webhookUrl；禁止保留键 | 原7字段 ACK；write完成后才返回；创建按 type upsert，保旧row extras |
| updateChannel | DesktopSettings:2139-2144 toggle；bridge:764-765 | strict `[id,patch]`，enabled 与上述字段；type仅可等于id | 原DTO与 not found 语义；只改明确字段，保其它配置 |
| deleteChannel | DesktopSettings:2129-2135；bridge:767-768 | strict `[id]`，原 UI confirm 保留；service user-only | void ACK；missing id幂等，不造默认配置文件 |
| testChannel | DesktopSettings:2270-2282；bridge:770-774 | strict `[id]`；纯strict读取当前配置；原 POST；仅http(s)、无userinfo | HTTP业务false保留；网络异常固定码，不读message/getter；不重发/不加deadline；原token到settle |
| createMCPInstall | DesktopSettings:2375-2390；bridge:843-844 | strict `[input]`，name/source/command/args；source写入 npm/github/local | 原7字段ACK；真实配置落盘，不安装/执行；command、args保持Windows/空参数原ABI |
| updateMCPInstall | bridge:846-847；当前 McpPane 的本项无按钮，完整 pane `DesktopSettings:2316-2808` 只create/delete与独立plugin actions | strict `[id,patch]`；支持现公开 Partial 中args，保stored future metadata、source旧string ABI | 原toMCPView列；not found保留；完整表读坏则拒绝 |
| deleteMCPInstall | DesktopSettings:2394-2400,2794-2798；bridge:849-850 | strict `[id]`；候选新增locale删除confirm + aria-label（原生产没有confirm，依据:2394-2399） | void ACK；missing幂等；失败不刷新/不清last-good |

preload TS白名单与直连 invoke：`preload-api.ts:561-568,1261-1268,1738-1745`，不改变7个方法名/tuple ABI；CJS transport无参数或wire变更，本候选不重写它，但其已有合同测试仍须运行。新增凭证/args/update enabled TS声明在patch明确列出；renderer桥接签名同步。旧 HTTP Settings 组件的独立导入不等于上述 current Desktop RPC caller，`renderer/src/api/index.ts:1-5` 当前barrel未导出这些旧HTTP create/update/delete 函数；不删旧模块、不缩父人口，owner保其独立验收。

## 候选实现与明确取舍

1. proposal.patch 用一张七项 producer Map 替代七个 raw handle；服务调用显式追加 main-owned `'user'`，不从payload采信requestSource。新增业务owner在service内部 default deny（missing/agent/scheduler），全部7项都做同一权限控制。raw source admission仍是唯一真实窗口依据，UI confirm不是新的Main权限凭据。
2. 新 registrar input先capture再tuple schema，output先capture/schema才交给通用runtime，避免 production把错误包装成resolve `{ok:false}`；无日志URL、name、command、config；sync/native Promise均覆盖，拒getter/proxy/cycle/toJSON与恶意constructor，不retry producer，保正常producer rejection identity。rolloutRound=34是候选编号，owner应在批次统一分配/同步两union；不作为计数。
3. strict file reader ENOENT-only缺失，其余JSON/shape/I/O固定 source_unavailable，不传JSON.parse凭证片段、不改坏文件、不备份/修复。通道规范化仅用于验证，实际保存raw schema1/2及全部非目标字段；调用现 saveConfig 保原600检查。MCP完整stored数组验证、重复id拒绝、JSON extras保留，ACK仍原投影7列；单文件600，不递归目录。两个业务 edit/read/write 在同JS turn、write前无await，修本族同turn丢更新。
4. **有意行为变化必须集中审**：现UI提交的凭证被丢弃（`desktop-services.ts:3983-3988` 只写name/sendMsgUrl/inboundMode/enabled，而表单 `DesktopSettings:2034-2075,2115-2118` 传其他字段）。候选按UI原字段名保存，不发明provider转换；不声称这些凭证已被运行时消费。upsert保extras、raw schema1不迁移、update args落盘、禁止prototype key/type改名、MCP删除confirm均为明确设计选择，不能未经DESIGN批准应用。
5. UI候选保既有读取owner、mutation成功后load、action/read错误独立；catch只展示本地化固定失败，test已知技术码映射既有失败label，HTTP业务失败保留。原失败会透出message的证据 `DesktopSettings:2124-2125,2134-2135,2143-2144,2277-2280,2389-2399`。三locale在patch，不编辑生产locale。

## 同权限兄弟入口及仍缺的 controls（禁止全族安全完成宣称）

| 兄弟/风险 | 亲读依据 | 本轮边界 / owner仍须闭合 |
|---|---|---|
| 通道实际发送/列表agent工具 | desktop-services:2890-2909,2913-2955，permission='safe' | 仍loadConfig repair；list公开URL、send异常message与POST可旁路本轮test限制。未改registry工具，不声称发送权限/secret全部安全 |
| config全份writer及CLI/agent文件能力 | desktop-services:3338/3382,3433-3435,3468-3470,3477-3484,3565-3579；src/commands/config:297-366；src/commands/yzj:658-659 | 旧writer悬挂快照仍可覆盖本候选的新编辑；Core saveConfig非原子事务、不提供跨进程锁/失败回滚；不改共享Core，all-writer验收保父门 |
| 同窗口saveFile直接写配置或MCP文件 | ipc:1584-1598，仅html/text-edit分支特殊校验，普通写直接writeFile | 七项schema不能替代文件能力政策；本轮无零成本绕过已闭合声称，独立父权限范围仍OPEN |
| 凭证投影ABI | readonly契约:5-10 / readonly-data:30 | webhook URL和MCP command/args仍原公开内容，MCP readonly passthrough extras仍可含env等信息；只有新credential字段不进入mutation Channel ACK，不宣称所有secret都隐藏 |
| 实际通道支持/确认 | DesktopSettings:2034-2075,2129-2130,2270-2273,2394-2399 | 凭证消费、不同通道真正消息协议、test发送预期、Main用户意图证明需owner验收；未新增确认token/自动权限放行 |
| 生命周期/平台/失败完整性 | shutdown-aware-ipc-main:160-169；新UI仍沿原lifetime | 已写network-held真实token测试；UI并发点击/迟到action覆盖新locale或unmount、成功ACK后读失败、Windows ACL/NTFS/symlink/hardlink、partialwrite/崩溃恢复/多进程互斥仍缺完整controls。POSIX EACCES/writefail候选仅nonroot非Windows，不能替代Windows证据 |

## 测试与集成顺序

- `red.test.ts` 拷至 `desktop/tests/main/channel-mcp-mutation-controls.test.ts`；真实 createDesktopServices/registerDesktopIpc + 生产 authorizeDesktopInvoke AST，无自造业务逻辑。`ui-red.test.tsx` 拷至 `desktop/tests/renderer/channel-mcp-mutation-ui.test.tsx`；真实页面/bridge，只替window transport。没有运行，不能写“已观测RED”或“通过”。
- DESIGN批审后 owner先运行原head的候选RED，再按批准设计应用proposal。`fixture-source.patch` 只为既有真实service caller补显式'user'，无原assertion删除/改值，须独立TEST_FIX评审；不是缩样本/强造绿。not found原字符串已保留。
- 运行（显式worktree）：`cd /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop && npm run test -- --run tests/main/channel-mcp-mutation-controls.test.ts tests/renderer/channel-mcp-mutation-ui.test.tsx`。
- 关联队列至少含原desktop-services、readonly controls/consumers/bridge/preload、desktop-settings-mcp-pane、preload-contract/sandbox、ipc-registrar-contract/schema-coverage，以及owner冻结的完整原人口/两完整strict noCheck:false/governance/architecture changed/newtestlint/两build/fresh CODE；本worker不跑重型验证、不更新baseline。全部实际安装/UI/native/Windows与原父门仍OPEN。
- 实际轻检查：5个候选TS/TSX transpile语法检查（不类型检查/不跑测试）；两patch `git apply --check`。`hygiene:check -- --no-fetch` exit1，sibling behind失败原样存log；完整fetch hygiene会写其它repo refs，不在唯一写目录授权内，交owner队列。结果详见 result.json。

---
## DOMAIN meeting-config4 (complete draft)
Source /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/meeting-config/design.md SHA256 e03250030b59af043eb82084ee0a6e4d9d4c9a6bb7a531b25fe6b96e5da7d194

# Meeting mutation4：未审、未应用候选

基于完整 HEAD b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1。唯一范围是 desktop:meeting:{requestMicrophonePermission,saveAsrConfig,downloadModel,uninstallModel}；224/298、剩74、Draft PR37、原人口/期限/baseline/失败/foreign WIP 不变。runtime 状态2归集成 owner。P0/P1 的异模型 DESIGN/CODE 审查由 owner 合批；本 worker 未派代理、未启动 GLM/Qoder、未 commit/push/merge/publish、未应用源码。

## 事实与复用

亲读：ipc.ts:1817–1826,1836–1843 四个 raw handler。save 使用 input??{}、await loadConfig 后修改和保存；模型每次新建实例并 String 强制转换。loadConfig 读失败返回默认、坏JSON backup/remove：src/utils/config.ts:66–99；这对 save 也会产生“修复后成功”。现有 save 的两个 await 允许两个 writer 先各自读取再覆盖：ipc.ts:1824–1825（因果 RED 候选，未运行）。saveConfig 自身同步 chmod/write，async wrapper 无内部 await：src/utils/config.ts:102–114。

复用已批准 readonly3：meeting-readonly-data.ts:21–45（真ENOENT、固定解析码、真实 normalizer、凭证布尔投影），meeting-readonly-typed-ipc.ts:10–23（capture/nativePromise/schema），shared/meeting-readonly-ipc-contract.ts:4–6（原完整DTO）。提取已有读取函数为 readMeetingAsrConfig()，readonly 原投影行为保持。已有 owned-window 设计 .artifacts/unfinished-closure-20261001/complete-main-20261011-r1/owned-window-admission-design-r3.md；生产绑定 main.ts:188、鉴别190–206；shutdown-aware-ipc-main.ts:160–169 原 token/admission/finally；不新建通用基建。

模型 download 无跨实例互斥、uninstall 不检查正在下载：meeting-model-service.ts:270–304；directory 的 extract await 期间也可能卸载：366–402。候选仅添加同 cache/model 的 process-local 下载 lease，完整覆盖 transfer/hash retry/extraction 到 Promise settlement，finally 释放，uninstall/重复download busy reject；不同模型仍可并发。原 Range/resume/HTTP aborted/镜像/20次有限重试/hash/size/目录完整性逻辑原样保留：430–529,564–575。用户取消参数/取消IPC目前不存在，依据亲读接口63–75及 IPC1836–1843；HTTP aborted 是可重试 transport 中断，不是用户取消成功。原 shutdown token 等到真实完成，不用 Promise.race 造取消 ACK。

## 实际 caller 与 owner

preload.cjs:471–476 与 preload-api.ts:1400–1405,1964–1969 为四项真实桥接，候选类型通过 preload-api 更新；shared/desktop.ts:3 继承 FullDesktopApi（未新增独立第二份类型）。KnowledgePage.tsx:1049–1056 请求权限后继续 getUserMedia；649–685 模型动作；710–729 保存与失败。DesktopSettings.tsx:455–496 保存、501–530 模型动作。VoiceSettings.tsx:667–690 另有保存调用（是否当前运行路由由 owner 继续核，不宣称不存在）。Main 和 current Recorder 同权限域，不能把 Recorder 限成5条录音命令。

Main 的 singleton meeting mutation facade 是用户动作 owner；service 显式 source，缺失/agent/scheduler default-deny，真实窗口准入后 main 传 user，wire 不能指定 source。OS permission service 仍为事实源，Darwin prompt 实际调用 askForMediaAccess；granted/denied/restricted 不重复请求，win32/linux unknown 后继续浏览器 getUserMedia（meeting-audio-permission.ts:30–49）。facade 仅合并同一 pending OS ask，不缓存完成结果。

## 边界矩阵

|入口|输入与成功|失败/生命周期/风险|
|---|---|---|
|requestMicrophonePermission|严格[]；原 status enum|真实平台分支；同 pending ask 单飞；拒绝不伪造 granted；原物理 token|
|saveAsrConfig|严格顶层/嵌套字段、原 provider；保留[]/[null]/[undefined]/[{}]与空白secret保留、clear优先；完整原 snapshot|capture先于任何getter；真实读取→edit→sync save同turn；确认后投影ACK；坏文件不修复；固定 save_failed；secret字段不投影|
|downloadModel|严格[string]，service匹配完整原 registry，不coerce/反射未知ID；完整{ok:true,model}|原网络/断点/镜像/校验；同资源busy；真实Promise settlement前不释lease/token；不同资源并发保留|
|uninstallModel|严格[string]且完整registry；完整{ok:true,model}|download/extract期间busy；真实rm异常reject；不能把不存在文件与读取权限失败的全部问题视为已关闭|

成功输出 capture+strict schema，拒绝 getter/proxy/thenable/非法nativePromise，不兜底成void ACK或resolved error envelope；原错误只允许固定domain码，否则 action_failed，不读取 error.message getter。公开 endpoint/baseUrl 新增协议与 credential URL 检查：保留空白删除和 http/https/ws/wss 自定义地址，拒绝userinfo/query/hash；存量带凭证URL在保存前投影校验失败，避免落盘后才发现不能安全返回。这项兼容性改变须独审，不能依候选直接裁掉旧人口。

## 尚缺控制 / 集中审阻塞

1. 高风险 DESIGN 未批准；proposal.patch 是可应用性检查通过的候选，不是 production ready。
2. 活跃转录/标点模型的 lease 不在候选中：meeting-sherpa-onnx-transcriber.ts:42–58、meeting-local-transcriber.ts:37–49、meeting-punctuation-service.ts:70–74 在各自 service 使用模型；uninstallModel:297–304 没有在用检查。owner须审明确已有运行模型占用策略并补真实 service/worker held 用例，不能声称完整生命周期关闭。
3. 明确用户取消/应用退出时下载处理 policy；当前 gate只close/drain（shutdown-aware-ipc-main.ts:79–127），没有广播AbortSignal。候选保原等待事实，未新增取消入口；不能把网络aborted重试当作用户取消控制。
4. lease按resolve+Windows lowercase，未覆盖同一cache的symlink别名/跨进程writer。原全writers、WindowsNTFS/ACL/native/安装等父门继续开放；不按局部mutex宣称全局事务。
5. 保存确认失败可能已有部分写盘（src/utils/config.ts:112–113），不宣称原子/rollback；兄弟config writers仍父债务。只读整体strict I/O与 mutation getModelInfo默认existsSync差异需审；候选不重设计readonly3。
6. 需补真实TS/CJS/preload reject传播、所有真实消费者动作错误/lastgood/locale/unmount、合法Main/Recorder全链、OS请求及网络取消平台事实。未跑任何测试/严格typecheck/build/hygiene/governance；全部由owner队列，保留原失败记录和人口。

## 文件与运行

red.test.ts 拷到 desktop/tests/main/meeting-mutation-controls.test.ts；model-lifecycle.red.test.ts 拷到 desktop/tests/main/meeting-mutation-model-lifecycle.test.ts。这两个只导入现有生产registrar/service，可在未应用候选的HEAD运行，预期含行为RED，**尚未实测**。授权负例使用原Main鉴别函数AST，fixture只设置其当前窗口事实；不是重写鉴别。模型是自有临时目录小文件，实际IPC负例的ID全部非registry，避免源码RED误触真实下载/卸载。

candidate-controls.test.ts 拷到 desktop/tests/main/meeting-mutation-candidate-controls.test.ts，仅在设计审批准且owner应用之后运行；未应用时缺模块不是行为RED。producer替身仅用于真实新registrar边界恶意输出/错误通道，不替代真实业务入口用例。

从worktree/desktop运行：
`npm run test -- --run tests/main/meeting-mutation-controls.test.ts tests/main/meeting-mutation-model-lifecycle.test.ts`
应用后增加 `tests/main/meeting-mutation-candidate-controls.test.ts`，并纳入原 meeting-model-service / audio-permission / asr-config / readonly / ui / preload / e2e 原人口。heavy/strict/build及全部父验证由owner安排。三个独立module文件的首行写明目标；proposal.patch包含这些module以及ipc.ts、preload-api.ts、meeting-readonly-data.ts、meeting-model-service.ts精确预计共享编辑，不编辑main/desktop-services/bridge/locales。
