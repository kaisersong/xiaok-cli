# Final actual15target batch CODE source

Complete tracked diff against exactbase b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1; allnewsource/test files complete below; allfullsource SHA in final-source-manifest-r1.json. No virtualoverlay. Native/runtime/installed/wholePR claims withheld.

```diff
diff --git a/desktop/electron/desktop-services.ts b/desktop/electron/desktop-services.ts
index 0fd6ab3b..d15ce646 100644
--- a/desktop/electron/desktop-services.ts
+++ b/desktop/electron/desktop-services.ts
@@ -1,3 +1,6 @@
+import { runDesktopSkillMutation } from './desktop-skill-mutation.js';
+import type { DesktopSkillMutationContext } from '../shared/skill-mutation-ipc-contract.js';
+import { createChannelMcpMutationOwner } from './channel-mcp-mutation-owner.js';
 import { readChannelViews, readMcpInstallViews } from './channel-mcp-readonly-data.js';
 import { captureSkillReadonlyPromise } from './skill-readonly-data.js';
 import { types as skillNodeTypes } from 'node:util';
@@ -909,6 +912,7 @@ function sanitizeSystemOnePatch(input: DesktopSaveSystemOneConfigInput | undefin
 }
 
 export function createDesktopServices(options: DesktopServicesOptions) {
+  const channelMcpMutations = createChannelMcpMutationOwner(options.dataRoot);
   let roomTimedActions:TimedActionService|undefined;
   const getManagedPythonCommand = options.getManagedPythonCommand;
   const officeDocumentParser = createOfficeDocumentParser({
@@ -3259,37 +3263,11 @@ export function createDesktopServices(options: DesktopServicesOptions) {
         tier: s.tier,
       }));
     },
-    async installSkill(skillName: string): Promise<{ success: boolean; message: string }> {
-      const result = spawnSync('clawhub', ['install', skillName], {
-        encoding: 'utf-8',
-        timeout: 60000,
-        cwd: process.cwd(),
-      });
-      if (result.error) {
-        return { success: false, message: `执行失败: ${result.error.message}` };
-      }
-      if (result.status !== 0) {
-        const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
-        return { success: false, message: stderr.slice(0, 500) };
-      }
-      bumpSkillCatalogVersion();
-      return { success: true, message: `技能 ${skillName} 已安装` };
-    },
-    async uninstallSkill(skillName: string): Promise<{ success: boolean; message: string }> {
-      const result = spawnSync('clawhub', ['uninstall', skillName], {
-        encoding: 'utf-8',
-        timeout: 30000,
-        cwd: process.cwd(),
-      });
-      if (result.error) {
-        return { success: false, message: `执行失败: ${result.error.message}` };
-      }
-      if (result.status !== 0) {
-        const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
-        return { success: false, message: stderr.slice(0, 500) };
-      }
-      bumpSkillCatalogVersion();
-      return { success: true, message: `技能 ${skillName} 已卸载` };
+    async installSkill(skillName: string, context: DesktopSkillMutationContext): Promise<{ success: boolean; message: string }> {
+      return runDesktopSkillMutation('install', skillName, context, process.cwd());
+    },
+    async uninstallSkill(skillName: string, context: DesktopSkillMutationContext): Promise<{ success: boolean; message: string }> {
+      return runDesktopSkillMutation('uninstall', skillName, context, process.cwd());
     },
     async createTaskWithFiles(input: {
       prompt: string;
@@ -3951,112 +3929,31 @@ export function createDesktopServices(options: DesktopServicesOptions) {
     async listChannels(): Promise<Array<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }>> {
       return readChannelViews();
     },
-    async testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }> {
-      const config = await loadConfig();
-      const channels = (config as unknown as Record<string, unknown>).channels ?? {};
-      const ch = (channels as Record<string, unknown>)[channelId] as { sendMsgUrl?: string; webhookUrl?: string } | undefined;
-      const url = ch?.sendMsgUrl || ch?.webhookUrl;
-      if (!url) {
-        return { success: false, error: '未配置 webhook URL' };
-      }
-      try {
-        const start = Date.now();
-        // Send a test ping message
-        const response = await fetch(url, {
-          method: 'POST',
-          headers: { 'Content-Type': 'application/json' },
-          body: JSON.stringify({ msgtype: 'text', text: { content: 'xiaok 测试连接 ✅' } }),
-        });
-        const latencyMs = Date.now() - start;
-        if (!response.ok) {
-          return { success: false, latencyMs, error: `HTTP ${response.status}` };
-        }
-        return { success: true, latencyMs };
-      } catch (e) {
-        return { success: false, error: (e as Error).message };
-      }
+    async testChannel(channelId: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.testChannel(channelId, requestSource);
     },
-    async createChannel(input: { type: string; name: string; webhookUrl?: string }): Promise<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }> {
-      const config = await loadConfig();
-      const raw = config as unknown as Record<string, unknown>;
-      if (!raw.channels) raw.channels = {};
-      (raw.channels as Record<string, unknown>)[input.type] = {
-        name: input.name,
-        sendMsgUrl: input.webhookUrl || '',
-        inboundMode: 'webhook',
-        enabled: true,
-      };
-      await saveConfig(config);
-      return {
-        id: input.type,
-        type: input.type,
-        name: input.name,
-        webhookUrl: input.webhookUrl,
-        enabled: true,
-        createdAt: Date.now(),
-        updatedAt: Date.now(),
-      };
+    async createChannel(input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.createChannel(input, requestSource);
     },
-    async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean }): Promise<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }> {
-      const config = await loadConfig();
-      const raw = config as unknown as Record<string, unknown>;
-      const channels = (raw.channels as Record<string, unknown>) || {};
-      const ch = channels[id] as Record<string, unknown> | undefined;
-      if (!ch) throw new Error('Channel not found');
-      if (input.name !== undefined) ch.name = input.name;
-      if (input.webhookUrl !== undefined) ch.sendMsgUrl = input.webhookUrl;
-      if (input.enabled !== undefined) ch.enabled = input.enabled;
-      await saveConfig(config);
-      return {
-        id, type: id, name: (ch.name as string) || id,
-        webhookUrl: ch.sendMsgUrl as string | undefined,
-        enabled: ch.enabled !== false, createdAt: 0, updatedAt: Date.now(),
-      };
+    async updateChannel(id: unknown, input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.updateChannel(id, input, requestSource);
     },
-    async deleteChannel(id: string) {
-      const config = await loadConfig();
-      const raw = config as unknown as Record<string, unknown>;
-      const channels = raw.channels as Record<string, unknown> | undefined;
-      if (channels) delete channels[id];
-      await saveConfig(config);
+    async deleteChannel(id: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.deleteChannel(id, requestSource);
     },
 
     // ---- MCP API ----
     async listMCPInstalls(): Promise<Array<{ id: string; name: string; source: string; command: string; args?: string[]; enabled: boolean; createdAt: number }>> {
       return readMcpInstallViews(options.dataRoot);
     },
-    async createMCPInstall(input: { name: string; source: 'npm' | 'github' | 'local'; command: string; args?: string[] }) {
-      const path = join(options.dataRoot, 'mcp-installs.json');
-      const installs = await loadJsonFile<MCPRecord[]>(path, []);
-      const record: MCPRecord = {
-        id: crypto.randomUUID(),
-        name: input.name,
-        source: input.source,
-        command: input.command,
-        args: input.args,
-        enabled: true,
-        createdAt: Date.now(),
-      };
-      installs.push(record);
-      await saveJsonFile(path, installs);
-      return toMCPView(record);
-    },
-    async updateMCPInstall(id: string, input: { name?: string; source?: 'npm' | 'github' | 'local'; command?: string; enabled?: boolean }) {
-      const path = join(options.dataRoot, 'mcp-installs.json');
-      const installs = await loadJsonFile<MCPRecord[]>(path, []);
-      const idx = installs.findIndex(c => c.id === id);
-      if (idx < 0) throw new Error('MCP install not found');
-      if (input.name !== undefined) installs[idx].name = input.name;
-      if (input.source !== undefined) installs[idx].source = input.source;
-      if (input.command !== undefined) installs[idx].command = input.command;
-      if (input.enabled !== undefined) installs[idx].enabled = input.enabled;
-      await saveJsonFile(path, installs);
-      return toMCPView(installs[idx]);
-    },
-    async deleteMCPInstall(id: string) {
-      const path = join(options.dataRoot, 'mcp-installs.json');
-      const installs = await loadJsonFile<MCPRecord[]>(path, []);
-      await saveJsonFile(path, installs.filter(c => c.id !== id));
+    async createMCPInstall(input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.createMCPInstall(input, requestSource);
+    },
+    async updateMCPInstall(id: unknown, input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.updateMCPInstall(id, input, requestSource);
+    },
+    async deleteMCPInstall(id: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.deleteMCPInstall(id, requestSource);
     },
 
     async exportTraceBundle(input: { kind: 'session' | 'project' | 'task'; id: string }): Promise<{ ok: boolean; path?: string; error?: string }> {
diff --git a/desktop/electron/ipc-runtime.ts b/desktop/electron/ipc-runtime.ts
index 789d1631..d3fd1718 100644
--- a/desktop/electron/ipc-runtime.ts
+++ b/desktop/electron/ipc-runtime.ts
@@ -27,7 +27,7 @@ export interface IpcSchemaEntry {
   payloadMode: 'single' | 'tuple';
   inputStage: 'beforeHandler' | 'afterHostAuthorization';
   wireInput?: ZodSchema;
-  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
+  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34;
   riskTags: RiskTag[];
 }
 
@@ -62,7 +62,7 @@ export interface IpcRegistrationOptions<I, O> {
   input: ZodSchema<I>;
   output: ZodSchema<O>;
   sourceFile: string;
-  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
+  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34;
   riskTags?: RiskTag[];
   handler: (input: I, event: IpcMainInvokeEvent, helpers?: IpcStageHelpers<I>) => Promise<O>;
   /** Main-owned adapters preserve domain error envelopes without granting caller authority. */
diff --git a/desktop/electron/ipc.ts b/desktop/electron/ipc.ts
index fe4c2e7d..7467ae7e 100644
--- a/desktop/electron/ipc.ts
+++ b/desktop/electron/ipc.ts
@@ -1,3 +1,8 @@
+import { registerComputerUseCapabilityReadonlyIpc } from './runtime-status-readonly-typed-ipc.js';
+import { registerSkillMutationIpc } from './skill-mutation-typed-ipc.js';
+import { registerChannelMcpMutationIpc } from './channel-mcp-mutation-typed-ipc.js';
+import { createMeetingMutationService } from './meeting-mutation-service.js';
+import { registerMeetingMutationIpc } from './meeting-mutation-typed-ipc.js';
 import { registerMeetingReadonlyIpc } from './meeting-readonly-typed-ipc.js';
 import { readMeetingAsrReadonly } from './meeting-readonly-data.js';
 import { registerChannelMcpReadonlyIpc } from './channel-mcp-readonly-typed-ipc.js';
@@ -1293,37 +1298,27 @@ export async function registerDesktopIpc(
     ['desktop:listSkills', () => captureSkillListServiceResult(services.listSkills(), count => log('info', 'listSkills', { count }))],
   ]);
   registerSkillListIpc(ipcMain, skillListProducers);
-  ipcMain.handle('desktop:installSkill', async (_event, skillName) => {
-    log('info', 'installSkill', { skillName });
-    const r = await services.installSkill(skillName);
-    log('info', 'installSkill result', { success: r.success });
-    return r;
-  });
-  ipcMain.handle('desktop:uninstallSkill', async (_event, skillName) => {
-    log('info', 'uninstallSkill', { skillName });
-    const r = await services.uninstallSkill(skillName);
-    log('info', 'uninstallSkill result', { success: r.success });
-    return r;
-  });
+  const skillMutationProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:installSkill', (_event, skillName) => services.installSkill(skillName, { requestSource: 'user' })],
+    ['desktop:uninstallSkill', (_event, skillName) => services.uninstallSkill(skillName, { requestSource: 'user' })],
+  ]);
+  registerSkillMutationIpc(ipcMain, skillMutationProducers);
   // Channel IPC
   const channelMcpReadonlyProducers = new Map<string, IpcHandlerListener>([
     ['desktop:listChannels', () => services.listChannels()],
     ['desktop:listMCPInstalls', () => services.listMCPInstalls()],
   ]);
   registerChannelMcpReadonlyIpc(ipcMain, channelMcpReadonlyProducers);
-  ipcMain.handle('desktop:testChannel', async (_event, channelId) => {
-    log('info', 'testChannel', { channelId });
-    const r = await services.testChannel(channelId);
-    log('info', 'testChannel result', { success: r.success });
-    return r;
-  });
-  ipcMain.handle('desktop:createChannel', async (_event, input) => services.createChannel(input));
-  ipcMain.handle('desktop:updateChannel', async (_event, id, input) => services.updateChannel(id, input));
-  ipcMain.handle('desktop:deleteChannel', async (_event, id) => services.deleteChannel(id));
-  // MCP IPC
-  ipcMain.handle('desktop:createMCPInstall', async (_event, input) => services.createMCPInstall(input));
-  ipcMain.handle('desktop:updateMCPInstall', async (_event, id, input) => services.updateMCPInstall(id, input));
-  ipcMain.handle('desktop:deleteMCPInstall', async (_event, id) => services.deleteMCPInstall(id));
+  const channelMcpMutationProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:testChannel', (_event, id) => services.testChannel(id, 'user')],
+    ['desktop:createChannel', (_event, input) => services.createChannel(input, 'user')],
+    ['desktop:updateChannel', (_event, id, input) => services.updateChannel(id, input, 'user')],
+    ['desktop:deleteChannel', (_event, id) => services.deleteChannel(id, 'user')],
+    ['desktop:createMCPInstall', (_event, input) => services.createMCPInstall(input, 'user')],
+    ['desktop:updateMCPInstall', (_event, id, input) => services.updateMCPInstall(id, input, 'user')],
+    ['desktop:deleteMCPInstall', (_event, id) => services.deleteMCPInstall(id, 'user')],
+  ]);
+  registerChannelMcpMutationIpc(ipcMain, channelMcpMutationProducers);
   // Plugin MCP servers
   registerPluginCatalogIpc(ipcMain, services);
   // Design v58 §7.2: `setPluginMcpServerEnabled` only mutated a view model and
@@ -1333,7 +1328,7 @@ export async function registerDesktopIpc(
     componentId: String((input as { componentId?: unknown })?.componentId ?? ''),
     requestSource: 'user',
   }));
-  ipcMain.handle('desktop:getComputerUseCapabilityStatus', () => services.getComputerUseCapabilityStatus());
+  registerComputerUseCapabilityReadonlyIpc(ipcMain, () => services.getComputerUseCapabilityStatus());
   ipcMain.handle('desktop:enableComputerUse', () => services.enableComputerUse({ requestSource: 'user' }));
   ipcMain.handle('desktop:reconnectComputerUse', () => services.reconnectComputerUse({ requestSource: 'user' }));
   ipcMain.handle('desktop:disableComputerUse', () => services.disableComputerUse({ requestSource: 'user' }));
@@ -1814,17 +1809,14 @@ export async function registerDesktopIpc(
     return result.filePaths[0] ?? null;
   });
 
-  ipcMain.handle('desktop:meeting:requestMicrophonePermission', async () => (
-    meetingAudioPermissionService.requestPermission()
-  ));
-
-  ipcMain.handle('desktop:meeting:saveAsrConfig', async (_event, input) => {
-    const { loadConfig, saveConfig } = await import('../../src/utils/config.js');
-    const { applyMeetingAsrConfigUpdate, createMeetingAsrConfigSnapshot } = await import('./meeting-asr-config.js');
-    const config = applyMeetingAsrConfigUpdate(await loadConfig(), input ?? {});
-    await saveConfig(config);
-    return createMeetingAsrConfigSnapshot(config);
-  });
+  const meetingMutations = createMeetingMutationService(meetingAudioPermissionService);
+  const meetingMutationProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:meeting:requestMicrophonePermission', () => meetingMutations.requestMicrophonePermission('user')],
+    ['desktop:meeting:saveAsrConfig', (_event, input) => meetingMutations.saveAsrConfig(input, 'user')],
+    ['desktop:meeting:downloadModel', (_event, id) => meetingMutations.downloadModel(id, 'user')],
+    ['desktop:meeting:uninstallModel', (_event, id) => meetingMutations.uninstallModel(id, 'user')],
+  ]);
+  registerMeetingMutationIpc(ipcMain, meetingMutationProducers);
 
   const meetingReadonlyProducers = new Map<string, IpcHandlerListener>([
     ['desktop:meeting:getMicrophonePermission', () => meetingAudioPermissionService.getStatus()],
@@ -1833,16 +1825,6 @@ export async function registerDesktopIpc(
   ]);
   registerMeetingReadonlyIpc(ipcMain, meetingReadonlyProducers);
 
-  ipcMain.handle('desktop:meeting:downloadModel', async (_event, modelId: string) => {
-    const { createMeetingModelService } = await import('./meeting-model-service.js');
-    return createMeetingModelService().downloadModel(String(modelId ?? ''));
-  });
-
-  ipcMain.handle('desktop:meeting:uninstallModel', async (_event, modelId: string) => {
-    const { createMeetingModelService } = await import('./meeting-model-service.js');
-    return createMeetingModelService().uninstallModel(String(modelId ?? ''));
-  });
-
   ipcMain.handle('desktop:meeting:saveRecordedAudio', async (_event, input) => {
     const wavBase64 = typeof input?.wavBase64 === 'string' ? input.wavBase64 : '';
     if (!wavBase64) return { ok: false, error: 'missing_audio' };
diff --git a/desktop/electron/main.ts b/desktop/electron/main.ts
index f62693fa..c395ace5 100644
--- a/desktop/electron/main.ts
+++ b/desktop/electron/main.ts
@@ -1,3 +1,4 @@
+import { registerKswarmStatusReadonlyIpc } from './runtime-status-readonly-typed-ipc.js';
 import { createAutomationConfigOwner } from './automation-config-owner.js';
 import { registerAutomationConfigIpc } from './automation-config-typed-ipc.js';
 import { createMobileRelaySignInOwner } from './mobile-relay-signin.js';
@@ -659,7 +660,7 @@ async function createInitialWindowResources(): Promise<BrowserWindow> {
   const kswarmService = createDesktopKSwarmService(desktopShutdownCoordinator, desktopFinalLifetimeSteps, { activityOwnerPending: process.env.XIAOK_CONVERSATION_ACTIVITY !== '0' });
   if (!kswarmService) return window;
   let kswarmStartPromise: Promise<void>;
-  shutdownAwareIpc.handle('desktop:kswarm:getStatus', () => kswarmService.getStatus());
+  registerKswarmStatusReadonlyIpc(shutdownAwareIpc, () => kswarmService.getStatus());
   shutdownAwareIpc.handle('desktop:kswarm:start', () => kswarmService.start());
   shutdownAwareIpc.handle('desktop:kswarm:stop', () => kswarmService.stop());
   shutdownAwareIpc.handle('desktop:kswarm:restart', () => kswarmService.restart());
diff --git a/desktop/electron/meeting-model-service.ts b/desktop/electron/meeting-model-service.ts
index 2a95dbbf..4d2bd919 100644
--- a/desktop/electron/meeting-model-service.ts
+++ b/desktop/electron/meeting-model-service.ts
@@ -5,7 +5,7 @@ import type { ClientRequest, IncomingMessage } from 'node:http';
 import { get as httpGet } from 'node:http';
 import { get as httpsGet } from 'node:https';
 import { homedir } from 'node:os';
-import { dirname, join } from 'node:path';
+import { dirname, join, resolve } from 'node:path';
 import { promisify, types as nodeTypes } from 'node:util';
 
 export type MeetingModelCheckReason = 'ready' | 'missing' | 'size_mismatch' | 'hash_mismatch';
@@ -191,6 +191,14 @@ function truthfulModelPathExists(path: string): boolean {
   catch(error) { if(error && typeof error==='object' && !nodeTypes.isProxy(error) && Object.getOwnPropertyDescriptor(error,'code')?.value==='ENOENT')return false;throw error; }
 }
 
+// One cache/model download lease shared by every factory instance in this process.
+// Does not claim a transcriber lease or cancellation protocol.
+const activeMeetingModelDownloads = new Set<string>();
+function meetingModelLeaseKey(cacheDir: string, model: MeetingModelDefinition): string {
+  const path = resolve(cacheDir, model.fileName);
+  return process.platform === 'win32' ? path.toLowerCase() : path;
+}
+
 export function createMeetingModelService(options: MeetingModelServiceOptions = {}): MeetingModelService {
   const env = options.env ?? process.env;
   const cacheDir = options.cacheDir ?? resolveMeetingWhisperCacheDir(env);
@@ -269,8 +277,12 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
     },
     async downloadModel(modelId) {
       const model = findModel(modelId);
+      const lease = meetingModelLeaseKey(cacheDir, model);
+      if (activeMeetingModelDownloads.has(lease)) throw Error('meeting_model_busy');
+      activeMeetingModelDownloads.add(lease);
+      try {
       if ((model.packageType ?? 'single-file') === 'directory') {
-        return downloadDirectoryModelPackage(model, cacheDir, downloadFile, extractArchive, getModelInfo);
+        return await downloadDirectoryModelPackage(model, cacheDir, downloadFile, extractArchive, getModelInfo);
       }
       mkdirSync(cacheDir, { recursive: true });
       const modelPath = join(cacheDir, model.fileName);
@@ -293,9 +305,11 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
         throw new Error(check.reason);
       }
       return { ok: true, model: getModelInfo(model) };
+      } finally { activeMeetingModelDownloads.delete(lease); }
     },
     uninstallModel(modelId) {
       const model = findModel(modelId);
+      if (activeMeetingModelDownloads.has(meetingModelLeaseKey(cacheDir, model))) throw Error('meeting_model_busy');
       const isDirectoryPackage = (model.packageType ?? 'single-file') === 'directory';
       rmSync(join(cacheDir, model.fileName), { recursive: isDirectoryPackage, force: true });
       if (isDirectoryPackage) {
diff --git a/desktop/electron/meeting-readonly-data.ts b/desktop/electron/meeting-readonly-data.ts
index 36eb9418..f4d10858 100644
--- a/desktop/electron/meeting-readonly-data.ts
+++ b/desktop/electron/meeting-readonly-data.ts
@@ -18,7 +18,7 @@ const storedMeeting = z.object({ asr: z.object({
   volcengine: provider.optional(), aliyun: provider.optional(),
 }).passthrough().optional() }).passthrough();
 
-export function readMeetingAsrReadonly() {
+export function readMeetingAsrConfig(): Config {
   let raw: string | undefined;
   try { raw = readFileSync(getConfigPath(), 'utf8'); }
   catch (error) {
@@ -39,6 +39,11 @@ export function readMeetingAsrReadonly() {
     if (obj.meeting !== undefined && !storedMeeting.safeParse(obj.meeting).success) throw Error('meeting_readonly_projection_unavailable');
     config = normalizeConfig(obj as unknown as Config | LegacyConfig);
   }
+  return config;
+}
+
+export function readMeetingAsrReadonly() {
+  const config = readMeetingAsrConfig();
   const dto = captureIpcData(createMeetingAsrConfigSnapshot(config), 'meeting_readonly_projection_unavailable');
   const parsed = MEETING_ASR_OUTPUT_SCHEMA.safeParse(dto);
   if (!parsed.success) throw Error('meeting_readonly_projection_unavailable');
diff --git a/desktop/electron/preload-api.ts b/desktop/electron/preload-api.ts
index d1292e8a..ba04c41c 100644
--- a/desktop/electron/preload-api.ts
+++ b/desktop/electron/preload-api.ts
@@ -1,3 +1,5 @@
+import type { ComputerUseReadonlyStatus, KswarmReadonlyStatus } from '../shared/runtime-status-readonly-ipc-contract.js';
+import type { MeetingMutationModelResult } from '../shared/meeting-mutation-ipc-contract.js';
 import type { MeetingReadonlyPermission, MeetingReadonlyAsr, MeetingReadonlyModels } from '../shared/meeting-readonly-ipc-contract.js';
 import type { ChannelReadonlyView, McpInstallReadonlyView } from '../shared/channel-mcp-readonly-ipc-contract.js';
 import type { SkillListDto } from '../shared/skill-list-ipc-contract.js';
@@ -858,6 +860,11 @@ export interface DesktopChannelInput {
   type: DesktopChannelType;
   name: string;
   webhookUrl?: string;
+  appId?: string;
+  appSecret?: string;
+  token?: string;
+  botToken?: string;
+  chatId?: string;
 }
 
 export type DesktopMCPInstallView = McpInstallReadonlyView;
@@ -922,6 +929,9 @@ export interface KSwarmServiceStatus {
   pid: number | null;
   restartCount: number;
   lastError: string | null;
+  terminalDegraded?: boolean;
+  persistenceFailStopCount?: number;
+  lastPersistenceFailStop?: string | null;
 }
 
 export type DesktopRelatedServiceId = RelatedServiceIdDto;
@@ -1260,16 +1270,16 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   listChannels(): Promise<DesktopChannelView[]>;
   testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }>;
   createChannel(input: DesktopChannelInput): Promise<DesktopChannelView>;
-  updateChannel(id: string, input: Partial<DesktopChannelInput>): Promise<DesktopChannelView>;
+  updateChannel(id: string, input: Partial<DesktopChannelInput> & { enabled?: boolean }): Promise<DesktopChannelView>;
   deleteChannel(id: string): Promise<void>;
   listMCPInstalls(): Promise<DesktopMCPInstallView[]>;
   createMCPInstall(input: DesktopMCPInput): Promise<DesktopMCPInstallView>;
-  updateMCPInstall(id: string, input: Partial<DesktopMCPInput>): Promise<DesktopMCPInstallView>;
+  updateMCPInstall(id: string, input: Partial<DesktopMCPInput> & { enabled?: boolean }): Promise<DesktopMCPInstallView>;
   deleteMCPInstall(id: string): Promise<void>;
   listPluginMcpServers(): Promise<PluginMcpServerView[]>;
   /** Design v58 §7.2: component-scoped retry; never writes persisted desired state. */
   retryPluginComponent(input: { componentId: string }): Promise<PluginMcpServerView[]>;
-  getComputerUseCapabilityStatus(): Promise<ComputerUseCapabilityStatusView>;
+  getComputerUseCapabilityStatus(): Promise<ComputerUseReadonlyStatus>;
   enableComputerUse(): Promise<ComputerUseCapabilityStatusView>;
   reconnectComputerUse(): Promise<ComputerUseCapabilityStatusView>;
   disableComputerUse(): Promise<ComputerUseCapabilityStatusView>;
@@ -1298,7 +1308,7 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   getSkillStats(): Promise<DesktopSkillStats[]>;
   getServiceStatus(): Promise<DesktopServiceStatusSnapshot>;
   restartRelatedService(serviceId: DesktopRelatedServiceId): Promise<void>;
-  kswarmGetStatus(): Promise<KSwarmServiceStatus>;
+  kswarmGetStatus(): Promise<KswarmReadonlyStatus>;
   kswarmStart(): Promise<void>;
   kswarmStop(): Promise<void>;
   kswarmRestart(): Promise<void>;
@@ -1397,12 +1407,12 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   kbPickFiles(): Promise<string[]>;
   meetingPickAudioFile(): Promise<string | null>;
   meetingGetMicrophonePermission(): Promise<MeetingReadonlyPermission>;
-  meetingRequestMicrophonePermission(): Promise<unknown>;
+  meetingRequestMicrophonePermission(): Promise<import('../shared/meeting-readonly-ipc-contract.js').MeetingReadonlyPermission>;
   meetingGetAsrConfig(): Promise<MeetingReadonlyAsr>;
   meetingSaveAsrConfig(input: MeetingSaveAsrConfigInput): Promise<MeetingAsrConfigSnapshot>;
   meetingListModels(): Promise<MeetingReadonlyModels>;
-  meetingDownloadModel(modelId: string): Promise<unknown>;
-  meetingUninstallModel(modelId: string): Promise<unknown>;
+  meetingDownloadModel(modelId: string): Promise<MeetingMutationModelResult>;
+  meetingUninstallModel(modelId: string): Promise<MeetingMutationModelResult>;
   meetingSaveRecordedAudio(input: unknown): Promise<unknown>;
   meetingTranscribePreview(input: unknown): Promise<unknown>;
   meetingStartLiveTranscription(input: { engine: 'aliyun-asr' | 'volcengine-asr'; sampleRate: number; language?: string }): Promise<{ ok: boolean; sessionId?: string; error?: string }>;
@@ -1745,7 +1755,7 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     deleteMCPInstall: (id) => ipcRenderer.invoke('desktop:deleteMCPInstall', id) as Promise<void>,
     listPluginMcpServers: () => ipcRenderer.invoke('desktop:listPluginMcpServers') as Promise<PluginMcpServerView[]>,
     retryPluginComponent: (input) => ipcRenderer.invoke('desktop:retryPluginComponent', input) as Promise<PluginMcpServerView[]>,
-    getComputerUseCapabilityStatus: () => ipcRenderer.invoke('desktop:getComputerUseCapabilityStatus') as Promise<ComputerUseCapabilityStatusView>,
+    getComputerUseCapabilityStatus: () => ipcRenderer.invoke('desktop:getComputerUseCapabilityStatus') as Promise<ComputerUseReadonlyStatus>,
     enableComputerUse: () => ipcRenderer.invoke('desktop:enableComputerUse') as Promise<ComputerUseCapabilityStatusView>,
     reconnectComputerUse: () => ipcRenderer.invoke('desktop:reconnectComputerUse') as Promise<ComputerUseCapabilityStatusView>,
     disableComputerUse: () => ipcRenderer.invoke('desktop:disableComputerUse') as Promise<ComputerUseCapabilityStatusView>,
@@ -1801,7 +1811,7 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     getSkillStats: () => ipcRenderer.invoke('desktop:getSkillStats') as ReturnType<DesktopApi['getSkillStats']>,
     getServiceStatus: () => ipcRenderer.invoke('desktop:services:getStatus') as Promise<DesktopServiceStatusSnapshot>,
     restartRelatedService: (serviceId) => ipcRenderer.invoke('desktop:services:restart', serviceId) as Promise<void>,
-    kswarmGetStatus: () => ipcRenderer.invoke('desktop:kswarm:getStatus') as Promise<KSwarmServiceStatus>,
+    kswarmGetStatus: () => ipcRenderer.invoke('desktop:kswarm:getStatus') as Promise<KswarmReadonlyStatus>,
     kswarmStart: () => ipcRenderer.invoke('desktop:kswarm:start') as Promise<void>,
     kswarmStop: () => ipcRenderer.invoke('desktop:kswarm:stop') as Promise<void>,
     kswarmRestart: () => ipcRenderer.invoke('desktop:kswarm:restart') as Promise<void>,
@@ -1961,12 +1971,12 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     kbPickFiles: () => ipcRenderer.invoke('desktop:kb:pickFiles') as Promise<string[]>,
     meetingPickAudioFile: () => ipcRenderer.invoke('desktop:meeting:pickAudioFile') as Promise<string | null>,
     meetingGetMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:getMicrophonePermission') as Promise<MeetingReadonlyPermission>,
-    meetingRequestMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:requestMicrophonePermission') as Promise<unknown>,
+    meetingRequestMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:requestMicrophonePermission') as Promise<import('../shared/meeting-readonly-ipc-contract.js').MeetingReadonlyPermission>,
     meetingGetAsrConfig: () => ipcRenderer.invoke('desktop:meeting:getAsrConfig') as Promise<MeetingReadonlyAsr>,
     meetingSaveAsrConfig: (input) => ipcRenderer.invoke('desktop:meeting:saveAsrConfig', input) as Promise<MeetingAsrConfigSnapshot>,
     meetingListModels: () => ipcRenderer.invoke('desktop:meeting:listModels') as Promise<MeetingReadonlyModels>,
-    meetingDownloadModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:downloadModel', modelId) as Promise<unknown>,
-    meetingUninstallModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:uninstallModel', modelId) as Promise<unknown>,
+    meetingDownloadModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:downloadModel', modelId) as Promise<MeetingMutationModelResult>,
+    meetingUninstallModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:uninstallModel', modelId) as Promise<MeetingMutationModelResult>,
     meetingSaveRecordedAudio: (input) => ipcRenderer.invoke('desktop:meeting:saveRecordedAudio', input) as Promise<unknown>,
     meetingTranscribePreview: (input) => ipcRenderer.invoke('desktop:meeting:transcribePreview', input) as Promise<unknown>,
     meetingStartLiveTranscription: (input) => ipcRenderer.invoke('desktop:meeting:live:start', input) as ReturnType<DesktopApi['meetingStartLiveTranscription']>,
diff --git a/desktop/renderer/src/api/bridge.ts b/desktop/renderer/src/api/bridge.ts
index 5a14d183..cc6e51e4 100644
--- a/desktop/renderer/src/api/bridge.ts
+++ b/desktop/renderer/src/api/bridge.ts
@@ -758,10 +758,10 @@ export const api = {
   async listChannels() {
     return window.xiaokDesktop.listChannels();
   },
-  async createChannel(input: { type: string; name: string; webhookUrl?: string }) {
+  async createChannel(input: { type: string; name: string; webhookUrl?: string; appId?: string; appSecret?: string; token?: string; botToken?: string; chatId?: string }) {
     return window.xiaokDesktop.createChannel(input as never);
   },
-  async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean }) {
+  async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean; appId?: string; appSecret?: string; token?: string; botToken?: string; chatId?: string }) {
     return window.xiaokDesktop.updateChannel(id, input as never);
   },
   async deleteChannel(id: string) {
@@ -769,7 +769,7 @@ export const api = {
   },
   async testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }> {
     if (!window.xiaokDesktop?.testChannel) {
-      return { success: false, error: 'testChannel API not available' };
+      throw Error('channel_mcp_mutation_runtime_unavailable');
     }
     return await window.xiaokDesktop.testChannel(channelId);
   },
@@ -843,7 +843,7 @@ export const api = {
   async createMCPInstall(input: { name: string; source: string; command: string; args?: string[] }) {
     return window.xiaokDesktop.createMCPInstall(input as never);
   },
-  async updateMCPInstall(id: string, input: { name?: string; source?: string; command?: string; enabled?: boolean }) {
+  async updateMCPInstall(id: string, input: { name?: string; source?: string; command?: string; args?: string[]; enabled?: boolean }) {
     return window.xiaokDesktop.updateMCPInstall(id, input as never);
   },
   async deleteMCPInstall(id: string) {
@@ -1402,7 +1402,9 @@ export async function searchMarketSkills(_accessToken: string, _query: string, _
 }
 
 export async function installSkill(_accessToken: string, ref: SkillReference): Promise<{ success: boolean; message: string }> {
-  return api.installSkill(ref.skill_key);
+  const result = await api.installSkill(ref.skill_key);
+  if (!result.success) throw new Error(result.message);
+  return result;
 }
 
 export async function deleteSkill(_accessToken: string, ref: SkillReference): Promise<void> {
diff --git a/desktop/renderer/src/components/DesktopSettings.tsx b/desktop/renderer/src/components/DesktopSettings.tsx
index 8af02990..a09abcb5 100644
--- a/desktop/renderer/src/components/DesktopSettings.tsx
+++ b/desktop/renderer/src/components/DesktopSettings.tsx
@@ -367,6 +367,15 @@ function VoicePane() {
   const [modelStatusesError, setModelStatusesError] = useState('');
   const [modelAction, setModelAction] = useState<MeetingModelActionState | null>(null);
 
+  // One mounted action owner. Locale changes reproject reasons at render time;
+  // they do not cancel an already authorized main-process mutation.
+  const actionLifetime = useRef<{ active: boolean; saving: boolean; model: boolean } | null>(null);
+  useEffect(() => {
+    const owner = { active: true, saving: false, model: false };
+    actionLifetime.current = owner;
+    return () => { owner.active = false; };
+  }, []);
+
   const engineLabels: Record<MeetingTranscriberEngine, string> = {
     'sherpa-onnx-paraformer': t.knowledge.meetingSpeechEngineSherpaOnnxParaformer,
     whisper: t.knowledge.meetingSpeechEngineWhisperFallback,
@@ -452,7 +461,10 @@ function VoicePane() {
   };
 
   const handleSaveMeetingAsrConfig = async () => {
-    if (!desktop?.meetingSaveAsrConfig || saving) return;
+    const owner = actionLifetime.current;
+    if (!desktop?.meetingSaveAsrConfig || !owner?.active || owner.saving) return;
+    owner.saving = true;
+    const current = () => owner.active && actionLifetime.current === owner;
     setSaving(true);
     setSaved(false);
     setSaveError('');
@@ -479,7 +491,11 @@ function VoicePane() {
         : { defaultProvider: engine };
     try {
       const snapshot = await desktop.meetingSaveAsrConfig(input) as MeetingAsrConfigSnapshot;
+      if (!current()) return;
+      // A read failure remains a read failure. It cannot change this confirmed
+      // save into a failure or replace the readonly owner's last-good facts.
       await asrFacts.reload().catch(() => {});
+      if (!current()) return;
       setAsrDraft(prev => ({
         ...prev,
         volcAppKey: '',
@@ -491,43 +507,52 @@ function VoicePane() {
       }));
       setSaved(true);
     } catch (error) {
-      setSaveError(t.knowledge.meetingOnlineAsrSaveFailed(error instanceof Error ? error.message : 'unknown'));
+      if (current()) setSaveError(error instanceof Error ? error.message : 'unknown');
     } finally {
-      setSaving(false);
+      owner.saving = false;
+      if (current()) setSaving(false);
     }
   };
 
   const handleDownloadMeetingModel = async (modelId: string) => {
-    if (!desktop?.meetingDownloadModel || modelAction) return;
+    const owner = actionLifetime.current;
+    if (!desktop?.meetingDownloadModel || !owner?.active || owner.model) return;
+    owner.model = true;
+    const current = () => owner.active && actionLifetime.current === owner;
     setModelAction({ modelId, kind: 'download' });
     setModelStatusesError('');
     try {
       const result = await desktop.meetingDownloadModel(modelId) as { ok?: boolean; reason?: string; error?: string };
+      if (!current()) return;
+      if (result?.ok === false) setModelStatusesError(result.reason ?? result.error ?? 'unknown');
       await loadMeetingModelStatuses();
-      if (result?.ok === false) {
-        setModelStatusesError(t.knowledge.meetingModelActionFailed(result.reason ?? result.error ?? 'unknown'));
-      }
-      setModelAction(null);
+      if (!current()) return;
     } catch (error) {
-      setModelStatusesError(t.knowledge.meetingModelActionFailed(error instanceof Error ? error.message : 'unknown'));
-      setModelAction(null);
+      if (current()) setModelStatusesError(error instanceof Error ? error.message : 'unknown');
+    } finally {
+      owner.model = false;
+      if (current()) setModelAction(null);
     }
   };
 
   const handleUninstallMeetingModel = async (modelId: string) => {
-    if (!desktop?.meetingUninstallModel || modelAction) return;
+    const owner = actionLifetime.current;
+    if (!desktop?.meetingUninstallModel || !owner?.active || owner.model) return;
+    owner.model = true;
+    const current = () => owner.active && actionLifetime.current === owner;
     setModelAction({ modelId, kind: 'uninstall' });
     setModelStatusesError('');
     try {
       const result = await desktop.meetingUninstallModel(modelId) as { ok?: boolean; reason?: string; error?: string };
+      if (!current()) return;
+      if (result?.ok === false) setModelStatusesError(result.reason ?? result.error ?? 'unknown');
       await loadMeetingModelStatuses();
-      if (result?.ok === false) {
-        setModelStatusesError(t.knowledge.meetingModelActionFailed(result.reason ?? result.error ?? 'unknown'));
-      }
-      setModelAction(null);
+      if (!current()) return;
     } catch (error) {
-      setModelStatusesError(t.knowledge.meetingModelActionFailed(error instanceof Error ? error.message : 'unknown'));
-      setModelAction(null);
+      if (current()) setModelStatusesError(error instanceof Error ? error.message : 'unknown');
+    } finally {
+      owner.model = false;
+      if (current()) setModelAction(null);
     }
   };
 
@@ -682,7 +707,7 @@ function VoicePane() {
             <p className="text-sm text-[var(--c-text-secondary)]">{t.knowledge.meetingModelDownloadStatusTitle}</p>
             {modelStatusesLoading && <span className="text-xs text-[var(--c-text-tertiary)]">{t.knowledge.meetingModelStatusLoading}</span>}
           </div>
-          {modelStatusesError && <p className="text-xs leading-5 text-red-600">{modelStatusesError}</p>}
+          {modelStatusesError && <p className="text-xs leading-5 text-red-600">{t.knowledge.meetingModelActionFailed(modelStatusesError)}</p>}
           {groupedModelStatuses.length > 0 ? (
             <div className="space-y-4">
               {groupedModelStatuses.map(group => (
@@ -784,7 +809,7 @@ function VoicePane() {
           <div className="mt-4 flex items-center justify-between gap-3">
             <div className="min-w-0">
               {saved && <p className="text-xs text-green-700">{ds.meetingAsrSaved}</p>}
-              {saveError && <p className="text-xs text-red-600">{saveError}</p>}
+              {saveError && <p className="text-xs text-red-600">{t.knowledge.meetingOnlineAsrSaveFailed(saveError)}</p>}
             </div>
             <button type="button" onClick={() => void handleSaveMeetingAsrConfig()} disabled={saving} className={btnPrimary}>
               {saving ? ds.meetingAsrSaving : ds.meetingAsrSave}
@@ -2086,63 +2111,110 @@ function ChannelsPane() {
   const [newType, setNewType] = useState('yunzhijia');
   const [newName, setNewName] = useState('');
   const [newFields, setNewFields] = useState<Record<string, string>>({});
-  const [testingChannel, setTestingChannel] = useState<string | null>(null);
   const [error, setError] = useState('');
   const [success, setSuccess] = useState('');
 
-  const { t } = useLocale();
+  const { t, locale } = useLocale();
   const ts = t.desktopSettings;
   const channelTypeConfig = getChannelTypeConfig(ts);
 
   const load = channelFacts.refresh;
 
+  type ActionOwner = { active: boolean; epoch: number; pending: Map<string, symbol> };
+  type ActionLease = { owner: ActionOwner; epoch: number; token: symbol; keys: string[] };
+  const actionOwner = useRef<ActionOwner>({ active: false, epoch: 0, pending: new Map() });
+  const [pendingActions, setPendingActions] = useState<ReadonlySet<string>>(() => new Set());
+  const testRevision = useRef(0);
+  useEffect(() => {
+    const owner = actionOwner.current;
+    owner.active = true; owner.epoch += 1;
+    setPendingActions(new Set(owner.pending.keys()));
+    setError(''); setSuccess('');
+    return () => {
+      owner.active = false; owner.epoch += 1;
+      testRevision.current += 1;
+      // Pending effects remain locked across locale changes until their real settlement.
+    };
+  }, [locale]);
+  const beginAction = (keys: string[]): ActionLease | null => {
+    const owner = actionOwner.current;
+    if (!owner.active || keys.some(key => owner.pending.has(key))) return null;
+    const token = Symbol();
+    for (const key of keys) owner.pending.set(key, token);
+    setPendingActions(new Set(owner.pending.keys()));
+    return { owner, epoch: owner.epoch, token, keys };
+  };
+  const isCurrentAction = (lease: ActionLease) => actionOwner.current === lease.owner
+    && lease.owner.active && lease.owner.epoch === lease.epoch;
+  const finishAction = (lease: ActionLease) => {
+    for (const key of lease.keys) if (lease.owner.pending.get(key) === lease.token) lease.owner.pending.delete(key);
+    // An old locale may release only its own settled locks; it cannot publish an action fact.
+    if (actionOwner.current === lease.owner && lease.owner.active) setPendingActions(new Set(lease.owner.pending.keys()));
+  };
+
   // Reset fields when type changes
   useEffect(() => {
     setNewFields({});
   }, [newType]);
 
   const handleCreate = async () => {
-    if (!newName.trim()) return;
+    if (!actionOwner.current.active || actionOwner.current.pending.has('create') || !newName.trim()) return;
     const typeConfig = channelTypeConfig[newType];
-    // Check required fields
     for (const field of typeConfig.fields) {
       if (field.required && !newFields[field.key]?.trim()) {
         alert(ts.channelsFieldRequired(field.label));
         return;
       }
     }
+    const lease = beginAction(['create', 'row:' + newType]);
+    if (!lease) return;
     try {
-      await api.createChannel({
-        type: newType,
-        name: newName.trim(),
-        ...newFields,
-      });
-      setNewName('');
-      setNewFields({});
-      setShowAdd(false);
+      await api.createChannel({ type: newType, name: newName.trim(), ...newFields });
+      if (!isCurrentAction(lease)) return;
+      setNewName(''); setNewFields({}); setShowAdd(false);
       load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+    } catch {
+      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleDelete = async (id: string) => {
+    if (!actionOwner.current.active || actionOwner.current.pending.has('row:' + id)) return;
     if (!confirm(ts.channelsDeleteConfirm)) return;
+    const lease = beginAction(['row:' + id]);
+    if (!lease) return;
     try {
       await api.deleteChannel(id);
-      load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+      if (isCurrentAction(lease)) load();
+    } catch {
+      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleToggle = async (channel: ChannelConfig) => {
+    const lease = beginAction(['row:' + channel.id]);
+    if (!lease) return;
     try {
       await api.updateChannel(channel.id, { enabled: !channel.enabled });
-      load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+      if (isCurrentAction(lease)) load();
+    } catch {
+      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
+    } finally { finishAction(lease); }
+  };
+
+  const handleTest = async (id: string) => {
+    const lease = beginAction(['test:' + id]);
+    if (!lease) return;
+    const revision = ++testRevision.current;
+    setError(''); setSuccess('');
+    try {
+      const result = await api.testChannel(id);
+      if (!isCurrentAction(lease) || revision !== testRevision.current) return;
+      if (result.success) setSuccess(ts.channelsTestSuccess(result.latencyMs ?? 0));
+      else setError(result.error?.startsWith('channel_mcp_mutation_') ? ts.channelsTestFailed : result.error || ts.channelsTestFailed);
+    } catch {
+      if (isCurrentAction(lease) && revision === testRevision.current) setError(ts.channelsTestFailed);
+    } finally { finishAction(lease); }
   };
 
   if (loading) {
@@ -2236,7 +2308,7 @@ function ChannelsPane() {
                 </div>
               ))}
               <div className="flex gap-2">
-                <button type="button" onClick={handleCreate} className={btnPrimary}>{ts.channelsCreateBtn}</button>
+                <button type="button" onClick={handleCreate} disabled={pendingActions.has('create')} className={btnPrimary}>{ts.channelsCreateBtn}</button>
                 <button type="button" onClick={() => setShowAdd(false)} className={btnSecondary}>{ts.channelsCancelBtn}</button>
               </div>
             </div>
@@ -2267,28 +2339,15 @@ function ChannelsPane() {
                   </div>
                   <div className="flex items-center gap-2 flex-wrap">
                     <button type="button"
-                      onClick={async () => {
-                        setTestingChannel(ch.id);
-                        try {
-                          const result = await api.testChannel(ch.id);
-                          if (result.success) {
-                            setSuccess(ts.channelsTestSuccess(result.latencyMs ?? 0));
-                          } else {
-                            setError(result.error || ts.channelsTestFailed);
-                          }
-                        } catch (e) {
-                          setError((e as Error).message);
-                        } finally {
-                          setTestingChannel(null);
-                        }
-                      }}
-                      disabled={testingChannel === ch.id}
+                      onClick={() => void handleTest(ch.id)}
+                      disabled={pendingActions.has('test:' + ch.id)}
                       className="inline-flex shrink-0 items-center gap-1 rounded-md border border-[var(--c-border)] px-2.5 py-1 text-xs text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)] transition-colors disabled:opacity-50"
                     >
-                      {testingChannel === ch.id ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
+                      {pendingActions.has('test:' + ch.id) ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                       {ts.channelsTestBtn}
                     </button>
                     <button type="button"
+                      disabled={pendingActions.has('row:' + ch.id)}
                       onClick={() => handleToggle(ch)}
                       className={`rounded-lg px-3 py-1.5 text-xs transition-colors ${
                         ch.enabled ? 'bg-green-50 text-green-600' : 'bg-[var(--c-bg-deep)] text-[var(--c-text-secondary)]'
@@ -2297,6 +2356,8 @@ function ChannelsPane() {
                       {ch.enabled ? ts.channelsEnabled : ts.channelsDisabled}
                     </button>
                     <button type="button"
+                      aria-label={ts.channelsDeleteConfirm}
+                      disabled={pendingActions.has('row:' + ch.id)}
                       onClick={() => handleDelete(ch.id)}
                       className="rounded-lg p-1.5 text-[var(--c-text-tertiary)] hover:text-red-500 transition-colors"
                     >
@@ -2342,6 +2403,35 @@ function McpPane() {
 
   const [installsReady, setInstallsReady] = useState(false), [installsUnavailable, setInstallsUnavailable] = useState(false);
   const [catalogUnavailable, setCatalogUnavailable] = useState(false);
+  type ActionOwner = { active: boolean; epoch: number; pending: Map<string, symbol> };
+  type ActionLease = { owner: ActionOwner; epoch: number; token: symbol; keys: string[] };
+  const actionOwner = useRef<ActionOwner>({ active: false, epoch: 0, pending: new Map() });
+  const [pendingActions, setPendingActions] = useState<ReadonlySet<string>>(() => new Set());
+  useEffect(() => {
+    const owner = actionOwner.current;
+    owner.active = true; owner.epoch += 1;
+    setPendingActions(new Set(owner.pending.keys()));
+    return () => {
+      owner.active = false; owner.epoch += 1;
+      // Pending effects remain locked across locale changes until their real settlement.
+    };
+  }, [locale]);
+  const beginAction = (keys: string[]): ActionLease | null => {
+    const owner = actionOwner.current;
+    if (!owner.active || keys.some(key => owner.pending.has(key))) return null;
+    const token = Symbol();
+    for (const key of keys) owner.pending.set(key, token);
+    setPendingActions(new Set(owner.pending.keys()));
+    return { owner, epoch: owner.epoch, token, keys };
+  };
+  const isCurrentAction = (lease: ActionLease) => actionOwner.current === lease.owner
+    && lease.owner.active && lease.owner.epoch === lease.epoch;
+  const finishAction = (lease: ActionLease) => {
+    for (const key of lease.keys) if (lease.owner.pending.get(key) === lease.token) lease.owner.pending.delete(key);
+    // An old locale may release only its own settled locks; it cannot publish an action fact.
+    if (actionOwner.current === lease.owner && lease.owner.active) setPendingActions(new Set(lease.owner.pending.keys()));
+  };
+
   const readGeneration = useRef(0), pendingRead = useRef<number | null>(null), manualReread = useRef(false);
   const load = useCallback((queueIfBusy = true) => {
     if (pendingRead.current !== null) { if (queueIfBusy) manualReread.current = true; return; }
@@ -2374,30 +2464,32 @@ function McpPane() {
 
   const handleCreate = async () => {
     if (!newName.trim() || !newCommand.trim()) return;
+    const lease = beginAction(['create']);
+    if (!lease) return;
     try {
       await api.createMCPInstall({
-        name: newName.trim(),
-        source: 'npm',
-        command: newCommand.trim(),
+        name: newName.trim(), source: 'npm', command: newCommand.trim(),
         args: newArgs.trim() ? newArgs.trim().split(/\s+/) : undefined,
       });
-      setNewName('');
-      setNewCommand('');
-      setNewArgs('');
-      setShowAdd(false);
+      if (!isCurrentAction(lease)) return;
+      setNewName(''); setNewCommand(''); setNewArgs(''); setShowAdd(false);
       load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+    } catch {
+      if (isCurrentAction(lease)) alert(t.mcpMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleDelete = async (id: string) => {
+    if (!actionOwner.current.active || actionOwner.current.pending.has('row:' + id)) return;
+    if (!window.confirm(t.mcpInstallDeleteConfirm)) return;
+    const lease = beginAction(['row:' + id]);
+    if (!lease) return;
     try {
       await api.deleteMCPInstall(id);
-      load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+      if (isCurrentAction(lease)) load();
+    } catch {
+      if (isCurrentAction(lease)) alert(t.mcpMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleInstallDependency = async (dependency: PluginDependencyStatus) => {
@@ -2760,7 +2852,7 @@ function McpPane() {
                 />
               </div>
               <div className="flex gap-2">
-                <button type="button" onClick={handleCreate} className={btnPrimary}>{ts.mcpCreateBtn}</button>
+                <button type="button" onClick={handleCreate} disabled={pendingActions.has('create')} className={btnPrimary}>{ts.mcpCreateBtn}</button>
                 <button type="button" onClick={() => setShowAdd(false)} className={btnSecondary}>{ts.mcpCancelBtn}</button>
               </div>
             </div>
@@ -2792,6 +2884,8 @@ function McpPane() {
                     </div>
                   </div>
                   <button type="button"
+                    aria-label={t.mcpInstallDeleteConfirm}
+                    disabled={pendingActions.has('row:' + install.id)}
                     onClick={() => handleDelete(install.id)}
                     className="rounded-lg p-1.5 text-[var(--c-text-tertiary)] hover:text-red-500 transition-colors"
                   >
diff --git a/desktop/renderer/src/components/SkillsSettingsContent.tsx b/desktop/renderer/src/components/SkillsSettingsContent.tsx
index f83763a9..4085fa56 100644
--- a/desktop/renderer/src/components/SkillsSettingsContent.tsx
+++ b/desktop/renderer/src/components/SkillsSettingsContent.tsx
@@ -43,6 +43,9 @@ import { SkillDetailModal } from './skills/SkillDetailModal'
 import { primaryButtonSmCls, secondaryButtonBorderStyle, secondaryButtonSmCls } from './buttonStyles'
 import { api } from '../api'
 
+type SkillActionErrorKey = 'importFailed' | 'repositoryMissing' | 'deleteConflict' | 'disableFailed' | 'githubInvalidUrl' | 'githubSkillNotFound'
+type SkillAction = { lifetime: object }
+
 type Props = {
   accessToken: string
   onTrySkill?: (prompt: string) => void
@@ -62,7 +65,11 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
   const [loading, setLoading] = useState(true)
   const [marketLoading, setMarketLoading] = useState(false)
   const [officialDisabled, setOfficialDisabled] = useState(false)
-  const [error, setError] = useState('')
+  const [error, setRawError] = useState('')
+  const [actionErrorKey, setActionErrorKey] = useState<SkillActionErrorKey | null>(null)
+  const setError = useCallback((message: string) => { setActionErrorKey(null); setRawError(message) }, [])
+  const setActionError = useCallback((key: SkillActionErrorKey) => { setRawError(''); setActionErrorKey(key) }, [])
+  const visibleError = actionErrorKey ? skillText[actionErrorKey] : error
   const [busySkillId, setBusySkillId] = useState<string | null>(null)
   const [uploadOpen, setUploadOpen] = useState(false)
   const [githubOpen, setGitHubOpen] = useState(false)
@@ -81,6 +88,36 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
   const addMenuRef = useRef<HTMLDivElement>(null)
   const cardMenuRef = useRef<HTMLDivElement>(null)
   const statsMap = new Map((statFacts.data ?? []).map(s => [s.skillName, s]))
+  const actionLifetime = useRef<object | null>(null)
+  const actionFlight = useRef<SkillAction | null>(null)
+  const defaultRevision = useRef(0)
+  const currentDefaults = useRef(defaultSkills)
+  currentDefaults.current = defaultSkills
+  useEffect(() => {
+    const lifetime = {}
+    actionLifetime.current = lifetime
+    actionFlight.current = null
+    defaultRevision.current += 1
+    setBusySkillId(null); setImporting(false); setUploading(false)
+    return () => {
+      if (actionLifetime.current === lifetime) actionLifetime.current = null
+      if (actionFlight.current?.lifetime === lifetime) actionFlight.current = null
+    }
+  }, [accessToken])
+  // One page-owned default writer. Locale changes do not invalidate authorized work.
+  const beginAction = useCallback((): SkillAction | null => {
+    if (!actionLifetime.current || actionFlight.current) return null
+    const action = { lifetime: actionLifetime.current }
+    actionFlight.current = action
+    return action
+  }, [])
+  const isCurrentAction = useCallback((action: SkillAction) =>
+    actionLifetime.current === action.lifetime && actionFlight.current === action, [])
+  const finishAction = useCallback((action: SkillAction) => {
+    if (!isCurrentAction(action)) return false
+    actionFlight.current = null
+    return true
+  }, [isCurrentAction])
   const catalogPending = useRef<Promise<import('../../../shared/skill-list-ipc-contract').SkillListDto> | null>(null)
   const refreshCatalog = useCallback(async () => {
     if (catalogPending.current) return catalogPending.current
@@ -88,15 +125,24 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
     try { return await pending } finally { if (catalogPending.current === pending) catalogPending.current = null }
   }, [listFacts.reload])
   const refreshBuiltin = useCallback(async () => {
-    const snapshot = await refreshCatalog(); const items = mapPlatformSkillList(snapshot); setBuiltinSkills(items); return items
+    const lifetime = actionLifetime.current
+    const snapshot = await refreshCatalog(); const items = mapPlatformSkillList(snapshot)
+    if (lifetime && actionLifetime.current === lifetime) setBuiltinSkills(items)
+    return items
   }, [refreshCatalog])
   const refreshInstalled = useCallback(async () => {
+    const lifetime = actionLifetime.current, revision = defaultRevision.current
     const [snapshot, defaults] = await Promise.all([refreshCatalog(), listDefaultSkills(accessToken)])
-    setDefaultSkills(defaults)
+    if (lifetime && actionLifetime.current === lifetime && defaultRevision.current === revision) setDefaultSkills(defaults)
     return { installed: mapInstalledSkillList(snapshot), defaults }
   }, [refreshCatalog, accessToken])
   useEffect(() => { setLoading(listFacts.reading && listFacts.data === null) }, [listFacts.reading, listFacts.data])
-  useEffect(() => { void listDefaultSkills(accessToken).then(setDefaultSkills).catch(() => {}) }, [accessToken])
+  useEffect(() => {
+    let active = true
+    const revision = defaultRevision.current
+    void listDefaultSkills(accessToken).then(defaults => { if (active && revision === defaultRevision.current) setDefaultSkills(defaults) }).catch(() => {})
+    return () => { active = false }
+  }, [accessToken])
   useEffect(() => { setBuiltinSkills(null) }, [listFacts.data])
 
   useEffect(() => {
@@ -112,17 +158,17 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
         setMarketSkills(items)
         setOfficialDisabled(false)
         if (query.trim()) {
-          setError('')
+          setRawError('')
         }
       } catch (err) {
         const apiErr = isApiError(err) ? err : null
         if (apiErr?.status === 503 || apiErr?.code === 'skills.market.not_configured') {
           setOfficialDisabled(true)
           setMarketSkills([])
-          setError(skillText.officialUnconfigured)
+          setRawError(skillText.officialUnconfigured)
         } else {
           setMarketSkills([])
-          setError(apiErr?.message || skillText.officialSearchFailed)
+          setRawError(apiErr?.message || skillText.officialSearchFailed)
         }
       } finally {
         setMarketLoading(false)
@@ -160,13 +206,15 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
     return mergeSkills(installedSkills, defaultSkills, marketSkills, query, viewMode)
   }, [viewMode, defaultSkills, installedSkills, marketSkills, query])
 
-  const syncDefaultSkills = useCallback(async (updater: (current: SkillReference[]) => SkillReference[]) => {
-    const current = defaultSkills.map(asSkillRef)
+  const syncDefaultSkills = useCallback(async (updater: (current: SkillReference[]) => SkillReference[], action: SkillAction) => {
+    if (!isCurrentAction(action)) throw new Error('skill_action_stale')
+    const current = currentDefaults.current.map(asSkillRef)
     const next = dedupeSkillRefs(updater(current))
+    defaultRevision.current += 1
     const updated = await replaceDefaultSkills(accessToken, next)
-    setDefaultSkills(updated)
+    if (isCurrentAction(action)) setDefaultSkills(updated)
     return updated
-  }, [accessToken, defaultSkills])
+  }, [accessToken, isCurrentAction])
 
   const shouldConfirmRisk = useCallback((skill: { display_name: string; scan_status?: SkillPackageResponse['scan_status']; scan_summary?: string; scan_has_warnings?: boolean }) => {
     const status = skill.scan_status ?? (skill.scan_has_warnings ? 'suspicious' : 'unknown')
@@ -174,28 +222,36 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
     return window.confirm(skillText.riskConfirm(skill.display_name, skillText.scanStatusLabel(status), skill.scan_summary))
   }, [skillText])
 
-  const ensureInstalledAndDefault = useCallback(async (skill: SkillPackageResponse) => {
+  const ensureInstalledAndDefault = useCallback(async (skill: SkillPackageResponse, action: SkillAction) => {
+    if (!isCurrentAction(action)) return
     const exists = installedSkills.some((item) => item.skill_key === skill.skill_key && item.version === skill.version)
     if (!exists) {
-      await installSkill(accessToken, asSkillRef(skill))
+      const result = await installSkill(accessToken, asSkillRef(skill))
+      if (!isCurrentAction(action)) return
+      if (!result.success) throw new Error('skill_install_failed')
     }
-    await syncDefaultSkills((current) => [...current, asSkillRef(skill)])
+    await syncDefaultSkills((current) => [...current, asSkillRef(skill)], action)
+    if (!isCurrentAction(action)) return
     await refreshInstalled()
-  }, [accessToken, installedSkills, refreshInstalled, syncDefaultSkills])
+  }, [accessToken, installedSkills, isCurrentAction, refreshInstalled, syncDefaultSkills])
 
   const handleEnable = useCallback(async (item: ViewSkill) => {
+    const action = beginAction()
+    if (!action) return
     setBusySkillId(item.id)
     setError('')
     try {
       if (item.is_platform && item.version) {
         await setPlatformSkillOverride(accessToken, item.skill_key, item.version, 'auto')
+        if (!isCurrentAction(action)) return
         await Promise.all([refreshInstalled(), refreshBuiltin()])
         return
       }
       if (item.installed && item.version) {
         const version = item.version
         if (!shouldConfirmRisk(item)) return
-        await syncDefaultSkills((current) => [...current, { skill_key: item.skill_key, version }])
+        await syncDefaultSkills((current) => [...current, { skill_key: item.skill_key, version }], action)
+        if (!isCurrentAction(action)) return
         await refreshInstalled()
         return
       }
@@ -206,65 +262,72 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
         detail_url: item.detail_url,
         repository_url: item.repository_url,
       })
-      if (!shouldConfirmRisk(imported)) return
-      await ensureInstalledAndDefault(imported)
+      if (!isCurrentAction(action) || !shouldConfirmRisk(imported)) return
+      await ensureInstalledAndDefault(imported, action)
     } catch (err) {
+      if (!isCurrentAction(action)) return
       const apiErr = isApiError(err) ? err : null
-      if (apiErr?.code === 'skills.market.repository_missing') {
-        setError(skillText.repositoryMissing)
-      } else {
-        setError(apiErr?.message || skillText.importFailed)
-      }
+      if (apiErr?.code === 'skills.market.repository_missing') setActionError('repositoryMissing')
+      else if (apiErr?.message) setError(apiErr.message)
+      else setActionError('importFailed')
     } finally {
-      setBusySkillId(null)
+      if (finishAction(action)) setBusySkillId(null)
     }
-  }, [accessToken, ensureInstalledAndDefault, refreshBuiltin, refreshInstalled, shouldConfirmRisk, skillText.importFailed, skillText.repositoryMissing, syncDefaultSkills])
+  }, [accessToken, beginAction, ensureInstalledAndDefault, finishAction, isCurrentAction, refreshBuiltin, refreshInstalled, setActionError, setError, shouldConfirmRisk, syncDefaultSkills])
 
   const handleRemove = useCallback(async (item: ViewSkill) => {
     if (!item.version) return
+    const action = beginAction()
+    if (!action) return
     setBusySkillId(item.id)
     setError('')
     try {
       if (item.is_platform) {
         await setPlatformSkillOverride(accessToken, item.skill_key, item.version, 'removed')
+        if (!isCurrentAction(action)) return
         await Promise.all([refreshInstalled(), refreshBuiltin()])
         return
       }
-      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)))
+      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)), action)
+      if (!isCurrentAction(action)) return
       await deleteSkill(accessToken, { skill_key: item.skill_key, version: item.version })
+      if (!isCurrentAction(action)) return
       await refreshInstalled()
     } catch (err) {
+      if (!isCurrentAction(action)) return
       const apiErr = isApiError(err) ? err : null
-      if (apiErr?.code === 'skills.in_use') {
-        setError(skillText.deleteConflict)
-      } else {
-        setError(skillText.importFailed)
-      }
+      setActionError(apiErr?.code === 'skills.in_use' ? 'deleteConflict' : 'importFailed')
     } finally {
-      setBusySkillId(null)
+      if (finishAction(action)) setBusySkillId(null)
     }
-  }, [accessToken, refreshBuiltin, refreshInstalled, skillText.deleteConflict, skillText.importFailed, syncDefaultSkills])
+  }, [accessToken, beginAction, finishAction, isCurrentAction, refreshBuiltin, refreshInstalled, setActionError, setError, syncDefaultSkills])
 
   const handleDisable = useCallback(async (item: ViewSkill) => {
     if (!item.version) return
+    const action = beginAction()
+    if (!action) return
     setBusySkillId(item.id)
     setError('')
     try {
       if (item.is_platform) {
         await setPlatformSkillOverride(accessToken, item.skill_key, item.version, 'manual')
+        if (!isCurrentAction(action)) return
         await Promise.all([refreshInstalled(), refreshBuiltin()])
         return
       }
-      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)))
+      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)), action)
+      if (!isCurrentAction(action)) return
       await refreshInstalled()
     } catch {
-      setError(skillText.disableFailed)
+      if (isCurrentAction(action)) setActionError('disableFailed')
     } finally {
-      setBusySkillId(null)
+      if (finishAction(action)) setBusySkillId(null)
     }
-  }, [accessToken, refreshBuiltin, refreshInstalled, skillText.disableFailed, syncDefaultSkills])
+  }, [accessToken, beginAction, finishAction, isCurrentAction, refreshBuiltin, refreshInstalled, setActionError, setError, syncDefaultSkills])
 
   const handleGitHubImport = useCallback(async (candidatePath?: string) => {
+    const action = beginAction()
+    if (!action) return
     setImporting(true)
     setError('')
     try {
@@ -273,54 +336,50 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
         ref: githubRef.trim() || undefined,
         candidate_path: candidatePath,
       })
+      if (!isCurrentAction(action)) return
       setCandidateState(null)
       setGitHubOpen(false)
-      await ensureInstalledAndDefault(response.skill)
+      await ensureInstalledAndDefault(response.skill, action)
+      if (!isCurrentAction(action)) return
       setGitHubUrl('')
       setGitHubRef('')
     } catch (err) {
+      if (!isCurrentAction(action)) return
       const apiErr = isApiError(err) ? err : null
       const details = apiErr?.details
       if (apiErr?.code === 'skills.import_ambiguous' && details && typeof details === 'object' && Array.isArray((details as { candidates?: unknown[] }).candidates)) {
-        setCandidateState({
-          candidates: (details as { candidates: SkillImportCandidate[] }).candidates,
-        })
+        setCandidateState({ candidates: (details as { candidates: SkillImportCandidate[] }).candidates })
         return
       }
-      if (apiErr?.code === 'skills.import_invalid_repository') {
-        setError(skillText.githubInvalidUrl)
-      } else if (apiErr?.code === 'skills.import_not_found') {
-        setError(skillText.githubSkillNotFound)
-      } else {
-        setError(apiErr?.message || skillText.importFailed)
-      }
+      if (apiErr?.code === 'skills.import_invalid_repository') setActionError('githubInvalidUrl')
+      else if (apiErr?.code === 'skills.import_not_found') setActionError('githubSkillNotFound')
+      else if (apiErr?.message) setError(apiErr.message)
+      else setActionError('importFailed')
     } finally {
-      setImporting(false)
+      if (finishAction(action)) setImporting(false)
     }
-  }, [accessToken, ensureInstalledAndDefault, githubRef, githubUrl, skillText.githubInvalidUrl, skillText.githubSkillNotFound, skillText.importFailed])
+  }, [accessToken, beginAction, ensureInstalledAndDefault, finishAction, githubRef, githubUrl, isCurrentAction, setActionError, setError])
 
   const handleUploadImport = useCallback(async () => {
     if (!file) return
+    const action = beginAction()
+    if (!action) return
     setUploading(true)
     setError('')
     try {
-      const response = await importSkillFromUpload(accessToken, {
-        file,
-        install_after_import: false,
-      })
-      if (installAfterImport) {
-        await ensureInstalledAndDefault(response)
-      } else {
-        await refreshInstalled()
-      }
+      const response = await importSkillFromUpload(accessToken, { file, install_after_import: false })
+      if (!isCurrentAction(action)) return
+      if (installAfterImport) await ensureInstalledAndDefault(response, action)
+      else await refreshInstalled()
+      if (!isCurrentAction(action)) return
       setFile(null)
       setUploadOpen(false)
     } catch {
-      setError(skillText.importFailed)
+      if (isCurrentAction(action)) setActionError('importFailed')
     } finally {
-      setUploading(false)
+      if (finishAction(action)) setUploading(false)
     }
-  }, [accessToken, ensureInstalledAndDefault, file, installAfterImport, refreshInstalled, skillText.importFailed])
+  }, [accessToken, beginAction, ensureInstalledAndDefault, file, finishAction, installAfterImport, isCurrentAction, refreshInstalled, setActionError, setError])
 
   const active = (item: ViewSkill) => item.installed && item.enabled_by_default
 
@@ -454,8 +513,8 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
       {viewMode === 'marketplace' && officialDisabled && (
         <p className="text-xs text-[var(--c-text-tertiary)]">{skillText.officialUnconfigured}</p>
       )}
-      {error && (
-        <p className="text-xs" style={{ color: 'var(--c-status-error-text)' }}>{error}</p>
+      {visibleError && (
+        <p className="text-xs" style={{ color: 'var(--c-status-error-text)' }}>{visibleError}</p>
       )}
 
       {viewMode === 'installed' && (
diff --git a/desktop/renderer/src/contexts/KSwarmContext.tsx b/desktop/renderer/src/contexts/KSwarmContext.tsx
index 42259e33..10ee13f6 100644
--- a/desktop/renderer/src/contexts/KSwarmContext.tsx
+++ b/desktop/renderer/src/contexts/KSwarmContext.tsx
@@ -1,41 +1,29 @@
+import { useKswarmStatusReadonly } from '../hooks/useKswarmStatusReadonly';
 /**
  * KSwarmContext — provides kswarm client state and actions to the component tree.
  *
  * Also manages the kswarm service lifecycle status via IPC.
  */
 
-import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
+import { createContext, useContext, type ReactNode } from 'react';
 import { useKSwarmClient, type KSwarmClientState, type KSwarmClientActions } from '../hooks/useKSwarmClient';
 import type { KSwarmServiceStatus } from '../../../electron/preload-api';
-import { getDesktopApi } from '../shared/desktop';
 
 interface KSwarmContextValue extends KSwarmClientState, KSwarmClientActions {
   serviceStatus: KSwarmServiceStatus | null;
+  serviceStatusReadFailed: boolean;
+  serviceStatusReading: boolean;
+  reloadServiceStatus(): void;
 }
 
 const KSwarmContext = createContext<KSwarmContextValue | null>(null);
 
 export function KSwarmProvider({ children }: { children: ReactNode }) {
   const client = useKSwarmClient();
-  const [serviceStatus, setServiceStatus] = useState<KSwarmServiceStatus | null>(null);
-
-  useEffect(() => {
-    const api = getDesktopApi() as { kswarmGetStatus(): Promise<KSwarmServiceStatus>; onKSwarmStatus(cb: (s: KSwarmServiceStatus) => void): () => void } | null;
-    if (!api) return;
-
-    // Get initial status
-    api.kswarmGetStatus().then(setServiceStatus).catch(() => {});
-
-    // Subscribe to status changes
-    const unsub = api.onKSwarmStatus((status) => {
-      setServiceStatus(status);
-    });
-
-    return unsub;
-  }, []);
+  const status = useKswarmStatusReadonly();
 
   return (
-    <KSwarmContext.Provider value={{ ...client, serviceStatus }}>
+    <KSwarmContext.Provider value={{ ...client, serviceStatus: status.data, serviceStatusReadFailed: status.failed, serviceStatusReading: status.reading, reloadServiceStatus: status.refresh }}>
       {children}
     </KSwarmContext.Provider>
   );
diff --git a/desktop/renderer/src/locales/en.ts b/desktop/renderer/src/locales/en.ts
index e7871ea1..bf1553ed 100644
--- a/desktop/renderer/src/locales/en.ts
+++ b/desktop/renderer/src/locales/en.ts
@@ -3046,6 +3046,9 @@ export const en: LocaleStrings = {
   meetingModelsReadonlyUnavailable: 'Unable to read meeting models',
   meetingAsrReadonlyUnknown: 'Speech configuration unknown',
   meetingAsrReadonlyUnavailable: 'Unable to read speech configuration',
+  channelMutationFailed: 'Channel operation failed. Please try again.',
+  mcpMutationFailed: 'MCP configuration operation failed. Please try again.',
+  mcpInstallDeleteConfirm: 'Delete this MCP configuration?',
   channelReadonlyUnknown: 'Channel information unknown',
   channelReadonlyUnavailable: 'Unable to read channels',
   mcpInstallsReadonlyUnknown: 'MCP installation information unknown',
diff --git a/desktop/renderer/src/locales/index.ts b/desktop/renderer/src/locales/index.ts
index 1ea700d4..06e5fb54 100644
--- a/desktop/renderer/src/locales/index.ts
+++ b/desktop/renderer/src/locales/index.ts
@@ -2933,6 +2933,9 @@ export interface LocaleStrings {
   meetingModelsReadonlyUnavailable: string;
   meetingAsrReadonlyUnknown: string;
   meetingAsrReadonlyUnavailable: string;
+  channelMutationFailed: string;
+  mcpMutationFailed: string;
+  mcpInstallDeleteConfirm: string;
   channelReadonlyUnknown: string;
   channelReadonlyUnavailable: string;
   mcpInstallsReadonlyUnknown: string;
diff --git a/desktop/renderer/src/locales/zh.ts b/desktop/renderer/src/locales/zh.ts
index 0b9cfa90..90129b98 100644
--- a/desktop/renderer/src/locales/zh.ts
+++ b/desktop/renderer/src/locales/zh.ts
@@ -3026,6 +3026,9 @@ export const zh: LocaleStrings = {
   meetingModelsReadonlyUnavailable: '\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b',
   meetingAsrReadonlyUnknown: '\u8bed\u97f3\u914d\u7f6e\u672a\u77e5',
   meetingAsrReadonlyUnavailable: '\u65e0\u6cd5\u8bfb\u53d6\u8bed\u97f3\u914d\u7f6e',
+  channelMutationFailed: '通道操作失败，请重试',
+  mcpMutationFailed: 'MCP 配置操作失败，请重试',
+  mcpInstallDeleteConfirm: '确定删除此 MCP 配置？',
   channelReadonlyUnknown: '通道信息未知',
   channelReadonlyUnavailable: '无法读取消息通道',
   mcpInstallsReadonlyUnknown: 'MCP 安装信息未知',
diff --git a/desktop/tests/main/channel-mcp-readonly-controls.test.ts b/desktop/tests/main/channel-mcp-readonly-controls.test.ts
index 3c79120a..c0a6cb8c 100644
--- a/desktop/tests/main/channel-mcp-readonly-controls.test.ts
+++ b/desktop/tests/main/channel-mcp-readonly-controls.test.ts
@@ -43,7 +43,7 @@ it('bad channel config rejects without modifying the real owned file or creating
   await expect(async () => f.invoke('listChannels')).rejects.toThrow(); expect(readFileSync(path, 'utf8')).toBe('{'); expect(existsSync(path + '.bak')).toBe(false);
 });
 it('actual existing MCP creation output passes the readonly schema with original command and args', async () => {
-  const f = await fixture(), created = await f.service.createMCPInstall({ name:'owned',source:'local',command:'C:\\owned\\command',args:['--owned',''] });
+  const f = await fixture(), created = await f.service.createMCPInstall({ name:'owned',source:'local',command:'C:\\owned\\command',args:['--owned',''] }, 'user');
   const rows = await f.invoke('listMCPInstalls'); expect(rows).toHaveLength(1); expect(rows[0]).toMatchObject(created); expect(rows[0].args).toEqual(['--owned','']);
 });
 it('preserves real absent file success for both readonly facts', async () => { const f = await fixture(); expect(await f.invoke('listChannels')).toEqual([]); expect(await f.invoke('listMCPInstalls')).toEqual([]); });
diff --git a/desktop/tests/main/desktop-services.test.ts b/desktop/tests/main/desktop-services.test.ts
index 2ddf785a..be2860fe 100644
--- a/desktop/tests/main/desktop-services.test.ts
+++ b/desktop/tests/main/desktop-services.test.ts
@@ -4010,7 +4010,7 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    const channel = await services.createChannel({ type: 'discord', name: 'My Discord', webhookUrl: 'https://discord.com/api/webhooks/...' });
+    const channel = await services.createChannel({ type: 'discord', name: 'My Discord', webhookUrl: 'https://discord.com/api/webhooks/...' }, 'user');
     expect(channel.id).toBe('discord');
     expect(channel.type).toBe('discord');
     expect(channel.name).toBe('My Discord');
@@ -4031,10 +4031,10 @@ describe('desktop services', () => {
     });
 
     // First create
-    await services.createChannel({ type: 'telegram', name: 'Old Name' });
+    await services.createChannel({ type: 'telegram', name: 'Old Name' }, 'user');
 
     // Then update
-    const updated = await services.updateChannel('telegram', { name: 'New Name', webhookUrl: 'https://api.telegram.org/bot123' });
+    const updated = await services.updateChannel('telegram', { name: 'New Name', webhookUrl: 'https://api.telegram.org/bot123' }, 'user');
     expect(updated.name).toBe('New Name');
     expect(updated.webhookUrl).toBe('https://api.telegram.org/bot123');
   });
@@ -4046,7 +4046,7 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    await expect(services.updateChannel('nonexistent', { name: 'test' })).rejects.toThrow('not found');
+    await expect(services.updateChannel('nonexistent', { name: 'test' }, 'user')).rejects.toThrow('not found');
   });
 
   it('deletes a channel from config.json', async () => {
@@ -4056,11 +4056,11 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    await services.createChannel({ type: 'feishu', name: 'Feishu' });
+    await services.createChannel({ type: 'feishu', name: 'Feishu' }, 'user');
     let channels = await services.listChannels();
     expect(channels.find(c => c.id === 'feishu')).toBeDefined();
 
-    await services.deleteChannel('feishu');
+    await services.deleteChannel('feishu', 'user');
     channels = await services.listChannels();
     expect(channels.find(c => c.id === 'feishu')).toBeUndefined();
   });
@@ -4089,7 +4089,7 @@ describe('desktop services', () => {
       name: 'Playwright',
       source: 'npm',
       command: '@anthropic/mcp-playwright',
-    });
+    }, 'user');
 
     expect(install.id).toBeDefined();
     expect(install.name).toBe('Playwright');
@@ -4115,9 +4115,9 @@ describe('desktop services', () => {
       name: 'Brave Search',
       source: 'npm',
       command: '@anthropic/mcp-brave-search',
-    });
+    }, 'user');
 
-    const updated = await services.updateMCPInstall(created.id, { enabled: false });
+    const updated = await services.updateMCPInstall(created.id, { enabled: false }, 'user');
     expect(updated.enabled).toBe(false);
   });
 
@@ -4128,7 +4128,7 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    await expect(services.updateMCPInstall('nonexistent', { enabled: false })).rejects.toThrow('not found');
+    await expect(services.updateMCPInstall('nonexistent', { enabled: false }, 'user')).rejects.toThrow('not found');
   });
 
   it('deletes an MCP install', async () => {
@@ -4138,8 +4138,8 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    const created = await services.createMCPInstall({ name: 'Test MCP', source: 'npm', command: 'test' });
-    await services.deleteMCPInstall(created.id);
+    const created = await services.createMCPInstall({ name: 'Test MCP', source: 'npm', command: 'test' }, 'user');
+    await services.deleteMCPInstall(created.id, 'user');
 
     const installs = await services.listMCPInstalls();
     expect(installs).toHaveLength(0);
@@ -4152,8 +4152,8 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    const install1 = await services.createMCPInstall({ name: 'MCP1', source: 'npm', command: 'cmd1' });
-    const install2 = await services.createMCPInstall({ name: 'MCP2', source: 'github', command: 'cmd2' });
+    const install1 = await services.createMCPInstall({ name: 'MCP1', source: 'npm', command: 'cmd1' }, 'user');
+    const install2 = await services.createMCPInstall({ name: 'MCP2', source: 'github', command: 'cmd2' }, 'user');
 
     expect(install1.id).not.toBe(install2.id);
     expect(install1.source).toBe('npm');
diff --git a/desktop/tests/main/ipc-schema-coverage.test.ts b/desktop/tests/main/ipc-schema-coverage.test.ts
index bdd51a18..c6ff7ef4 100644
--- a/desktop/tests/main/ipc-schema-coverage.test.ts
+++ b/desktop/tests/main/ipc-schema-coverage.test.ts
@@ -1,3 +1,7 @@
+import { registerComputerUseCapabilityReadonlyIpc, registerKswarmStatusReadonlyIpc } from '../../electron/runtime-status-readonly-typed-ipc.js';
+import { registerSkillMutationIpc } from '../../electron/skill-mutation-typed-ipc.js';
+import { registerChannelMcpMutationIpc } from '../../electron/channel-mcp-mutation-typed-ipc.js';
+import { registerMeetingMutationIpc } from '../../electron/meeting-mutation-typed-ipc.js';
 import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from '../../electron/skill-list-typed-ipc.js';
@@ -24,6 +28,7 @@ registerAutomationConfigIpc({handle:channel=>{currentViewChannels.push(channel);
 registerSkillListIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerChannelMcpReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerMeetingReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
+registerComputerUseCapabilityReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});registerKswarmStatusReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});registerSkillMutationIpc({handle:channel=>{currentViewChannels.push(channel);}});registerChannelMcpMutationIpc({handle:channel=>{currentViewChannels.push(channel);}});registerMeetingMutationIpc({handle:channel=>{currentViewChannels.push(channel);}}, new Map());
 registerServiceControlIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerMobileReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerPluginCatalogIpc({handle:channel=>{currentViewChannels.push(channel);}});
diff --git a/desktop/tests/main/preload-contract.test.ts b/desktop/tests/main/preload-contract.test.ts
index 0b246332..b43a0e8e 100644
--- a/desktop/tests/main/preload-contract.test.ts
+++ b/desktop/tests/main/preload-contract.test.ts
@@ -1,3 +1,7 @@
+import { registerComputerUseCapabilityReadonlyIpc, registerKswarmStatusReadonlyIpc } from '../../electron/runtime-status-readonly-typed-ipc.js';
+import { registerSkillMutationIpc } from '../../electron/skill-mutation-typed-ipc.js';
+import { registerChannelMcpMutationIpc } from '../../electron/channel-mcp-mutation-typed-ipc.js';
+import { registerMeetingMutationIpc } from '../../electron/meeting-mutation-typed-ipc.js';
 import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from '../../electron/skill-list-typed-ipc.js';
@@ -1073,6 +1077,7 @@ function extractRegisteredHandlerChannels(): Set<string> {
   registerSkillListIpc({ handle: channel => { channels.add(channel); } });
   registerChannelMcpReadonlyIpc({ handle: channel => { channels.add(channel); } });
 registerMeetingReadonlyIpc({ handle: channel => { channels.add(channel); } });
+registerComputerUseCapabilityReadonlyIpc({ handle: channel => { channels.add(channel); } });registerKswarmStatusReadonlyIpc({ handle: channel => { channels.add(channel); } });registerSkillMutationIpc({ handle: channel => { channels.add(channel); } });registerChannelMcpMutationIpc({ handle: channel => { channels.add(channel); } });registerMeetingMutationIpc({ handle: channel => { channels.add(channel); } }, new Map());
   registerKSwarmProxy({ handle: channel => { channels.add(channel); } }, {} as never);
 registerLoopOutputIpc({handle:channel=>{channels.add(channel);}},{} as never,()=>false);
   registerConversationActivityIpc({ handle: channel => { channels.add(channel); } }, null, () => null);
diff --git a/desktop/tests/main/skill-reload-on-install.test.ts b/desktop/tests/main/skill-reload-on-install.test.ts
index 155fd155..a1c6ecd6 100644
--- a/desktop/tests/main/skill-reload-on-install.test.ts
+++ b/desktop/tests/main/skill-reload-on-install.test.ts
@@ -12,16 +12,105 @@
 import { describe, expect, it } from 'vitest';
 import { readFileSync } from 'node:fs';
 import { join } from 'node:path';
+import ts from 'typescript';
 
 const servicesSource = readFileSync(join(__dirname, '../../electron/desktop-services.ts'), 'utf-8');
+const mutationSource = readFileSync(join(__dirname, '../../electron/desktop-skill-mutation.ts'), 'utf-8');
 const mainSource = readFileSync(join(__dirname, '../../electron/main.ts'), 'utf-8');
 
 describe('skill install auto reload wiring', () => {
   it('bumps the shared catalog version from every install/uninstall entrance', () => {
-    // Two agent tools (skill_install / skill_uninstall) + two settings-pane
-    // services (installSkill / uninstallSkill) = at least 4 bump call sites.
-    const bumps = servicesSource.match(/bumpSkillCatalogVersion\(\)/g) ?? [];
-    expect(bumps.length).toBeGreaterThanOrEqual(4);
+    // Keep all four original entrances. Physical bump sites moved into the
+    // shared Desktop domain helper; literals in the old file are no longer
+    // evidence for its two callers. Real service behavior has separate controls.
+    const servicesAst = ts.createSourceFile('desktop-services.ts', servicesSource, ts.ScriptTarget.Latest, true);
+    const mutationAst = ts.createSourceFile('desktop-skill-mutation.ts', mutationSource, ts.ScriptTarget.Latest, true);
+    function nodes<T extends ts.Node>(root: ts.Node, guard: (node: ts.Node) => node is T): T[] {
+      const found: T[] = [];
+      const visit = (node: ts.Node) => { if (guard(node)) found.push(node); ts.forEachChild(node, visit); };
+      visit(root); return found;
+    }
+    function name(node: ts.PropertyName | undefined) {
+      return node && (ts.isIdentifier(node) || ts.isStringLiteral(node)) ? node.text : undefined;
+    }
+    function property(object: ts.ObjectLiteralExpression, key: string) {
+      return object.properties.find((node): node is ts.PropertyAssignment => ts.isPropertyAssignment(node) && name(node.name) === key)?.initializer;
+    }
+    function successfulBump(body: ts.Block, ast: ts.SourceFile, command: string, operand: string) {
+      const result = nodes(body, ts.isVariableDeclaration).filter(node => ts.isIdentifier(node.name) && node.name.text === 'result');
+      expect(result).toHaveLength(1);
+      const call = result[0]!.initializer;
+      expect(call && ts.isCallExpression(call)).toBe(true);
+      if (!call || !ts.isCallExpression(call)) throw Error('skill_command_call_missing');
+      expect(call.expression.getText(ast)).toBe(command);
+      expect(call.arguments[0] && ts.isStringLiteral(call.arguments[0]) ? call.arguments[0].text : undefined).toBe('clawhub');
+      const args = call.arguments[1];
+      expect(args && ts.isArrayLiteralExpression(args)).toBe(true);
+      if (!args || !ts.isArrayLiteralExpression(args)) throw Error('skill_command_argv_missing');
+      expect(args.elements).toHaveLength(2);
+      const operation = args.elements[0]!;
+      expect(ts.isStringLiteral(operation) ? operation.text : operation.getText(ast)).toBe(operand);
+      expect(args.elements[1]!.getText(ast)).toBe('skillName');
+      const bumps = nodes(body, ts.isCallExpression).filter(call => ts.isIdentifier(call.expression) && call.expression.text === 'bumpSkillCatalogVersion');
+      expect(bumps).toHaveLength(1);
+      const bumpIndex = body.statements.findIndex(statement => ts.isExpressionStatement(statement) && statement.expression === bumps[0]);
+      expect(bumpIndex).toBeGreaterThan(0);
+      for (const condition of ['result.error', 'result.status !== 0']) {
+        const index = body.statements.findIndex(statement => ts.isIfStatement(statement) && statement.expression.getText(ast) === condition);
+        expect(index).toBeGreaterThanOrEqual(0); expect(index).toBeLessThan(bumpIndex);
+        const statement = body.statements[index]!;
+        if (!ts.isIfStatement(statement)) throw Error('skill_failure_guard_missing');
+        const branch = statement.thenStatement;
+        expect(ts.isReturnStatement(branch) || ts.isBlock(branch) && ts.isReturnStatement(branch.statements[branch.statements.length - 1]!)).toBe(true);
+        expect(statement.elseStatement).toBeUndefined();
+      }
+      const success = body.statements[bumpIndex + 1]!;
+      expect(ts.isReturnStatement(success)).toBe(true);
+      const successDTO = nodes(success, ts.isObjectLiteralExpression).filter(dto => property(dto, 'success')?.kind === ts.SyntaxKind.TrueKeyword);
+      expect(successDTO).toHaveLength(1);
+    }
+    const owners = nodes(servicesAst, ts.isFunctionDeclaration).filter(node => node.name?.text === 'createDesktopServices');
+    expect(owners).toHaveLength(1);
+    const methods = nodes(owners[0]!, ts.isMethodDeclaration);
+    const registrations = methods.filter(node => name(node.name) === 'registerSkillTools');
+    expect(registrations).toHaveLength(1);
+    const entrancePopulation: string[] = [];
+    for (const [toolName, operation] of [['skill_install', 'install'], ['skill_uninstall', 'uninstall']] as const) {
+      const tools = nodes(registrations[0]!, ts.isObjectLiteralExpression).filter(tool => {
+        const definition = property(tool, 'definition');
+        if (!definition || !ts.isObjectLiteralExpression(definition)) return false;
+        const id = property(definition, 'name'); return id && ts.isStringLiteral(id) && id.text === toolName;
+      });
+      expect(tools).toHaveLength(1);
+      const executes = tools[0]!.properties.filter((node): node is ts.MethodDeclaration => ts.isMethodDeclaration(node) && name(node.name) === 'execute');
+      expect(executes).toHaveLength(1); expect(executes[0]!.body).toBeDefined();
+      successfulBump(executes[0]!.body!, servicesAst, 'spawnSync', operation);
+      entrancePopulation.push(toolName);
+    }
+    const imports = servicesAst.statements.filter((node): node is ts.ImportDeclaration => ts.isImportDeclaration(node)
+      && ts.isStringLiteral(node.moduleSpecifier) && node.moduleSpecifier.text === './desktop-skill-mutation.js');
+    expect(imports).toHaveLength(1);
+    const bindings = imports[0]!.importClause?.namedBindings;
+    expect(bindings && ts.isNamedImports(bindings) && bindings.elements.some(node => node.name.text === 'runDesktopSkillMutation' && !node.propertyName)).toBe(true);
+    for (const [methodName, operation] of [['installSkill', 'install'], ['uninstallSkill', 'uninstall']] as const) {
+      const delegates = methods.filter(node => name(node.name) === methodName);
+      expect(delegates).toHaveLength(1); expect(delegates[0]!.body?.statements).toHaveLength(1);
+      const statement = delegates[0]!.body!.statements[0]!;
+      expect(ts.isReturnStatement(statement)).toBe(true);
+      const call = ts.isReturnStatement(statement) ? statement.expression : undefined;
+      if (!call || !ts.isCallExpression(call)) throw Error('skill_desktop_delegate_missing');
+      expect(call.expression.getText(servicesAst)).toBe('runDesktopSkillMutation');
+      expect(call.arguments).toHaveLength(4);
+      expect(ts.isStringLiteral(call.arguments[0]!) ? call.arguments[0]!.text : undefined).toBe(operation);
+      expect(call.arguments.slice(1).map(node => node.getText(servicesAst))).toEqual(['skillName', 'context', 'process.cwd()']);
+      entrancePopulation.push(methodName);
+    }
+    const helpers = mutationAst.statements.filter((node): node is ts.FunctionDeclaration => ts.isFunctionDeclaration(node) && node.name?.text === 'runDesktopSkillMutation');
+    expect(helpers).toHaveLength(1);
+    expect(helpers[0]!.modifiers?.some(node => node.kind === ts.SyntaxKind.ExportKeyword)).toBe(true);
+    expect(helpers[0]!.body).toBeDefined();
+    successfulBump(helpers[0]!.body!, mutationAst, 'crossSpawn.sync', 'operation');
+    expect(entrancePopulation).toEqual(['skill_install', 'skill_uninstall', 'installSkill', 'uninstallSkill']);
   });
 
   it('runner reloads the catalog when the shared version changes instead of a one-shot gate', () => {
diff --git a/src/types/cross-spawn.d.ts b/src/types/cross-spawn.d.ts
index 6ee09b71..0ac7736f 100644
--- a/src/types/cross-spawn.d.ts
+++ b/src/types/cross-spawn.d.ts
@@ -8,5 +8,9 @@ declare module 'cross-spawn' {
 
   function spawn(command: string, args?: readonly string[], options?: SpawnOptions): ChildProcess;
 
+  namespace spawn {
+    const sync: typeof import('node:child_process').spawnSync;
+  }
+
   export = spawn;
 }

```

## FULL desktop/electron/channel-mcp-mutation-owner.ts
```typescript
// UNREVIEWED CANDIDATE — business owner only; not a new generic IPC/fs framework.
import { readFileSync, writeFileSync, mkdirSync, existsSync, chmodSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { types } from 'node:util';
import { getConfigPath, saveConfig } from '../../src/utils/config.js';
import { DEFAULT_CONFIG, isValidLegacyProvider, type Config, type LegacyConfig } from '../../src/types.js';
import { normalizeConfig } from '../../src/ai/providers/normalize.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { STORED_CHANNELS_READONLY_SCHEMA, MCP_INSTALLS_READONLY_OUTPUT_SCHEMA } from '../shared/channel-mcp-readonly-ipc-contract.js';
import { CHANNEL_MCP_MUTATION_INPUTS, type ChannelMcpMutationMethod } from '../shared/channel-mcp-mutation-ipc-contract.js';
type RequestSource = 'user' | 'agent' | 'scheduler';
const own = Object.hasOwn;
function admission(method: ChannelMcpMutationMethod, args: unknown[], source?: RequestSource): unknown[] {
  if (source !== 'user') throw Error('channel_mcp_mutation_request_source_forbidden');
  const captured = captureIpcData(args, 'channel_mcp_mutation_input_invalid');
  const parsed = CHANNEL_MCP_MUTATION_INPUTS[method].safeParse(captured);
  if (!parsed.success) throw Error('channel_mcp_mutation_input_invalid');
  return parsed.data;
}
function readJson(path: string): unknown | undefined {
  let bytes: string;
  try { bytes = readFileSync(path, 'utf8'); }
  catch (error) {
    if (error && typeof error === 'object' && !types.isProxy(error) && Object.getOwnPropertyDescriptor(error, 'code')?.value === 'ENOENT') return undefined;
    throw Error('channel_mcp_mutation_source_unavailable');
  }
  // Native JSON.parse messages may echo credential fragments. Do not transport them.
  try { return captureIpcData(JSON.parse(bytes), 'channel_mcp_mutation_source_unavailable', { preserveDataPrototype: true }); }
  catch { throw Error('channel_mcp_mutation_source_unavailable'); }
}
function configForEdit(): Record<string, unknown> & { channels: Record<string, Record<string, unknown>> } {
  const loaded = readJson(getConfigPath());
  const raw = loaded === undefined ? JSON.parse(JSON.stringify(DEFAULT_CONFIG)) : loaded;
  try {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw Error();
    const obj = raw as Record<string, unknown>;
    if (obj.schemaVersion !== 1 && obj.schemaVersion !== 2) throw Error();
    if (obj.schemaVersion === 1 && obj.defaultModel !== undefined && !isValidLegacyProvider(obj.defaultModel)) throw Error();
    if (obj.channels != null && !STORED_CHANNELS_READONLY_SCHEMA.safeParse(obj.channels).success) throw Error();
    const normalized = normalizeConfig(obj as unknown as LegacyConfig | Config);
    if (!STORED_CHANNELS_READONLY_SCHEMA.safeParse(normalized.channels ?? {}).success) throw Error();
    // Keep raw schema1/2 providers, keys, unknown extras and channel-specific state.
    // Normalize only to validate; a channel edit must not rewrite unrelated settings.
    obj.channels ??= {};
    return obj as Record<string, unknown> & { channels: Record<string, Record<string, unknown>> };
  } catch { throw Error('channel_mcp_mutation_source_unavailable'); }
}
async function persistConfig(config: Record<string, unknown>): Promise<void> {
  // saveConfig writes synchronously before returning its Promise. No await between read/edit/write.
  try { await saveConfig(config as unknown as Config); }
  catch { throw Error('channel_mcp_mutation_write_failed'); }
}
function channelView(id: string, row: Record<string, unknown>, createdAt = 0) {
  return { id, type: id, name: (row.name as string) || id, webhookUrl: (row.sendMsgUrl || row.webhookUrl) as string | undefined,
    enabled: row.enabled !== false, createdAt, updatedAt: Date.now() };
}
function readInstalls(root: string) {
  const raw = readJson(join(root, 'mcp-installs.json'));
  const rows = raw === undefined ? [] : raw;
  const parsed = MCP_INSTALLS_READONLY_OUTPUT_SCHEMA.safeParse(rows);
  if (!parsed.success) throw Error('channel_mcp_mutation_source_unavailable');
  if (new Set(parsed.data.map(row => row.id)).size !== parsed.data.length) throw Error('channel_mcp_mutation_source_unavailable');
  return parsed.data;
}
function writeInstalls(root: string, rows: unknown): void {
  const path = join(root, 'mcp-installs.json');
  try {
    mkdirSync(root, { recursive: true });
    if (process.platform !== 'win32' && existsSync(path)) {
      chmodSync(path, 0o600);
      if ((statSync(path).mode & 0o777) !== 0o600) throw Error();
    }
    writeFileSync(path, JSON.stringify(rows, null, 2), { encoding: 'utf8', mode: 0o600 });
  } catch { throw Error('channel_mcp_mutation_write_failed'); }
}
function mcpView(row: ReturnType<typeof readInstalls>[number]) {
  return { id: row.id, name: row.name, source: row.source, command: row.command, args: row.args, enabled: row.enabled, createdAt: row.createdAt };
}
export function createChannelMcpMutationOwner(dataRoot: string) {
  return {
    async createChannel(input: unknown, requestSource?: RequestSource) {
      const [parsed] = admission('createChannel', [input], requestSource);
      const value = parsed as { type: string; name: string; webhookUrl?: string } & Record<string, unknown>;
      const config = configForEdit(), prior = own(config.channels, value.type) ? config.channels[value.type] : {};
      const { type: id, webhookUrl, ...fields } = value;
      config.channels[id] = { ...prior, ...Object.fromEntries(Object.entries(fields).filter(([, value]) => value !== undefined)), sendMsgUrl: webhookUrl || '', inboundMode: 'webhook', enabled: true };
      if (own(config.channels[id]!, 'webhookUrl')) config.channels[id]!.webhookUrl = webhookUrl || '';
      const result = { ...channelView(id, config.channels[id]!, Date.now()), name: value.name, webhookUrl };
      await persistConfig(config); return result;
    },
    async updateChannel(id: unknown, input: unknown, requestSource?: RequestSource) {
      const [key, patch] = admission('updateChannel', [id, input], requestSource) as [string, Record<string, unknown>];
      if (patch.type !== undefined && patch.type !== key) throw Error('channel_mcp_mutation_input_invalid');
      const config = configForEdit();
      if (!own(config.channels, key)) throw Error('Channel not found');
      const row = config.channels[key]!;
      for (const [field, value] of Object.entries(patch)) {
        if (value !== undefined && field !== 'type') row[field === 'webhookUrl' ? 'sendMsgUrl' : field] = value;
      }
      // A changed webhook must not be shadowed by an old webhookUrl in readonly projection.
      if (patch.webhookUrl !== undefined && own(row, 'webhookUrl')) row.webhookUrl = patch.webhookUrl;
      const result = channelView(key, row); await persistConfig(config); return result;
    },
    async deleteChannel(id: unknown, requestSource?: RequestSource) {
      const [key] = admission('deleteChannel', [id], requestSource) as [string];
      const config = configForEdit();
      if (!own(config.channels, key)) return; // preserve idempotent delete, do not create a default file
      delete config.channels[key]; await persistConfig(config);
    },
    async testChannel(id: unknown, requestSource?: RequestSource) {
      const [key] = admission('testChannel', [id], requestSource) as [string];
      const config = configForEdit(), row = own(config.channels, key) ? config.channels[key] : undefined;
      const url = row?.sendMsgUrl || row?.webhookUrl;
      if (!url) return { success: false, error: 'channel_mcp_mutation_webhook_missing' };
      let target: URL;
      try { target = new URL(url as string); }
      catch { return { success: false, error: 'channel_mcp_mutation_webhook_invalid' }; }
      if (!['https:', 'http:'].includes(target.protocol) || target.username || target.password) return { success: false, error: 'channel_mcp_mutation_webhook_invalid' };
      try {
        const start = Date.now();
        const response = await fetch(target.href, { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ msgtype: 'text', text: { content: 'xiaok 测试连接 ✅' } }) });
        const latencyMs = Math.max(0, Date.now() - start);
        return response.ok ? { success: true, latencyMs } : { success: false, latencyMs, error: `HTTP ${response.status}` };
      } catch { return { success: false, error: 'channel_mcp_mutation_network_failed' }; }
      // No automatic resend, new timeout, install or process spawn. Original IPC shutdown token owns settlement.
    },
    async createMCPInstall(input: unknown, requestSource?: RequestSource) {
      const [parsed] = admission('createMCPInstall', [input], requestSource);
      const value = parsed as { name: string; source: 'npm' | 'github' | 'local'; command: string; args?: string[] };
      const rows = readInstalls(dataRoot), record = { ...value, id: randomUUID(), enabled: true, createdAt: Date.now() };
      rows.push(record); const result = mcpView(record); writeInstalls(dataRoot, rows); return result;
    },
    async updateMCPInstall(id: unknown, input: unknown, requestSource?: RequestSource) {
      const [key, patch] = admission('updateMCPInstall', [id, input], requestSource) as [string, Record<string, unknown>];
      const rows = readInstalls(dataRoot), row = rows.find(record => record.id === key);
      if (!row) throw Error('MCP install not found');
      for (const [field, value] of Object.entries(patch)) if (value !== undefined) row[field] = value;
      const result = mcpView(row); writeInstalls(dataRoot, rows); return result;
    },
    async deleteMCPInstall(id: unknown, requestSource?: RequestSource) {
      const [key] = admission('deleteMCPInstall', [id], requestSource) as [string];
      const rows = readInstalls(dataRoot); if (!rows.some(row => row.id === key)) return;
      writeInstalls(dataRoot, rows.filter(row => row.id !== key));
    },
  };
}

```
