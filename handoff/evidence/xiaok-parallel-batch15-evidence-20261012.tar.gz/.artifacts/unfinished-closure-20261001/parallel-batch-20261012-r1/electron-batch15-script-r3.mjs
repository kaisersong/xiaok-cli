import{app,BrowserWindow,ipcMain,screen}from'electron';import{writeFile,readFile}from'node:fs/promises';import{join,dirname}from'node:path';import{fileURLToPath}from'node:url';import{createServer}from'node:http';
import{ShutdownAwareIpcMain,DesktopShutdownGate}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/shutdown-aware-ipc-main.js";import{isTrustedDesktopRendererUrl,buildBrowserWindowOptions}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/security.js";import{createMeetingRecorderWindowController}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-recorder-window.js";
import{registerSkillMutationIpc}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/skill-mutation-typed-ipc.js";import{runDesktopSkillMutation}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/desktop-skill-mutation.js";import{registerChannelMcpMutationIpc}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/channel-mcp-mutation-typed-ipc.js";import{createChannelMcpMutationOwner}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/channel-mcp-mutation-owner.js";import{registerMeetingMutationIpc}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-mutation-typed-ipc.js";import{createMeetingMutationService}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-mutation-service.js";import{registerComputerUseCapabilityReadonlyIpc,registerKswarmStatusReadonlyIpc}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/runtime-status-readonly-typed-ipc.js";import{MEETING_TRANSCRIBER_MODEL_REGISTRY}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/meeting-model-service.js";import{getSkillCatalogVersion}from "file:///Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/dist/main/desktop/electron/skill-catalog-invalidation.js";
const root="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-batch15-ipc-JEEgeG",rendererFile="/private/var/folders/qk/0759gskn77v_x22b9xqbk_f00000gp/T/xiaok-batch15-ipc-JEEgeG/desktop/dist/renderer/index.html",__dirname=dirname(fileURLToPath(import.meta.url));app.setPath('userData',join(root,'electron-user-data'));const options={dataRoot:join(root,'data')};let mainWindow=null,meetingRecorderController=null,asks=0,requests=0;
const server=createServer((req,res)=>{requests++;res.writeHead(200,{'content-type':'application/json'});res.end('{}')});
const pluginMcpServers=[],computerUseUnavailableError={code:'COMPUTER_USE_NEEDS_ENABLEMENT',message:'owned-source-probe'},computerUseWrapperRegistered=true,computerUseBackend=null,computerUseObserved=false;
const getComputerUseCapabilityStatus = () => {
    const server = pluginMcpServers.find((entry) => entry.name === 'cua-driver' && entry.pluginName === 'cua-computer-use');
    if (computerUseUnavailableError.code === 'COMPUTER_USE_DISABLED_BY_USER') {
        return {
            state: 'disabled_by_user',
            mcpConnected: false,
            wrapperReady: computerUseWrapperRegistered,
            lastError: computerUseUnavailableError.message,
        };
    }
    if (computerUseBackend && server?.connected) {
        return { state: computerUseObserved ? 'ready' : 'connected_no_target', mcpConnected: true, wrapperReady: true };
    }
    if (server?.enabled === false || computerUseUnavailableError.code === 'COMPUTER_USE_NEEDS_ENABLEMENT') {
        return {
            state: 'not_enabled',
            mcpConnected: false,
            wrapperReady: computerUseWrapperRegistered,
            lastError: computerUseUnavailableError.message,
        };
    }
    return {
        state: 'failed',
        mcpConnected: false,
        wrapperReady: computerUseWrapperRegistered,
        lastError: computerUseUnavailableError.message || server?.lastError,
    };
};

function getStatus() {
    return {
        running,
        port: KSWARM_PORT,
        pid: child?.pid ?? null,
        restartCount,
        lastError,
        terminalDegraded,
        persistenceFailStopCount,
        lastPersistenceFailStop,
    };
}

const running=false,KSWARM_PORT=4400,child=null,restartCount=0,lastError=null,terminalDegraded=true,persistenceFailStopCount=2,lastPersistenceFailStop='owned-failure';const kswarmService={getStatus};
const channelMcpMutations=createChannelMcpMutationOwner(options.dataRoot);
const services = { async installSkill(skillName, context) {
        return runDesktopSkillMutation('install', skillName, context, process.cwd());
    }, async uninstallSkill(skillName, context) {
        return runDesktopSkillMutation('uninstall', skillName, context, process.cwd());
    }, getComputerUseCapabilityStatus() {
        return getComputerUseCapabilityStatus();
    }, async createChannel(input, requestSource) {
        return channelMcpMutations.createChannel(input, requestSource);
    }, async updateChannel(id, input, requestSource) {
        return channelMcpMutations.updateChannel(id, input, requestSource);
    }, async deleteChannel(id, requestSource) {
        return channelMcpMutations.deleteChannel(id, requestSource);
    }, async testChannel(channelId, requestSource) {
        return channelMcpMutations.testChannel(channelId, requestSource);
    }, async createMCPInstall(input, requestSource) {
        return channelMcpMutations.createMCPInstall(input, requestSource);
    }, async updateMCPInstall(id, input, requestSource) {
        return channelMcpMutations.updateMCPInstall(id, input, requestSource);
    }, async deleteMCPInstall(id, requestSource) {
        return channelMcpMutations.deleteMCPInstall(id, requestSource);
    } };

// OS permission dependency is an explicit nonprompt surrogate; other facade/file/model helpers are real.
const meetingAudioPermissionService={requestPermission:async()=>{asks++;return{status:'unknown'}}};
const meetingMutations = createMeetingMutationService(meetingAudioPermissionService);

const skillMutationProducers = new Map([
    ['desktop:installSkill', (_event, skillName) => services.installSkill(skillName, { requestSource: 'user' })],
    ['desktop:uninstallSkill', (_event, skillName) => services.uninstallSkill(skillName, { requestSource: 'user' })],
]);

const channelMcpMutationProducers = new Map([
    ['desktop:testChannel', (_event, id) => services.testChannel(id, 'user')],
    ['desktop:createChannel', (_event, input) => services.createChannel(input, 'user')],
    ['desktop:updateChannel', (_event, id, input) => services.updateChannel(id, input, 'user')],
    ['desktop:deleteChannel', (_event, id) => services.deleteChannel(id, 'user')],
    ['desktop:createMCPInstall', (_event, input) => services.createMCPInstall(input, 'user')],
    ['desktop:updateMCPInstall', (_event, id, input) => services.updateMCPInstall(id, input, 'user')],
    ['desktop:deleteMCPInstall', (_event, id) => services.deleteMCPInstall(id, 'user')],
]);

const meetingMutationProducers = new Map([
    ['desktop:meeting:requestMicrophonePermission', () => meetingMutations.requestMicrophonePermission('user')],
    ['desktop:meeting:saveAsrConfig', (_event, input) => meetingMutations.saveAsrConfig(input, 'user')],
    ['desktop:meeting:downloadModel', (_event, id) => meetingMutations.downloadModel(id, 'user')],
    ['desktop:meeting:uninstallModel', (_event, id) => meetingMutations.uninstallModel(id, 'user')],
]);

function authorizeDesktopInvoke(event) {
    try {
        const sender = event.sender;
        if (!sender || sender.isDestroyed())
            throw new Error('desktop_user_sender_forbidden');
        const ownedMain = mainWindow && !mainWindow.isDestroyed() && sender === mainWindow.webContents;
        if (!ownedMain && meetingRecorderController?.ownsWebContents(sender) !== true) {
            throw new Error('desktop_user_sender_forbidden');
        }
        const frame = event.senderFrame;
        if (!frame || frame !== sender.mainFrame || !isTrustedDesktopRendererUrl(frame.url, {
            rendererFile: join(__dirname, '../../../renderer/index.html'),
            devServer: process.env['XIAOK_DESKTOP_DEV_SERVER'],
        }))
            throw new Error('desktop_user_sender_forbidden');
    }
    catch {
        // Teardown failures are unavailable caller facts, never an admission grant.
        throw new Error('desktop_user_sender_forbidden');
    }
}

const gate=new DesktopShutdownGate(),shutdownAwareIpc=new ShutdownAwareIpcMain(ipcMain,gate,authorizeDesktopInvoke),results=[];registerSkillMutationIpc(shutdownAwareIpc,skillMutationProducers);registerChannelMcpMutationIpc(shutdownAwareIpc,channelMcpMutationProducers);registerMeetingMutationIpc(shutdownAwareIpc,meetingMutationProducers);
registerComputerUseCapabilityReadonlyIpc(shutdownAwareIpc, () => services.getComputerUseCapabilityStatus());

registerKswarmStatusReadonlyIpc(shutdownAwareIpc, () => kswarmService.getStatus());

const methods=['getComputerUseCapabilityStatus','kswarmGetStatus','installSkill','uninstallSkill','createChannel','updateChannel','testChannel','deleteChannel','createMCPInstall','updateMCPInstall','deleteMCPInstall','meetingRequestMicrophonePermission','meetingSaveAsrConfig','meetingUninstallModel','meetingDownloadModel'];
const verify=(v,reason)=>{if(!v)throw Error(reason)};
async function call(window,role,method,args){const expression='window.xiaokDesktop.'+method+'(...'+JSON.stringify(args)+').then(value=>({ok:true,value}),error=>({ok:false,error:String(error)}))';const reply=await window.webContents.executeJavaScript(expression);results.push({role,method,reply});return reply;}
app.whenReady().then(async()=>{try{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const url='http://127.0.0.1:'+server.address().port+'/owned';await writeFile(join(root,'config/config.json'),JSON.stringify({schemaVersion:2,providers:{},models:[],future:{preserved:true},channels:{}}));const opts=buildBrowserWindowOptions("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",{platform:process.platform});mainWindow=new BrowserWindow({...opts,show:false});await mainWindow.loadFile(rendererFile);meetingRecorderController=createMeetingRecorderWindowController({BrowserWindow,getMainWindow:()=>mainWindow,notificationPort:{show:async()=>({ok:true})},platform:process.platform,preloadPath:"/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop/electron/preload.cjs",rendererFile,screen});await meetingRecorderController.open({collectionId:'owned-batch15'});const recorder=BrowserWindow.getAllWindows().find(w=>meetingRecorderController.ownsWebContents(w.webContents));verify(!!recorder,'recorder_missing');
const unknown=new BrowserWindow({...opts,show:false});await unknown.loadFile(rendererFile);const old=mainWindow;mainWindow=new BrowserWindow({...opts,show:false});await mainWindow.loadFile(rendererFile);
for(const[role,window]of[['unknown-same-url',unknown],['old-main',old]])for(const method of methods){const reply=await call(window,role,method,[]);verify(!reply.ok&&reply.error.includes('desktop_user_sender_forbidden'),'unowned_admitted_'+method)}
for(const[role,window]of[['replacement-main',mainWindow],['recorder',recorder]]){let reply=await call(window,role,'getComputerUseCapabilityStatus',[]);verify(reply.ok&&reply.value.state==='not_enabled','capability_failed');reply=await call(window,role,'kswarmGetStatus',[]);verify(reply.ok&&Object.keys(reply.value).length===8&&reply.value.terminalDegraded&&reply.value.persistenceFailStopCount===2,'sdk_full8_failed');for(const method of ['installSkill','uninstallSkill']){reply=await call(window,role,method,['owned-skill']);verify(reply.ok&&reply.value.success,'skill_failed');}reply=await call(window,role,'createChannel',[{type:'owned',name:role,webhookUrl:url,appSecret:'owned-fake-secret'}]);verify(reply.ok&&reply.value.name===role&&!JSON.stringify(reply).includes('owned-fake-secret'),'channel_create_failed');reply=await call(window,role,'updateChannel',['owned',{enabled:false}]);verify(reply.ok&&reply.value.enabled===false,'channel_update_failed');reply=await call(window,role,'testChannel',['owned']);verify(reply.ok&&reply.value.success,'channel_test_failed');reply=await call(window,role,'deleteChannel',['owned']);verify(reply.ok&&reply.value===undefined,'channel_delete_failed');reply=await call(window,role,'createMCPInstall',[{name:role,source:'local',command:'owned-command',args:['--owned','']}]);verify(reply.ok&&reply.value.args.length===2,'mcp_create_failed');const id=reply.value.id;reply=await call(window,role,'updateMCPInstall',[id,{enabled:false,args:['','--new']}]);verify(reply.ok&&reply.value.args[0]===''&&!reply.value.enabled,'mcp_update_failed');reply=await call(window,role,'deleteMCPInstall',[id]);verify(reply.ok&&reply.value===undefined,'mcp_delete_failed');reply=await call(window,role,'meetingRequestMicrophonePermission',[]);verify(reply.ok&&reply.value.status==='unknown','permission_surrogate_failed');reply=await call(window,role,'meetingSaveAsrConfig',[{defaultProvider:'aliyun-asr',aliyun:{apiKey:'owned-fake-asr-secret',baseUrl:'https://owned.invalid',model:'owned-model'}}]);verify(reply.ok&&reply.value.aliyun.configured&&!JSON.stringify(reply).includes('owned-fake-asr-secret'),'asr_save_failed');reply=await call(window,role,'meetingUninstallModel',[MEETING_TRANSCRIBER_MODEL_REGISTRY[0].id]);verify(reply.ok&&reply.value.model.status==='not_downloaded','owned_model_uninstall_failed');reply=await call(window,role,'meetingDownloadModel',['never-a-registry-id']);verify(!reply.ok&&reply.error.includes('meeting_mutation_input_invalid'),'unknown_model_rejection_failed');}
verify(gate.outstanding===0&&asks===2&&requests===2,'token_or_effect_counts_changed');const argv=await readFile(join(root,'clawhub-argv.log'),'utf8');verify(argv.split('\n').filter(Boolean).length===8,'owned_cli_argv_changed');const stored=JSON.parse(await readFile(join(root,'config/config.json'),'utf8'));verify(stored.future.preserved,'non_target_config_lost');await writeFile("/Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/.artifacts/unfinished-closure-20261001/parallel-batch-20261012-r1/electron-batch15-probe-r3.json",JSON.stringify({actualElectron:true,actualExtractedAuthorizer:true,actualExtractedProducerMaps:true,actualExtractedServiceDelegates:true,realCompiledRegistrarsFacadesFileHelpers:true,actualSandboxCjs:true,actualRecorderController:true,sdkCachedVariableBindingsExplicitSurrogates:true,OSPermissionExplicitSurrogate:true,normalInstalledClawhubClaim:false,normalModelDownloadClaim:false,normalSdkConstructorClaim:false,nativeAuthorityClaim:false,wholeUiOrWindowsClaim:false,ownedCliShim:true,results,asks,requests,skillCatalogVersion:getSkillCatalogVersion(),tokenOutstanding:gate.outstanding},null,2));meetingRecorderController.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();await new Promise(resolve=>server.close(resolve));app.quit();}catch(error){console.error(error);meetingRecorderController?.dispose();for(const w of BrowserWindow.getAllWindows())w.destroy();server.close();app.exit(1);}}).catch(error=>{console.error(error);app.exit(1)});
