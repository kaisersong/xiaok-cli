import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd(), desktop = resolve(root, 'desktop');
const ts = (await import(pathToFileURL(resolve(desktop, 'node_modules/typescript/lib/typescript.js')).href)).default;
const sha = value => createHash('sha256').update(value).digest('hex');
const firstReads = new Map();
const read = path => {
  let value;
  try { value = readFileSync(path, 'utf8'); } catch { return undefined; }
  if (!firstReads.has(path)) firstReads.set(path, sha(value));
  return value;
};
const mainTests = ['skill-mutation-controls','skill-mutation-preload','channel-mcp-mutation-controls','meeting-mutation-controls','meeting-mutation-model-lifecycle','meeting-mutation-candidate-controls','runtime-status-readonly-controls','meeting-readonly-controls','meeting-readonly-model-io','meeting-readonly-output-boundary','meeting-readonly-preload','meeting-model-service','meeting-audio-permission','meeting-punctuation-service','meeting-punctuation-worker','meeting-sherpa-onnx-transcriber','meeting-local-transcriber','channel-mcp-readonly-controls','channel-mcp-readonly-preload', 'skills-readonly-edge-controls', 'skills-readonly-preload', 'skills-readonly-controls', 'skill-discovery-observation', 'diagnostics-ipc-business', 'diagnostics-ipc-contract', 'ipc-native-promise-sibling', 'automation-config-main-controls', 'automation-config-persistence', 'automation-config-contract', 'automation-overview', 'meeting-asr-config', 'mobile-signin-main-controls', 'mobile-signin-contract', 'service-control-main-controls', 'service-control-facade', 'service-control-sdk-characterization', 'service-control-preload', 'kswarm-service', 'kswarm-service-diagnostics', 'kswarm-runtime-bridge', 'kswarm-instance-drain', 'e2e-kswarm-desktop-runtime-bridge', 'mobile-gateway', 'mobile-relay', 'mobile-relay-credentials', 'mobile-snapshot', 'mobile-readonly-main-controls', 'mobile-readonly-output-boundary', 'mobile-readonly-preload', 'desktop-invoke-admission', 'ipc-registrar-contract', 'meeting-service-permissions', 'updater', 'updater-handoff', 'updater-integration', 'updater-owner-state', 'updater-source-authority', 'updater-main-controls', 'updater-output-boundary', 'updater-preload', 'preload-contract', 'preload-sandbox', 'plugin-catalog-characterization', 'plugin-catalog-main-controls', 'plugin-catalog-preload', 'ipc-schema-coverage'];
const rendererTests = ['channel-mcp-mutation-ui','runtime-status-readonly-context','project-workflow-status','meeting-readonly-consumers','channel-mcp-readonly-consumers', 'skills-readonly-consumers', 'skill-prerequisite-controls', 'automation-config-consistency', 'automations-navigation', 'desktop-settings-loops', 'welcome-page-home', 'welcome-page-quick-prompts', 'mobile-signin-action', 'service-control-read-errors', 'desktop-settings-service-status', 'mobile-readonly-consistency', 'sidebar-update-reminder', 'desktop-settings-update-handoff', 'updater-read-failure', 'updater-sidebar-facts', 'plugin-catalog-read-errors', 'plugin-catalog-mcp-read-errors'];
const results = [];
for (const [config, additions] of [
  ['tsconfig.electron.json', mainTests.map(name => resolve(desktop, 'tests/main', name + '.test.ts'))],
  ['tsconfig.renderer.json', [resolve(desktop,'tests/renderer/skill-mutation-bridge.test.ts'),resolve(desktop,'tests/renderer/meeting-readonly-bridge.test.ts'),resolve(desktop,'tests/renderer/channel-mcp-readonly-bridge.test.ts'), resolve(desktop,'tests/renderer/skills-readonly-bridge.test.ts'), resolve(desktop, 'tests/setup.ts'), resolve(desktop, 'renderer/src/components/settings/PluginsSettings.tsx'), ...rendererTests.map(name => resolve(desktop, 'tests/renderer', name + '.test.tsx')), resolve(desktop,'tests/renderer/welcome-home-source-contract.test.ts'), resolve(desktop,'tests/renderer/welcome-home-projection.test.ts'), resolve(desktop,'tests/renderer/kimi-k3-d9-automation-contract.test.tsx'), resolve(desktop,'renderer/src/components/SkillsSettingsContent.tsx'), resolve(desktop,'renderer/src/components/skills/InstalledSkillsView.tsx'), resolve(desktop,'renderer/src/components/skills/SkillList.tsx'), resolve(desktop,'renderer/src/components/skills/SkillDetailModal.tsx'), resolve(desktop,'renderer/src/components/skills/BuiltinSkillsView.tsx'), resolve(desktop,'renderer/src/components/ChatInput.tsx')]],
]) {
  const path = resolve(desktop, config);
  const loaded = ts.readConfigFile(path, read);
  const parsed = ts.parseJsonConfigFileContent(loaded.config, { ...ts.sys, readFile: read }, desktop, {}, path);
  const options = { ...parsed.options, noCheck: false, noEmit: true, incremental: false, allowImportingTsExtensions: config === 'tsconfig.electron.json' };
  const host = ts.createCompilerHost(options); host.readFile = read;
  const roots = [...new Set([...parsed.fileNames, ...additions])];
  const program = ts.createProgram({ rootNames: roots, options, host });
  const diagnostics = [...(loaded.error ? [loaded.error] : []), ...parsed.errors, ...ts.getPreEmitDiagnostics(program)];
  const messages = diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'));
  console.log(config, roots.length, program.getSourceFiles().length, 'diagnostics', diagnostics.length);
  if (diagnostics.length) console.log(ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCurrentDirectory: () => root, getCanonicalFileName: path => path, getNewLine: () => '\n' }));
  results.push({ config, rootCount: roots.length, sourceCount: program.getSourceFiles().length, additionalActualTestRoots: additions, options, diagnostics: messages });
}
const reads = [...firstReads].map(([path, before]) => ({ path, before, after: sha(readFileSync(path, 'utf8')) }));
const result = { actualSource: true, virtualOverlay: false, customModuleResolver: false, fullOriginalConfigRoots: true, results, reads, drift: reads.filter(row => row.before !== row.after) };
writeFileSync(process.argv[2], JSON.stringify(result, null, 2), { flag: 'wx' });
process.exitCode = results.some(row => row.diagnostics.length) || result.drift.length ? 1 : 0;
