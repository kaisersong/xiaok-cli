
## FULL desktop/electron/channel-mcp-mutation-typed-ipc.ts
```typescript
// UNREVIEWED CANDIDATE — install at desktop/electron only after owner DESIGN approval.
import { types } from 'node:util';
import { z } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { CHANNEL_MCP_MUTATION_METHODS, CHANNEL_MCP_MUTATION_INPUTS, CHANNEL_MCP_MUTATION_OUTPUTS, CHANNEL_MCP_MUTATION_RISKS } from '../shared/channel-mcp-mutation-ipc-contract.js';
const isPromise = types.isPromise, NativePromise = Promise, nativeThen = Promise.prototype.then, apply = Reflect.apply;
const owners = new WeakMap<IpcHandleRegistrar, ReadonlyMap<string, IpcHandlerListener> | null>();
export function registerChannelMcpMutationIpc(ipc: IpcHandleRegistrar, rawProducers?: ReadonlyMap<string, IpcHandlerListener>): void {
  const producers = rawProducers ?? null;
  if (owners.has(ipc)) { if (owners.get(ipc) !== producers) throw Error('channel_mcp_mutation_registrar_owner_conflict'); return; }
  for (const method of CHANNEL_MCP_MUTATION_METHODS) {
    const channel = 'desktop:' + method, output = CHANNEL_MCP_MUTATION_OUTPUTS[method];
    const capture = (raw: unknown) => {
      const value = captureIpcData(raw, 'channel_mcp_mutation_projection_unavailable');
      if (!output.safeParse(value).success) throw Error('channel_mcp_mutation_projection_unavailable');
      return value;
    };
    registerIpcHandler<unknown[], unknown>({
      registrar: ipc, channel, output, payloadMode: 'tuple', rolloutRound: 34,
      sourceFile: 'desktop/electron/channel-mcp-mutation-typed-ipc.ts', riskTags: [...CHANNEL_MCP_MUTATION_RISKS[method]],
      input: z.custom<unknown[]>(() => true).transform(raw => {
        const value = captureIpcData(raw, 'channel_mcp_mutation_input_invalid');
        if (!CHANNEL_MCP_MUTATION_INPUTS[method].safeParse(value).success) throw Error('channel_mcp_mutation_input_invalid');
        return value;
      }),
      handler: async (args, event) => {
        const producer = producers?.get(channel);
        if (!producer) throw Error('channel_mcp_mutation_runtime_unavailable');
        const result = producer(event, ...args);
        if (!isPromise(result)) return capture(result);
        assertStandardIpcPromise(result, 'channel_mcp_mutation_projection_unavailable');
        return new NativePromise((resolve, reject) => apply(nativeThen, result, [(value: unknown) => {
          try { resolve(capture(value)); } catch (error) { reject(error); }
        }, reject]));
      },
    });
  }
  owners.set(ipc, producers);
}

```

## FULL desktop/electron/desktop-skill-mutation.ts
```typescript
import crossSpawn from 'cross-spawn';
import { SKILL_MUTATION_NAME_SCHEMA, type DesktopSkillMutationContext, type DesktopSkillMutationResult } from '../shared/skill-mutation-ipc-contract.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { bumpSkillCatalogVersion } from './skill-catalog-invalidation.js';
// Main supplies cwd. No renderer-controlled roots, shell text, flags or source.
// Keep the existing synchronous command, deadlines and success/failure DTO.
export function runDesktopSkillMutation(operation: 'install' | 'uninstall', rawName: unknown,
  rawContext: DesktopSkillMutationContext, cwd: string): DesktopSkillMutationResult {
  const context = captureIpcData(rawContext, 'skill_mutation_source_forbidden');
  if (context?.requestSource !== 'user') throw Error('skill_mutation_source_forbidden');
  const input = captureIpcData(rawName, 'skill_mutation_input_invalid');
  if (!SKILL_MUTATION_NAME_SCHEMA.safeParse(input).success) throw Error('skill_mutation_input_invalid');
  const skillName = input as string;
  // cross-spawn handles Windows .cmd shims and argv escaping; no manual shell interpolation.
  const result = crossSpawn.sync('clawhub', [operation, skillName], {
    encoding: 'utf-8', timeout: operation === 'install' ? 60000 : 30000, cwd,
  });
  if (result.error) return { success: false, message: `执行失败: ${result.error.message}` };
  if (result.status !== 0) {
    const message = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
    return { success: false, message: message.slice(0, 500) };
  }
  bumpSkillCatalogVersion();
  return { success: true, message: `技能 ${skillName} 已${operation === 'install' ? '安装' : '卸载'}` };
}

```

## FULL desktop/electron/meeting-mutation-service.ts
```typescript
import { types } from 'node:util';
import { saveConfig } from '../../src/utils/config.js';
import { applyMeetingAsrConfigUpdate, createMeetingAsrConfigSnapshot } from './meeting-asr-config.js';
import { readMeetingAsrConfig } from './meeting-readonly-data.js';
import { createMeetingModelService, MEETING_TRANSCRIBER_MODEL_REGISTRY } from './meeting-model-service.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { MEETING_SAVE_INPUT_SCHEMA, MEETING_MUTATION_ASR_OUTPUT_SCHEMA } from '../shared/meeting-mutation-ipc-contract.js';
import type { MeetingAudioPermissionResult } from './meeting-audio-permission.js';
const nativeThen = Promise.prototype.then;
export function createMeetingMutationService(permission: { requestPermission(): Promise<MeetingAudioPermissionResult> }) {
  let models: ReturnType<typeof createMeetingModelService> | undefined;
  let pendingPermission: Promise<MeetingAudioPermissionResult> | undefined;
  const authorize = (source: unknown) => { if (source !== 'user') throw Error('meeting_mutation_request_source_forbidden'); };
  const modelId = (id: unknown): string => {
    if (typeof id !== 'string' || !MEETING_TRANSCRIBER_MODEL_REGISTRY.some(model => model.id === id)) throw Error('meeting_mutation_input_invalid');
    return id;
  };
  return {
    async requestMicrophonePermission(source?: 'user' | 'agent' | 'scheduler') {
      authorize(source);
      if (pendingPermission) return pendingPermission;
      const operation = permission.requestPermission();
      assertStandardIpcPromise(operation, 'meeting_mutation_projection_unavailable');
      pendingPermission = operation;
      try { return await operation; } finally { pendingPermission = undefined; }
    },
    async saveAsrConfig(input: unknown, source?: 'user' | 'agent' | 'scheduler') {
      authorize(source);
      const snapshot = captureIpcData(input ?? {}, 'meeting_mutation_input_invalid');
      const parsed = MEETING_SAVE_INPUT_SCHEMA.safeParse(snapshot);
      if (!parsed.success) throw Error('meeting_mutation_input_invalid');
      try {
        // No await between truthful read / semantic edit / synchronous saveConfig body.
        const config = applyMeetingAsrConfigUpdate(readMeetingAsrConfig(), parsed.data);
        const projected = captureIpcData(createMeetingAsrConfigSnapshot(config), 'meeting_mutation_save_failed');
        if (!MEETING_MUTATION_ASR_OUTPUT_SCHEMA.safeParse(projected).success) throw Error('meeting_mutation_save_failed');
        const result = saveConfig(config);
        assertStandardIpcPromise(result, 'meeting_mutation_save_failed');
        await new Promise<void>((resolve, reject) => Reflect.apply(nativeThen, result, [resolve, reject]));
        return projected;
      } catch { throw Error('meeting_mutation_save_failed'); }
    },
    async downloadModel(id: unknown, source?: 'user' | 'agent' | 'scheduler') {
      authorize(source); const known = modelId(id);
      return (models ??= createMeetingModelService()).downloadModel(known);
    },
    async uninstallModel(id: unknown, source?: 'user' | 'agent' | 'scheduler') {
      authorize(source); const known = modelId(id);
      return (models ??= createMeetingModelService()).uninstallModel(known);
    },
  };
}
// Only fixed domain codes can cross the error transport. Never access error.message.
export function meetingMutationError(error: unknown): Error {
  const descriptor = error && typeof error === 'object' && !types.isProxy(error) ? Object.getOwnPropertyDescriptor(error, 'message') : undefined;
  const value = descriptor && 'value' in descriptor ? descriptor.value : undefined;
  const allowed = ['meeting_mutation_input_invalid', 'meeting_mutation_request_source_forbidden', 'meeting_mutation_save_failed', 'meeting_mutation_projection_unavailable', 'meeting_model_busy', 'size_mismatch', 'hash_mismatch', 'model_package_incomplete'];
  return Error(typeof value === 'string' && allowed.includes(value) ? value : 'meeting_mutation_action_failed');
}

```

## FULL desktop/electron/meeting-mutation-typed-ipc.ts
```typescript
import { types } from 'node:util';
import { z } from 'zod';
import { registerIpcHandler } from './ipc-runtime.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { meetingMutationError } from './meeting-mutation-service.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { MEETING_MUTATION_METHODS, MEETING_MUTATION_INPUT_SCHEMAS, MEETING_MUTATION_OUTPUT_SCHEMAS } from '../shared/meeting-mutation-ipc-contract.js';
const nativeThen = Promise.prototype.then;
const owners = new WeakMap<IpcHandleRegistrar, ReadonlyMap<string, IpcHandlerListener>>();
export function registerMeetingMutationIpc(ipc: IpcHandleRegistrar, producers: ReadonlyMap<string, IpcHandlerListener>): void {
  if (owners.has(ipc)) { if (owners.get(ipc) !== producers) throw Error('meeting_mutation_registrar_owner_conflict'); return; }
  // Detach producer bindings once; do not trust subsequent Map mutation.
  const bindings = new Map(producers);
  for (const method of MEETING_MUTATION_METHODS) {
    const channel = 'desktop:meeting:' + method, output = MEETING_MUTATION_OUTPUT_SCHEMAS[method];
    const capture = (raw: unknown) => {
      const value = captureIpcData(raw, 'meeting_mutation_projection_unavailable');
      if (!output.safeParse(value).success) throw Error('meeting_mutation_projection_unavailable');
      return value;
    };
    registerIpcHandler<unknown[], unknown>({ registrar: ipc, channel,
      input: z.custom<unknown[]>(() => true).transform(raw => {
        const value = captureIpcData(raw, 'meeting_mutation_input_invalid');
        if (!MEETING_MUTATION_INPUT_SCHEMAS[method].safeParse(value).success) throw Error('meeting_mutation_input_invalid');
        return value;
      }), output, payloadMode: 'tuple', rolloutRound: 34,
      riskTags: method === 'requestMicrophonePermission' ? ['dialog'] : method === 'saveAsrConfig' ? ['fs-write'] : method === 'downloadModel' ? ['network', 'fs-write'] : ['fs-delete'],
      sourceFile: 'desktop/electron/meeting-mutation-typed-ipc.ts',
      handler: async (args, event) => {
        const producer = bindings.get(channel); if (!producer) throw Error('meeting_mutation_runtime_unavailable');
        try {
          const result = producer(event, ...args);
          if (!types.isPromise(result)) return capture(result);
          assertStandardIpcPromise(result, 'meeting_mutation_projection_unavailable');
          return await new Promise((resolve, reject) => Reflect.apply(nativeThen, result, [(value: unknown) => { try { resolve(capture(value)); } catch (error) { reject(error); } }, reject]));
        } catch (error) { throw meetingMutationError(error); }
      },
    });
  }
  owners.set(ipc, producers);
}

```

## FULL desktop/electron/runtime-status-readonly-typed-ipc.ts
```typescript
import { types } from 'node:util';
import { z, type ZodType } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { COMPUTER_USE_STATUS_SCHEMA, KSWARM_STATUS_SCHEMA, RUNTIME_STATUS_INPUT_SCHEMA } from '../shared/runtime-status-readonly-ipc-contract.js';
const isPromise = types.isPromise, NativePromise = Promise, nativeThen = Promise.prototype.then, apply = Reflect.apply;
const capabilityOwners = new WeakMap<IpcHandleRegistrar, IpcHandlerListener | undefined>();
const sdkOwners = new WeakMap<IpcHandleRegistrar, IpcHandlerListener | undefined>();
function registerStatus(ipc: IpcHandleRegistrar, channel: string, output: ZodType, owners: WeakMap<IpcHandleRegistrar, IpcHandlerListener | undefined>, producer?: IpcHandlerListener) {
  if (owners.has(ipc)) { if (owners.get(ipc) !== producer) throw Error('runtime_status_registrar_owner_conflict'); return; }
  const capture = (raw: unknown) => {
    const value = captureIpcData(raw, 'runtime_status_projection_unavailable');
    if (!output.safeParse(value).success) throw Error('runtime_status_projection_unavailable');
    return value;
  };
  registerIpcHandler<unknown[], unknown>({
    registrar: ipc, channel, output, payloadMode: 'tuple', rolloutRound: 34, riskTags: [], sourceFile: 'desktop/electron/runtime-status-readonly-typed-ipc.ts',
    input: z.custom<unknown[]>(() => true).transform(raw => {
      const value = captureIpcData(raw, 'runtime_status_input_invalid');
      if (!RUNTIME_STATUS_INPUT_SCHEMA.safeParse(value).success) throw Error('runtime_status_input_invalid');
      return value;
    }),
    handler: async (args, event) => {
      if (!producer) throw Error('runtime_status_runtime_unavailable');
      const result = producer(event, ...args);
      if (!isPromise(result)) return capture(result);
      assertStandardIpcPromise(result, 'runtime_status_projection_unavailable');
      return new NativePromise((resolve, reject) => apply(nativeThen, result, [(value: unknown) => { try { resolve(capture(value)); } catch (error) { reject(error); } }, reject]));
    },
  });
  owners.set(ipc, producer);
}
export function registerComputerUseCapabilityReadonlyIpc(ipc: IpcHandleRegistrar, producer?: IpcHandlerListener) { registerStatus(ipc, 'desktop:getComputerUseCapabilityStatus', COMPUTER_USE_STATUS_SCHEMA, capabilityOwners, producer); }
export function registerKswarmStatusReadonlyIpc(ipc: IpcHandleRegistrar, producer?: IpcHandlerListener) { registerStatus(ipc, 'desktop:kswarm:getStatus', KSWARM_STATUS_SCHEMA, sdkOwners, producer); }

```

## FULL desktop/electron/skill-mutation-typed-ipc.ts
```typescript
import { z } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { SKILL_MUTATION_INPUT_SCHEMA, SKILL_MUTATION_OUTPUT_SCHEMA } from '../shared/skill-mutation-ipc-contract.js';
const NativePromise = Promise, nativeThen = Promise.prototype.then, apply = Reflect.apply;
type Producers = ReadonlyMap<string, IpcHandlerListener>;
const owners = new WeakMap<IpcHandleRegistrar, Producers | null>();
export function registerSkillMutationIpc(ipc: IpcHandleRegistrar, rawProducers?: Producers): void {
  const producers = rawProducers ?? null;
  if (owners.has(ipc)) { if (owners.get(ipc) !== producers) throw Error('skill_mutation_registrar_owner_conflict'); return; }
  for (const channel of ['desktop:installSkill', 'desktop:uninstallSkill']) {
    registerIpcHandler<unknown[], unknown>({ registrar: ipc, channel,
      input: z.custom<unknown[]>(() => true).transform(raw => {
        const snapshot = captureIpcData(raw, 'skill_mutation_input_invalid');
        if (!SKILL_MUTATION_INPUT_SCHEMA.safeParse(snapshot).success) throw Error('skill_mutation_input_invalid');
        return snapshot;
      }), output: SKILL_MUTATION_OUTPUT_SCHEMA, payloadMode: 'tuple', rolloutRound: 34,
      riskTags: channel === 'desktop:installSkill' ? ['external-process', 'network', 'fs-write'] : ['external-process', 'fs-delete'],
      sourceFile: 'desktop/electron/skill-mutation-typed-ipc.ts',
      handler: async (args, event) => {
        const producer = producers?.get(channel);
        if (!producer) throw Error('skill_mutation_runtime_unavailable');
        const result = producer(event, ...args);
        assertStandardIpcPromise(result, 'skill_mutation_output_invalid');
        return new NativePromise((resolve, reject) => apply(nativeThen, result, [(value: unknown) => {
          try {
            const snapshot = captureIpcData(value, 'skill_mutation_output_invalid');
            if (!SKILL_MUTATION_OUTPUT_SCHEMA.safeParse(snapshot).success) throw Error('skill_mutation_output_invalid');
            resolve(snapshot);
          } catch (error) { reject(error); }
        }, reject]));
      },
    });
  }
  owners.set(ipc, producers);
}

```

## FULL desktop/renderer/src/hooks/useKswarmStatusReadonly.ts
```typescript
import { useCallback, useEffect, useRef, useState } from 'react';
import { getDesktopApi } from '../shared/desktop';
import { KSWARM_STATUS_SCHEMA, type KswarmReadonlyStatus } from '../../../shared/runtime-status-readonly-ipc-contract';
type Owner = { active: boolean; busy: boolean; queued: boolean; events: number };
export function useKswarmStatusReadonly() {
  const [data, setData] = useState<KswarmReadonlyStatus | null>(null), [failed, setFailed] = useState(false), [reading, setReading] = useState(true);
  const lifetime = useRef<Owner | null>(null);
  const runRef = useRef<(owner: Owner) => void>(() => {});
  const run = useCallback((owner: Owner) => {
    if (!owner.active || lifetime.current !== owner) return;
    owner.busy = true; setReading(true); const events = owner.events;
    void (async () => {
      try {
        const desktop = getDesktopApi();
        if (!desktop?.kswarmGetStatus) throw Error('runtime_status_runtime_unavailable');
        const value = await desktop.kswarmGetStatus(), parsed = KSWARM_STATUS_SCHEMA.safeParse(value);
        if (!parsed.success) throw Error('runtime_status_projection_unavailable');
        if (owner.active && lifetime.current === owner && owner.events === events) { setData(parsed.data); setFailed(false); }
      } catch {
        if (owner.active && lifetime.current === owner && owner.events === events) setFailed(true);
      } finally {
        if (owner.active && lifetime.current === owner) {
          owner.busy = false; setReading(false);
          if (owner.queued) { owner.queued = false; runRef.current(owner); }
        }
      }
    })();
  }, []);
  runRef.current = run;
  const refresh = useCallback(() => {
    const owner = lifetime.current;
    if (!owner?.active) return;
    if (owner.busy) { owner.queued = true; return; }
    runRef.current(owner);
  }, []);
  useEffect(() => {
    const owner: Owner = { active: true, busy: false, queued: false, events: 0 }; lifetime.current = owner;
    let unsubscribe: (() => void) | undefined;
    try {
      const desktop = getDesktopApi();
      if (desktop?.onKSwarmStatus) unsubscribe = desktop.onKSwarmStatus(value => {
        if (!owner.active || lifetime.current !== owner) return;
        owner.events++;
        const parsed = KSWARM_STATUS_SCHEMA.safeParse(value);
        if (!parsed.success) { setFailed(true); return; }
        setData(parsed.data); setFailed(false);
      });
    } catch { setFailed(true); }
    refresh();
    return () => { owner.active = false; owner.queued = false; unsubscribe?.(); };
  }, [refresh]);
  return { data, failed, reading, refresh };
}

```

## FULL desktop/shared/channel-mcp-mutation-ipc-contract.ts
```typescript
// UNREVIEWED CANDIDATE — install at desktop/shared only after owner DESIGN approval.
import { z } from 'zod';
import { CHANNEL_READONLY_OUTPUT_SCHEMA, MCP_INSTALLS_READONLY_OUTPUT_SCHEMA } from './channel-mcp-readonly-ipc-contract.js';
export const CHANNEL_MCP_MUTATION_METHODS = ['createChannel', 'updateChannel', 'deleteChannel', 'testChannel', 'createMCPInstall', 'updateMCPInstall', 'deleteMCPInstall'] as const;
export type ChannelMcpMutationMethod = typeof CHANNEL_MCP_MUTATION_METHODS[number];
const key = z.string().min(1).refine(v => !['__proto__', 'prototype', 'constructor'].includes(v));
const credentials = { appId: z.string().optional(), appSecret: z.string().optional(), token: z.string().optional(), botToken: z.string().optional(), chatId: z.string().optional() };
const channelFields = { name: z.string(), webhookUrl: z.string().optional(), ...credentials };
const createChannel = z.object({ type: key, ...channelFields }).strict();
const updateChannel = z.object({ type: key.optional(), ...channelFields, enabled: z.boolean() }).partial().strict();
const mcpFields = { name: z.string(), source: z.enum(['npm', 'github', 'local']), command: z.string().min(1), args: z.array(z.string()).optional() };
const createMcp = z.object(mcpFields).strict();
const updateMcp = z.object({ ...mcpFields, enabled: z.boolean() }).partial().strict();
export const CHANNEL_MCP_MUTATION_INPUTS = {
  createChannel: z.tuple([createChannel]), updateChannel: z.tuple([key, updateChannel]), deleteChannel: z.tuple([key]), testChannel: z.tuple([key]),
  createMCPInstall: z.tuple([createMcp]), updateMCPInstall: z.tuple([key, updateMcp]), deleteMCPInstall: z.tuple([key]),
} as const;
const channel = CHANNEL_READONLY_OUTPUT_SCHEMA.element.extend({ createdAt: z.number().finite(), updatedAt: z.number().finite() });
// Mutation ACK retains original toMCPView columns; stored/read-only rows retain passthrough metadata.
const mcp = MCP_INSTALLS_READONLY_OUTPUT_SCHEMA.element.strict().extend({ createdAt: z.number().finite() });
export const CHANNEL_MCP_MUTATION_OUTPUTS = {
  createChannel: channel, updateChannel: channel, deleteChannel: z.undefined(),
  testChannel: z.object({ success: z.boolean(), latencyMs: z.number().finite().nonnegative().optional(), error: z.string().optional() }).strict(),
  createMCPInstall: mcp, updateMCPInstall: mcp, deleteMCPInstall: z.undefined(),
} as const;
export const CHANNEL_MCP_MUTATION_RISKS = {
  createChannel: ['fs-write'], updateChannel: ['fs-write'], deleteChannel: ['fs-write', 'fs-delete'], testChannel: ['fs-read', 'network'],
  createMCPInstall: ['fs-write-userData'], updateMCPInstall: ['fs-write-userData'], deleteMCPInstall: ['fs-write-userData', 'fs-delete'],
} as const;

```

## FULL desktop/shared/meeting-mutation-ipc-contract.ts
```typescript
import { z } from 'zod';
import { MEETING_PERMISSION_OUTPUT_SCHEMA, MEETING_ASR_OUTPUT_SCHEMA, MEETING_MODELS_OUTPUT_SCHEMA } from './meeting-readonly-ipc-contract.js';
export const MEETING_MUTATION_METHODS = ['requestMicrophonePermission', 'saveAsrConfig', 'downloadModel', 'uninstallModel'] as const;
// Empty strings preserve deletion semantics. Credential-bearing URLs must not
// be returned as public endpoint/baseUrl fields.
export const MEETING_PUBLIC_ENDPOINT_SCHEMA = z.string().refine(value => {
  if (!value.trim()) return true;
  try { const url = new URL(value.trim()); return ['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol) && !url.username && !url.password && !url.search && !url.hash; } catch { return false; }
});
export const MEETING_MUTATION_ASR_OUTPUT_SCHEMA = MEETING_ASR_OUTPUT_SCHEMA.extend({
  volcengine: MEETING_ASR_OUTPUT_SCHEMA.shape.volcengine.extend({ endpoint: MEETING_PUBLIC_ENDPOINT_SCHEMA.optional() }),
  aliyun: MEETING_ASR_OUTPUT_SCHEMA.shape.aliyun.extend({ baseUrl: MEETING_PUBLIC_ENDPOINT_SCHEMA }),
});
export const MEETING_SAVE_INPUT_SCHEMA = z.object({
  defaultProvider: MEETING_ASR_OUTPUT_SCHEMA.shape.defaultProvider.optional(),
  volcengine: z.object({ appKey: z.string().optional(), accessKey: z.string().optional(), endpoint: MEETING_PUBLIC_ENDPOINT_SCHEMA.optional(), resourceId: z.string().optional(), clearAppKey: z.boolean().optional(), clearAccessKey: z.boolean().optional() }).strict().optional(),
  aliyun: z.object({ apiKey: z.string().optional(), baseUrl: MEETING_PUBLIC_ENDPOINT_SCHEMA.optional(), model: z.string().optional(), clearApiKey: z.boolean().optional() }).strict().optional(),
}).strict();
// Preserve the original input ?? {} save behavior; reject surplus transport arguments.
export const MEETING_MUTATION_INPUT_SCHEMAS = {
  requestMicrophonePermission: z.tuple([]),
  saveAsrConfig: z.union([z.tuple([]), z.tuple([MEETING_SAVE_INPUT_SCHEMA.nullish()])]),
  downloadModel: z.tuple([z.string()]),
  uninstallModel: z.tuple([z.string()]),
} as const;
const model = MEETING_MODELS_OUTPUT_SCHEMA.element.extend({ sizeBytes: z.number().finite().nonnegative(), localSizeBytes: z.number().finite().nonnegative().optional() }).strict();
export const MEETING_MODEL_ACTION_OUTPUT_SCHEMA = z.object({ ok: z.literal(true), model }).strict();
export const MEETING_MUTATION_OUTPUT_SCHEMAS = { requestMicrophonePermission: MEETING_PERMISSION_OUTPUT_SCHEMA, saveAsrConfig: MEETING_MUTATION_ASR_OUTPUT_SCHEMA, downloadModel: MEETING_MODEL_ACTION_OUTPUT_SCHEMA, uninstallModel: MEETING_MODEL_ACTION_OUTPUT_SCHEMA } as const;
export type MeetingMutationModelResult = z.infer<typeof MEETING_MODEL_ACTION_OUTPUT_SCHEMA>;

```

## FULL desktop/shared/runtime-status-readonly-ipc-contract.ts
```typescript
import { z } from 'zod';
const number = z.custom<number>(value => typeof value === 'number');
export const RUNTIME_STATUS_INPUT_SCHEMA = z.tuple([]);
export const COMPUTER_USE_STATUS_SCHEMA = z.object({
  state: z.string(), mcpConnected: z.boolean(), wrapperReady: z.boolean(), lastError: z.string().optional(),
}).passthrough();
export const KSWARM_STATUS_SCHEMA = z.object({
  running: z.boolean(), port: number, pid: number.nullable(), restartCount: number, lastError: z.string().nullable(),
  terminalDegraded: z.boolean().optional(), persistenceFailStopCount: number.optional(), lastPersistenceFailStop: z.string().nullable().optional(),
}).passthrough();
export type ComputerUseReadonlyStatus = z.infer<typeof COMPUTER_USE_STATUS_SCHEMA>;
export type KswarmReadonlyStatus = z.infer<typeof KSWARM_STATUS_SCHEMA>;

```

## FULL desktop/shared/skill-mutation-ipc-contract.ts
```typescript
import { z } from 'zod';
// Preserve Unicode and interior spaces/namespace punctuation; do not silently coerce.
// A registry name is one argv operand, not a filesystem path or CLI option.
export const SKILL_MUTATION_NAME_SCHEMA = z.string().min(1).max(512).refine(name =>
  name === name.trim() && !name.startsWith('-') && name !== '.' && name !== '..'
  && !/[\\/\x00-\x1f\x7f]/.test(name) && !/^[A-Za-z]:/.test(name));
export const SKILL_MUTATION_INPUT_SCHEMA = z.tuple([SKILL_MUTATION_NAME_SCHEMA]);
export const SKILL_MUTATION_OUTPUT_SCHEMA = z.object({
  success: z.boolean(), message: z.string(),
}).passthrough();
export type DesktopSkillMutationResult = z.infer<typeof SKILL_MUTATION_OUTPUT_SCHEMA>;
export interface DesktopSkillMutationContext { requestSource: 'user' | 'agent' | 'scheduler' }

```

## FULL desktop/tests/main/channel-mcp-mutation-controls.test.ts
```typescript
// UNREVIEWED RED CANDIDATE. Copy to desktop/tests/main/channel-mcp-mutation-controls.test.ts.
// cd desktop && npm run test -- --run tests/main/channel-mcp-mutation-controls.test.ts
// Production registrar + service + production Main authorizer AST, no reimplemented business logic.
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'channel-mcp-mutation-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}


const methods = ['createChannel','updateChannel','deleteChannel','testChannel','createMCPInstall','updateMCPInstall','deleteMCPInstall'] as const;
type Method = typeof methods[number];
const legitimate: Record<Method, unknown[]> = {
  createChannel:[{type:'owned',name:'Owned',webhookUrl:'https://owned.invalid/path?token=OWNED_SECRET'}],
  updateChannel:['owned',{enabled:false}],deleteChannel:['owned'],testChannel:['owned'],
  createMCPInstall:[{name:'Owned MCP',source:'local',command:'C:\\owned\\command',args:['--owned','']}],
  updateMCPInstall:['owned',{enabled:false}],deleteMCPInstall:['owned'],
};
function seed(f: Awaited<ReturnType<typeof fixture>>) {
  const config=join(f.root,'config');mkdirSync(config,{recursive:true});
  writeFileSync(join(config,'config.json'),JSON.stringify({schemaVersion:2,providers:{private:{apiKey:'OWNED_PROVIDER_SECRET'}},models:{},future:{keep:true},channels:{owned:{name:'Owned',sendMsgUrl:'https://owned.invalid/path?token=OWNED_SECRET',enabled:true,appSecret:'OWNED_APP_SECRET',future:{keep:true}}}}));
  writeFileSync(join(f.data,'mcp-installs.json'),JSON.stringify([{id:'owned',name:'Owned MCP',source:'local',command:'owned-command',args:['--owned',''],enabled:true,createdAt:1,future:{keep:true}}]));
}
it('registers all seven tuple contracts at the actual production registrar', async()=>{
  await fixture();for(const method of methods)expect(IPC_SCHEMA_REGISTRY.get('desktop:'+method)).toMatchObject({payloadMode:'tuple',inputStage:'beforeHandler',sourceFile:'desktop/electron/channel-mcp-mutation-typed-ipc.ts'});
});
it.each(methods)('%s rejects surplus tuple arguments before its service',async method=>{
  const f=await fixture();seed(f);const producer=vi.spyOn(f.service,method);
  await expect(f.invoke(method,...legitimate[method],{})).rejects.toThrow('channel_mcp_mutation_input_invalid');expect(producer).not.toHaveBeenCalled();
});
it.each(methods)('%s rejects accessor inputs without invoking getters or service',async method=>{
  const f=await fixture();seed(f);let reads=0;const input=Object.defineProperty({},'name',{enumerable:true,get(){reads++;return 'Owned'}}),producer=vi.spyOn(f.service,method);
  const args=method.startsWith('update')?['owned',input]:[input];
  await expect(f.invoke(method,...args)).rejects.toThrow('channel_mcp_mutation_input_invalid');expect(reads).toBe(0);expect(producer).not.toHaveBeenCalled();
});
it.each(methods)('%s rejects proxy input without traps or service',async method=>{
  const f=await fixture();seed(f);let traps=0;const input=new Proxy({},{ownKeys(){traps++;throw Error('owned')}}),producer=vi.spyOn(f.service,method);
  await expect(f.invoke(method,...(method.startsWith('update')?['owned',input]:[input]))).rejects.toThrow('channel_mcp_mutation_input_invalid');expect(traps).toBe(0);expect(producer).not.toHaveBeenCalled();
});
it.each(methods)('%s denies absent/agent/scheduler source at the actual service, before disk/network',async method=>{
  const f=await fixture();seed(f);const config=join(f.root,'config','config.json'),mcp=join(f.data,'mcp-installs.json'),a=readFileSync(config,'utf8'),b=readFileSync(mcp,'utf8');
  const network=vi.fn(async()=>Response.json({}));vi.stubGlobal('fetch',network);
  try{for(const source of [undefined,'agent','scheduler'])await expect(Reflect.apply(f.service[method],f.service,[...legitimate[method],source])).rejects.toThrow('channel_mcp_mutation_request_source_forbidden');
    expect(network).not.toHaveBeenCalled();expect(readFileSync(config,'utf8')).toBe(a);expect(readFileSync(mcp,'utf8')).toBe(b);
  }finally{vi.unstubAllGlobals();}
});
it.each(methods)('%s is admitted as user only through the real Main binding',async method=>{
  const f=await fixture();seed(f);const producer=vi.spyOn(f.service,method),network=vi.fn(async()=>Response.json({}));vi.stubGlobal('fetch',network);
  try{await f.invoke(method,...legitimate[method]);expect(producer).toHaveBeenCalledExactlyOnceWith(...legitimate[method],'user');}finally{vi.unstubAllGlobals();}
});
it.each(methods)('%s rejects unknown sender/old main/subframe before payload getters',async method=>{
  for(const kind of ['unknown','old-main','subframe']){
    const f=await fixture();seed(f);const old=f.sender;if(kind==='old-main')f.authority.setMain({webContents:{mainFrame:f.frame,isDestroyed:()=>false},isDestroyed:()=>false});
    const sender=kind==='unknown'?{mainFrame:f.frame,isDestroyed:()=>false}:old,frame=kind==='subframe'?{url:f.frame.url}:f.frame;let reads=0;
    const input=Object.defineProperty({},'name',{enumerable:true,get(){reads++;return 'Owned'}}),producer=vi.spyOn(f.service,method);
    await expect(Reflect.apply(f.listeners.get('desktop:'+method)!,undefined,[{sender,senderFrame:frame},input])).rejects.toThrow('desktop_user_sender_forbidden');expect(reads).toBe(0);expect(producer).not.toHaveBeenCalled();
  }
});
it.each(methods)('%s retains legal Recorder caller population',async method=>{
  const f=await fixture();seed(f);vi.stubGlobal('fetch',vi.fn(async()=>Response.json({})));
  try{const result=await Reflect.apply(f.listeners.get('desktop:'+method)!,undefined,[{sender:f.recorder,senderFrame:f.recorderFrame},...legitimate[method]]);if(method.startsWith('delete'))expect(result).toBeUndefined();else expect(result).toBeDefined();}finally{vi.unstubAllGlobals();}
});
it.each(['createChannel','updateChannel','deleteChannel','testChannel'] as const)('%s refuses corrupted config without backup/removal/write/fetch',async method=>{
  const f=await fixture();seed(f);const path=join(f.root,'config','config.json'),bytes='{"OWNED_PRIVATE_CONFIG_SECRET":';writeFileSync(path,bytes);vi.stubGlobal('fetch',vi.fn());
  try{const result=await f.invoke(method,...legitimate[method]).then(()=>null,(error: unknown)=>error);
    expect(result).toBeInstanceOf(Error);expect(result.message).toBe('channel_mcp_mutation_source_unavailable');expect(result.message).not.toContain('OWNED_PRIVATE_CONFIG_SECRET');expect(readFileSync(path,'utf8')).toBe(bytes);expect(existsSync(path+'.bak')).toBe(false);expect(fetch).not.toHaveBeenCalled();
  }finally{vi.unstubAllGlobals();}
});
it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall'] as const)('%s refuses corrupted MCP bytes instead of fallback [] overwrite',async method=>{
  const f=await fixture();seed(f);const path=join(f.data,'mcp-installs.json'),bytes='{"OWNED_PRIVATE_MCP_SECRET":';writeFileSync(path,bytes);
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);
});
it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall'] as const)('%s rejects a malformed row anywhere in the table without discarding it',async method=>{
  const f=await fixture();seed(f);const path=join(f.data,'mcp-installs.json'),rows=JSON.parse(readFileSync(path,'utf8'));rows.push({id:'bad',args:7});const bytes=JSON.stringify(rows);writeFileSync(path,bytes);
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);
});
it('same-turn concurrent channel edits and MCP creates preserve both real commits',async()=>{
  const f=await fixture();seed(f);
  await Promise.all([f.invoke('createChannel',{type:'a',name:'A'}),f.invoke('createChannel',{type:'b',name:'B'})]);
  expect(JSON.parse(readFileSync(join(f.root,'config','config.json'),'utf8')).channels).toMatchObject({a:{name:'A'},b:{name:'B'},owned:{appSecret:'OWNED_APP_SECRET'}});
  const created=await Promise.all([f.invoke('createMCPInstall',{name:'A',source:'local',command:'a'}),f.invoke('createMCPInstall',{name:'B',source:'local',command:'b'})]);
  const rows=await f.invoke('listMCPInstalls');expect(rows.map((row:{id:string})=>row.id)).toEqual(expect.arrayContaining(created.map((row:{id:string})=>row.id)));expect(rows).toHaveLength(3);
});
it('real creation persists all currently submitted UI credentials but public ACK/list exclude them',async()=>{
  const f=await fixture();seed(f);const result=await f.invoke('createChannel',{type:'discord',name:'Owned Discord',botToken:'OWNED_BOT_SECRET',chatId:'owned-room'});
  const config=JSON.parse(readFileSync(join(f.root,'config','config.json'),'utf8'));
  expect(config.channels.discord).toMatchObject({botToken:'OWNED_BOT_SECRET',chatId:'owned-room'});expect(config.providers.private.apiKey).toBe('OWNED_PROVIDER_SECRET');expect(config.future).toEqual({keep:true});
  expect(JSON.stringify(result)).not.toContain('OWNED_BOT_SECRET');expect(JSON.stringify(await f.invoke('listChannels'))).not.toContain('OWNED_BOT_SECRET');
});
it('MCP args update and metadata survive real write/read, without installing/spawning',async()=>{
  const f=await fixture();seed(f);const result=await f.invoke('updateMCPInstall','owned',{args:['--new','']});
  expect(result.args).toEqual(['--new','']);const rows=await f.invoke('listMCPInstalls');expect(rows[0]).toMatchObject({args:['--new',''],future:{keep:true}});
});
it('schema1 channel edit preserves legacy provider secrets and unknown fields',async()=>{
  const f=await fixture();seed(f);const path=join(f.root,'config','config.json'),original={schemaVersion:1,defaultModel:'openai',models:{openai:{apiKey:'OWNED_LEGACY_KEY'}},future:{keep:true},channels:{owned:{name:'Old',secret:'OWNED_CHANNEL_KEY'}}};writeFileSync(path,JSON.stringify(original));
  await f.invoke('updateChannel','owned',{name:'New'});const actual=JSON.parse(readFileSync(path,'utf8'));expect(actual).toEqual({...original,channels:{owned:{...original.channels.owned,name:'New'}}});
});
it('channel test returns fixed failure without reading an exception message getter or credential echo',async()=>{
  const f=await fixture();seed(f);let reads=0;const error=Object.defineProperty({},'message',{get(){reads++;return 'OWNED_NETWORK_SECRET'}});vi.stubGlobal('fetch',vi.fn().mockRejectedValue(error));
  try{expect(await f.invoke('testChannel','owned')).toEqual({success:false,error:'channel_mcp_mutation_network_failed'});expect(reads).toBe(0);}finally{vi.unstubAllGlobals();}
});
it('HTTP rejection remains business false; no retry and original webhook POST payload retained',async()=>{
  const f=await fixture();seed(f);const network=vi.fn(async(..._args:unknown[])=>new Response('',{status:403}));vi.stubGlobal('fetch',network);
  try{expect(await f.invoke('testChannel','owned')).toMatchObject({success:false,error:'HTTP 403'});expect(network).toHaveBeenCalledTimes(1);expect(network.mock.calls[0]).toEqual(['https://owned.invalid/path?token=OWNED_SECRET',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({msgtype:'text',text:{content:'xiaok 测试连接 ✅'}})}]);}finally{vi.unstubAllGlobals();}
});
it.each(methods)('%s rejects invalid production output rather than a successful contract-violation envelope',async method=>{
  const f=await fixture();seed(f);f.service[method]=(()=>({ok:false,error:'OWNED_LEAK'}))as never;const previous=process.env.NODE_ENV;process.env.NODE_ENV='production';
  try{await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');}finally{if(previous===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=previous;}
});
it.each(methods)('%s rejects output accessors without executing them',async method=>{
  const f=await fixture();seed(f);let reads=0;const result=Object.defineProperty({},'success',{enumerable:true,get(){reads++;return true}});f.service[method]=(()=>result)as never;
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');expect(reads).toBe(0);
});
it.each(methods)('%s keeps original producer rejection identity',async method=>{
  const f=await fixture();seed(f);const error=Error('owned-domain-failure');f.service[method]=(()=>{throw error})as never;await expect(f.invoke(method,...legitimate[method])).rejects.toBe(error);
  f.service[method]=(()=>Promise.reject(error))as never;await expect(f.invoke(method,...legitimate[method])).rejects.toBe(error);
});
it('held actual testChannel network promise retains the original shutdown token beyond five seconds',async()=>{
  const f=await fixture();seed(f);let release!:(response:Response)=>void;const network=vi.fn(()=>new Promise<Response>(resolve=>{release=resolve}));vi.stubGlobal('fetch',network);vi.useFakeTimers();
  const pending=f.invoke('testChannel','owned');await Promise.resolve();await Promise.resolve();
  try{expect(f.gate.outstanding).toBe(1);const drain=f.gate.drain(5000);await vi.advanceTimersByTimeAsync(5001);expect(await drain).toBe(false);expect(f.gate.outstanding).toBe(1);expect(network).toHaveBeenCalledTimes(1);}finally{release(Response.json({}));await pending;vi.unstubAllGlobals();}expect(f.gate.outstanding).toBe(0);
});

it.each(methods)('%s rejects promise constructor accessors without reading them',async method=>{
  const f=await fixture();seed(f);let reads=0;const result=Promise.resolve(undefined);Object.defineProperty(result,'constructor',{get(){reads++;return Promise}});f.service[method]=(()=>result)as never;
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');expect(reads).toBe(0);
});
it.each(methods)('%s rejects proxy/cycle/serializer output without traps/serialization/retry',async method=>{
  const f=await fixture();seed(f);let reads=0;const cycle:{self?:unknown}={};cycle.self=cycle;
  for(const output of [new Proxy({},{ownKeys(){reads++;throw Error('owned')}}),cycle,{toJSON(){reads++;return {}}}]){
    const producer=vi.spyOn(f.service,method).mockImplementation((()=>output)as never);
    await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');expect(reads).toBe(0);expect(producer).toHaveBeenCalledTimes(1);producer.mockRestore();
  }
});
it.each(['createChannel','updateChannel','deleteChannel','testChannel']as const)('%s rejects invalid channels map before normalization can erase it',async method=>{
  const f=await fixture();seed(f);const path=join(f.root,'config','config.json'),bytes=JSON.stringify({schemaVersion:2,providers:{},models:{},channels:[]});writeFileSync(path,bytes);
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);
});
const posix = process.platform !== 'win32' && process.getuid?.() !== 0;
it.runIf(posix).each(['createChannel','updateChannel','deleteChannel','testChannel','createMCPInstall','updateMCPInstall','deleteMCPInstall']as const)('%s refuses actual parent EACCES instead of defaults',async method=>{
  const f=await fixture();seed(f);const directory=method.includes('MCP')?f.data:join(f.root,'config'),file=join(directory,method.includes('MCP')?'mcp-installs.json':'config.json'),bytes=readFileSync(file,'utf8');chmodSync(directory,0);
  try{await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');}finally{chmodSync(directory,0o700);}
  expect(readFileSync(file,'utf8')).toBe(bytes);expect(existsSync(file+'.bak')).toBe(false);
});
it.runIf(posix).each(['createChannel','createMCPInstall']as const)('%s ACK waits for real write completion and refuses unwritable missing target',async method=>{
  const f=await fixture();seed(f);const directory=method.includes('MCP')?f.data:join(f.root,'config'),file=join(directory,method.includes('MCP')?'mcp-installs.json':'config.json');unlinkSync(file);chmodSync(directory,0o500);
  try{await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_write_failed');}finally{chmodSync(directory,0o700);}expect(existsSync(file)).toBe(false);
});

it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall']as const)('%s rejects JSON null/scalar/object rather than treating them as a missing MCP file',async method=>{
 const f=await fixture();seed(f);const path=join(f.data,'mcp-installs.json');
 for(const bytes of ['null','false','42','{}']){writeFileSync(path,bytes);await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);}
});
it.each(['createChannel','updateChannel','deleteChannel','testChannel']as const)('%s rejects JSON null/scalar/array config instead of replacing it with defaults',async method=>{
 const f=await fixture();seed(f);const path=join(f.root,'config','config.json');
 for(const bytes of ['null','false','42','[]']){writeFileSync(path,bytes);await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);expect(existsSync(path+'.bak')).toBe(false);}
});

```

## FULL desktop/tests/main/meeting-mutation-candidate-controls.test.ts
```typescript
// UNREVIEWED POST-APPLICATION controls. This imports new candidates at their
// production targets, so do NOT report missing-module baseline as a behavior RED.
// Copy to desktop/tests/main/meeting-mutation-candidate-controls.test.ts.
// @vitest-environment node
import { beforeEach, expect, it } from 'vitest';
import { registerMeetingMutationIpc } from '../../electron/meeting-mutation-typed-ipc.js';
import { createMeetingMutationService } from '../../electron/meeting-mutation-service.js';
import { createMeetingAudioPermissionService } from '../../electron/meeting-audio-permission.js';
import { resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
beforeEach(resetIpcSchemaRegistryForTests);
function boundary(producer: IpcHandlerListener) {
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate();
  const registrar = new ShutdownAwareIpcMain({ handle: (channel, listener) => listeners.set(channel, listener) }, gate);
  const producers = new Map([['desktop:meeting:requestMicrophonePermission', producer]]);
  registerMeetingMutationIpc(registrar, producers);
  return { gate, registrar, producers, invoke: () => listeners.get('desktop:meeting:requestMicrophonePermission')!({} as never) };
}
it('production typed boundary rejects output accessor without evaluating it', async () => {
  let reads = 0; const f = boundary(() => Object.defineProperty({}, 'status', { enumerable: true, get() { reads++; return 'granted'; } }));
  await expect(f.invoke()).rejects.toThrow('meeting_mutation_projection_unavailable'); expect(reads).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it.each([undefined, null, { status: 'invented' }, { status: 'granted', secret: 'owned-private-marker' }, { ok: false, error: 'fake-ack' }])('production typed boundary rejects invalid output %j', async value => {
  const f = boundary(() => value); await expect(f.invoke()).rejects.toThrow('meeting_mutation_projection_unavailable');
});
it('unknown producer rejection is fixed and never evaluates the error getter', async () => {
  let reads = 0; const error = Object.defineProperty({}, 'message', { get() { reads++; return 'owned-private-marker'; } });
  const f = boundary(() => Promise.reject(error)); await expect(f.invoke()).rejects.toThrow('meeting_mutation_action_failed'); expect(reads).toBe(0);
});
it('a native pending producer holds physical token until actual rejection', async () => {
  let reject!: (error: unknown) => void; const f = boundary(() => new Promise((_r, j) => { reject = j; }));
  const operation = Promise.resolve(f.invoke()).catch(error => error); expect(f.gate.outstanding).toBe(1);
  f.gate.close(); const drained = f.gate.drain(1000); reject(Error('owned-private-marker'));
  expect(await operation).toMatchObject({ message: 'meeting_mutation_action_failed' }); expect(await drained).toBe(true); expect(f.gate.outstanding).toBe(0);
});
it('producer bindings detach and registrar owner identity is enforced', async () => {
  const f = boundary(() => ({ status: 'granted' })); f.producers.set('desktop:meeting:requestMicrophonePermission', () => ({ status: 'denied' }));
  expect(await f.invoke()).toEqual({ status: 'granted' }); registerMeetingMutationIpc(f.registrar, f.producers);
  expect(() => registerMeetingMutationIpc(f.registrar, new Map(f.producers))).toThrow('meeting_mutation_registrar_owner_conflict');
});
it.each([undefined, 'agent', 'scheduler'] as const)('actual facade denies %s before permission/config/model work', async source => {
  let asks = 0; const permission = createMeetingAudioPermissionService({ platform: 'darwin', getMediaAccessStatus: () => 'not-determined', askForMediaAccess: async () => { asks++; return true; } });
  const service = createMeetingMutationService(permission);
  let getters = 0; const payload = Object.defineProperty({}, 'aliyun', { enumerable: true, get() { getters++; return {}; } });
  for (const operation of [() => service.requestMicrophonePermission(source), () => service.saveAsrConfig(payload, source), () => service.downloadModel(payload, source), () => service.uninstallModel(payload, source)]) await expect(operation()).rejects.toThrow('meeting_mutation_request_source_forbidden');
  expect(asks).toBe(0); expect(getters).toBe(0);
});
it('actual permission owner coalesces a pending OS ask and permits the next request after settlement', async () => {
  let asks = 0, finish!: (value: boolean) => void;
  const permission = createMeetingAudioPermissionService({ platform: 'darwin', getMediaAccessStatus: () => 'not-determined', askForMediaAccess: async () => { asks++; return new Promise<boolean>(r => { finish = r; }); } });
  const service = createMeetingMutationService(permission); const a = service.requestMicrophonePermission('user'), b = service.requestMicrophonePermission('user');
  const before = asks; finish(true); expect(await a).toEqual({ status: 'granted' }); expect(await b).toEqual({ status: 'granted' }); expect(before).toBe(1);
  const c = service.requestMicrophonePermission('user'); finish(true); await c; expect(asks).toBe(2);
});

```

## FULL desktop/tests/main/meeting-mutation-controls.test.ts
```typescript
// UNREVIEWED RED CANDIDATE. Copy to desktop/tests/main/meeting-mutation-controls.test.ts.
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'meeting-mutation-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;},setRecorder(v){meetingRecorderController=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}


// Fixture above is copied from the accepted readonly3 real-entry test. Main
// authorizeDesktopInvoke is extracted from production, not reimplemented here.
const methods = ['requestMicrophonePermission', 'saveAsrConfig', 'downloadModel', 'uninstallModel'] as const;
it.each(methods)('registers actual %s with captured tuple metadata', async method => {
  await fixture(); const entry = IPC_SCHEMA_REGISTRY.get('desktop:meeting:' + method);
  expect(entry).toMatchObject({ payloadMode: 'tuple', inputStage: 'beforeHandler', sourceFile: 'desktop/electron/meeting-mutation-typed-ipc.ts' });
});
it.each([
  ['requestMicrophonePermission', [{}]],
  ['saveAsrConfig', [{ defaultProvider: 'invented' }]],
  ['saveAsrConfig', [{ aliyun: { apiKey: 'owned-fixture-marker', clearApiKey: 'yes' } }]],
  ['saveAsrConfig', [{ aliyun: { unknownField: true } }]],
  ['saveAsrConfig', [{}, {}]],
  ['downloadModel', [42]], ['downloadModel', ['../outside']], ['downloadModel', ['never-a-registry-id', {}]],
  ['uninstallModel', [{}]], ['uninstallModel', ['never-a-registry-id', {}]],
] as [string, unknown[]][])('rejects %s invalid tuple without fabricating an ACK', async (method, args) => {
  const f = await fixture(); await expect(async () => f.invoke('meeting:' + method, ...args)).rejects.toThrow('meeting_mutation_input_invalid');
  expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(false); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('captures %s input before reading caller accessors', async method => {
  const f = await fixture(); let getters = 0;
  const payload = Object.defineProperty({}, method === 'saveAsrConfig' ? 'aliyun' : 'toString', { enumerable: true, get() { getters++; return method === 'saveAsrConfig' ? {} : () => 'never-a-registry-id'; } });
  await expect(async () => f.invoke('meeting:' + method, payload)).rejects.toThrow('meeting_mutation_input_invalid');
  expect(getters).toBe(0); expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(false);
});
it.each(methods.flatMap(method => ['unknown', 'old-main', 'subframe', 'bad-url', 'retired-recorder'].map(kind => [method, kind])))('source gate rejects %s / %s before payload inspection', async (method, kind) => {
  const f = await fixture(); let getters = 0;
  if (kind === 'old-main') f.authority.setMain({ webContents: { mainFrame: f.frame, isDestroyed: () => false }, isDestroyed: () => false });
  if (kind === 'bad-url') f.frame.url = 'file:///never-owned/index.html';
  if (kind === 'retired-recorder') f.authority.setRecorder({ ownsWebContents: () => false });
  const sender = kind === 'unknown' ? { mainFrame: f.frame, isDestroyed: () => false } : kind === 'retired-recorder' ? f.recorder : f.sender;
  const frame = kind === 'subframe' ? { url: f.frame.url } : kind === 'retired-recorder' ? f.recorderFrame : f.frame;
  const payload = Object.defineProperty({}, 'aliyun', { enumerable: true, get() { getters++; return {}; } });
  await expect(async () => Reflect.apply(f.listeners.get('desktop:meeting:' + method)!, undefined, [{ sender, senderFrame: frame }, payload])).rejects.toThrow('desktop_user_sender_forbidden');
  expect(getters).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('closed shutdown gate rejects %s before payload or work', async method => {
  const f = await fixture(); f.gate.close(); let reads = 0;
  const payload = Object.defineProperty({}, 'aliyun', { enumerable: true, get() { reads++; return {}; } });
  await expect(async () => f.invoke('meeting:' + method, payload)).rejects.toThrow('shutting_down'); expect(reads).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it('save keeps actual credentials private and preserves explicit clear / blank semantics', async () => {
  const f = await fixture(); const path = join(f.root, 'config', 'config.json');
  const dto = await f.invoke('meeting:saveAsrConfig', { defaultProvider: 'aliyun-asr', aliyun: { apiKey: 'owned-fixture-not-a-real-key', baseUrl: 'https://owned.invalid/', model: 'owned-model' } });
  expect(dto.aliyun).toMatchObject({ configured: true, apiKeyConfigured: true, baseUrl: 'https://owned.invalid', model: 'owned-model' });
  expect(JSON.stringify(dto)).not.toContain('owned-fixture-not-a-real-key'); expect(JSON.parse(readFileSync(path, 'utf8')).meeting.asr.aliyun.apiKey).toBe('owned-fixture-not-a-real-key');
  await f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: '   ' } });
  expect(JSON.parse(readFileSync(path, 'utf8')).meeting.asr.aliyun.apiKey).toBe('owned-fixture-not-a-real-key');
  const cleared = await f.invoke('meeting:saveAsrConfig', { aliyun: { clearApiKey: true, apiKey: 'ignored-owned-marker' } });
  expect(cleared.aliyun.apiKeyConfigured).toBe(false); expect(JSON.parse(readFileSync(path, 'utf8')).meeting.asr.aliyun.apiKey).toBeUndefined();
});
it.each([[], [null], [undefined], [{}]].map(args => ({ args })))('keeps original nullish / empty save input behavior: %j', async ({ args }) => {
  const f = await fixture(); const dto = await f.invoke('meeting:saveAsrConfig', ...args);
  expect(dto.defaultProvider).toBe('sherpa-onnx-paraformer'); expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(true);
});
it('corrupt actual config cannot be repaired into a successful save ACK or credential-bearing error', async () => {
  const f = await fixture(), dir = join(f.root, 'config'); mkdirSync(dir, { recursive: true });
  const path = join(dir, 'config.json'), raw = '{"meeting":{"asr":{"aliyun":{"apiKey":owned-private-marker}}}}'; writeFileSync(path, raw);
  await expect(async () => f.invoke('meeting:saveAsrConfig', { defaultProvider: 'whisper' })).rejects.toThrow('meeting_mutation_save_failed');
  expect(readFileSync(path, 'utf8')).toBe(raw); expect(existsSync(path + '.bak')).toBe(false);
});
it('a real filesystem save failure rejects with a fixed credential-free code', async () => {
  const f = await fixture(), dir = join(f.root, 'config'); mkdirSync(dir, { recursive: true }); mkdirSync(join(dir, 'config.json'));
  const error = await Promise.resolve().then(() => f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: 'owned-private-marker' } })).catch(e => e);
  expect(error).toBeInstanceOf(Error); expect(error.message).toBe('meeting_mutation_save_failed'); expect(String(error)).not.toContain('owned-private-marker');
});
it('two real saves in one turn retain edits to both providers', async () => {
  const f = await fixture(); await Promise.all([
    f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: 'owned-ali' } }),
    f.invoke('meeting:saveAsrConfig', { volcengine: { appKey: 'owned-volc' } }),
  ]);
  const data = JSON.parse(readFileSync(join(f.root, 'config', 'config.json'), 'utf8'));
  expect(data.meeting.asr.aliyun.apiKey).toBe('owned-ali'); expect(data.meeting.asr.volcengine.appKey).toBe('owned-volc');
});
it('current Recorder is a valid save caller through the production Main authorizer', async () => {
  const f = await fixture(); const dto = await Reflect.apply(f.listeners.get('desktop:meeting:saveAsrConfig')!, undefined, [{ sender: f.recorder, senderFrame: f.recorderFrame }, {}]);
  expect(dto.defaultProvider).toBe('sherpa-onnx-paraformer'); expect(f.gate.outstanding).toBe(0);
});

it.each(['https://owned:owned-private-marker@owned.invalid', 'https://owned.invalid/?token=owned-private-marker', 'https://owned.invalid/#owned-private-marker'])('rejects credential-bearing public endpoint %s before saving', async baseUrl => {
  const f = await fixture(); await expect(async () => f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: 'owned-private-marker', baseUrl } })).rejects.toThrow('meeting_mutation_input_invalid');
  expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(false);
});

```

## FULL desktop/tests/main/meeting-mutation-model-lifecycle.test.ts
```typescript
// UNREVIEWED RED CANDIDATE. Copy to desktop/tests/main/meeting-mutation-model-lifecycle.test.ts.
// @vitest-environment node
import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, expect, it } from 'vitest';
import { createMeetingModelService, type MeetingModelDefinition } from '../../electron/meeting-model-service.js';
import { createMeetingAudioPermissionService } from '../../electron/meeting-audio-permission.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function heldFixture(directory = false) {
  const cacheDir = mkdtempSync(join(tmpdir(), 'meeting-model-lease-owned-')); roots.push(cacheDir);
  let release!: () => void; const held = new Promise<void>(r => { release = r; }); let calls = 0;
  const bytes = Buffer.from('owned-model-bytes');
  const model: MeetingModelDefinition = { id: 'owned', fileName: directory ? 'owned-dir' : 'owned.bin', url: 'https://owned.invalid/model', expectedSizeBytes: bytes.length, expectedSha256: createHash('sha256').update(bytes).digest('hex'), ...(directory ? { packageType: 'directory' as const, archiveFileName: 'owned.tar.bz2', requiredFiles: ['model.bin'] } : {}) };
  const options = { cacheDir, models: [model], downloadFile: async (_url: string, destination: string) => { calls++; await held; writeFileSync(destination, bytes); } };
  return { cacheDir, model, release, calls: () => calls, first: createMeetingModelService(options), second: createMeetingModelService(options) };
}
it('same cache/model across real service instances rejects a concurrent download', async () => {
  const f = heldFixture(); const first = f.first.downloadModel('owned');
  let secondError: unknown, succeeded = false;
  const second = f.second.downloadModel('owned').then(() => { succeeded = true; }, error => { secondError = error; });
  await Promise.resolve(); const before = f.calls();
  f.release(); await Promise.all([first, second]);
  expect(before).toBe(1); expect(succeeded).toBe(false); expect(secondError).toMatchObject({ message: 'meeting_model_busy' });
});
it('actual uninstall cannot ACK while an admitted download can recreate the model', async () => {
  const f = heldFixture(); const download = f.first.downloadModel('owned'); let failure: unknown;
  try { f.second.uninstallModel('owned'); } catch (error) { failure = error; } finally { f.release(); }
  await download; expect(failure).toMatchObject({ message: 'meeting_model_busy' });
  const result = f.second.uninstallModel('owned'); expect(result.ok).toBe(true); expect(result.model.packageState).toBe('missing'); expect(existsSync(join(f.cacheDir, f.model.fileName))).toBe(false);
});
it('failed real download releases its cache/model lease for a later action', async () => {
  const cacheDir = mkdtempSync(join(tmpdir(), 'meeting-model-failure-owned-')); roots.push(cacheDir);
  const model = { id: 'owned', fileName: 'owned.bin', url: 'https://owned.invalid', expectedSizeBytes: 1, expectedSha256: '0'.repeat(64) };
  const service = createMeetingModelService({ cacheDir, models: [model], downloadFile: async () => { throw Error('owned-transfer-failed'); } });
  await expect(service.downloadModel('owned')).rejects.toThrow('owned-transfer-failed'); expect(service.uninstallModel('owned').ok).toBe(true);
});
it('real directory extraction remains covered by the download lease until settlement', async () => {
  const f = heldFixture(true); f.release();
  let finish!: () => void, started!: () => void;
  const extracting = new Promise<void>(r => { started = r; }), held = new Promise<void>(r => { finish = r; });
  const service = createMeetingModelService({ cacheDir: f.cacheDir, models: [f.model], downloadFile: async (_url, path) => writeFileSync(path, Buffer.from('owned-model-bytes')), extractArchive: async () => { started(); await held; throw Error('owned-extraction-failed'); } });
  const operation = service.downloadModel('owned').catch(error => error); await extracting;
  let error: unknown; try { f.second.uninstallModel('owned'); } catch (value) { error = value; } finally { finish(); }
  expect((await operation).message).toBe('owned-extraction-failed'); expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(f.second.uninstallModel('owned').ok).toBe(true);
});
it('physical shutdown token remains held for the real download, then releases on completion', async () => {
  const f = heldFixture(), gate = new DesktopShutdownGate(); let listener!: IpcHandlerListener;
  const ipc = new ShutdownAwareIpcMain({ handle: (_channel, value) => { listener = value; } }, gate);
  ipc.handle('owned:test:real-model-download', () => f.first.downloadModel('owned'));
  const operation = listener({} as never); expect(gate.outstanding).toBe(1); gate.close(); const drained = gate.drain(1000);
  f.release(); await operation; expect(await drained).toBe(true); expect(gate.outstanding).toBe(0);
});
it.each(['darwin', 'win32', 'linux'])('real permission service retains %s platform behavior', async platform => {
  let asks = 0; const service = createMeetingAudioPermissionService({ platform, getMediaAccessStatus: () => 'not-determined', askForMediaAccess: async media => { expect(media).toBe('microphone'); asks++; return true; } });
  expect((await service.requestPermission()).status).toBe(platform === 'darwin' ? 'granted' : 'unknown'); expect(asks).toBe(platform === 'darwin' ? 1 : 0);
});
it.each(['granted', 'denied', 'restricted'])('real permission service does not re-prompt Darwin %s', async status => {
  let asks = 0; const service = createMeetingAudioPermissionService({ platform: 'darwin', getMediaAccessStatus: () => status, askForMediaAccess: async () => { asks++; return true; } });
  expect(await service.requestPermission()).toEqual({ status }); expect(asks).toBe(0);
});

```

## FULL desktop/tests/main/runtime-status-readonly-controls.test.ts
```typescript
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'skills-readonly-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { ipc, root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}



async function statusFixture(method:'getComputerUseCapabilityStatus'|'kswarm:getStatus'){
 const f=await fixture();const row={running:false,port:4400,pid:null,restartCount:0,lastError:null,terminalDegraded:true,persistenceFailStopCount:2,lastPersistenceFailStop:'owned-failure',future:{kept:['owned']}};const produce=vi.fn(()=>row);
 if(method==='kswarm:getStatus'){
  const source=readFileSync(new URL('../../electron/main.ts',import.meta.url),'utf8'),ast=ts.createSourceFile('main.ts',source,ts.ScriptTarget.Latest,true);let declaration:ts.ExpressionStatement|undefined;function visit(node:ts.Node){if(ts.isExpressionStatement(node)&&ts.isCallExpression(node.expression)){const call=node.expression,name=call.expression.getText(ast);if(name==='registerKswarmStatusReadonlyIpc'||name==='shutdownAwareIpc.handle'&&call.arguments[0]&&ts.isStringLiteral(call.arguments[0])&&call.arguments[0].text==='desktop:kswarm:getStatus')declaration=node;}ts.forEachChild(node,visit);}visit(ast);expect(declaration).toBeDefined();
  const isTyped=source.includes('registerKswarmStatusReadonlyIpc');const register=isTyped?(await import('../../electron/runtime-status-readonly-typed-ipc.js')).registerKswarmStatusReadonlyIpc:undefined;
  const code=ts.transpileModule(declaration!.getText(ast),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;compileFunction(code,['shutdownAwareIpc','kswarmService','registerKswarmStatusReadonlyIpc'])(f.ipc,{getStatus:produce},register);
 }else vi.spyOn(f.service,'getComputerUseCapabilityStatus').mockImplementation(produce as never);
 return{...f,row,produce,invoke:(...args:unknown[])=>f.invoke(method,...args)};
}
it.each(['getComputerUseCapabilityStatus','kswarm:getStatus']as const)('rejects actual %s extra transport input before cached getter',async method=>{const f=await statusFixture(method);await expect(async()=>f.invoke({})).rejects.toThrow('runtime_status_input_invalid');expect(f.produce).not.toHaveBeenCalled();});
it.each(['getComputerUseCapabilityStatus','kswarm:getStatus']as const)('rejects actual %s malformed successful producer value',async method=>{const f=await statusFixture(method);f.produce.mockReturnValue({}as never);await expect(async()=>f.invoke()).rejects.toThrow('runtime_status_projection_unavailable');expect(f.produce).toHaveBeenCalledTimes(1);});
it.each(['unknown','old-main','subframe'])('denies %s before status producer and payload getters',async kind=>{const f=await statusFixture('kswarm:getStatus'),old=f.sender;if(kind==='old-main')f.authority.setMain({webContents:{mainFrame:f.frame,isDestroyed:()=>false},isDestroyed:()=>false});const sender=kind==='unknown'?{mainFrame:f.frame,isDestroyed:()=>false}:old,frame=kind==='subframe'?{url:f.frame.url}:f.frame;let reads=0;const input=Object.defineProperty({},'owned',{enumerable:true,get(){reads++;return'owned'}});await expect(async()=>Reflect.apply(f.listeners.get('desktop:kswarm:getStatus')!,undefined,[{sender,senderFrame:frame},input])).rejects.toThrow('desktop_user_sender_forbidden');expect(reads).toBe(0);expect(f.produce).not.toHaveBeenCalled();});
it('detaches all8 SDK fields and future metadata on each actual Main source invocation',async()=>{const f=await statusFixture('kswarm:getStatus'),a=await f.invoke(),b=await f.invoke();expect(a).toEqual(f.row);expect(a).not.toBe(f.row);expect(a).not.toBe(b);expect(a.future.kept).not.toBe(f.row.future.kept);expect(a.terminalDegraded).toBe(true);expect(a.persistenceFailStopCount).toBe(2);expect(f.gate.outstanding).toBe(0);});

```

## FULL desktop/tests/main/skill-mutation-controls.test.ts
```typescript
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
const processMocks = vi.hoisted(() => ({ sync: vi.fn() }));
vi.mock('node:child_process', async load => ({ ...await load<typeof import('node:child_process')>(), spawnSync: processMocks.sync }));
vi.mock('cross-spawn', () => ({ default: { sync: processMocks.sync } }));
import { getSkillCatalogVersion, onSkillCatalogChanged } from '../../electron/skill-catalog-invalidation.js';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'skills-readonly-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); processMocks.sync.mockReset(); processMocks.sync.mockReturnValue({ status: 0, error: undefined, stdout: '', stderr: '' }); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  const broadcast = ast.statements.length && (() => {
    let statement: ts.ExpressionStatement | undefined;
    const visit = (n: ts.Node) => { if (ts.isExpressionStatement(n) && ts.isCallExpression(n.expression) && n.expression.expression.getText(ast) === 'onSkillCatalogChanged') statement = n; ts.forEachChild(n, visit); }; visit(ast);
    expect(statement).toBeDefined();
    const sent = vi.fn();
    const code = ts.transpileModule('return ' + statement!.expression.getText(ast) + ';', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
    const unsubscribe = compileFunction(code, ['onSkillCatalogChanged', 'mainWindow'])(onSkillCatalogChanged, { isDestroyed: () => false, webContents: { send: sent } });
    cleanups.push(async () => unsubscribe()); return sent;
  })();
  return { root, data, service, broadcast, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}

// Copy to desktop/tests/main/skill-mutation-controls.test.ts BEFORE applying proposal.patch.
// All RED expectations invoke the real registerDesktopIpc / createDesktopServices.
const methods = ['installSkill', 'uninstallSkill'] as const;
it.each(methods)('qualifies %s as an exact one-argument typed tuple', async method => {
  await fixture(); expect(IPC_SCHEMA_REGISTRY.get('desktop:' + method)).toMatchObject({ payloadMode: 'tuple', rolloutRound: 34 });
});
it.each(methods)('%s preserves clawhub command/deadline/cwd and invalidates+broadcasts once on success', async method => {
  const f = await fixture(), version = getSkillCatalogVersion();
  const result = await f.invoke(method, 'owned-skill'); expect(result.success).toBe(true);
  expect(processMocks.sync).toHaveBeenCalledExactlyOnceWith('clawhub', [method === 'installSkill' ? 'install' : 'uninstall', 'owned-skill'], { encoding: 'utf-8', timeout: method === 'installSkill' ? 60000 : 30000, cwd: process.cwd() });
  expect(getSkillCatalogVersion()).toBe(version + 1); expect(f.broadcast).toHaveBeenCalledExactlyOnceWith('desktop:skillsChanged'); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s does not invalidate/broadcast on process errors, signal, timeout or nonzero exit', async method => {
  const f = await fixture();
  for (const failure of [{ status: 1, stderr: 'owned_failure', stdout: '' }, { status: null, signal: 'SIGTERM', stderr: '', stdout: '' }, { error: Error('ENOENT'), status: null }, { error: Error('ETIMEDOUT'), status: null }]) {
    const version = getSkillCatalogVersion(); processMocks.sync.mockReturnValueOnce(failure);
    expect((await f.invoke(method, 'owned-skill')).success).toBe(false); expect(getSkillCatalogVersion()).toBe(version);
  }
  expect(f.broadcast).not.toHaveBeenCalled(); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s preserves bounded stderr/stdout fallback rather than a success ACK', async method => {
  const f = await fixture(); processMocks.sync.mockReturnValueOnce({ status: 3, stderr: ' x'.repeat(400), stdout: 'ignored' });
  expect(await f.invoke(method, 'owned-skill')).toEqual({ success: false, message: ' x'.repeat(400).trim().slice(0, 500) });
  processMocks.sync.mockReturnValueOnce({ status: 1, stderr: '', stdout: 'stdout-failure' }); expect((await f.invoke(method, 'owned-skill')).message).toBe('stdout-failure');
});
it.each(methods)('%s rejects missing/extra/source/path/option input before the actual OS boundary', async method => {
  const f = await fixture();
  for (const args of [[], ['owned', { requestSource: 'user' }], [42], [''], [' owned '], ['--force'], ['../escape'], ['C:\\escape'], ['C:escape'], ['\\\\server\\share'], ['/absolute'], ['.'], ['..'], ['bad\0name']]) {
    await expect(async () => f.invoke(method, ...args)).rejects.toThrow('skill_mutation_input_invalid');
  }
  expect(processMocks.sync).not.toHaveBeenCalled(); expect(f.broadcast).not.toHaveBeenCalled();
});
it.each(methods)('%s retains Unicode, namespace and interior-space caller names as one operand', async method => {
  const f = await fixture(); for (const name of ['报告技能', 'team:owned-skill', 'owned skill', 'a.b_c-1']) expect((await f.invoke(method, name)).success).toBe(true);
  expect(processMocks.sync.mock.calls.map(call => call[1][1])).toEqual(['报告技能', 'team:owned-skill', 'owned skill', 'a.b_c-1']);
});
it.each(methods)('%s captures input before toJSON/accessors or result logging can execute', async method => {
  const f = await fixture(); let reads = 0;
  for (const value of [Object.defineProperty({}, 'skill', { enumerable: true, get() { reads++; return 'owned'; } }), { toJSON() { reads++; return 'owned'; } }]) await expect(async () => f.invoke(method, value)).rejects.toThrow('skill_mutation_input_invalid');
  expect(reads).toBe(0); expect(processMocks.sync).not.toHaveBeenCalled();
});
it.each(methods)('%s enforces user source inside the real service, including omitted and accessor source', async method => {
  const f = await fixture(); const mutate = f.service[method] as unknown as (name: unknown, context?: unknown) => Promise<unknown>;
  let reads = 0; const accessor = Object.defineProperty({}, 'requestSource', { enumerable: true, get() { reads++; return 'user'; } });
  for (const context of [undefined, { requestSource: 'agent' }, { requestSource: 'scheduler' }, accessor]) await expect(async () => mutate('owned-skill', context)).rejects.toThrow('skill_mutation_source_forbidden');
  expect(reads).toBe(0); expect(processMocks.sync).not.toHaveBeenCalled();
  expect(await mutate('owned-skill', { requestSource: 'user' })).toMatchObject({ success: true });
});
it.each(methods)('%s validates names inside the real service even without IPC', async method => {
  const f = await fixture(); const mutate = f.service[method] as unknown as (name: unknown, context: unknown) => Promise<unknown>;
  await expect(async () => mutate('../escape', { requestSource: 'user' })).rejects.toThrow('skill_mutation_input_invalid'); expect(processMocks.sync).not.toHaveBeenCalled();
});
it.each(methods)('%s validates producer output before result getter/toJSON/unknown ACK', async method => {
  const f = await fixture(); let reads = 0;
  const accessor = Object.defineProperty({ message: 'owned' }, 'success', { enumerable: true, get() { reads++; return true; } });
  for (const value of [accessor, { success: true, message: 'owned', toJSON() { reads++; return {}; } }, undefined, { success: 'yes', message: 'owned' }]) {
    f.service[method] = (() => Promise.resolve(value)) as never;
    await expect(async () => f.invoke(method, 'owned')).rejects.toThrow('skill_mutation_output_invalid');
  }
  expect(reads).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s rejects unsafe thenables without invoking their then accessor', async method => {
  const f = await fixture(); let reads = 0; const value = Object.defineProperty({}, 'then', { get() { reads++; return () => {}; } });
  f.service[method] = (() => value) as never; await expect(async () => f.invoke(method, 'owned')).rejects.toThrow('skill_mutation_output_invalid'); expect(reads).toBe(0);
});
it.each(methods)('%s detaches producer metadata and preserves business failure shape', async method => {
  const f = await fixture(), value = { success: false, message: 'owned_failure', future: { retained: true } }; f.service[method] = (() => Promise.resolve(value)) as never;
  const result = await f.invoke(method, 'owned'); expect(result).toEqual(value); expect(result).not.toBe(value); expect(result.future).not.toBe(value.future);
});
it.each(methods)('%s retains producer throw/reject identity and releases the original token', async method => {
  const f = await fixture(), failure = Error('owned_service_failure');
  f.service[method] = (() => { throw failure; }) as never; await expect(async () => f.invoke(method, 'owned')).rejects.toBe(failure);
  f.service[method] = (() => Promise.reject(failure)) as never; await expect(async () => f.invoke(method, 'owned')).rejects.toBe(failure); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s denies unknown/old/subframe/bad-URL sender before input capture', async method => {
  const f = await fixture(); let reads = 0; const input = Object.defineProperty({}, 'field', { enumerable: true, get() { reads++; return 'owned'; } });
  const invokeAs = (sender: unknown, senderFrame: unknown) => Reflect.apply(f.listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame }, input]);
  await expect(async () => invokeAs({ ...f.sender }, f.frame)).rejects.toThrow('desktop_user_sender_forbidden');
  await expect(async () => invokeAs(f.sender, { ...f.frame })).rejects.toThrow('desktop_user_sender_forbidden');
  const url = f.frame.url; f.frame.url = 'https://untrusted.invalid/'; await expect(async () => invokeAs(f.sender, f.frame)).rejects.toThrow('desktop_user_sender_forbidden'); f.frame.url = url;
  f.authority.setMain({ isDestroyed: () => false, webContents: {} }); await expect(async () => invokeAs(f.sender, f.frame)).rejects.toThrow('desktop_user_sender_forbidden');
  expect(reads).toBe(0); expect(processMocks.sync).not.toHaveBeenCalled();
});
it.each(methods)('%s retains the existing owned Recorder admission population', async method => {
  const f = await fixture(); expect(await Reflect.apply(f.listeners.get('desktop:' + method)!, undefined, [{ sender: f.recorder, senderFrame: f.recorderFrame }, 'owned-skill'])).toMatchObject({ success: true });
});
it.each(methods)('%s holds one original token past shutdown deadline then drains and rejects new calls', async method => {
  const f = await fixture(); let release!: (v: { success: boolean; message: string }) => void;
  f.service[method] = (() => new Promise(resolve => { release = resolve; })) as never;
  vi.useFakeTimers(); const reading = f.invoke(method, 'owned'); await Promise.resolve(); expect(f.gate.outstanding).toBe(1);
  try { f.gate.close(); const drain = f.gate.drain(5000); await vi.advanceTimersByTimeAsync(5001); expect(await drain).toBe(false); expect(f.gate.outstanding).toBe(1); await expect(async () => f.invoke(method, 'other')).rejects.toThrow('shutting_down'); }
  finally { release({ success: true, message: 'owned' }); await reading; }
  expect(f.gate.outstanding).toBe(0);
});

```

## FULL desktop/tests/main/skill-mutation-preload.test.ts
```typescript
// @vitest-environment node
// Copy to desktop/tests/main/skill-mutation-preload.test.ts.
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import * as os from 'node:os';
import { expect, it, vi } from 'vitest';
import { createPreloadApi } from '../../electron/preload-api.js';
function port() { return { invoke: vi.fn(async (_channel: string, ..._args: unknown[]) => ({ success: true, message: 'owned_ok' })), on: vi.fn(), off: vi.fn(), removeListener: vi.fn(), send: vi.fn() }; }
async function check(api: ReturnType<typeof createPreloadApi>, ipc: ReturnType<typeof port>) {
  for (const method of ['installSkill', 'uninstallSkill'] as const) {
    ipc.invoke.mockClear(); expect(await api[method]('owned-skill')).toEqual({ success: true, message: 'owned_ok' });
    expect(ipc.invoke).toHaveBeenCalledExactlyOnceWith('desktop:' + method, 'owned-skill');
    const failure = Error('owned_failure'); ipc.invoke.mockRejectedValueOnce(failure); await expect(api[method]('owned-skill')).rejects.toBe(failure);
    ipc.invoke.mockResolvedValueOnce({ success: false, message: 'owned_business_failure' }); expect(await api[method]('owned-skill')).toEqual({ success: false, message: 'owned_business_failure' });
  }
  const callback = vi.fn(), dispose = api.onSkillsChanged(callback); expect(ipc.on).toHaveBeenCalledExactlyOnceWith('desktop:skillsChanged', expect.any(Function));
  ipc.on.mock.calls[0]![1]({}, undefined); expect(callback).toHaveBeenCalledTimes(1); dispose();
  expect([...ipc.off.mock.calls, ...ipc.removeListener.mock.calls]).toEqual([['desktop:skillsChanged', ipc.on.mock.calls[0]![1]]]);
}
it('TS preload retains exact skill tuple, business failure, rejection and reload disposal', async () => { const ipc = port(); await check(createPreloadApi(ipc), ipc); });
it('real CJS sandbox preload retains exact skill tuple, business failure, rejection and reload disposal', async () => {
  const ipc = port(); let api!: ReturnType<typeof createPreloadApi>;
  runInNewContext(readFileSync(new URL('../../electron/preload.cjs', import.meta.url), 'utf8'), { require(name: string) {
    if (name === 'electron') return { ipcRenderer: ipc, contextBridge: { exposeInMainWorld(_key: string, value: ReturnType<typeof createPreloadApi>) { api = value; } } };
    if (name === 'os') return os; throw Error('unexpected dependency ' + name);
  } }); await check(api, ipc);
});

```
