# Final actual15target batch CODE source

Complete tracked diff against exactbase b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1; allnewsource/test files complete below; allfullsource SHA in final-source-manifest-r1.json. No virtualoverlay. Native/runtime/installed/wholePR claims withheld.

```diff
diff --git a/desktop/electron/desktop-services.ts b/desktop/electron/desktop-services.ts
index 0fd6ab3b..d15ce646 100644
--- a/desktop/electron/desktop-services.ts
+++ b/desktop/electron/desktop-services.ts
@@ -1,3 +1,6 @@
+import { runDesktopSkillMutation } from './desktop-skill-mutation.js';
+import type { DesktopSkillMutationContext } from '../shared/skill-mutation-ipc-contract.js';
+import { createChannelMcpMutationOwner } from './channel-mcp-mutation-owner.js';
 import { readChannelViews, readMcpInstallViews } from './channel-mcp-readonly-data.js';
 import { captureSkillReadonlyPromise } from './skill-readonly-data.js';
 import { types as skillNodeTypes } from 'node:util';
@@ -909,6 +912,7 @@ function sanitizeSystemOnePatch(input: DesktopSaveSystemOneConfigInput | undefin
 }
 
 export function createDesktopServices(options: DesktopServicesOptions) {
+  const channelMcpMutations = createChannelMcpMutationOwner(options.dataRoot);
   let roomTimedActions:TimedActionService|undefined;
   const getManagedPythonCommand = options.getManagedPythonCommand;
   const officeDocumentParser = createOfficeDocumentParser({
@@ -3259,37 +3263,11 @@ export function createDesktopServices(options: DesktopServicesOptions) {
         tier: s.tier,
       }));
     },
-    async installSkill(skillName: string): Promise<{ success: boolean; message: string }> {
-      const result = spawnSync('clawhub', ['install', skillName], {
-        encoding: 'utf-8',
-        timeout: 60000,
-        cwd: process.cwd(),
-      });
-      if (result.error) {
-        return { success: false, message: `执行失败: ${result.error.message}` };
-      }
-      if (result.status !== 0) {
-        const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
-        return { success: false, message: stderr.slice(0, 500) };
-      }
-      bumpSkillCatalogVersion();
-      return { success: true, message: `技能 ${skillName} 已安装` };
-    },
-    async uninstallSkill(skillName: string): Promise<{ success: boolean; message: string }> {
-      const result = spawnSync('clawhub', ['uninstall', skillName], {
-        encoding: 'utf-8',
-        timeout: 30000,
-        cwd: process.cwd(),
-      });
-      if (result.error) {
-        return { success: false, message: `执行失败: ${result.error.message}` };
-      }
-      if (result.status !== 0) {
-        const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
-        return { success: false, message: stderr.slice(0, 500) };
-      }
-      bumpSkillCatalogVersion();
-      return { success: true, message: `技能 ${skillName} 已卸载` };
+    async installSkill(skillName: string, context: DesktopSkillMutationContext): Promise<{ success: boolean; message: string }> {
+      return runDesktopSkillMutation('install', skillName, context, process.cwd());
+    },
+    async uninstallSkill(skillName: string, context: DesktopSkillMutationContext): Promise<{ success: boolean; message: string }> {
+      return runDesktopSkillMutation('uninstall', skillName, context, process.cwd());
     },
     async createTaskWithFiles(input: {
       prompt: string;
@@ -3951,112 +3929,31 @@ export function createDesktopServices(options: DesktopServicesOptions) {
     async listChannels(): Promise<Array<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }>> {
       return readChannelViews();
     },
-    async testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }> {
-      const config = await loadConfig();
-      const channels = (config as unknown as Record<string, unknown>).channels ?? {};
-      const ch = (channels as Record<string, unknown>)[channelId] as { sendMsgUrl?: string; webhookUrl?: string } | undefined;
-      const url = ch?.sendMsgUrl || ch?.webhookUrl;
-      if (!url) {
-        return { success: false, error: '未配置 webhook URL' };
-      }
-      try {
-        const start = Date.now();
-        // Send a test ping message
-        const response = await fetch(url, {
-          method: 'POST',
-          headers: { 'Content-Type': 'application/json' },
-          body: JSON.stringify({ msgtype: 'text', text: { content: 'xiaok 测试连接 ✅' } }),
-        });
-        const latencyMs = Date.now() - start;
-        if (!response.ok) {
-          return { success: false, latencyMs, error: `HTTP ${response.status}` };
-        }
-        return { success: true, latencyMs };
-      } catch (e) {
-        return { success: false, error: (e as Error).message };
-      }
+    async testChannel(channelId: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.testChannel(channelId, requestSource);
     },
-    async createChannel(input: { type: string; name: string; webhookUrl?: string }): Promise<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }> {
-      const config = await loadConfig();
-      const raw = config as unknown as Record<string, unknown>;
-      if (!raw.channels) raw.channels = {};
-      (raw.channels as Record<string, unknown>)[input.type] = {
-        name: input.name,
-        sendMsgUrl: input.webhookUrl || '',
-        inboundMode: 'webhook',
-        enabled: true,
-      };
-      await saveConfig(config);
-      return {
-        id: input.type,
-        type: input.type,
-        name: input.name,
-        webhookUrl: input.webhookUrl,
-        enabled: true,
-        createdAt: Date.now(),
-        updatedAt: Date.now(),
-      };
+    async createChannel(input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.createChannel(input, requestSource);
     },
-    async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean }): Promise<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }> {
-      const config = await loadConfig();
-      const raw = config as unknown as Record<string, unknown>;
-      const channels = (raw.channels as Record<string, unknown>) || {};
-      const ch = channels[id] as Record<string, unknown> | undefined;
-      if (!ch) throw new Error('Channel not found');
-      if (input.name !== undefined) ch.name = input.name;
-      if (input.webhookUrl !== undefined) ch.sendMsgUrl = input.webhookUrl;
-      if (input.enabled !== undefined) ch.enabled = input.enabled;
-      await saveConfig(config);
-      return {
-        id, type: id, name: (ch.name as string) || id,
-        webhookUrl: ch.sendMsgUrl as string | undefined,
-        enabled: ch.enabled !== false, createdAt: 0, updatedAt: Date.now(),
-      };
+    async updateChannel(id: unknown, input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.updateChannel(id, input, requestSource);
     },
-    async deleteChannel(id: string) {
-      const config = await loadConfig();
-      const raw = config as unknown as Record<string, unknown>;
-      const channels = raw.channels as Record<string, unknown> | undefined;
-      if (channels) delete channels[id];
-      await saveConfig(config);
+    async deleteChannel(id: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.deleteChannel(id, requestSource);
     },
 
     // ---- MCP API ----
     async listMCPInstalls(): Promise<Array<{ id: string; name: string; source: string; command: string; args?: string[]; enabled: boolean; createdAt: number }>> {
       return readMcpInstallViews(options.dataRoot);
     },
-    async createMCPInstall(input: { name: string; source: 'npm' | 'github' | 'local'; command: string; args?: string[] }) {
-      const path = join(options.dataRoot, 'mcp-installs.json');
-      const installs = await loadJsonFile<MCPRecord[]>(path, []);
-      const record: MCPRecord = {
-        id: crypto.randomUUID(),
-        name: input.name,
-        source: input.source,
-        command: input.command,
-        args: input.args,
-        enabled: true,
-        createdAt: Date.now(),
-      };
-      installs.push(record);
-      await saveJsonFile(path, installs);
-      return toMCPView(record);
-    },
-    async updateMCPInstall(id: string, input: { name?: string; source?: 'npm' | 'github' | 'local'; command?: string; enabled?: boolean }) {
-      const path = join(options.dataRoot, 'mcp-installs.json');
-      const installs = await loadJsonFile<MCPRecord[]>(path, []);
-      const idx = installs.findIndex(c => c.id === id);
-      if (idx < 0) throw new Error('MCP install not found');
-      if (input.name !== undefined) installs[idx].name = input.name;
-      if (input.source !== undefined) installs[idx].source = input.source;
-      if (input.command !== undefined) installs[idx].command = input.command;
-      if (input.enabled !== undefined) installs[idx].enabled = input.enabled;
-      await saveJsonFile(path, installs);
-      return toMCPView(installs[idx]);
-    },
-    async deleteMCPInstall(id: string) {
-      const path = join(options.dataRoot, 'mcp-installs.json');
-      const installs = await loadJsonFile<MCPRecord[]>(path, []);
-      await saveJsonFile(path, installs.filter(c => c.id !== id));
+    async createMCPInstall(input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.createMCPInstall(input, requestSource);
+    },
+    async updateMCPInstall(id: unknown, input: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.updateMCPInstall(id, input, requestSource);
+    },
+    async deleteMCPInstall(id: unknown, requestSource?: 'user' | 'agent' | 'scheduler') {
+      return channelMcpMutations.deleteMCPInstall(id, requestSource);
     },
 
     async exportTraceBundle(input: { kind: 'session' | 'project' | 'task'; id: string }): Promise<{ ok: boolean; path?: string; error?: string }> {
diff --git a/desktop/electron/ipc-runtime.ts b/desktop/electron/ipc-runtime.ts
index 789d1631..d3fd1718 100644
--- a/desktop/electron/ipc-runtime.ts
+++ b/desktop/electron/ipc-runtime.ts
@@ -27,7 +27,7 @@ export interface IpcSchemaEntry {
   payloadMode: 'single' | 'tuple';
   inputStage: 'beforeHandler' | 'afterHostAuthorization';
   wireInput?: ZodSchema;
-  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
+  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34;
   riskTags: RiskTag[];
 }
 
@@ -62,7 +62,7 @@ export interface IpcRegistrationOptions<I, O> {
   input: ZodSchema<I>;
   output: ZodSchema<O>;
   sourceFile: string;
-  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33;
+  rolloutRound: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 | 34;
   riskTags?: RiskTag[];
   handler: (input: I, event: IpcMainInvokeEvent, helpers?: IpcStageHelpers<I>) => Promise<O>;
   /** Main-owned adapters preserve domain error envelopes without granting caller authority. */
diff --git a/desktop/electron/ipc.ts b/desktop/electron/ipc.ts
index fe4c2e7d..7467ae7e 100644
--- a/desktop/electron/ipc.ts
+++ b/desktop/electron/ipc.ts
@@ -1,3 +1,8 @@
+import { registerComputerUseCapabilityReadonlyIpc } from './runtime-status-readonly-typed-ipc.js';
+import { registerSkillMutationIpc } from './skill-mutation-typed-ipc.js';
+import { registerChannelMcpMutationIpc } from './channel-mcp-mutation-typed-ipc.js';
+import { createMeetingMutationService } from './meeting-mutation-service.js';
+import { registerMeetingMutationIpc } from './meeting-mutation-typed-ipc.js';
 import { registerMeetingReadonlyIpc } from './meeting-readonly-typed-ipc.js';
 import { readMeetingAsrReadonly } from './meeting-readonly-data.js';
 import { registerChannelMcpReadonlyIpc } from './channel-mcp-readonly-typed-ipc.js';
@@ -1293,37 +1298,27 @@ export async function registerDesktopIpc(
     ['desktop:listSkills', () => captureSkillListServiceResult(services.listSkills(), count => log('info', 'listSkills', { count }))],
   ]);
   registerSkillListIpc(ipcMain, skillListProducers);
-  ipcMain.handle('desktop:installSkill', async (_event, skillName) => {
-    log('info', 'installSkill', { skillName });
-    const r = await services.installSkill(skillName);
-    log('info', 'installSkill result', { success: r.success });
-    return r;
-  });
-  ipcMain.handle('desktop:uninstallSkill', async (_event, skillName) => {
-    log('info', 'uninstallSkill', { skillName });
-    const r = await services.uninstallSkill(skillName);
-    log('info', 'uninstallSkill result', { success: r.success });
-    return r;
-  });
+  const skillMutationProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:installSkill', (_event, skillName) => services.installSkill(skillName, { requestSource: 'user' })],
+    ['desktop:uninstallSkill', (_event, skillName) => services.uninstallSkill(skillName, { requestSource: 'user' })],
+  ]);
+  registerSkillMutationIpc(ipcMain, skillMutationProducers);
   // Channel IPC
   const channelMcpReadonlyProducers = new Map<string, IpcHandlerListener>([
     ['desktop:listChannels', () => services.listChannels()],
     ['desktop:listMCPInstalls', () => services.listMCPInstalls()],
   ]);
   registerChannelMcpReadonlyIpc(ipcMain, channelMcpReadonlyProducers);
-  ipcMain.handle('desktop:testChannel', async (_event, channelId) => {
-    log('info', 'testChannel', { channelId });
-    const r = await services.testChannel(channelId);
-    log('info', 'testChannel result', { success: r.success });
-    return r;
-  });
-  ipcMain.handle('desktop:createChannel', async (_event, input) => services.createChannel(input));
-  ipcMain.handle('desktop:updateChannel', async (_event, id, input) => services.updateChannel(id, input));
-  ipcMain.handle('desktop:deleteChannel', async (_event, id) => services.deleteChannel(id));
-  // MCP IPC
-  ipcMain.handle('desktop:createMCPInstall', async (_event, input) => services.createMCPInstall(input));
-  ipcMain.handle('desktop:updateMCPInstall', async (_event, id, input) => services.updateMCPInstall(id, input));
-  ipcMain.handle('desktop:deleteMCPInstall', async (_event, id) => services.deleteMCPInstall(id));
+  const channelMcpMutationProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:testChannel', (_event, id) => services.testChannel(id, 'user')],
+    ['desktop:createChannel', (_event, input) => services.createChannel(input, 'user')],
+    ['desktop:updateChannel', (_event, id, input) => services.updateChannel(id, input, 'user')],
+    ['desktop:deleteChannel', (_event, id) => services.deleteChannel(id, 'user')],
+    ['desktop:createMCPInstall', (_event, input) => services.createMCPInstall(input, 'user')],
+    ['desktop:updateMCPInstall', (_event, id, input) => services.updateMCPInstall(id, input, 'user')],
+    ['desktop:deleteMCPInstall', (_event, id) => services.deleteMCPInstall(id, 'user')],
+  ]);
+  registerChannelMcpMutationIpc(ipcMain, channelMcpMutationProducers);
   // Plugin MCP servers
   registerPluginCatalogIpc(ipcMain, services);
   // Design v58 §7.2: `setPluginMcpServerEnabled` only mutated a view model and
@@ -1333,7 +1328,7 @@ export async function registerDesktopIpc(
     componentId: String((input as { componentId?: unknown })?.componentId ?? ''),
     requestSource: 'user',
   }));
-  ipcMain.handle('desktop:getComputerUseCapabilityStatus', () => services.getComputerUseCapabilityStatus());
+  registerComputerUseCapabilityReadonlyIpc(ipcMain, () => services.getComputerUseCapabilityStatus());
   ipcMain.handle('desktop:enableComputerUse', () => services.enableComputerUse({ requestSource: 'user' }));
   ipcMain.handle('desktop:reconnectComputerUse', () => services.reconnectComputerUse({ requestSource: 'user' }));
   ipcMain.handle('desktop:disableComputerUse', () => services.disableComputerUse({ requestSource: 'user' }));
@@ -1814,17 +1809,14 @@ export async function registerDesktopIpc(
     return result.filePaths[0] ?? null;
   });
 
-  ipcMain.handle('desktop:meeting:requestMicrophonePermission', async () => (
-    meetingAudioPermissionService.requestPermission()
-  ));
-
-  ipcMain.handle('desktop:meeting:saveAsrConfig', async (_event, input) => {
-    const { loadConfig, saveConfig } = await import('../../src/utils/config.js');
-    const { applyMeetingAsrConfigUpdate, createMeetingAsrConfigSnapshot } = await import('./meeting-asr-config.js');
-    const config = applyMeetingAsrConfigUpdate(await loadConfig(), input ?? {});
-    await saveConfig(config);
-    return createMeetingAsrConfigSnapshot(config);
-  });
+  const meetingMutations = createMeetingMutationService(meetingAudioPermissionService);
+  const meetingMutationProducers = new Map<string, IpcHandlerListener>([
+    ['desktop:meeting:requestMicrophonePermission', () => meetingMutations.requestMicrophonePermission('user')],
+    ['desktop:meeting:saveAsrConfig', (_event, input) => meetingMutations.saveAsrConfig(input, 'user')],
+    ['desktop:meeting:downloadModel', (_event, id) => meetingMutations.downloadModel(id, 'user')],
+    ['desktop:meeting:uninstallModel', (_event, id) => meetingMutations.uninstallModel(id, 'user')],
+  ]);
+  registerMeetingMutationIpc(ipcMain, meetingMutationProducers);
 
   const meetingReadonlyProducers = new Map<string, IpcHandlerListener>([
     ['desktop:meeting:getMicrophonePermission', () => meetingAudioPermissionService.getStatus()],
@@ -1833,16 +1825,6 @@ export async function registerDesktopIpc(
   ]);
   registerMeetingReadonlyIpc(ipcMain, meetingReadonlyProducers);
 
-  ipcMain.handle('desktop:meeting:downloadModel', async (_event, modelId: string) => {
-    const { createMeetingModelService } = await import('./meeting-model-service.js');
-    return createMeetingModelService().downloadModel(String(modelId ?? ''));
-  });
-
-  ipcMain.handle('desktop:meeting:uninstallModel', async (_event, modelId: string) => {
-    const { createMeetingModelService } = await import('./meeting-model-service.js');
-    return createMeetingModelService().uninstallModel(String(modelId ?? ''));
-  });
-
   ipcMain.handle('desktop:meeting:saveRecordedAudio', async (_event, input) => {
     const wavBase64 = typeof input?.wavBase64 === 'string' ? input.wavBase64 : '';
     if (!wavBase64) return { ok: false, error: 'missing_audio' };
diff --git a/desktop/electron/main.ts b/desktop/electron/main.ts
index f62693fa..c395ace5 100644
--- a/desktop/electron/main.ts
+++ b/desktop/electron/main.ts
@@ -1,3 +1,4 @@
+import { registerKswarmStatusReadonlyIpc } from './runtime-status-readonly-typed-ipc.js';
 import { createAutomationConfigOwner } from './automation-config-owner.js';
 import { registerAutomationConfigIpc } from './automation-config-typed-ipc.js';
 import { createMobileRelaySignInOwner } from './mobile-relay-signin.js';
@@ -659,7 +660,7 @@ async function createInitialWindowResources(): Promise<BrowserWindow> {
   const kswarmService = createDesktopKSwarmService(desktopShutdownCoordinator, desktopFinalLifetimeSteps, { activityOwnerPending: process.env.XIAOK_CONVERSATION_ACTIVITY !== '0' });
   if (!kswarmService) return window;
   let kswarmStartPromise: Promise<void>;
-  shutdownAwareIpc.handle('desktop:kswarm:getStatus', () => kswarmService.getStatus());
+  registerKswarmStatusReadonlyIpc(shutdownAwareIpc, () => kswarmService.getStatus());
   shutdownAwareIpc.handle('desktop:kswarm:start', () => kswarmService.start());
   shutdownAwareIpc.handle('desktop:kswarm:stop', () => kswarmService.stop());
   shutdownAwareIpc.handle('desktop:kswarm:restart', () => kswarmService.restart());
diff --git a/desktop/electron/meeting-model-service.ts b/desktop/electron/meeting-model-service.ts
index 2a95dbbf..4d2bd919 100644
--- a/desktop/electron/meeting-model-service.ts
+++ b/desktop/electron/meeting-model-service.ts
@@ -5,7 +5,7 @@ import type { ClientRequest, IncomingMessage } from 'node:http';
 import { get as httpGet } from 'node:http';
 import { get as httpsGet } from 'node:https';
 import { homedir } from 'node:os';
-import { dirname, join } from 'node:path';
+import { dirname, join, resolve } from 'node:path';
 import { promisify, types as nodeTypes } from 'node:util';
 
 export type MeetingModelCheckReason = 'ready' | 'missing' | 'size_mismatch' | 'hash_mismatch';
@@ -191,6 +191,14 @@ function truthfulModelPathExists(path: string): boolean {
   catch(error) { if(error && typeof error==='object' && !nodeTypes.isProxy(error) && Object.getOwnPropertyDescriptor(error,'code')?.value==='ENOENT')return false;throw error; }
 }
 
+// One cache/model download lease shared by every factory instance in this process.
+// Does not claim a transcriber lease or cancellation protocol.
+const activeMeetingModelDownloads = new Set<string>();
+function meetingModelLeaseKey(cacheDir: string, model: MeetingModelDefinition): string {
+  const path = resolve(cacheDir, model.fileName);
+  return process.platform === 'win32' ? path.toLowerCase() : path;
+}
+
 export function createMeetingModelService(options: MeetingModelServiceOptions = {}): MeetingModelService {
   const env = options.env ?? process.env;
   const cacheDir = options.cacheDir ?? resolveMeetingWhisperCacheDir(env);
@@ -269,8 +277,12 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
     },
     async downloadModel(modelId) {
       const model = findModel(modelId);
+      const lease = meetingModelLeaseKey(cacheDir, model);
+      if (activeMeetingModelDownloads.has(lease)) throw Error('meeting_model_busy');
+      activeMeetingModelDownloads.add(lease);
+      try {
       if ((model.packageType ?? 'single-file') === 'directory') {
-        return downloadDirectoryModelPackage(model, cacheDir, downloadFile, extractArchive, getModelInfo);
+        return await downloadDirectoryModelPackage(model, cacheDir, downloadFile, extractArchive, getModelInfo);
       }
       mkdirSync(cacheDir, { recursive: true });
       const modelPath = join(cacheDir, model.fileName);
@@ -293,9 +305,11 @@ export function createMeetingModelService(options: MeetingModelServiceOptions =
         throw new Error(check.reason);
       }
       return { ok: true, model: getModelInfo(model) };
+      } finally { activeMeetingModelDownloads.delete(lease); }
     },
     uninstallModel(modelId) {
       const model = findModel(modelId);
+      if (activeMeetingModelDownloads.has(meetingModelLeaseKey(cacheDir, model))) throw Error('meeting_model_busy');
       const isDirectoryPackage = (model.packageType ?? 'single-file') === 'directory';
       rmSync(join(cacheDir, model.fileName), { recursive: isDirectoryPackage, force: true });
       if (isDirectoryPackage) {
diff --git a/desktop/electron/meeting-readonly-data.ts b/desktop/electron/meeting-readonly-data.ts
index 36eb9418..f4d10858 100644
--- a/desktop/electron/meeting-readonly-data.ts
+++ b/desktop/electron/meeting-readonly-data.ts
@@ -18,7 +18,7 @@ const storedMeeting = z.object({ asr: z.object({
   volcengine: provider.optional(), aliyun: provider.optional(),
 }).passthrough().optional() }).passthrough();
 
-export function readMeetingAsrReadonly() {
+export function readMeetingAsrConfig(): Config {
   let raw: string | undefined;
   try { raw = readFileSync(getConfigPath(), 'utf8'); }
   catch (error) {
@@ -39,6 +39,11 @@ export function readMeetingAsrReadonly() {
     if (obj.meeting !== undefined && !storedMeeting.safeParse(obj.meeting).success) throw Error('meeting_readonly_projection_unavailable');
     config = normalizeConfig(obj as unknown as Config | LegacyConfig);
   }
+  return config;
+}
+
+export function readMeetingAsrReadonly() {
+  const config = readMeetingAsrConfig();
   const dto = captureIpcData(createMeetingAsrConfigSnapshot(config), 'meeting_readonly_projection_unavailable');
   const parsed = MEETING_ASR_OUTPUT_SCHEMA.safeParse(dto);
   if (!parsed.success) throw Error('meeting_readonly_projection_unavailable');
diff --git a/desktop/electron/preload-api.ts b/desktop/electron/preload-api.ts
index d1292e8a..ba04c41c 100644
--- a/desktop/electron/preload-api.ts
+++ b/desktop/electron/preload-api.ts
@@ -1,3 +1,5 @@
+import type { ComputerUseReadonlyStatus, KswarmReadonlyStatus } from '../shared/runtime-status-readonly-ipc-contract.js';
+import type { MeetingMutationModelResult } from '../shared/meeting-mutation-ipc-contract.js';
 import type { MeetingReadonlyPermission, MeetingReadonlyAsr, MeetingReadonlyModels } from '../shared/meeting-readonly-ipc-contract.js';
 import type { ChannelReadonlyView, McpInstallReadonlyView } from '../shared/channel-mcp-readonly-ipc-contract.js';
 import type { SkillListDto } from '../shared/skill-list-ipc-contract.js';
@@ -858,6 +860,11 @@ export interface DesktopChannelInput {
   type: DesktopChannelType;
   name: string;
   webhookUrl?: string;
+  appId?: string;
+  appSecret?: string;
+  token?: string;
+  botToken?: string;
+  chatId?: string;
 }
 
 export type DesktopMCPInstallView = McpInstallReadonlyView;
@@ -922,6 +929,9 @@ export interface KSwarmServiceStatus {
   pid: number | null;
   restartCount: number;
   lastError: string | null;
+  terminalDegraded?: boolean;
+  persistenceFailStopCount?: number;
+  lastPersistenceFailStop?: string | null;
 }
 
 export type DesktopRelatedServiceId = RelatedServiceIdDto;
@@ -1260,16 +1270,16 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   listChannels(): Promise<DesktopChannelView[]>;
   testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }>;
   createChannel(input: DesktopChannelInput): Promise<DesktopChannelView>;
-  updateChannel(id: string, input: Partial<DesktopChannelInput>): Promise<DesktopChannelView>;
+  updateChannel(id: string, input: Partial<DesktopChannelInput> & { enabled?: boolean }): Promise<DesktopChannelView>;
   deleteChannel(id: string): Promise<void>;
   listMCPInstalls(): Promise<DesktopMCPInstallView[]>;
   createMCPInstall(input: DesktopMCPInput): Promise<DesktopMCPInstallView>;
-  updateMCPInstall(id: string, input: Partial<DesktopMCPInput>): Promise<DesktopMCPInstallView>;
+  updateMCPInstall(id: string, input: Partial<DesktopMCPInput> & { enabled?: boolean }): Promise<DesktopMCPInstallView>;
   deleteMCPInstall(id: string): Promise<void>;
   listPluginMcpServers(): Promise<PluginMcpServerView[]>;
   /** Design v58 §7.2: component-scoped retry; never writes persisted desired state. */
   retryPluginComponent(input: { componentId: string }): Promise<PluginMcpServerView[]>;
-  getComputerUseCapabilityStatus(): Promise<ComputerUseCapabilityStatusView>;
+  getComputerUseCapabilityStatus(): Promise<ComputerUseReadonlyStatus>;
   enableComputerUse(): Promise<ComputerUseCapabilityStatusView>;
   reconnectComputerUse(): Promise<ComputerUseCapabilityStatusView>;
   disableComputerUse(): Promise<ComputerUseCapabilityStatusView>;
@@ -1298,7 +1308,7 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   getSkillStats(): Promise<DesktopSkillStats[]>;
   getServiceStatus(): Promise<DesktopServiceStatusSnapshot>;
   restartRelatedService(serviceId: DesktopRelatedServiceId): Promise<void>;
-  kswarmGetStatus(): Promise<KSwarmServiceStatus>;
+  kswarmGetStatus(): Promise<KswarmReadonlyStatus>;
   kswarmStart(): Promise<void>;
   kswarmStop(): Promise<void>;
   kswarmRestart(): Promise<void>;
@@ -1397,12 +1407,12 @@ export interface DesktopApi extends MultiAgentDesktopAPI, RoomWorkspaceApi {
   kbPickFiles(): Promise<string[]>;
   meetingPickAudioFile(): Promise<string | null>;
   meetingGetMicrophonePermission(): Promise<MeetingReadonlyPermission>;
-  meetingRequestMicrophonePermission(): Promise<unknown>;
+  meetingRequestMicrophonePermission(): Promise<import('../shared/meeting-readonly-ipc-contract.js').MeetingReadonlyPermission>;
   meetingGetAsrConfig(): Promise<MeetingReadonlyAsr>;
   meetingSaveAsrConfig(input: MeetingSaveAsrConfigInput): Promise<MeetingAsrConfigSnapshot>;
   meetingListModels(): Promise<MeetingReadonlyModels>;
-  meetingDownloadModel(modelId: string): Promise<unknown>;
-  meetingUninstallModel(modelId: string): Promise<unknown>;
+  meetingDownloadModel(modelId: string): Promise<MeetingMutationModelResult>;
+  meetingUninstallModel(modelId: string): Promise<MeetingMutationModelResult>;
   meetingSaveRecordedAudio(input: unknown): Promise<unknown>;
   meetingTranscribePreview(input: unknown): Promise<unknown>;
   meetingStartLiveTranscription(input: { engine: 'aliyun-asr' | 'volcengine-asr'; sampleRate: number; language?: string }): Promise<{ ok: boolean; sessionId?: string; error?: string }>;
@@ -1745,7 +1755,7 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     deleteMCPInstall: (id) => ipcRenderer.invoke('desktop:deleteMCPInstall', id) as Promise<void>,
     listPluginMcpServers: () => ipcRenderer.invoke('desktop:listPluginMcpServers') as Promise<PluginMcpServerView[]>,
     retryPluginComponent: (input) => ipcRenderer.invoke('desktop:retryPluginComponent', input) as Promise<PluginMcpServerView[]>,
-    getComputerUseCapabilityStatus: () => ipcRenderer.invoke('desktop:getComputerUseCapabilityStatus') as Promise<ComputerUseCapabilityStatusView>,
+    getComputerUseCapabilityStatus: () => ipcRenderer.invoke('desktop:getComputerUseCapabilityStatus') as Promise<ComputerUseReadonlyStatus>,
     enableComputerUse: () => ipcRenderer.invoke('desktop:enableComputerUse') as Promise<ComputerUseCapabilityStatusView>,
     reconnectComputerUse: () => ipcRenderer.invoke('desktop:reconnectComputerUse') as Promise<ComputerUseCapabilityStatusView>,
     disableComputerUse: () => ipcRenderer.invoke('desktop:disableComputerUse') as Promise<ComputerUseCapabilityStatusView>,
@@ -1801,7 +1811,7 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     getSkillStats: () => ipcRenderer.invoke('desktop:getSkillStats') as ReturnType<DesktopApi['getSkillStats']>,
     getServiceStatus: () => ipcRenderer.invoke('desktop:services:getStatus') as Promise<DesktopServiceStatusSnapshot>,
     restartRelatedService: (serviceId) => ipcRenderer.invoke('desktop:services:restart', serviceId) as Promise<void>,
-    kswarmGetStatus: () => ipcRenderer.invoke('desktop:kswarm:getStatus') as Promise<KSwarmServiceStatus>,
+    kswarmGetStatus: () => ipcRenderer.invoke('desktop:kswarm:getStatus') as Promise<KswarmReadonlyStatus>,
     kswarmStart: () => ipcRenderer.invoke('desktop:kswarm:start') as Promise<void>,
     kswarmStop: () => ipcRenderer.invoke('desktop:kswarm:stop') as Promise<void>,
     kswarmRestart: () => ipcRenderer.invoke('desktop:kswarm:restart') as Promise<void>,
@@ -1961,12 +1971,12 @@ export function createPreloadApi(ipcRenderer: IpcRendererLike, systemUsername =
     kbPickFiles: () => ipcRenderer.invoke('desktop:kb:pickFiles') as Promise<string[]>,
     meetingPickAudioFile: () => ipcRenderer.invoke('desktop:meeting:pickAudioFile') as Promise<string | null>,
     meetingGetMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:getMicrophonePermission') as Promise<MeetingReadonlyPermission>,
-    meetingRequestMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:requestMicrophonePermission') as Promise<unknown>,
+    meetingRequestMicrophonePermission: () => ipcRenderer.invoke('desktop:meeting:requestMicrophonePermission') as Promise<import('../shared/meeting-readonly-ipc-contract.js').MeetingReadonlyPermission>,
     meetingGetAsrConfig: () => ipcRenderer.invoke('desktop:meeting:getAsrConfig') as Promise<MeetingReadonlyAsr>,
     meetingSaveAsrConfig: (input) => ipcRenderer.invoke('desktop:meeting:saveAsrConfig', input) as Promise<MeetingAsrConfigSnapshot>,
     meetingListModels: () => ipcRenderer.invoke('desktop:meeting:listModels') as Promise<MeetingReadonlyModels>,
-    meetingDownloadModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:downloadModel', modelId) as Promise<unknown>,
-    meetingUninstallModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:uninstallModel', modelId) as Promise<unknown>,
+    meetingDownloadModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:downloadModel', modelId) as Promise<MeetingMutationModelResult>,
+    meetingUninstallModel: (modelId: string) => ipcRenderer.invoke('desktop:meeting:uninstallModel', modelId) as Promise<MeetingMutationModelResult>,
     meetingSaveRecordedAudio: (input) => ipcRenderer.invoke('desktop:meeting:saveRecordedAudio', input) as Promise<unknown>,
     meetingTranscribePreview: (input) => ipcRenderer.invoke('desktop:meeting:transcribePreview', input) as Promise<unknown>,
     meetingStartLiveTranscription: (input) => ipcRenderer.invoke('desktop:meeting:live:start', input) as ReturnType<DesktopApi['meetingStartLiveTranscription']>,
diff --git a/desktop/renderer/src/api/bridge.ts b/desktop/renderer/src/api/bridge.ts
index 5a14d183..cc6e51e4 100644
--- a/desktop/renderer/src/api/bridge.ts
+++ b/desktop/renderer/src/api/bridge.ts
@@ -758,10 +758,10 @@ export const api = {
   async listChannels() {
     return window.xiaokDesktop.listChannels();
   },
-  async createChannel(input: { type: string; name: string; webhookUrl?: string }) {
+  async createChannel(input: { type: string; name: string; webhookUrl?: string; appId?: string; appSecret?: string; token?: string; botToken?: string; chatId?: string }) {
     return window.xiaokDesktop.createChannel(input as never);
   },
-  async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean }) {
+  async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean; appId?: string; appSecret?: string; token?: string; botToken?: string; chatId?: string }) {
     return window.xiaokDesktop.updateChannel(id, input as never);
   },
   async deleteChannel(id: string) {
@@ -769,7 +769,7 @@ export const api = {
   },
   async testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }> {
     if (!window.xiaokDesktop?.testChannel) {
-      return { success: false, error: 'testChannel API not available' };
+      throw Error('channel_mcp_mutation_runtime_unavailable');
     }
     return await window.xiaokDesktop.testChannel(channelId);
   },
@@ -843,7 +843,7 @@ export const api = {
   async createMCPInstall(input: { name: string; source: string; command: string; args?: string[] }) {
     return window.xiaokDesktop.createMCPInstall(input as never);
   },
-  async updateMCPInstall(id: string, input: { name?: string; source?: string; command?: string; enabled?: boolean }) {
+  async updateMCPInstall(id: string, input: { name?: string; source?: string; command?: string; args?: string[]; enabled?: boolean }) {
     return window.xiaokDesktop.updateMCPInstall(id, input as never);
   },
   async deleteMCPInstall(id: string) {
@@ -1402,7 +1402,9 @@ export async function searchMarketSkills(_accessToken: string, _query: string, _
 }
 
 export async function installSkill(_accessToken: string, ref: SkillReference): Promise<{ success: boolean; message: string }> {
-  return api.installSkill(ref.skill_key);
+  const result = await api.installSkill(ref.skill_key);
+  if (!result.success) throw new Error(result.message);
+  return result;
 }
 
 export async function deleteSkill(_accessToken: string, ref: SkillReference): Promise<void> {
diff --git a/desktop/renderer/src/components/DesktopSettings.tsx b/desktop/renderer/src/components/DesktopSettings.tsx
index 8af02990..a09abcb5 100644
--- a/desktop/renderer/src/components/DesktopSettings.tsx
+++ b/desktop/renderer/src/components/DesktopSettings.tsx
@@ -367,6 +367,15 @@ function VoicePane() {
   const [modelStatusesError, setModelStatusesError] = useState('');
   const [modelAction, setModelAction] = useState<MeetingModelActionState | null>(null);
 
+  // One mounted action owner. Locale changes reproject reasons at render time;
+  // they do not cancel an already authorized main-process mutation.
+  const actionLifetime = useRef<{ active: boolean; saving: boolean; model: boolean } | null>(null);
+  useEffect(() => {
+    const owner = { active: true, saving: false, model: false };
+    actionLifetime.current = owner;
+    return () => { owner.active = false; };
+  }, []);
+
   const engineLabels: Record<MeetingTranscriberEngine, string> = {
     'sherpa-onnx-paraformer': t.knowledge.meetingSpeechEngineSherpaOnnxParaformer,
     whisper: t.knowledge.meetingSpeechEngineWhisperFallback,
@@ -452,7 +461,10 @@ function VoicePane() {
   };
 
   const handleSaveMeetingAsrConfig = async () => {
-    if (!desktop?.meetingSaveAsrConfig || saving) return;
+    const owner = actionLifetime.current;
+    if (!desktop?.meetingSaveAsrConfig || !owner?.active || owner.saving) return;
+    owner.saving = true;
+    const current = () => owner.active && actionLifetime.current === owner;
     setSaving(true);
     setSaved(false);
     setSaveError('');
@@ -479,7 +491,11 @@ function VoicePane() {
         : { defaultProvider: engine };
     try {
       const snapshot = await desktop.meetingSaveAsrConfig(input) as MeetingAsrConfigSnapshot;
+      if (!current()) return;
+      // A read failure remains a read failure. It cannot change this confirmed
+      // save into a failure or replace the readonly owner's last-good facts.
       await asrFacts.reload().catch(() => {});
+      if (!current()) return;
       setAsrDraft(prev => ({
         ...prev,
         volcAppKey: '',
@@ -491,43 +507,52 @@ function VoicePane() {
       }));
       setSaved(true);
     } catch (error) {
-      setSaveError(t.knowledge.meetingOnlineAsrSaveFailed(error instanceof Error ? error.message : 'unknown'));
+      if (current()) setSaveError(error instanceof Error ? error.message : 'unknown');
     } finally {
-      setSaving(false);
+      owner.saving = false;
+      if (current()) setSaving(false);
     }
   };
 
   const handleDownloadMeetingModel = async (modelId: string) => {
-    if (!desktop?.meetingDownloadModel || modelAction) return;
+    const owner = actionLifetime.current;
+    if (!desktop?.meetingDownloadModel || !owner?.active || owner.model) return;
+    owner.model = true;
+    const current = () => owner.active && actionLifetime.current === owner;
     setModelAction({ modelId, kind: 'download' });
     setModelStatusesError('');
     try {
       const result = await desktop.meetingDownloadModel(modelId) as { ok?: boolean; reason?: string; error?: string };
+      if (!current()) return;
+      if (result?.ok === false) setModelStatusesError(result.reason ?? result.error ?? 'unknown');
       await loadMeetingModelStatuses();
-      if (result?.ok === false) {
-        setModelStatusesError(t.knowledge.meetingModelActionFailed(result.reason ?? result.error ?? 'unknown'));
-      }
-      setModelAction(null);
+      if (!current()) return;
     } catch (error) {
-      setModelStatusesError(t.knowledge.meetingModelActionFailed(error instanceof Error ? error.message : 'unknown'));
-      setModelAction(null);
+      if (current()) setModelStatusesError(error instanceof Error ? error.message : 'unknown');
+    } finally {
+      owner.model = false;
+      if (current()) setModelAction(null);
     }
   };
 
   const handleUninstallMeetingModel = async (modelId: string) => {
-    if (!desktop?.meetingUninstallModel || modelAction) return;
+    const owner = actionLifetime.current;
+    if (!desktop?.meetingUninstallModel || !owner?.active || owner.model) return;
+    owner.model = true;
+    const current = () => owner.active && actionLifetime.current === owner;
     setModelAction({ modelId, kind: 'uninstall' });
     setModelStatusesError('');
     try {
       const result = await desktop.meetingUninstallModel(modelId) as { ok?: boolean; reason?: string; error?: string };
+      if (!current()) return;
+      if (result?.ok === false) setModelStatusesError(result.reason ?? result.error ?? 'unknown');
       await loadMeetingModelStatuses();
-      if (result?.ok === false) {
-        setModelStatusesError(t.knowledge.meetingModelActionFailed(result.reason ?? result.error ?? 'unknown'));
-      }
-      setModelAction(null);
+      if (!current()) return;
     } catch (error) {
-      setModelStatusesError(t.knowledge.meetingModelActionFailed(error instanceof Error ? error.message : 'unknown'));
-      setModelAction(null);
+      if (current()) setModelStatusesError(error instanceof Error ? error.message : 'unknown');
+    } finally {
+      owner.model = false;
+      if (current()) setModelAction(null);
     }
   };
 
@@ -682,7 +707,7 @@ function VoicePane() {
             <p className="text-sm text-[var(--c-text-secondary)]">{t.knowledge.meetingModelDownloadStatusTitle}</p>
             {modelStatusesLoading && <span className="text-xs text-[var(--c-text-tertiary)]">{t.knowledge.meetingModelStatusLoading}</span>}
           </div>
-          {modelStatusesError && <p className="text-xs leading-5 text-red-600">{modelStatusesError}</p>}
+          {modelStatusesError && <p className="text-xs leading-5 text-red-600">{t.knowledge.meetingModelActionFailed(modelStatusesError)}</p>}
           {groupedModelStatuses.length > 0 ? (
             <div className="space-y-4">
               {groupedModelStatuses.map(group => (
@@ -784,7 +809,7 @@ function VoicePane() {
           <div className="mt-4 flex items-center justify-between gap-3">
             <div className="min-w-0">
               {saved && <p className="text-xs text-green-700">{ds.meetingAsrSaved}</p>}
-              {saveError && <p className="text-xs text-red-600">{saveError}</p>}
+              {saveError && <p className="text-xs text-red-600">{t.knowledge.meetingOnlineAsrSaveFailed(saveError)}</p>}
             </div>
             <button type="button" onClick={() => void handleSaveMeetingAsrConfig()} disabled={saving} className={btnPrimary}>
               {saving ? ds.meetingAsrSaving : ds.meetingAsrSave}
@@ -2086,63 +2111,110 @@ function ChannelsPane() {
   const [newType, setNewType] = useState('yunzhijia');
   const [newName, setNewName] = useState('');
   const [newFields, setNewFields] = useState<Record<string, string>>({});
-  const [testingChannel, setTestingChannel] = useState<string | null>(null);
   const [error, setError] = useState('');
   const [success, setSuccess] = useState('');
 
-  const { t } = useLocale();
+  const { t, locale } = useLocale();
   const ts = t.desktopSettings;
   const channelTypeConfig = getChannelTypeConfig(ts);
 
   const load = channelFacts.refresh;
 
+  type ActionOwner = { active: boolean; epoch: number; pending: Map<string, symbol> };
+  type ActionLease = { owner: ActionOwner; epoch: number; token: symbol; keys: string[] };
+  const actionOwner = useRef<ActionOwner>({ active: false, epoch: 0, pending: new Map() });
+  const [pendingActions, setPendingActions] = useState<ReadonlySet<string>>(() => new Set());
+  const testRevision = useRef(0);
+  useEffect(() => {
+    const owner = actionOwner.current;
+    owner.active = true; owner.epoch += 1;
+    setPendingActions(new Set(owner.pending.keys()));
+    setError(''); setSuccess('');
+    return () => {
+      owner.active = false; owner.epoch += 1;
+      testRevision.current += 1;
+      // Pending effects remain locked across locale changes until their real settlement.
+    };
+  }, [locale]);
+  const beginAction = (keys: string[]): ActionLease | null => {
+    const owner = actionOwner.current;
+    if (!owner.active || keys.some(key => owner.pending.has(key))) return null;
+    const token = Symbol();
+    for (const key of keys) owner.pending.set(key, token);
+    setPendingActions(new Set(owner.pending.keys()));
+    return { owner, epoch: owner.epoch, token, keys };
+  };
+  const isCurrentAction = (lease: ActionLease) => actionOwner.current === lease.owner
+    && lease.owner.active && lease.owner.epoch === lease.epoch;
+  const finishAction = (lease: ActionLease) => {
+    for (const key of lease.keys) if (lease.owner.pending.get(key) === lease.token) lease.owner.pending.delete(key);
+    // An old locale may release only its own settled locks; it cannot publish an action fact.
+    if (actionOwner.current === lease.owner && lease.owner.active) setPendingActions(new Set(lease.owner.pending.keys()));
+  };
+
   // Reset fields when type changes
   useEffect(() => {
     setNewFields({});
   }, [newType]);
 
   const handleCreate = async () => {
-    if (!newName.trim()) return;
+    if (!actionOwner.current.active || actionOwner.current.pending.has('create') || !newName.trim()) return;
     const typeConfig = channelTypeConfig[newType];
-    // Check required fields
     for (const field of typeConfig.fields) {
       if (field.required && !newFields[field.key]?.trim()) {
         alert(ts.channelsFieldRequired(field.label));
         return;
       }
     }
+    const lease = beginAction(['create', 'row:' + newType]);
+    if (!lease) return;
     try {
-      await api.createChannel({
-        type: newType,
-        name: newName.trim(),
-        ...newFields,
-      });
-      setNewName('');
-      setNewFields({});
-      setShowAdd(false);
+      await api.createChannel({ type: newType, name: newName.trim(), ...newFields });
+      if (!isCurrentAction(lease)) return;
+      setNewName(''); setNewFields({}); setShowAdd(false);
       load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+    } catch {
+      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleDelete = async (id: string) => {
+    if (!actionOwner.current.active || actionOwner.current.pending.has('row:' + id)) return;
     if (!confirm(ts.channelsDeleteConfirm)) return;
+    const lease = beginAction(['row:' + id]);
+    if (!lease) return;
     try {
       await api.deleteChannel(id);
-      load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+      if (isCurrentAction(lease)) load();
+    } catch {
+      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleToggle = async (channel: ChannelConfig) => {
+    const lease = beginAction(['row:' + channel.id]);
+    if (!lease) return;
     try {
       await api.updateChannel(channel.id, { enabled: !channel.enabled });
-      load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+      if (isCurrentAction(lease)) load();
+    } catch {
+      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
+    } finally { finishAction(lease); }
+  };
+
+  const handleTest = async (id: string) => {
+    const lease = beginAction(['test:' + id]);
+    if (!lease) return;
+    const revision = ++testRevision.current;
+    setError(''); setSuccess('');
+    try {
+      const result = await api.testChannel(id);
+      if (!isCurrentAction(lease) || revision !== testRevision.current) return;
+      if (result.success) setSuccess(ts.channelsTestSuccess(result.latencyMs ?? 0));
+      else setError(result.error?.startsWith('channel_mcp_mutation_') ? ts.channelsTestFailed : result.error || ts.channelsTestFailed);
+    } catch {
+      if (isCurrentAction(lease) && revision === testRevision.current) setError(ts.channelsTestFailed);
+    } finally { finishAction(lease); }
   };
 
   if (loading) {
@@ -2236,7 +2308,7 @@ function ChannelsPane() {
                 </div>
               ))}
               <div className="flex gap-2">
-                <button type="button" onClick={handleCreate} className={btnPrimary}>{ts.channelsCreateBtn}</button>
+                <button type="button" onClick={handleCreate} disabled={pendingActions.has('create')} className={btnPrimary}>{ts.channelsCreateBtn}</button>
                 <button type="button" onClick={() => setShowAdd(false)} className={btnSecondary}>{ts.channelsCancelBtn}</button>
               </div>
             </div>
@@ -2267,28 +2339,15 @@ function ChannelsPane() {
                   </div>
                   <div className="flex items-center gap-2 flex-wrap">
                     <button type="button"
-                      onClick={async () => {
-                        setTestingChannel(ch.id);
-                        try {
-                          const result = await api.testChannel(ch.id);
-                          if (result.success) {
-                            setSuccess(ts.channelsTestSuccess(result.latencyMs ?? 0));
-                          } else {
-                            setError(result.error || ts.channelsTestFailed);
-                          }
-                        } catch (e) {
-                          setError((e as Error).message);
-                        } finally {
-                          setTestingChannel(null);
-                        }
-                      }}
-                      disabled={testingChannel === ch.id}
+                      onClick={() => void handleTest(ch.id)}
+                      disabled={pendingActions.has('test:' + ch.id)}
                       className="inline-flex shrink-0 items-center gap-1 rounded-md border border-[var(--c-border)] px-2.5 py-1 text-xs text-[var(--c-text-secondary)] hover:bg-[var(--c-bg-deep)] transition-colors disabled:opacity-50"
                     >
-                      {testingChannel === ch.id ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
+                      {pendingActions.has('test:' + ch.id) ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                       {ts.channelsTestBtn}
                     </button>
                     <button type="button"
+                      disabled={pendingActions.has('row:' + ch.id)}
                       onClick={() => handleToggle(ch)}
                       className={`rounded-lg px-3 py-1.5 text-xs transition-colors ${
                         ch.enabled ? 'bg-green-50 text-green-600' : 'bg-[var(--c-bg-deep)] text-[var(--c-text-secondary)]'
@@ -2297,6 +2356,8 @@ function ChannelsPane() {
                       {ch.enabled ? ts.channelsEnabled : ts.channelsDisabled}
                     </button>
                     <button type="button"
+                      aria-label={ts.channelsDeleteConfirm}
+                      disabled={pendingActions.has('row:' + ch.id)}
                       onClick={() => handleDelete(ch.id)}
                       className="rounded-lg p-1.5 text-[var(--c-text-tertiary)] hover:text-red-500 transition-colors"
                     >
@@ -2342,6 +2403,35 @@ function McpPane() {
 
   const [installsReady, setInstallsReady] = useState(false), [installsUnavailable, setInstallsUnavailable] = useState(false);
   const [catalogUnavailable, setCatalogUnavailable] = useState(false);
+  type ActionOwner = { active: boolean; epoch: number; pending: Map<string, symbol> };
+  type ActionLease = { owner: ActionOwner; epoch: number; token: symbol; keys: string[] };
+  const actionOwner = useRef<ActionOwner>({ active: false, epoch: 0, pending: new Map() });
+  const [pendingActions, setPendingActions] = useState<ReadonlySet<string>>(() => new Set());
+  useEffect(() => {
+    const owner = actionOwner.current;
+    owner.active = true; owner.epoch += 1;
+    setPendingActions(new Set(owner.pending.keys()));
+    return () => {
+      owner.active = false; owner.epoch += 1;
+      // Pending effects remain locked across locale changes until their real settlement.
+    };
+  }, [locale]);
+  const beginAction = (keys: string[]): ActionLease | null => {
+    const owner = actionOwner.current;
+    if (!owner.active || keys.some(key => owner.pending.has(key))) return null;
+    const token = Symbol();
+    for (const key of keys) owner.pending.set(key, token);
+    setPendingActions(new Set(owner.pending.keys()));
+    return { owner, epoch: owner.epoch, token, keys };
+  };
+  const isCurrentAction = (lease: ActionLease) => actionOwner.current === lease.owner
+    && lease.owner.active && lease.owner.epoch === lease.epoch;
+  const finishAction = (lease: ActionLease) => {
+    for (const key of lease.keys) if (lease.owner.pending.get(key) === lease.token) lease.owner.pending.delete(key);
+    // An old locale may release only its own settled locks; it cannot publish an action fact.
+    if (actionOwner.current === lease.owner && lease.owner.active) setPendingActions(new Set(lease.owner.pending.keys()));
+  };
+
   const readGeneration = useRef(0), pendingRead = useRef<number | null>(null), manualReread = useRef(false);
   const load = useCallback((queueIfBusy = true) => {
     if (pendingRead.current !== null) { if (queueIfBusy) manualReread.current = true; return; }
@@ -2374,30 +2464,32 @@ function McpPane() {
 
   const handleCreate = async () => {
     if (!newName.trim() || !newCommand.trim()) return;
+    const lease = beginAction(['create']);
+    if (!lease) return;
     try {
       await api.createMCPInstall({
-        name: newName.trim(),
-        source: 'npm',
-        command: newCommand.trim(),
+        name: newName.trim(), source: 'npm', command: newCommand.trim(),
         args: newArgs.trim() ? newArgs.trim().split(/\s+/) : undefined,
       });
-      setNewName('');
-      setNewCommand('');
-      setNewArgs('');
-      setShowAdd(false);
+      if (!isCurrentAction(lease)) return;
+      setNewName(''); setNewCommand(''); setNewArgs(''); setShowAdd(false);
       load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+    } catch {
+      if (isCurrentAction(lease)) alert(t.mcpMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleDelete = async (id: string) => {
+    if (!actionOwner.current.active || actionOwner.current.pending.has('row:' + id)) return;
+    if (!window.confirm(t.mcpInstallDeleteConfirm)) return;
+    const lease = beginAction(['row:' + id]);
+    if (!lease) return;
     try {
       await api.deleteMCPInstall(id);
-      load();
-    } catch (e) {
-      alert((e as Error).message);
-    }
+      if (isCurrentAction(lease)) load();
+    } catch {
+      if (isCurrentAction(lease)) alert(t.mcpMutationFailed);
+    } finally { finishAction(lease); }
   };
 
   const handleInstallDependency = async (dependency: PluginDependencyStatus) => {
@@ -2760,7 +2852,7 @@ function McpPane() {
                 />
               </div>
               <div className="flex gap-2">
-                <button type="button" onClick={handleCreate} className={btnPrimary}>{ts.mcpCreateBtn}</button>
+                <button type="button" onClick={handleCreate} disabled={pendingActions.has('create')} className={btnPrimary}>{ts.mcpCreateBtn}</button>
                 <button type="button" onClick={() => setShowAdd(false)} className={btnSecondary}>{ts.mcpCancelBtn}</button>
               </div>
             </div>
@@ -2792,6 +2884,8 @@ function McpPane() {
                     </div>
                   </div>
                   <button type="button"
+                    aria-label={t.mcpInstallDeleteConfirm}
+                    disabled={pendingActions.has('row:' + install.id)}
                     onClick={() => handleDelete(install.id)}
                     className="rounded-lg p-1.5 text-[var(--c-text-tertiary)] hover:text-red-500 transition-colors"
                   >
diff --git a/desktop/renderer/src/components/SkillsSettingsContent.tsx b/desktop/renderer/src/components/SkillsSettingsContent.tsx
index f83763a9..4085fa56 100644
--- a/desktop/renderer/src/components/SkillsSettingsContent.tsx
+++ b/desktop/renderer/src/components/SkillsSettingsContent.tsx
@@ -43,6 +43,9 @@ import { SkillDetailModal } from './skills/SkillDetailModal'
 import { primaryButtonSmCls, secondaryButtonBorderStyle, secondaryButtonSmCls } from './buttonStyles'
 import { api } from '../api'
 
+type SkillActionErrorKey = 'importFailed' | 'repositoryMissing' | 'deleteConflict' | 'disableFailed' | 'githubInvalidUrl' | 'githubSkillNotFound'
+type SkillAction = { lifetime: object }
+
 type Props = {
   accessToken: string
   onTrySkill?: (prompt: string) => void
@@ -62,7 +65,11 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
   const [loading, setLoading] = useState(true)
   const [marketLoading, setMarketLoading] = useState(false)
   const [officialDisabled, setOfficialDisabled] = useState(false)
-  const [error, setError] = useState('')
+  const [error, setRawError] = useState('')
+  const [actionErrorKey, setActionErrorKey] = useState<SkillActionErrorKey | null>(null)
+  const setError = useCallback((message: string) => { setActionErrorKey(null); setRawError(message) }, [])
+  const setActionError = useCallback((key: SkillActionErrorKey) => { setRawError(''); setActionErrorKey(key) }, [])
+  const visibleError = actionErrorKey ? skillText[actionErrorKey] : error
   const [busySkillId, setBusySkillId] = useState<string | null>(null)
   const [uploadOpen, setUploadOpen] = useState(false)
   const [githubOpen, setGitHubOpen] = useState(false)
@@ -81,6 +88,36 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
   const addMenuRef = useRef<HTMLDivElement>(null)
   const cardMenuRef = useRef<HTMLDivElement>(null)
   const statsMap = new Map((statFacts.data ?? []).map(s => [s.skillName, s]))
+  const actionLifetime = useRef<object | null>(null)
+  const actionFlight = useRef<SkillAction | null>(null)
+  const defaultRevision = useRef(0)
+  const currentDefaults = useRef(defaultSkills)
+  currentDefaults.current = defaultSkills
+  useEffect(() => {
+    const lifetime = {}
+    actionLifetime.current = lifetime
+    actionFlight.current = null
+    defaultRevision.current += 1
+    setBusySkillId(null); setImporting(false); setUploading(false)
+    return () => {
+      if (actionLifetime.current === lifetime) actionLifetime.current = null
+      if (actionFlight.current?.lifetime === lifetime) actionFlight.current = null
+    }
+  }, [accessToken])
+  // One page-owned default writer. Locale changes do not invalidate authorized work.
+  const beginAction = useCallback((): SkillAction | null => {
+    if (!actionLifetime.current || actionFlight.current) return null
+    const action = { lifetime: actionLifetime.current }
+    actionFlight.current = action
+    return action
+  }, [])
+  const isCurrentAction = useCallback((action: SkillAction) =>
+    actionLifetime.current === action.lifetime && actionFlight.current === action, [])
+  const finishAction = useCallback((action: SkillAction) => {
+    if (!isCurrentAction(action)) return false
+    actionFlight.current = null
+    return true
+  }, [isCurrentAction])
   const catalogPending = useRef<Promise<import('../../../shared/skill-list-ipc-contract').SkillListDto> | null>(null)
   const refreshCatalog = useCallback(async () => {
     if (catalogPending.current) return catalogPending.current
@@ -88,15 +125,24 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
     try { return await pending } finally { if (catalogPending.current === pending) catalogPending.current = null }
   }, [listFacts.reload])
   const refreshBuiltin = useCallback(async () => {
-    const snapshot = await refreshCatalog(); const items = mapPlatformSkillList(snapshot); setBuiltinSkills(items); return items
+    const lifetime = actionLifetime.current
+    const snapshot = await refreshCatalog(); const items = mapPlatformSkillList(snapshot)
+    if (lifetime && actionLifetime.current === lifetime) setBuiltinSkills(items)
+    return items
   }, [refreshCatalog])
   const refreshInstalled = useCallback(async () => {
+    const lifetime = actionLifetime.current, revision = defaultRevision.current
     const [snapshot, defaults] = await Promise.all([refreshCatalog(), listDefaultSkills(accessToken)])
-    setDefaultSkills(defaults)
+    if (lifetime && actionLifetime.current === lifetime && defaultRevision.current === revision) setDefaultSkills(defaults)
     return { installed: mapInstalledSkillList(snapshot), defaults }
   }, [refreshCatalog, accessToken])
   useEffect(() => { setLoading(listFacts.reading && listFacts.data === null) }, [listFacts.reading, listFacts.data])
-  useEffect(() => { void listDefaultSkills(accessToken).then(setDefaultSkills).catch(() => {}) }, [accessToken])
+  useEffect(() => {
+    let active = true
+    const revision = defaultRevision.current
+    void listDefaultSkills(accessToken).then(defaults => { if (active && revision === defaultRevision.current) setDefaultSkills(defaults) }).catch(() => {})
+    return () => { active = false }
+  }, [accessToken])
   useEffect(() => { setBuiltinSkills(null) }, [listFacts.data])
 
   useEffect(() => {
@@ -112,17 +158,17 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
         setMarketSkills(items)
         setOfficialDisabled(false)
         if (query.trim()) {
-          setError('')
+          setRawError('')
         }
       } catch (err) {
         const apiErr = isApiError(err) ? err : null
         if (apiErr?.status === 503 || apiErr?.code === 'skills.market.not_configured') {
           setOfficialDisabled(true)
           setMarketSkills([])
-          setError(skillText.officialUnconfigured)
+          setRawError(skillText.officialUnconfigured)
         } else {
           setMarketSkills([])
-          setError(apiErr?.message || skillText.officialSearchFailed)
+          setRawError(apiErr?.message || skillText.officialSearchFailed)
         }
       } finally {
         setMarketLoading(false)
@@ -160,13 +206,15 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
     return mergeSkills(installedSkills, defaultSkills, marketSkills, query, viewMode)
   }, [viewMode, defaultSkills, installedSkills, marketSkills, query])
 
-  const syncDefaultSkills = useCallback(async (updater: (current: SkillReference[]) => SkillReference[]) => {
-    const current = defaultSkills.map(asSkillRef)
+  const syncDefaultSkills = useCallback(async (updater: (current: SkillReference[]) => SkillReference[], action: SkillAction) => {
+    if (!isCurrentAction(action)) throw new Error('skill_action_stale')
+    const current = currentDefaults.current.map(asSkillRef)
     const next = dedupeSkillRefs(updater(current))
+    defaultRevision.current += 1
     const updated = await replaceDefaultSkills(accessToken, next)
-    setDefaultSkills(updated)
+    if (isCurrentAction(action)) setDefaultSkills(updated)
     return updated
-  }, [accessToken, defaultSkills])
+  }, [accessToken, isCurrentAction])
 
   const shouldConfirmRisk = useCallback((skill: { display_name: string; scan_status?: SkillPackageResponse['scan_status']; scan_summary?: string; scan_has_warnings?: boolean }) => {
     const status = skill.scan_status ?? (skill.scan_has_warnings ? 'suspicious' : 'unknown')
@@ -174,28 +222,36 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
     return window.confirm(skillText.riskConfirm(skill.display_name, skillText.scanStatusLabel(status), skill.scan_summary))
   }, [skillText])
 
-  const ensureInstalledAndDefault = useCallback(async (skill: SkillPackageResponse) => {
+  const ensureInstalledAndDefault = useCallback(async (skill: SkillPackageResponse, action: SkillAction) => {
+    if (!isCurrentAction(action)) return
     const exists = installedSkills.some((item) => item.skill_key === skill.skill_key && item.version === skill.version)
     if (!exists) {
-      await installSkill(accessToken, asSkillRef(skill))
+      const result = await installSkill(accessToken, asSkillRef(skill))
+      if (!isCurrentAction(action)) return
+      if (!result.success) throw new Error('skill_install_failed')
     }
-    await syncDefaultSkills((current) => [...current, asSkillRef(skill)])
+    await syncDefaultSkills((current) => [...current, asSkillRef(skill)], action)
+    if (!isCurrentAction(action)) return
     await refreshInstalled()
-  }, [accessToken, installedSkills, refreshInstalled, syncDefaultSkills])
+  }, [accessToken, installedSkills, isCurrentAction, refreshInstalled, syncDefaultSkills])
 
   const handleEnable = useCallback(async (item: ViewSkill) => {
+    const action = beginAction()
+    if (!action) return
     setBusySkillId(item.id)
     setError('')
     try {
       if (item.is_platform && item.version) {
         await setPlatformSkillOverride(accessToken, item.skill_key, item.version, 'auto')
+        if (!isCurrentAction(action)) return
         await Promise.all([refreshInstalled(), refreshBuiltin()])
         return
       }
       if (item.installed && item.version) {
         const version = item.version
         if (!shouldConfirmRisk(item)) return
-        await syncDefaultSkills((current) => [...current, { skill_key: item.skill_key, version }])
+        await syncDefaultSkills((current) => [...current, { skill_key: item.skill_key, version }], action)
+        if (!isCurrentAction(action)) return
         await refreshInstalled()
         return
       }
@@ -206,65 +262,72 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
         detail_url: item.detail_url,
         repository_url: item.repository_url,
       })
-      if (!shouldConfirmRisk(imported)) return
-      await ensureInstalledAndDefault(imported)
+      if (!isCurrentAction(action) || !shouldConfirmRisk(imported)) return
+      await ensureInstalledAndDefault(imported, action)
     } catch (err) {
+      if (!isCurrentAction(action)) return
       const apiErr = isApiError(err) ? err : null
-      if (apiErr?.code === 'skills.market.repository_missing') {
-        setError(skillText.repositoryMissing)
-      } else {
-        setError(apiErr?.message || skillText.importFailed)
-      }
+      if (apiErr?.code === 'skills.market.repository_missing') setActionError('repositoryMissing')
+      else if (apiErr?.message) setError(apiErr.message)
+      else setActionError('importFailed')
     } finally {
-      setBusySkillId(null)
+      if (finishAction(action)) setBusySkillId(null)
     }
-  }, [accessToken, ensureInstalledAndDefault, refreshBuiltin, refreshInstalled, shouldConfirmRisk, skillText.importFailed, skillText.repositoryMissing, syncDefaultSkills])
+  }, [accessToken, beginAction, ensureInstalledAndDefault, finishAction, isCurrentAction, refreshBuiltin, refreshInstalled, setActionError, setError, shouldConfirmRisk, syncDefaultSkills])
 
   const handleRemove = useCallback(async (item: ViewSkill) => {
     if (!item.version) return
+    const action = beginAction()
+    if (!action) return
     setBusySkillId(item.id)
     setError('')
     try {
       if (item.is_platform) {
         await setPlatformSkillOverride(accessToken, item.skill_key, item.version, 'removed')
+        if (!isCurrentAction(action)) return
         await Promise.all([refreshInstalled(), refreshBuiltin()])
         return
       }
-      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)))
+      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)), action)
+      if (!isCurrentAction(action)) return
       await deleteSkill(accessToken, { skill_key: item.skill_key, version: item.version })
+      if (!isCurrentAction(action)) return
       await refreshInstalled()
     } catch (err) {
+      if (!isCurrentAction(action)) return
       const apiErr = isApiError(err) ? err : null
-      if (apiErr?.code === 'skills.in_use') {
-        setError(skillText.deleteConflict)
-      } else {
-        setError(skillText.importFailed)
-      }
+      setActionError(apiErr?.code === 'skills.in_use' ? 'deleteConflict' : 'importFailed')
     } finally {
-      setBusySkillId(null)
+      if (finishAction(action)) setBusySkillId(null)
     }
-  }, [accessToken, refreshBuiltin, refreshInstalled, skillText.deleteConflict, skillText.importFailed, syncDefaultSkills])
+  }, [accessToken, beginAction, finishAction, isCurrentAction, refreshBuiltin, refreshInstalled, setActionError, setError, syncDefaultSkills])
 
   const handleDisable = useCallback(async (item: ViewSkill) => {
     if (!item.version) return
+    const action = beginAction()
+    if (!action) return
     setBusySkillId(item.id)
     setError('')
     try {
       if (item.is_platform) {
         await setPlatformSkillOverride(accessToken, item.skill_key, item.version, 'manual')
+        if (!isCurrentAction(action)) return
         await Promise.all([refreshInstalled(), refreshBuiltin()])
         return
       }
-      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)))
+      await syncDefaultSkills((current) => current.filter((skill) => !(skill.skill_key === item.skill_key && skill.version === item.version)), action)
+      if (!isCurrentAction(action)) return
       await refreshInstalled()
     } catch {
-      setError(skillText.disableFailed)
+      if (isCurrentAction(action)) setActionError('disableFailed')
     } finally {
-      setBusySkillId(null)
+      if (finishAction(action)) setBusySkillId(null)
     }
-  }, [accessToken, refreshBuiltin, refreshInstalled, skillText.disableFailed, syncDefaultSkills])
+  }, [accessToken, beginAction, finishAction, isCurrentAction, refreshBuiltin, refreshInstalled, setActionError, setError, syncDefaultSkills])
 
   const handleGitHubImport = useCallback(async (candidatePath?: string) => {
+    const action = beginAction()
+    if (!action) return
     setImporting(true)
     setError('')
     try {
@@ -273,54 +336,50 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
         ref: githubRef.trim() || undefined,
         candidate_path: candidatePath,
       })
+      if (!isCurrentAction(action)) return
       setCandidateState(null)
       setGitHubOpen(false)
-      await ensureInstalledAndDefault(response.skill)
+      await ensureInstalledAndDefault(response.skill, action)
+      if (!isCurrentAction(action)) return
       setGitHubUrl('')
       setGitHubRef('')
     } catch (err) {
+      if (!isCurrentAction(action)) return
       const apiErr = isApiError(err) ? err : null
       const details = apiErr?.details
       if (apiErr?.code === 'skills.import_ambiguous' && details && typeof details === 'object' && Array.isArray((details as { candidates?: unknown[] }).candidates)) {
-        setCandidateState({
-          candidates: (details as { candidates: SkillImportCandidate[] }).candidates,
-        })
+        setCandidateState({ candidates: (details as { candidates: SkillImportCandidate[] }).candidates })
         return
       }
-      if (apiErr?.code === 'skills.import_invalid_repository') {
-        setError(skillText.githubInvalidUrl)
-      } else if (apiErr?.code === 'skills.import_not_found') {
-        setError(skillText.githubSkillNotFound)
-      } else {
-        setError(apiErr?.message || skillText.importFailed)
-      }
+      if (apiErr?.code === 'skills.import_invalid_repository') setActionError('githubInvalidUrl')
+      else if (apiErr?.code === 'skills.import_not_found') setActionError('githubSkillNotFound')
+      else if (apiErr?.message) setError(apiErr.message)
+      else setActionError('importFailed')
     } finally {
-      setImporting(false)
+      if (finishAction(action)) setImporting(false)
     }
-  }, [accessToken, ensureInstalledAndDefault, githubRef, githubUrl, skillText.githubInvalidUrl, skillText.githubSkillNotFound, skillText.importFailed])
+  }, [accessToken, beginAction, ensureInstalledAndDefault, finishAction, githubRef, githubUrl, isCurrentAction, setActionError, setError])
 
   const handleUploadImport = useCallback(async () => {
     if (!file) return
+    const action = beginAction()
+    if (!action) return
     setUploading(true)
     setError('')
     try {
-      const response = await importSkillFromUpload(accessToken, {
-        file,
-        install_after_import: false,
-      })
-      if (installAfterImport) {
-        await ensureInstalledAndDefault(response)
-      } else {
-        await refreshInstalled()
-      }
+      const response = await importSkillFromUpload(accessToken, { file, install_after_import: false })
+      if (!isCurrentAction(action)) return
+      if (installAfterImport) await ensureInstalledAndDefault(response, action)
+      else await refreshInstalled()
+      if (!isCurrentAction(action)) return
       setFile(null)
       setUploadOpen(false)
     } catch {
-      setError(skillText.importFailed)
+      if (isCurrentAction(action)) setActionError('importFailed')
     } finally {
-      setUploading(false)
+      if (finishAction(action)) setUploading(false)
     }
-  }, [accessToken, ensureInstalledAndDefault, file, installAfterImport, refreshInstalled, skillText.importFailed])
+  }, [accessToken, beginAction, ensureInstalledAndDefault, file, finishAction, installAfterImport, isCurrentAction, refreshInstalled, setActionError, setError])
 
   const active = (item: ViewSkill) => item.installed && item.enabled_by_default
 
@@ -454,8 +513,8 @@ export function SkillsSettingsContent({ accessToken, onTrySkill }: Props) {
       {viewMode === 'marketplace' && officialDisabled && (
         <p className="text-xs text-[var(--c-text-tertiary)]">{skillText.officialUnconfigured}</p>
       )}
-      {error && (
-        <p className="text-xs" style={{ color: 'var(--c-status-error-text)' }}>{error}</p>
+      {visibleError && (
+        <p className="text-xs" style={{ color: 'var(--c-status-error-text)' }}>{visibleError}</p>
       )}
 
       {viewMode === 'installed' && (
diff --git a/desktop/renderer/src/contexts/KSwarmContext.tsx b/desktop/renderer/src/contexts/KSwarmContext.tsx
index 42259e33..10ee13f6 100644
--- a/desktop/renderer/src/contexts/KSwarmContext.tsx
+++ b/desktop/renderer/src/contexts/KSwarmContext.tsx
@@ -1,41 +1,29 @@
+import { useKswarmStatusReadonly } from '../hooks/useKswarmStatusReadonly';
 /**
  * KSwarmContext — provides kswarm client state and actions to the component tree.
  *
  * Also manages the kswarm service lifecycle status via IPC.
  */
 
-import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
+import { createContext, useContext, type ReactNode } from 'react';
 import { useKSwarmClient, type KSwarmClientState, type KSwarmClientActions } from '../hooks/useKSwarmClient';
 import type { KSwarmServiceStatus } from '../../../electron/preload-api';
-import { getDesktopApi } from '../shared/desktop';
 
 interface KSwarmContextValue extends KSwarmClientState, KSwarmClientActions {
   serviceStatus: KSwarmServiceStatus | null;
+  serviceStatusReadFailed: boolean;
+  serviceStatusReading: boolean;
+  reloadServiceStatus(): void;
 }
 
 const KSwarmContext = createContext<KSwarmContextValue | null>(null);
 
 export function KSwarmProvider({ children }: { children: ReactNode }) {
   const client = useKSwarmClient();
-  const [serviceStatus, setServiceStatus] = useState<KSwarmServiceStatus | null>(null);
-
-  useEffect(() => {
-    const api = getDesktopApi() as { kswarmGetStatus(): Promise<KSwarmServiceStatus>; onKSwarmStatus(cb: (s: KSwarmServiceStatus) => void): () => void } | null;
-    if (!api) return;
-
-    // Get initial status
-    api.kswarmGetStatus().then(setServiceStatus).catch(() => {});
-
-    // Subscribe to status changes
-    const unsub = api.onKSwarmStatus((status) => {
-      setServiceStatus(status);
-    });
-
-    return unsub;
-  }, []);
+  const status = useKswarmStatusReadonly();
 
   return (
-    <KSwarmContext.Provider value={{ ...client, serviceStatus }}>
+    <KSwarmContext.Provider value={{ ...client, serviceStatus: status.data, serviceStatusReadFailed: status.failed, serviceStatusReading: status.reading, reloadServiceStatus: status.refresh }}>
       {children}
     </KSwarmContext.Provider>
   );
diff --git a/desktop/renderer/src/locales/en.ts b/desktop/renderer/src/locales/en.ts
index e7871ea1..bf1553ed 100644
--- a/desktop/renderer/src/locales/en.ts
+++ b/desktop/renderer/src/locales/en.ts
@@ -3046,6 +3046,9 @@ export const en: LocaleStrings = {
   meetingModelsReadonlyUnavailable: 'Unable to read meeting models',
   meetingAsrReadonlyUnknown: 'Speech configuration unknown',
   meetingAsrReadonlyUnavailable: 'Unable to read speech configuration',
+  channelMutationFailed: 'Channel operation failed. Please try again.',
+  mcpMutationFailed: 'MCP configuration operation failed. Please try again.',
+  mcpInstallDeleteConfirm: 'Delete this MCP configuration?',
   channelReadonlyUnknown: 'Channel information unknown',
   channelReadonlyUnavailable: 'Unable to read channels',
   mcpInstallsReadonlyUnknown: 'MCP installation information unknown',
diff --git a/desktop/renderer/src/locales/index.ts b/desktop/renderer/src/locales/index.ts
index 1ea700d4..06e5fb54 100644
--- a/desktop/renderer/src/locales/index.ts
+++ b/desktop/renderer/src/locales/index.ts
@@ -2933,6 +2933,9 @@ export interface LocaleStrings {
   meetingModelsReadonlyUnavailable: string;
   meetingAsrReadonlyUnknown: string;
   meetingAsrReadonlyUnavailable: string;
+  channelMutationFailed: string;
+  mcpMutationFailed: string;
+  mcpInstallDeleteConfirm: string;
   channelReadonlyUnknown: string;
   channelReadonlyUnavailable: string;
   mcpInstallsReadonlyUnknown: string;
diff --git a/desktop/renderer/src/locales/zh.ts b/desktop/renderer/src/locales/zh.ts
index 0b9cfa90..90129b98 100644
--- a/desktop/renderer/src/locales/zh.ts
+++ b/desktop/renderer/src/locales/zh.ts
@@ -3026,6 +3026,9 @@ export const zh: LocaleStrings = {
   meetingModelsReadonlyUnavailable: '\u65e0\u6cd5\u8bfb\u53d6\u4f1a\u8bae\u6a21\u578b',
   meetingAsrReadonlyUnknown: '\u8bed\u97f3\u914d\u7f6e\u672a\u77e5',
   meetingAsrReadonlyUnavailable: '\u65e0\u6cd5\u8bfb\u53d6\u8bed\u97f3\u914d\u7f6e',
+  channelMutationFailed: '通道操作失败，请重试',
+  mcpMutationFailed: 'MCP 配置操作失败，请重试',
+  mcpInstallDeleteConfirm: '确定删除此 MCP 配置？',
   channelReadonlyUnknown: '通道信息未知',
   channelReadonlyUnavailable: '无法读取消息通道',
   mcpInstallsReadonlyUnknown: 'MCP 安装信息未知',
diff --git a/desktop/tests/main/channel-mcp-readonly-controls.test.ts b/desktop/tests/main/channel-mcp-readonly-controls.test.ts
index 3c79120a..c0a6cb8c 100644
--- a/desktop/tests/main/channel-mcp-readonly-controls.test.ts
+++ b/desktop/tests/main/channel-mcp-readonly-controls.test.ts
@@ -43,7 +43,7 @@ it('bad channel config rejects without modifying the real owned file or creating
   await expect(async () => f.invoke('listChannels')).rejects.toThrow(); expect(readFileSync(path, 'utf8')).toBe('{'); expect(existsSync(path + '.bak')).toBe(false);
 });
 it('actual existing MCP creation output passes the readonly schema with original command and args', async () => {
-  const f = await fixture(), created = await f.service.createMCPInstall({ name:'owned',source:'local',command:'C:\\owned\\command',args:['--owned',''] });
+  const f = await fixture(), created = await f.service.createMCPInstall({ name:'owned',source:'local',command:'C:\\owned\\command',args:['--owned',''] }, 'user');
   const rows = await f.invoke('listMCPInstalls'); expect(rows).toHaveLength(1); expect(rows[0]).toMatchObject(created); expect(rows[0].args).toEqual(['--owned','']);
 });
 it('preserves real absent file success for both readonly facts', async () => { const f = await fixture(); expect(await f.invoke('listChannels')).toEqual([]); expect(await f.invoke('listMCPInstalls')).toEqual([]); });
diff --git a/desktop/tests/main/desktop-services.test.ts b/desktop/tests/main/desktop-services.test.ts
index 2ddf785a..be2860fe 100644
--- a/desktop/tests/main/desktop-services.test.ts
+++ b/desktop/tests/main/desktop-services.test.ts
@@ -4010,7 +4010,7 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    const channel = await services.createChannel({ type: 'discord', name: 'My Discord', webhookUrl: 'https://discord.com/api/webhooks/...' });
+    const channel = await services.createChannel({ type: 'discord', name: 'My Discord', webhookUrl: 'https://discord.com/api/webhooks/...' }, 'user');
     expect(channel.id).toBe('discord');
     expect(channel.type).toBe('discord');
     expect(channel.name).toBe('My Discord');
@@ -4031,10 +4031,10 @@ describe('desktop services', () => {
     });
 
     // First create
-    await services.createChannel({ type: 'telegram', name: 'Old Name' });
+    await services.createChannel({ type: 'telegram', name: 'Old Name' }, 'user');
 
     // Then update
-    const updated = await services.updateChannel('telegram', { name: 'New Name', webhookUrl: 'https://api.telegram.org/bot123' });
+    const updated = await services.updateChannel('telegram', { name: 'New Name', webhookUrl: 'https://api.telegram.org/bot123' }, 'user');
     expect(updated.name).toBe('New Name');
     expect(updated.webhookUrl).toBe('https://api.telegram.org/bot123');
   });
@@ -4046,7 +4046,7 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    await expect(services.updateChannel('nonexistent', { name: 'test' })).rejects.toThrow('not found');
+    await expect(services.updateChannel('nonexistent', { name: 'test' }, 'user')).rejects.toThrow('not found');
   });
 
   it('deletes a channel from config.json', async () => {
@@ -4056,11 +4056,11 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    await services.createChannel({ type: 'feishu', name: 'Feishu' });
+    await services.createChannel({ type: 'feishu', name: 'Feishu' }, 'user');
     let channels = await services.listChannels();
     expect(channels.find(c => c.id === 'feishu')).toBeDefined();
 
-    await services.deleteChannel('feishu');
+    await services.deleteChannel('feishu', 'user');
     channels = await services.listChannels();
     expect(channels.find(c => c.id === 'feishu')).toBeUndefined();
   });
@@ -4089,7 +4089,7 @@ describe('desktop services', () => {
       name: 'Playwright',
       source: 'npm',
       command: '@anthropic/mcp-playwright',
-    });
+    }, 'user');
 
     expect(install.id).toBeDefined();
     expect(install.name).toBe('Playwright');
@@ -4115,9 +4115,9 @@ describe('desktop services', () => {
       name: 'Brave Search',
       source: 'npm',
       command: '@anthropic/mcp-brave-search',
-    });
+    }, 'user');
 
-    const updated = await services.updateMCPInstall(created.id, { enabled: false });
+    const updated = await services.updateMCPInstall(created.id, { enabled: false }, 'user');
     expect(updated.enabled).toBe(false);
   });
 
@@ -4128,7 +4128,7 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    await expect(services.updateMCPInstall('nonexistent', { enabled: false })).rejects.toThrow('not found');
+    await expect(services.updateMCPInstall('nonexistent', { enabled: false }, 'user')).rejects.toThrow('not found');
   });
 
   it('deletes an MCP install', async () => {
@@ -4138,8 +4138,8 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    const created = await services.createMCPInstall({ name: 'Test MCP', source: 'npm', command: 'test' });
-    await services.deleteMCPInstall(created.id);
+    const created = await services.createMCPInstall({ name: 'Test MCP', source: 'npm', command: 'test' }, 'user');
+    await services.deleteMCPInstall(created.id, 'user');
 
     const installs = await services.listMCPInstalls();
     expect(installs).toHaveLength(0);
@@ -4152,8 +4152,8 @@ describe('desktop services', () => {
       now: () => 300,
     });
 
-    const install1 = await services.createMCPInstall({ name: 'MCP1', source: 'npm', command: 'cmd1' });
-    const install2 = await services.createMCPInstall({ name: 'MCP2', source: 'github', command: 'cmd2' });
+    const install1 = await services.createMCPInstall({ name: 'MCP1', source: 'npm', command: 'cmd1' }, 'user');
+    const install2 = await services.createMCPInstall({ name: 'MCP2', source: 'github', command: 'cmd2' }, 'user');
 
     expect(install1.id).not.toBe(install2.id);
     expect(install1.source).toBe('npm');
diff --git a/desktop/tests/main/ipc-schema-coverage.test.ts b/desktop/tests/main/ipc-schema-coverage.test.ts
index bdd51a18..c6ff7ef4 100644
--- a/desktop/tests/main/ipc-schema-coverage.test.ts
+++ b/desktop/tests/main/ipc-schema-coverage.test.ts
@@ -1,3 +1,7 @@
+import { registerComputerUseCapabilityReadonlyIpc, registerKswarmStatusReadonlyIpc } from '../../electron/runtime-status-readonly-typed-ipc.js';
+import { registerSkillMutationIpc } from '../../electron/skill-mutation-typed-ipc.js';
+import { registerChannelMcpMutationIpc } from '../../electron/channel-mcp-mutation-typed-ipc.js';
+import { registerMeetingMutationIpc } from '../../electron/meeting-mutation-typed-ipc.js';
 import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from '../../electron/skill-list-typed-ipc.js';
@@ -24,6 +28,7 @@ registerAutomationConfigIpc({handle:channel=>{currentViewChannels.push(channel);
 registerSkillListIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerChannelMcpReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerMeetingReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
+registerComputerUseCapabilityReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});registerKswarmStatusReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});registerSkillMutationIpc({handle:channel=>{currentViewChannels.push(channel);}});registerChannelMcpMutationIpc({handle:channel=>{currentViewChannels.push(channel);}});registerMeetingMutationIpc({handle:channel=>{currentViewChannels.push(channel);}}, new Map());
 registerServiceControlIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerMobileReadonlyIpc({handle:channel=>{currentViewChannels.push(channel);}});
 registerPluginCatalogIpc({handle:channel=>{currentViewChannels.push(channel);}});
diff --git a/desktop/tests/main/preload-contract.test.ts b/desktop/tests/main/preload-contract.test.ts
index 0b246332..b43a0e8e 100644
--- a/desktop/tests/main/preload-contract.test.ts
+++ b/desktop/tests/main/preload-contract.test.ts
@@ -1,3 +1,7 @@
+import { registerComputerUseCapabilityReadonlyIpc, registerKswarmStatusReadonlyIpc } from '../../electron/runtime-status-readonly-typed-ipc.js';
+import { registerSkillMutationIpc } from '../../electron/skill-mutation-typed-ipc.js';
+import { registerChannelMcpMutationIpc } from '../../electron/channel-mcp-mutation-typed-ipc.js';
+import { registerMeetingMutationIpc } from '../../electron/meeting-mutation-typed-ipc.js';
 import { registerMeetingReadonlyIpc } from '../../electron/meeting-readonly-typed-ipc.js';
 import { registerChannelMcpReadonlyIpc } from '../../electron/channel-mcp-readonly-typed-ipc.js';
 import { registerSkillListIpc } from '../../electron/skill-list-typed-ipc.js';
@@ -1073,6 +1077,7 @@ function extractRegisteredHandlerChannels(): Set<string> {
   registerSkillListIpc({ handle: channel => { channels.add(channel); } });
   registerChannelMcpReadonlyIpc({ handle: channel => { channels.add(channel); } });
 registerMeetingReadonlyIpc({ handle: channel => { channels.add(channel); } });
+registerComputerUseCapabilityReadonlyIpc({ handle: channel => { channels.add(channel); } });registerKswarmStatusReadonlyIpc({ handle: channel => { channels.add(channel); } });registerSkillMutationIpc({ handle: channel => { channels.add(channel); } });registerChannelMcpMutationIpc({ handle: channel => { channels.add(channel); } });registerMeetingMutationIpc({ handle: channel => { channels.add(channel); } }, new Map());
   registerKSwarmProxy({ handle: channel => { channels.add(channel); } }, {} as never);
 registerLoopOutputIpc({handle:channel=>{channels.add(channel);}},{} as never,()=>false);
   registerConversationActivityIpc({ handle: channel => { channels.add(channel); } }, null, () => null);
diff --git a/desktop/tests/main/skill-reload-on-install.test.ts b/desktop/tests/main/skill-reload-on-install.test.ts
index 155fd155..a1c6ecd6 100644
--- a/desktop/tests/main/skill-reload-on-install.test.ts
+++ b/desktop/tests/main/skill-reload-on-install.test.ts
@@ -12,16 +12,105 @@
 import { describe, expect, it } from 'vitest';
 import { readFileSync } from 'node:fs';
 import { join } from 'node:path';
+import ts from 'typescript';
 
 const servicesSource = readFileSync(join(__dirname, '../../electron/desktop-services.ts'), 'utf-8');
+const mutationSource = readFileSync(join(__dirname, '../../electron/desktop-skill-mutation.ts'), 'utf-8');
 const mainSource = readFileSync(join(__dirname, '../../electron/main.ts'), 'utf-8');
 
 describe('skill install auto reload wiring', () => {
   it('bumps the shared catalog version from every install/uninstall entrance', () => {
-    // Two agent tools (skill_install / skill_uninstall) + two settings-pane
-    // services (installSkill / uninstallSkill) = at least 4 bump call sites.
-    const bumps = servicesSource.match(/bumpSkillCatalogVersion\(\)/g) ?? [];
-    expect(bumps.length).toBeGreaterThanOrEqual(4);
+    // Keep all four original entrances. Physical bump sites moved into the
+    // shared Desktop domain helper; literals in the old file are no longer
+    // evidence for its two callers. Real service behavior has separate controls.
+    const servicesAst = ts.createSourceFile('desktop-services.ts', servicesSource, ts.ScriptTarget.Latest, true);
+    const mutationAst = ts.createSourceFile('desktop-skill-mutation.ts', mutationSource, ts.ScriptTarget.Latest, true);
+    function nodes<T extends ts.Node>(root: ts.Node, guard: (node: ts.Node) => node is T): T[] {
+      const found: T[] = [];
+      const visit = (node: ts.Node) => { if (guard(node)) found.push(node); ts.forEachChild(node, visit); };
+      visit(root); return found;
+    }
+    function name(node: ts.PropertyName | undefined) {
+      return node && (ts.isIdentifier(node) || ts.isStringLiteral(node)) ? node.text : undefined;
+    }
+    function property(object: ts.ObjectLiteralExpression, key: string) {
+      return object.properties.find((node): node is ts.PropertyAssignment => ts.isPropertyAssignment(node) && name(node.name) === key)?.initializer;
+    }
+    function successfulBump(body: ts.Block, ast: ts.SourceFile, command: string, operand: string) {
+      const result = nodes(body, ts.isVariableDeclaration).filter(node => ts.isIdentifier(node.name) && node.name.text === 'result');
+      expect(result).toHaveLength(1);
+      const call = result[0]!.initializer;
+      expect(call && ts.isCallExpression(call)).toBe(true);
+      if (!call || !ts.isCallExpression(call)) throw Error('skill_command_call_missing');
+      expect(call.expression.getText(ast)).toBe(command);
+      expect(call.arguments[0] && ts.isStringLiteral(call.arguments[0]) ? call.arguments[0].text : undefined).toBe('clawhub');
+      const args = call.arguments[1];
+      expect(args && ts.isArrayLiteralExpression(args)).toBe(true);
+      if (!args || !ts.isArrayLiteralExpression(args)) throw Error('skill_command_argv_missing');
+      expect(args.elements).toHaveLength(2);
+      const operation = args.elements[0]!;
+      expect(ts.isStringLiteral(operation) ? operation.text : operation.getText(ast)).toBe(operand);
+      expect(args.elements[1]!.getText(ast)).toBe('skillName');
+      const bumps = nodes(body, ts.isCallExpression).filter(call => ts.isIdentifier(call.expression) && call.expression.text === 'bumpSkillCatalogVersion');
+      expect(bumps).toHaveLength(1);
+      const bumpIndex = body.statements.findIndex(statement => ts.isExpressionStatement(statement) && statement.expression === bumps[0]);
+      expect(bumpIndex).toBeGreaterThan(0);
+      for (const condition of ['result.error', 'result.status !== 0']) {
+        const index = body.statements.findIndex(statement => ts.isIfStatement(statement) && statement.expression.getText(ast) === condition);
+        expect(index).toBeGreaterThanOrEqual(0); expect(index).toBeLessThan(bumpIndex);
+        const statement = body.statements[index]!;
+        if (!ts.isIfStatement(statement)) throw Error('skill_failure_guard_missing');
+        const branch = statement.thenStatement;
+        expect(ts.isReturnStatement(branch) || ts.isBlock(branch) && ts.isReturnStatement(branch.statements[branch.statements.length - 1]!)).toBe(true);
+        expect(statement.elseStatement).toBeUndefined();
+      }
+      const success = body.statements[bumpIndex + 1]!;
+      expect(ts.isReturnStatement(success)).toBe(true);
+      const successDTO = nodes(success, ts.isObjectLiteralExpression).filter(dto => property(dto, 'success')?.kind === ts.SyntaxKind.TrueKeyword);
+      expect(successDTO).toHaveLength(1);
+    }
+    const owners = nodes(servicesAst, ts.isFunctionDeclaration).filter(node => node.name?.text === 'createDesktopServices');
+    expect(owners).toHaveLength(1);
+    const methods = nodes(owners[0]!, ts.isMethodDeclaration);
+    const registrations = methods.filter(node => name(node.name) === 'registerSkillTools');
+    expect(registrations).toHaveLength(1);
+    const entrancePopulation: string[] = [];
+    for (const [toolName, operation] of [['skill_install', 'install'], ['skill_uninstall', 'uninstall']] as const) {
+      const tools = nodes(registrations[0]!, ts.isObjectLiteralExpression).filter(tool => {
+        const definition = property(tool, 'definition');
+        if (!definition || !ts.isObjectLiteralExpression(definition)) return false;
+        const id = property(definition, 'name'); return id && ts.isStringLiteral(id) && id.text === toolName;
+      });
+      expect(tools).toHaveLength(1);
+      const executes = tools[0]!.properties.filter((node): node is ts.MethodDeclaration => ts.isMethodDeclaration(node) && name(node.name) === 'execute');
+      expect(executes).toHaveLength(1); expect(executes[0]!.body).toBeDefined();
+      successfulBump(executes[0]!.body!, servicesAst, 'spawnSync', operation);
+      entrancePopulation.push(toolName);
+    }
+    const imports = servicesAst.statements.filter((node): node is ts.ImportDeclaration => ts.isImportDeclaration(node)
+      && ts.isStringLiteral(node.moduleSpecifier) && node.moduleSpecifier.text === './desktop-skill-mutation.js');
+    expect(imports).toHaveLength(1);
+    const bindings = imports[0]!.importClause?.namedBindings;
+    expect(bindings && ts.isNamedImports(bindings) && bindings.elements.some(node => node.name.text === 'runDesktopSkillMutation' && !node.propertyName)).toBe(true);
+    for (const [methodName, operation] of [['installSkill', 'install'], ['uninstallSkill', 'uninstall']] as const) {
+      const delegates = methods.filter(node => name(node.name) === methodName);
+      expect(delegates).toHaveLength(1); expect(delegates[0]!.body?.statements).toHaveLength(1);
+      const statement = delegates[0]!.body!.statements[0]!;
+      expect(ts.isReturnStatement(statement)).toBe(true);
+      const call = ts.isReturnStatement(statement) ? statement.expression : undefined;
+      if (!call || !ts.isCallExpression(call)) throw Error('skill_desktop_delegate_missing');
+      expect(call.expression.getText(servicesAst)).toBe('runDesktopSkillMutation');
+      expect(call.arguments).toHaveLength(4);
+      expect(ts.isStringLiteral(call.arguments[0]!) ? call.arguments[0]!.text : undefined).toBe(operation);
+      expect(call.arguments.slice(1).map(node => node.getText(servicesAst))).toEqual(['skillName', 'context', 'process.cwd()']);
+      entrancePopulation.push(methodName);
+    }
+    const helpers = mutationAst.statements.filter((node): node is ts.FunctionDeclaration => ts.isFunctionDeclaration(node) && node.name?.text === 'runDesktopSkillMutation');
+    expect(helpers).toHaveLength(1);
+    expect(helpers[0]!.modifiers?.some(node => node.kind === ts.SyntaxKind.ExportKeyword)).toBe(true);
+    expect(helpers[0]!.body).toBeDefined();
+    successfulBump(helpers[0]!.body!, mutationAst, 'crossSpawn.sync', 'operation');
+    expect(entrancePopulation).toEqual(['skill_install', 'skill_uninstall', 'installSkill', 'uninstallSkill']);
   });
 
   it('runner reloads the catalog when the shared version changes instead of a one-shot gate', () => {
diff --git a/src/types/cross-spawn.d.ts b/src/types/cross-spawn.d.ts
index 6ee09b71..0ac7736f 100644
--- a/src/types/cross-spawn.d.ts
+++ b/src/types/cross-spawn.d.ts
@@ -8,5 +8,9 @@ declare module 'cross-spawn' {
 
   function spawn(command: string, args?: readonly string[], options?: SpawnOptions): ChildProcess;
 
+  namespace spawn {
+    const sync: typeof import('node:child_process').spawnSync;
+  }
+
   export = spawn;
 }

```

## FULL desktop/electron/channel-mcp-mutation-owner.ts
```typescript
// UNREVIEWED CANDIDATE — business owner only; not a new generic IPC/fs framework.
import { readFileSync, writeFileSync, mkdirSync, existsSync, chmodSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { types } from 'node:util';
import { getConfigPath, saveConfig } from '../../src/utils/config.js';
import { DEFAULT_CONFIG, isValidLegacyProvider, type Config, type LegacyConfig } from '../../src/types.js';
import { normalizeConfig } from '../../src/ai/providers/normalize.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { STORED_CHANNELS_READONLY_SCHEMA, MCP_INSTALLS_READONLY_OUTPUT_SCHEMA } from '../shared/channel-mcp-readonly-ipc-contract.js';
import { CHANNEL_MCP_MUTATION_INPUTS, type ChannelMcpMutationMethod } from '../shared/channel-mcp-mutation-ipc-contract.js';
type RequestSource = 'user' | 'agent' | 'scheduler';
const own = Object.hasOwn;
function admission(method: ChannelMcpMutationMethod, args: unknown[], source?: RequestSource): unknown[] {
  if (source !== 'user') throw Error('channel_mcp_mutation_request_source_forbidden');
  const captured = captureIpcData(args, 'channel_mcp_mutation_input_invalid');
  const parsed = CHANNEL_MCP_MUTATION_INPUTS[method].safeParse(captured);
  if (!parsed.success) throw Error('channel_mcp_mutation_input_invalid');
  return parsed.data;
}
function readJson(path: string): unknown | undefined {
  let bytes: string;
  try { bytes = readFileSync(path, 'utf8'); }
  catch (error) {
    if (error && typeof error === 'object' && !types.isProxy(error) && Object.getOwnPropertyDescriptor(error, 'code')?.value === 'ENOENT') return undefined;
    throw Error('channel_mcp_mutation_source_unavailable');
  }
  // Native JSON.parse messages may echo credential fragments. Do not transport them.
  try { return captureIpcData(JSON.parse(bytes), 'channel_mcp_mutation_source_unavailable', { preserveDataPrototype: true }); }
  catch { throw Error('channel_mcp_mutation_source_unavailable'); }
}
function configForEdit(): Record<string, unknown> & { channels: Record<string, Record<string, unknown>> } {
  const loaded = readJson(getConfigPath());
  const raw = loaded === undefined ? JSON.parse(JSON.stringify(DEFAULT_CONFIG)) : loaded;
  try {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw Error();
    const obj = raw as Record<string, unknown>;
    if (obj.schemaVersion !== 1 && obj.schemaVersion !== 2) throw Error();
    if (obj.schemaVersion === 1 && obj.defaultModel !== undefined && !isValidLegacyProvider(obj.defaultModel)) throw Error();
    if (obj.channels != null && !STORED_CHANNELS_READONLY_SCHEMA.safeParse(obj.channels).success) throw Error();
    const normalized = normalizeConfig(obj as unknown as LegacyConfig | Config);
    if (!STORED_CHANNELS_READONLY_SCHEMA.safeParse(normalized.channels ?? {}).success) throw Error();
    // Keep raw schema1/2 providers, keys, unknown extras and channel-specific state.
    // Normalize only to validate; a channel edit must not rewrite unrelated settings.
    obj.channels ??= {};
    return obj as Record<string, unknown> & { channels: Record<string, Record<string, unknown>> };
  } catch { throw Error('channel_mcp_mutation_source_unavailable'); }
}
async function persistConfig(config: Record<string, unknown>): Promise<void> {
  // saveConfig writes synchronously before returning its Promise. No await between read/edit/write.
  try { await saveConfig(config as unknown as Config); }
  catch { throw Error('channel_mcp_mutation_write_failed'); }
}
function channelView(id: string, row: Record<string, unknown>, createdAt = 0) {
  return { id, type: id, name: (row.name as string) || id, webhookUrl: (row.sendMsgUrl || row.webhookUrl) as string | undefined,
    enabled: row.enabled !== false, createdAt, updatedAt: Date.now() };
}
function readInstalls(root: string) {
  const raw = readJson(join(root, 'mcp-installs.json'));
  const rows = raw === undefined ? [] : raw;
  const parsed = MCP_INSTALLS_READONLY_OUTPUT_SCHEMA.safeParse(rows);
  if (!parsed.success) throw Error('channel_mcp_mutation_source_unavailable');
  if (new Set(parsed.data.map(row => row.id)).size !== parsed.data.length) throw Error('channel_mcp_mutation_source_unavailable');
  return parsed.data;
}
function writeInstalls(root: string, rows: unknown): void {
  const path = join(root, 'mcp-installs.json');
  try {
    mkdirSync(root, { recursive: true });
    if (process.platform !== 'win32' && existsSync(path)) {
      chmodSync(path, 0o600);
      if ((statSync(path).mode & 0o777) !== 0o600) throw Error();
    }
    writeFileSync(path, JSON.stringify(rows, null, 2), { encoding: 'utf8', mode: 0o600 });
  } catch { throw Error('channel_mcp_mutation_write_failed'); }
}
function mcpView(row: ReturnType<typeof readInstalls>[number]) {
  return { id: row.id, name: row.name, source: row.source, command: row.command, args: row.args, enabled: row.enabled, createdAt: row.createdAt };
}
export function createChannelMcpMutationOwner(dataRoot: string) {
  return {
    async createChannel(input: unknown, requestSource?: RequestSource) {
      const [parsed] = admission('createChannel', [input], requestSource);
      const value = parsed as { type: string; name: string; webhookUrl?: string } & Record<string, unknown>;
      const config = configForEdit(), prior = own(config.channels, value.type) ? config.channels[value.type] : {};
      const { type: id, webhookUrl, ...fields } = value;
      config.channels[id] = { ...prior, ...Object.fromEntries(Object.entries(fields).filter(([, value]) => value !== undefined)), sendMsgUrl: webhookUrl || '', inboundMode: 'webhook', enabled: true };
      if (own(config.channels[id]!, 'webhookUrl')) config.channels[id]!.webhookUrl = webhookUrl || '';
      const result = { ...channelView(id, config.channels[id]!, Date.now()), name: value.name, webhookUrl };
      await persistConfig(config); return result;
    },
    async updateChannel(id: unknown, input: unknown, requestSource?: RequestSource) {
      const [key, patch] = admission('updateChannel', [id, input], requestSource) as [string, Record<string, unknown>];
      if (patch.type !== undefined && patch.type !== key) throw Error('channel_mcp_mutation_input_invalid');
      const config = configForEdit();
      if (!own(config.channels, key)) throw Error('Channel not found');
      const row = config.channels[key]!;
      for (const [field, value] of Object.entries(patch)) {
        if (value !== undefined && field !== 'type') row[field === 'webhookUrl' ? 'sendMsgUrl' : field] = value;
      }
      // A changed webhook must not be shadowed by an old webhookUrl in readonly projection.
      if (patch.webhookUrl !== undefined && own(row, 'webhookUrl')) row.webhookUrl = patch.webhookUrl;
      const result = channelView(key, row); await persistConfig(config); return result;
    },
    async deleteChannel(id: unknown, requestSource?: RequestSource) {
      const [key] = admission('deleteChannel', [id], requestSource) as [string];
      const config = configForEdit();
      if (!own(config.channels, key)) return; // preserve idempotent delete, do not create a default file
      delete config.channels[key]; await persistConfig(config);
    },
    async testChannel(id: unknown, requestSource?: RequestSource) {
      const [key] = admission('testChannel', [id], requestSource) as [string];
      const config = configForEdit(), row = own(config.channels, key) ? config.channels[key] : undefined;
      const url = row?.sendMsgUrl || row?.webhookUrl;
      if (!url) return { success: false, error: 'channel_mcp_mutation_webhook_missing' };
      let target: URL;
      try { target = new URL(url as string); }
      catch { return { success: false, error: 'channel_mcp_mutation_webhook_invalid' }; }
      if (!['https:', 'http:'].includes(target.protocol) || target.username || target.password) return { success: false, error: 'channel_mcp_mutation_webhook_invalid' };
      try {
        const start = Date.now();
        const response = await fetch(target.href, { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ msgtype: 'text', text: { content: 'xiaok 测试连接 ✅' } }) });
        const latencyMs = Math.max(0, Date.now() - start);
        return response.ok ? { success: true, latencyMs } : { success: false, latencyMs, error: `HTTP ${response.status}` };
      } catch { return { success: false, error: 'channel_mcp_mutation_network_failed' }; }
      // No automatic resend, new timeout, install or process spawn. Original IPC shutdown token owns settlement.
    },
    async createMCPInstall(input: unknown, requestSource?: RequestSource) {
      const [parsed] = admission('createMCPInstall', [input], requestSource);
      const value = parsed as { name: string; source: 'npm' | 'github' | 'local'; command: string; args?: string[] };
      const rows = readInstalls(dataRoot), record = { ...value, id: randomUUID(), enabled: true, createdAt: Date.now() };
      rows.push(record); const result = mcpView(record); writeInstalls(dataRoot, rows); return result;
    },
    async updateMCPInstall(id: unknown, input: unknown, requestSource?: RequestSource) {
      const [key, patch] = admission('updateMCPInstall', [id, input], requestSource) as [string, Record<string, unknown>];
      const rows = readInstalls(dataRoot), row = rows.find(record => record.id === key);
      if (!row) throw Error('MCP install not found');
      for (const [field, value] of Object.entries(patch)) if (value !== undefined) row[field] = value;
      const result = mcpView(row); writeInstalls(dataRoot, rows); return result;
    },
    async deleteMCPInstall(id: unknown, requestSource?: RequestSource) {
      const [key] = admission('deleteMCPInstall', [id], requestSource) as [string];
      const rows = readInstalls(dataRoot); if (!rows.some(row => row.id === key)) return;
      writeInstalls(dataRoot, rows.filter(row => row.id !== key));
    },
  };
}

```

## FULL desktop/electron/channel-mcp-mutation-typed-ipc.ts
```typescript
// UNREVIEWED CANDIDATE — install at desktop/electron only after owner DESIGN approval.
import { types } from 'node:util';
import { z } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { CHANNEL_MCP_MUTATION_METHODS, CHANNEL_MCP_MUTATION_INPUTS, CHANNEL_MCP_MUTATION_OUTPUTS, CHANNEL_MCP_MUTATION_RISKS } from '../shared/channel-mcp-mutation-ipc-contract.js';
const isPromise = types.isPromise, NativePromise = Promise, nativeThen = Promise.prototype.then, apply = Reflect.apply;
const owners = new WeakMap<IpcHandleRegistrar, ReadonlyMap<string, IpcHandlerListener> | null>();
export function registerChannelMcpMutationIpc(ipc: IpcHandleRegistrar, rawProducers?: ReadonlyMap<string, IpcHandlerListener>): void {
  const producers = rawProducers ?? null;
  if (owners.has(ipc)) { if (owners.get(ipc) !== producers) throw Error('channel_mcp_mutation_registrar_owner_conflict'); return; }
  for (const method of CHANNEL_MCP_MUTATION_METHODS) {
    const channel = 'desktop:' + method, output = CHANNEL_MCP_MUTATION_OUTPUTS[method];
    const capture = (raw: unknown) => {
      const value = captureIpcData(raw, 'channel_mcp_mutation_projection_unavailable');
      if (!output.safeParse(value).success) throw Error('channel_mcp_mutation_projection_unavailable');
      return value;
    };
    registerIpcHandler<unknown[], unknown>({
      registrar: ipc, channel, output, payloadMode: 'tuple', rolloutRound: 34,
      sourceFile: 'desktop/electron/channel-mcp-mutation-typed-ipc.ts', riskTags: [...CHANNEL_MCP_MUTATION_RISKS[method]],
      input: z.custom<unknown[]>(() => true).transform(raw => {
        const value = captureIpcData(raw, 'channel_mcp_mutation_input_invalid');
        if (!CHANNEL_MCP_MUTATION_INPUTS[method].safeParse(value).success) throw Error('channel_mcp_mutation_input_invalid');
        return value;
      }),
      handler: async (args, event) => {
        const producer = producers?.get(channel);
        if (!producer) throw Error('channel_mcp_mutation_runtime_unavailable');
        const result = producer(event, ...args);
        if (!isPromise(result)) return capture(result);
        assertStandardIpcPromise(result, 'channel_mcp_mutation_projection_unavailable');
        return new NativePromise((resolve, reject) => apply(nativeThen, result, [(value: unknown) => {
          try { resolve(capture(value)); } catch (error) { reject(error); }
        }, reject]));
      },
    });
  }
  owners.set(ipc, producers);
}

```

## FULL desktop/electron/desktop-skill-mutation.ts
```typescript
import crossSpawn from 'cross-spawn';
import { SKILL_MUTATION_NAME_SCHEMA, type DesktopSkillMutationContext, type DesktopSkillMutationResult } from '../shared/skill-mutation-ipc-contract.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { bumpSkillCatalogVersion } from './skill-catalog-invalidation.js';
// Main supplies cwd. No renderer-controlled roots, shell text, flags or source.
// Keep the existing synchronous command, deadlines and success/failure DTO.
export function runDesktopSkillMutation(operation: 'install' | 'uninstall', rawName: unknown,
  rawContext: DesktopSkillMutationContext, cwd: string): DesktopSkillMutationResult {
  const context = captureIpcData(rawContext, 'skill_mutation_source_forbidden');
  if (context?.requestSource !== 'user') throw Error('skill_mutation_source_forbidden');
  const input = captureIpcData(rawName, 'skill_mutation_input_invalid');
  if (!SKILL_MUTATION_NAME_SCHEMA.safeParse(input).success) throw Error('skill_mutation_input_invalid');
  const skillName = input as string;
  // cross-spawn handles Windows .cmd shims and argv escaping; no manual shell interpolation.
  const result = crossSpawn.sync('clawhub', [operation, skillName], {
    encoding: 'utf-8', timeout: operation === 'install' ? 60000 : 30000, cwd,
  });
  if (result.error) return { success: false, message: `执行失败: ${result.error.message}` };
  if (result.status !== 0) {
    const message = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
    return { success: false, message: message.slice(0, 500) };
  }
  bumpSkillCatalogVersion();
  return { success: true, message: `技能 ${skillName} 已${operation === 'install' ? '安装' : '卸载'}` };
}

```

## FULL desktop/electron/meeting-mutation-service.ts
```typescript
import { types } from 'node:util';
import { saveConfig } from '../../src/utils/config.js';
import { applyMeetingAsrConfigUpdate, createMeetingAsrConfigSnapshot } from './meeting-asr-config.js';
import { readMeetingAsrConfig } from './meeting-readonly-data.js';
import { createMeetingModelService, MEETING_TRANSCRIBER_MODEL_REGISTRY } from './meeting-model-service.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { MEETING_SAVE_INPUT_SCHEMA, MEETING_MUTATION_ASR_OUTPUT_SCHEMA } from '../shared/meeting-mutation-ipc-contract.js';
import type { MeetingAudioPermissionResult } from './meeting-audio-permission.js';
const nativeThen = Promise.prototype.then;
export function createMeetingMutationService(permission: { requestPermission(): Promise<MeetingAudioPermissionResult> }) {
  let models: ReturnType<typeof createMeetingModelService> | undefined;
  let pendingPermission: Promise<MeetingAudioPermissionResult> | undefined;
  const authorize = (source: unknown) => { if (source !== 'user') throw Error('meeting_mutation_request_source_forbidden'); };
  const modelId = (id: unknown): string => {
    if (typeof id !== 'string' || !MEETING_TRANSCRIBER_MODEL_REGISTRY.some(model => model.id === id)) throw Error('meeting_mutation_input_invalid');
    return id;
  };
  return {
    async requestMicrophonePermission(source?: 'user' | 'agent' | 'scheduler') {
      authorize(source);
      if (pendingPermission) return pendingPermission;
      const operation = permission.requestPermission();
      assertStandardIpcPromise(operation, 'meeting_mutation_projection_unavailable');
      pendingPermission = operation;
      try { return await operation; } finally { pendingPermission = undefined; }
    },
    async saveAsrConfig(input: unknown, source?: 'user' | 'agent' | 'scheduler') {
      authorize(source);
      const snapshot = captureIpcData(input ?? {}, 'meeting_mutation_input_invalid');
      const parsed = MEETING_SAVE_INPUT_SCHEMA.safeParse(snapshot);
      if (!parsed.success) throw Error('meeting_mutation_input_invalid');
      try {
        // No await between truthful read / semantic edit / synchronous saveConfig body.
        const config = applyMeetingAsrConfigUpdate(readMeetingAsrConfig(), parsed.data);
        const projected = captureIpcData(createMeetingAsrConfigSnapshot(config), 'meeting_mutation_save_failed');
        if (!MEETING_MUTATION_ASR_OUTPUT_SCHEMA.safeParse(projected).success) throw Error('meeting_mutation_save_failed');
        const result = saveConfig(config);
        assertStandardIpcPromise(result, 'meeting_mutation_save_failed');
        await new Promise<void>((resolve, reject) => Reflect.apply(nativeThen, result, [resolve, reject]));
        return projected;
      } catch { throw Error('meeting_mutation_save_failed'); }
    },
    async downloadModel(id: unknown, source?: 'user' | 'agent' | 'scheduler') {
      authorize(source); const known = modelId(id);
      return (models ??= createMeetingModelService()).downloadModel(known);
    },
    async uninstallModel(id: unknown, source?: 'user' | 'agent' | 'scheduler') {
      authorize(source); const known = modelId(id);
      return (models ??= createMeetingModelService()).uninstallModel(known);
    },
  };
}
// Only fixed domain codes can cross the error transport. Never access error.message.
export function meetingMutationError(error: unknown): Error {
  const descriptor = error && typeof error === 'object' && !types.isProxy(error) ? Object.getOwnPropertyDescriptor(error, 'message') : undefined;
  const value = descriptor && 'value' in descriptor ? descriptor.value : undefined;
  const allowed = ['meeting_mutation_input_invalid', 'meeting_mutation_request_source_forbidden', 'meeting_mutation_save_failed', 'meeting_mutation_projection_unavailable', 'meeting_model_busy', 'size_mismatch', 'hash_mismatch', 'model_package_incomplete'];
  return Error(typeof value === 'string' && allowed.includes(value) ? value : 'meeting_mutation_action_failed');
}

```

## FULL desktop/electron/meeting-mutation-typed-ipc.ts
```typescript
import { types } from 'node:util';
import { z } from 'zod';
import { registerIpcHandler } from './ipc-runtime.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { meetingMutationError } from './meeting-mutation-service.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { MEETING_MUTATION_METHODS, MEETING_MUTATION_INPUT_SCHEMAS, MEETING_MUTATION_OUTPUT_SCHEMAS } from '../shared/meeting-mutation-ipc-contract.js';
const nativeThen = Promise.prototype.then;
const owners = new WeakMap<IpcHandleRegistrar, ReadonlyMap<string, IpcHandlerListener>>();
export function registerMeetingMutationIpc(ipc: IpcHandleRegistrar, producers: ReadonlyMap<string, IpcHandlerListener>): void {
  if (owners.has(ipc)) { if (owners.get(ipc) !== producers) throw Error('meeting_mutation_registrar_owner_conflict'); return; }
  // Detach producer bindings once; do not trust subsequent Map mutation.
  const bindings = new Map(producers);
  for (const method of MEETING_MUTATION_METHODS) {
    const channel = 'desktop:meeting:' + method, output = MEETING_MUTATION_OUTPUT_SCHEMAS[method];
    const capture = (raw: unknown) => {
      const value = captureIpcData(raw, 'meeting_mutation_projection_unavailable');
      if (!output.safeParse(value).success) throw Error('meeting_mutation_projection_unavailable');
      return value;
    };
    registerIpcHandler<unknown[], unknown>({ registrar: ipc, channel,
      input: z.custom<unknown[]>(() => true).transform(raw => {
        const value = captureIpcData(raw, 'meeting_mutation_input_invalid');
        if (!MEETING_MUTATION_INPUT_SCHEMAS[method].safeParse(value).success) throw Error('meeting_mutation_input_invalid');
        return value;
      }), output, payloadMode: 'tuple', rolloutRound: 34,
      riskTags: method === 'requestMicrophonePermission' ? ['dialog'] : method === 'saveAsrConfig' ? ['fs-write'] : method === 'downloadModel' ? ['network', 'fs-write'] : ['fs-delete'],
      sourceFile: 'desktop/electron/meeting-mutation-typed-ipc.ts',
      handler: async (args, event) => {
        const producer = bindings.get(channel); if (!producer) throw Error('meeting_mutation_runtime_unavailable');
        try {
          const result = producer(event, ...args);
          if (!types.isPromise(result)) return capture(result);
          assertStandardIpcPromise(result, 'meeting_mutation_projection_unavailable');
          return await new Promise((resolve, reject) => Reflect.apply(nativeThen, result, [(value: unknown) => { try { resolve(capture(value)); } catch (error) { reject(error); } }, reject]));
        } catch (error) { throw meetingMutationError(error); }
      },
    });
  }
  owners.set(ipc, producers);
}

```

## FULL desktop/electron/runtime-status-readonly-typed-ipc.ts
```typescript
import { types } from 'node:util';
import { z, type ZodType } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { COMPUTER_USE_STATUS_SCHEMA, KSWARM_STATUS_SCHEMA, RUNTIME_STATUS_INPUT_SCHEMA } from '../shared/runtime-status-readonly-ipc-contract.js';
const isPromise = types.isPromise, NativePromise = Promise, nativeThen = Promise.prototype.then, apply = Reflect.apply;
const capabilityOwners = new WeakMap<IpcHandleRegistrar, IpcHandlerListener | undefined>();
const sdkOwners = new WeakMap<IpcHandleRegistrar, IpcHandlerListener | undefined>();
function registerStatus(ipc: IpcHandleRegistrar, channel: string, output: ZodType, owners: WeakMap<IpcHandleRegistrar, IpcHandlerListener | undefined>, producer?: IpcHandlerListener) {
  if (owners.has(ipc)) { if (owners.get(ipc) !== producer) throw Error('runtime_status_registrar_owner_conflict'); return; }
  const capture = (raw: unknown) => {
    const value = captureIpcData(raw, 'runtime_status_projection_unavailable');
    if (!output.safeParse(value).success) throw Error('runtime_status_projection_unavailable');
    return value;
  };
  registerIpcHandler<unknown[], unknown>({
    registrar: ipc, channel, output, payloadMode: 'tuple', rolloutRound: 34, riskTags: [], sourceFile: 'desktop/electron/runtime-status-readonly-typed-ipc.ts',
    input: z.custom<unknown[]>(() => true).transform(raw => {
      const value = captureIpcData(raw, 'runtime_status_input_invalid');
      if (!RUNTIME_STATUS_INPUT_SCHEMA.safeParse(value).success) throw Error('runtime_status_input_invalid');
      return value;
    }),
    handler: async (args, event) => {
      if (!producer) throw Error('runtime_status_runtime_unavailable');
      const result = producer(event, ...args);
      if (!isPromise(result)) return capture(result);
      assertStandardIpcPromise(result, 'runtime_status_projection_unavailable');
      return new NativePromise((resolve, reject) => apply(nativeThen, result, [(value: unknown) => { try { resolve(capture(value)); } catch (error) { reject(error); } }, reject]));
    },
  });
  owners.set(ipc, producer);
}
export function registerComputerUseCapabilityReadonlyIpc(ipc: IpcHandleRegistrar, producer?: IpcHandlerListener) { registerStatus(ipc, 'desktop:getComputerUseCapabilityStatus', COMPUTER_USE_STATUS_SCHEMA, capabilityOwners, producer); }
export function registerKswarmStatusReadonlyIpc(ipc: IpcHandleRegistrar, producer?: IpcHandlerListener) { registerStatus(ipc, 'desktop:kswarm:getStatus', KSWARM_STATUS_SCHEMA, sdkOwners, producer); }

```

## FULL desktop/electron/skill-mutation-typed-ipc.ts
```typescript
import { z } from 'zod';
import { captureIpcData } from './ipc-data-snapshot.js';
import { assertStandardIpcPromise } from './ipc-native-promise.js';
import { registerIpcHandler } from './ipc-runtime.js';
import type { IpcHandleRegistrar, IpcHandlerListener } from './shutdown-aware-ipc-main.js';
import { SKILL_MUTATION_INPUT_SCHEMA, SKILL_MUTATION_OUTPUT_SCHEMA } from '../shared/skill-mutation-ipc-contract.js';
const NativePromise = Promise, nativeThen = Promise.prototype.then, apply = Reflect.apply;
type Producers = ReadonlyMap<string, IpcHandlerListener>;
const owners = new WeakMap<IpcHandleRegistrar, Producers | null>();
export function registerSkillMutationIpc(ipc: IpcHandleRegistrar, rawProducers?: Producers): void {
  const producers = rawProducers ?? null;
  if (owners.has(ipc)) { if (owners.get(ipc) !== producers) throw Error('skill_mutation_registrar_owner_conflict'); return; }
  for (const channel of ['desktop:installSkill', 'desktop:uninstallSkill']) {
    registerIpcHandler<unknown[], unknown>({ registrar: ipc, channel,
      input: z.custom<unknown[]>(() => true).transform(raw => {
        const snapshot = captureIpcData(raw, 'skill_mutation_input_invalid');
        if (!SKILL_MUTATION_INPUT_SCHEMA.safeParse(snapshot).success) throw Error('skill_mutation_input_invalid');
        return snapshot;
      }), output: SKILL_MUTATION_OUTPUT_SCHEMA, payloadMode: 'tuple', rolloutRound: 34,
      riskTags: channel === 'desktop:installSkill' ? ['external-process', 'network', 'fs-write'] : ['external-process', 'fs-delete'],
      sourceFile: 'desktop/electron/skill-mutation-typed-ipc.ts',
      handler: async (args, event) => {
        const producer = producers?.get(channel);
        if (!producer) throw Error('skill_mutation_runtime_unavailable');
        const result = producer(event, ...args);
        assertStandardIpcPromise(result, 'skill_mutation_output_invalid');
        return new NativePromise((resolve, reject) => apply(nativeThen, result, [(value: unknown) => {
          try {
            const snapshot = captureIpcData(value, 'skill_mutation_output_invalid');
            if (!SKILL_MUTATION_OUTPUT_SCHEMA.safeParse(snapshot).success) throw Error('skill_mutation_output_invalid');
            resolve(snapshot);
          } catch (error) { reject(error); }
        }, reject]));
      },
    });
  }
  owners.set(ipc, producers);
}

```

## FULL desktop/renderer/src/hooks/useKswarmStatusReadonly.ts
```typescript
import { useCallback, useEffect, useRef, useState } from 'react';
import { getDesktopApi } from '../shared/desktop';
import { KSWARM_STATUS_SCHEMA, type KswarmReadonlyStatus } from '../../../shared/runtime-status-readonly-ipc-contract';
type Owner = { active: boolean; busy: boolean; queued: boolean; events: number };
export function useKswarmStatusReadonly() {
  const [data, setData] = useState<KswarmReadonlyStatus | null>(null), [failed, setFailed] = useState(false), [reading, setReading] = useState(true);
  const lifetime = useRef<Owner | null>(null);
  const runRef = useRef<(owner: Owner) => void>(() => {});
  const run = useCallback((owner: Owner) => {
    if (!owner.active || lifetime.current !== owner) return;
    owner.busy = true; setReading(true); const events = owner.events;
    void (async () => {
      try {
        const desktop = getDesktopApi();
        if (!desktop?.kswarmGetStatus) throw Error('runtime_status_runtime_unavailable');
        const value = await desktop.kswarmGetStatus(), parsed = KSWARM_STATUS_SCHEMA.safeParse(value);
        if (!parsed.success) throw Error('runtime_status_projection_unavailable');
        if (owner.active && lifetime.current === owner && owner.events === events) { setData(parsed.data); setFailed(false); }
      } catch {
        if (owner.active && lifetime.current === owner && owner.events === events) setFailed(true);
      } finally {
        if (owner.active && lifetime.current === owner) {
          owner.busy = false; setReading(false);
          if (owner.queued) { owner.queued = false; runRef.current(owner); }
        }
      }
    })();
  }, []);
  runRef.current = run;
  const refresh = useCallback(() => {
    const owner = lifetime.current;
    if (!owner?.active) return;
    if (owner.busy) { owner.queued = true; return; }
    runRef.current(owner);
  }, []);
  useEffect(() => {
    const owner: Owner = { active: true, busy: false, queued: false, events: 0 }; lifetime.current = owner;
    let unsubscribe: (() => void) | undefined;
    try {
      const desktop = getDesktopApi();
      if (desktop?.onKSwarmStatus) unsubscribe = desktop.onKSwarmStatus(value => {
        if (!owner.active || lifetime.current !== owner) return;
        owner.events++;
        const parsed = KSWARM_STATUS_SCHEMA.safeParse(value);
        if (!parsed.success) { setFailed(true); return; }
        setData(parsed.data); setFailed(false);
      });
    } catch { setFailed(true); }
    refresh();
    return () => { owner.active = false; owner.queued = false; unsubscribe?.(); };
  }, [refresh]);
  return { data, failed, reading, refresh };
}

```

## FULL desktop/shared/channel-mcp-mutation-ipc-contract.ts
```typescript
// UNREVIEWED CANDIDATE — install at desktop/shared only after owner DESIGN approval.
import { z } from 'zod';
import { CHANNEL_READONLY_OUTPUT_SCHEMA, MCP_INSTALLS_READONLY_OUTPUT_SCHEMA } from './channel-mcp-readonly-ipc-contract.js';
export const CHANNEL_MCP_MUTATION_METHODS = ['createChannel', 'updateChannel', 'deleteChannel', 'testChannel', 'createMCPInstall', 'updateMCPInstall', 'deleteMCPInstall'] as const;
export type ChannelMcpMutationMethod = typeof CHANNEL_MCP_MUTATION_METHODS[number];
const key = z.string().min(1).refine(v => !['__proto__', 'prototype', 'constructor'].includes(v));
const credentials = { appId: z.string().optional(), appSecret: z.string().optional(), token: z.string().optional(), botToken: z.string().optional(), chatId: z.string().optional() };
const channelFields = { name: z.string(), webhookUrl: z.string().optional(), ...credentials };
const createChannel = z.object({ type: key, ...channelFields }).strict();
const updateChannel = z.object({ type: key.optional(), ...channelFields, enabled: z.boolean() }).partial().strict();
const mcpFields = { name: z.string(), source: z.enum(['npm', 'github', 'local']), command: z.string().min(1), args: z.array(z.string()).optional() };
const createMcp = z.object(mcpFields).strict();
const updateMcp = z.object({ ...mcpFields, enabled: z.boolean() }).partial().strict();
export const CHANNEL_MCP_MUTATION_INPUTS = {
  createChannel: z.tuple([createChannel]), updateChannel: z.tuple([key, updateChannel]), deleteChannel: z.tuple([key]), testChannel: z.tuple([key]),
  createMCPInstall: z.tuple([createMcp]), updateMCPInstall: z.tuple([key, updateMcp]), deleteMCPInstall: z.tuple([key]),
} as const;
const channel = CHANNEL_READONLY_OUTPUT_SCHEMA.element.extend({ createdAt: z.number().finite(), updatedAt: z.number().finite() });
// Mutation ACK retains original toMCPView columns; stored/read-only rows retain passthrough metadata.
const mcp = MCP_INSTALLS_READONLY_OUTPUT_SCHEMA.element.strict().extend({ createdAt: z.number().finite() });
export const CHANNEL_MCP_MUTATION_OUTPUTS = {
  createChannel: channel, updateChannel: channel, deleteChannel: z.undefined(),
  testChannel: z.object({ success: z.boolean(), latencyMs: z.number().finite().nonnegative().optional(), error: z.string().optional() }).strict(),
  createMCPInstall: mcp, updateMCPInstall: mcp, deleteMCPInstall: z.undefined(),
} as const;
export const CHANNEL_MCP_MUTATION_RISKS = {
  createChannel: ['fs-write'], updateChannel: ['fs-write'], deleteChannel: ['fs-write', 'fs-delete'], testChannel: ['fs-read', 'network'],
  createMCPInstall: ['fs-write-userData'], updateMCPInstall: ['fs-write-userData'], deleteMCPInstall: ['fs-write-userData', 'fs-delete'],
} as const;

```

## FULL desktop/shared/meeting-mutation-ipc-contract.ts
```typescript
import { z } from 'zod';
import { MEETING_PERMISSION_OUTPUT_SCHEMA, MEETING_ASR_OUTPUT_SCHEMA, MEETING_MODELS_OUTPUT_SCHEMA } from './meeting-readonly-ipc-contract.js';
export const MEETING_MUTATION_METHODS = ['requestMicrophonePermission', 'saveAsrConfig', 'downloadModel', 'uninstallModel'] as const;
// Empty strings preserve deletion semantics. Credential-bearing URLs must not
// be returned as public endpoint/baseUrl fields.
export const MEETING_PUBLIC_ENDPOINT_SCHEMA = z.string().refine(value => {
  if (!value.trim()) return true;
  try { const url = new URL(value.trim()); return ['http:', 'https:', 'ws:', 'wss:'].includes(url.protocol) && !url.username && !url.password && !url.search && !url.hash; } catch { return false; }
});
export const MEETING_MUTATION_ASR_OUTPUT_SCHEMA = MEETING_ASR_OUTPUT_SCHEMA.extend({
  volcengine: MEETING_ASR_OUTPUT_SCHEMA.shape.volcengine.extend({ endpoint: MEETING_PUBLIC_ENDPOINT_SCHEMA.optional() }),
  aliyun: MEETING_ASR_OUTPUT_SCHEMA.shape.aliyun.extend({ baseUrl: MEETING_PUBLIC_ENDPOINT_SCHEMA }),
});
export const MEETING_SAVE_INPUT_SCHEMA = z.object({
  defaultProvider: MEETING_ASR_OUTPUT_SCHEMA.shape.defaultProvider.optional(),
  volcengine: z.object({ appKey: z.string().optional(), accessKey: z.string().optional(), endpoint: MEETING_PUBLIC_ENDPOINT_SCHEMA.optional(), resourceId: z.string().optional(), clearAppKey: z.boolean().optional(), clearAccessKey: z.boolean().optional() }).strict().optional(),
  aliyun: z.object({ apiKey: z.string().optional(), baseUrl: MEETING_PUBLIC_ENDPOINT_SCHEMA.optional(), model: z.string().optional(), clearApiKey: z.boolean().optional() }).strict().optional(),
}).strict();
// Preserve the original input ?? {} save behavior; reject surplus transport arguments.
export const MEETING_MUTATION_INPUT_SCHEMAS = {
  requestMicrophonePermission: z.tuple([]),
  saveAsrConfig: z.union([z.tuple([]), z.tuple([MEETING_SAVE_INPUT_SCHEMA.nullish()])]),
  downloadModel: z.tuple([z.string()]),
  uninstallModel: z.tuple([z.string()]),
} as const;
const model = MEETING_MODELS_OUTPUT_SCHEMA.element.extend({ sizeBytes: z.number().finite().nonnegative(), localSizeBytes: z.number().finite().nonnegative().optional() }).strict();
export const MEETING_MODEL_ACTION_OUTPUT_SCHEMA = z.object({ ok: z.literal(true), model }).strict();
export const MEETING_MUTATION_OUTPUT_SCHEMAS = { requestMicrophonePermission: MEETING_PERMISSION_OUTPUT_SCHEMA, saveAsrConfig: MEETING_MUTATION_ASR_OUTPUT_SCHEMA, downloadModel: MEETING_MODEL_ACTION_OUTPUT_SCHEMA, uninstallModel: MEETING_MODEL_ACTION_OUTPUT_SCHEMA } as const;
export type MeetingMutationModelResult = z.infer<typeof MEETING_MODEL_ACTION_OUTPUT_SCHEMA>;

```

## FULL desktop/shared/runtime-status-readonly-ipc-contract.ts
```typescript
import { z } from 'zod';
const number = z.custom<number>(value => typeof value === 'number');
export const RUNTIME_STATUS_INPUT_SCHEMA = z.tuple([]);
export const COMPUTER_USE_STATUS_SCHEMA = z.object({
  state: z.string(), mcpConnected: z.boolean(), wrapperReady: z.boolean(), lastError: z.string().optional(),
}).passthrough();
export const KSWARM_STATUS_SCHEMA = z.object({
  running: z.boolean(), port: number, pid: number.nullable(), restartCount: number, lastError: z.string().nullable(),
  terminalDegraded: z.boolean().optional(), persistenceFailStopCount: number.optional(), lastPersistenceFailStop: z.string().nullable().optional(),
}).passthrough();
export type ComputerUseReadonlyStatus = z.infer<typeof COMPUTER_USE_STATUS_SCHEMA>;
export type KswarmReadonlyStatus = z.infer<typeof KSWARM_STATUS_SCHEMA>;

```

## FULL desktop/shared/skill-mutation-ipc-contract.ts
```typescript
import { z } from 'zod';
// Preserve Unicode and interior spaces/namespace punctuation; do not silently coerce.
// A registry name is one argv operand, not a filesystem path or CLI option.
export const SKILL_MUTATION_NAME_SCHEMA = z.string().min(1).max(512).refine(name =>
  name === name.trim() && !name.startsWith('-') && name !== '.' && name !== '..'
  && !/[\\/\x00-\x1f\x7f]/.test(name) && !/^[A-Za-z]:/.test(name));
export const SKILL_MUTATION_INPUT_SCHEMA = z.tuple([SKILL_MUTATION_NAME_SCHEMA]);
export const SKILL_MUTATION_OUTPUT_SCHEMA = z.object({
  success: z.boolean(), message: z.string(),
}).passthrough();
export type DesktopSkillMutationResult = z.infer<typeof SKILL_MUTATION_OUTPUT_SCHEMA>;
export interface DesktopSkillMutationContext { requestSource: 'user' | 'agent' | 'scheduler' }

```

## FULL desktop/tests/main/channel-mcp-mutation-controls.test.ts
```typescript
// UNREVIEWED RED CANDIDATE. Copy to desktop/tests/main/channel-mcp-mutation-controls.test.ts.
// cd desktop && npm run test -- --run tests/main/channel-mcp-mutation-controls.test.ts
// Production registrar + service + production Main authorizer AST, no reimplemented business logic.
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'channel-mcp-mutation-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}


const methods = ['createChannel','updateChannel','deleteChannel','testChannel','createMCPInstall','updateMCPInstall','deleteMCPInstall'] as const;
type Method = typeof methods[number];
const legitimate: Record<Method, unknown[]> = {
  createChannel:[{type:'owned',name:'Owned',webhookUrl:'https://owned.invalid/path?token=OWNED_SECRET'}],
  updateChannel:['owned',{enabled:false}],deleteChannel:['owned'],testChannel:['owned'],
  createMCPInstall:[{name:'Owned MCP',source:'local',command:'C:\\owned\\command',args:['--owned','']}],
  updateMCPInstall:['owned',{enabled:false}],deleteMCPInstall:['owned'],
};
function seed(f: Awaited<ReturnType<typeof fixture>>) {
  const config=join(f.root,'config');mkdirSync(config,{recursive:true});
  writeFileSync(join(config,'config.json'),JSON.stringify({schemaVersion:2,providers:{private:{apiKey:'OWNED_PROVIDER_SECRET'}},models:{},future:{keep:true},channels:{owned:{name:'Owned',sendMsgUrl:'https://owned.invalid/path?token=OWNED_SECRET',enabled:true,appSecret:'OWNED_APP_SECRET',future:{keep:true}}}}));
  writeFileSync(join(f.data,'mcp-installs.json'),JSON.stringify([{id:'owned',name:'Owned MCP',source:'local',command:'owned-command',args:['--owned',''],enabled:true,createdAt:1,future:{keep:true}}]));
}
it('registers all seven tuple contracts at the actual production registrar', async()=>{
  await fixture();for(const method of methods)expect(IPC_SCHEMA_REGISTRY.get('desktop:'+method)).toMatchObject({payloadMode:'tuple',inputStage:'beforeHandler',sourceFile:'desktop/electron/channel-mcp-mutation-typed-ipc.ts'});
});
it.each(methods)('%s rejects surplus tuple arguments before its service',async method=>{
  const f=await fixture();seed(f);const producer=vi.spyOn(f.service,method);
  await expect(f.invoke(method,...legitimate[method],{})).rejects.toThrow('channel_mcp_mutation_input_invalid');expect(producer).not.toHaveBeenCalled();
});
it.each(methods)('%s rejects accessor inputs without invoking getters or service',async method=>{
  const f=await fixture();seed(f);let reads=0;const input=Object.defineProperty({},'name',{enumerable:true,get(){reads++;return 'Owned'}}),producer=vi.spyOn(f.service,method);
  const args=method.startsWith('update')?['owned',input]:[input];
  await expect(f.invoke(method,...args)).rejects.toThrow('channel_mcp_mutation_input_invalid');expect(reads).toBe(0);expect(producer).not.toHaveBeenCalled();
});
it.each(methods)('%s rejects proxy input without traps or service',async method=>{
  const f=await fixture();seed(f);let traps=0;const input=new Proxy({},{ownKeys(){traps++;throw Error('owned')}}),producer=vi.spyOn(f.service,method);
  await expect(f.invoke(method,...(method.startsWith('update')?['owned',input]:[input]))).rejects.toThrow('channel_mcp_mutation_input_invalid');expect(traps).toBe(0);expect(producer).not.toHaveBeenCalled();
});
it.each(methods)('%s denies absent/agent/scheduler source at the actual service, before disk/network',async method=>{
  const f=await fixture();seed(f);const config=join(f.root,'config','config.json'),mcp=join(f.data,'mcp-installs.json'),a=readFileSync(config,'utf8'),b=readFileSync(mcp,'utf8');
  const network=vi.fn(async()=>Response.json({}));vi.stubGlobal('fetch',network);
  try{for(const source of [undefined,'agent','scheduler'])await expect(Reflect.apply(f.service[method],f.service,[...legitimate[method],source])).rejects.toThrow('channel_mcp_mutation_request_source_forbidden');
    expect(network).not.toHaveBeenCalled();expect(readFileSync(config,'utf8')).toBe(a);expect(readFileSync(mcp,'utf8')).toBe(b);
  }finally{vi.unstubAllGlobals();}
});
it.each(methods)('%s is admitted as user only through the real Main binding',async method=>{
  const f=await fixture();seed(f);const producer=vi.spyOn(f.service,method),network=vi.fn(async()=>Response.json({}));vi.stubGlobal('fetch',network);
  try{await f.invoke(method,...legitimate[method]);expect(producer).toHaveBeenCalledExactlyOnceWith(...legitimate[method],'user');}finally{vi.unstubAllGlobals();}
});
it.each(methods)('%s rejects unknown sender/old main/subframe before payload getters',async method=>{
  for(const kind of ['unknown','old-main','subframe']){
    const f=await fixture();seed(f);const old=f.sender;if(kind==='old-main')f.authority.setMain({webContents:{mainFrame:f.frame,isDestroyed:()=>false},isDestroyed:()=>false});
    const sender=kind==='unknown'?{mainFrame:f.frame,isDestroyed:()=>false}:old,frame=kind==='subframe'?{url:f.frame.url}:f.frame;let reads=0;
    const input=Object.defineProperty({},'name',{enumerable:true,get(){reads++;return 'Owned'}}),producer=vi.spyOn(f.service,method);
    await expect(Reflect.apply(f.listeners.get('desktop:'+method)!,undefined,[{sender,senderFrame:frame},input])).rejects.toThrow('desktop_user_sender_forbidden');expect(reads).toBe(0);expect(producer).not.toHaveBeenCalled();
  }
});
it.each(methods)('%s retains legal Recorder caller population',async method=>{
  const f=await fixture();seed(f);vi.stubGlobal('fetch',vi.fn(async()=>Response.json({})));
  try{const result=await Reflect.apply(f.listeners.get('desktop:'+method)!,undefined,[{sender:f.recorder,senderFrame:f.recorderFrame},...legitimate[method]]);if(method.startsWith('delete'))expect(result).toBeUndefined();else expect(result).toBeDefined();}finally{vi.unstubAllGlobals();}
});
it.each(['createChannel','updateChannel','deleteChannel','testChannel'] as const)('%s refuses corrupted config without backup/removal/write/fetch',async method=>{
  const f=await fixture();seed(f);const path=join(f.root,'config','config.json'),bytes='{"OWNED_PRIVATE_CONFIG_SECRET":';writeFileSync(path,bytes);vi.stubGlobal('fetch',vi.fn());
  try{const result=await f.invoke(method,...legitimate[method]).then(()=>null,(error: unknown)=>error);
    expect(result).toBeInstanceOf(Error);expect(result.message).toBe('channel_mcp_mutation_source_unavailable');expect(result.message).not.toContain('OWNED_PRIVATE_CONFIG_SECRET');expect(readFileSync(path,'utf8')).toBe(bytes);expect(existsSync(path+'.bak')).toBe(false);expect(fetch).not.toHaveBeenCalled();
  }finally{vi.unstubAllGlobals();}
});
it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall'] as const)('%s refuses corrupted MCP bytes instead of fallback [] overwrite',async method=>{
  const f=await fixture();seed(f);const path=join(f.data,'mcp-installs.json'),bytes='{"OWNED_PRIVATE_MCP_SECRET":';writeFileSync(path,bytes);
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);
});
it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall'] as const)('%s rejects a malformed row anywhere in the table without discarding it',async method=>{
  const f=await fixture();seed(f);const path=join(f.data,'mcp-installs.json'),rows=JSON.parse(readFileSync(path,'utf8'));rows.push({id:'bad',args:7});const bytes=JSON.stringify(rows);writeFileSync(path,bytes);
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);
});
it('same-turn concurrent channel edits and MCP creates preserve both real commits',async()=>{
  const f=await fixture();seed(f);
  await Promise.all([f.invoke('createChannel',{type:'a',name:'A'}),f.invoke('createChannel',{type:'b',name:'B'})]);
  expect(JSON.parse(readFileSync(join(f.root,'config','config.json'),'utf8')).channels).toMatchObject({a:{name:'A'},b:{name:'B'},owned:{appSecret:'OWNED_APP_SECRET'}});
  const created=await Promise.all([f.invoke('createMCPInstall',{name:'A',source:'local',command:'a'}),f.invoke('createMCPInstall',{name:'B',source:'local',command:'b'})]);
  const rows=await f.invoke('listMCPInstalls');expect(rows.map((row:{id:string})=>row.id)).toEqual(expect.arrayContaining(created.map((row:{id:string})=>row.id)));expect(rows).toHaveLength(3);
});
it('real creation persists all currently submitted UI credentials but public ACK/list exclude them',async()=>{
  const f=await fixture();seed(f);const result=await f.invoke('createChannel',{type:'discord',name:'Owned Discord',botToken:'OWNED_BOT_SECRET',chatId:'owned-room'});
  const config=JSON.parse(readFileSync(join(f.root,'config','config.json'),'utf8'));
  expect(config.channels.discord).toMatchObject({botToken:'OWNED_BOT_SECRET',chatId:'owned-room'});expect(config.providers.private.apiKey).toBe('OWNED_PROVIDER_SECRET');expect(config.future).toEqual({keep:true});
  expect(JSON.stringify(result)).not.toContain('OWNED_BOT_SECRET');expect(JSON.stringify(await f.invoke('listChannels'))).not.toContain('OWNED_BOT_SECRET');
});
it('MCP args update and metadata survive real write/read, without installing/spawning',async()=>{
  const f=await fixture();seed(f);const result=await f.invoke('updateMCPInstall','owned',{args:['--new','']});
  expect(result.args).toEqual(['--new','']);const rows=await f.invoke('listMCPInstalls');expect(rows[0]).toMatchObject({args:['--new',''],future:{keep:true}});
});
it('schema1 channel edit preserves legacy provider secrets and unknown fields',async()=>{
  const f=await fixture();seed(f);const path=join(f.root,'config','config.json'),original={schemaVersion:1,defaultModel:'openai',models:{openai:{apiKey:'OWNED_LEGACY_KEY'}},future:{keep:true},channels:{owned:{name:'Old',secret:'OWNED_CHANNEL_KEY'}}};writeFileSync(path,JSON.stringify(original));
  await f.invoke('updateChannel','owned',{name:'New'});const actual=JSON.parse(readFileSync(path,'utf8'));expect(actual).toEqual({...original,channels:{owned:{...original.channels.owned,name:'New'}}});
});
it('channel test returns fixed failure without reading an exception message getter or credential echo',async()=>{
  const f=await fixture();seed(f);let reads=0;const error=Object.defineProperty({},'message',{get(){reads++;return 'OWNED_NETWORK_SECRET'}});vi.stubGlobal('fetch',vi.fn().mockRejectedValue(error));
  try{expect(await f.invoke('testChannel','owned')).toEqual({success:false,error:'channel_mcp_mutation_network_failed'});expect(reads).toBe(0);}finally{vi.unstubAllGlobals();}
});
it('HTTP rejection remains business false; no retry and original webhook POST payload retained',async()=>{
  const f=await fixture();seed(f);const network=vi.fn(async(..._args:unknown[])=>new Response('',{status:403}));vi.stubGlobal('fetch',network);
  try{expect(await f.invoke('testChannel','owned')).toMatchObject({success:false,error:'HTTP 403'});expect(network).toHaveBeenCalledTimes(1);expect(network.mock.calls[0]).toEqual(['https://owned.invalid/path?token=OWNED_SECRET',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({msgtype:'text',text:{content:'xiaok 测试连接 ✅'}})}]);}finally{vi.unstubAllGlobals();}
});
it.each(methods)('%s rejects invalid production output rather than a successful contract-violation envelope',async method=>{
  const f=await fixture();seed(f);f.service[method]=(()=>({ok:false,error:'OWNED_LEAK'}))as never;const previous=process.env.NODE_ENV;process.env.NODE_ENV='production';
  try{await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');}finally{if(previous===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=previous;}
});
it.each(methods)('%s rejects output accessors without executing them',async method=>{
  const f=await fixture();seed(f);let reads=0;const result=Object.defineProperty({},'success',{enumerable:true,get(){reads++;return true}});f.service[method]=(()=>result)as never;
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');expect(reads).toBe(0);
});
it.each(methods)('%s keeps original producer rejection identity',async method=>{
  const f=await fixture();seed(f);const error=Error('owned-domain-failure');f.service[method]=(()=>{throw error})as never;await expect(f.invoke(method,...legitimate[method])).rejects.toBe(error);
  f.service[method]=(()=>Promise.reject(error))as never;await expect(f.invoke(method,...legitimate[method])).rejects.toBe(error);
});
it('held actual testChannel network promise retains the original shutdown token beyond five seconds',async()=>{
  const f=await fixture();seed(f);let release!:(response:Response)=>void;const network=vi.fn(()=>new Promise<Response>(resolve=>{release=resolve}));vi.stubGlobal('fetch',network);vi.useFakeTimers();
  const pending=f.invoke('testChannel','owned');await Promise.resolve();await Promise.resolve();
  try{expect(f.gate.outstanding).toBe(1);const drain=f.gate.drain(5000);await vi.advanceTimersByTimeAsync(5001);expect(await drain).toBe(false);expect(f.gate.outstanding).toBe(1);expect(network).toHaveBeenCalledTimes(1);}finally{release(Response.json({}));await pending;vi.unstubAllGlobals();}expect(f.gate.outstanding).toBe(0);
});

it.each(methods)('%s rejects promise constructor accessors without reading them',async method=>{
  const f=await fixture();seed(f);let reads=0;const result=Promise.resolve(undefined);Object.defineProperty(result,'constructor',{get(){reads++;return Promise}});f.service[method]=(()=>result)as never;
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');expect(reads).toBe(0);
});
it.each(methods)('%s rejects proxy/cycle/serializer output without traps/serialization/retry',async method=>{
  const f=await fixture();seed(f);let reads=0;const cycle:{self?:unknown}={};cycle.self=cycle;
  for(const output of [new Proxy({},{ownKeys(){reads++;throw Error('owned')}}),cycle,{toJSON(){reads++;return {}}}]){
    const producer=vi.spyOn(f.service,method).mockImplementation((()=>output)as never);
    await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_projection_unavailable');expect(reads).toBe(0);expect(producer).toHaveBeenCalledTimes(1);producer.mockRestore();
  }
});
it.each(['createChannel','updateChannel','deleteChannel','testChannel']as const)('%s rejects invalid channels map before normalization can erase it',async method=>{
  const f=await fixture();seed(f);const path=join(f.root,'config','config.json'),bytes=JSON.stringify({schemaVersion:2,providers:{},models:{},channels:[]});writeFileSync(path,bytes);
  await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);
});
const posix = process.platform !== 'win32' && process.getuid?.() !== 0;
it.runIf(posix).each(['createChannel','updateChannel','deleteChannel','testChannel','createMCPInstall','updateMCPInstall','deleteMCPInstall']as const)('%s refuses actual parent EACCES instead of defaults',async method=>{
  const f=await fixture();seed(f);const directory=method.includes('MCP')?f.data:join(f.root,'config'),file=join(directory,method.includes('MCP')?'mcp-installs.json':'config.json'),bytes=readFileSync(file,'utf8');chmodSync(directory,0);
  try{await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');}finally{chmodSync(directory,0o700);}
  expect(readFileSync(file,'utf8')).toBe(bytes);expect(existsSync(file+'.bak')).toBe(false);
});
it.runIf(posix).each(['createChannel','createMCPInstall']as const)('%s ACK waits for real write completion and refuses unwritable missing target',async method=>{
  const f=await fixture();seed(f);const directory=method.includes('MCP')?f.data:join(f.root,'config'),file=join(directory,method.includes('MCP')?'mcp-installs.json':'config.json');unlinkSync(file);chmodSync(directory,0o500);
  try{await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_write_failed');}finally{chmodSync(directory,0o700);}expect(existsSync(file)).toBe(false);
});

it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall']as const)('%s rejects JSON null/scalar/object rather than treating them as a missing MCP file',async method=>{
 const f=await fixture();seed(f);const path=join(f.data,'mcp-installs.json');
 for(const bytes of ['null','false','42','{}']){writeFileSync(path,bytes);await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);}
});
it.each(['createChannel','updateChannel','deleteChannel','testChannel']as const)('%s rejects JSON null/scalar/array config instead of replacing it with defaults',async method=>{
 const f=await fixture();seed(f);const path=join(f.root,'config','config.json');
 for(const bytes of ['null','false','42','[]']){writeFileSync(path,bytes);await expect(f.invoke(method,...legitimate[method])).rejects.toThrow('channel_mcp_mutation_source_unavailable');expect(readFileSync(path,'utf8')).toBe(bytes);expect(existsSync(path+'.bak')).toBe(false);}
});

```

## FULL desktop/tests/main/meeting-mutation-candidate-controls.test.ts
```typescript
// UNREVIEWED POST-APPLICATION controls. This imports new candidates at their
// production targets, so do NOT report missing-module baseline as a behavior RED.
// Copy to desktop/tests/main/meeting-mutation-candidate-controls.test.ts.
// @vitest-environment node
import { beforeEach, expect, it } from 'vitest';
import { registerMeetingMutationIpc } from '../../electron/meeting-mutation-typed-ipc.js';
import { createMeetingMutationService } from '../../electron/meeting-mutation-service.js';
import { createMeetingAudioPermissionService } from '../../electron/meeting-audio-permission.js';
import { resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
beforeEach(resetIpcSchemaRegistryForTests);
function boundary(producer: IpcHandlerListener) {
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate();
  const registrar = new ShutdownAwareIpcMain({ handle: (channel, listener) => listeners.set(channel, listener) }, gate);
  const producers = new Map([['desktop:meeting:requestMicrophonePermission', producer]]);
  registerMeetingMutationIpc(registrar, producers);
  return { gate, registrar, producers, invoke: () => listeners.get('desktop:meeting:requestMicrophonePermission')!({} as never) };
}
it('production typed boundary rejects output accessor without evaluating it', async () => {
  let reads = 0; const f = boundary(() => Object.defineProperty({}, 'status', { enumerable: true, get() { reads++; return 'granted'; } }));
  await expect(f.invoke()).rejects.toThrow('meeting_mutation_projection_unavailable'); expect(reads).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it.each([undefined, null, { status: 'invented' }, { status: 'granted', secret: 'owned-private-marker' }, { ok: false, error: 'fake-ack' }])('production typed boundary rejects invalid output %j', async value => {
  const f = boundary(() => value); await expect(f.invoke()).rejects.toThrow('meeting_mutation_projection_unavailable');
});
it('unknown producer rejection is fixed and never evaluates the error getter', async () => {
  let reads = 0; const error = Object.defineProperty({}, 'message', { get() { reads++; return 'owned-private-marker'; } });
  const f = boundary(() => Promise.reject(error)); await expect(f.invoke()).rejects.toThrow('meeting_mutation_action_failed'); expect(reads).toBe(0);
});
it('a native pending producer holds physical token until actual rejection', async () => {
  let reject!: (error: unknown) => void; const f = boundary(() => new Promise((_r, j) => { reject = j; }));
  const operation = Promise.resolve(f.invoke()).catch(error => error); expect(f.gate.outstanding).toBe(1);
  f.gate.close(); const drained = f.gate.drain(1000); reject(Error('owned-private-marker'));
  expect(await operation).toMatchObject({ message: 'meeting_mutation_action_failed' }); expect(await drained).toBe(true); expect(f.gate.outstanding).toBe(0);
});
it('producer bindings detach and registrar owner identity is enforced', async () => {
  const f = boundary(() => ({ status: 'granted' })); f.producers.set('desktop:meeting:requestMicrophonePermission', () => ({ status: 'denied' }));
  expect(await f.invoke()).toEqual({ status: 'granted' }); registerMeetingMutationIpc(f.registrar, f.producers);
  expect(() => registerMeetingMutationIpc(f.registrar, new Map(f.producers))).toThrow('meeting_mutation_registrar_owner_conflict');
});
it.each([undefined, 'agent', 'scheduler'] as const)('actual facade denies %s before permission/config/model work', async source => {
  let asks = 0; const permission = createMeetingAudioPermissionService({ platform: 'darwin', getMediaAccessStatus: () => 'not-determined', askForMediaAccess: async () => { asks++; return true; } });
  const service = createMeetingMutationService(permission);
  let getters = 0; const payload = Object.defineProperty({}, 'aliyun', { enumerable: true, get() { getters++; return {}; } });
  for (const operation of [() => service.requestMicrophonePermission(source), () => service.saveAsrConfig(payload, source), () => service.downloadModel(payload, source), () => service.uninstallModel(payload, source)]) await expect(operation()).rejects.toThrow('meeting_mutation_request_source_forbidden');
  expect(asks).toBe(0); expect(getters).toBe(0);
});
it('actual permission owner coalesces a pending OS ask and permits the next request after settlement', async () => {
  let asks = 0, finish!: (value: boolean) => void;
  const permission = createMeetingAudioPermissionService({ platform: 'darwin', getMediaAccessStatus: () => 'not-determined', askForMediaAccess: async () => { asks++; return new Promise<boolean>(r => { finish = r; }); } });
  const service = createMeetingMutationService(permission); const a = service.requestMicrophonePermission('user'), b = service.requestMicrophonePermission('user');
  const before = asks; finish(true); expect(await a).toEqual({ status: 'granted' }); expect(await b).toEqual({ status: 'granted' }); expect(before).toBe(1);
  const c = service.requestMicrophonePermission('user'); finish(true); await c; expect(asks).toBe(2);
});

```

## FULL desktop/tests/main/meeting-mutation-controls.test.ts
```typescript
// UNREVIEWED RED CANDIDATE. Copy to desktop/tests/main/meeting-mutation-controls.test.ts.
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'meeting-mutation-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;},setRecorder(v){meetingRecorderController=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}


// Fixture above is copied from the accepted readonly3 real-entry test. Main
// authorizeDesktopInvoke is extracted from production, not reimplemented here.
const methods = ['requestMicrophonePermission', 'saveAsrConfig', 'downloadModel', 'uninstallModel'] as const;
it.each(methods)('registers actual %s with captured tuple metadata', async method => {
  await fixture(); const entry = IPC_SCHEMA_REGISTRY.get('desktop:meeting:' + method);
  expect(entry).toMatchObject({ payloadMode: 'tuple', inputStage: 'beforeHandler', sourceFile: 'desktop/electron/meeting-mutation-typed-ipc.ts' });
});
it.each([
  ['requestMicrophonePermission', [{}]],
  ['saveAsrConfig', [{ defaultProvider: 'invented' }]],
  ['saveAsrConfig', [{ aliyun: { apiKey: 'owned-fixture-marker', clearApiKey: 'yes' } }]],
  ['saveAsrConfig', [{ aliyun: { unknownField: true } }]],
  ['saveAsrConfig', [{}, {}]],
  ['downloadModel', [42]], ['downloadModel', ['../outside']], ['downloadModel', ['never-a-registry-id', {}]],
  ['uninstallModel', [{}]], ['uninstallModel', ['never-a-registry-id', {}]],
] as [string, unknown[]][])('rejects %s invalid tuple without fabricating an ACK', async (method, args) => {
  const f = await fixture(); await expect(async () => f.invoke('meeting:' + method, ...args)).rejects.toThrow('meeting_mutation_input_invalid');
  expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(false); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('captures %s input before reading caller accessors', async method => {
  const f = await fixture(); let getters = 0;
  const payload = Object.defineProperty({}, method === 'saveAsrConfig' ? 'aliyun' : 'toString', { enumerable: true, get() { getters++; return method === 'saveAsrConfig' ? {} : () => 'never-a-registry-id'; } });
  await expect(async () => f.invoke('meeting:' + method, payload)).rejects.toThrow('meeting_mutation_input_invalid');
  expect(getters).toBe(0); expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(false);
});
it.each(methods.flatMap(method => ['unknown', 'old-main', 'subframe', 'bad-url', 'retired-recorder'].map(kind => [method, kind])))('source gate rejects %s / %s before payload inspection', async (method, kind) => {
  const f = await fixture(); let getters = 0;
  if (kind === 'old-main') f.authority.setMain({ webContents: { mainFrame: f.frame, isDestroyed: () => false }, isDestroyed: () => false });
  if (kind === 'bad-url') f.frame.url = 'file:///never-owned/index.html';
  if (kind === 'retired-recorder') f.authority.setRecorder({ ownsWebContents: () => false });
  const sender = kind === 'unknown' ? { mainFrame: f.frame, isDestroyed: () => false } : kind === 'retired-recorder' ? f.recorder : f.sender;
  const frame = kind === 'subframe' ? { url: f.frame.url } : kind === 'retired-recorder' ? f.recorderFrame : f.frame;
  const payload = Object.defineProperty({}, 'aliyun', { enumerable: true, get() { getters++; return {}; } });
  await expect(async () => Reflect.apply(f.listeners.get('desktop:meeting:' + method)!, undefined, [{ sender, senderFrame: frame }, payload])).rejects.toThrow('desktop_user_sender_forbidden');
  expect(getters).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('closed shutdown gate rejects %s before payload or work', async method => {
  const f = await fixture(); f.gate.close(); let reads = 0;
  const payload = Object.defineProperty({}, 'aliyun', { enumerable: true, get() { reads++; return {}; } });
  await expect(async () => f.invoke('meeting:' + method, payload)).rejects.toThrow('shutting_down'); expect(reads).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it('save keeps actual credentials private and preserves explicit clear / blank semantics', async () => {
  const f = await fixture(); const path = join(f.root, 'config', 'config.json');
  const dto = await f.invoke('meeting:saveAsrConfig', { defaultProvider: 'aliyun-asr', aliyun: { apiKey: 'owned-fixture-not-a-real-key', baseUrl: 'https://owned.invalid/', model: 'owned-model' } });
  expect(dto.aliyun).toMatchObject({ configured: true, apiKeyConfigured: true, baseUrl: 'https://owned.invalid', model: 'owned-model' });
  expect(JSON.stringify(dto)).not.toContain('owned-fixture-not-a-real-key'); expect(JSON.parse(readFileSync(path, 'utf8')).meeting.asr.aliyun.apiKey).toBe('owned-fixture-not-a-real-key');
  await f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: '   ' } });
  expect(JSON.parse(readFileSync(path, 'utf8')).meeting.asr.aliyun.apiKey).toBe('owned-fixture-not-a-real-key');
  const cleared = await f.invoke('meeting:saveAsrConfig', { aliyun: { clearApiKey: true, apiKey: 'ignored-owned-marker' } });
  expect(cleared.aliyun.apiKeyConfigured).toBe(false); expect(JSON.parse(readFileSync(path, 'utf8')).meeting.asr.aliyun.apiKey).toBeUndefined();
});
it.each([[], [null], [undefined], [{}]].map(args => ({ args })))('keeps original nullish / empty save input behavior: %j', async ({ args }) => {
  const f = await fixture(); const dto = await f.invoke('meeting:saveAsrConfig', ...args);
  expect(dto.defaultProvider).toBe('sherpa-onnx-paraformer'); expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(true);
});
it('corrupt actual config cannot be repaired into a successful save ACK or credential-bearing error', async () => {
  const f = await fixture(), dir = join(f.root, 'config'); mkdirSync(dir, { recursive: true });
  const path = join(dir, 'config.json'), raw = '{"meeting":{"asr":{"aliyun":{"apiKey":owned-private-marker}}}}'; writeFileSync(path, raw);
  await expect(async () => f.invoke('meeting:saveAsrConfig', { defaultProvider: 'whisper' })).rejects.toThrow('meeting_mutation_save_failed');
  expect(readFileSync(path, 'utf8')).toBe(raw); expect(existsSync(path + '.bak')).toBe(false);
});
it('a real filesystem save failure rejects with a fixed credential-free code', async () => {
  const f = await fixture(), dir = join(f.root, 'config'); mkdirSync(dir, { recursive: true }); mkdirSync(join(dir, 'config.json'));
  const error = await Promise.resolve().then(() => f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: 'owned-private-marker' } })).catch(e => e);
  expect(error).toBeInstanceOf(Error); expect(error.message).toBe('meeting_mutation_save_failed'); expect(String(error)).not.toContain('owned-private-marker');
});
it('two real saves in one turn retain edits to both providers', async () => {
  const f = await fixture(); await Promise.all([
    f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: 'owned-ali' } }),
    f.invoke('meeting:saveAsrConfig', { volcengine: { appKey: 'owned-volc' } }),
  ]);
  const data = JSON.parse(readFileSync(join(f.root, 'config', 'config.json'), 'utf8'));
  expect(data.meeting.asr.aliyun.apiKey).toBe('owned-ali'); expect(data.meeting.asr.volcengine.appKey).toBe('owned-volc');
});
it('current Recorder is a valid save caller through the production Main authorizer', async () => {
  const f = await fixture(); const dto = await Reflect.apply(f.listeners.get('desktop:meeting:saveAsrConfig')!, undefined, [{ sender: f.recorder, senderFrame: f.recorderFrame }, {}]);
  expect(dto.defaultProvider).toBe('sherpa-onnx-paraformer'); expect(f.gate.outstanding).toBe(0);
});

it.each(['https://owned:owned-private-marker@owned.invalid', 'https://owned.invalid/?token=owned-private-marker', 'https://owned.invalid/#owned-private-marker'])('rejects credential-bearing public endpoint %s before saving', async baseUrl => {
  const f = await fixture(); await expect(async () => f.invoke('meeting:saveAsrConfig', { aliyun: { apiKey: 'owned-private-marker', baseUrl } })).rejects.toThrow('meeting_mutation_input_invalid');
  expect(existsSync(join(f.root, 'config', 'config.json'))).toBe(false);
});

```

## FULL desktop/tests/main/meeting-mutation-model-lifecycle.test.ts
```typescript
// UNREVIEWED RED CANDIDATE. Copy to desktop/tests/main/meeting-mutation-model-lifecycle.test.ts.
// @vitest-environment node
import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, expect, it } from 'vitest';
import { createMeetingModelService, type MeetingModelDefinition } from '../../electron/meeting-model-service.js';
import { createMeetingAudioPermissionService } from '../../electron/meeting-audio-permission.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function heldFixture(directory = false) {
  const cacheDir = mkdtempSync(join(tmpdir(), 'meeting-model-lease-owned-')); roots.push(cacheDir);
  let release!: () => void; const held = new Promise<void>(r => { release = r; }); let calls = 0;
  const bytes = Buffer.from('owned-model-bytes');
  const model: MeetingModelDefinition = { id: 'owned', fileName: directory ? 'owned-dir' : 'owned.bin', url: 'https://owned.invalid/model', expectedSizeBytes: bytes.length, expectedSha256: createHash('sha256').update(bytes).digest('hex'), ...(directory ? { packageType: 'directory' as const, archiveFileName: 'owned.tar.bz2', requiredFiles: ['model.bin'] } : {}) };
  const options = { cacheDir, models: [model], downloadFile: async (_url: string, destination: string) => { calls++; await held; writeFileSync(destination, bytes); } };
  return { cacheDir, model, release, calls: () => calls, first: createMeetingModelService(options), second: createMeetingModelService(options) };
}
it('same cache/model across real service instances rejects a concurrent download', async () => {
  const f = heldFixture(); const first = f.first.downloadModel('owned');
  let secondError: unknown, succeeded = false;
  const second = f.second.downloadModel('owned').then(() => { succeeded = true; }, error => { secondError = error; });
  await Promise.resolve(); const before = f.calls();
  f.release(); await Promise.all([first, second]);
  expect(before).toBe(1); expect(succeeded).toBe(false); expect(secondError).toMatchObject({ message: 'meeting_model_busy' });
});
it('actual uninstall cannot ACK while an admitted download can recreate the model', async () => {
  const f = heldFixture(); const download = f.first.downloadModel('owned'); let failure: unknown;
  try { f.second.uninstallModel('owned'); } catch (error) { failure = error; } finally { f.release(); }
  await download; expect(failure).toMatchObject({ message: 'meeting_model_busy' });
  const result = f.second.uninstallModel('owned'); expect(result.ok).toBe(true); expect(result.model.packageState).toBe('missing'); expect(existsSync(join(f.cacheDir, f.model.fileName))).toBe(false);
});
it('failed real download releases its cache/model lease for a later action', async () => {
  const cacheDir = mkdtempSync(join(tmpdir(), 'meeting-model-failure-owned-')); roots.push(cacheDir);
  const model = { id: 'owned', fileName: 'owned.bin', url: 'https://owned.invalid', expectedSizeBytes: 1, expectedSha256: '0'.repeat(64) };
  const service = createMeetingModelService({ cacheDir, models: [model], downloadFile: async () => { throw Error('owned-transfer-failed'); } });
  await expect(service.downloadModel('owned')).rejects.toThrow('owned-transfer-failed'); expect(service.uninstallModel('owned').ok).toBe(true);
});
it('real directory extraction remains covered by the download lease until settlement', async () => {
  const f = heldFixture(true); f.release();
  let finish!: () => void, started!: () => void;
  const extracting = new Promise<void>(r => { started = r; }), held = new Promise<void>(r => { finish = r; });
  const service = createMeetingModelService({ cacheDir: f.cacheDir, models: [f.model], downloadFile: async (_url, path) => writeFileSync(path, Buffer.from('owned-model-bytes')), extractArchive: async () => { started(); await held; throw Error('owned-extraction-failed'); } });
  const operation = service.downloadModel('owned').catch(error => error); await extracting;
  let error: unknown; try { f.second.uninstallModel('owned'); } catch (value) { error = value; } finally { finish(); }
  expect((await operation).message).toBe('owned-extraction-failed'); expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(f.second.uninstallModel('owned').ok).toBe(true);
});
it('physical shutdown token remains held for the real download, then releases on completion', async () => {
  const f = heldFixture(), gate = new DesktopShutdownGate(); let listener!: IpcHandlerListener;
  const ipc = new ShutdownAwareIpcMain({ handle: (_channel, value) => { listener = value; } }, gate);
  ipc.handle('owned:test:real-model-download', () => f.first.downloadModel('owned'));
  const operation = listener({} as never); expect(gate.outstanding).toBe(1); gate.close(); const drained = gate.drain(1000);
  f.release(); await operation; expect(await drained).toBe(true); expect(gate.outstanding).toBe(0);
});
it.each(['darwin', 'win32', 'linux'])('real permission service retains %s platform behavior', async platform => {
  let asks = 0; const service = createMeetingAudioPermissionService({ platform, getMediaAccessStatus: () => 'not-determined', askForMediaAccess: async media => { expect(media).toBe('microphone'); asks++; return true; } });
  expect((await service.requestPermission()).status).toBe(platform === 'darwin' ? 'granted' : 'unknown'); expect(asks).toBe(platform === 'darwin' ? 1 : 0);
});
it.each(['granted', 'denied', 'restricted'])('real permission service does not re-prompt Darwin %s', async status => {
  let asks = 0; const service = createMeetingAudioPermissionService({ platform: 'darwin', getMediaAccessStatus: () => status, askForMediaAccess: async () => { asks++; return true; } });
  expect(await service.requestPermission()).toEqual({ status }); expect(asks).toBe(0);
});

```

## FULL desktop/tests/main/runtime-status-readonly-controls.test.ts
```typescript
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'skills-readonly-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { ipc, root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}



async function statusFixture(method:'getComputerUseCapabilityStatus'|'kswarm:getStatus'){
 const f=await fixture();const row={running:false,port:4400,pid:null,restartCount:0,lastError:null,terminalDegraded:true,persistenceFailStopCount:2,lastPersistenceFailStop:'owned-failure',future:{kept:['owned']}};const produce=vi.fn(()=>row);
 if(method==='kswarm:getStatus'){
  const source=readFileSync(new URL('../../electron/main.ts',import.meta.url),'utf8'),ast=ts.createSourceFile('main.ts',source,ts.ScriptTarget.Latest,true);let declaration:ts.ExpressionStatement|undefined;function visit(node:ts.Node){if(ts.isExpressionStatement(node)&&ts.isCallExpression(node.expression)){const call=node.expression,name=call.expression.getText(ast);if(name==='registerKswarmStatusReadonlyIpc'||name==='shutdownAwareIpc.handle'&&call.arguments[0]&&ts.isStringLiteral(call.arguments[0])&&call.arguments[0].text==='desktop:kswarm:getStatus')declaration=node;}ts.forEachChild(node,visit);}visit(ast);expect(declaration).toBeDefined();
  const isTyped=source.includes('registerKswarmStatusReadonlyIpc');const register=isTyped?(await import('../../electron/runtime-status-readonly-typed-ipc.js')).registerKswarmStatusReadonlyIpc:undefined;
  const code=ts.transpileModule(declaration!.getText(ast),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;compileFunction(code,['shutdownAwareIpc','kswarmService','registerKswarmStatusReadonlyIpc'])(f.ipc,{getStatus:produce},register);
 }else vi.spyOn(f.service,'getComputerUseCapabilityStatus').mockImplementation(produce as never);
 return{...f,row,produce,invoke:(...args:unknown[])=>f.invoke(method,...args)};
}
it.each(['getComputerUseCapabilityStatus','kswarm:getStatus']as const)('rejects actual %s extra transport input before cached getter',async method=>{const f=await statusFixture(method);await expect(async()=>f.invoke({})).rejects.toThrow('runtime_status_input_invalid');expect(f.produce).not.toHaveBeenCalled();});
it.each(['getComputerUseCapabilityStatus','kswarm:getStatus']as const)('rejects actual %s malformed successful producer value',async method=>{const f=await statusFixture(method);f.produce.mockReturnValue({}as never);await expect(async()=>f.invoke()).rejects.toThrow('runtime_status_projection_unavailable');expect(f.produce).toHaveBeenCalledTimes(1);});
it.each(['unknown','old-main','subframe'])('denies %s before status producer and payload getters',async kind=>{const f=await statusFixture('kswarm:getStatus'),old=f.sender;if(kind==='old-main')f.authority.setMain({webContents:{mainFrame:f.frame,isDestroyed:()=>false},isDestroyed:()=>false});const sender=kind==='unknown'?{mainFrame:f.frame,isDestroyed:()=>false}:old,frame=kind==='subframe'?{url:f.frame.url}:f.frame;let reads=0;const input=Object.defineProperty({},'owned',{enumerable:true,get(){reads++;return'owned'}});await expect(async()=>Reflect.apply(f.listeners.get('desktop:kswarm:getStatus')!,undefined,[{sender,senderFrame:frame},input])).rejects.toThrow('desktop_user_sender_forbidden');expect(reads).toBe(0);expect(f.produce).not.toHaveBeenCalled();});
it('detaches all8 SDK fields and future metadata on each actual Main source invocation',async()=>{const f=await statusFixture('kswarm:getStatus'),a=await f.invoke(),b=await f.invoke();expect(a).toEqual(f.row);expect(a).not.toBe(f.row);expect(a).not.toBe(b);expect(a.future.kept).not.toBe(f.row.future.kept);expect(a.terminalDegraded).toBe(true);expect(a.persistenceFailStopCount).toBe(2);expect(f.gate.outstanding).toBe(0);});

```

## FULL desktop/tests/main/skill-mutation-controls.test.ts
```typescript
// @vitest-environment node
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
const processMocks = vi.hoisted(() => ({ sync: vi.fn() }));
vi.mock('node:child_process', async load => ({ ...await load<typeof import('node:child_process')>(), spawnSync: processMocks.sync }));
vi.mock('cross-spawn', () => ({ default: { sync: processMocks.sync } }));
import { getSkillCatalogVersion, onSkillCatalogChanged } from '../../electron/skill-catalog-invalidation.js';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'skills-readonly-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); processMocks.sync.mockReset(); processMocks.sync.mockReturnValue({ status: 0, error: undefined, stdout: '', stderr: '' }); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  const broadcast = ast.statements.length && (() => {
    let statement: ts.ExpressionStatement | undefined;
    const visit = (n: ts.Node) => { if (ts.isExpressionStatement(n) && ts.isCallExpression(n.expression) && n.expression.expression.getText(ast) === 'onSkillCatalogChanged') statement = n; ts.forEachChild(n, visit); }; visit(ast);
    expect(statement).toBeDefined();
    const sent = vi.fn();
    const code = ts.transpileModule('return ' + statement!.expression.getText(ast) + ';', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
    const unsubscribe = compileFunction(code, ['onSkillCatalogChanged', 'mainWindow'])(onSkillCatalogChanged, { isDestroyed: () => false, webContents: { send: sent } });
    cleanups.push(async () => unsubscribe()); return sent;
  })();
  return { root, data, service, broadcast, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}

// Copy to desktop/tests/main/skill-mutation-controls.test.ts BEFORE applying proposal.patch.
// All RED expectations invoke the real registerDesktopIpc / createDesktopServices.
const methods = ['installSkill', 'uninstallSkill'] as const;
it.each(methods)('qualifies %s as an exact one-argument typed tuple', async method => {
  await fixture(); expect(IPC_SCHEMA_REGISTRY.get('desktop:' + method)).toMatchObject({ payloadMode: 'tuple', rolloutRound: 34 });
});
it.each(methods)('%s preserves clawhub command/deadline/cwd and invalidates+broadcasts once on success', async method => {
  const f = await fixture(), version = getSkillCatalogVersion();
  const result = await f.invoke(method, 'owned-skill'); expect(result.success).toBe(true);
  expect(processMocks.sync).toHaveBeenCalledExactlyOnceWith('clawhub', [method === 'installSkill' ? 'install' : 'uninstall', 'owned-skill'], { encoding: 'utf-8', timeout: method === 'installSkill' ? 60000 : 30000, cwd: process.cwd() });
  expect(getSkillCatalogVersion()).toBe(version + 1); expect(f.broadcast).toHaveBeenCalledExactlyOnceWith('desktop:skillsChanged'); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s does not invalidate/broadcast on process errors, signal, timeout or nonzero exit', async method => {
  const f = await fixture();
  for (const failure of [{ status: 1, stderr: 'owned_failure', stdout: '' }, { status: null, signal: 'SIGTERM', stderr: '', stdout: '' }, { error: Error('ENOENT'), status: null }, { error: Error('ETIMEDOUT'), status: null }]) {
    const version = getSkillCatalogVersion(); processMocks.sync.mockReturnValueOnce(failure);
    expect((await f.invoke(method, 'owned-skill')).success).toBe(false); expect(getSkillCatalogVersion()).toBe(version);
  }
  expect(f.broadcast).not.toHaveBeenCalled(); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s preserves bounded stderr/stdout fallback rather than a success ACK', async method => {
  const f = await fixture(); processMocks.sync.mockReturnValueOnce({ status: 3, stderr: ' x'.repeat(400), stdout: 'ignored' });
  expect(await f.invoke(method, 'owned-skill')).toEqual({ success: false, message: ' x'.repeat(400).trim().slice(0, 500) });
  processMocks.sync.mockReturnValueOnce({ status: 1, stderr: '', stdout: 'stdout-failure' }); expect((await f.invoke(method, 'owned-skill')).message).toBe('stdout-failure');
});
it.each(methods)('%s rejects missing/extra/source/path/option input before the actual OS boundary', async method => {
  const f = await fixture();
  for (const args of [[], ['owned', { requestSource: 'user' }], [42], [''], [' owned '], ['--force'], ['../escape'], ['C:\\escape'], ['C:escape'], ['\\\\server\\share'], ['/absolute'], ['.'], ['..'], ['bad\0name']]) {
    await expect(async () => f.invoke(method, ...args)).rejects.toThrow('skill_mutation_input_invalid');
  }
  expect(processMocks.sync).not.toHaveBeenCalled(); expect(f.broadcast).not.toHaveBeenCalled();
});
it.each(methods)('%s retains Unicode, namespace and interior-space caller names as one operand', async method => {
  const f = await fixture(); for (const name of ['报告技能', 'team:owned-skill', 'owned skill', 'a.b_c-1']) expect((await f.invoke(method, name)).success).toBe(true);
  expect(processMocks.sync.mock.calls.map(call => call[1][1])).toEqual(['报告技能', 'team:owned-skill', 'owned skill', 'a.b_c-1']);
});
it.each(methods)('%s captures input before toJSON/accessors or result logging can execute', async method => {
  const f = await fixture(); let reads = 0;
  for (const value of [Object.defineProperty({}, 'skill', { enumerable: true, get() { reads++; return 'owned'; } }), { toJSON() { reads++; return 'owned'; } }]) await expect(async () => f.invoke(method, value)).rejects.toThrow('skill_mutation_input_invalid');
  expect(reads).toBe(0); expect(processMocks.sync).not.toHaveBeenCalled();
});
it.each(methods)('%s enforces user source inside the real service, including omitted and accessor source', async method => {
  const f = await fixture(); const mutate = f.service[method] as unknown as (name: unknown, context?: unknown) => Promise<unknown>;
  let reads = 0; const accessor = Object.defineProperty({}, 'requestSource', { enumerable: true, get() { reads++; return 'user'; } });
  for (const context of [undefined, { requestSource: 'agent' }, { requestSource: 'scheduler' }, accessor]) await expect(async () => mutate('owned-skill', context)).rejects.toThrow('skill_mutation_source_forbidden');
  expect(reads).toBe(0); expect(processMocks.sync).not.toHaveBeenCalled();
  expect(await mutate('owned-skill', { requestSource: 'user' })).toMatchObject({ success: true });
});
it.each(methods)('%s validates names inside the real service even without IPC', async method => {
  const f = await fixture(); const mutate = f.service[method] as unknown as (name: unknown, context: unknown) => Promise<unknown>;
  await expect(async () => mutate('../escape', { requestSource: 'user' })).rejects.toThrow('skill_mutation_input_invalid'); expect(processMocks.sync).not.toHaveBeenCalled();
});
it.each(methods)('%s validates producer output before result getter/toJSON/unknown ACK', async method => {
  const f = await fixture(); let reads = 0;
  const accessor = Object.defineProperty({ message: 'owned' }, 'success', { enumerable: true, get() { reads++; return true; } });
  for (const value of [accessor, { success: true, message: 'owned', toJSON() { reads++; return {}; } }, undefined, { success: 'yes', message: 'owned' }]) {
    f.service[method] = (() => Promise.resolve(value)) as never;
    await expect(async () => f.invoke(method, 'owned')).rejects.toThrow('skill_mutation_output_invalid');
  }
  expect(reads).toBe(0); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s rejects unsafe thenables without invoking their then accessor', async method => {
  const f = await fixture(); let reads = 0; const value = Object.defineProperty({}, 'then', { get() { reads++; return () => {}; } });
  f.service[method] = (() => value) as never; await expect(async () => f.invoke(method, 'owned')).rejects.toThrow('skill_mutation_output_invalid'); expect(reads).toBe(0);
});
it.each(methods)('%s detaches producer metadata and preserves business failure shape', async method => {
  const f = await fixture(), value = { success: false, message: 'owned_failure', future: { retained: true } }; f.service[method] = (() => Promise.resolve(value)) as never;
  const result = await f.invoke(method, 'owned'); expect(result).toEqual(value); expect(result).not.toBe(value); expect(result.future).not.toBe(value.future);
});
it.each(methods)('%s retains producer throw/reject identity and releases the original token', async method => {
  const f = await fixture(), failure = Error('owned_service_failure');
  f.service[method] = (() => { throw failure; }) as never; await expect(async () => f.invoke(method, 'owned')).rejects.toBe(failure);
  f.service[method] = (() => Promise.reject(failure)) as never; await expect(async () => f.invoke(method, 'owned')).rejects.toBe(failure); expect(f.gate.outstanding).toBe(0);
});
it.each(methods)('%s denies unknown/old/subframe/bad-URL sender before input capture', async method => {
  const f = await fixture(); let reads = 0; const input = Object.defineProperty({}, 'field', { enumerable: true, get() { reads++; return 'owned'; } });
  const invokeAs = (sender: unknown, senderFrame: unknown) => Reflect.apply(f.listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame }, input]);
  await expect(async () => invokeAs({ ...f.sender }, f.frame)).rejects.toThrow('desktop_user_sender_forbidden');
  await expect(async () => invokeAs(f.sender, { ...f.frame })).rejects.toThrow('desktop_user_sender_forbidden');
  const url = f.frame.url; f.frame.url = 'https://untrusted.invalid/'; await expect(async () => invokeAs(f.sender, f.frame)).rejects.toThrow('desktop_user_sender_forbidden'); f.frame.url = url;
  f.authority.setMain({ isDestroyed: () => false, webContents: {} }); await expect(async () => invokeAs(f.sender, f.frame)).rejects.toThrow('desktop_user_sender_forbidden');
  expect(reads).toBe(0); expect(processMocks.sync).not.toHaveBeenCalled();
});
it.each(methods)('%s retains the existing owned Recorder admission population', async method => {
  const f = await fixture(); expect(await Reflect.apply(f.listeners.get('desktop:' + method)!, undefined, [{ sender: f.recorder, senderFrame: f.recorderFrame }, 'owned-skill'])).toMatchObject({ success: true });
});
it.each(methods)('%s holds one original token past shutdown deadline then drains and rejects new calls', async method => {
  const f = await fixture(); let release!: (v: { success: boolean; message: string }) => void;
  f.service[method] = (() => new Promise(resolve => { release = resolve; })) as never;
  vi.useFakeTimers(); const reading = f.invoke(method, 'owned'); await Promise.resolve(); expect(f.gate.outstanding).toBe(1);
  try { f.gate.close(); const drain = f.gate.drain(5000); await vi.advanceTimersByTimeAsync(5001); expect(await drain).toBe(false); expect(f.gate.outstanding).toBe(1); await expect(async () => f.invoke(method, 'other')).rejects.toThrow('shutting_down'); }
  finally { release({ success: true, message: 'owned' }); await reading; }
  expect(f.gate.outstanding).toBe(0);
});

```

## FULL desktop/tests/main/skill-mutation-preload.test.ts
```typescript
// @vitest-environment node
// Copy to desktop/tests/main/skill-mutation-preload.test.ts.
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import * as os from 'node:os';
import { expect, it, vi } from 'vitest';
import { createPreloadApi } from '../../electron/preload-api.js';
function port() { return { invoke: vi.fn(async (_channel: string, ..._args: unknown[]) => ({ success: true, message: 'owned_ok' })), on: vi.fn(), off: vi.fn(), removeListener: vi.fn(), send: vi.fn() }; }
async function check(api: ReturnType<typeof createPreloadApi>, ipc: ReturnType<typeof port>) {
  for (const method of ['installSkill', 'uninstallSkill'] as const) {
    ipc.invoke.mockClear(); expect(await api[method]('owned-skill')).toEqual({ success: true, message: 'owned_ok' });
    expect(ipc.invoke).toHaveBeenCalledExactlyOnceWith('desktop:' + method, 'owned-skill');
    const failure = Error('owned_failure'); ipc.invoke.mockRejectedValueOnce(failure); await expect(api[method]('owned-skill')).rejects.toBe(failure);
    ipc.invoke.mockResolvedValueOnce({ success: false, message: 'owned_business_failure' }); expect(await api[method]('owned-skill')).toEqual({ success: false, message: 'owned_business_failure' });
  }
  const callback = vi.fn(), dispose = api.onSkillsChanged(callback); expect(ipc.on).toHaveBeenCalledExactlyOnceWith('desktop:skillsChanged', expect.any(Function));
  ipc.on.mock.calls[0]![1]({}, undefined); expect(callback).toHaveBeenCalledTimes(1); dispose();
  expect([...ipc.off.mock.calls, ...ipc.removeListener.mock.calls]).toEqual([['desktop:skillsChanged', ipc.on.mock.calls[0]![1]]]);
}
it('TS preload retains exact skill tuple, business failure, rejection and reload disposal', async () => { const ipc = port(); await check(createPreloadApi(ipc), ipc); });
it('real CJS sandbox preload retains exact skill tuple, business failure, rejection and reload disposal', async () => {
  const ipc = port(); let api!: ReturnType<typeof createPreloadApi>;
  runInNewContext(readFileSync(new URL('../../electron/preload.cjs', import.meta.url), 'utf8'), { require(name: string) {
    if (name === 'electron') return { ipcRenderer: ipc, contextBridge: { exposeInMainWorld(_key: string, value: ReturnType<typeof createPreloadApi>) { api = value; } } };
    if (name === 'os') return os; throw Error('unexpected dependency ' + name);
  } }); await check(api, ipc);
});

```

## FULL desktop/tests/renderer/channel-mcp-mutation-ui-followup.test.tsx
```typescript
// UNREVIEWED FOLLOWUP controls. Copy to desktop/tests/renderer with this filename.
// Real DesktopSettings/ChannelsPane/McpPane + real bridge; only window transport is controlled.
// npm run test -- --run tests/renderer/channel-mcp-mutation-ui-followup.test.tsx
import { cleanup, fireEvent, render, screen, waitFor, within, act } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
type Kind='channels'|'mcp';
type Action='create'|'delete'|'toggle';
const cases=[['channels','create'],['channels','delete'],['channels','toggle'],['mcp','create'],['mcp','delete']]as const;
const channel={id:'owned',type:'telegram',name:'Owned channel',enabled:true,createdAt:0,updatedAt:0};
const install={id:'owned',name:'Owned MCP',source:'local',command:'owned-command',args:['--owned'],enabled:true,createdAt:0};
const endpoint={listChannels:vi.fn(),listMCPInstalls:vi.fn(),createChannel:vi.fn(),deleteChannel:vi.fn(),updateChannel:vi.fn(),testChannel:vi.fn(),createMCPInstall:vi.fn(),deleteMCPInstall:vi.fn()};
let previous:typeof window.xiaokDesktop;
function deferred<T>(){
 let complete!:(value:T)=>void,reject!:(error:unknown)=>void,settled=false;
 const promise=new Promise<T>((yes,no)=>{complete=yes;reject=no;});
 return {promise,resolve:(value:T)=>{settled=true;complete(value);},reject:(error:unknown)=>{settled=true;reject(error);},get settled(){return settled;}};
}
function LocaleSwitch(){const {setLocale}=useLocale();return <button onClick={()=>setLocale('en')}>followup-locale</button>;}
beforeEach(()=>{
 previous=window.xiaokDesktop;localStorage.setItem('xiaok:locale','zh');for(const mock of Object.values(endpoint))mock.mockReset();
 endpoint.listChannels.mockResolvedValue([channel]);endpoint.listMCPInstalls.mockResolvedValue([install]);
 window.xiaokDesktop={...previous,...endpoint,listPluginMcpServers:async()=>[],listPluginDependencyStatuses:async()=>[],getServiceStatus:async()=>({services:[]}),getSkillDebugConfig:async()=>({enabled:false}),getKswarmConfig:async()=>({maxConcurrentTasks:3})}as never;
 vi.spyOn(window,'confirm').mockReturnValue(true);vi.spyOn(window,'alert').mockImplementation(()=>{});
});
afterEach(()=>{cleanup();window.xiaokDesktop=previous;localStorage.removeItem('xiaok:locale');vi.restoreAllMocks();vi.useRealTimers();});
function read(kind:Kind){return kind==='channels'?endpoint.listChannels:endpoint.listMCPInstalls;}
function action(kind:Kind,name:Action){return kind==='channels'?(name==='create'?endpoint.createChannel:name==='toggle'?endpoint.updateChannel:endpoint.deleteChannel):(name==='create'?endpoint.createMCPInstall:endpoint.deleteMCPInstall);}
function row(name:string){const element=screen.getByText(name).closest('.flex.items-center.justify-between');expect(element).not.toBeNull();return within(element as HTMLElement);}
async function mount(kind:Kind){
 const view=render(<MemoryRouter><LocaleProvider><LocaleSwitch/><DesktopSettings onClose={()=>{}}/></LocaleProvider></MemoryRouter>);
 fireEvent.click(screen.getByRole('button',{name:kind==='channels'?'消息通道':'MCP 服务器'}));await screen.findByText(kind==='channels'?channel.name:install.name);return view;
}
function input(id:string,value:string){const node=document.getElementById(id);expect(node).not.toBeNull();fireEvent.change(node!,{target:{value}});}
function openCreate(kind:Kind){
 fireEvent.click(screen.getByRole('button',{name:kind==='channels'?'添加通道':'添加 MCP 服务器'}));
 if(kind==='channels'){
  input('desktop-channel-name',' Owned new ');input('desktop-channel-type','discord');input('desktop-channel-field-botToken','OWNED_BOT_SECRET');
 }else{input('desktop-mcp-server-name',' Owned new ');input('desktop-mcp-server-command',' owned-command ');input('desktop-mcp-server-args',' --one  two ');}
 return screen.getByRole('button',{name:'创建'});
}
function start(kind:Kind,name:Action){
 const button=name==='create'?openCreate(kind):name==='toggle'?row(channel.name).getByRole('button',{name:'启用中'}):row(kind==='channels'?channel.name:install.name).getAllByRole('button').at(-1)!;
 fireEvent.click(button);return button;
}
function ack(kind:Kind,name:Action){return name==='delete'?undefined:name==='toggle'?{...channel,enabled:false}:kind==='channels'?{...channel,id:'discord',type:'discord',name:'Owned new'}:{...install,id:'created',name:'Owned new'};}
async function finish<T>(held:ReturnType<typeof deferred<T>>,value:T){await act(async()=>{held.resolve(value);await held.promise;});}
function factsVisible(kind:Kind){expect(screen.getByText(kind==='channels'?channel.name:install.name)).toBeInTheDocument();}
function assertOriginalArgs(kind:Kind,name:Action){
 const expected=name==='delete'?['owned']:name==='toggle'?['owned',{enabled:false}]:kind==='channels'?[{type:'discord',name:'Owned new',botToken:'OWNED_BOT_SECRET'}]:[{name:'Owned new',source:'npm',command:'owned-command',args:['--one','two']}];
 expect(action(kind,name)).toHaveBeenCalledExactlyOnceWith(...expected);
}
it.each(cases)('%s/%s held action retains form/facts and does not refresh before actual ACK',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);const reads=read(kind).mock.calls.length;
 try{start(kind,name);assertOriginalArgs(kind,name);await act(async()=>{await Promise.resolve();});factsVisible(kind);expect(read(kind)).toHaveBeenCalledTimes(reads);
  if(name==='create')expect(document.getElementById(kind==='channels'?'desktop-channel-name':'desktop-mcp-server-name')).toHaveValue(' Owned new ');
  await finish(held,ack(kind,name));await waitFor(()=>expect(read(kind).mock.calls.length).toBeGreaterThan(reads));
 }finally{if(!held.settled)await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s repeated click during a held action cannot issue duplicate mutations',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);
 try{const button=start(kind,name);fireEvent.click(button);expect(action(kind,name)).toHaveBeenCalledTimes(1);factsVisible(kind);}finally{await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s late ACK after unmount cannot restart the readonly owner',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);const view=await mount(kind);start(kind,name);const reads=read(kind).mock.calls.length;view.unmount();
 await finish(held,ack(kind,name));expect(read(kind)).toHaveBeenCalledTimes(reads);expect(window.alert).not.toHaveBeenCalled();expect(action(kind,name)).toHaveBeenCalledTimes(1);
});
it.each(cases)('%s/%s late rejection after unmount cannot publish a global alert',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);const view=await mount(kind);start(kind,name);const reads=read(kind).mock.calls.length;view.unmount();
 await act(async()=>{held.reject(Error('OWNED_EXPIRED_ACTION'));await held.promise.catch(()=>{});});expect(window.alert).not.toHaveBeenCalled();expect(read(kind)).toHaveBeenCalledTimes(reads);
});
it.each(cases)('%s/%s old locale ACK cannot refresh the new lifetime or close/reset its draft',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);
 try{start(kind,name);fireEvent.click(screen.getByRole('button',{name:'followup-locale'}));await waitFor(()=>expect(read(kind)).toHaveBeenCalledTimes(2));const reads=read(kind).mock.calls.length;
  if(name==='create')input(kind==='channels'?'desktop-channel-name':'desktop-mcp-server-name','Current English draft');
  await finish(held,ack(kind,name));expect(read(kind)).toHaveBeenCalledTimes(reads);factsVisible(kind);
  if(name==='create')expect(document.getElementById(kind==='channels'?'desktop-channel-name':'desktop-mcp-server-name')).toHaveValue('Current English draft');
 }finally{if(!held.settled)await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s old locale failure cannot publish errors in the new lifetime',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);start(kind,name);fireEvent.click(screen.getByRole('button',{name:'followup-locale'}));await waitFor(()=>expect(read(kind)).toHaveBeenCalledTimes(2));
 await act(async()=>{held.reject(Error('OWNED_EXPIRED_ACTION'));await held.promise.catch(()=>{});});expect(window.alert).not.toHaveBeenCalled();factsVisible(kind);
});
it.each(cases)('%s/%s successful ACK followed by readonly failure keeps last-good and never resends',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);
 try{start(kind,name);read(kind).mockRejectedValue(Error('OWNED_READ_AFTER_ACK'));await finish(held,ack(kind,name));
  expect(await screen.findByText(kind==='channels'?'无法读取消息通道':'无法读取 MCP 安装列表')).toBeInTheDocument();factsVisible(kind);assertOriginalArgs(kind,name);expect(window.alert).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button',{name:'重新读取'}));await waitFor(()=>expect(read(kind).mock.calls.length).toBeGreaterThanOrEqual(3));factsVisible(kind);assertOriginalArgs(kind,name);
 }finally{if(!held.settled)await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s rejected action keeps last-good, does not refresh, and manual read cannot clear/resend it',async(kind,name)=>{
 const failure=Error('OWNED_ACTION_FAILURE');action(kind,name).mockRejectedValue(failure);await mount(kind);const reads=read(kind).mock.calls.length;start(kind,name);
 await waitFor(()=>expect(window.alert).toHaveBeenCalledTimes(1));factsVisible(kind);expect(read(kind)).toHaveBeenCalledTimes(reads);assertOriginalArgs(kind,name);
 read(kind).mockRejectedValue(Error('OWNED_READ_FAILURE'));fireEvent.click(screen.getByRole('button',{name:'重新读取'}));expect(await screen.findByText(kind==='channels'?'无法读取消息通道':'无法读取 MCP 安装列表')).toBeInTheDocument();factsVisible(kind);assertOriginalArgs(kind,name);expect(window.alert).toHaveBeenCalledTimes(1);
});
it('Channel toggle has a held per-row action owner and repeated clicks cannot duplicate edits',async()=>{
 const held=deferred<unknown>();endpoint.updateChannel.mockReturnValue(held.promise);await mount('channels');
 try{const button=row(channel.name).getByRole('button',{name:'启用中'});fireEvent.click(button);fireEvent.click(button);expect(endpoint.updateChannel).toHaveBeenCalledExactlyOnceWith('owned',{enabled:false});factsVisible('channels');expect(endpoint.listChannels).toHaveBeenCalledTimes(1);}finally{await finish(held,{...channel,enabled:false});}
});
it('Channel tests on different rows retain independent busy states when the first one settles',async()=>{
 const other={...channel,id:'second',name:'Owned second channel'};endpoint.listChannels.mockResolvedValue([channel,other]);const first=deferred<unknown>(),second=deferred<unknown>();
 endpoint.testChannel.mockImplementation((id:string)=>id==='owned'?first.promise:second.promise);await mount('channels');
 try{fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));fireEvent.click(row(other.name).getByRole('button',{name:'测试'}));await finish(first,{success:true,latencyMs:1});
  const remaining=row(other.name).getByRole('button',{name:'测试'});expect(remaining).toBeDisabled();fireEvent.click(remaining);expect(endpoint.testChannel).toHaveBeenCalledTimes(2);
 }finally{if(!first.settled)await finish(first,{success:true,latencyMs:1});await finish(second,{success:true,latencyMs:2});}
});
it.each(['resolve','reject']as const)('held Channel test %s after locale change cannot publish an obsolete action fact',async mode=>{
 const held=deferred<unknown>();endpoint.testChannel.mockReturnValue(held.promise);await mount('channels');fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));fireEvent.click(screen.getByRole('button',{name:'followup-locale'}));await waitFor(()=>expect(endpoint.listChannels).toHaveBeenCalledTimes(2));
 await act(async()=>{if(mode==='resolve')held.resolve({success:false,error:'OWNED_EXPIRED_TEST'});else held.reject(Error('OWNED_EXPIRED_TEST'));await held.promise.catch(()=>{});});
 expect(screen.queryByText('OWNED_EXPIRED_TEST')).toBeNull();expect(screen.queryByText('Connection failed')).toBeNull();factsVisible('channels');expect(endpoint.testChannel).toHaveBeenCalledExactlyOnceWith('owned');
});
it('Channel action error and readonly last-good stay independent; a newer successful action clears only the old action error',async()=>{
 endpoint.testChannel.mockResolvedValueOnce({success:false,error:'OWNED_CURRENT_TEST_FAILURE'}).mockResolvedValueOnce({success:true,latencyMs:7});await mount('channels');fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));await screen.findByText('OWNED_CURRENT_TEST_FAILURE');
 endpoint.listChannels.mockRejectedValue(Error('OWNED_READ_FAILURE'));fireEvent.click(screen.getByRole('button',{name:'重新读取'}));await screen.findByText('无法读取消息通道');expect(screen.getByText('OWNED_CURRENT_TEST_FAILURE')).toBeInTheDocument();factsVisible('channels');expect(endpoint.testChannel).toHaveBeenCalledTimes(1);
 fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));await screen.findByText('连接成功，延迟 7ms');expect(screen.queryByText('OWNED_CURRENT_TEST_FAILURE')).toBeNull();expect(screen.getByText('无法读取消息通道')).toBeInTheDocument();factsVisible('channels');expect(endpoint.testChannel).toHaveBeenCalledTimes(2);
});
it('held MCP mutation does not acquire or duplicate the two-second readonly poll owner',async()=>{
 const held=deferred<unknown>();endpoint.deleteMCPInstall.mockReturnValue(held.promise);vi.useFakeTimers();
 const view=render(<MemoryRouter><LocaleProvider><LocaleSwitch/><DesktopSettings onClose={()=>{}}/></LocaleProvider></MemoryRouter>);
 fireEvent.click(screen.getByRole('button',{name:'MCP 服务器'}));await act(async()=>{await Promise.resolve();});factsVisible('mcp');start('mcp','delete');
 try{await act(async()=>{await vi.advanceTimersByTimeAsync(6_100);});expect(endpoint.listMCPInstalls).toHaveBeenCalledTimes(4);expect(endpoint.deleteMCPInstall).toHaveBeenCalledExactlyOnceWith('owned');factsVisible('mcp');view.unmount();const reads=endpoint.listMCPInstalls.mock.calls.length;
  await finish(held,undefined);await act(async()=>{await vi.advanceTimersByTimeAsync(4_100);});expect(endpoint.listMCPInstalls).toHaveBeenCalledTimes(reads);
 }finally{if(!held.settled)await finish(held,undefined);vi.useRealTimers();}
});

```

## FULL desktop/tests/renderer/channel-mcp-mutation-ui.test.tsx
```typescript
// UNREVIEWED RED CANDIDATE: desktop/tests/renderer/channel-mcp-mutation-ui.test.tsx
// cd desktop && npm run test -- --run tests/renderer/channel-mcp-mutation-ui.test.tsx
// Uses real DesktopSettings + real bridge. Only window transport endpoint is replaced.
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';
const channels=[{id:'owned',type:'telegram',name:'Owned channel',enabled:true,createdAt:0,updatedAt:0}];
const installs=[{id:'owned',name:'Owned MCP',source:'local',command:'owned-command',enabled:true,createdAt:0}];
let previous:typeof window.xiaokDesktop;
const endpoint={listChannels:vi.fn(),listMCPInstalls:vi.fn(),testChannel:vi.fn(),deleteChannel:vi.fn(),deleteMCPInstall:vi.fn(),updateChannel:vi.fn()};
beforeEach(()=>{
 previous=window.xiaokDesktop;localStorage.setItem('xiaok:locale','zh');
 for(const mock of Object.values(endpoint))mock.mockReset();endpoint.listChannels.mockResolvedValue(channels);endpoint.listMCPInstalls.mockResolvedValue(installs);
 window.xiaokDesktop={...previous,...endpoint,listPluginMcpServers:async()=>[],listPluginDependencyStatuses:async()=>[],getServiceStatus:async()=>({services:[]}),getSkillDebugConfig:async()=>({enabled:false}),getKswarmConfig:async()=>({maxConcurrentTasks:3})}as never;
});
afterEach(()=>{cleanup();window.xiaokDesktop=previous;localStorage.removeItem('xiaok:locale');vi.restoreAllMocks();});
async function mount(kind:'channels'|'mcp'){
 render(<MemoryRouter><LocaleProvider><DesktopSettings onClose={()=>{}} /></LocaleProvider></MemoryRouter>);
 fireEvent.click(screen.getByRole('button',{name:kind==='channels'?'消息通道':'MCP 服务器'}));await screen.findByText(kind==='channels'?'Owned channel':'Owned MCP');
}
function deleteButton(kind:'channels'|'mcp'){
 // Current production has no accessible delete label. Locate the actual row's last button;
 // proposed patch adds locale aria-label without making the RED depend on that change.
 const name=screen.getByText(kind==='channels'?'Owned channel':'Owned MCP');const card=name.closest('.flex.items-center.justify-between');expect(card).not.toBeNull();
 const buttons=within(card as HTMLElement).getAllByRole('button');return buttons[buttons.length-1]!;
}
it.each(['channels','mcp']as const)('%s canceled delete does not cross the real bridge and keeps last-good facts',async kind=>{
 const confirm=vi.spyOn(window,'confirm').mockReturnValue(false);await mount(kind);fireEvent.click(deleteButton(kind));
 expect(confirm).toHaveBeenCalledTimes(1);expect(kind==='channels'?endpoint.deleteChannel:endpoint.deleteMCPInstall).not.toHaveBeenCalled();expect(screen.getByText(kind==='channels'?'Owned channel':'Owned MCP')).toBeInTheDocument();
});
it.each(['channels','mcp']as const)('%s confirmed delete routes original id and only refreshes after ACK',async kind=>{
 vi.spyOn(window,'confirm').mockReturnValue(true);const remove=kind==='channels'?endpoint.deleteChannel:endpoint.deleteMCPInstall;remove.mockResolvedValue(undefined);await mount(kind);fireEvent.click(deleteButton(kind));
 await waitFor(()=>expect(remove).toHaveBeenCalledExactlyOnceWith('owned'));await waitFor(()=>expect(kind==='channels'?endpoint.listChannels:endpoint.listMCPInstalls).toHaveBeenCalledTimes(2));
});
it.each(['channels','mcp']as const)('%s rejected delete preserves last-good and shows localized failure without secret echo',async kind=>{
 vi.spyOn(window,'confirm').mockReturnValue(true);const alert=vi.spyOn(window,'alert').mockImplementation(()=>{}),remove=kind==='channels'?endpoint.deleteChannel:endpoint.deleteMCPInstall;remove.mockRejectedValue(Error('OWNED_PRIVATE_SECRET'));await mount(kind);fireEvent.click(deleteButton(kind));
 await waitFor(()=>expect(alert).toHaveBeenCalledExactlyOnceWith(kind==='channels'?'通道操作失败，请重试':'MCP 配置操作失败，请重试'));expect(screen.getByText(kind==='channels'?'Owned channel':'Owned MCP')).toBeInTheDocument();expect(kind==='channels'?endpoint.listChannels:endpoint.listMCPInstalls).toHaveBeenCalledTimes(1);
});
it('test rejection crosses the actual bridge, stays independent of readonly retry, and never echoes secrets',async()=>{
 endpoint.testChannel.mockRejectedValue(Error('OWNED_PRIVATE_SECRET'));await mount('channels');fireEvent.click(screen.getByRole('button',{name:'测试'}));expect(await screen.findByText('连接失败')).toBeInTheDocument();expect(screen.queryByText('OWNED_PRIVATE_SECRET')).toBeNull();
 fireEvent.click(screen.getByRole('button',{name:'重新读取'}));await waitFor(()=>expect(endpoint.listChannels).toHaveBeenCalledTimes(2));expect(screen.getByText('连接失败')).toBeInTheDocument();expect(endpoint.testChannel).toHaveBeenCalledExactlyOnceWith('owned');
});

```

## FULL desktop/tests/renderer/meeting-voicepane-actions.test.tsx
```typescript
// Actual DesktopSettings mounts its private VoicePane; only external preload
// dependency is replaced. These page tests do not claim real IPC/native proof.
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
import { zh } from '../../renderer/src/locales/zh';
import { en } from '../../renderer/src/locales/en';
const mocks = vi.hoisted(() => ({ models: vi.fn(), asr: vi.fn(), save: vi.fn(), download: vi.fn(), uninstall: vi.fn() }));
vi.mock('../../renderer/src/shared/desktop', () => ({ getDesktopApi: () => ({ meetingListModels: mocks.models, meetingGetAsrConfig: mocks.asr, meetingSaveAsrConfig: mocks.save, meetingDownloadModel: mocks.download, meetingUninstallModel: mocks.uninstall }) }));
const model = { id: 'owned-model', fileName: 'owned.pt', sizeBytes: 10, sizeLabel: '10 B', cacheDir: '/owned', path: '/owned/owned.pt', downloaded: false, status: 'not_downloaded', capability: 'asr', engineId: 'whisper', packageId: 'owned', packageType: 'single-file', packageState: 'missing', manifestTrusted: true, runtimeAutoDownloadAllowed: false };
const config = { defaultProvider: 'aliyun-asr', volcengine: { configured: false, appKeyConfigured: false, accessKeyConfigured: false, endpoint: 'wss://before.invalid', resourceId: 'owned-resource' }, aliyun: { configured: true, apiKeyConfigured: true, baseUrl: 'https://before.invalid', model: 'fun-asr' } };
function deferred<T>() { let resolve!: (value: T) => void, reject!: (value: unknown) => void; const promise = new Promise<T>((r, j) => { resolve = r; reject = j; }); return { promise, resolve, reject }; }
function LocaleButton() { const { setLocale } = useLocale(); return <button onClick={() => setLocale('en')}>test-switch-locale</button>; }
function mount() {
  const view = render(<MemoryRouter><LocaleProvider><LocaleButton /><DesktopSettings onClose={() => {}} /></LocaleProvider></MemoryRouter>);
  fireEvent.click(screen.getByRole('button', { name: zh.desktopSettings.voice })); return view;
}
async function ready() { await screen.findByText('owned.pt'); await screen.findByDisplayValue('https://before.invalid'); }
const apiKeyLabel = `${zh.desktopSettings.meetingAsrAliyunTitle} ${zh.desktopSettings.meetingAsrApiKey}`;
function action(kind: 'save' | 'download' | 'uninstall') {
  fireEvent.click(screen.getByRole('button', { name: kind === 'save' ? zh.desktopSettings.meetingAsrSave : kind === 'download' ? zh.knowledge.meetingModelDownloadAria('owned.pt') : zh.knowledge.meetingModelUninstallAria('owned.pt') }));
}
function initialRows(kind: string) { if (kind === 'uninstall') mocks.models.mockResolvedValue([{ ...model, downloaded: true, status: 'downloaded', packageState: 'verified' }]); }
beforeEach(() => { localStorage.clear(); localStorage.setItem('xiaok:locale', 'zh'); mocks.models.mockReset().mockResolvedValue([model]); mocks.asr.mockReset().mockResolvedValue(config); mocks.save.mockReset().mockResolvedValue(config); mocks.download.mockReset().mockResolvedValue({ ok: true, model: { ...model, downloaded: true, status: 'downloaded', packageState: 'verified' } }); mocks.uninstall.mockReset().mockResolvedValue({ ok: true, model }); });
afterEach(() => { cleanup(); localStorage.clear(); vi.restoreAllMocks(); });
it('actual save rejection retains credentials in the draft, reports failure, and does not re-read or retry', async () => {
  mocks.save.mockRejectedValueOnce(Error('meeting_mutation_save_failed')); mount(); await ready();
  fireEvent.change(screen.getByLabelText(apiKeyLabel), { target: { value: 'owned-draft-only-key' } }); action('save');
  await screen.findByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'));
  expect(screen.queryByText(zh.desktopSettings.meetingAsrSaved)).toBeNull(); expect(screen.getByLabelText(apiKeyLabel)).toHaveValue('owned-draft-only-key');
  expect(mocks.save).toHaveBeenCalledExactlyOnceWith({ defaultProvider: 'aliyun-asr', aliyun: { apiKey: 'owned-draft-only-key', baseUrl: 'https://before.invalid', model: 'fun-asr' } });
  expect(mocks.asr).toHaveBeenCalledTimes(1); expect(mocks.download).not.toHaveBeenCalled(); expect(mocks.uninstall).not.toHaveBeenCalled();
});
it.each(['download', 'uninstall'] as const)('actual %s rejection stays independent of successful readonly retry', async kind => {
  initialRows(kind); mocks[kind].mockRejectedValueOnce(Error('meeting_model_busy')); mount(); await ready(); action(kind);
  await screen.findByText(zh.knowledge.meetingModelActionFailed('meeting_model_busy'));
  fireEvent.click(screen.getByRole('button', { name: zh.desktopReadonlyRetry })); await waitFor(() => expect(mocks.models).toHaveBeenCalledTimes(2));
  expect(screen.getByText(zh.knowledge.meetingModelActionFailed('meeting_model_busy'))).toBeInTheDocument(); expect(mocks[kind]).toHaveBeenCalledExactlyOnceWith('owned-model'); expect(mocks.save).not.toHaveBeenCalled();
});
it.each(['save', 'download', 'uninstall'] as const)('late %s rejection after locale change uses current locale without repeating work', async kind => {
  initialRows(kind); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); mount(); await ready(); action(kind);
  fireEvent.click(screen.getByRole('button', { name: 'test-switch-locale' })); await waitFor(() => expect(mocks.asr).toHaveBeenCalledTimes(2));
  await act(async () => { held.reject(Error(kind === 'save' ? 'meeting_mutation_save_failed' : 'meeting_model_busy')); });
  const reason = kind === 'save' ? 'meeting_mutation_save_failed' : 'meeting_model_busy';
  const expected = kind === 'save' ? en.knowledge.meetingOnlineAsrSaveFailed(reason) : en.knowledge.meetingModelActionFailed(reason);
  const old = kind === 'save' ? zh.knowledge.meetingOnlineAsrSaveFailed(reason) : zh.knowledge.meetingModelActionFailed(reason);
  expect(await screen.findByText(expected)).toBeInTheDocument(); expect(screen.queryByText(old)).toBeNull(); expect(mocks[kind]).toHaveBeenCalledTimes(1);
});
it('existing save failure relocalizes after locale change without retrying the action', async () => {
  mocks.save.mockRejectedValueOnce(Error('meeting_mutation_save_failed')); mount(); await ready(); action('save');
  await screen.findByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'));
  fireEvent.click(screen.getByRole('button', { name: 'test-switch-locale' }));
  expect(await screen.findByText(en.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'))).toBeInTheDocument(); expect(mocks.save).toHaveBeenCalledTimes(1);
});
it('confirmed save remains successful when the subsequent real readonly owner fails', async () => {
  const acknowledged = { ...config, aliyun: { ...config.aliyun, baseUrl: 'https://confirmed.invalid' } };
  mocks.save.mockResolvedValueOnce(acknowledged); mocks.asr.mockResolvedValueOnce(config).mockRejectedValueOnce(Error('owned-private-read-marker'));
  mount(); await ready(); fireEvent.change(screen.getByLabelText(apiKeyLabel), { target: { value: 'owned-draft-only-key' } }); action('save');
  expect(await screen.findByText(zh.desktopSettings.meetingAsrSaved)).toBeInTheDocument(); expect(screen.getByText(zh.meetingAsrReadonlyUnavailable)).toBeInTheDocument();
  expect(screen.getByLabelText(apiKeyLabel)).toHaveValue(''); expect(screen.getByDisplayValue('https://confirmed.invalid')).toBeInTheDocument();
  expect(screen.queryByText(/owned-private-read-marker/)).toBeNull(); expect(screen.queryByText(/meeting_mutation_save_failed/)).toBeNull(); expect(mocks.save).toHaveBeenCalledTimes(1); expect(mocks.asr).toHaveBeenCalledTimes(2);
});
it('save failure is retained when a later readonly retry fails, without clearing last-good facts', async () => {
  mocks.save.mockRejectedValueOnce(Error('meeting_mutation_save_failed')); mount(); await ready(); action('save'); await screen.findByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'));
  mocks.asr.mockRejectedValueOnce(Error('owned-private-read-marker')); fireEvent.click(screen.getByRole('button', { name: zh.desktopReadonlyRetry }));
  await screen.findByText(zh.meetingAsrReadonlyUnavailable); expect(screen.getByDisplayValue('https://before.invalid')).toBeInTheDocument(); expect(screen.getByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'))).toBeInTheDocument(); expect(mocks.save).toHaveBeenCalledTimes(1);
});
it.each(['save', 'download', 'uninstall'] as const)('unmounted %s success cannot schedule successor reads or overwrite a fresh VoicePane', async kind => {
  initialRows(kind); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); const old = mount(); await ready(); action(kind); old.unmount();
  const fresh = { ...config, aliyun: { ...config.aliyun, baseUrl: 'https://fresh.invalid' } }; mocks.asr.mockResolvedValue(fresh);
  mount(); await screen.findByDisplayValue('https://fresh.invalid'); const modelsBefore = mocks.models.mock.calls.length, asrBefore = mocks.asr.mock.calls.length;
  await act(async () => { held.resolve(kind === 'save' ? { ...config, aliyun: { ...config.aliyun, baseUrl: 'https://stale.invalid' } } : { ok: true, model }); });
  expect(mocks.models).toHaveBeenCalledTimes(modelsBefore); expect(mocks.asr).toHaveBeenCalledTimes(asrBefore); expect(screen.getByDisplayValue('https://fresh.invalid')).toBeInTheDocument(); expect(screen.queryByDisplayValue('https://stale.invalid')).toBeNull(); expect(screen.queryByText(en.desktopSettings.meetingAsrSaved)).toBeNull(); expect(screen.queryByText(zh.desktopSettings.meetingAsrSaved)).toBeNull(); expect(mocks[kind]).toHaveBeenCalledTimes(1);
});
it.each(['save', 'download', 'uninstall'] as const)('unmounted %s rejection stays out of the fresh screen', async kind => {
  initialRows(kind); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); const old = mount(); await ready(); action(kind); old.unmount(); mount(); await ready();
  await act(async () => { held.reject(Error('owned-retired-action-marker')); }); expect(screen.queryByText(/owned-retired-action-marker/)).toBeNull(); expect(mocks[kind]).toHaveBeenCalledTimes(1);
});
it('save admits one action when two clicks occur before React publishes busy state', async () => {
  const held = deferred<unknown>(); mocks.save.mockReturnValueOnce(held.promise); mount(); await ready();
  const button = screen.getByRole('button', { name: zh.desktopSettings.meetingAsrSave });
  act(() => { button.dispatchEvent(new MouseEvent('click', { bubbles: true })); button.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
  const callsBeforeReply = mocks.save.mock.calls.length;
  await act(async () => { held.resolve(config); });
  expect(callsBeforeReply).toBe(1); expect(mocks.save).toHaveBeenCalledTimes(1);
});
it.each(['download', 'uninstall'] as const)('model action %s blocks a different model action in the same JS turn', async kind => {
  const first = kind === 'download' ? model : { ...model, downloaded: true, status: 'downloaded', packageState: 'verified' };
  const other = { ...model, id: 'owned-other', fileName: 'other.pt', path: '/owned/other.pt', downloaded: kind === 'download', status: kind === 'download' ? 'downloaded' : 'not_downloaded', packageState: kind === 'download' ? 'verified' : 'missing' };
  mocks.models.mockResolvedValue([first, other]); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); mount(); await ready();
  const start = screen.getByRole('button', { name: kind === 'download' ? zh.knowledge.meetingModelDownloadAria('owned.pt') : zh.knowledge.meetingModelUninstallAria('owned.pt') });
  const competing = screen.getByRole('button', { name: kind === 'download' ? zh.knowledge.meetingModelUninstallAria('other.pt') : zh.knowledge.meetingModelDownloadAria('other.pt') });
  act(() => { start.dispatchEvent(new MouseEvent('click', { bubbles: true })); competing.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
  const firstCalls = mocks[kind].mock.calls.length, competingCalls = mocks[kind === 'download' ? 'uninstall' : 'download'].mock.calls.length;
  await act(async () => { held.resolve({ ok: true, model: first }); });
  expect(firstCalls).toBe(1); expect(competingCalls).toBe(0); expect(mocks[kind]).toHaveBeenCalledExactlyOnceWith('owned-model');
});

```

## FULL desktop/tests/renderer/runtime-status-readonly-context.test.tsx
```typescript
import {cleanup,render,screen,act,fireEvent,waitFor} from '@testing-library/react';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {KSwarmProvider,useKSwarm} from '../../renderer/src/contexts/KSwarmContext';
import {LocaleProvider,useLocale} from '../../renderer/src/contexts/LocaleContext';
const mocks=vi.hoisted(()=>({read:vi.fn(),unsub:vi.fn(),subscribe:vi.fn(),event:null as null|((value:unknown)=>void),starts:vi.fn()}));
vi.mock('../../renderer/src/hooks/useKSwarmClient',()=>({useKSwarmClient:()=>({})}));
vi.mock('../../renderer/src/shared/desktop',()=>({getDesktopApi:()=>({kswarmGetStatus:mocks.read,onKSwarmStatus:mocks.subscribe,kswarmStart:mocks.starts})}));
const row={running:false,port:4400,pid:null,restartCount:0,lastError:null,terminalDegraded:true,persistenceFailStopCount:2,lastPersistenceFailStop:'owned-failure',future:{kept:['owned']}};
function Probe(){const state=useKSwarm(),{setLocale}=useLocale();return <><output data-testid="facts">{JSON.stringify(state.serviceStatus)}</output><output data-testid="reload-kind">{typeof state.reloadServiceStatus}</output><output data-testid="failed">{String(state.serviceStatusReadFailed)}</output><button onClick={()=>{if(typeof state.reloadServiceStatus==='function')state.reloadServiceStatus();}}>retry</button><button onClick={()=>setLocale('en')}>locale</button></>;}
function mount(){return render(<LocaleProvider><KSwarmProvider><Probe/></KSwarmProvider></LocaleProvider>);}
beforeEach(()=>{localStorage.setItem('xiaok:locale','zh');mocks.read.mockReset().mockResolvedValue(row);mocks.unsub.mockReset();mocks.starts.mockReset();mocks.subscribe.mockReset().mockImplementation((handler:(value:unknown)=>void)=>{mocks.event=handler;return mocks.unsub;});});
afterEach(()=>{cleanup();localStorage.clear();vi.restoreAllMocks();});
it('reports actual initial read failure as unavailable with original null facts',async()=>{mocks.read.mockRejectedValue(Error('private-reader-failure'));mount();await waitFor(()=>expect(screen.getByTestId('failed')).toHaveTextContent('true'));expect(screen.getByTestId('facts')).toHaveTextContent('null');expect(screen.queryByText('private-reader-failure')).toBeNull();expect(mocks.starts).not.toHaveBeenCalled();});
it('does not publish malformed read successes as SDK facts',async()=>{mocks.read.mockResolvedValue({});mount();await waitFor(()=>expect(screen.getByTestId('failed')).toHaveTextContent('true'));expect(screen.getByTestId('facts')).toHaveTextContent('null');});
it('keeps valid newer SDK events when an older initial response arrives late',async()=>{let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));mount();const newer={...row,running:true,lastError:'dynamic workflows owned-known-error'};await act(async()=>mocks.event!(newer));expect(screen.getByTestId('facts')).toHaveTextContent('dynamic workflows owned-known-error');await act(async()=>release(row));expect(screen.getByTestId('facts')).toHaveTextContent('dynamic workflows owned-known-error');expect(mocks.starts).not.toHaveBeenCalled();});
it('retains lastgood facts when latest event is malformed and an older read settles',async()=>{let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));mount();await act(async()=>mocks.event!(row));await act(async()=>mocks.event!({}));await act(async()=>release({...row,running:true}));expect(screen.getByTestId('facts')).toHaveTextContent('owned-failure');expect(screen.getByTestId('facts')).toHaveTextContent('"running":false');expect(screen.getByTestId('failed')).toHaveTextContent('true');});
it('manual retries preserve all8 plus future metadata and coalesce only one successor',async()=>{mount();await waitFor(()=>expect(screen.getByTestId('facts')).toHaveTextContent('owned-failure'));expect(screen.getByTestId('reload-kind')).toHaveTextContent('function');const stateButton=screen.getByRole('button',{name:'retry'});let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));fireEvent.click(stateButton);fireEvent.click(stateButton);fireEvent.click(stateButton);expect(mocks.read).toHaveBeenCalledTimes(2);await act(async()=>release(row));await waitFor(()=>expect(mocks.read).toHaveBeenCalledTimes(3));expect(screen.getByTestId('facts')).toHaveTextContent('"terminalDegraded":true');expect(screen.getByTestId('facts')).toHaveTextContent('"persistenceFailStopCount":2');expect(screen.getByTestId('facts')).toHaveTextContent('"future":{"kept":["owned"]}');expect(mocks.starts).not.toHaveBeenCalled();});
it('preserves original mount-only subscription across locale changes',async()=>{mount();await waitFor(()=>expect(screen.getByTestId('facts')).toHaveTextContent('owned-failure'));fireEvent.click(screen.getByRole('button',{name:'locale'}));expect(mocks.read).toHaveBeenCalledTimes(1);expect(mocks.subscribe).toHaveBeenCalledTimes(1);expect(mocks.unsub).not.toHaveBeenCalled();});
it('unmount removes own subscription and leaves no queued read or late event work',async()=>{let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));const view=mount();view.unmount();await act(async()=>{mocks.event!(row);release(row);});expect(mocks.unsub).toHaveBeenCalledTimes(1);expect(mocks.read).toHaveBeenCalledTimes(1);expect(mocks.starts).not.toHaveBeenCalled();});

```

## FULL desktop/tests/renderer/skill-mutation-bridge.test.ts
```typescript
// Copy to desktop/tests/renderer/skill-mutation-bridge.test.ts.
import { afterEach, expect, it, vi } from 'vitest';
import { api, installSkill, deleteSkill } from '../../renderer/src/api/bridge';
const original = window.xiaokDesktop;
afterEach(() => { window.xiaokDesktop = original; vi.restoreAllMocks(); });
it('market install adapter rejects a business failure so ensureInstalledAndDefault cannot continue', async () => {
  const install = vi.fn().mockResolvedValue({ success: false, message: 'owned_failure' }); window.xiaokDesktop = { ...original, installSkill: install };
  await expect(installSkill('', { skill_key: 'owned', version: '1' })).rejects.toThrow('owned_failure'); expect(install).toHaveBeenCalledExactlyOnceWith('owned');
});
it.each(['installSkill', 'uninstallSkill'] as const)('actual bridge preserves %s rejection', async method => {
  const failure = Error('owned_transport_failure'); window.xiaokDesktop = { ...original, [method]: vi.fn().mockRejectedValue(failure) };
  await expect(api[method]('owned')).rejects.toBe(failure);
});
it('market delete adapter preserves the existing business-failure rejection', async () => {
  window.xiaokDesktop = { ...original, uninstallSkill: vi.fn().mockResolvedValue({ success: false, message: 'owned_failure' }) };
  await expect(deleteSkill('', { skill_key: 'owned', version: '1' })).rejects.toThrow('owned_failure');
});
it('market install adapter retains the successful result and exact slug', async () => {
  const result = { success: true, message: 'owned_ok' }, install = vi.fn().mockResolvedValue(result); window.xiaokDesktop = { ...original, installSkill: install };
  expect(await installSkill('', { skill_key: 'owned', version: '1' })).toBe(result); expect(install).toHaveBeenCalledExactlyOnceWith('owned');
});

```

## FULL desktop/tests/renderer/skills-settings-action-controls.test.tsx
```typescript
// Candidate only. Copy to desktop/tests/renderer/skills-settings-action-controls.test.tsx.
// Real SkillsSettingsContent + real installSkill adapter + real api.installSkill.
// Only unavailable marketplace/default-list boundaries and the preload port are fixtures.
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { SkillsSettingsContent } from '../../renderer/src/components/SkillsSettingsContent';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
import { locales } from '../../renderer/src/locales';
import type { MarketSkill, SkillPackageResponse } from '../../renderer/src/api/bridge';
import { _resetDesktopApiCache } from '../../renderer/src/shared/desktop';
const seams = vi.hoisted(() => ({ search: vi.fn(), imported: vi.fn(), defaults: vi.fn(), replace: vi.fn(), discover: vi.fn() }));
vi.mock('../../renderer/src/api/bridge', async load => {
  const actual = await load<typeof import('../../renderer/src/api/bridge')>();
  return { ...actual, searchMarketSkills: seams.search, importRegistrySkill: seams.imported,
    listDefaultSkills: seams.defaults, replaceDefaultSkills: seams.replace, discoverExternalSkills: seams.discover };
});
const skill: SkillPackageResponse = { skill_key: 'owned-skill', display_name: 'Owned skill', version: '1.0', source: 'official', is_platform: false, scan_status: 'clean' };
const market: MarketSkill = { skill_key: skill.skill_key, display_name: skill.display_name, version: skill.version, registry_slug: skill.skill_key, installed: false, enabled_by_default: false, scan_status: 'clean' };
const original = window.xiaokDesktop;
let port: { listSkills: ReturnType<typeof vi.fn>; getSkillStats: ReturnType<typeof vi.fn>; installSkill: ReturnType<typeof vi.fn>; uninstallSkill: ReturnType<typeof vi.fn>; onSkillsChanged: ReturnType<typeof vi.fn> };
function LocaleButton() { const { setLocale } = useLocale(); return <button onClick={() => setLocale('en')}>test-current-locale</button>; }
function mount() { return render(<MemoryRouter><LocaleProvider><LocaleButton /><SkillsSettingsContent accessToken="owned" /></LocaleProvider></MemoryRouter>); }
async function openMarketplace(locale: 'zh' | 'en' = 'zh') {
  fireEvent.click(screen.getByRole('tab', { name: locales[locale].skills.marketplaceTab }));
  await screen.findByRole('button', { name: 'Owned skill' });
  return screen.getByRole('switch', { name: locales[locale].skills.enabledByDefault + ': Owned skill' });
}
async function beginInstall(locale: 'zh' | 'en' = 'zh') {
  const toggle = await openMarketplace(locale); fireEvent.click(toggle);
  await waitFor(() => expect(port.installSkill).toHaveBeenCalledExactlyOnceWith('owned-skill'));
  return toggle;
}
function held<T>() { let resolve!: (value: T) => void, reject!: (error: unknown) => void; const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; }
beforeEach(() => {
  localStorage.setItem('xiaok:locale', 'zh'); _resetDesktopApiCache();
  seams.search.mockReset().mockResolvedValue([market]); seams.imported.mockReset().mockResolvedValue(skill); seams.defaults.mockReset().mockResolvedValue([]); seams.replace.mockReset().mockResolvedValue([]); seams.discover.mockReset().mockResolvedValue({ dirs: [] });
  port = { listSkills: vi.fn().mockResolvedValue([]), getSkillStats: vi.fn().mockResolvedValue([]), installSkill: vi.fn().mockResolvedValue({ success: true, message: 'owned_ok' }), uninstallSkill: vi.fn(), onSkillsChanged: vi.fn(() => () => {}) };
  window.xiaokDesktop = { ...original, ...port } as typeof window.xiaokDesktop;
});
afterEach(() => { cleanup(); window.xiaokDesktop = original; _resetDesktopApiCache(); localStorage.removeItem('xiaok:locale'); vi.restoreAllMocks(); });
it.each(['zh', 'en'] as const)('actual page %s installation business false does not enable defaults and shows localized action failure', async locale => {
  localStorage.setItem('xiaok:locale', locale); port.installSkill.mockResolvedValue({ success: false, message: 'private_owned_process_failure' }); mount(); await beginInstall(locale);
  expect(await screen.findByText(locales[locale].skills.importFailed)).toBeInTheDocument();
  expect(screen.queryByText('private_owned_process_failure')).toBeNull(); expect(seams.replace).not.toHaveBeenCalled(); expect(port.uninstallSkill).not.toHaveBeenCalled();
  expect(screen.getByRole('switch', { name: locales[locale].skills.enabledByDefault + ': Owned skill' })).not.toBeChecked();
});
it.each(['zh', 'en'] as const)('actual page %s transport rejection is localized and never mutates defaults', async locale => {
  localStorage.setItem('xiaok:locale', locale); port.installSkill.mockRejectedValue(Error('private_owned_transport_failure')); mount(); await beginInstall(locale);
  expect(await screen.findByText(locales[locale].skills.importFailed)).toBeInTheDocument(); expect(screen.queryByText('private_owned_transport_failure')).toBeNull(); expect(seams.replace).not.toHaveBeenCalled();
});
it('success preserves the exact slug/version and performs the existing default enable and catalog refresh once', async () => {
  mount(); await beginInstall(); await waitFor(() => expect(seams.replace).toHaveBeenCalledExactlyOnceWith('owned', [{ skill_key: 'owned-skill', version: '1.0' }]));
  await waitFor(() => expect(port.listSkills).toHaveBeenCalledTimes(2)); expect(seams.imported).toHaveBeenCalledTimes(1); expect(port.uninstallSkill).not.toHaveBeenCalled();
});
it.each(['business-false', 'reject'] as const)('held %s settles with current locale error and no default write', async failure => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); mount(); const toggle = await beginInstall();
  expect(toggle).toBeDisabled(); expect(seams.replace).not.toHaveBeenCalled(); fireEvent.click(screen.getByRole('button', { name: 'test-current-locale' }));
  await act(async () => { if (failure === 'reject') request.reject(Error('private_held_failure')); else request.resolve({ success: false, message: 'private_held_failure' }); });
  expect(await screen.findByText(locales.en.skills.importFailed)).toBeInTheDocument(); expect(screen.queryByText(locales.zh.skills.importFailed)).toBeNull(); expect(seams.replace).not.toHaveBeenCalled(); expect(port.installSkill).toHaveBeenCalledTimes(1);
});
it('an already visible action error follows a locale switch without another mutation or losing facts', async () => {
  port.installSkill.mockRejectedValue(Error('private_owned_failure')); mount(); await beginInstall(); await screen.findByText(locales.zh.skills.importFailed);
  fireEvent.click(screen.getByRole('button', { name: 'test-current-locale' })); expect(await screen.findByText(locales.en.skills.importFailed)).toBeInTheDocument();
  expect(screen.queryByText(locales.zh.skills.importFailed)).toBeNull(); expect(screen.getByRole('button', { name: 'Owned skill' })).toBeInTheDocument(); expect(port.installSkill).toHaveBeenCalledTimes(1); expect(seams.replace).not.toHaveBeenCalled();
});
it('a held success remains authorized across locale change and is not replayed', async () => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); mount(); await beginInstall(); fireEvent.click(screen.getByRole('button', { name: 'test-current-locale' }));
  await act(async () => request.resolve({ success: true, message: 'owned_ok' })); await waitFor(() => expect(seams.replace).toHaveBeenCalledExactlyOnceWith('owned', [{ skill_key: 'owned-skill', version: '1.0' }]));
  expect(port.installSkill).toHaveBeenCalledTimes(1); expect(seams.imported).toHaveBeenCalledTimes(1); expect(screen.queryByText(locales.en.skills.importFailed)).toBeNull();
});
it('busy switch duplicate clicks cannot dispatch a second held installation', async () => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); const view = mount(); const toggle = await beginInstall();
  fireEvent.click(toggle); fireEvent.click(toggle); expect(port.installSkill).toHaveBeenCalledTimes(1); expect(seams.imported).toHaveBeenCalledTimes(1); expect(seams.replace).not.toHaveBeenCalled();
  try { await act(async () => request.resolve({ success: false, message: 'owned_failure' })); await screen.findByText(locales.zh.skills.importFailed); } finally { view.unmount(); }
  expect(seams.replace).not.toHaveBeenCalled();
});
it.each(['success', 'business-false', 'reject'] as const)('unmounted held %s cannot enable defaults or refresh a successor component', async outcome => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); const old = mount(); await beginInstall(); old.unmount();
  const fresh = mount(); await openMarketplace(); const reads = port.listSkills.mock.calls.length, defaults = seams.defaults.mock.calls.length;
  try {
    await act(async () => { if (outcome === 'reject') request.reject(Error('private_unmounted_failure')); else request.resolve({ success: outcome === 'success', message: 'private_unmounted_receipt' }); });
    expect(seams.replace).not.toHaveBeenCalled(); expect(port.listSkills).toHaveBeenCalledTimes(reads); expect(seams.defaults).toHaveBeenCalledTimes(defaults);
    expect(screen.queryByText(locales.zh.skills.importFailed)).toBeNull(); expect(screen.queryByText('private_unmounted_receipt')).toBeNull(); expect(port.installSkill).toHaveBeenCalledTimes(1);
  } finally { fresh.unmount(); }
});

```
