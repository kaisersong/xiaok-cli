
## FULL desktop/tests/renderer/channel-mcp-mutation-ui-followup.test.tsx
```typescript
// UNREVIEWED FOLLOWUP controls. Copy to desktop/tests/renderer with this filename.
// Real DesktopSettings/ChannelsPane/McpPane + real bridge; only window transport is controlled.
// npm run test -- --run tests/renderer/channel-mcp-mutation-ui-followup.test.tsx
import { cleanup, fireEvent, render, screen, waitFor, within, act } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
type Kind='channels'|'mcp';
type Action='create'|'delete'|'toggle';
const cases=[['channels','create'],['channels','delete'],['channels','toggle'],['mcp','create'],['mcp','delete']]as const;
const channel={id:'owned',type:'telegram',name:'Owned channel',enabled:true,createdAt:0,updatedAt:0};
const install={id:'owned',name:'Owned MCP',source:'local',command:'owned-command',args:['--owned'],enabled:true,createdAt:0};
const endpoint={listChannels:vi.fn(),listMCPInstalls:vi.fn(),createChannel:vi.fn(),deleteChannel:vi.fn(),updateChannel:vi.fn(),testChannel:vi.fn(),createMCPInstall:vi.fn(),deleteMCPInstall:vi.fn()};
let previous:typeof window.xiaokDesktop;
function deferred<T>(){
 let complete!:(value:T)=>void,reject!:(error:unknown)=>void,settled=false;
 const promise=new Promise<T>((yes,no)=>{complete=yes;reject=no;});
 return {promise,resolve:(value:T)=>{settled=true;complete(value);},reject:(error:unknown)=>{settled=true;reject(error);},get settled(){return settled;}};
}
function LocaleSwitch(){const {setLocale}=useLocale();return <button onClick={()=>setLocale('en')}>followup-locale</button>;}
beforeEach(()=>{
 previous=window.xiaokDesktop;localStorage.setItem('xiaok:locale','zh');for(const mock of Object.values(endpoint))mock.mockReset();
 endpoint.listChannels.mockResolvedValue([channel]);endpoint.listMCPInstalls.mockResolvedValue([install]);
 window.xiaokDesktop={...previous,...endpoint,listPluginMcpServers:async()=>[],listPluginDependencyStatuses:async()=>[],getServiceStatus:async()=>({services:[]}),getSkillDebugConfig:async()=>({enabled:false}),getKswarmConfig:async()=>({maxConcurrentTasks:3})}as never;
 vi.spyOn(window,'confirm').mockReturnValue(true);vi.spyOn(window,'alert').mockImplementation(()=>{});
});
afterEach(()=>{cleanup();window.xiaokDesktop=previous;localStorage.removeItem('xiaok:locale');vi.restoreAllMocks();vi.useRealTimers();});
function read(kind:Kind){return kind==='channels'?endpoint.listChannels:endpoint.listMCPInstalls;}
function action(kind:Kind,name:Action){return kind==='channels'?(name==='create'?endpoint.createChannel:name==='toggle'?endpoint.updateChannel:endpoint.deleteChannel):(name==='create'?endpoint.createMCPInstall:endpoint.deleteMCPInstall);}
function row(name:string){const element=screen.getByText(name).closest('.flex.items-center.justify-between');expect(element).not.toBeNull();return within(element as HTMLElement);}
async function mount(kind:Kind){
 const view=render(<MemoryRouter><LocaleProvider><LocaleSwitch/><DesktopSettings onClose={()=>{}}/></LocaleProvider></MemoryRouter>);
 fireEvent.click(screen.getByRole('button',{name:kind==='channels'?'消息通道':'MCP 服务器'}));await screen.findByText(kind==='channels'?channel.name:install.name);return view;
}
function input(id:string,value:string){const node=document.getElementById(id);expect(node).not.toBeNull();fireEvent.change(node!,{target:{value}});}
function openCreate(kind:Kind){
 fireEvent.click(screen.getByRole('button',{name:kind==='channels'?'添加通道':'添加 MCP 服务器'}));
 if(kind==='channels'){
  input('desktop-channel-name',' Owned new ');input('desktop-channel-type','discord');input('desktop-channel-field-botToken','OWNED_BOT_SECRET');
 }else{input('desktop-mcp-server-name',' Owned new ');input('desktop-mcp-server-command',' owned-command ');input('desktop-mcp-server-args',' --one  two ');}
 return screen.getByRole('button',{name:'创建'});
}
function start(kind:Kind,name:Action){
 const button=name==='create'?openCreate(kind):name==='toggle'?row(channel.name).getByRole('button',{name:'启用中'}):row(kind==='channels'?channel.name:install.name).getAllByRole('button').at(-1)!;
 fireEvent.click(button);return button;
}
function ack(kind:Kind,name:Action){return name==='delete'?undefined:name==='toggle'?{...channel,enabled:false}:kind==='channels'?{...channel,id:'discord',type:'discord',name:'Owned new'}:{...install,id:'created',name:'Owned new'};}
async function finish<T>(held:ReturnType<typeof deferred<T>>,value:T){await act(async()=>{held.resolve(value);await held.promise;});}
function factsVisible(kind:Kind){expect(screen.getByText(kind==='channels'?channel.name:install.name)).toBeInTheDocument();}
function assertOriginalArgs(kind:Kind,name:Action){
 const expected=name==='delete'?['owned']:name==='toggle'?['owned',{enabled:false}]:kind==='channels'?[{type:'discord',name:'Owned new',botToken:'OWNED_BOT_SECRET'}]:[{name:'Owned new',source:'npm',command:'owned-command',args:['--one','two']}];
 expect(action(kind,name)).toHaveBeenCalledExactlyOnceWith(...expected);
}
it.each(cases)('%s/%s held action retains form/facts and does not refresh before actual ACK',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);const reads=read(kind).mock.calls.length;
 try{start(kind,name);assertOriginalArgs(kind,name);await act(async()=>{await Promise.resolve();});factsVisible(kind);expect(read(kind)).toHaveBeenCalledTimes(reads);
  if(name==='create')expect(document.getElementById(kind==='channels'?'desktop-channel-name':'desktop-mcp-server-name')).toHaveValue(' Owned new ');
  await finish(held,ack(kind,name));await waitFor(()=>expect(read(kind).mock.calls.length).toBeGreaterThan(reads));
 }finally{if(!held.settled)await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s repeated click during a held action cannot issue duplicate mutations',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);
 try{const button=start(kind,name);fireEvent.click(button);expect(action(kind,name)).toHaveBeenCalledTimes(1);factsVisible(kind);}finally{await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s late ACK after unmount cannot restart the readonly owner',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);const view=await mount(kind);start(kind,name);const reads=read(kind).mock.calls.length;view.unmount();
 await finish(held,ack(kind,name));expect(read(kind)).toHaveBeenCalledTimes(reads);expect(window.alert).not.toHaveBeenCalled();expect(action(kind,name)).toHaveBeenCalledTimes(1);
});
it.each(cases)('%s/%s late rejection after unmount cannot publish a global alert',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);const view=await mount(kind);start(kind,name);const reads=read(kind).mock.calls.length;view.unmount();
 await act(async()=>{held.reject(Error('OWNED_EXPIRED_ACTION'));await held.promise.catch(()=>{});});expect(window.alert).not.toHaveBeenCalled();expect(read(kind)).toHaveBeenCalledTimes(reads);
});
it.each(cases)('%s/%s old locale ACK cannot refresh the new lifetime or close/reset its draft',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);
 try{start(kind,name);fireEvent.click(screen.getByRole('button',{name:'followup-locale'}));await waitFor(()=>expect(read(kind)).toHaveBeenCalledTimes(2));const reads=read(kind).mock.calls.length;
  if(name==='create')input(kind==='channels'?'desktop-channel-name':'desktop-mcp-server-name','Current English draft');
  await finish(held,ack(kind,name));expect(read(kind)).toHaveBeenCalledTimes(reads);factsVisible(kind);
  if(name==='create')expect(document.getElementById(kind==='channels'?'desktop-channel-name':'desktop-mcp-server-name')).toHaveValue('Current English draft');
 }finally{if(!held.settled)await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s old locale failure cannot publish errors in the new lifetime',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);start(kind,name);fireEvent.click(screen.getByRole('button',{name:'followup-locale'}));await waitFor(()=>expect(read(kind)).toHaveBeenCalledTimes(2));
 await act(async()=>{held.reject(Error('OWNED_EXPIRED_ACTION'));await held.promise.catch(()=>{});});expect(window.alert).not.toHaveBeenCalled();factsVisible(kind);
});
it.each(cases)('%s/%s successful ACK followed by readonly failure keeps last-good and never resends',async(kind,name)=>{
 const held=deferred<unknown>();action(kind,name).mockReturnValue(held.promise);await mount(kind);
 try{start(kind,name);read(kind).mockRejectedValue(Error('OWNED_READ_AFTER_ACK'));await finish(held,ack(kind,name));
  expect(await screen.findByText(kind==='channels'?'无法读取消息通道':'无法读取 MCP 安装列表')).toBeInTheDocument();factsVisible(kind);assertOriginalArgs(kind,name);expect(window.alert).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button',{name:'重新读取'}));await waitFor(()=>expect(read(kind).mock.calls.length).toBeGreaterThanOrEqual(3));factsVisible(kind);assertOriginalArgs(kind,name);
 }finally{if(!held.settled)await finish(held,ack(kind,name));}
});
it.each(cases)('%s/%s rejected action keeps last-good, does not refresh, and manual read cannot clear/resend it',async(kind,name)=>{
 const failure=Error('OWNED_ACTION_FAILURE');action(kind,name).mockRejectedValue(failure);await mount(kind);const reads=read(kind).mock.calls.length;start(kind,name);
 await waitFor(()=>expect(window.alert).toHaveBeenCalledTimes(1));factsVisible(kind);expect(read(kind)).toHaveBeenCalledTimes(reads);assertOriginalArgs(kind,name);
 read(kind).mockRejectedValue(Error('OWNED_READ_FAILURE'));fireEvent.click(screen.getByRole('button',{name:'重新读取'}));expect(await screen.findByText(kind==='channels'?'无法读取消息通道':'无法读取 MCP 安装列表')).toBeInTheDocument();factsVisible(kind);assertOriginalArgs(kind,name);expect(window.alert).toHaveBeenCalledTimes(1);
});
it('Channel toggle has a held per-row action owner and repeated clicks cannot duplicate edits',async()=>{
 const held=deferred<unknown>();endpoint.updateChannel.mockReturnValue(held.promise);await mount('channels');
 try{const button=row(channel.name).getByRole('button',{name:'启用中'});fireEvent.click(button);fireEvent.click(button);expect(endpoint.updateChannel).toHaveBeenCalledExactlyOnceWith('owned',{enabled:false});factsVisible('channels');expect(endpoint.listChannels).toHaveBeenCalledTimes(1);}finally{await finish(held,{...channel,enabled:false});}
});
it('Channel tests on different rows retain independent busy states when the first one settles',async()=>{
 const other={...channel,id:'second',name:'Owned second channel'};endpoint.listChannels.mockResolvedValue([channel,other]);const first=deferred<unknown>(),second=deferred<unknown>();
 endpoint.testChannel.mockImplementation((id:string)=>id==='owned'?first.promise:second.promise);await mount('channels');
 try{fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));fireEvent.click(row(other.name).getByRole('button',{name:'测试'}));await finish(first,{success:true,latencyMs:1});
  const remaining=row(other.name).getByRole('button',{name:'测试'});expect(remaining).toBeDisabled();fireEvent.click(remaining);expect(endpoint.testChannel).toHaveBeenCalledTimes(2);
 }finally{if(!first.settled)await finish(first,{success:true,latencyMs:1});await finish(second,{success:true,latencyMs:2});}
});
it.each(['resolve','reject']as const)('held Channel test %s after locale change cannot publish an obsolete action fact',async mode=>{
 const held=deferred<unknown>();endpoint.testChannel.mockReturnValue(held.promise);await mount('channels');fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));fireEvent.click(screen.getByRole('button',{name:'followup-locale'}));await waitFor(()=>expect(endpoint.listChannels).toHaveBeenCalledTimes(2));
 await act(async()=>{if(mode==='resolve')held.resolve({success:false,error:'OWNED_EXPIRED_TEST'});else held.reject(Error('OWNED_EXPIRED_TEST'));await held.promise.catch(()=>{});});
 expect(screen.queryByText('OWNED_EXPIRED_TEST')).toBeNull();expect(screen.queryByText('Connection failed')).toBeNull();factsVisible('channels');expect(endpoint.testChannel).toHaveBeenCalledExactlyOnceWith('owned');
});
it('Channel action error and readonly last-good stay independent; a newer successful action clears only the old action error',async()=>{
 endpoint.testChannel.mockResolvedValueOnce({success:false,error:'OWNED_CURRENT_TEST_FAILURE'}).mockResolvedValueOnce({success:true,latencyMs:7});await mount('channels');fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));await screen.findByText('OWNED_CURRENT_TEST_FAILURE');
 endpoint.listChannels.mockRejectedValue(Error('OWNED_READ_FAILURE'));fireEvent.click(screen.getByRole('button',{name:'重新读取'}));await screen.findByText('无法读取消息通道');expect(screen.getByText('OWNED_CURRENT_TEST_FAILURE')).toBeInTheDocument();factsVisible('channels');expect(endpoint.testChannel).toHaveBeenCalledTimes(1);
 fireEvent.click(row(channel.name).getByRole('button',{name:'测试'}));await screen.findByText('连接成功，延迟 7ms');expect(screen.queryByText('OWNED_CURRENT_TEST_FAILURE')).toBeNull();expect(screen.getByText('无法读取消息通道')).toBeInTheDocument();factsVisible('channels');expect(endpoint.testChannel).toHaveBeenCalledTimes(2);
});
it('held MCP mutation does not acquire or duplicate the two-second readonly poll owner',async()=>{
 const held=deferred<unknown>();endpoint.deleteMCPInstall.mockReturnValue(held.promise);vi.useFakeTimers();
 const view=render(<MemoryRouter><LocaleProvider><LocaleSwitch/><DesktopSettings onClose={()=>{}}/></LocaleProvider></MemoryRouter>);
 fireEvent.click(screen.getByRole('button',{name:'MCP 服务器'}));await act(async()=>{await Promise.resolve();});factsVisible('mcp');start('mcp','delete');
 try{await act(async()=>{await vi.advanceTimersByTimeAsync(6_100);});expect(endpoint.listMCPInstalls).toHaveBeenCalledTimes(4);expect(endpoint.deleteMCPInstall).toHaveBeenCalledExactlyOnceWith('owned');factsVisible('mcp');view.unmount();const reads=endpoint.listMCPInstalls.mock.calls.length;
  await finish(held,undefined);await act(async()=>{await vi.advanceTimersByTimeAsync(4_100);});expect(endpoint.listMCPInstalls).toHaveBeenCalledTimes(reads);
 }finally{if(!held.settled)await finish(held,undefined);vi.useRealTimers();}
});

```

## FULL desktop/tests/renderer/channel-mcp-mutation-ui.test.tsx
```typescript
// UNREVIEWED RED CANDIDATE: desktop/tests/renderer/channel-mcp-mutation-ui.test.tsx
// cd desktop && npm run test -- --run tests/renderer/channel-mcp-mutation-ui.test.tsx
// Uses real DesktopSettings + real bridge. Only window transport endpoint is replaced.
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider } from '../../renderer/src/contexts/LocaleContext';
const channels=[{id:'owned',type:'telegram',name:'Owned channel',enabled:true,createdAt:0,updatedAt:0}];
const installs=[{id:'owned',name:'Owned MCP',source:'local',command:'owned-command',enabled:true,createdAt:0}];
let previous:typeof window.xiaokDesktop;
const endpoint={listChannels:vi.fn(),listMCPInstalls:vi.fn(),testChannel:vi.fn(),deleteChannel:vi.fn(),deleteMCPInstall:vi.fn(),updateChannel:vi.fn()};
beforeEach(()=>{
 previous=window.xiaokDesktop;localStorage.setItem('xiaok:locale','zh');
 for(const mock of Object.values(endpoint))mock.mockReset();endpoint.listChannels.mockResolvedValue(channels);endpoint.listMCPInstalls.mockResolvedValue(installs);
 window.xiaokDesktop={...previous,...endpoint,listPluginMcpServers:async()=>[],listPluginDependencyStatuses:async()=>[],getServiceStatus:async()=>({services:[]}),getSkillDebugConfig:async()=>({enabled:false}),getKswarmConfig:async()=>({maxConcurrentTasks:3})}as never;
});
afterEach(()=>{cleanup();window.xiaokDesktop=previous;localStorage.removeItem('xiaok:locale');vi.restoreAllMocks();});
async function mount(kind:'channels'|'mcp'){
 render(<MemoryRouter><LocaleProvider><DesktopSettings onClose={()=>{}} /></LocaleProvider></MemoryRouter>);
 fireEvent.click(screen.getByRole('button',{name:kind==='channels'?'消息通道':'MCP 服务器'}));await screen.findByText(kind==='channels'?'Owned channel':'Owned MCP');
}
function deleteButton(kind:'channels'|'mcp'){
 // Current production has no accessible delete label. Locate the actual row's last button;
 // proposed patch adds locale aria-label without making the RED depend on that change.
 const name=screen.getByText(kind==='channels'?'Owned channel':'Owned MCP');const card=name.closest('.flex.items-center.justify-between');expect(card).not.toBeNull();
 const buttons=within(card as HTMLElement).getAllByRole('button');return buttons[buttons.length-1]!;
}
it.each(['channels','mcp']as const)('%s canceled delete does not cross the real bridge and keeps last-good facts',async kind=>{
 const confirm=vi.spyOn(window,'confirm').mockReturnValue(false);await mount(kind);fireEvent.click(deleteButton(kind));
 expect(confirm).toHaveBeenCalledTimes(1);expect(kind==='channels'?endpoint.deleteChannel:endpoint.deleteMCPInstall).not.toHaveBeenCalled();expect(screen.getByText(kind==='channels'?'Owned channel':'Owned MCP')).toBeInTheDocument();
});
it.each(['channels','mcp']as const)('%s confirmed delete routes original id and only refreshes after ACK',async kind=>{
 vi.spyOn(window,'confirm').mockReturnValue(true);const remove=kind==='channels'?endpoint.deleteChannel:endpoint.deleteMCPInstall;remove.mockResolvedValue(undefined);await mount(kind);fireEvent.click(deleteButton(kind));
 await waitFor(()=>expect(remove).toHaveBeenCalledExactlyOnceWith('owned'));await waitFor(()=>expect(kind==='channels'?endpoint.listChannels:endpoint.listMCPInstalls).toHaveBeenCalledTimes(2));
});
it.each(['channels','mcp']as const)('%s rejected delete preserves last-good and shows localized failure without secret echo',async kind=>{
 vi.spyOn(window,'confirm').mockReturnValue(true);const alert=vi.spyOn(window,'alert').mockImplementation(()=>{}),remove=kind==='channels'?endpoint.deleteChannel:endpoint.deleteMCPInstall;remove.mockRejectedValue(Error('OWNED_PRIVATE_SECRET'));await mount(kind);fireEvent.click(deleteButton(kind));
 await waitFor(()=>expect(alert).toHaveBeenCalledExactlyOnceWith(kind==='channels'?'通道操作失败，请重试':'MCP 配置操作失败，请重试'));expect(screen.getByText(kind==='channels'?'Owned channel':'Owned MCP')).toBeInTheDocument();expect(kind==='channels'?endpoint.listChannels:endpoint.listMCPInstalls).toHaveBeenCalledTimes(1);
});
it('test rejection crosses the actual bridge, stays independent of readonly retry, and never echoes secrets',async()=>{
 endpoint.testChannel.mockRejectedValue(Error('OWNED_PRIVATE_SECRET'));await mount('channels');fireEvent.click(screen.getByRole('button',{name:'测试'}));expect(await screen.findByText('连接失败')).toBeInTheDocument();expect(screen.queryByText('OWNED_PRIVATE_SECRET')).toBeNull();
 fireEvent.click(screen.getByRole('button',{name:'重新读取'}));await waitFor(()=>expect(endpoint.listChannels).toHaveBeenCalledTimes(2));expect(screen.getByText('连接失败')).toBeInTheDocument();expect(endpoint.testChannel).toHaveBeenCalledExactlyOnceWith('owned');
});

```

## FULL desktop/tests/renderer/meeting-voicepane-actions.test.tsx
```typescript
// Actual DesktopSettings mounts its private VoicePane; only external preload
// dependency is replaced. These page tests do not claim real IPC/native proof.
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { DesktopSettings } from '../../renderer/src/components/DesktopSettings';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
import { zh } from '../../renderer/src/locales/zh';
import { en } from '../../renderer/src/locales/en';
const mocks = vi.hoisted(() => ({ models: vi.fn(), asr: vi.fn(), save: vi.fn(), download: vi.fn(), uninstall: vi.fn() }));
vi.mock('../../renderer/src/shared/desktop', () => ({ getDesktopApi: () => ({ meetingListModels: mocks.models, meetingGetAsrConfig: mocks.asr, meetingSaveAsrConfig: mocks.save, meetingDownloadModel: mocks.download, meetingUninstallModel: mocks.uninstall }) }));
const model = { id: 'owned-model', fileName: 'owned.pt', sizeBytes: 10, sizeLabel: '10 B', cacheDir: '/owned', path: '/owned/owned.pt', downloaded: false, status: 'not_downloaded', capability: 'asr', engineId: 'whisper', packageId: 'owned', packageType: 'single-file', packageState: 'missing', manifestTrusted: true, runtimeAutoDownloadAllowed: false };
const config = { defaultProvider: 'aliyun-asr', volcengine: { configured: false, appKeyConfigured: false, accessKeyConfigured: false, endpoint: 'wss://before.invalid', resourceId: 'owned-resource' }, aliyun: { configured: true, apiKeyConfigured: true, baseUrl: 'https://before.invalid', model: 'fun-asr' } };
function deferred<T>() { let resolve!: (value: T) => void, reject!: (value: unknown) => void; const promise = new Promise<T>((r, j) => { resolve = r; reject = j; }); return { promise, resolve, reject }; }
function LocaleButton() { const { setLocale } = useLocale(); return <button onClick={() => setLocale('en')}>test-switch-locale</button>; }
function mount() {
  const view = render(<MemoryRouter><LocaleProvider><LocaleButton /><DesktopSettings onClose={() => {}} /></LocaleProvider></MemoryRouter>);
  fireEvent.click(screen.getByRole('button', { name: zh.desktopSettings.voice })); return view;
}
async function ready() { await screen.findByText('owned.pt'); await screen.findByDisplayValue('https://before.invalid'); }
const apiKeyLabel = `${zh.desktopSettings.meetingAsrAliyunTitle} ${zh.desktopSettings.meetingAsrApiKey}`;
function action(kind: 'save' | 'download' | 'uninstall') {
  fireEvent.click(screen.getByRole('button', { name: kind === 'save' ? zh.desktopSettings.meetingAsrSave : kind === 'download' ? zh.knowledge.meetingModelDownloadAria('owned.pt') : zh.knowledge.meetingModelUninstallAria('owned.pt') }));
}
function initialRows(kind: string) { if (kind === 'uninstall') mocks.models.mockResolvedValue([{ ...model, downloaded: true, status: 'downloaded', packageState: 'verified' }]); }
beforeEach(() => { localStorage.clear(); localStorage.setItem('xiaok:locale', 'zh'); mocks.models.mockReset().mockResolvedValue([model]); mocks.asr.mockReset().mockResolvedValue(config); mocks.save.mockReset().mockResolvedValue(config); mocks.download.mockReset().mockResolvedValue({ ok: true, model: { ...model, downloaded: true, status: 'downloaded', packageState: 'verified' } }); mocks.uninstall.mockReset().mockResolvedValue({ ok: true, model }); });
afterEach(() => { cleanup(); localStorage.clear(); vi.restoreAllMocks(); });
it('actual save rejection retains credentials in the draft, reports failure, and does not re-read or retry', async () => {
  mocks.save.mockRejectedValueOnce(Error('meeting_mutation_save_failed')); mount(); await ready();
  fireEvent.change(screen.getByLabelText(apiKeyLabel), { target: { value: 'owned-draft-only-key' } }); action('save');
  await screen.findByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'));
  expect(screen.queryByText(zh.desktopSettings.meetingAsrSaved)).toBeNull(); expect(screen.getByLabelText(apiKeyLabel)).toHaveValue('owned-draft-only-key');
  expect(mocks.save).toHaveBeenCalledExactlyOnceWith({ defaultProvider: 'aliyun-asr', aliyun: { apiKey: 'owned-draft-only-key', baseUrl: 'https://before.invalid', model: 'fun-asr' } });
  expect(mocks.asr).toHaveBeenCalledTimes(1); expect(mocks.download).not.toHaveBeenCalled(); expect(mocks.uninstall).not.toHaveBeenCalled();
});
it.each(['download', 'uninstall'] as const)('actual %s rejection stays independent of successful readonly retry', async kind => {
  initialRows(kind); mocks[kind].mockRejectedValueOnce(Error('meeting_model_busy')); mount(); await ready(); action(kind);
  await screen.findByText(zh.knowledge.meetingModelActionFailed('meeting_model_busy'));
  fireEvent.click(screen.getByRole('button', { name: zh.desktopReadonlyRetry })); await waitFor(() => expect(mocks.models).toHaveBeenCalledTimes(2));
  expect(screen.getByText(zh.knowledge.meetingModelActionFailed('meeting_model_busy'))).toBeInTheDocument(); expect(mocks[kind]).toHaveBeenCalledExactlyOnceWith('owned-model'); expect(mocks.save).not.toHaveBeenCalled();
});
it.each(['save', 'download', 'uninstall'] as const)('late %s rejection after locale change uses current locale without repeating work', async kind => {
  initialRows(kind); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); mount(); await ready(); action(kind);
  fireEvent.click(screen.getByRole('button', { name: 'test-switch-locale' })); await waitFor(() => expect(mocks.asr).toHaveBeenCalledTimes(2));
  await act(async () => { held.reject(Error(kind === 'save' ? 'meeting_mutation_save_failed' : 'meeting_model_busy')); });
  const reason = kind === 'save' ? 'meeting_mutation_save_failed' : 'meeting_model_busy';
  const expected = kind === 'save' ? en.knowledge.meetingOnlineAsrSaveFailed(reason) : en.knowledge.meetingModelActionFailed(reason);
  const old = kind === 'save' ? zh.knowledge.meetingOnlineAsrSaveFailed(reason) : zh.knowledge.meetingModelActionFailed(reason);
  expect(await screen.findByText(expected)).toBeInTheDocument(); expect(screen.queryByText(old)).toBeNull(); expect(mocks[kind]).toHaveBeenCalledTimes(1);
});
it('existing save failure relocalizes after locale change without retrying the action', async () => {
  mocks.save.mockRejectedValueOnce(Error('meeting_mutation_save_failed')); mount(); await ready(); action('save');
  await screen.findByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'));
  fireEvent.click(screen.getByRole('button', { name: 'test-switch-locale' }));
  expect(await screen.findByText(en.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'))).toBeInTheDocument(); expect(mocks.save).toHaveBeenCalledTimes(1);
});
it('confirmed save remains successful when the subsequent real readonly owner fails', async () => {
  const acknowledged = { ...config, aliyun: { ...config.aliyun, baseUrl: 'https://confirmed.invalid' } };
  mocks.save.mockResolvedValueOnce(acknowledged); mocks.asr.mockResolvedValueOnce(config).mockRejectedValueOnce(Error('owned-private-read-marker'));
  mount(); await ready(); fireEvent.change(screen.getByLabelText(apiKeyLabel), { target: { value: 'owned-draft-only-key' } }); action('save');
  expect(await screen.findByText(zh.desktopSettings.meetingAsrSaved)).toBeInTheDocument(); expect(screen.getByText(zh.meetingAsrReadonlyUnavailable)).toBeInTheDocument();
  expect(screen.getByLabelText(apiKeyLabel)).toHaveValue(''); expect(screen.getByDisplayValue('https://confirmed.invalid')).toBeInTheDocument();
  expect(screen.queryByText(/owned-private-read-marker/)).toBeNull(); expect(screen.queryByText(/meeting_mutation_save_failed/)).toBeNull(); expect(mocks.save).toHaveBeenCalledTimes(1); expect(mocks.asr).toHaveBeenCalledTimes(2);
});
it('save failure is retained when a later readonly retry fails, without clearing last-good facts', async () => {
  mocks.save.mockRejectedValueOnce(Error('meeting_mutation_save_failed')); mount(); await ready(); action('save'); await screen.findByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'));
  mocks.asr.mockRejectedValueOnce(Error('owned-private-read-marker')); fireEvent.click(screen.getByRole('button', { name: zh.desktopReadonlyRetry }));
  await screen.findByText(zh.meetingAsrReadonlyUnavailable); expect(screen.getByDisplayValue('https://before.invalid')).toBeInTheDocument(); expect(screen.getByText(zh.knowledge.meetingOnlineAsrSaveFailed('meeting_mutation_save_failed'))).toBeInTheDocument(); expect(mocks.save).toHaveBeenCalledTimes(1);
});
it.each(['save', 'download', 'uninstall'] as const)('unmounted %s success cannot schedule successor reads or overwrite a fresh VoicePane', async kind => {
  initialRows(kind); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); const old = mount(); await ready(); action(kind); old.unmount();
  const fresh = { ...config, aliyun: { ...config.aliyun, baseUrl: 'https://fresh.invalid' } }; mocks.asr.mockResolvedValue(fresh);
  mount(); await screen.findByDisplayValue('https://fresh.invalid'); const modelsBefore = mocks.models.mock.calls.length, asrBefore = mocks.asr.mock.calls.length;
  await act(async () => { held.resolve(kind === 'save' ? { ...config, aliyun: { ...config.aliyun, baseUrl: 'https://stale.invalid' } } : { ok: true, model }); });
  expect(mocks.models).toHaveBeenCalledTimes(modelsBefore); expect(mocks.asr).toHaveBeenCalledTimes(asrBefore); expect(screen.getByDisplayValue('https://fresh.invalid')).toBeInTheDocument(); expect(screen.queryByDisplayValue('https://stale.invalid')).toBeNull(); expect(screen.queryByText(en.desktopSettings.meetingAsrSaved)).toBeNull(); expect(screen.queryByText(zh.desktopSettings.meetingAsrSaved)).toBeNull(); expect(mocks[kind]).toHaveBeenCalledTimes(1);
});
it.each(['save', 'download', 'uninstall'] as const)('unmounted %s rejection stays out of the fresh screen', async kind => {
  initialRows(kind); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); const old = mount(); await ready(); action(kind); old.unmount(); mount(); await ready();
  await act(async () => { held.reject(Error('owned-retired-action-marker')); }); expect(screen.queryByText(/owned-retired-action-marker/)).toBeNull(); expect(mocks[kind]).toHaveBeenCalledTimes(1);
});
it('save admits one action when two clicks occur before React publishes busy state', async () => {
  const held = deferred<unknown>(); mocks.save.mockReturnValueOnce(held.promise); mount(); await ready();
  const button = screen.getByRole('button', { name: zh.desktopSettings.meetingAsrSave });
  act(() => { button.dispatchEvent(new MouseEvent('click', { bubbles: true })); button.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
  const callsBeforeReply = mocks.save.mock.calls.length;
  await act(async () => { held.resolve(config); });
  expect(callsBeforeReply).toBe(1); expect(mocks.save).toHaveBeenCalledTimes(1);
});
it.each(['download', 'uninstall'] as const)('model action %s blocks a different model action in the same JS turn', async kind => {
  const first = kind === 'download' ? model : { ...model, downloaded: true, status: 'downloaded', packageState: 'verified' };
  const other = { ...model, id: 'owned-other', fileName: 'other.pt', path: '/owned/other.pt', downloaded: kind === 'download', status: kind === 'download' ? 'downloaded' : 'not_downloaded', packageState: kind === 'download' ? 'verified' : 'missing' };
  mocks.models.mockResolvedValue([first, other]); const held = deferred<unknown>(); mocks[kind].mockReturnValueOnce(held.promise); mount(); await ready();
  const start = screen.getByRole('button', { name: kind === 'download' ? zh.knowledge.meetingModelDownloadAria('owned.pt') : zh.knowledge.meetingModelUninstallAria('owned.pt') });
  const competing = screen.getByRole('button', { name: kind === 'download' ? zh.knowledge.meetingModelUninstallAria('other.pt') : zh.knowledge.meetingModelDownloadAria('other.pt') });
  act(() => { start.dispatchEvent(new MouseEvent('click', { bubbles: true })); competing.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
  const firstCalls = mocks[kind].mock.calls.length, competingCalls = mocks[kind === 'download' ? 'uninstall' : 'download'].mock.calls.length;
  await act(async () => { held.resolve({ ok: true, model: first }); });
  expect(firstCalls).toBe(1); expect(competingCalls).toBe(0); expect(mocks[kind]).toHaveBeenCalledExactlyOnceWith('owned-model');
});

```

## FULL desktop/tests/renderer/runtime-status-readonly-context.test.tsx
```typescript
import {cleanup,render,screen,act,fireEvent,waitFor} from '@testing-library/react';
import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {KSwarmProvider,useKSwarm} from '../../renderer/src/contexts/KSwarmContext';
import {LocaleProvider,useLocale} from '../../renderer/src/contexts/LocaleContext';
const mocks=vi.hoisted(()=>({read:vi.fn(),unsub:vi.fn(),subscribe:vi.fn(),event:null as null|((value:unknown)=>void),starts:vi.fn()}));
vi.mock('../../renderer/src/hooks/useKSwarmClient',()=>({useKSwarmClient:()=>({})}));
vi.mock('../../renderer/src/shared/desktop',()=>({getDesktopApi:()=>({kswarmGetStatus:mocks.read,onKSwarmStatus:mocks.subscribe,kswarmStart:mocks.starts})}));
const row={running:false,port:4400,pid:null,restartCount:0,lastError:null,terminalDegraded:true,persistenceFailStopCount:2,lastPersistenceFailStop:'owned-failure',future:{kept:['owned']}};
function Probe(){const state=useKSwarm(),{setLocale}=useLocale();return <><output data-testid="facts">{JSON.stringify(state.serviceStatus)}</output><output data-testid="reload-kind">{typeof state.reloadServiceStatus}</output><output data-testid="failed">{String(state.serviceStatusReadFailed)}</output><button onClick={()=>{if(typeof state.reloadServiceStatus==='function')state.reloadServiceStatus();}}>retry</button><button onClick={()=>setLocale('en')}>locale</button></>;}
function mount(){return render(<LocaleProvider><KSwarmProvider><Probe/></KSwarmProvider></LocaleProvider>);}
beforeEach(()=>{localStorage.setItem('xiaok:locale','zh');mocks.read.mockReset().mockResolvedValue(row);mocks.unsub.mockReset();mocks.starts.mockReset();mocks.subscribe.mockReset().mockImplementation((handler:(value:unknown)=>void)=>{mocks.event=handler;return mocks.unsub;});});
afterEach(()=>{cleanup();localStorage.clear();vi.restoreAllMocks();});
it('reports actual initial read failure as unavailable with original null facts',async()=>{mocks.read.mockRejectedValue(Error('private-reader-failure'));mount();await waitFor(()=>expect(screen.getByTestId('failed')).toHaveTextContent('true'));expect(screen.getByTestId('facts')).toHaveTextContent('null');expect(screen.queryByText('private-reader-failure')).toBeNull();expect(mocks.starts).not.toHaveBeenCalled();});
it('does not publish malformed read successes as SDK facts',async()=>{mocks.read.mockResolvedValue({});mount();await waitFor(()=>expect(screen.getByTestId('failed')).toHaveTextContent('true'));expect(screen.getByTestId('facts')).toHaveTextContent('null');});
it('keeps valid newer SDK events when an older initial response arrives late',async()=>{let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));mount();const newer={...row,running:true,lastError:'dynamic workflows owned-known-error'};await act(async()=>mocks.event!(newer));expect(screen.getByTestId('facts')).toHaveTextContent('dynamic workflows owned-known-error');await act(async()=>release(row));expect(screen.getByTestId('facts')).toHaveTextContent('dynamic workflows owned-known-error');expect(mocks.starts).not.toHaveBeenCalled();});
it('retains lastgood facts when latest event is malformed and an older read settles',async()=>{let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));mount();await act(async()=>mocks.event!(row));await act(async()=>mocks.event!({}));await act(async()=>release({...row,running:true}));expect(screen.getByTestId('facts')).toHaveTextContent('owned-failure');expect(screen.getByTestId('facts')).toHaveTextContent('"running":false');expect(screen.getByTestId('failed')).toHaveTextContent('true');});
it('manual retries preserve all8 plus future metadata and coalesce only one successor',async()=>{mount();await waitFor(()=>expect(screen.getByTestId('facts')).toHaveTextContent('owned-failure'));expect(screen.getByTestId('reload-kind')).toHaveTextContent('function');const stateButton=screen.getByRole('button',{name:'retry'});let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));fireEvent.click(stateButton);fireEvent.click(stateButton);fireEvent.click(stateButton);expect(mocks.read).toHaveBeenCalledTimes(2);await act(async()=>release(row));await waitFor(()=>expect(mocks.read).toHaveBeenCalledTimes(3));expect(screen.getByTestId('facts')).toHaveTextContent('"terminalDegraded":true');expect(screen.getByTestId('facts')).toHaveTextContent('"persistenceFailStopCount":2');expect(screen.getByTestId('facts')).toHaveTextContent('"future":{"kept":["owned"]}');expect(mocks.starts).not.toHaveBeenCalled();});
it('preserves original mount-only subscription across locale changes',async()=>{mount();await waitFor(()=>expect(screen.getByTestId('facts')).toHaveTextContent('owned-failure'));fireEvent.click(screen.getByRole('button',{name:'locale'}));expect(mocks.read).toHaveBeenCalledTimes(1);expect(mocks.subscribe).toHaveBeenCalledTimes(1);expect(mocks.unsub).not.toHaveBeenCalled();});
it('unmount removes own subscription and leaves no queued read or late event work',async()=>{let release!:(value:unknown)=>void;mocks.read.mockReturnValueOnce(new Promise(resolve=>{release=resolve}));const view=mount();view.unmount();await act(async()=>{mocks.event!(row);release(row);});expect(mocks.unsub).toHaveBeenCalledTimes(1);expect(mocks.read).toHaveBeenCalledTimes(1);expect(mocks.starts).not.toHaveBeenCalled();});

```

## FULL desktop/tests/renderer/skill-mutation-bridge.test.ts
```typescript
// Copy to desktop/tests/renderer/skill-mutation-bridge.test.ts.
import { afterEach, expect, it, vi } from 'vitest';
import { api, installSkill, deleteSkill } from '../../renderer/src/api/bridge';
const original = window.xiaokDesktop;
afterEach(() => { window.xiaokDesktop = original; vi.restoreAllMocks(); });
it('market install adapter rejects a business failure so ensureInstalledAndDefault cannot continue', async () => {
  const install = vi.fn().mockResolvedValue({ success: false, message: 'owned_failure' }); window.xiaokDesktop = { ...original, installSkill: install };
  await expect(installSkill('', { skill_key: 'owned', version: '1' })).rejects.toThrow('owned_failure'); expect(install).toHaveBeenCalledExactlyOnceWith('owned');
});
it.each(['installSkill', 'uninstallSkill'] as const)('actual bridge preserves %s rejection', async method => {
  const failure = Error('owned_transport_failure'); window.xiaokDesktop = { ...original, [method]: vi.fn().mockRejectedValue(failure) };
  await expect(api[method]('owned')).rejects.toBe(failure);
});
it('market delete adapter preserves the existing business-failure rejection', async () => {
  window.xiaokDesktop = { ...original, uninstallSkill: vi.fn().mockResolvedValue({ success: false, message: 'owned_failure' }) };
  await expect(deleteSkill('', { skill_key: 'owned', version: '1' })).rejects.toThrow('owned_failure');
});
it('market install adapter retains the successful result and exact slug', async () => {
  const result = { success: true, message: 'owned_ok' }, install = vi.fn().mockResolvedValue(result); window.xiaokDesktop = { ...original, installSkill: install };
  expect(await installSkill('', { skill_key: 'owned', version: '1' })).toBe(result); expect(install).toHaveBeenCalledExactlyOnceWith('owned');
});

```

## FULL desktop/tests/renderer/skills-settings-action-controls.test.tsx
```typescript
// Candidate only. Copy to desktop/tests/renderer/skills-settings-action-controls.test.tsx.
// Real SkillsSettingsContent + real installSkill adapter + real api.installSkill.
// Only unavailable marketplace/default-list boundaries and the preload port are fixtures.
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';
import { SkillsSettingsContent } from '../../renderer/src/components/SkillsSettingsContent';
import { LocaleProvider, useLocale } from '../../renderer/src/contexts/LocaleContext';
import { locales } from '../../renderer/src/locales';
import type { MarketSkill, SkillPackageResponse } from '../../renderer/src/api/bridge';
import { _resetDesktopApiCache } from '../../renderer/src/shared/desktop';
const seams = vi.hoisted(() => ({ search: vi.fn(), imported: vi.fn(), defaults: vi.fn(), replace: vi.fn(), discover: vi.fn() }));
vi.mock('../../renderer/src/api/bridge', async load => {
  const actual = await load<typeof import('../../renderer/src/api/bridge')>();
  return { ...actual, searchMarketSkills: seams.search, importRegistrySkill: seams.imported,
    listDefaultSkills: seams.defaults, replaceDefaultSkills: seams.replace, discoverExternalSkills: seams.discover };
});
const skill: SkillPackageResponse = { skill_key: 'owned-skill', display_name: 'Owned skill', version: '1.0', source: 'official', is_platform: false, scan_status: 'clean' };
const market: MarketSkill = { skill_key: skill.skill_key, display_name: skill.display_name, version: skill.version, registry_slug: skill.skill_key, installed: false, enabled_by_default: false, scan_status: 'clean' };
const original = window.xiaokDesktop;
let port: { listSkills: ReturnType<typeof vi.fn>; getSkillStats: ReturnType<typeof vi.fn>; installSkill: ReturnType<typeof vi.fn>; uninstallSkill: ReturnType<typeof vi.fn>; onSkillsChanged: ReturnType<typeof vi.fn> };
function LocaleButton() { const { setLocale } = useLocale(); return <button onClick={() => setLocale('en')}>test-current-locale</button>; }
function mount() { return render(<MemoryRouter><LocaleProvider><LocaleButton /><SkillsSettingsContent accessToken="owned" /></LocaleProvider></MemoryRouter>); }
async function openMarketplace(locale: 'zh' | 'en' = 'zh') {
  fireEvent.click(screen.getByRole('tab', { name: locales[locale].skills.marketplaceTab }));
  await screen.findByRole('button', { name: 'Owned skill' });
  return screen.getByRole('switch', { name: locales[locale].skills.enabledByDefault + ': Owned skill' });
}
async function beginInstall(locale: 'zh' | 'en' = 'zh') {
  const toggle = await openMarketplace(locale); fireEvent.click(toggle);
  await waitFor(() => expect(port.installSkill).toHaveBeenCalledExactlyOnceWith('owned-skill'));
  return toggle;
}
function held<T>() { let resolve!: (value: T) => void, reject!: (error: unknown) => void; const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; }
beforeEach(() => {
  localStorage.setItem('xiaok:locale', 'zh'); _resetDesktopApiCache();
  seams.search.mockReset().mockResolvedValue([market]); seams.imported.mockReset().mockResolvedValue(skill); seams.defaults.mockReset().mockResolvedValue([]); seams.replace.mockReset().mockResolvedValue([]); seams.discover.mockReset().mockResolvedValue({ dirs: [] });
  port = { listSkills: vi.fn().mockResolvedValue([]), getSkillStats: vi.fn().mockResolvedValue([]), installSkill: vi.fn().mockResolvedValue({ success: true, message: 'owned_ok' }), uninstallSkill: vi.fn(), onSkillsChanged: vi.fn(() => () => {}) };
  window.xiaokDesktop = { ...original, ...port } as typeof window.xiaokDesktop;
});
afterEach(() => { cleanup(); window.xiaokDesktop = original; _resetDesktopApiCache(); localStorage.removeItem('xiaok:locale'); vi.restoreAllMocks(); });
it.each(['zh', 'en'] as const)('actual page %s installation business false does not enable defaults and shows localized action failure', async locale => {
  localStorage.setItem('xiaok:locale', locale); port.installSkill.mockResolvedValue({ success: false, message: 'private_owned_process_failure' }); mount(); await beginInstall(locale);
  expect(await screen.findByText(locales[locale].skills.importFailed)).toBeInTheDocument();
  expect(screen.queryByText('private_owned_process_failure')).toBeNull(); expect(seams.replace).not.toHaveBeenCalled(); expect(port.uninstallSkill).not.toHaveBeenCalled();
  expect(screen.getByRole('switch', { name: locales[locale].skills.enabledByDefault + ': Owned skill' })).not.toBeChecked();
});
it.each(['zh', 'en'] as const)('actual page %s transport rejection is localized and never mutates defaults', async locale => {
  localStorage.setItem('xiaok:locale', locale); port.installSkill.mockRejectedValue(Error('private_owned_transport_failure')); mount(); await beginInstall(locale);
  expect(await screen.findByText(locales[locale].skills.importFailed)).toBeInTheDocument(); expect(screen.queryByText('private_owned_transport_failure')).toBeNull(); expect(seams.replace).not.toHaveBeenCalled();
});
it('success preserves the exact slug/version and performs the existing default enable and catalog refresh once', async () => {
  mount(); await beginInstall(); await waitFor(() => expect(seams.replace).toHaveBeenCalledExactlyOnceWith('owned', [{ skill_key: 'owned-skill', version: '1.0' }]));
  await waitFor(() => expect(port.listSkills).toHaveBeenCalledTimes(2)); expect(seams.imported).toHaveBeenCalledTimes(1); expect(port.uninstallSkill).not.toHaveBeenCalled();
});
it.each(['business-false', 'reject'] as const)('held %s settles with current locale error and no default write', async failure => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); mount(); const toggle = await beginInstall();
  expect(toggle).toBeDisabled(); expect(seams.replace).not.toHaveBeenCalled(); fireEvent.click(screen.getByRole('button', { name: 'test-current-locale' }));
  await act(async () => { if (failure === 'reject') request.reject(Error('private_held_failure')); else request.resolve({ success: false, message: 'private_held_failure' }); });
  expect(await screen.findByText(locales.en.skills.importFailed)).toBeInTheDocument(); expect(screen.queryByText(locales.zh.skills.importFailed)).toBeNull(); expect(seams.replace).not.toHaveBeenCalled(); expect(port.installSkill).toHaveBeenCalledTimes(1);
});
it('an already visible action error follows a locale switch without another mutation or losing facts', async () => {
  port.installSkill.mockRejectedValue(Error('private_owned_failure')); mount(); await beginInstall(); await screen.findByText(locales.zh.skills.importFailed);
  fireEvent.click(screen.getByRole('button', { name: 'test-current-locale' })); expect(await screen.findByText(locales.en.skills.importFailed)).toBeInTheDocument();
  expect(screen.queryByText(locales.zh.skills.importFailed)).toBeNull(); expect(screen.getByRole('button', { name: 'Owned skill' })).toBeInTheDocument(); expect(port.installSkill).toHaveBeenCalledTimes(1); expect(seams.replace).not.toHaveBeenCalled();
});
it('a held success remains authorized across locale change and is not replayed', async () => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); mount(); await beginInstall(); fireEvent.click(screen.getByRole('button', { name: 'test-current-locale' }));
  await act(async () => request.resolve({ success: true, message: 'owned_ok' })); await waitFor(() => expect(seams.replace).toHaveBeenCalledExactlyOnceWith('owned', [{ skill_key: 'owned-skill', version: '1.0' }]));
  expect(port.installSkill).toHaveBeenCalledTimes(1); expect(seams.imported).toHaveBeenCalledTimes(1); expect(screen.queryByText(locales.en.skills.importFailed)).toBeNull();
});
it('busy switch duplicate clicks cannot dispatch a second held installation', async () => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); const view = mount(); const toggle = await beginInstall();
  fireEvent.click(toggle); fireEvent.click(toggle); expect(port.installSkill).toHaveBeenCalledTimes(1); expect(seams.imported).toHaveBeenCalledTimes(1); expect(seams.replace).not.toHaveBeenCalled();
  try { await act(async () => request.resolve({ success: false, message: 'owned_failure' })); await screen.findByText(locales.zh.skills.importFailed); } finally { view.unmount(); }
  expect(seams.replace).not.toHaveBeenCalled();
});
it.each(['success', 'business-false', 'reject'] as const)('unmounted held %s cannot enable defaults or refresh a successor component', async outcome => {
  const request = held<{ success: boolean; message: string }>(); port.installSkill.mockReturnValue(request.promise); const old = mount(); await beginInstall(); old.unmount();
  const fresh = mount(); await openMarketplace(); const reads = port.listSkills.mock.calls.length, defaults = seams.defaults.mock.calls.length;
  try {
    await act(async () => { if (outcome === 'reject') request.reject(Error('private_unmounted_failure')); else request.resolve({ success: outcome === 'success', message: 'private_unmounted_receipt' }); });
    expect(seams.replace).not.toHaveBeenCalled(); expect(port.listSkills).toHaveBeenCalledTimes(reads); expect(seams.defaults).toHaveBeenCalledTimes(defaults);
    expect(screen.queryByText(locales.zh.skills.importFailed)).toBeNull(); expect(screen.queryByText('private_unmounted_receipt')).toBeNull(); expect(port.installSkill).toHaveBeenCalledTimes(1);
  } finally { fresh.unmount(); }
});

```
