# 原人口并行批15源码组件合同

本批 runtime状态2、技能动作2、channel/MCP7、meeting配置/授权/模型4；round34。三位worker分域编码，集成owner负责共享hunks、重型测试和GLM‑5.3整批审。编码GPT‑6与实际评审GLM‑5.3为不同模型。正式计数与全SHA以最终资格票/PR为准。

Main真实窗口authorizer及物理shutdown token复用；输入先capture再schema，结果capture为完整DTO，显式拒绝constructor/species并保单次producer，技能失败不默认enable。service mutation均明确来源且非user默认拒绝。ASR保存读取真实配置，同JS turn编辑同步save；无凭证成功/异常输出。channel写保非target字段，MCP完整数组保未来元数据。权限仅pending singleflight不缓存完成结果；model下载lease进程内跨facade一致直到实际settle，未冒充跨进程/activeconsumer/alias/cancel协议。UI动作单飞、lastgood、locale/unmount/事件与旧read回执保护。

最终验证：331新控制、77UI、106新Promise+原112；相关145files2023pass/2原workflow失败/2原条件转录skip。untouchedb757同2brand失败，权限/断言未改。完整strict Main414roots1865source/Renderer42roots2071source diag0/noCheckfalse；gov/changed/testlint0新违规、两build0。真实Electron60calls，非法30拒绝、合法28成功+2未知模型拒绝、token0、reap/gone/noSHA漂移。探针SDK缓存与OS权限为明确surrogate、CLIownedshim，未作正常安装/正常下载/native/Windows/全UI资格。

原失败、一次reporter路径覆盖事实保留；原176/351人口与时限保留。father所有未完事项继承，原自动中断native/material/P4未重试。PR37为完整历史恢复快照，组件批准不等于最终完整HEAD质量；后者未跑未放行。创始人决定合并，代理未合并/发布。Desktop tag与CLI包将来同一完整SHA，build→pack:cli→verify:pack-dist实际exit0。
