from pathlib import Path
import hashlib,json,re,subprocess,difflib
root=Path.cwd();base=root/'.artifacts/unfinished-closure-20261001/parallel-fastlane-20261012';out=root/'.artifacts/unfinished-closure-20261001/parallel-batch-20261012-r1';records=json.loads((out/'shared-hunk-application-r1.json').read_text()) if (out/'shared-hunk-application-r1.json').exists() else []
allowed={'desktop/electron/ipc.ts','desktop/electron/desktop-services.ts','desktop/electron/preload-api.ts','desktop/electron/ipc-runtime.ts','desktop/electron/meeting-readonly-data.ts','desktop/electron/meeting-model-service.ts','desktop/renderer/src/api/bridge.ts','desktop/renderer/src/components/DesktopSettings.tsx','desktop/renderer/src/locales/index.ts','desktop/renderer/src/locales/en.ts','desktop/renderer/src/locales/zh.ts'}
for name in ['skills','channel-mcp','meeting-config']:
 lines=(base/name/'proposal.patch').read_text().splitlines(keepends=True);i=0;target=None
 while i<len(lines):
  line=lines[i]
  if line.startswith('+++ b/'):target=line[6:].strip();i+=1;continue
  if line.startswith('@@'):
   header=line.strip();i+=1;old=[];new=[]
   while i<len(lines) and lines[i][:1]in [' ','+','-'] and not lines[i].startswith(('--- ','+++ ')):
    part=lines[i]
    if part[0]in [' ','-']:old.append(part[1:])
    if part[0]in [' ','+']:new.append(part[1:])
    i+=1
   if target in allowed and not any(x['domain']==name and x['path']==target and x['hunk']==header for x in records):
    path=root/target;current=path.read_text();before=''.join(old);after=''.join(new);count=current.count(before)
    chosen=None
    if count!=1:
     original=subprocess.check_output(['git','show','b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1:'+target],text=True);start=int(re.search(r'@@ -(\d+)',header).group(1))-1;ol=original.splitlines(keepends=True);cl=current.splitlines(keepends=True);assert ''.join(ol[start:start+len(old)])==before
     for tag,a,b,c,d in difflib.SequenceMatcher(None,ol,cl,autojunk=False).get_opcodes():
      if tag=='equal'and a<=start and start+len(old)<=b:chosen=len(''.join(cl[:c+start-a]));break
     if chosen is None or current[chosen:chosen+len(before)]!=before:raise RuntimeError((name,target,header,'no exact unchanged base span',count))
    if chosen is None:path.write_text(current.replace(before,after,1))
    else:path.write_text(current[:chosen]+after+current[chosen+len(before):]);
    records.append({'domain':name,'path':target,'hunk':header,'exactUniqueOriginalBodyMatched':True,'beforeHunkSha256':hashlib.sha256(before.encode()).hexdigest(),'afterHunkSha256':hashlib.sha256(after.encode()).hexdigest()});(out/'shared-hunk-application-r1.json').write_text(json.dumps(records,indent=2))
   continue
  i+=1
print('applied approved shared hunks',len(records),'exactly once')
