import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

root = Path(__file__).resolve().parent
request = json.loads(Path(sys.argv[1]).read_text())
label = request['label']
receipt = root / (label + '-process.json')
log = root / (label + '.log')
lock = root / 'heavy-cpu-lease.lock'
token = str(uuid.uuid4())
inputs = request.get('inputs', [])
def hashes():
    return {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs}
before = hashes()
fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
os.write(fd, json.dumps({'owner': label, 'token': token, 'pid': os.getpid()}).encode())
os.close(fd)
started = time.time()
child = None
gone = False
try:
    with log.open('x') as output:
        child = subprocess.Popen(request['argv'], cwd=request['cwd'], start_new_session=True,
                                 stdin=subprocess.PIPE if 'stdin' in request else subprocess.DEVNULL,
                                 stdout=output, stderr=subprocess.STDOUT)
        (root / (label + '-pid.json')).write_text(json.dumps({'pid': child.pid, 'pgid': child.pid, 'token': token, 'started': started}))
        child.communicate(request.get('stdin', '').encode() if 'stdin' in request else None)
    try:
        os.killpg(child.pid, 0)
    except ProcessLookupError:
        gone = True
    after = hashes()
    result = {'label': label, 'argv': request['argv'], 'cwd': request['cwd'], 'pid': child.pid,
              'started': started, 'elapsedSeconds': time.time()-started, 'exit': child.returncode,
              'actualWait': True, 'reaped': True, 'groupGone': gone, 'before': before, 'after': after,
              'sourceDrift': [p for p in before if before[p] != after[p]]}
    receipt.write_text(json.dumps(result, indent=2))
    print(json.dumps({k: result[k] for k in ('label','exit','elapsedSeconds','groupGone','sourceDrift')}))
    if not gone:
        raise RuntimeError('owned_group_still_alive')
finally:
    if gone and json.loads(lock.read_text())['token'] == token:
        lock.unlink()
sys.exit(child.returncode)
