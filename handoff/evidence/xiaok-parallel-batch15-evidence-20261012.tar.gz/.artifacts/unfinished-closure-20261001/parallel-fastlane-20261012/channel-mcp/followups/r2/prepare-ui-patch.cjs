// Artifact-only generator: reads current DesktopSettings, writes only beside this script.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),ts=require('typescript'),cp=require('node:child_process');
const root=process.cwd(),out=__dirname,target='desktop/renderer/src/components/DesktopSettings.tsx';
const original=fs.readFileSync(target,'utf8'),ast=ts.createSourceFile(target,original,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const declarations=['ChannelsPane','McpPane'].map(name=>{const node=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);if(!node)throw Error('function missing: '+name);return {name,start:node.getStart(ast),end:node.end,text:node.getText(ast)};});
function replaceOnce(source,from,to){if(source.split(from).length!==2)throw Error('anchor not unique: '+from.slice(0,80));return source.replace(from,to);}
function ownerHelpers(channel){return `  type ActionOwner = { active: boolean; epoch: number; pending: Map<string, symbol> };
  type ActionLease = { owner: ActionOwner; epoch: number; token: symbol; keys: string[] };
  const actionOwner = useRef<ActionOwner>({ active: false, epoch: 0, pending: new Map() });
  const [pendingActions, setPendingActions] = useState<ReadonlySet<string>>(() => new Set());
${channel?'  const testRevision = useRef(0);\n':''}  useEffect(() => {
    const owner = actionOwner.current;
    owner.active = true; owner.epoch += 1;
    setPendingActions(new Set(owner.pending.keys()));
${channel?"    setError(''); setSuccess('');\n":''}    return () => {
      owner.active = false; owner.epoch += 1;
${channel?'      testRevision.current += 1;\n':''}      // Pending effects remain locked across locale changes until their real settlement.
    };
  }, [locale]);
  const beginAction = (keys: string[]): ActionLease | null => {
    const owner = actionOwner.current;
    if (!owner.active || keys.some(key => owner.pending.has(key))) return null;
    const token = Symbol();
    for (const key of keys) owner.pending.set(key, token);
    setPendingActions(new Set(owner.pending.keys()));
    return { owner, epoch: owner.epoch, token, keys };
  };
  const isCurrentAction = (lease: ActionLease) => actionOwner.current === lease.owner
    && lease.owner.active && lease.owner.epoch === lease.epoch;
  const finishAction = (lease: ActionLease) => {
    for (const key of lease.keys) if (lease.owner.pending.get(key) === lease.token) lease.owner.pending.delete(key);
    // An old locale may release only its own settled locks; it cannot publish an action fact.
    if (actionOwner.current === lease.owner && lease.owner.active) setPendingActions(new Set(lease.owner.pending.keys()));
  };

`;}
function channels(source){
 source=replaceOnce(source,"  const [testingChannel, setTestingChannel] = useState<string | null>(null);\n",'');
 source=replaceOnce(source,'  const { t } = useLocale();','  const { t, locale } = useLocale();');
 source=replaceOnce(source,'  // Reset fields when type changes',ownerHelpers(true)+'  // Reset fields when type changes');
 const start=source.indexOf('  const handleCreate = async () => {'),end=source.indexOf('  if (loading) {',start);
 if(start<0||end<0)throw Error('channel action anchors missing');
 const handlers=`  const handleCreate = async () => {
    if (!actionOwner.current.active || actionOwner.current.pending.has('create') || !newName.trim()) return;
    const typeConfig = channelTypeConfig[newType];
    for (const field of typeConfig.fields) {
      if (field.required && !newFields[field.key]?.trim()) {
        alert(ts.channelsFieldRequired(field.label));
        return;
      }
    }
    const lease = beginAction(['create', 'row:' + newType]);
    if (!lease) return;
    try {
      await api.createChannel({ type: newType, name: newName.trim(), ...newFields });
      if (!isCurrentAction(lease)) return;
      setNewName(''); setNewFields({}); setShowAdd(false);
      load();
    } catch {
      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
    } finally { finishAction(lease); }
  };

  const handleDelete = async (id: string) => {
    if (!actionOwner.current.active || actionOwner.current.pending.has('row:' + id)) return;
    if (!confirm(ts.channelsDeleteConfirm)) return;
    const lease = beginAction(['row:' + id]);
    if (!lease) return;
    try {
      await api.deleteChannel(id);
      if (isCurrentAction(lease)) load();
    } catch {
      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
    } finally { finishAction(lease); }
  };

  const handleToggle = async (channel: ChannelConfig) => {
    const lease = beginAction(['row:' + channel.id]);
    if (!lease) return;
    try {
      await api.updateChannel(channel.id, { enabled: !channel.enabled });
      if (isCurrentAction(lease)) load();
    } catch {
      if (isCurrentAction(lease)) alert(t.channelMutationFailed);
    } finally { finishAction(lease); }
  };

  const handleTest = async (id: string) => {
    const lease = beginAction(['test:' + id]);
    if (!lease) return;
    const revision = ++testRevision.current;
    setError(''); setSuccess('');
    try {
      const result = await api.testChannel(id);
      if (!isCurrentAction(lease) || revision !== testRevision.current) return;
      if (result.success) setSuccess(ts.channelsTestSuccess(result.latencyMs ?? 0));
      else setError(result.error?.startsWith('channel_mcp_mutation_') ? ts.channelsTestFailed : result.error || ts.channelsTestFailed);
    } catch {
      if (isCurrentAction(lease) && revision === testRevision.current) setError(ts.channelsTestFailed);
    } finally { finishAction(lease); }
  };

`;
 source=source.slice(0,start)+handlers+source.slice(end);
 const from=source.indexOf('                      onClick={async () => {'),to=source.indexOf("                      className=\"inline-flex shrink-0 items-center gap-1 rounded-md border",from);
 if(from<0||to<0)throw Error('channel test button anchor missing');
 source=source.slice(0,from)+`                      onClick={() => void handleTest(ch.id)}
                      disabled={pendingActions.has('test:' + ch.id)}
`+source.slice(to);
 source=replaceOnce(source,"{testingChannel === ch.id ? <Loader2 size={12} className=\"animate-spin\" /> : <Zap size={12} />}","{pendingActions.has('test:' + ch.id) ? <Loader2 size={12} className=\"animate-spin\" /> : <Zap size={12} />}");
 source=replaceOnce(source,'<button type="button" onClick={handleCreate} className={btnPrimary}>','<button type="button" onClick={handleCreate} disabled={pendingActions.has(\'create\')} className={btnPrimary}>');
 source=replaceOnce(source,'onClick={() => handleToggle(ch)}','disabled={pendingActions.has(\'row:\' + ch.id)}\n                      onClick={() => handleToggle(ch)}');
 source=replaceOnce(source,'onClick={() => handleDelete(ch.id)}','disabled={pendingActions.has(\'row:\' + ch.id)}\n                      onClick={() => handleDelete(ch.id)}');
 return source;
}
function mcp(source){
 source=replaceOnce(source,'  const readGeneration = useRef(0)',ownerHelpers(false)+'  const readGeneration = useRef(0)');
 const start=source.indexOf('  const handleCreate = async () => {'),end=source.indexOf('  const handleInstallDependency',start);
 if(start<0||end<0)throw Error('MCP action anchors missing');
 const handlers=`  const handleCreate = async () => {
    if (!newName.trim() || !newCommand.trim()) return;
    const lease = beginAction(['create']);
    if (!lease) return;
    try {
      await api.createMCPInstall({
        name: newName.trim(), source: 'npm', command: newCommand.trim(),
        args: newArgs.trim() ? newArgs.trim().split(/\\s+/) : undefined,
      });
      if (!isCurrentAction(lease)) return;
      setNewName(''); setNewCommand(''); setNewArgs(''); setShowAdd(false);
      load();
    } catch {
      if (isCurrentAction(lease)) alert(t.mcpMutationFailed);
    } finally { finishAction(lease); }
  };

  const handleDelete = async (id: string) => {
    if (!actionOwner.current.active || actionOwner.current.pending.has('row:' + id)) return;
    if (!window.confirm(t.mcpInstallDeleteConfirm)) return;
    const lease = beginAction(['row:' + id]);
    if (!lease) return;
    try {
      await api.deleteMCPInstall(id);
      if (isCurrentAction(lease)) load();
    } catch {
      if (isCurrentAction(lease)) alert(t.mcpMutationFailed);
    } finally { finishAction(lease); }
  };

`;
 source=source.slice(0,start)+handlers+source.slice(end);
 source=replaceOnce(source,'<button type="button" onClick={handleCreate} className={btnPrimary}>','<button type="button" onClick={handleCreate} disabled={pendingActions.has(\'create\')} className={btnPrimary}>');
 source=replaceOnce(source,'onClick={() => handleDelete(install.id)}','disabled={pendingActions.has(\'row:\' + install.id)}\n                    onClick={() => handleDelete(install.id)}');
 return source;
}
const edits=declarations.map(d=>({...d,after:d.name==='ChannelsPane'?channels(d.text):mcp(d.text)}));
let candidate=original;for(const edit of [...edits].sort((a,b)=>b.start-a.start))candidate=candidate.slice(0,edit.start)+edit.after+candidate.slice(edit.end);
const candidateAst=ts.createSourceFile(target,candidate,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const otherFunctions=ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&!edits.some(e=>e.name===n.name?.text));
const outsideFunctions=otherFunctions.map(node=>{const next=candidateAst.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===node.name?.text);return {name:node.name?.text,unchanged:!!next&&next.getText(candidateAst)===node.getText(ast)};});
const skeleton=(source,nodes)=>{let result=source;for(const n of [...nodes].sort((a,b)=>b.start-a.start))result=result.slice(0,n.start)+'/* owned function '+n.name+' */'+result.slice(n.end);return result;};
const nextNodes=edits.map(e=>{const n=candidateAst.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===e.name);return {name:e.name,start:n.getStart(candidateAst),end:n.end};});
if(skeleton(original,edits)!==skeleton(candidate,nextNodes))throw Error('out-of-scope byte mutation');
const patchCode="import sys,json,difflib; d=json.load(sys.stdin); print('diff --git a/'+d['path']+' b/'+d['path']); sys.stdout.write(''.join(difflib.unified_diff(d['old'].splitlines(True),d['new'].splitlines(True),fromfile='a/'+d['path'],tofile='b/'+d['path'],n=3)))";
const patch=cp.execFileSync('python3',['-c',patchCode],{input:JSON.stringify({path:target,old:original,new:candidate}),encoding:'utf8'});
const sha=text=>crypto.createHash('sha256').update(text).digest('hex');
fs.writeFileSync(path.join(out,'ui-lifecycle.patch'),patch);
for(const edit of edits)fs.writeFileSync(path.join(out,edit.name+'.candidate.tsx'),'// CANDIDATE ONLY: function replacement in '+target+'; not applied.\n'+edit.after+'\n');
const syntax=ts.transpileModule(candidate,{fileName:target,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}});
const syntaxDiagnostics=(syntax.diagnostics||[]).map(d=>ts.flattenDiagnosticMessageText(d.messageText,' '));
const testPath=path.join(root,'desktop/tests/renderer/channel-mcp-mutation-ui-followup.test.tsx');
const testSyntax=ts.transpileModule(fs.readFileSync(testPath,'utf8'),{fileName:testPath,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}});
const testDiagnostics=(testSyntax.diagnostics||[]).map(d=>ts.flattenDiagnosticMessageText(d.messageText,' '));
fs.writeFileSync(path.join(out,'scope-and-syntax.json'),JSON.stringify({target,sourceSHA256:sha(original),candidateSHA256:sha(candidate),patchSHA256:sha(patch),functions:edits.map(e=>({name:e.name,sourceSHA256:sha(e.text),candidateSHA256:sha(e.after)})),outsideOwnedFunctionsByteIdentical:true,otherFunctions:outsideFunctions,syntaxOnly:true,sourceDiagnostics:syntaxDiagnostics,testDiagnostics,testsRun:false,uiProductionApplied:false},null,2)+'\n');
if(syntaxDiagnostics.length||testDiagnostics.length)throw Error('syntax diagnostics');
process.stdout.write(JSON.stringify({patch:path.join(out,'ui-lifecycle.patch'),patchSHA256:sha(patch),testSHA256:sha(fs.readFileSync(testPath)),outsideOwnedFunctionsByteIdentical:true,sourceDiagnostics:syntaxDiagnostics.length,testDiagnostics:testDiagnostics.length}));
