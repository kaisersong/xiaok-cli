// NO production writes. Prepare current-file hunks or verify a later authorized application.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),ts=require('typescript'),cp=require('node:child_process');
const out=__dirname,r2=path.resolve(out,'../r2'),target=path.resolve(process.cwd(),'desktop/renderer/src/components/DesktopSettings.tsx');
const args=process.argv.slice(2),option=name=>{const i=args.indexOf(name);return i<0?null:args[i+1];};
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const proof=JSON.parse(fs.readFileSync(path.join(r2,'scope-and-syntax.json'),'utf8'));
function parse(source){
 const ast=ts.createSourceFile(target,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 const functions=['ChannelsPane','McpPane','VoicePane'].map(name=>{const n=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);if(!n)throw Error('missing function '+name);return {name,start:n.getStart(ast),end:n.end,text:n.getText(ast),sha256:sha(n.getText(ast))};});
 const owned=functions.filter(f=>f.name!=='VoicePane').sort((a,b)=>a.start-b.start);let cursor=0;
 const outside=owned.map((f,index)=>{const bytes=source.slice(cursor,f.start);cursor=f.end;return {segment:index,bytes:Buffer.byteLength(bytes,'utf8'),sha256:sha(bytes)};});const bytes=source.slice(cursor);outside.push({segment:outside.length,bytes:Buffer.byteLength(bytes,'utf8'),sha256:sha(bytes)});
 return {functions,owned,outside,voice: functions.find(f=>f.name==='VoicePane')};
}
function tagValid(tag){if(!tag||!/^[a-z][a-z0-9-]*$/.test(tag))throw Error('safe --tag required');return tag;}
const verifyTag=option('--verify-tag');
if(verifyTag){
 const tag=tagValid(verifyTag),before=JSON.parse(fs.readFileSync(path.join(out,tag+'-before.json'),'utf8')),source=fs.readFileSync(target,'utf8'),current=parse(source);
 if(JSON.stringify(current.outside)!==JSON.stringify(before.outside))throw Error('outside-owned-function bytes changed; do not claim conservation');
 if(current.voice.sha256!==before.voiceSHA256)throw Error('VoicePane changed');
 for(const expected of proof.functions){if(current.owned.find(f=>f.name===expected.name).sha256!==expected.candidateSHA256)throw Error('candidate mismatch '+expected.name);}
 const record={mode:'verify-only',target,sourceSHA256:sha(source),outsideOwnedFunctionBytesUnchanged:true,VoicePaneSHA256:current.voice.sha256,ownedFunctions:current.owned.map(f=>({name:f.name,sha256:f.sha256})),productionWrittenByScript:false};
 fs.writeFileSync(path.join(out,tag+'-verified.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify(record));process.exit(0);
}
const tag=tagValid(option('--tag')),source=fs.readFileSync(target,'utf8'),sourceSHA=sha(source),current=parse(source);
const expectedFileSHA=option('--expected-file-sha'),expectedVoiceSHA=option('--expected-voice-sha');
if(expectedFileSHA&&sourceSHA!==expectedFileSHA)throw Error('fresh whole-file SHA differs from owner gate');
if(expectedVoiceSHA&&current.voice.sha256!==expectedVoiceSHA)throw Error('fresh VoicePane SHA differs from owner gate');
for(const expected of proof.functions){if(current.owned.find(f=>f.name===expected.name).sha256!==expected.sourceSHA256)throw Error('owned function drift '+expected.name+'; retain foreign changes, never overwrite');}
const candidates=current.owned.map(f=>{
 const text=fs.readFileSync(path.join(r2,f.name+'.candidate.tsx'),'utf8'),ast=ts.createSourceFile(f.name+'.tsx',text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX),node=ast.statements.find(n=>ts.isFunctionDeclaration(n)&&n.name?.text===f.name),candidate=node.getText(ast),approved=proof.functions.find(g=>g.name===f.name);
 if(sha(candidate)!==approved.candidateSHA256)throw Error('approved candidate drift '+f.name);return {...f,candidate};
});
// Only stitch reviewed function bodies into the just-read current source in memory.
// The production file is NEVER written or replaced by this script.
let next=source;for(const f of [...candidates].sort((a,b)=>b.start-a.start))next=next.slice(0,f.start)+f.candidate+next.slice(f.end);
const expected=parse(next);
if(JSON.stringify(expected.outside)!==JSON.stringify(current.outside)||expected.voice.sha256!==current.voice.sha256)throw Error('out-of-scope mutation');
const code="import sys,json,difflib; d=json.load(sys.stdin); print('diff --git a/'+d['file']+' b/'+d['file']); sys.stdout.write(''.join(difflib.unified_diff(d['old'].splitlines(True),d['new'].splitlines(True),fromfile='a/'+d['file'],tofile='b/'+d['file'],n=3)))";
const patch=cp.execFileSync('python3',['-c',code],{input:JSON.stringify({file:'desktop/renderer/src/components/DesktopSettings.tsx',old:source,new:next}),encoding:'utf8'});
if(sha(fs.readFileSync(target))!==sourceSHA)throw Error('source changed during prepare; retry only after owner confirms Voice worker finished');
const patchPath=path.join(out,tag+'.patch'),recordPath=path.join(out,tag+'-before.json');
if(fs.existsSync(patchPath)||fs.existsSync(recordPath))throw Error('tag artifacts exist; select a new tag instead of overwriting');
fs.writeFileSync(patchPath,patch,{flag:'wx'});
const checked=cp.spawnSync('git',['apply','--check',patchPath],{encoding:'utf8'});
const record={mode:'prepare-only',productionWrittenByScript:false,target,sourceSHA256:sourceSHA,candidateSHA256:sha(next),patch:patchPath,patchSHA256:sha(patch),voiceSHA256:current.voice.sha256,outside:current.outside,ownedFunctions:current.owned.map(f=>({name:f.name,sourceSHA256:f.sha256,candidateSHA256:proof.functions.find(g=>g.name===f.name).candidateSHA256})),outsideOwnedFunctionBytesConservedInCandidate:true,VoicePaneBytesConservedInCandidate:true,expectedFileSHA,expectedVoiceSHA,checkExitCode:checked.status,checkStdout:checked.stdout,checkStderr:checked.stderr};
fs.writeFileSync(recordPath,JSON.stringify(record,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify(record));process.exitCode=checked.status===0?0:1;
