# R2 UI lifecycle candidate（生产未应用）

独占边界仅 `DesktopSettings.tsx` 的 ChannelsPane/McpPane；原文件之外的字符及全部其它函数（含VoicePane）AST+字节核对不变。实际测试文件已按owner授权拷入 tests/renderer，内容与冻结followup完全相同，不删旧人口或断言。

动作owner是组件局部ref：真实pending按key同步锁定；Channels create同时锁create及目标row、toggle/delete同row互斥、test各row独立；MCP create/delete对应锁。locale/unmount使epoch失效，旧ACK/错误不得refresh、alert、关闭/清空新draft或发布test状态；旧finally只移除其本人token，真实未settle动作跨locale仍锁定，不伪造cancel/ACK。

Channel test的busy由每row pending投影；单个状态panel采用最新test revision，旧row回执不能盖新动作，开始新test清旧action状态。read lastgood/failed不受这些状态操作影响；mutation ACK成功后仍复用原refresh，读取失败不伪装mutation失败、不resend，error与read独立。

MCP原load callback、generation、Promise.allSettled、busy/manual单飞、2s interval、全部plugin/dependency动作未改；helper新effect只做动作lifetime，无poll/read/event。原Channel/MCP confirm、trim/args split/source/credentials/id/enabled/POST参数和本地化消息保持，不扩权限/locale/bridge/Core。

亲读当前依据：Channels callbacks `DesktopSettings.tsx:2104-2144,2270-2285`；MCP callbacks `:2376-2402`；原MCP读owner `:2346-2374`。新patch不是“完整全McpPane插件动作lifetime已闭合”宣称；其它父债与native/material/P4拒绝仍保留。

仅TypeScript transpile语法和 git apply --check，未运行测试/types/build/GLM。React best practices技能检查：transient epoch/token/revision在ref，busy呈现用state；effect依赖primitive locale，不让readonly或plugin事实变动重建动作owner。下一步owner实测这份真实生产UI RED，再授权应用patch；当前禁止worker应用UI行为源码。

owner命令：
```sh
cd /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop
npm run test -- --run tests/renderer/channel-mcp-mutation-ui-followup.test.tsx
```

原用户范围、期限/baseline/失败与foreign WIP不缩减；集中13files331为owner报告、非本worker日志。CODE和全父验收仍由owner队列。
