# 追加控制：仅候选，旧冻结输入不变

集成owner已报告原批实际 RED `9files248=87pass161fail`（转引，非本worker执行）。当前followups没有运行测试、类型检查或build；不改变原失败、计数/人口/期限/baseline、native/material/P4拒绝和foreign WIP。本目录只增加controls；父目录所有旧文件hash在frozen-before/after中核对。

## 页面真实链

`channel-mcp-mutation-ui-followup.test.tsx` 使用真实 DesktopSettings 中 ChannelsPane/McpPane、LocaleProvider、实际 api/bridge，只有 window.xiaokDesktop 终端运输替换成 held Promise/拒绝/正常事实；未替换生产hook/bridge/parse或实现被测逻辑。

- 五个现有用户动作：Channel create/delete/toggle 与 MCP create/delete，各覆盖 held前保facts/draft、ACK才刷新、重复click不重复mutation、unmount/locale后迟到ACK/拒绝无当前scope刷新/alert/draft覆盖、ACK后读取失败保last-good且不重发、action拒绝与read失败独立。原参数与真实id断言保留；MCP confirm原cancel/confirmed控制仍在冻结ui-red中，不用这批替换它。
- 另有Channel真实test双row busy独立、locale后迟到resolve/reject、readonly失败保last-good/当前actionerror，新成功action仅清旧actionerror；MCP held mutation不增加/劫持2秒poll，unmount后迟到ACK不得重启读。
- selector亲读：Channel输入与button `DesktopSettings.tsx:2199-2239`；toggle locale实际文字 `locales/zh.ts:1247` 为“启用中”，不采用猜测“已启用”；MCP inputs/button `DesktopSettings.tsx:2730-2763`。timer控制在render前启fake timers，避免把已经创建的真实interval当fake测试。
- 已存在的读取生命周期不等于动作生命周期：Channel action回调 `DesktopSettings.tsx:2104-2144,2270-2282`、MCP action `:2375-2399` 没有动作generation检查；MCP读取自身generation/cleanup `:2345-2372`。因此不能以hook读取已受控推断late action受控。test busy为单个channel id `:2089,2271,2282,2285`，实际第二row测试与第一rowfinally可冲突；新增test调用真实按钮检查。

## 真正writer控制

`channel-mcp-mutation-writer-followup.test.ts` 使用真实 createDesktopServices/registerDesktopIpc、production Main admission AST及自有temp文件：

- 6个mutation writer注入真实writeFileSync故障：只在本case精确owned配置文件路径写入17字符前缀，再抛ENOSPC。断言实际命中一次、没有成功ACK、原committed字节仍完整；不是mock业务writer或自造rollback。通过mutable fs default + syncBuiltinESMExports接入当前实际Core/MCP named builtin，finally严格恢复。若owner后续改writer边界，必须独审更新注入并保真实partial-fault条件，不可把“未命中”当通过。
- 故障边界亲读：`src/utils/config.ts:106-113` 直接覆盖config；`desktop-services.ts:5116-5122` MCP直接覆盖；冻结owner候选继续这类writer，只有拒绝ACK不证明失败前无partial损坏。partialwrite case是原父安全/完整性控制，**冻结proposal不保证绿**，没有改设计暗示已有atomic rollback。
- 同JS turn 三个注册Channel与三个注册MCP create/update/delete，验证每个独立提交与非目标metadata；两service实例同paths验证同process，同turn完成，不冒充跨进程互斥。
- schema1/2 raw非目标字段、模型/凭证/未知extras与其它配置文件保留；MCP peer rows、env、args/future完整保留；实际Channel upsert保同row credential/extras。
- 实际跨writer无mock/no sleep：同turn先调用真实 saveSkillDebugConfig/saveKswarmConfig，再调用真实 createChannel，Promise.all后须同时保两更新。旧writer `desktop-services.ts:3464-3470,3477-3484` 在await loadConfig之前已同步captured配置（`src/utils/config.ts:62-99`）；当前legacy family或冻结family candidate至少一方可能覆盖另一方。此测试使all-writer父债可复现，不借7项candidate关闭global父门，不改共享Core。

## owner使用

拷两个候选至 `desktop/tests/renderer/channel-mcp-mutation-ui-followup.test.tsx` 与 `desktop/tests/main/channel-mcp-mutation-writer-followup.test.ts`，保持冻结旧测试全人口，不替换原文件。命令：

```sh
cd /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop
npm run test -- --run tests/renderer/channel-mcp-mutation-ui-followup.test.tsx tests/main/channel-mcp-mutation-writer-followup.test.ts
```

owner批队列运行实际RED/批准源后的controls；本worker仅transpile语法检查，不跑heavy/GLM/Qoder、不应用production。独立DESIGN/TEST_FIX/CODE规则保持。缺：实际跨进程/崩溃恢复、Windows ACL/native安装、真实secret/provider消费、全部原父验收；不重试已自动拒绝的native/material/P4。
