# WAIT期只读适配准备

尚未获实际UI应用授权；本次不修改任何生产文件、不运行测试/GLM/build/commit。77=39pass38fail、Channels/Mcp 27失败来自owner消息，非worker运行结果，原失败保留。

prepare-fresh-hunks.cjs **没有任何生产写入分支**。默认仅读取当前DesktopSettings AST，核对ChannelsPane/McpPane的当前旧函数SHA与R2批准基准一致、候选函数SHA不变，现场拼接仅两函数的稀疏hunks，写artifact patch及外部bytes记录。VoicePane从当前文件读取并保留，三个外部连续bytes段（prefix/两函数之间/suffix）记录长度+SHA。

实测当前whole-file SHA已不同于R2旧snapshot，但两个归属函数旧SHA仍一致；本次fresh生成保持当前所有外部bytes，没有把R2整文件回写。此结果不代表Voice worker已完成，也不授予应用权限。

收到owner确认Voice完成与新授权后，必须再生成新tag，不能使用WAIT期patch或旧snapshot：
```sh
node .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/channel-mcp/followups/r3/prepare-fresh-hunks.cjs --tag authorized-after-voice-r2 --expected-file-sha <owner确认的当前整文件SHA>
```
若owner提供的是VoicePane函数SHA则使用 `--expected-voice-sha`。函数漂移/外部源在prepare期间变化/旧tag存在均fail closed，不能覆盖。该命令仍只是prepare，不应用。

仅获明确授权后才用新fresh patch执行稀疏hunk apply，随后运行：
```sh
node .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/channel-mcp/followups/r3/prepare-fresh-hunks.cjs --verify-tag authorized-after-voice-r2
```
verify只读生产：核两归属函数为批准candidate SHA、Voice SHA及所有外部段长度/SHA完全等于该次fresh-before；不使用旧整文件覆盖、不掩盖foreign变化。测试和CODE仍owner集中队列。
