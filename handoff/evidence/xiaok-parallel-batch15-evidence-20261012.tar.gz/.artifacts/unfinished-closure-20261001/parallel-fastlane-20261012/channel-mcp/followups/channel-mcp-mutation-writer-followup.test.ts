// UNREVIEWED FOLLOWUP controls. Copy to desktop/tests/main with this filename.
// Production registrar/service/Core writer; partial-write injection touches only owned target file.
// npm run test -- --run tests/main/channel-mcp-mutation-writer-followup.test.ts
// @vitest-environment node
import fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, existsSync, chmodSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createDesktopServices } from '../../electron/desktop-services.js';
import { registerDesktopIpc } from '../../electron/ipc.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
import { isTrustedDesktopRendererUrl } from '../../electron/security.js';
import { IPC_SCHEMA_REGISTRY, resetIpcSchemaRegistryForTests } from '../../electron/ipc-runtime.js';
const roots: string[] = [], cleanups: Array<() => Promise<void>> = [];
let previousConfig: string | undefined;
beforeEach(() => { previousConfig = process.env['XIAOK_CONFIG_DIR']; resetIpcSchemaRegistryForTests(); });
afterEach(async () => { for (const cleanup of cleanups.splice(0)) await cleanup(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); if (previousConfig === undefined) delete process.env['XIAOK_CONFIG_DIR']; else process.env['XIAOK_CONFIG_DIR'] = previousConfig; vi.restoreAllMocks(); syncBuiltinESMExports(); vi.useRealTimers(); });
async function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'channel-mcp-writer-followup-owned-')), data = join(root, 'data'); roots.push(root); mkdirSync(data); process.env['XIAOK_CONFIG_DIR'] = join(root, 'config');
  const sdk = { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) };
  const service = createDesktopServices({ dataRoot: data, kswarmService: sdk as never, runner: async () => { throw Error('readonly_must_not_execute_task'); } });
  cleanups.push(async () => { await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent(); });
  const source = readFileSync(new URL('../../electron/main.ts', import.meta.url), 'utf8'), ast = ts.createSourceFile('main.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((n): n is ts.FunctionDeclaration => ts.isFunctionDeclaration(n) && n.name?.text === 'authorizeDesktopInvoke'); expect(declaration).toBeDefined();
  const dirname = resolve('dist/main/desktop/electron'), frame = { url: pathToFileURL(join(dirname, '../../../renderer/index.html')).href }, recorderFrame = { url: frame.url + '#/meeting-recorder/owned' };
  const sender = { mainFrame: frame, isDestroyed: () => false }, recorder = { mainFrame: recorderFrame, isDestroyed: () => false };
  const code = ts.transpileModule("let mainWindow=initialMain,meetingRecorderController=initialRecorder;\n" + declaration!.getText(ast) + "\nreturn { authorize:authorizeDesktopInvoke,setMain(v){mainWindow=v;} };", { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const authority = compileFunction(code, ['initialMain', 'initialRecorder', 'isTrustedDesktopRendererUrl', 'join', '__dirname', 'process'])({ webContents: sender, isDestroyed: () => false }, { ownsWebContents: (v: unknown) => v === recorder }, isTrustedDesktopRendererUrl, join, dirname, { env: {} });
  const listeners = new Map<string, IpcHandlerListener>(), gate = new DesktopShutdownGate(), ipc = new ShutdownAwareIpcMain({ handle: (name, listener) => { expect(listeners.has(name)).toBe(false); listeners.set(name, listener); } }, gate, authority.authorize);
  await registerDesktopIpc(ipc, { isDestroyed: () => false, webContents: { send() {}, id: 1 } } as never, service);
  return { root, data, service, frame, recorderFrame, sender, recorder, authority, gate, listeners, invoke: (method: string, ...args: unknown[]) => Reflect.apply(listeners.get('desktop:' + method)!, undefined, [{ sender, senderFrame: frame }, ...args]) };
}



const methods=['createChannel','updateChannel','deleteChannel','createMCPInstall','updateMCPInstall','deleteMCPInstall']as const;
type Method=typeof methods[number];
const valid:Record<Method,unknown[]>={createChannel:[{type:'added',name:'Added'}],updateChannel:['kept',{name:'Changed'}],deleteChannel:['deleted'],createMCPInstall:[{name:'Added MCP',source:'local',command:'new-command',args:['--new','']}],updateMCPInstall:['kept',{name:'Changed MCP',command:'changed-command'}],deleteMCPInstall:['deleted']};
function seed(f:Awaited<ReturnType<typeof fixture>>,schema:1|2=2){
 const configDirectory=join(f.root,'config');mkdirSync(configDirectory,{recursive:true});
 const channels={owned:{name:'Owned',sendMsgUrl:'https://owned.invalid',enabled:true,secret:'OWNED_CHANNEL_SECRET',future:{keep:true}},kept:{name:'Kept',enabled:true,botToken:'OWNED_BOT_SECRET',future:{deep:['preserve']}},deleted:{name:'Deleted',enabled:true}};
 const base={schemaVersion:schema,skillDebug:false,kswarm:{maxConcurrentTasks:3},channels,future:{keep:['whole-config']},opaquePolicy:{keep:true}};
 const config=schema===2?{...base,defaultProvider:'owned',defaultModelId:'owned-model',providers:{owned:{type:'custom',protocol:'openai_legacy',apiKey:'OWNED_PROVIDER_SECRET',baseUrl:'https://owned.invalid'}},models:{'owned-model':{provider:'owned',model:'owned-wire',label:'Owned'}}}:{...base,defaultModel:'openai',models:{openai:{apiKey:'OWNED_LEGACY_SECRET',model:'owned-wire'}}};
 const installs=['owned','kept','deleted'].map(id=>({id,name:id+' MCP',source:'local',command:'owned-command',args:['--owned',''],enabled:true,createdAt:1,env:{OWNED_KEY:'OWNED_MCP_SECRET'},future:{deep:[id]}}));
 const configPath=join(configDirectory,'config.json'),mcpPath=join(f.data,'mcp-installs.json');writeFileSync(configPath,JSON.stringify(config));writeFileSync(mcpPath,JSON.stringify(installs));return {configPath,mcpPath,config,installs};
}
it.each(methods)('%s partial-write fault cannot ACK or destroy the previously committed file',async method=>{
 const f=await fixture(),files=seed(f),target=method.includes('MCP')?files.mcpPath:files.configPath,before=readFileSync(target,'utf8');
 const nativeWrite=fs.writeFileSync;let partialWrites=0;
 const spy=vi.spyOn(fs,'writeFileSync').mockImplementation(((...args:Parameters<typeof fs.writeFileSync>)=>{
  if(String(args[0])!==target)return Reflect.apply(nativeWrite,fs,args);
  partialWrites++;const bytes=typeof args[1]==='string'?args[1]:String(args[1]);
  // Inject an actual committed prefix then an I/O fault, not a fake mutation or fake rollback.
  Reflect.apply(nativeWrite,fs,[args[0],bytes.slice(0,17),args[2]]);throw Object.assign(Error('OWNED_PARTIAL_WRITE'),{code:'ENOSPC'});
 })as typeof fs.writeFileSync);syncBuiltinESMExports();
 try{
  const outcome=await f.invoke(method,...valid[method]).then(value=>({ok:true as const,value}),error=>({ok:false as const,error}));
  expect(partialWrites,'the real production writer must hit the owned fault boundary').toBe(1);expect(outcome.ok).toBe(false);
  expect(readFileSync(target,'utf8'),'a rejected write must preserve the prior committed bytes').toBe(before);
 }finally{spy.mockRestore();syncBuiltinESMExports();}
});
it('same-turn real registered Channel create/update/delete retain every disjoint edit',async()=>{
 const f=await fixture(),files=seed(f);const before=files.config;
 await Promise.all([f.invoke('createChannel',...valid.createChannel),f.invoke('updateChannel',...valid.updateChannel),f.invoke('deleteChannel',...valid.deleteChannel)]);
 const after=JSON.parse(readFileSync(files.configPath,'utf8'));expect(after.channels.added).toMatchObject({name:'Added'});expect(after.channels.kept).toMatchObject({name:'Changed',botToken:'OWNED_BOT_SECRET',future:{deep:['preserve']}});expect(after.channels.deleted).toBeUndefined();expect(after.channels.owned).toEqual(before.channels.owned);
 expect(after.providers).toEqual('providers'in before?before.providers:undefined);expect(after.models).toEqual(before.models);expect(after.future).toEqual(before.future);
});
it('same-turn real registered MCP create/update/delete retain every disjoint edit and stored metadata',async()=>{
 const f=await fixture(),files=seed(f);
 const [created]=await Promise.all([f.invoke('createMCPInstall',...valid.createMCPInstall),f.invoke('updateMCPInstall',...valid.updateMCPInstall),f.invoke('deleteMCPInstall',...valid.deleteMCPInstall)]);
 const rows=JSON.parse(readFileSync(files.mcpPath,'utf8'));expect(rows.map((row:{id:string})=>row.id).sort()).toEqual(['owned','kept',created.id].sort());
 expect(rows.find((row:{id:string})=>row.id==='kept')).toMatchObject({name:'Changed MCP',command:'changed-command',args:['--owned',''],env:{OWNED_KEY:'OWNED_MCP_SECRET'},future:{deep:['kept']}});expect(rows.find((row:{id:string})=>row.id==='owned')).toEqual(files.installs[0]);
 const readonly=await f.invoke('listMCPInstalls');expect(readonly).toEqual(rows);
});
it.each([1,2]as const)('schema%s actual Channel edits preserve every non-target field and unrelated file',async schema=>{
 for(const method of ['createChannel','updateChannel','deleteChannel']as const){
  const f=await fixture(),files=seed(f,schema),before=JSON.parse(readFileSync(files.configPath,'utf8')),mcpBytes=readFileSync(files.mcpPath,'utf8');await f.invoke(method,...valid[method]);const after=JSON.parse(readFileSync(files.configPath,'utf8'));
  const {channels:oldRows,...nonTarget}=before,{channels:newRows,...afterNonTarget}=after;expect(afterNonTarget).toEqual(nonTarget);expect(newRows.owned).toEqual(oldRows.owned);expect(readFileSync(files.mcpPath,'utf8')).toBe(mcpBytes);
  if(method==='updateChannel')expect(newRows.kept).toEqual({...oldRows.kept,name:'Changed'});if(method==='deleteChannel')expect(newRows.deleted).toBeUndefined();
 }
});
it.each(['createMCPInstall','updateMCPInstall','deleteMCPInstall']as const)('%s actual edit preserves non-target MCP records, metadata, args and config bytes',async method=>{
 const f=await fixture(),files=seed(f),configBytes=readFileSync(files.configPath,'utf8');await f.invoke(method,...valid[method]);const rows=JSON.parse(readFileSync(files.mcpPath,'utf8'));
 expect(readFileSync(files.configPath,'utf8')).toBe(configBytes);expect(rows.find((row:{id:string})=>row.id==='owned')).toEqual(files.installs[0]);
 if(method==='updateMCPInstall')expect(rows.find((row:{id:string})=>row.id==='kept')).toEqual({...files.installs[1],name:'Changed MCP',command:'changed-command'});
 else expect(rows.find((row:{id:string})=>row.id==='kept')).toEqual(files.installs[1]);
});
it.each(['saveSkillDebugConfig','saveKswarmConfig']as const)('cross-writer %s and Channel create in the same turn must retain both durable updates',async sibling=>{
 const f=await fixture(),files=seed(f);const siblingInput=sibling==='saveSkillDebugConfig'?{enabled:true}:{maxConcurrentTasks:7};
 // Both are real production services. The legacy writer captures loadConfig synchronously
 // and yields at its existing await; the family mutation starts in that same JS turn.
 // No replacement of loadConfig/saveConfig, no sleep, no imitation of their state logic.
 const broader=Reflect.apply(f.service[sibling],f.service,[siblingInput,'user']);
 const family=Reflect.apply(f.service.createChannel,f.service,[{type:'added',name:'Added'},'user']);
 await Promise.all([broader,family]);const after=JSON.parse(readFileSync(files.configPath,'utf8'));
 expect(after.channels.added,'cross-writer whole-config snapshots must not erase the successful Channel commit').toMatchObject({name:'Added'});
 if(sibling==='saveSkillDebugConfig')expect(after.skillDebug).toBe(true);else expect(after.kswarm.maxConcurrentTasks).toBe(7);
 expect(after.providers).toEqual('providers'in files.config?files.config.providers:undefined);expect(after.models).toEqual(files.config.models);expect(after.channels.owned).toEqual(files.config.channels.owned);
});
it('two real service instances sharing the same config and MCP paths cannot lose same-turn family edits',async()=>{
 const f=await fixture(),files=seed(f);const sdk={start:async()=>{},stop:async()=>{},restart:async()=>{},getStatus:()=>({running:false,port:4400,pid:null,restartCount:0,lastError:null}),onStatusChange:()=>()=>{},request:async()=>Response.json({})};
 const second=createDesktopServices({dataRoot:f.data,kswarmService:sdk as never,runner:async()=>{throw Error('must_not_run')}});cleanups.push(async()=>{await second.closeTaskSourceWritersForMigration();await second.disposeMultiAgent();});
 const a=Reflect.apply(f.service.createChannel,f.service,[{type:'service-a',name:'Service A'},'user']),b=Reflect.apply(second.createChannel,second,[{type:'service-b',name:'Service B'},'user']);await Promise.all([a,b]);
 const config=JSON.parse(readFileSync(files.configPath,'utf8'));expect(config.channels).toMatchObject({'service-a':{name:'Service A'},'service-b':{name:'Service B'}});
 const c=Reflect.apply(f.service.createMCPInstall,f.service,[{name:'Service A',source:'local',command:'a'},'user']),d=Reflect.apply(second.createMCPInstall,second,[{name:'Service B',source:'local',command:'b'},'user']);
 const created=await Promise.all([c,d]),rows=JSON.parse(readFileSync(files.mcpPath,'utf8'));expect(rows).toHaveLength(5);expect(rows.map((row:{id:string})=>row.id)).toEqual(expect.arrayContaining(created.map((row:{id:string})=>row.id)));
 // Same-process/same-turn only: this does not prove multiprocess or crash recovery.
});

it('real Channel upsert retains existing credentials/extras and does not rewrite other owners',async()=>{
 const f=await fixture(),files=seed(f),before=JSON.parse(readFileSync(files.configPath,'utf8'));await f.invoke('createChannel',{type:'owned',name:'Updated Owned',webhookUrl:'https://owned.invalid/new'});
 const after=JSON.parse(readFileSync(files.configPath,'utf8'));expect(after.channels.owned).toMatchObject({name:'Updated Owned',sendMsgUrl:'https://owned.invalid/new',secret:'OWNED_CHANNEL_SECRET',future:{keep:true}});expect(after.channels.kept).toEqual(before.channels.kept);expect(after.providers).toEqual(before.providers);expect(after.models).toEqual(before.models);expect(after.future).toEqual(before.future);
});
