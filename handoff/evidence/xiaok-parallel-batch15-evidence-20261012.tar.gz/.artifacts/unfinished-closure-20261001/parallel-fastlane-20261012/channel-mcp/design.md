# Channel/MCP mutation7：未审、未应用候选

事实基准：b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1；224/298、剩74、Draft PR37 原样保留。只有本目录写入；无 commit/push/生产应用/子代理/GLM/Qoder。集成与 DESIGN/TEST_FIX/CODE 独立异模型评审 owner：01a12dcb-8ce2-7392-be2e-2ea1a5fedcc5。原验收人口、期限、baseline、失败、foreign WIP 与 native/material/P4 自动拒绝全保留；本交付不计任何关闭。

## 已亲读事实与复用

- 根 AGENTS.md、CONTEXT.md、desktop-architecture/agent-tools/verification/evidence-and-design guidance、docs/quality/lessons-ledger.md 全文已读。遵循台账 #13/#16/#22/#23；只写候选是用户最新明确授权。
- 七项 raw handler 直接调用 service，未加 typed tuple/projection 校验：`desktop/electron/ipc.ts:1314-1326`。不是“没有来源准入”：唯一 raw owner 已在 `shutdown-aware-ipc-main.ts:160-169` 准入、持有原 token；生产绑定 `main.ts:188-205` 检查 current Main/Recorder、mainFrame 和 URL。直接复用，不重设 runtime 状态2。
- 已关闭 readonly2 的批准范围及排除项：`.artifacts/unfinished-closure-20261001/channel-mcp-readonly2-20261012-recovery-r1/component-final-r1.json:7-13,30`（其历史计数不作当前计数）。复用 `channel-mcp-readonly-ipc-contract.ts:5-13` 存储/公开 schemas、`channel-mcp-readonly-typed-ipc.ts:15-19` capture/intrinsic Promise 方式，`ipc-data-snapshot.ts` 与 `ipc-native-promise.ts:8-16`；不改 Core3/readonly实现。
- 三个通道 writer/test 均调用 repair-capable loadConfig：`desktop-services.ts:3955,3980,4001,4017`；坏JSON备份移除→默认 `src/utils/config.ts:80-96`，I/O fallback默认 `:73-78`；写入整份配置 `:106-113`。MCP三个 writer catch-all默认 [] `desktop-services.ts:4030,4046,4058,5116-5122`。没有 durable MCP 安装/执行动作：这三个方法完整体 `:4028-4059` 仅写 JSON/投影；“安装成功”不能据此推断进程已运行。

## 真实 caller / owner / contract 矩阵

| IPC | 真实 Desktop UI/bridge | Main owner 与候选边界 | 正常结果、错误、lifecycle |
|---|---|---|---|
| createChannel | DesktopSettings:2104-2125；api/bridge:761-762 | strict `[input]`；支持当前表单 appId/appSecret/token/botToken/chatId + type/name/webhookUrl；禁止保留键 | 原7字段 ACK；write完成后才返回；创建按 type upsert，保旧row extras |
| updateChannel | DesktopSettings:2139-2144 toggle；bridge:764-765 | strict `[id,patch]`，enabled 与上述字段；type仅可等于id | 原DTO与 not found 语义；只改明确字段，保其它配置 |
| deleteChannel | DesktopSettings:2129-2135；bridge:767-768 | strict `[id]`，原 UI confirm 保留；service user-only | void ACK；missing id幂等，不造默认配置文件 |
| testChannel | DesktopSettings:2270-2282；bridge:770-774 | strict `[id]`；纯strict读取当前配置；原 POST；仅http(s)、无userinfo | HTTP业务false保留；网络异常固定码，不读message/getter；不重发/不加deadline；原token到settle |
| createMCPInstall | DesktopSettings:2375-2390；bridge:843-844 | strict `[input]`，name/source/command/args；source写入 npm/github/local | 原7字段ACK；真实配置落盘，不安装/执行；command、args保持Windows/空参数原ABI |
| updateMCPInstall | bridge:846-847；当前 McpPane 的本项无按钮，完整 pane `DesktopSettings:2316-2808` 只create/delete与独立plugin actions | strict `[id,patch]`；支持现公开 Partial 中args，保stored future metadata、source旧string ABI | 原toMCPView列；not found保留；完整表读坏则拒绝 |
| deleteMCPInstall | DesktopSettings:2394-2400,2794-2798；bridge:849-850 | strict `[id]`；候选新增locale删除confirm + aria-label（原生产没有confirm，依据:2394-2399） | void ACK；missing幂等；失败不刷新/不清last-good |

preload TS白名单与直连 invoke：`preload-api.ts:561-568,1261-1268,1738-1745`，不改变7个方法名/tuple ABI；CJS transport无参数或wire变更，本候选不重写它，但其已有合同测试仍须运行。新增凭证/args/update enabled TS声明在patch明确列出；renderer桥接签名同步。旧 HTTP Settings 组件的独立导入不等于上述 current Desktop RPC caller，`renderer/src/api/index.ts:1-5` 当前barrel未导出这些旧HTTP create/update/delete 函数；不删旧模块、不缩父人口，owner保其独立验收。

## 候选实现与明确取舍

1. proposal.patch 用一张七项 producer Map 替代七个 raw handle；服务调用显式追加 main-owned `'user'`，不从payload采信requestSource。新增业务owner在service内部 default deny（missing/agent/scheduler），全部7项都做同一权限控制。raw source admission仍是唯一真实窗口依据，UI confirm不是新的Main权限凭据。
2. 新 registrar input先capture再tuple schema，output先capture/schema才交给通用runtime，避免 production把错误包装成resolve `{ok:false}`；无日志URL、name、command、config；sync/native Promise均覆盖，拒getter/proxy/cycle/toJSON与恶意constructor，不retry producer，保正常producer rejection identity。rolloutRound=34是候选编号，owner应在批次统一分配/同步两union；不作为计数。
3. strict file reader ENOENT-only缺失，其余JSON/shape/I/O固定 source_unavailable，不传JSON.parse凭证片段、不改坏文件、不备份/修复。通道规范化仅用于验证，实际保存raw schema1/2及全部非目标字段；调用现 saveConfig 保原600检查。MCP完整stored数组验证、重复id拒绝、JSON extras保留，ACK仍原投影7列；单文件600，不递归目录。两个业务 edit/read/write 在同JS turn、write前无await，修本族同turn丢更新。
4. **有意行为变化必须集中审**：现UI提交的凭证被丢弃（`desktop-services.ts:3983-3988` 只写name/sendMsgUrl/inboundMode/enabled，而表单 `DesktopSettings:2034-2075,2115-2118` 传其他字段）。候选按UI原字段名保存，不发明provider转换；不声称这些凭证已被运行时消费。upsert保extras、raw schema1不迁移、update args落盘、禁止prototype key/type改名、MCP删除confirm均为明确设计选择，不能未经DESIGN批准应用。
5. UI候选保既有读取owner、mutation成功后load、action/read错误独立；catch只展示本地化固定失败，test已知技术码映射既有失败label，HTTP业务失败保留。原失败会透出message的证据 `DesktopSettings:2124-2125,2134-2135,2143-2144,2277-2280,2389-2399`。三locale在patch，不编辑生产locale。

## 同权限兄弟入口及仍缺的 controls（禁止全族安全完成宣称）

| 兄弟/风险 | 亲读依据 | 本轮边界 / owner仍须闭合 |
|---|---|---|
| 通道实际发送/列表agent工具 | desktop-services:2890-2909,2913-2955，permission='safe' | 仍loadConfig repair；list公开URL、send异常message与POST可旁路本轮test限制。未改registry工具，不声称发送权限/secret全部安全 |
| config全份writer及CLI/agent文件能力 | desktop-services:3338/3382,3433-3435,3468-3470,3477-3484,3565-3579；src/commands/config:297-366；src/commands/yzj:658-659 | 旧writer悬挂快照仍可覆盖本候选的新编辑；Core saveConfig非原子事务、不提供跨进程锁/失败回滚；不改共享Core，all-writer验收保父门 |
| 同窗口saveFile直接写配置或MCP文件 | ipc:1584-1598，仅html/text-edit分支特殊校验，普通写直接writeFile | 七项schema不能替代文件能力政策；本轮无零成本绕过已闭合声称，独立父权限范围仍OPEN |
| 凭证投影ABI | readonly契约:5-10 / readonly-data:30 | webhook URL和MCP command/args仍原公开内容，MCP readonly passthrough extras仍可含env等信息；只有新credential字段不进入mutation Channel ACK，不宣称所有secret都隐藏 |
| 实际通道支持/确认 | DesktopSettings:2034-2075,2129-2130,2270-2273,2394-2399 | 凭证消费、不同通道真正消息协议、test发送预期、Main用户意图证明需owner验收；未新增确认token/自动权限放行 |
| 生命周期/平台/失败完整性 | shutdown-aware-ipc-main:160-169；新UI仍沿原lifetime | 已写network-held真实token测试；UI并发点击/迟到action覆盖新locale或unmount、成功ACK后读失败、Windows ACL/NTFS/symlink/hardlink、partialwrite/崩溃恢复/多进程互斥仍缺完整controls。POSIX EACCES/writefail候选仅nonroot非Windows，不能替代Windows证据 |

## 测试与集成顺序

- `red.test.ts` 拷至 `desktop/tests/main/channel-mcp-mutation-controls.test.ts`；真实 createDesktopServices/registerDesktopIpc + 生产 authorizeDesktopInvoke AST，无自造业务逻辑。`ui-red.test.tsx` 拷至 `desktop/tests/renderer/channel-mcp-mutation-ui.test.tsx`；真实页面/bridge，只替window transport。没有运行，不能写“已观测RED”或“通过”。
- DESIGN批审后 owner先运行原head的候选RED，再按批准设计应用proposal。`fixture-source.patch` 只为既有真实service caller补显式'user'，无原assertion删除/改值，须独立TEST_FIX评审；不是缩样本/强造绿。not found原字符串已保留。
- 运行（显式worktree）：`cd /Users/kk/projects/.worktrees/unfinished-handoff-20261011/xiaok-cli/desktop && npm run test -- --run tests/main/channel-mcp-mutation-controls.test.ts tests/renderer/channel-mcp-mutation-ui.test.tsx`。
- 关联队列至少含原desktop-services、readonly controls/consumers/bridge/preload、desktop-settings-mcp-pane、preload-contract/sandbox、ipc-registrar-contract/schema-coverage，以及owner冻结的完整原人口/两完整strict noCheck:false/governance/architecture changed/newtestlint/两build/fresh CODE；本worker不跑重型验证、不更新baseline。全部实际安装/UI/native/Windows与原父门仍OPEN。
- 实际轻检查：5个候选TS/TSX transpile语法检查（不类型检查/不跑测试）；两patch `git apply --check`。`hygiene:check -- --no-fetch` exit1，sibling behind失败原样存log；完整fetch hygiene会写其它repo refs，不在唯一写目录授权内，交owner队列。结果详见 result.json。
