# Meeting mutation4：未审、未应用候选

基于完整 HEAD b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1。唯一范围是 desktop:meeting:{requestMicrophonePermission,saveAsrConfig,downloadModel,uninstallModel}；224/298、剩74、Draft PR37、原人口/期限/baseline/失败/foreign WIP 不变。runtime 状态2归集成 owner。P0/P1 的异模型 DESIGN/CODE 审查由 owner 合批；本 worker 未派代理、未启动 GLM/Qoder、未 commit/push/merge/publish、未应用源码。

## 事实与复用

亲读：ipc.ts:1817–1826,1836–1843 四个 raw handler。save 使用 input??{}、await loadConfig 后修改和保存；模型每次新建实例并 String 强制转换。loadConfig 读失败返回默认、坏JSON backup/remove：src/utils/config.ts:66–99；这对 save 也会产生“修复后成功”。现有 save 的两个 await 允许两个 writer 先各自读取再覆盖：ipc.ts:1824–1825（因果 RED 候选，未运行）。saveConfig 自身同步 chmod/write，async wrapper 无内部 await：src/utils/config.ts:102–114。

复用已批准 readonly3：meeting-readonly-data.ts:21–45（真ENOENT、固定解析码、真实 normalizer、凭证布尔投影），meeting-readonly-typed-ipc.ts:10–23（capture/nativePromise/schema），shared/meeting-readonly-ipc-contract.ts:4–6（原完整DTO）。提取已有读取函数为 readMeetingAsrConfig()，readonly 原投影行为保持。已有 owned-window 设计 .artifacts/unfinished-closure-20261001/complete-main-20261011-r1/owned-window-admission-design-r3.md；生产绑定 main.ts:188、鉴别190–206；shutdown-aware-ipc-main.ts:160–169 原 token/admission/finally；不新建通用基建。

模型 download 无跨实例互斥、uninstall 不检查正在下载：meeting-model-service.ts:270–304；directory 的 extract await 期间也可能卸载：366–402。候选仅添加同 cache/model 的 process-local 下载 lease，完整覆盖 transfer/hash retry/extraction 到 Promise settlement，finally 释放，uninstall/重复download busy reject；不同模型仍可并发。原 Range/resume/HTTP aborted/镜像/20次有限重试/hash/size/目录完整性逻辑原样保留：430–529,564–575。用户取消参数/取消IPC目前不存在，依据亲读接口63–75及 IPC1836–1843；HTTP aborted 是可重试 transport 中断，不是用户取消成功。原 shutdown token 等到真实完成，不用 Promise.race 造取消 ACK。

## 实际 caller 与 owner

preload.cjs:471–476 与 preload-api.ts:1400–1405,1964–1969 为四项真实桥接，候选类型通过 preload-api 更新；shared/desktop.ts:3 继承 FullDesktopApi（未新增独立第二份类型）。KnowledgePage.tsx:1049–1056 请求权限后继续 getUserMedia；649–685 模型动作；710–729 保存与失败。DesktopSettings.tsx:455–496 保存、501–530 模型动作。VoiceSettings.tsx:667–690 另有保存调用（是否当前运行路由由 owner 继续核，不宣称不存在）。Main 和 current Recorder 同权限域，不能把 Recorder 限成5条录音命令。

Main 的 singleton meeting mutation facade 是用户动作 owner；service 显式 source，缺失/agent/scheduler default-deny，真实窗口准入后 main 传 user，wire 不能指定 source。OS permission service 仍为事实源，Darwin prompt 实际调用 askForMediaAccess；granted/denied/restricted 不重复请求，win32/linux unknown 后继续浏览器 getUserMedia（meeting-audio-permission.ts:30–49）。facade 仅合并同一 pending OS ask，不缓存完成结果。

## 边界矩阵

|入口|输入与成功|失败/生命周期/风险|
|---|---|---|
|requestMicrophonePermission|严格[]；原 status enum|真实平台分支；同 pending ask 单飞；拒绝不伪造 granted；原物理 token|
|saveAsrConfig|严格顶层/嵌套字段、原 provider；保留[]/[null]/[undefined]/[{}]与空白secret保留、clear优先；完整原 snapshot|capture先于任何getter；真实读取→edit→sync save同turn；确认后投影ACK；坏文件不修复；固定 save_failed；secret字段不投影|
|downloadModel|严格[string]，service匹配完整原 registry，不coerce/反射未知ID；完整{ok:true,model}|原网络/断点/镜像/校验；同资源busy；真实Promise settlement前不释lease/token；不同资源并发保留|
|uninstallModel|严格[string]且完整registry；完整{ok:true,model}|download/extract期间busy；真实rm异常reject；不能把不存在文件与读取权限失败的全部问题视为已关闭|

成功输出 capture+strict schema，拒绝 getter/proxy/thenable/非法nativePromise，不兜底成void ACK或resolved error envelope；原错误只允许固定domain码，否则 action_failed，不读取 error.message getter。公开 endpoint/baseUrl 新增协议与 credential URL 检查：保留空白删除和 http/https/ws/wss 自定义地址，拒绝userinfo/query/hash；存量带凭证URL在保存前投影校验失败，避免落盘后才发现不能安全返回。这项兼容性改变须独审，不能依候选直接裁掉旧人口。

## 尚缺控制 / 集中审阻塞

1. 高风险 DESIGN 未批准；proposal.patch 是可应用性检查通过的候选，不是 production ready。
2. 活跃转录/标点模型的 lease 不在候选中：meeting-sherpa-onnx-transcriber.ts:42–58、meeting-local-transcriber.ts:37–49、meeting-punctuation-service.ts:70–74 在各自 service 使用模型；uninstallModel:297–304 没有在用检查。owner须审明确已有运行模型占用策略并补真实 service/worker held 用例，不能声称完整生命周期关闭。
3. 明确用户取消/应用退出时下载处理 policy；当前 gate只close/drain（shutdown-aware-ipc-main.ts:79–127），没有广播AbortSignal。候选保原等待事实，未新增取消入口；不能把网络aborted重试当作用户取消控制。
4. lease按resolve+Windows lowercase，未覆盖同一cache的symlink别名/跨进程writer。原全writers、WindowsNTFS/ACL/native/安装等父门继续开放；不按局部mutex宣称全局事务。
5. 保存确认失败可能已有部分写盘（src/utils/config.ts:112–113），不宣称原子/rollback；兄弟config writers仍父债务。只读整体strict I/O与 mutation getModelInfo默认existsSync差异需审；候选不重设计readonly3。
6. 需补真实TS/CJS/preload reject传播、所有真实消费者动作错误/lastgood/locale/unmount、合法Main/Recorder全链、OS请求及网络取消平台事实。未跑任何测试/严格typecheck/build/hygiene/governance；全部由owner队列，保留原失败记录和人口。

## 文件与运行

red.test.ts 拷到 desktop/tests/main/meeting-mutation-controls.test.ts；model-lifecycle.red.test.ts 拷到 desktop/tests/main/meeting-mutation-model-lifecycle.test.ts。这两个只导入现有生产registrar/service，可在未应用候选的HEAD运行，预期含行为RED，**尚未实测**。授权负例使用原Main鉴别函数AST，fixture只设置其当前窗口事实；不是重写鉴别。模型是自有临时目录小文件，实际IPC负例的ID全部非registry，避免源码RED误触真实下载/卸载。

candidate-controls.test.ts 拷到 desktop/tests/main/meeting-mutation-candidate-controls.test.ts，仅在设计审批准且owner应用之后运行；未应用时缺模块不是行为RED。producer替身仅用于真实新registrar边界恶意输出/错误通道，不替代真实业务入口用例。

从worktree/desktop运行：
`npm run test -- --run tests/main/meeting-mutation-controls.test.ts tests/main/meeting-mutation-model-lifecycle.test.ts`
应用后增加 `tests/main/meeting-mutation-candidate-controls.test.ts`，并纳入原 meeting-model-service / audio-permission / asr-config / readonly / ui / preload / e2e 原人口。heavy/strict/build及全部父验证由owner安排。三个独立module文件的首行写明目标；proposal.patch包含这些module以及ipc.ts、preload-api.ts、meeting-readonly-data.ts、meeting-model-service.ts精确预计共享编辑，不编辑main/desktop-services/bridge/locales。
