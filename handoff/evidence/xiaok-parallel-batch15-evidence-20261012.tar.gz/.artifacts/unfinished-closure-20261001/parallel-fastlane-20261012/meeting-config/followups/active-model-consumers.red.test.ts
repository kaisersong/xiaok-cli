// UNREVIEWED source-before controls. Copy to desktop/tests/main/meeting-active-model-consumers.test.ts.
// @vitest-environment node
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, expect, it, vi } from 'vitest';
import { createMeetingModelService, type MeetingModelDefinition } from '../../electron/meeting-model-service.js';
import { createLocalMeetingTranscriber } from '../../electron/meeting-local-transcriber.js';
import { createSherpaOnnxParaformerTranscriber, clearSherpaOnnxRecognizerCacheForTests } from '../../electron/meeting-sherpa-onnx-transcriber.js';
import { createMeetingPunctuationService } from '../../electron/meeting-punctuation-service.js';
import { runPunctuationWorkerRequest } from '../../electron/meeting-punctuation-worker.js';
import { encodePcm16Wav } from '../../electron/meeting-audio-format.js';
const roots: string[] = [];
afterEach(() => { vi.useRealTimers(); clearSherpaOnnxRecognizerCacheForTests(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }
function realModel(engine: 'whisper' | 'sherpa-onnx-paraformer' | 'sherpa-onnx-punctuation') {
  const root = mkdtempSync(join(tmpdir(), 'meeting-active-model-owned-')); roots.push(root);
  const cacheDir = join(root, 'cache'); mkdirSync(cacheDir);
  const bytes = Buffer.from('owned-small-model'); const directory = engine !== 'whisper';
  const definition: MeetingModelDefinition = { id: 'owned-' + engine, fileName: directory ? 'owned-model-dir' : 'owned-model.bin', url: 'https://owned.invalid/model', expectedSizeBytes: bytes.length, expectedSha256: createHash('sha256').update(bytes).digest('hex'), capability: engine === 'sherpa-onnx-punctuation' ? 'punctuation' : 'asr', engineId: engine, ...(directory ? { packageType: 'directory' as const, archiveFileName: 'owned-model.tar.bz2', requiredFiles: engine === 'sherpa-onnx-paraformer' ? ['model.int8.onnx', 'tokens.txt'] : ['model.int8.onnx'] } : {}) };
  const path = join(cacheDir, definition.fileName); if (directory) { mkdirSync(path); writeFileSync(join(path, 'model.int8.onnx'), bytes); if (engine === 'sherpa-onnx-paraformer') writeFileSync(join(path, 'tokens.txt'), 'owned\n'); } else writeFileSync(path, bytes);
  const nativeModelPath = directory ? join(path, 'model.int8.onnx') : path;
  const transfer = deferred<void>(); let transfers = 0;
  const options = { cacheDir, models: [definition], downloadFile: async (_url: string, destination: string) => { transfers++; await transfer.promise; writeFileSync(destination, bytes); }, extractArchive: async (_archive: string, destination: string) => { mkdirSync(destination, { recursive: true }); writeFileSync(join(destination, 'model.int8.onnx'), bytes); if (engine === 'sherpa-onnx-paraformer') writeFileSync(join(destination, 'tokens.txt'), 'owned\n'); } };
  const service = createMeetingModelService(options), mutationService = createMeetingModelService(options);
  expect(service.listModels()[0]?.status).toBe('downloaded');
  const audio = join(root, 'owned.wav'); writeFileSync(audio, encodePcm16Wav({ samples: new Int16Array([0, 1, -1]), sampleRate: 16000, channels: 1 }));
  return { root, cacheDir, path, nativeModelPath, definition, service, mutationService, transfer, transfers: () => transfers, audio };
}
// External native/python runtime is explicitly a held dependency. The readiness,
// model IO, transcription parsing, punctuation service and worker request logic
// below are all actual production modules; no readyModelService DTO stand-in.
async function heldConsumer(kind: 'whisper' | 'sherpa-onnx-paraformer' | 'sherpa-onnx-punctuation') {
  const f = realModel(kind), entered = deferred<void>(), finish = deferred<void>();
  let operation: Promise<unknown>;
  if (kind === 'whisper') {
    const transcriber = createLocalMeetingTranscriber({ model: f.definition.id, modelService: f.service, scriptPath: join(f.root, 'owned-script.py'), exec: async () => { entered.resolve(); await finish.promise; return { stdout: JSON.stringify({ text: 'owned transcript', segments: [{ start: 0, end: 1, text: 'owned transcript' }] }) }; } });
    operation = transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned' });
  } else if (kind === 'sherpa-onnx-paraformer') {
    const transcriber = createSherpaOnnxParaformerTranscriber({ model: f.definition.id, modelService: f.service, loadRuntime: async () => ({ OfflineRecognizer: { createAsync: async () => ({ createStream: () => ({ acceptWaveform() {} }), decodeAsync: async () => { entered.resolve(); await finish.promise; return { text: 'owned transcript' }; } }) } }) });
    operation = transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned' });
  } else {
    const punctuation = createMeetingPunctuationService({ modelId: f.definition.id, modelService: f.service, runPunctuationWorker: async input => {
      const result = await runPunctuationWorkerRequest(input, { loadRuntime: async () => { entered.resolve(); await finish.promise; return { OfflinePunctuation: class { constructor(config: { model: { ctTransformer: string } }) { expect(config.model.ctTransformer).toBe(f.nativeModelPath); } addPunct(text: string) { return text + '。'; } } }; } });
      if (!result.ok) throw Error(result.error); return result.text;
    } });
    operation = punctuation.restoreFinalPunctuation({ text: '本次真实服务测试只使用自有数据', segments: [], language: 'zh' });
  }
  await entered.promise;
  return { ...f, finish, operation };
}
it.each(['whisper', 'sherpa-onnx-paraformer', 'sherpa-onnx-punctuation'] as const)('actual active %s consumer blocks uninstall until physical completion', async kind => {
  const f = await heldConsumer(kind); let error: unknown; let existsDuring = false;
  try { try { f.mutationService.uninstallModel(f.definition.id); } catch (value) { error = value; } existsDuring = existsSync(f.nativeModelPath); }
  finally { f.finish.resolve(); f.transfer.resolve(); await f.operation; }
  expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(existsDuring).toBe(true);
  expect(f.mutationService.uninstallModel(f.definition.id).model.packageState).toBe('missing');
});
it.each(['whisper', 'sherpa-onnx-paraformer', 'sherpa-onnx-punctuation'] as const)('actual active %s consumer blocks overwrite/download before any transfer work', async kind => {
  const f = await heldConsumer(kind); let error: unknown; const action = f.mutationService.downloadModel(f.definition.id).catch(value => { error = value; });
  await Promise.resolve(); const before = f.transfers(), retained = readFileSync(f.nativeModelPath);
  f.finish.resolve(); f.transfer.resolve(); await Promise.all([f.operation, action]);
  expect(before).toBe(0); expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(retained.toString()).toBe('owned-small-model');
  expect((await f.mutationService.downloadModel(f.definition.id)).model.status).toBe('downloaded');
});
it('two actual consumers of one resource require both completions before uninstall', async () => {
  const f = realModel('whisper'), entered = deferred<void>(), first = deferred<void>(), second = deferred<void>(); let calls = 0;
  const transcriber = createLocalMeetingTranscriber({ model: f.definition.id, modelService: f.service, scriptPath: join(f.root, 'owned.py'), exec: async () => { const number = ++calls; if (calls === 2) entered.resolve(); await (number === 1 ? first.promise : second.promise); return { stdout: '{"text":"owned transcript"}' }; } });
  const a = transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned-a' }), b = transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned-b' }); await entered.promise;
  first.resolve(); await a; let error: unknown;
  try { f.mutationService.uninstallModel(f.definition.id); } catch (value) { error = value; } finally { second.resolve(); await b; }
  expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(f.mutationService.uninstallModel(f.definition.id).ok).toBe(true);
});
it('Sherpa logical timeout does not release an active physical decode lease', async () => {
  vi.useFakeTimers(); const f = realModel('sherpa-onnx-paraformer'), entered = deferred<void>(), finish = deferred<void>();
  const transcriber = createSherpaOnnxParaformerTranscriber({ model: f.definition.id, modelService: f.service, loadRuntime: async () => ({ OfflineRecognizer: { createAsync: async () => ({ createStream: () => ({ acceptWaveform() {} }), decodeAsync: async () => { entered.resolve(); await finish.promise; return { text: 'owned' }; } }) } }) });
  const result = transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned' }).catch(error => error); await entered.promise;
  // Preserve the production 30-minute default budget; advance only virtual time.
  await vi.advanceTimersByTimeAsync(30 * 60 * 1000 + 1); expect((await result).message).toBe('sherpa_onnx_transcribe_timeout');
  let error: unknown; try { f.mutationService.uninstallModel(f.definition.id); } catch (value) { error = value; } finally { finish.resolve(); await Promise.resolve(); }
  expect(error).toMatchObject({ message: 'meeting_model_busy' });
});
it('actual failed local transcription releases its resource for uninstall', async () => {
  const f = realModel('whisper'); const transcriber = createLocalMeetingTranscriber({ model: f.definition.id, modelService: f.service, scriptPath: join(f.root, 'owned.py'), exec: async () => { throw Error('owned-native-failure'); } });
  await expect(transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned' })).rejects.toThrow('owned-native-failure'); expect(f.mutationService.uninstallModel(f.definition.id).ok).toBe(true);
});
it('an active real download prevents a new local consumer before invoking Python', async () => {
  const f = realModel('whisper'); let executions = 0;
  const download = f.mutationService.downloadModel(f.definition.id);
  const transcriber = createLocalMeetingTranscriber({ model: f.definition.id, modelService: f.service, scriptPath: join(f.root, 'owned.py'), exec: async () => { executions++; return { stdout: '{"text":"owned transcript"}' }; } });
  const result = transcriber.transcribeFile({ audioFilePath: f.audio, meetingId: 'owned' }).catch(error => error);
  const value = await result; f.transfer.resolve(); await download;
  expect(executions).toBe(0); expect(value).toMatchObject({ message: 'meeting_model_busy' });
});
it.each(['whisper', 'sherpa-onnx-punctuation'] as const)('active %s consumer protects the same cache through a symlink/junction alias', async kind => {
  const f = await heldConsumer(kind), alias = join(f.root, 'alias'); symlinkSync(f.cacheDir, alias, process.platform === 'win32' ? 'junction' : 'dir'); expect(realpathSync(alias)).toBe(realpathSync(f.cacheDir));
  const mutation = createMeetingModelService({ cacheDir: alias, models: [f.definition] }); let error: unknown, retained = false;
  try { try { mutation.uninstallModel(f.definition.id); } catch (value) { error = value; } retained = existsSync(f.nativeModelPath); }
  finally { f.finish.resolve(); await f.operation; }
  expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(retained).toBe(true); expect(mutation.uninstallModel(f.definition.id).ok).toBe(true);
});
it('an active consumer does not block lifecycle work on an unrelated model in the same cache', async () => {
  const f = await heldConsumer('whisper'), definition = { ...f.definition, id: 'owned-unrelated', fileName: 'unrelated.bin' }; writeFileSync(join(f.cacheDir, definition.fileName), Buffer.from('owned-small-model'));
  const other = createMeetingModelService({ cacheDir: f.cacheDir, models: [f.definition, definition] });
  let result: unknown, retained = false;
  try { result = other.uninstallModel(definition.id); retained = existsSync(f.nativeModelPath); } finally { f.finish.resolve(); await f.operation; }
  expect(result).toMatchObject({ ok: true, model: { id: definition.id, status: 'not_downloaded' } }); expect(retained).toBe(true);
});
