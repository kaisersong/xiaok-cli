# 冻结原候选后的补充控制（未运行、未审、未应用）

只写 followups/，不重写原 design/result/proposal。原15入口批DESIGN与9files248=87pass161fail是owner消息所述，**转引、未在本worker复测**；本目录新增用例不冒充该票人口或运行结果。不派代理、不启动GLM/重型验证/提交，不重试或改名原native/material/P4自动拒绝候选。

## 退出 / 取消的准确现状

- 四项中“用户取消模型下载”接口不存在：亲读 meeting-model-service.ts:63–75、ipc.ts:1836–1843、preload.cjs:475–476。download仅接受id，低层HTTP请求/响应/文件句柄局部持有：meeting-model-service.ts:467–529；res.aborted → fail/destroy transport →有限retry/mirrors，依据508、430–448、451–464、564–575。网络aborted不得表述为用户取消完成；原自有断点续传/校验/镜像/重试人口须保留。
- **直播取消实际存在**：ipc.ts:2004–2017 根据真实sender/session选择Aliyun/Volcengine registry.cancel并清session；不能因模型没有cancel API，写成“meeting没有取消”。此直播操作不取消本地模型下载/Whisper进程/Sherpa decode/标点worker。它不在本轮四项的新合同中。
- app shutdown原 gate.close先拒新invoke，已有invoke一直持有物理token到callback finally：shutdown-aware-ipc-main.ts:79–127,160–169。Main生产绑定main.ts:188,228–254,262；Coordinator关闭gate、销毁窗口、停止/abort**已注册**ingress并同时drain，普通期限原5s/保护cap原34s：desktop-shutdown-coordinator.ts:104–115,128–155。
- 这不是“所有任务最多等待5s再取消成功”：超时后outstanding/失败事实仍在；不close stores/不release source pin，记deferred，仍清理独立lifetime并调用continuation：desktop-shutdown-coordinator.ts:164–202。Main已登记ingress为goal(736)、loop输出/视图/发布(1146–1153)、timed scheduler(1638–1643)；meeting recorder dispose在main.ts:1949–1953。上述实际注册没有模型download ingress/abort hook，模型接口也无abort/dispose，因此本轮不声称退出已能确认取消模型传输。
- 本目录 physical-worker-exit.red.test.ts 最后一项调用真实model service + ShutdownAwareIpcMain + DesktopShutdownCoordinator，**虚拟时间推进原5s，不改生产期限**：要求held下载未完成时ordinaryDrained=false/storesClosed=false/deferred、token仍1；随后只在fixture释放真实adapter工作后才成功ACK。它刻画当前策略，不改app.quit，不是实际OS退出/网络取消票。

最小保守策略：本次四项仍不新增cancel入口/AbortSignal，也不以Promise.race释放token；window隐藏/renderer卸载不等于授权取消main下载。退出仍执行既有deferred策略。若父验收要求确认取消，必须owner单独补设计+真实transfer/response/file/extractor/process终止确认及旧重试条件；不可凭这个目录宣称满足。用户cancel未来必须有固定取消失败码与**物理关闭确认**，不能用live:cancel替身或假的void成功。

## 模型占用与alias边界

真实调用链：Whisper在meeting-local-transcriber.ts:35–74 readiness后await exec；Sherpa在meeting-sherpa-onnx-transcriber.ts:47–101 readiness、runtime/create/decode，私有withTimeout:153–166只逻辑reject，没有terminate确认；标点service:107–123 readiness后await worker，实际worker request:27–45 await runtime，thread controller service:271–301 timeout/message/error触发terminate但**不await terminate Promise就settle**。这些“没有物理确认”均为亲读上述行，不是转引。

active-model-consumers.red.test.ts全部使用真实createMeetingModelService与自有小文件/目录，三个实际consumer而非手造ready模型DTO。外部Python/native runtime是明确的held依赖；标点同时调用实际runPunctuationWorkerRequest。控制包括active消费者×download/uninstall、双reader计数、失败释放、writer持有时禁止新consumer、Sherpa默认30分钟逻辑超时仍保护未完成decode。它们在当前HEAD和原仅download Set候选上可能仍RED，不能应用原候选后直接关闭model lifecycle。

cache-alias.red.test.ts真实创建symlink（Windows为junction），确认realpath相同，再跨两个真实service实例请求download/卸载。原proposal resolve+lowercase不能等同物理资源唯一身份，故保留此新增负例。未mock fs/realpath，未静默skip权限失败；Windows无创建资格的失败须如实留票。

owner整合方向（尚需批审）：同一真实cache资源持有reader计数+exclusive writer，read acquisition与writer冲突default拒，reader互相允许；writer覆盖下载、校验、重新下载和extract，卸载覆盖实际rm，均finally释放；read不能覆盖readonly list污染其合法观察人口。物理readerlease要从真实consumer开始，覆盖Python exec/native create+decode/标点workerrequest到实际工作完成；Sherpa的逻辑timeout与thread早settle不能作为释放点。物理取消失败维持busy/诊断，不形成永久“成功取消”。模型service、三consumer与worker controller改动必须统一owner实现和binder控制，别仅在IPC facade加计数。

cache身份基于真实父cache路径（已有cache realpath；未创建cache从最近已有ancestor的realpath加固定suffix推导），Windows比较规则经Windows验证；不能把unknown path/wire id当授权。symlink目标更换、跨进程与外部writer属于仍开的父资源边界，局部内存registry不声称OS文件锁或全writers完成。

physical-worker-exit.red.test.ts前三项提取生产私有runPunctuationWorkerThread body，注入held Worker adapter，只替换import.meta宿主URL；逻辑未重写。分别message/timeout/error均要求物理terminate Promise未完成前不得settle。adapter不是native线程，不启动真实worker或网络；真实worker/native termination仍需owner原验收队列，不能把源码票当成native票。

## VoicePane实际动作链与预期

DesktopSettings.tsx:304 真正挂VoicePane；345–368状态、454–497 save、500–531 download/uninstall、623–627 readonly独立告警/retry、784–790 saved/action错误。useMeetingReadonly.ts:4–15使用真实read owner；useSkillReadonly.ts:19–35,40–56在locale/unmount使旧read失效。VoicePane动作自己的catch却把当时t格式化字符串放state（494/512/529），在旧locale pending后reject或已有error再切locale时不能自动得到新locale文字，依据亲读这些代码；新UI用例对此保留因果RED，不先改locales/共享源码。

voicepane-actions.red.test.tsx实际render DesktopSettings选择voice，保留实际VoicePane、LocaleProvider、readonly hooks，仅mock外部preload。涵盖：真实保存参数与失败不清secret草稿、不假saved、不自动重试；download/uninstall失败不被readonly重读清掉；三动作late rejection使用当前locale；旧save错误随locale变化重新投影；成功save之后readonly失败显示“已保存”和独立读取告警、清secret草稿并用ACK公开字段，不把读取错变动作失败；save失败后读取失败保lastgood与动作错；三动作unmount后的成功/失败都不得触发旧scope successor读取或覆盖新VoicePane。

这些页面测试不声称真IPC/native链；原proposal candidate-controls、真实registrar RED和TS/CJS入口控制仍须owner全部运行。并发动作禁止、成功动作后的真实readonly失败、没有偷偷自动重试等都保留原权限/读取人口。

## 拷贝与命令（未执行）

|候选|实际目标|
|---|---|
|active-model-consumers.red.test.ts|desktop/tests/main/meeting-active-model-consumers.test.ts|
|cache-alias.red.test.ts|desktop/tests/main/meeting-cache-alias.test.ts|
|physical-worker-exit.red.test.ts|desktop/tests/main/meeting-physical-worker-exit.test.ts|
|voicepane-actions.red.test.tsx|desktop/tests/renderer/meeting-voicepane-actions.test.tsx|

owner从worktree/desktop运行：
`npm run test -- --run tests/main/meeting-active-model-consumers.test.ts tests/main/meeting-cache-alias.test.ts tests/main/meeting-physical-worker-exit.test.ts tests/renderer/meeting-voicepane-actions.test.tsx`

不要把新增文件“存在/解析成功”写成RED实测；也不要以预期RED替代已有全量票、typecheck/build、真实OS/native/安装/Windows验证。这批只补候选，原count/期限/baseline/失败/foreign WIP完全不改。
