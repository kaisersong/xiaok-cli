# VoicePane lifecycle r2 — 候选尚未应用

owner授权以批DESIGN/UIlifecycle条件为依据，仅VoicePane与真实UI测试；等待owner真RED授权后应用UI。原artifact全冻结，不改ChannelsPane/McpPane/其它函数/imports/Core/model-service/cancel/lease/alias策略，不跑heavy/GLM/commit。

亲读 DesktopSettings.tsx:454–531：saving/modelAction只用React state阻挡，catch存已格式化旧locale文本，动作await之后无自身mount身份检查。readonly owner在useSkillReadonly.ts:19–35,40–56已有lastgood/locale/unmount失效；VoicePane不能用它代替动作回执owner，也不创建第二个读取owner。

候选只修改函数片段：mount-only动作owner ref，save与模型分别同步单飞（model共享download/uninstall槽），每个await后先确认同一active owner才读取/写状态；finally释放本动作槽，当前owner才更新UI。locale变化不擅自取消已授权main动作，存reason在当前t渲染，所以pending和已有错误均当前语言。手工readonly重读不清动作错误。

save参数/persist choice/空secret/confirmed ACK保持原样：先确认保存，随后仍通过已有asrFacts.reload；读取失败由readonly hook独立告警并保其原lastgood，不能造默认健康或把save变失败；成功后清提交凭证草稿并用保存ACK公开字段，显示saved。既有主进程fullDTO审与服务事实维持。未新增cancel/lease/第二轮询，也未改原成功动作重读及legacy ok:false测试人口。

真实test从冻结followup原样拷入desktop/tests/renderer/meeting-voicepane-actions.test.tsx（只移artifact首行），全部原断言保留，另加save重复click/model跨模型相反动作在同JS turn的同步重入控制。实际render DesktopSettings私人VoicePane/LocaleProvider/readonly hooks，只mock外部preload，不自造UI实现。测试未跑，owner统一真RED票。

proposal.patch只含VoicePane hunks；before/after文件只有函数本体。应用时fresh读共享文件，核当前唯一VoicePane片段与before SHA一致，仅replace该唯一片段，严禁把旧wholefile snapshot覆写到频道worker改动。若片段变了要重新对照，不盲apply；body SHA在scope/result。

Owner run（本worker未执行）：cd desktop && npm run test -- --run tests/renderer/meeting-voicepane-actions.test.tsx tests/renderer/meeting-readonly-consumers.test.tsx。trueRED授权后应用再GREEN；完整13files331只是owner转引，未复测，不抵消新失败/旧人口/原期限/224/298/父门。
