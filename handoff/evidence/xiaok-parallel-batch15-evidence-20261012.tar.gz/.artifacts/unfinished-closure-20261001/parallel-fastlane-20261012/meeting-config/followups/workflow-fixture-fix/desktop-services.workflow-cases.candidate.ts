// REVIEW FRAGMENTS ONLY. Apply proposal.patch hunks to existing suite; do not run as a separate test population.
  it('runs a task workflow node without reporting system plan artifacts as deliverables', async () => {
    const owned = await openOwnedWorkflowNormalCase({"project":{"id":"proj-workflow","name":"Workflow project","goal":"Verify workflow"},"issuer":"po-generated-task","tasks":[{"id":"proj-workflow__item-1","title":"Write final report","assignedAgent":"xiaok-worker","acceptanceCriteria":"必须包含真实 workflow run ID。","requiredOutputs":["markdown"]}],"taskId":"proj-workflow__item-1","now":1});
    let services: ReturnType<typeof createDesktopServices> | undefined;
    try {
    const workFolder = owned.fixture.workspace.path;
    const artifactsDir = join(workFolder, 'artifacts');
    const finalArtifactPath = join(artifactsDir, 'workflow-final-report.md');
    const planArtifactPath = join(artifactsDir, 'plan-v1.md');
    let receivedPrompt = '';
    services = createDesktopServices({
      dataRoot: join(rootDir, 'data'),
      kswarmService: owned.kswarmService,
      now: () => 300,
      runner: async ({ prompt, emitRuntimeEvent, sessionId }) => {
        receivedPrompt = prompt;
        mkdirSync(artifactsDir, { recursive: true });
        writeFileSync(planArtifactPath, '# System plan');
        writeFileSync(finalArtifactPath, '# Final report');
        emitRuntimeEvent({
          type: 'receipt_emitted',
          sessionId,
          turnId: 'turn_1',
          intentId: 'intent_1',
          stepId: 'step_1',
          note: JSON.stringify({
            output: {
              summary: '最终报告已生成。',
              artifacts: [{ path: finalArtifactPath, kind: 'markdown', label: 'workflow-final-report.md' }],
              evidenceRefs: [`artifact:${finalArtifactPath}`],
            },
          }),
        });
      },
    });

    const result = await services.runKSwarmWorkflowNode({
      handoff: owned.handoff,
      targetParticipantId: 'xiaok-worker',
    });

    expect(receivedPrompt).toContain('真实 workflow run ID 是 wf-proj-workflow-po-generated-task-workflow-1');
    expect(result.output?.artifacts).toEqual([
      { path: 'artifacts/workflow-final-report.md', kind: 'markdown', label: 'workflow-final-report.md' },
    ]);
    expect(result.output?.evidenceRefs).toEqual(['artifact:artifacts/workflow-final-report.md']);
    } finally { await owned.close(services); }
  });

  it('runs a project workflow node as a whole-project deliverable producer', async () => {
    const owned = await openOwnedWorkflowNormalCase({"project":{"id":"proj-project-workflow","name":"Workflow project","goal":"Deliver whole project"},"issuer":"po-generated-project","tasks":[{"id":"item-1","title":"收集资料","assignedAgent":"xiaok-worker"},{"id":"item-2","title":"生成最终报告","assignedAgent":"xiaok-worker"}],"now":1});
    let services: ReturnType<typeof createDesktopServices> | undefined;
    try {
    const workFolder = owned.fixture.workspace.path;
    const artifactsDir = join(workFolder, 'artifacts');
    const finalArtifactPath = join(artifactsDir, 'project-final-report.md');
    let receivedPrompt = '';
    services = createDesktopServices({
      dataRoot: join(rootDir, 'data'),
      kswarmService: owned.kswarmService,
      now: () => 300,
      runner: async ({ prompt, emitRuntimeEvent, sessionId }) => {
        receivedPrompt = prompt;
        mkdirSync(artifactsDir, { recursive: true });
        writeFileSync(finalArtifactPath, '# Project final report');
        emitRuntimeEvent({
          type: 'receipt_emitted',
          sessionId,
          turnId: 'turn_1',
          intentId: 'intent_1',
          stepId: 'step_1',
          note: JSON.stringify({
            output: {
              summary: '项目最终报告已生成。',
              artifacts: [{ path: finalArtifactPath, kind: 'markdown', label: 'project-final-report.md' }],
              evidenceRefs: [`artifact:${finalArtifactPath}`],
            },
          }),
        });
      },
    });

    const result = await services.runKSwarmWorkflowNode({
      handoff: owned.handoff,
      targetParticipantId: 'xiaok-worker',
    });

    expect(receivedPrompt).toContain('执行整个项目');
    expect(receivedPrompt).toContain('最终项目交付物');
    expect(receivedPrompt).toContain('真实 workflow run ID 是 wf-proj-project-workflow-po-generated-project-workflow-1');
    expect(receivedPrompt).not.toContain('sourceTask 是唯一工作范围');
    expect(result.output?.artifacts).toEqual([
      { path: 'artifacts/project-final-report.md', kind: 'markdown', label: 'project-final-report.md' },
    ]);
    expect(result.output?.evidenceRefs).toEqual(['artifact:artifacts/project-final-report.md']);
    } finally { await owned.close(services); }
  });

