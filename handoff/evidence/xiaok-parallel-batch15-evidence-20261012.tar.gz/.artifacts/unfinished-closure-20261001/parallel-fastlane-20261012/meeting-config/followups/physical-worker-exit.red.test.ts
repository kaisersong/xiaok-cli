// UNREVIEWED source-before controls. Copy to desktop/tests/main/meeting-physical-worker-exit.test.ts.
// @vitest-environment node
import { EventEmitter } from 'node:events';
import { readFileSync, mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { compileFunction } from 'node:vm';
import ts from 'typescript';
import { afterEach, expect, it, vi } from 'vitest';
import { createMeetingModelService } from '../../electron/meeting-model-service.js';
import { DesktopShutdownCoordinator } from '../../electron/desktop-shutdown-coordinator.js';
import { DesktopShutdownGate, ShutdownAwareIpcMain, type IpcHandlerListener } from '../../electron/shutdown-aware-ipc-main.js';
const roots: string[] = [];
afterEach(() => { vi.useRealTimers(); for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(r => { resolve = r; }); return { promise, resolve }; }
function actualThreadController() {
  // Extract exactly the private production owner; this does not copy/rewrite its
  // message/timeout/error/terminate logic. Worker dependency is a held adapter,
  // explicitly not proof of native thread termination or OS ownership.
  const source = readFileSync(new URL('../../electron/meeting-punctuation-service.ts', import.meta.url), 'utf8');
  const ast = ts.createSourceFile('meeting-punctuation-service.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = ast.statements.find((node): node is ts.FunctionDeclaration => ts.isFunctionDeclaration(node) && node.name?.text === 'runPunctuationWorkerThread'); expect(declaration).toBeDefined();
  const termination = deferred<number>(); let worker!: EventEmitter; let terminateCalls = 0;
  class WorkerAdapter extends EventEmitter {
    constructor(url: URL, options: { execArgv: unknown[] }) { super(); expect(url.pathname.endsWith('meeting-punctuation-worker.js')).toBe(true); expect(options.execArgv).toEqual([]); worker = this; }
    terminate() { terminateCalls++; return termination.promise; }
  }
  const body = declaration!.getText(ast).replace('import.meta.url', 'entryUrl');
  const code = ts.transpileModule(body + '\nreturn runPunctuationWorkerThread;', { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  const run = compileFunction(code, ['Worker', 'URL', 'entryUrl', 'setTimeout', 'clearTimeout'])(WorkerAdapter, URL, new URL('../../electron/meeting-punctuation-service.ts', import.meta.url).href, setTimeout, clearTimeout) as (input: { text: string; modelPath: string }, timeout: number) => Promise<string>;
  return { run, worker: () => worker, termination, terminateCalls: () => terminateCalls };
}
it.each(['message', 'timeout', 'error'] as const)('actual punctuation thread owner waits for physical termination after %s', async cause => {
  vi.useFakeTimers(); const f = actualThreadController(); let settled = false, result: unknown;
  const operation = f.run({ text: 'owned text', modelPath: join(tmpdir(), 'owned-small-model.int8.onnx') }, 30000).then(value => { settled = true; result = value; }, error => { settled = true; result = error; });
  if (cause === 'message') f.worker().emit('message', { ok: true, text: 'owned text。' });
  else if (cause === 'error') f.worker().emit('error', Error('owned-worker-failure'));
  else await vi.advanceTimersByTimeAsync(30000);
  await Promise.resolve(); const beforePhysicalExit = settled; const calls = f.terminateCalls();
  f.termination.resolve(0); await operation;
  expect(calls).toBe(1); expect(beforePhysicalExit).toBe(false);
  if (cause === 'message') expect(result).toBe('owned text。'); else expect(result).toMatchObject({ message: cause === 'timeout' ? 'punctuation_timeout' : 'owned-worker-failure' });
});
it('actual shutdown times out a held model download without claiming cancellation or closing stores', async () => {
  vi.useFakeTimers(); const cacheDir = mkdtempSync(join(tmpdir(), 'meeting-shutdown-download-owned-')); roots.push(cacheDir);
  const bytes = Buffer.from('owned-model'), held = deferred<void>();
  const model = { id: 'owned', fileName: 'owned.bin', url: 'https://owned.invalid', expectedSizeBytes: bytes.length, expectedSha256: createHash('sha256').update(bytes).digest('hex') };
  const service = createMeetingModelService({ cacheDir, models: [model], downloadFile: async (_url, path) => { await held.promise; writeFileSync(path, bytes); } });
  const gate = new DesktopShutdownGate(); let listener!: IpcHandlerListener;
  const ipc = new ShutdownAwareIpcMain({ handle: (_channel, value) => { listener = value; } }, gate); ipc.handle('owned:held:model-download', () => service.downloadModel('owned'));
  let completed = false; const action = Promise.resolve(listener({} as never)).then(value => { completed = true; return value; });
  let closed = 0, pins = 0, continued = 0;
  const coordinator = new DesktopShutdownCoordinator({ gate, providerRuntime: { beginShutdown: () => ({ leases: [], waitForSettled: async () => true }), hideAndAbortNonProtected() {}, closeOrdinaryProviders: async () => ({ cleanupFailed: [] }) }, ingressOwners: [], durableStores: [{ name: 'owned', close: async () => { closed++; } }], destroyWindows() {}, disposeLifetimeResources: async () => {}, releaseMainSourcePin: async () => { pins++; }, continuation() { continued++; } });
  const shutdown = coordinator.onBeforeQuit(); expect(shutdown.preventDefault).toBe(true); expect(gate.isOpen).toBe(false);
  await vi.advanceTimersByTimeAsync(5000); const report = await shutdown.shutdown;
  const unfinishedAtContinuation = !completed, tokensAtContinuation = gate.outstanding;
  held.resolve(); const value = await action;
  expect(report).toMatchObject({ ordinaryDrained: false, storesClosed: false, deferredReason: 'store_close_deferred_to_process_exit' });
  expect(continued).toBe(1); expect(closed).toBe(0); expect(pins).toBe(0); expect(unfinishedAtContinuation).toBe(true); expect(tokensAtContinuation).toBe(1);
  expect(value).toMatchObject({ ok: true }); expect(gate.outstanding).toBe(0);
});
