# 两旧 workflow 测试 genuine fixture TEST_FIX 候选（未应用）

只新增此目录；生产/共享测试源码一律未编辑。owner已说明旧2case在隔离b757基线也失败，此为转引，worker未复测；187定向skip不当全部资格。不运行heavy/GLM/commit，不改assertion或重试原native/material/P4自动拒绝。

亲读 desktop/tests/main/desktop-services.test.ts:689–749,751–811，两项仍用mockKSwarmService和手造handoff。品牌门kswarm-service.ts:706–718读取工厂私有WeakMap与真实request方法身份，旧mock没有该登记，必先throw kswarm_workflow_read_instance_unknown；不能给mock加同名方法/借方法/修改品牌门。

复用已存在 desktop/tests/support/owned-workflow-normal-case.ts:7–25：实际createKSwarmService、真实forwardedFetch、同自有HTTP+SQLite服务、sealAndDrain与fixture.close完整回收；不新建框架。其依赖owned-workflow-network-fixture.mjs:35–49目前只有builtin-smoke/script issuer分支，二者不能产生原PO task/project prompt分支（生产desktop-services.ts:4333–4392）。

proposal.patch仅3个测试域文件：在现有helper扩选项联合类型；现有network fixture增加po-generated-task/project publicHub分支；两旧例改用owned.kswarmService与owned.handoff及真实workspace，finally owned.close(services)。真实issuer调用handleCreateTasks→handleApprove→createWorkflowProposal→startWorkflowRunFromProposal。亲读../kswarm/src/core/hub.js:1558–1593,1303–1329,3641–3674,3907–3963；没有篡改持久run/source/spec/权限字段，没有fake成功HTTP body，没有替换SDK.request。

固定预期wf-...-1保留，采用公开issuer的now:1参数生成真实ID：../kswarm/src/core/workflow-builtins.js:385–386,447–448。身份/attempt/handoff/node/participant一律真正dispatcher给出（hub.js:4804–4829），不保留伪wfhd-1去绕真实性检查。原sourceTask标题/acceptanceCriteria/requiredOutputs、项目目标、两项目任务标题保留；taskSnapshot task ID按真实Board归一化，不伪造原手写非规范ID。原runner prompt receipt/artifact/evidence payload全文字节不变，9条原expect表达式全文不变，test名字与prompt断言固定runID也不变；invariants.json机器对照留证。workspace改成真实fixture自有根，原相对artifact/evidenceRefs断言不变。

## 必须诚实保留的下一层阻塞

真实PO specs权限为read_project_state+write_artifact/allowWrite=true，并带allowShell/Network/Renderer=false：../kswarm/src/core/workflow-builtins.js:136,190（两worker节点:158,215）。checkpoint亲读src/runtime/task-host/workflow-restriction-checkpoint.ts:53–60,72–77：只读flag=false；有任一false即requiresReadonlyOrSuccessor；非readonly且混合限制→workflow_stored_restrictions_denied。故修掉品牌mock后，genuine issuer按当前生产仍可能暴露这个真实fail-closed缺口，**不能宣称此fixture修正即可绿色**。这是静态因果证据，尚未运行；不得清空permissions、换script source、弱化品牌门、删除expect或把native/material/P4票改名重试。

fixture patch保持权限100%真实，供TEST_FIX独审；该后续产品能力/父验收决策由owner另列，fixture不能替代artifact-only/fine-grained successor。9条旧assertion不因这个阻塞被改成expect.rejects或skip。静态syntax和apply-check不证明运行资格。

owner review后从desktop运行（worker未执行）：
`npm run test -- --run tests/main/desktop-services.test.ts -t 'runs a task workflow node without reporting system plan artifacts as deliverables|runs a project workflow node as a whole-project deliverable producer'`
仅2case定向诊断，无关skip不得作完整suite票。最终完整原suite+TEST_FIX/CODE及原全部条件仍需owner队列。

review文件：proposal.patch、两旧case片段与两个现有support候选。support .candidate是审查副本不是新framework；应用共享test必须fresh按hunk，别把wholefile旧snapshot写回。本目录不含生产补丁。
