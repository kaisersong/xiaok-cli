// UNREVIEWED source-before controls. Copy to desktop/tests/main/meeting-cache-alias.test.ts.
// @vitest-environment node
import { createHash } from 'node:crypto';
import { mkdtempSync, mkdirSync, realpathSync, symlinkSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, expect, it } from 'vitest';
import { createMeetingModelService } from '../../electron/meeting-model-service.js';
const roots: string[] = [];
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }); });
function fixture() {
  const root = mkdtempSync(join(tmpdir(), 'meeting-cache-alias-owned-')); roots.push(root);
  const cache = join(root, 'cache'), alias = join(root, 'alias'); mkdirSync(cache); symlinkSync(cache, alias, process.platform === 'win32' ? 'junction' : 'dir');
  expect(realpathSync(cache)).toBe(realpathSync(alias)); const bytes = Buffer.from('owned-model');
  const model = { id: 'owned', fileName: 'owned.bin', url: 'https://owned.invalid', expectedSizeBytes: bytes.length, expectedSha256: createHash('sha256').update(bytes).digest('hex') };
  let release!: () => void; const hold = new Promise<void>(r => { release = r; }); let calls = 0;
  const options = { models: [model], downloadFile: async (_url: string, path: string) => { calls++; await hold; writeFileSync(path, bytes); } };
  return { first: createMeetingModelService({ ...options, cacheDir: cache }), alias: createMeetingModelService({ ...options, cacheDir: alias }), release, calls: () => calls };
}
it('same real cache through a symlink/junction cannot start a second download', async () => {
  const f = fixture(); const first = f.first.downloadModel('owned'); let error: unknown;
  const duplicate = f.alias.downloadModel('owned').catch(value => { error = value; }); await Promise.resolve(); const before = f.calls();
  f.release(); await Promise.all([first, duplicate]); expect(before).toBe(1); expect(error).toMatchObject({ message: 'meeting_model_busy' });
});
it('alias uninstall cannot ACK while a real-path download remains active', async () => {
  const f = fixture(); const operation = f.first.downloadModel('owned'); let error: unknown;
  try { f.alias.uninstallModel('owned'); } catch (value) { error = value; } finally { f.release(); await operation; }
  expect(error).toMatchObject({ message: 'meeting_model_busy' }); expect(f.alias.uninstallModel('owned').model.status).toBe('not_downloaded');
});
