# skills mutation2 候选设计（未审、未应用）

基于完整 head `b7571986bd8c7d6e99383016cbf5e8c8dec5e4d1`。仅 `desktop:installSkill` / `desktop:uninstallSkill`。224/298、剩74、Draft PR37及原验收人口/期限/baseline/失败票/native/material/P4自动拒绝均不改。集成owner `01a12dcb-8ce2-7392-be2e-2ea1a5fedcc5` 统一安排不同模型 DESIGN/CODE 审、应用及重型验证；worker 未启动 GLM/Qoder、子代理、commit/push/合并/发布。

## 亲读事实与真实调用链

| 边界 | 当前代码证据（本worker亲读） | 结论 |
|---|---|---|
| 设置页真实入口 | `desktop/renderer/src/components/DesktopSettings.tsx:1809-1848` | install trim名称；uninstall先confirm；两者检查success、成功刷新、catch显示动作错误。 |
| 市场页caller | `desktop/renderer/src/components/SkillsSettingsContent.tsx:177-184`；`desktop/renderer/src/api/bridge.ts:1404-1410` | 安装adapter直接返回false；caller未检查就执行默认技能启用。delete已有false→throw。导入stub当前拒绝（`bridge.ts:1413-1422`），不能夸称市场真实安装链已验收。 |
| preload | `desktop/electron/preload-api.ts:1258-1259,1735-1736`；`desktop/electron/preload.cjs:168-169` | 原单字符串调用及 `{success,message}` DTO保留；不传renderer自称来源/路径。 |
| Main registrar | `desktop/electron/ipc.ts:1296-1306`；日志实现`:608-611` | 未做这两条的tuple/schema/capture；日志先读输入及输出success。异常对象getter/toJSON会被直接读取。 |
| service/实际副作用 | `desktop/electron/desktop-services.ts:3262-3292` | 直接同步clawhub install/uninstall；60/30秒、cwd=process.cwd()；error/nonzero返回false，status0才bump。此处没有安装文件存在/删除事实的后置核对，也没有service内requestSource限制。退出码成功不能单独证明安装目录进入catalog。 |
| catalog失效/广播 | `desktop/electron/skill-catalog-invalidation.ts:8-23`；`desktop/electron/main.ts:1733-1736` | bump版本并同步listener；listener异常不改变命令结果；Main窗口存活才广播，不是全窗口广播。 |
| runner reload | `desktop/electron/desktop-services.ts:8030-8032,8096-8109` | 非受限下一任务版本不同才reload；reload失败也推进版本，当前任务保持原目录。非“安装完成即全runner同步reload”。 |
| root可见性 | `src/ai/skills/loader.ts:541-542`；`desktop/electron/desktop-services.ts:3266,3282,8030` | loader使用global/project .xiaok roots，runner另有extraRoots；服务未传clawhub安装root。真实clawhub解析目标是否对齐尚需安装环境证据，不以推测写成不存在。 |
| 已审底座 | `desktop/electron/main.ts:188-207`；`desktop/electron/shutdown-aware-ipc-main.ts:168-179`；`desktop/electron/ipc-data-snapshot.ts:10-40`；`desktop/electron/skill-list-typed-ipc.ts:15-45` | 当前Main/Recorder/mainFrame/URL来源准入先于payload；同一个shutdown token包围handler，复用capture/nativePromise/runtime。 |
| 兄弟路径 | `desktop/electron/desktop-services.ts:2964-3029`；`src/ai/tools/uninstall-skill.ts:79-95`；`src/ai/tools/install-skill.ts:197-222` | Desktop agent工具仍permission=safe且直接spawnSync；CLI另有filesystem/git写链。本候选不改它们，不声称全部技能mutation权限已关闭。 |

优先复用已实现自动reload设计 `docs/design/2026-07-28-desktop-skill-install-auto-reload.md`，该文“现状缺口”是历史描述，以上代码才是本次事实；未找到本两条mutation独立批准票的证明，不能借readonly2批准视为本设计批准。复用readonly2现有capture/registrar模式，不引入通用基础新owner。

## 候选实现与风险

1. 新shared contract只限定原名称字符串的一参tuple；拒绝多参（包括伪造source/root）、getter/serializer、空/外边空白、路径分隔符/控制字符/盘符/`.`/`..`/开头option及>512名称。不限定ASCII slug，Unicode、内部空格、namespace均保留。512上限及盘符样式名称拒绝仍是行为增量，须审确认原caller人口，不通过缩人口拿资格。
2. 新typed registrar复用现有runtime/capture/nativePromise；先capture输入再调用producer；返回原DTO并保未知data extras；producer异常保持identity，非法ACK拒绝，不造false/true兜底。原payload/结果日志移除，避免capture前触发getter。合法Main与Recorder原人口保留。round33只是现有union可用的候选值，owner审核分配；不改runtime两处union，不改typed计数。
3. service显式要求main-owned `{requestSource:'user'}`（缺失/agent/scheduler拒绝），即使绕IPC也先验证名称；新domain module执行原流程。IPC固定注入来源，renderer不可自授来源。它不取代真实sender闸门，也不能防有能力伪造user的其他Main内部caller；agent兄弟路径未闭合必须保留风险。
4. 复用已安装cross-spawn 7.0.6的sync处理Windows .cmd（`desktop/package.json:39`），不手拼shell。保持命令、cwd、60/30秒、failure message优先级与500截断、成功时一次bump。没有改成异步/换根/重试/自动回滚。
5. 市场安装adapter像既有delete一样对业务false抛错，阻止启用默认技能。设置页继续用原DTO分支；preload/type/CJS传参返回不变，所以只增加真实双入口contract controls。

## 边界矩阵（已写候选，全部未跑）

| 控制 | 实际被调入口/外部替身 | 预期 |
|---|---|---|
| success命令/deadline/cwd | 真service+registrar；只替换OS process primitive | 参数原样；version+1；执行真实Main广播registration回调一次 |
| error/ENOENT/timeout/signal/nonzero | 同上 | false、bounded stderr/stdout优先级；零bump/广播/token泄漏 |
| missing/extra/伪来源/path/option/getter/toJSON | 真registrar+直接service | 副作用前拒绝；getter零读取 |
| direct service来源缺失/agent/scheduler/accessor | 真service | 默认拒绝；合法user路径仍成功 |
| unknown ACK/getter/toJSON/thenable | 真registrar调用可故障注入service | capture先于getter；固定边界错误；合法false+extras脱离引用 |
| service throw/reject | 真registrar | 保持原错误identity、token归零 |
| unknown/旧Main/subframe/坏URL | 真Main authorize函数+真实ShutdownAwareIpcMain | source拒绝早于payload；合法Recorder保留 |
| held/shutdown | 真registrar+held service Promise | 原5秒drain仍false、token保留，settle释放，新invoke拒绝 |
| renderer adapter业务false/transport reject | 真bridge | 安装false不能继续默认启用；delete原行为与success保留 |
| TS/CJS preload与事件dispose | 两个实际preload | 单字符串原tuple、不传source；false/reject保留；unsubscribe |

测试仅在OS process primitive替身下验证协议和因果；Main broadcaster与authorize通过AST读取真实生产语句后执行，不在测试重写其逻辑。既有runner源码扫描、catalog机制/readonly消费者controls保留，但本包不能把它们替代真实安装/native/Windows/全UI验收。

## 未闭合控制与审查重点

- 外部clawhub执行目标root、installed包可发现、卸载后确实不可用、重复安装/不存在卸载、权限拒绝、partial write后失败、symlink/Windows ACL/正常安装包：均需owner自有sandbox物理控制。服务只看exit0，无文件后验（证据见3262-3292）；不宣称已有这些保证。
- sync阻塞Main达60/30秒保留；此时UI/quit事件调度不能等价held Promise测试。Windows cross-spawn候选只有接线，尚缺真实.cmd shim/argv特殊字符/环境PATH控制。cwd root安全策略仍旧，没有偷偷改成dataRoot。
- 原工具兄弟链可绕此service；本次仅2条IPC资格，不能关闭全mutation授权。permission=safe及CLI脚本行为需父票风险保留。
- stdout/stderr原样可能含路径/凭证；候选刻意保留失败文案语义，敏感错误投影需审决策，尚缺真实错误通道秘密控制。未知DTO拒绝不等于错误脱敏。
- 市场adapter改善失败传播，仍缺实际SkillsSettingsContent失败后默认技能零写入/完整UI生命周期与本地化错误验证；现有stub不构成真实市场安装证明。
- 成功broadcast仅Main，销毁窗口跳过；listener throw被吞；runner reload失败推进version旧语义保留，需完整真实任务/多runner控制而非假绿重写。

## owner运行顺序与命令

先集中DESIGN审（P0/P1 Codex写、不同模型审）；owner将文件复制到以下实际目录，先在未应用head留RED日志，再审、应用patch。只允许owner执行这些写生产动作。

```sh
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/red.test.ts desktop/tests/main/skill-mutation-controls.test.ts
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/bridge.red.test.ts desktop/tests/renderer/skill-mutation-bridge.test.ts
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/preload.control.test.ts desktop/tests/main/skill-mutation-preload.test.ts
npm --prefix desktop run test -- --run tests/main/skill-mutation-controls.test.ts tests/main/skill-mutation-preload.test.ts tests/renderer/skill-mutation-bridge.test.ts
# 审批后由owner应用，不由worker执行：
git apply .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/proposal.patch
# 集中关联队列：
npm --prefix desktop run test -- --run tests/main/skill-mutation-controls.test.ts tests/main/skill-mutation-preload.test.ts tests/renderer/skill-mutation-bridge.test.ts tests/main/skill-reload-on-install.test.ts tests/main/skill-catalog-invalidation.test.ts tests/main/skills-readonly-controls.test.ts tests/renderer/skills-readonly-consumers.test.tsx tests/main/ipc-registrar-contract.test.ts tests/main/preload-contract.test.ts
```

worker实际只执行TypeScript syntax parse与`git apply --check`，均通过；没有运行上述测试/build/typecheck/governance/hygiene/native、没有production应用。hygiene及其它gate移交集中队列；foreign WIP `?? handoff-migration/`保留。P0/P1设计/代码批审未开始，不能宣称RED已实测或2项已关闭。
