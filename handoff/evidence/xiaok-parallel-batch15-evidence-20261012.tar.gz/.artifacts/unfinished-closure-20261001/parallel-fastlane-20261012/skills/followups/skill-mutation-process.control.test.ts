// @vitest-environment node
// Copy to desktop/tests/main/skill-mutation-process-controls.test.ts.
// Separate subprocess owns cwd, OS home, config and external command; no process.chdir in Vitest.
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createHash } from 'node:crypto';
import { afterEach, expect, it } from 'vitest';
const run = promisify(execFile), require = createRequire(import.meta.url), roots: string[] = [];
const shim = fileURLToPath(new URL('../fixtures/clawhub-owned-shim.cjs', import.meta.url));
const entry = fileURLToPath(new URL('../fixtures/skill-mutation-process-entry.ts', import.meta.url));
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }); });
function target(root: string, name: string) { return join(root, '.xiaok', 'skills', createHash('sha256').update(name).digest('hex').slice(0, 16), 'SKILL.md'); }
async function execute(mode: string, steps: Array<{ operation: 'install' | 'uninstall'; name: string }>, seed = false) {
  const root = mkdtempSync(join(tmpdir(), 'skill-process-owned-')); roots.push(root);
  const bin = join(root, 'bin'); mkdirSync(bin);
  // Actual launcher path is quoted. User operands are forwarded by the command launcher.
  if (process.platform === 'win32') writeFileSync(join(bin, 'clawhub.cmd'), `@echo off\r\n"${process.execPath}" "${shim}" %*\r\nexit /b %errorlevel%\r\n`);
  else writeFileSync(join(bin, 'clawhub'), `#!${process.execPath}\nrequire(${JSON.stringify(shim)});\n`, { mode: 0o700 });
  const sentinel = join(root, 'foreign-owned-sentinel.txt'); writeFileSync(sentinel, 'leave unchanged');
  if (seed) { const file = target(root, steps[0]!.name); mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, `---\nname: ${JSON.stringify(steps[0]!.name)}\ndescription: owned fixture\n---\nseed\n`); }
  const env = { ...process.env, PATH: bin + (process.platform === 'win32' ? ';' : ':') + (process.env['PATH'] ?? ''), XIAOK_SKILL_CASE_ROOT: root, XIAOK_SKILL_CASE_MODE: mode, XIAOK_SKILL_CASE_JSON: JSON.stringify({ steps }), XIAOK_SKILL_ARGV_SENTINEL: 'expanded_fixture_value' };
  // On Windows environment keys are case insensitive; remove other PATH spellings.
  for (const key of Object.keys(env)) if (key !== 'PATH' && key.toLowerCase() === 'path') delete (env as Record<string, unknown>)[key];
  const { stdout, stderr } = await run(process.execPath, ['--import', pathToFileURL(require.resolve('tsx')).href, entry], { cwd: root, env, timeout: 75000, maxBuffer: 4 * 1024 * 1024 });
  const line = stdout.split('\n').find(line => line.startsWith('XIAOK_SKILL_RECEIPT=')); expect(line, stderr).toBeDefined();
  const receipt = JSON.parse(line!.slice('XIAOK_SKILL_RECEIPT='.length)); expect(readFileSync(sentinel, 'utf8')).toBe('leave unchanged');
  return { root, receipt };
}
it('real service + real OS command installs discoverable owned files then removes them, with original cwd and invalidation', async () => {
  const { root, receipt } = await execute('success', [{ operation: 'install', name: 'owned-skill' }, { operation: 'uninstall', name: 'owned-skill' }]);
  expect(receipt.steps[0].result.success).toBe(true); expect(receipt.steps[0].catalog.some((row: { name: string }) => row.name === 'owned-skill')).toBe(true);
  expect(receipt.steps[1].result.success).toBe(true); expect(receipt.steps[1].catalog.some((row: { name: string }) => row.name === 'owned-skill')).toBe(false); expect(existsSync(target(root, 'owned-skill'))).toBe(false);
  for (const step of receipt.steps) { expect(step.version).toBe(step.beforeVersion + 1); expect(step.eventDelta).toBe(1); }
  expect(receipt.argv.map((row: { argv: string[] }) => row.argv)).toEqual([['install', 'owned-skill'], ['uninstall', 'owned-skill']]); expect(receipt.argv.every((row: { cwd: string }) => resolve(row.cwd) === resolve(root))).toBe(true);
}, 90000);
it.each(['wrong-root', 'zero-no-write'])('physical RED: %s exit0 must not qualify an undiscoverable install as completed', async mode => {
  const { receipt } = await execute(mode, [{ operation: 'install', name: 'owned-skill' }]);
  // Acceptance candidate intentionally exposes the still-open no-postcondition gap.
  // Do not relabel this as green by deleting the catalog assertion.
  expect(receipt.steps[0].result.success).toBe(true); expect(receipt.steps[0].catalog.some((row: { name: string }) => row.name === 'owned-skill')).toBe(true);
}, 90000);
it('CHARACTERIZATION only: partial install physically writes but returns false without invalidation', async () => {
  const { root, receipt } = await execute('partial-install', [{ operation: 'install', name: 'owned-skill' }]);
  expect(existsSync(target(root, 'owned-skill'))).toBe(true); expect(receipt.steps[0].result.success).toBe(false); expect(receipt.steps[0].catalog.some((row: { name: string }) => row.name === 'owned-skill')).toBe(true);
  expect(receipt.steps[0].version).toBe(receipt.steps[0].beforeVersion); expect(receipt.steps[0].eventDelta).toBe(0);
}, 90000);
it('CHARACTERIZATION only: partial uninstall physically removes but returns false without invalidation', async () => {
  const { root, receipt } = await execute('partial-uninstall', [{ operation: 'uninstall', name: 'owned-skill' }], true);
  expect(existsSync(target(root, 'owned-skill'))).toBe(false); expect(receipt.steps[0].result.success).toBe(false); expect(receipt.steps[0].catalog.some((row: { name: string }) => row.name === 'owned-skill')).toBe(false);
  expect(receipt.steps[0].version).toBe(receipt.steps[0].beforeVersion); expect(receipt.steps[0].eventDelta).toBe(0);
}, 90000);
it.each(['报告技能', 'team:owned-skill', 'owned skill', 'a.b_c-1'])('owned OS argv control preserves normal fixture operand %s without renaming', async name => {
  const { receipt } = await execute('success', [{ operation: 'install', name }]); expect(receipt.argv.map((row: { argv: string[] }) => row.argv)).toEqual([['install', name]]); expect(receipt.steps[0].rejected).toBeNull();
}, 90000);

it.each(['owned "quote"', 'owned%XIAOK_SKILL_ARGV_SENTINEL%', 'owned & echo ARGV_BREAK', 'owned^caret'])('owned external shim retains hostile argv operand verbatim (%s), with no expansion or extra command', async name => {
  const { receipt } = await execute('success', [{ operation: 'install', name }]);
  expect(receipt.argv.map((row: { argv: string[] }) => row.argv)).toEqual([['install', name]]);
  expect(receipt.steps[0].rejected).toBeNull();
}, 90000);
