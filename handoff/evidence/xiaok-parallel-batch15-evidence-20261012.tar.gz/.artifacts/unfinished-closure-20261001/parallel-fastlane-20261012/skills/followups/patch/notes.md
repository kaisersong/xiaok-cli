# 已批UI lifecycle候选；等待owner实测RED再应用

唯一生产目标：SkillsSettingsContent.tsx；本worker只在真实测试目录写入13例文件，生产目标SHA仍是receipt基准。既有root artifacts/followups文件不修改。

- 原install adapter已经由owner接false→throw，本UI仍显式检查success防止失败ACK续default；名称/slug/version、风险确认、default dedupe、refresh参数和GitHub/upload参保持原样。
- 页面lifetime只因unmount/accessToken换代；locale不使在途动作失效。成功安装的后续default writer只在原lifetime与当前lease下开始；已开始的Main副作用/default writer不能被UI取消或回滚，ACK后旧页面不publish/refresh。
- 页面中原parent enable/remove/disable/GitHub/upload共用一个本地default writer lease，pending时重复parent mutation不另发；这避免同一default全表并发与busy/错误旧finally覆盖。BuiltinSkillsView自己的直接override链没有改；不能据此宣称所有writer受控。
- known action error存key、渲染读取当前t.skills；原ApiError自带message分支保留，敏感错误通道仍属父债。市场读取只操作rawError，不清掉已有actionErrorKey。read-hook owner及source/cwd/deadlines未改。
- default read发布受lifetime+revision约束，writer从当前defaults ref取原完整名单；初始旧read/换tokenread不覆盖写后事实。完整跨writer事务仍非本UI保证。
- 原13例先跑RED，随后owner授权应用；worker没有运行test/build/typecheck/GLM或commit。原稿patch仅一UI文件；不新增locale key/无新通用模块。

运行：`npm --prefix desktop run test -- --run tests/renderer/skills-settings-action-controls.test.tsx`。本候选syntax-only与git apply --check通过，不能当GREEN。
