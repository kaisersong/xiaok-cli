# skills followup：真实页面与CLI验证设计（未审、未跑）

owner已报告统一RED 9files248=87pass161fail、尚未应用。该数字仅转引，worker未亲读日志/运行。原design/result/proposal及全部root文件以 `frozen-originals.json` SHA冻结；本包只新增followups。不启动GLM/Qoder、生产应用、build/完整测试/commit/push。

## 真实页面候选

`skills-settings-action.red.test.tsx` 调真实 `SkillsSettingsContent`、`ensureInstalledAndDefault`、`handleEnable`、`SkillList/BooleanSwitch`、LocaleProvider、安装adapter及api.installSkill。只替换原desktop模式不可用的market search/import/default-list接口（`desktop/renderer/src/api/bridge.ts:1400-1426`）并提供preload port。不是替换installSkill函数，也不在测试内写“安装后应如何处理”的逻辑。

亲读入口：`SkillsSettingsContent.tsx:163-184` 默认writer/安装续步骤；`:186-221` 操作错误闭包；`:93-100` refresh；`:457-459` error文本；`SkillList.tsx:203-210` busy开关；`BooleanSwitch.tsx:9-10`真实disabled/aria-checked。当前错误用useState字符串 `SkillsSettingsContent.tsx:65` 和catch的闭包locale值`:216`，没有保存错误key；当前安装成功后的writer没有在`:177-184`检查component lifetime。测试用于验证这些真实路径，不按分析预填运行结果。

候选13例：zh/en业务false默认零写入+本地化、zh/en transport reject、正常成功slug/version+默认一次写入+catalog refresh；held false/reject后当前locale；已有错误随locale更新；held成功locale切换不重发也不取消授权；busy重复点击；unmount后held success/false/reject不得使继任页面写默认或刷新。失败不显示原process/private消息。

**待审语义明确**：locale改变仅改变错误显示，仍挂载的成功流程继续原授权；unmount不能撤销已经发生的Main安装，不发送取消/卸载，但不再产生未提交的默认writer/页面refresh。若owner判定默认writer也是必须完成的durable授权事务，应在Main事务owner闭合；不把这个UI候选当成批准的取消政策。现有初版proposal只改adapter，预计不能解决错误locale及成功unmount续写，缺口保留等待批审，worker不补生产patch。

## 可直接运行的OS进程控制（surrogate，绝不算真实ClawHub）

三个文件搭配：`skill-mutation-process.control.test.ts`、`skill-mutation-process-entry.ts`、`clawhub-owned-shim.cjs`。真实进程启动真实createDesktopServices和service.listSkills；独立子进程owns cwd及data/config/Node OS account home；PATH只加自己的可执行fixture。POSIX实际执行clawhub executable，Windows实际执行.clawhub.cmd shim，生产没有mock/spawn替身。node:os homedir/userInfo是测试账户隔离，不是业务重实现；entry在隔离后动态import生产服务。父进程记录每个receipt、argv及sentinel，所有子进程有75秒timeout；不按命令名清理别人进程。

控制13例：正常install→catalog可见→uninstall不可见；wrong-root和zero-no-write的exit0真实后验RED（保持catalog断言）；partial install/uninstall真实物理写/删+false+零版本/广播的原语义characterization；四种Unicode/namespace/空格/标点名字的单argv接线；四种quote/percent/ampersand/caret真实OS接线对抗（percent使用固定fixture环境值检测展开）。partial两例即使绿也不算修复：明确测出物理事实改变而缓存不失效的债务，不删旧失败/不改期限。60000/30000来自原service，父超时75000只为含fixture初始化的测试进程，不延长业务期限。

```sh
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/followups/skills-settings-action.red.test.tsx desktop/tests/renderer/skills-settings-action-controls.test.tsx
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/followups/skill-mutation-process.control.test.ts desktop/tests/main/skill-mutation-process-controls.test.ts
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/followups/skill-mutation-process-entry.ts desktop/tests/fixtures/skill-mutation-process-entry.ts
cp .artifacts/unfinished-closure-20261001/parallel-fastlane-20261012/skills/followups/clawhub-owned-shim.cjs desktop/tests/fixtures/clawhub-owned-shim.cjs
npm --prefix desktop run test -- --run tests/renderer/skills-settings-action-controls.test.tsx
npm --prefix desktop run test -- --run tests/main/skill-mutation-process-controls.test.ts
```

Windows需在原Windows native x64环境运行同一文件（不以mac替代）。原Node spawnSync无shell调.cmd是明确风险，候选cross-spawn还需实际这组控制才可确认。四个fixture名称仅附加控制，**不代表原正常名称人口**；原Main listSkills与实际两个页面caller的name/skill_key原始记录必须冻结并逐字复用，不trim/截断/替换/去掉不符合初版schema的名字，尤其namespace、slash、drive-like、长名若原caller有。初版512/路径限制未经人口控制不能拿资格。

## 真ClawHub / 实际cwd-root / Windows argv / partialwrite的精确运行清单

真正CLI未随repo定义，也未在本worker PATH发现（原checks.json exit1）。必须提供原批准安装环境中真实clawhub binary与版本、实际正常技能slug/版本、隔离真实OS账户和可用registry；shim不能替代这些，也不能通过换CLI、改name或mock exit0关闭失败。正式native控制保留实际环境、安装包、平台、人口、deadline与原日志。

1. **真实正常安装/卸载**：在隔离OS账户复制process-entry到上述目录；用真实clawhub所在目录扩PATH，禁止fixture bin。启动entry的cwd必须是该批准安装环境原来的实际cwd；entry当前owns-cwd安全检查只接受账户自有非根scratch cwd，适用于该正面控制。提供 `XIAOK_SKILL_CASE_ROOT=<该cwd>`、`XIAOK_SKILL_CASE_MODE=real`、`XIAOK_SKILL_CASE_JSON={"steps":[{"operation":"install","name":"<原批准slug>"},{"operation":"uninstall","name":"<同一slug>"}]}`；通过 `node --import <repo中require.resolve('tsx')的fileURL> <entry绝对路径>` 执行。命令解析方法和execPath在process.control源码明确，不能裸npx捡另一版本。逐步receipt要同时满足success、catalog名称物理可见/消失、版本+1、eventDelta=1；再在真实Desktop下一任务验证runner使用该技能。真实CLI可能写账户home，必须真实隔离OS账户，Node OS mock不是外部CLI隔离证明。
2. **原cwd与root策略**：从正常安装包实际Main收集process.cwd()，外部CLI用同一cwd；不能把它暗换dataRoot。若是文件系统根，不在真实宿主根执行fixture。使用自有VM/容器只读系统盘和自有scratch数据盘：子进程cwd根、service dataRoot/config/home仍scratch；执行真实同一个service与clawhub，不添加--dir/root参数。entry当前故意拒绝非自有cwd，因此root测试需要owner单独fixture将data/account root与actual cwd分离，再加只读root约束（**尚缺文件、不可称可运行root control**）。判据：拒绝/权限错误仍false、非scratch零改动、catalog不误报完成；若正常安装实际依赖root，应修事实owner路径而非通过拒绝掉全部正常caller换资格。mac/Windows根路径均在原平台测；Linux容器只是source surrogate。
3. **Windows argv/PATH**：同一process control在Windows生成真实.cmd。冻结原名称名单逐项执行argv.jsonl精确比较（长度1、不重命名），另加空格、Unicode、quote、percent、ampersand、caret等transport对抗字符串；这些对抗字符串不混作正常人口。特殊字符串只传给自有记录fixture，以hash做路径，禁止实际shell副作用；真实CLI正常名称逐项install/uninstall要物理后验。加独立外部sentinel保证没有展开/执行extra命令；实际错误码/ENOENT/.cmd缺失留原结果。POSIX通过不能替代Windows。
4. **权限边界**：POSIX非root隔离账户将**自有** `.xiaok/skills` chmod500，运行原install，期望false、零新增、零bump并恢复700；uninstall对自有父目录禁止write同测，不递归改共享目录。Windows自有目录用该测试账户ACL拒绝写/删，记录icacls前后原文并恢复原ACL；不改外部用户目录。这两平台机制具体命令要由owner在实际账户确认，当前未产Windows ACL harness，不以chmod模拟ACL资格。
5. **partial write/drop**：已给shim物理因果characterization；真实CLI需在自有本地registry/下载fixture控制“包先创建后下载/解析失败”与“部分文件先删后退出失败”，不得mock service逻辑。先snapshot安装root目录树+catalog，再动作及fail后snapshot，并启动既有runner下一任务检查缓存。原service仅status0才bump（`desktop/electron/desktop-services.ts:3268-3276,3284-3292`），真实partial事实与零广播要留债。修法需批审决定对任何可证目录改变失效而保持false，或事务写入rollback；worker不预定新全局事务、不增自动重试。

**未闭合不变**：真实CLI版本/目标root/原名称日志、root专用sandbox entry、Windows argv实际运行/ACL、真实registry故障、完整UI/native/安装包与runner门。批审后owner再给生产修订任务，followups不修改原design/proposal。此包所有测试未跑；syntax-only检查不当GREEN。
