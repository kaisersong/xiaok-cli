// Candidate fixture. Copy to desktop/tests/fixtures/skill-mutation-process-entry.ts.
// Dynamic production imports occur after isolating BOTH os.homedir and userInfo.
import { createRequire, syncBuiltinESMExports } from 'node:module';
import { mkdirSync, readFileSync, existsSync, chmodSync } from 'node:fs';
import { join, resolve } from 'node:path';
const root = process.env['XIAOK_SKILL_CASE_ROOT'];
if (!root || resolve(root) !== process.cwd()) throw Error('owned_process_root_required');
const require = createRequire(import.meta.url), os = require('node:os');
const home = join(root, 'home'); mkdirSync(home, { recursive: true });
const originalHome = os.homedir, originalUser = os.userInfo;
os.homedir = () => home; os.userInfo = (options: unknown) => { const info = originalUser(options); return { ...info, homedir: Buffer.isBuffer(info.homedir) ? Buffer.from(home) : home }; }; syncBuiltinESMExports();
process.env['XIAOK_CONFIG_DIR'] = join(home, '.xiaok');
const data = join(root, 'data'); mkdirSync(data, { recursive: true });
const { createDesktopServices } = await import('../../electron/desktop-services.js');
const { getSkillCatalogVersion, onSkillCatalogChanged } = await import('../../electron/skill-catalog-invalidation.js');
const service = createDesktopServices({ dataRoot: data, runner: async () => { throw Error('process_control_must_not_execute_task'); }, kswarmService: { start: async () => {}, stop: async () => {}, restart: async () => {}, getStatus: () => ({ running: false, port: 4400, pid: null, restartCount: 0, lastError: null }), onStatusChange: () => () => {}, request: async () => Response.json({}) } as never });
let events = 0; const dispose = onSkillCatalogChanged(() => events++);
const input = JSON.parse(process.env['XIAOK_SKILL_CASE_JSON']!);
const steps: unknown[] = [];
try {
  for (const step of input.steps) {
    const before = getSkillCatalogVersion(), beforeEvents = events;
    let result: unknown, rejected: string | null = null;
    try { result = await Reflect.apply(service[step.operation === 'install' ? 'installSkill' : 'uninstallSkill'], service, [step.name, { requestSource: 'user' }]); }
    catch (error) { rejected = error instanceof Error ? error.message : 'non_error_rejection'; }
    const catalog = await service.listSkills();
    steps.push({ operation: step.operation, name: step.name, result, rejected, beforeVersion: before, version: getSkillCatalogVersion(), eventDelta: events - beforeEvents, catalog });
  }
  const argvPath = join(root, 'argv.jsonl');
  const argv = existsSync(argvPath) ? readFileSync(argvPath, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line)) : [];
  console.log('XIAOK_SKILL_RECEIPT=' + JSON.stringify({ steps, argv, root, home, mode: process.env['XIAOK_SKILL_CASE_MODE'], surrogate: process.env['XIAOK_SKILL_CASE_MODE'] !== 'real' }));
} finally {
  dispose(); await service.closeTaskSourceWritersForMigration(); await service.disposeMultiAgent();
  const restricted = join(root, '.xiaok', 'skills'); if (existsSync(restricted)) chmodSync(restricted, 0o700);
  os.homedir = originalHome; os.userInfo = originalUser; syncBuiltinESMExports();
}
