// Owned test-only external process fixture. Not real ClawHub and not a service mock.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const [operation, name, ...extra] = process.argv.slice(2);
const root = process.env.XIAOK_SKILL_CASE_ROOT, mode = process.env.XIAOK_SKILL_CASE_MODE;
if (!root || path.resolve(root) !== process.cwd()) throw Error('owned_shim_cwd_mismatch');
fs.appendFileSync(path.join(root, 'argv.jsonl'), JSON.stringify({ argv: [operation, name, ...extra], cwd: process.cwd() }) + '\n');
const key = crypto.createHash('sha256').update(name || '').digest('hex').slice(0, 16);
const target = path.join(root, mode === 'wrong-root' ? 'skills' : '.xiaok', ...(mode === 'wrong-root' ? [] : ['skills']), key);
if (mode === 'zero-no-write') process.exit(0);
if (operation === 'install') {
  fs.mkdirSync(target, { recursive: true });
  fs.writeFileSync(path.join(target, 'SKILL.md'), `---\nname: ${JSON.stringify(name)}\ndescription: owned external process fixture\n---\nOwned fixture instructions.\n`);
} else if (operation === 'uninstall') {
  fs.rmSync(target, { recursive: true, force: true });
} else process.exit(8);
if (mode === 'partial-install' || mode === 'partial-uninstall') { process.stderr.write('owned_partial_write_failure'); process.exit(7); }
