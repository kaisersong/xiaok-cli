BLOCK_DESIGN

核对了 design-draft-r1.md、characterization-before-r1.json、preflight manifest、caller-census-r1.log，并实读全部锚点源码（main.ts:660-662、ipc.ts:1336、kswarm-service.ts:774-785/330-339、desktop-services.ts:1776-1804/3182-3184、preload-api.ts:899/919-925、bridge.ts:860-861、main.tsx:33、KSwarmContext.tsx、useKSwarmClient.ts）。两处阻塞，均为设计文档修订，无需改源码：

**1. design-draft-r1.md:15 — “No actual UI consumes serviceStatus: existing useKSwarm callers destructure otherfacts” 是虚假无界断言，与其引用的 census 自相矛盾。**
实际证据：ProjectDetailPage.tsx:435 从 `useKSwarm()`（:439）解构 `serviceStatus`，:1010-1012 用 `serviceStatus?.lastError?.includes('dynamic workflows')` 渲染用户可见的 `t.projectsDetailWorkflowServiceOutdated` 横幅；caller-census-r1.log:43-44 本身就记录了这两行。DesktopSettings 的 serviceStatus 是另一事实（DesktopServiceStatusSnapshot，父债通道），不属这两个 channel。
必须修：把该断言按 census 收窄——capability `getComputerUseCapabilityStatus` 在 renderer 无 bridge.ts:860-861 之外调用者；kswarm `serviceStatus` 恰有一个现存消费者（ProjectDetailPage.tsx:435、1010）。并补一段针对该消费者的显式兼容说明：初始 null 不变；读失败时 `serviceStatus` 保持 null（与 KSwarmContext.tsx:27 现行 `.catch(() => {})` 等价，横幅路径不变）；有效事件照常发布；无效事件由“发布原始负载”改为“保留 lastgood”（更安全，且 main 只发有效 8 字段 DTO）；新增 `serviceStatusReadFailed/reloadServiceStatus/serviceStatusReading` 为增量字段，现存消费者不读取；“no new badge/control” 仍成立。

**2. design-draft-r1.md:16 — "Lifecycle per locale+mount" 与现行行为差异未声明。**
现 effect 依赖为 `[]`（KSwarmContext.tsx:35）：locale 切换不重读、不重订阅。若新 hook 生命周期按 locale+mount 键控，locale 切换会触发新的初始读+订阅，与同段 “preserve existing serviceStatus property and all useKSwarmClient behavior” 存在张力。必须二选一并写明一句：(a) 声明 per-locale 重读为有意行为（RED locale gate 覆盖之，并将其排除出 preserve 条款），或 (b) 生命周期仅按 mount 键控（deps 不含 locale）。当前文本歧义。

其余全部核实无误：main.ts:660 注册缺失保留、无全局生命周期重排、读路径无 constructor（kswarm-service.ts:768 `loadOrCreateRoomSecrets` 仅构造路径）、getStatus 实返 8 字段/preload 919 仅述 5、capability 4 字段自由 state、错误码与 producer 身份/WeakMap owner 语义、manual single queue/events-vs-read/unmount/null unknown 均已决策、上下文新字段与 useKSwarmClient.ts:313-368 无命名冲突、characterization 10 例 starts0/actions0 无 SDK/native 声明、224→226 门控与全部父债保留。修订上述两处后可直接复审。