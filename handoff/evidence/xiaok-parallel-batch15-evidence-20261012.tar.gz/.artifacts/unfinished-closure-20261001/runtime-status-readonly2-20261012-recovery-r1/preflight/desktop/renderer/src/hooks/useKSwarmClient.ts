/**
 * useKSwarmClient — React hook for connecting to the KSwarm API from xiaok desktop renderer.
 *
 * Provides WebSocket real-time updates and REST API operations for projects/agents.
 * Port of kswarm/web/src/hooks/useKSwarm.js to TypeScript, adapted for xiaok desktop.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { getDesktopApi } from '@xiaok/shared/desktop';
import type { ProxyHttpBody, KSwarmAgentSemanticInput, ProjectTeamOperationView, ProjectTeamPlanView } from '../api/types';

const RECONNECT_DELAY = 3000;
const MAX_RECONNECT_DELAY = 60_000;
const PARTICIPANT_POLL_INTERVAL = 8000;
const INITIAL_SNAPSHOT_RETRY_DELAYS_MS = [1000, 2500, 5000, 10_000];

const PROJECT_REFRESH_EVENTS = new Set([
  'project_created',
  'project_approved',
  'project_closed',
  'project_deliverable',
  'tasks_created',
  'tasks_dispatched',
  'task_done',
  'task_failed',
  'task_retry',
  'task_update',
  'task_reviewed',
  'task_cancelled',
  'task_rework',
  'plan_submitted',
  'plan_revised',
  'project_continue',
  'project_execution_mode_updated',
  'workflow_run_started',
  'workflow_run_updated',
  'workflow_run_completed',
  'workflow_progress_batch',
]);

export function shouldRefreshProjectsForEvent(type?: string | null): boolean {
  return !!type && PROJECT_REFRESH_EVENTS.has(type);
}

// ─── Types ────────────────────────────────────────────────────────

export interface KSwarmTaskResult {
  summary?: string;
  artifacts?: KSwarmArtifact[];
}

export interface KSwarmTaskReviewResult {
  passed?: boolean;
  feedback?: string;
  failureClass?: string;
  reviewedAt?: number;
}

export interface KSwarmTask {
  id: string;
  title: string;
  description?: string;
  status: 'pending' | 'dispatched' | 'accepted' | 'in_progress' | 'submitted' | 'review' | 'done' | 'failed' | 'blocked' | 'cancelled';
  assignedAgent?: string;
  assignedRuntimeInstance?: string;
  phase?: number;
  priority?: number;
  planItemId?: string;
  acceptanceCriteria?: string | string[];
  result?: KSwarmTaskResult | string | null;
  artifacts?: KSwarmArtifact[];
  blockedReason?: string;
  failureReason?: string;
  lastFailureClass?: string;
  failureClass?: string;
  failureCount?: number;
  qualityFailureCount?: number;
  reviewResult?: KSwarmTaskReviewResult | null;
  startedAt?: number | string | null;
  completedAt?: number | string | null;
  createdAt?: number | string;
  updatedAt?: number | string;
  suspendedAt?: number;
  recoveryStatus?: string;
  recoveryReason?: string;
  retryNotBefore?: number;
  execution?: KSwarmTaskExecution | null;
}

export type KSwarmProjectStartPolicy = 'plan_only' | 'auto_activate_after_plan' | 'activate_and_dispatch_after_plan';

export type KSwarmProjectExecutionMode = 'direct' | 'auto' | 'workflow_preferred';

export interface KSwarmTaskExecution {
  strategy: 'direct' | 'workflow';
  modeSource?: 'project_default' | 'auto_selector' | 'manual_override' | string;
  reasonCode?: string;
  workflowRunId?: string | null;
  workflowPatternSummary?: {
    pattern?: KSwarmWorkflowPattern | string;
    label?: string;
    patternReasonCode?: string;
  } | null;
  selectedAt?: number;
}

export interface KSwarmArtifact {
  name?: string;
  filename?: string;
  mimeType?: string;
  type?: string;
  projectId?: string;
  path?: string;
  relativePath?: string;
  url?: string;
  size?: number;
  previewable?: boolean;
  createdAt?: number | string;
  updatedAt?: number | string;
  generatedAt?: number | string;
}

export interface KSwarmPhase {
  id: number;
  title: string;
  status: 'pending' | 'active' | 'completed';
  tasks: string[]; // task ids
}

export interface KSwarmProject {
  requestedStartPolicy?: KSwarmProjectStartPolicy;
  id: string;
  name: string;
  goal?: string;
  requirements?: string;
  status: 'draft' | 'planning' | 'created' | 'active' | 'review' | 'delivered' | 'closed';
  executionMode?: KSwarmProjectExecutionMode;
  tasks?: KSwarmTask[];
  phases?: KSwarmPhase[];
  poAgent?: string;
  members?: string[];
  deliverable?: KSwarmProjectDeliverable | null;
  deliveredAt?: number | string | null;
  closedAt?: number | string | null;
  createdAt?: string;
  updatedAt?: string;
  progress?: number;
  taskCount?: number;
  doneCount?: number;
  stoppedCount?: number;
  deliverables?: KSwarmDeliverable[];
  enableSummary?: boolean;
  summary?: string | null;
  summaryScore?: number | null;
  taskScores?: Array<{ title: string; agent: string; score: number; comment: string }> | null;
  projectIntervention?: ProjectIntervention | null;
  latestWorkflowRun?: KSwarmWorkflowRun | null;
}

export interface CreateKSwarmProjectResponse {
  ok: boolean;
  project?: KSwarmProject;
  preparation?: unknown;
  planningStart?: unknown;
}

export interface KSwarmDeliverable {
  id: string;
  title: string;
  format?: string;
  path?: string;
  url?: string;
  createdAt?: string;
}

export interface KSwarmProjectDeliverable {
  summary?: string;
  artifacts?: KSwarmArtifact[];
  synthesis?: boolean;
  files?: unknown[];
  description?: string;
}

export interface KSwarmAgent {
  desktopModelId?: string | null;
  id: string;
  name: string;
  description?: string;
  roles?: string[];
  capabilities?: string[];
  status: 'idle' | 'waiting' | 'working' | 'blocked' | 'failed' | 'error' | 'completed' | 'offline';
  provider?: string;
  model?: string;
  baseUrl?: string;
  instructions?: string;
  runtimeType?: string;
  runtimeMode?: 'local' | 'cloud';
  maxConcurrentTasks?: number;
  currentTask?: string;
  fallbackToDesktopModel?: boolean;
}

export interface KSwarmActivityEvent {
  type: string;
  projectId?: string;
  taskId?: string;
  taskTitle?: string;
  agent?: string;
  by?: string;
  target?: string;
  ts?: number | string;
  tasks?: Array<{ title: string; assignedAgent?: string }>;
  output?: { artifacts?: KSwarmArtifact[] };
  count?: number;
  failureReason?: string;
  errorMessage?: string;
  feedback?: string;
  reason?: string;
  blockedReason?: string;
  failureClass?: string;
  action?: string;
  passed?: boolean;
  workflowRunId?: string;
  workflowId?: string;
  status?: string;
  decision?: string;
}

export interface KSwarmHumanAction {
  action: string;
  projectName?: string;
  ts: number;
}

export interface KSwarmParticipant {
  participantId: string;
  alias?: string;
  kind?: string;
  roles?: string[];
  inboxMode?: string;
  lastSeen?: string;
}

export interface KSwarmEvent {
  type: string;
  projectId?: string;
  taskId?: string;
  data?: unknown;
  timestamp?: string;
}

export interface CreateAgentInput {
  desktopModelId?: string | null;
  name: string;
  description?: string;
  roles?: string[];
  capabilities?: string[];
  provider?: string;
  model?: string;
  baseUrl?: string;
  apiKey?: string;
  instructions?: string;
  runtimeType?: string;
  maxConcurrentTasks?: number;
  fallbackToDesktopModel?: boolean;
}

export interface AgentProbe {
  healthy: boolean;
  callability?: 'available' | 'limited' | 'unavailable';
  version?: string;
  error?: string;
  message?: string;
  durationMs?: number;
}

export type KSwarmAgentSelectionSource = 'default_seed' | 'explicit_user' | 'system_migration';

export interface KSwarmProjectAgentSelection {
  poAgent: { agentId: string; source: KSwarmAgentSelectionSource };
  members: Array<{ agentId: string; source: KSwarmAgentSelectionSource }>;
}

export interface CreateKSwarmProjectInput {
  startPolicy?: KSwarmProjectStartPolicy;
  name: string;
  goal: string;
  requirements?: string;
  poAgent: string;
  members?: string[];
  workFolder?: string;
  enableSummary?: boolean;
  executionMode?: KSwarmProjectExecutionMode;
  agentSelection?: KSwarmProjectAgentSelection;
}

export interface KSwarmWorkflowNodeDispatch {
  workflowRunId: string;
  nodeId: string;
  agentId?: string;
  taskId?: string;
}

export interface DispatchTasksResult {
  dispatched: string[];
  workflowRuns?: KSwarmWorkflowRun[];
  workflowNodeDispatches?: KSwarmWorkflowNodeDispatch[];
  skipped?: unknown[];
  blocked?: unknown[];
  ok?: boolean;
}

export interface KSwarmClientState {
  connected: boolean;
  projects: KSwarmProject[];
  projectsLoaded: boolean;
  agents: KSwarmAgent[];
  participants: KSwarmParticipant[];
  lastEvent: KSwarmEvent | null;
  /** Monotonically increasing counter — changes on every WS event. Use as effect dependency instead of lastEvent object reference. */
  lastEventSeq: number;
  /** Synchronous read of the most recent WS event (stable ref). */
  getLastEvent: () => KSwarmEvent | null;
}

export interface KSwarmClientActions {
  // Project actions
  fetchProjects(): Promise<KSwarmProject[]>;
  getProjectDetail(projectId: string): Promise<KSwarmProject | null>;
  getProjectFullDetail(projectId: string): Promise<ProjectFullDetail | null>;
  createProject(input: CreateKSwarmProjectInput): Promise<KSwarmProject | null>;
  updateProjectExecutionMode(projectId: string, executionMode: KSwarmProjectExecutionMode): Promise<KSwarmProject | null>;
  approveProject(projectId: string): Promise<boolean>;
  retryPlan(projectId: string): Promise<{ ok: boolean; retried?: boolean; poReassigned?: boolean; poAgent?: string; previousPoAgent?: string; poResolutionReason?: string } | null>;
  continueProject(projectId: string, request: ContinueProjectRequest): Promise<ContinueProjectResult | null>;
  closeProject(projectId: string): Promise<boolean>;
  deleteProject(projectId: string): Promise<boolean>;
  planProjectTeam(input: { projectId: string }): Promise<ProjectTeamPlanView>;
  applyProjectTeamPlan(input: { projectId: string; planId: string; projectRevision: number }): Promise<ProjectTeamOperationView>;
  getProjectTeamOperation(input: { projectId: string }): Promise<ProjectTeamOperationView | null>;
  deliverProject(projectId: string): Promise<boolean>;
  startProjectDiagnoseWorkflow(projectId: string): Promise<KSwarmWorkflowRun | null>;
  startProjectAgentReviewSmokeWorkflow(projectId: string): Promise<KSwarmWorkflowRun | null>;
  createWorkflowProposal(projectId: string, workflowId: string, options?: { taskId?: string }): Promise<KSwarmWorkflowProposal | null>;
  startWorkflowRunFromProposal(projectId: string, workflowId: string, proposalId: string, options?: { taskId?: string }): Promise<KSwarmWorkflowRun | null>;
  cancelWorkflowRun(projectId: string, workflowRunId: string): Promise<KSwarmWorkflowRun | null>;
  // Task actions
  humanAddTasks(projectId: string, tasks: Array<{ title: string; description?: string; assignedAgent?: string }>): Promise<boolean>;
  createTasks(projectId: string, tasks: Array<{ title: string; description?: string; phase?: number }>): Promise<boolean>;
  dispatchTasks(projectId: string, fromAgent?: string): Promise<DispatchTasksResult | null>;
  markTaskDone(projectId: string, taskId: string, fromAgent?: string): Promise<boolean>;
  cancelTask(projectId: string, taskId: string): Promise<boolean>;
  taskFailed(projectId: string, taskId: string, failureReason?: string, errorMessage?: string): Promise<{ ok: boolean; retried?: boolean; retryTaskId?: string; attempt?: number; failureReason?: string } | null>;
  // Agent actions
  fetchAgents(): Promise<KSwarmAgent[]>;
  fetchParticipants(): Promise<KSwarmParticipant[]>;
  createAgent(input: CreateAgentInput): Promise<KSwarmAgent | null>;
  updateAgent(id: string, input: Partial<CreateAgentInput>): Promise<KSwarmAgent | null>;
  archiveAgent(id: string): Promise<boolean>;
  startAgent(id: string): Promise<boolean>;
  stopAgent(id: string): Promise<boolean>;
  probeAgent(id: string): Promise<AgentProbe | null>;
  fetchLiveness(): Promise<Record<string, { lastSeen: number | null; online: boolean; status: string }>>;
  pingHeartbeat(agentId: string): Promise<boolean>;
  // Runtime & provider discovery
  fetchRuntimes(): Promise<Array<{ type: string; displayName: string; description: string; detected: boolean; supported?: boolean; path: string | null }>>;
  fetchLlmProviders(): Promise<string[]>;
}

export interface ProjectFullDetail {
  project: KSwarmProject & { workFolder?: string; requirements?: string; plan?: any; deliveredAt?: string; deliverable?: any; closedAt?: string };
  tasks: KSwarmTask[];
  activities: KSwarmActivityEvent[];
  humanActions: KSwarmHumanAction[];
  workspace: { path: string; custom?: boolean; artifacts?: Array<KSwarmArtifact | string> };
  plan: any | null;
  planProgress: { phases: Array<{ phaseId: string | number; total: number; done: number }>; total: number; done: number } | null;
  dispatchPlan?: {
    dispatchedTasks?: Array<{
      id?: string;
      taskId?: string;
      title?: string;
      status?: string;
      agentId?: string;
      assignedAgent?: string;
      reason?: string;
      blockKind?: string | null;
      activeRunId?: string | null;
    }>;
    dispatchable?: Array<{ taskId: string; agentId?: string; reason?: string }>;
    blocked?: Array<{ taskId: string; reason: string; blockedByTaskId?: string }>;
    waiting?: Array<{ taskId: string; reason: string; agentId?: string }>;
  };
  projectHealth?: {
    status?: 'healthy' | 'running' | 'waiting' | 'needs_review' | 'blocked' | 'failed' | 'unknown';
    state?: 'idle' | 'healthy' | 'running' | 'dispatchable' | 'waiting' | 'needs_review' | 'blocked' | 'failed' | 'complete' | 'closed' | 'unknown';
    gate?: string | null;
    counts?: Record<string, number>;
    reasons?: Array<{ taskId?: string; message?: string; nextActions?: unknown[] }>;
    primaryBlockedTaskId?: string;
    message?: string;
    actions?: Array<{ id: string; label: string; recommended?: boolean }>;
  };
  projectIntervention?: ProjectIntervention | null;
  workflowRuns?: KSwarmWorkflowRun[];
}

export type KSwarmWorkflowRunStatus =
  | 'awaiting_approval'
  | 'running'
  | 'blocked'
  | 'completed'
  | 'failed'
  | 'cancelled';

export type KSwarmWorkflowNodeStatus =
  | 'pending'
  | 'ready'
  | 'running'
  | 'completed'
  | 'failed'
  | 'blocked'
  | 'cancelled';

export type KSwarmWorkflowPattern =
  | 'deliver_review_reduce'
  | 'classify_and_act'
  | 'fanout_synthesize'
  | 'adversarial_verify'
  | 'generate_filter'
  | 'tournament'
  | 'bounded_loop_until_done'
  | 'root_cause_hypothesis_race'
  | 'quarantine_triage'
  | 'rule_mining';

export interface KSwarmWorkflowRunPublicView {
  id: string;
  projectId: string;
  taskId?: string;
  status: string;
  title: string;
  patternLabel: string;
  reasonLabel?: string;
  progress: number;
  currentPhase?: string;
  keyFindings?: string[];
  risks?: string[];
  pendingQuestion?: string | null;
  deliverables?: KSwarmArtifact[];
  recoveryAction?: { kind?: string; label?: string } | null;
}

export interface KSwarmWorkflowRun {
  id: string;
  projectId: string;
  workflowId: 'project-diagnose' | string;
  title: string;
  strategy: 'workflow';
  source: 'builtin' | string;
  status: KSwarmWorkflowRunStatus;
  createdAt: number;
  updatedAt: number;
  startedAt?: number | null;
  completedAt?: number | null;
  cancelledAt?: number | null;
  requestedBy?: string | null;
  scope?: { projectId?: string; taskId?: string } | null;
  sourceTask?: { id: string; title?: string; status?: string; assignedAgent?: string | null } | null;
  workflowPattern?: KSwarmWorkflowPattern | string | null;
  patternSelection?: {
    pattern?: KSwarmWorkflowPattern | string;
    patternReasonCode?: string;
    confidence?: 'low' | 'medium' | 'high' | string;
    requiresUserConfirmation?: boolean;
    selectedAt?: number;
    selectorVersion?: string;
    inputDigest?: string;
    [key: string]: unknown;
  } | null;
  compiledContract?: unknown;
  patternState?: unknown;
  publicView?: KSwarmWorkflowRunPublicView | null;
  approval?: {
    required: boolean;
    status: 'not_required' | 'pending' | 'approved' | 'rejected' | string;
    budget?: { maxAgents?: number; maxUsd?: number; maxMinutes?: number } | null;
    approvedBy?: string | null;
    decidedAt?: number | null;
  };
  budgets?: {
    maxNodes?: number;
    maxParallelism?: number;
    maxAgents?: number;
    maxMinutes?: number;
    maxTokens?: number;
  } | null;
  budgetGate?: {
    status?: 'passed' | 'blocked' | string;
    hardLimits?: {
      maxNodes?: number;
      maxParallelism?: number;
      maxAgents?: number;
      maxMinutes?: number;
      maxTokens?: number;
    };
    estimate?: { riskLevel?: 'low' | 'medium' | 'high' | string; reason?: string };
  } | null;
  phases: Array<{ id: string; title: string; status: KSwarmWorkflowNodeStatus; nodeIds: string[] }>;
  nodes: KSwarmWorkflowNode[];
  summary: {
    total: number;
    completed: number;
    failed: number;
    blocked: number;
    running: number;
    pending: number;
    progress: number;
    primaryMessage?: string | null;
    cache?: { storedNodeCount?: number; reusableNodeCount?: number };
    parallelGroups?: {
      total?: number;
      completed?: number;
      failed?: number;
      blocked?: number;
      running?: number;
      cancelled?: number;
    };
    checkpoints?: {
      total?: number;
      completed?: number;
      waiting?: number;
      failed?: number;
    };
    blockingFailures?: Array<{ nodeId?: string; title?: string; status?: string; reason?: string | null }>;
  };
  parallelGroups?: KSwarmWorkflowParallelGroup[];
  scriptCheckpoints?: KSwarmWorkflowScriptCheckpoint[];
  progressState?: {
    lastMaterialProgress?: { nodeId?: string; message?: string; at?: number };
  } | null;
  recovery?: {
    mode?: 'not_needed' | 'resume_completed_nodes' | 'blocked_waiting_runtime' | 'rerun_from_start' | string;
    reusableNodeCount?: number;
    nextAction?: string;
  } | null;
  diagnosis?: KSwarmWorkflowDiagnosis | null;
  gateDecision?: KSwarmWorkflowReviewDecision | null;
}

export interface KSwarmWorkflowProposal {
  id: string;
  projectId: string;
  workflowId: string;
  title: string;
  description?: string;
  goal?: string;
  status: 'pending' | 'approved' | 'cancelled' | string;
  requestedBy?: string | null;
  strategy?: 'workflow' | string;
  source?: 'builtin' | 'builtin-smoke' | 'po_generated' | string;
  scope?: { projectId?: string; taskId?: string } | null;
  sourceTask?: { id: string; title?: string; status?: string; assignedAgent?: string | null } | null;
  createdAt: number;
  updatedAt: number;
  specHash?: string;
  phases: Array<{
    id: string;
    title: string;
    nodes: Array<{ id: string; title: string; kind: string; required: boolean; dependsOn?: string[] }>;
  }>;
  budgets: {
    maxNodes?: number;
    maxParallelism?: number;
    maxAgents?: number;
    maxMinutes?: number;
    maxTokens?: number;
  };
  budgetGate?: KSwarmWorkflowRun['budgetGate'];
  permissions: {
    toolCategories?: string[];
    allowWrite?: boolean;
    allowShell?: boolean;
    allowNetwork?: boolean;
    allowRenderer?: boolean;
  };
  outputContract?: { kind?: string; requiredArtifactTypes?: string[] } | null;
  assumptions?: string[];
  acceptanceRubric: {
    id: string;
    title: string;
    machineChecks: Array<{ id: string; title: string; checkKind: string; required: boolean; inputRefs?: string[] }>;
    judgmentChecks: Array<{ id: string; title: string; prompt?: string; evidenceRequired: boolean; reviewerCount: number; required: boolean }>;
    disagreementPolicy: string;
  };
  approval: {
    required: boolean;
    status: 'pending' | 'approved' | 'rejected' | string;
    budget?: KSwarmWorkflowProposal['budgets'] | null;
    approvedBy?: string | null;
    decidedAt?: number | null;
  };
}

export interface KSwarmWorkflowNode {
  id: string;
  phaseId: string;
  title: string;
  status: KSwarmWorkflowNodeStatus;
  kind: 'control' | 'review' | 'agent_task' | string;
  dependsOn: string[];
  assignedAgent?: string | null;
  attempt?: number;
  input?: Record<string, unknown> | null;
  output?: Record<string, unknown> | null;
  reviewDecision?: KSwarmWorkflowReviewDecision | null;
  runtime?: {
    handoffId?: string;
    runId?: string;
    participantId?: string;
    lastProgressAt?: number;
  } | null;
  cache?: {
    key?: string;
    status?: 'stored' | string;
    storedAt?: number;
    inputHash?: string;
    outputHash?: string;
  } | null;
  producerAgent?: string | null;
  error?: string | null;
  startedAt?: number | null;
  completedAt?: number | null;
  parallelGroupId?: string | null;
  fanoutItemKey?: string | null;
  fanoutItemLabel?: string | null;
  pipelineStageIndex?: number | null;
  required?: boolean;
  outputSchema?: Record<string, unknown> | null;
  evidenceRequired?: boolean;
}

export interface KSwarmWorkflowParallelGroup {
  id: string;
  workflowRunId?: string | null;
  phaseId?: string | null;
  primitiveId?: string | null;
  kind?: 'parallel' | 'pipeline' | string;
  label: string;
  status: string;
  limit?: number;
  totalCount?: number;
  completedCount?: number;
  failedCount?: number;
  cancelledCount?: number;
  requiredFailedCount?: number;
  failurePolicy?: 'required_all' | 'collect_errors' | 'fail_fast' | 'quorum' | string;
  quorum?: number | null;
  createdAt?: number | null;
  updatedAt?: number | null;
  completedAt?: number | null;
}

export interface KSwarmWorkflowScriptCheckpoint {
  id: string;
  workflowRunId?: string | null;
  scriptHash?: string | null;
  primitiveType?: 'parallel' | 'pipeline' | 'agent' | string | null;
  primitiveId?: string | null;
  phaseId?: string | null;
  parallelGroupId?: string | null;
  status: string;
  inputHash?: string | null;
  outputRefs?: string[];
  createdAt?: number | null;
  updatedAt?: number | null;
}

export interface KSwarmWorkflowReviewDecision {
  status: 'passed' | 'needs_rework' | 'blocked' | string;
  reason: string;
  evidenceRefs?: string[];
}

export interface KSwarmWorkflowDiagnosis {
  healthState?: string | null;
  gate?: string | null;
  blockedTasks: Array<{ taskId?: string; message?: string }>;
  dispatchableCount: number;
  waitingCount: number;
  recommendedActions: Array<{ id: string; label: string; reason: string }>;
}

export interface ProjectIntervention {
  required: boolean;
  severity?: 'normal' | 'warning' | 'action_required' | string;
  kind?: 'task_board' | 'script_workflow' | string;
  projectId?: string | null;
  workflowRunId?: string | null;
  workflowId?: string | null;
  scriptHash?: string | null;
  reason?: string;
  headline?: string | null;
  message?: string;
  primaryTaskId?: string | null;
  primaryTaskTitle?: string | null;
  lastEventAt?: number | string | null;
  downstreamBlockedCount?: number;
  primaryFailure?: {
    reason?: string | null;
    feedback?: string;
    assignedAgent?: string | null;
    status?: string | null;
    qualityFailureCount?: number;
  } | null;
  primaryAction?: {
    id: 'continue_project' | string;
    label?: string;
    strategy?: string;
    taskId?: string;
    taskUpdatedAt?: number | string | null;
    toolName?: string;
    params?: {
      projectId?: string;
      resumeWorkflowRunId?: string;
      [key: string]: unknown;
    } | null;
  } | null;
  secondaryAction?: {
    id: 'ask_xiaok' | string;
    label: string;
    context?: Record<string, unknown>;
  } | null;
}

export interface ContinueProjectRequest {
  expectedPrimaryTaskId?: string;
  expectedTaskUpdatedAt?: number | string | null;
  idempotencyKey: string;
}

export interface ContinueProjectResult {
  ok: boolean;
  action?: 'continue_project' | string;
  strategy?: string | null;
  outcome?: 'advanced' | 'submitted_for_review' | 'needs_user_action' | 'not_advanced' | string;
  projectChanged?: boolean;
  humanActionRequired?: boolean;
  error?: string;
  status?: number;
  dispatched?: string[];
  idempotent?: boolean;
  xiaokContext?: Record<string, unknown>;
  nextActions?: Array<{
    id: string;
    label?: string;
    description?: string;
    toolName?: string;
    params?: Record<string, unknown>;
  }>;
  reviewNotification?: 'sent' | 'failed' | 'not_available' | string;
  reviewNotificationError?: string;
  reviewNotificationNeeded?: boolean;
}

// ─── Principles Injection ────────────────────────────────────────

interface PrincipleEntry {
  id: string;
  content: string;
  scenarios: string[];
  enabled: boolean;
  createdAt: number;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function readConnectionStatus(value: unknown): string | undefined {
  if (!isRecord(value)) return undefined;
  return typeof value.status === 'string' ? value.status : undefined;
}

function readKSwarmEvent(value: unknown): KSwarmEvent | null {
  if (!isRecord(value) || typeof value.type !== 'string') return null;
  return value as unknown as KSwarmEvent;
}

function readPrincipleEntries(value: unknown): PrincipleEntry[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is Record<string, unknown> => isRecord(item))
    .filter((item) => typeof item.id === 'string' && typeof item.content === 'string')
    .map((item) => ({
      id: item.id as string,
      content: item.content as string,
      scenarios: Array.isArray(item.scenarios) ? item.scenarios.map((scenario) => String(scenario)) : [],
      enabled: item.enabled !== false,
      createdAt: typeof item.createdAt === 'number' ? item.createdAt : 0,
    }));
}

function toSemanticAgentInput(input: Partial<CreateAgentInput>): Partial<KSwarmAgentSemanticInput> {
  return Object.fromEntries(Object.entries({
    name: input.name,
    desktopModelId: input.desktopModelId,
    description: input.description,
    roles: input.roles,
    capabilities: input.capabilities,
    instructions: input.instructions,
    runtimeType: input.runtimeType,
    maxConcurrentTasks: input.maxConcurrentTasks,
    fallbackToDesktopModel: input.fallbackToDesktopModel,
  }).filter(([, value]) => value !== undefined));
}

function readSemanticAgent(value: unknown): KSwarmAgent | null {
  if (!isRecord(value)) return null;
  const candidate = isRecord(value.agent) ? value.agent : value;
  return typeof candidate.id === 'string' ? candidate as unknown as KSwarmAgent : null;
}

function readSemanticOk(value: unknown): boolean {
  return value === true || (isRecord(value) && value.ok === true);
}

export function buildCreateProjectPlanningGuidance(input: {
  goal: string;
  requirements?: string;
  principles?: PrincipleEntry[];
}): { visibleRequirements: string; planningGuidance: string } {
  const visibleRequirements = input.requirements || '';
  const blocks = [
    inferRendererPlanningGuidance(`${input.goal || ''}\n${visibleRequirements}`),
    formatPrinciplesForPlanningGuidance(input.principles || []),
  ].filter(Boolean);
  return {
    visibleRequirements,
    planningGuidance: blocks.join('\n\n'),
  };
}

function inferRendererPlanningGuidance(text: string): string {
  const value = String(text || '');
  const explicitMarkdown = /(\.md\b|\.markdown\b|\bmarkdown\b)/i.test(value);
  const explicitPptx = /(\.pptx\b|\bpptx\b|\bpowerpoint\b|\bppt\s*(文件|file|deck)?\b)/i.test(value);
  const slide = /(幻灯片|演示文稿|slide deck|slides|presentation)/i.test(value);
  const report = /(报告|\breport\b)/i.test(value);
  const analysisReport = !report && isAnalysisReportLikeProject(value);

  if (slide && explicitPptx) {
    return [
      '输出意图：用户明确要求演示文稿/幻灯片交付 PPTX。',
      '不要改写用户目标或项目要求；计划中细化为最终任务生成 PPTX 文件。',
      '前序内容任务可以产出素材或草稿，但最终交付物必须符合用户明确格式。',
    ].join('\n');
  }
  if (slide && !explicitPptx) {
    return [
      '输出意图：用户要演示文稿/幻灯片。',
      '计划中必须安排最终任务使用 slide renderer 生成 HTML deck；不要默认改成 PPTX。',
      '前序内容任务可以产出素材或草稿，但最终交付物必须是 slide renderer HTML。',
    ].join('\n');
  }
  if (report && explicitMarkdown) {
    return [
      '输出意图：用户明确要求报告交付 Markdown。',
      '不要改写用户目标或项目要求；计划中细化为最终任务生成 Markdown 报告。',
      '前序研究/写作任务可以产出素材或草稿，但最终交付物必须符合用户明确格式。',
    ].join('\n');
  }
  if ((report || analysisReport) && !explicitMarkdown) {
    return [
      analysisReport
        ? '输出意图：用户要分析/研究类交付物，默认按报告交付；最终任务必须使用 report renderer 生成 HTML 报告。'
        : '输出意图：用户要报告，最终任务必须使用 report renderer 生成 HTML 报告。',
      '不要把用户目标改写为其他交付格式。',
      '前序研究/写作任务可以产出素材或中间 Markdown，但最终交付物必须是 report renderer HTML。',
    ].join('\n');
  }
  return '';
}

function isAnalysisReportLikeProject(text: string): boolean {
  const analysis = /(分析|研究|调研|评估|研判|洞察|复盘|\banalysis\b|\bresearch\b|\bassessment\b|\bbrief\b)/i.test(text);
  const deliverableCue = /(高层|管理层|决策|战略|研发|产品|竞品|市场|行业|趋势|动态|情况|内容|汇报|材料|交付|leadership|executive|strategy|market|industry|trend|product|competitive)/i.test(text);
  return analysis && deliverableCue;
}

function formatPrinciplesForPlanningGuidance(principles: PrincipleEntry[]): string {
  // Filter: enabled + planning or execution scenarios (Phase 1: only createProject)
  const matched = principles.filter(
    p => p.enabled && (p.scenarios.includes('planning') || p.scenarios.includes('execution'))
  );
  if (matched.length === 0) return '';

  // Format lines: collapse multiline, escape ## headings
  const lines: string[] = [];
  let totalLen = 0;
  for (let i = 0; i < matched.length; i++) {
    const content = matched[i].content.replace(/\n/g, '；').replace(/^## /gm, '> ## ');
    const line = `${i + 1}. ${content}`;
    if (totalLen + line.length > 3000) break;
    lines.push(line);
    totalLen += line.length;
  }

  const truncateNote = lines.length < matched.length
    ? `\n\n（共 ${matched.length} 条原则，已展示前 ${lines.length} 条）`
    : '';

  const block = lines.join('\n');
  return `知识与规则（系统规划指导，不写入用户可见要求）：\n${block}${truncateNote}`;
}

// ─── HTTP Helpers (via IPC proxy) ────────────────────────────────

async function httpGet<T>(path: string): Promise<T | null> {
  const api = getDesktopApi();
  if (!api?.kswarmProxyGet) return null;
  try {
    return await api.kswarmProxyGet(path) as T | null;
  } catch (err) {
    console.warn(`[kswarm] GET ${path} failed`, err);
    return null;
  }
}

async function httpPost<T>(path: string, body?: unknown): Promise<T | null> {
  const api = getDesktopApi();
  if (!api?.kswarmProxyPost) return null;
  try {
    return await api.kswarmProxyPost(path, body as ProxyHttpBody) as T | null;
  } catch (err) {
    console.warn(`[kswarm] POST ${path} failed`, err);
    return null;
  }
}

async function httpPostJson<T>(path: string, body?: unknown): Promise<T | null> {
  const api = getDesktopApi();
  if (!api?.kswarmProxyPostJson) return null;
  try {
    return await api.kswarmProxyPostJson(path, body as ProxyHttpBody) as T | null;
  } catch (err) {
    console.warn(`[kswarm] POST(json) ${path} failed`, err);
    return null;
  }
}

// ─── Hook ─────────────────────────────────────────────────────────

export function useKSwarmClient(): KSwarmClientState & KSwarmClientActions {
  const [connected, setConnected] = useState(false);
  const [projects, setProjects] = useState<KSwarmProject[]>([]);
  const [projectsLoaded, setProjectsLoaded] = useState(false);
  const [agents, setAgents] = useState<KSwarmAgent[]>([]);
  const [participants, setParticipants] = useState<KSwarmParticipant[]>([]);
  const [lastEvent, setLastEvent] = useState<KSwarmEvent | null>(null);
  const [lastEventSeq, setLastEventSeq] = useState(0);
  const lastEventRef = useRef<KSwarmEvent | null>(null);
  const getLastEvent = useCallback(() => lastEventRef.current, []);

  const wsRef = useRef<(() => void) | null>(null);
  const wsEventRef = useRef<(() => void) | null>(null);
  const pollTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const connectedRef = useRef(false);
  const projectsRef = useRef<KSwarmProject[]>([]);
  const agentsRef = useRef<KSwarmAgent[]>([]);
  const participantsRef = useRef<KSwarmParticipant[]>([]);

  // ─── IPC Stream Connection ─────────────────────────────────────

  function handleWsMessage(msg: KSwarmEvent) {
    lastEventRef.current = msg;
    setLastEvent(msg);
    setLastEventSeq(s => s + 1);

    if (shouldRefreshProjectsForEvent(msg.type)) {
      fetchProjects();
    }
    if (msg.type === 'agent_created' || msg.type === 'agent_updated' || msg.type === 'agent_archived' || msg.type === 'agent_started' || msg.type === 'agent_stopped') {
      fetchAgents();
    }
  }

  // ─── Lifecycle ────────────────────────────────────────────────

  useEffect(() => {
    const api = getDesktopApi();
    if (!api) return;
    let disposed = false;
    let snapshotRetryTimer: ReturnType<typeof setTimeout> | null = null;
    let snapshotRetryAttempt = 0;

    const clearSnapshotRetry = () => {
      if (snapshotRetryTimer) {
        clearTimeout(snapshotRetryTimer);
        snapshotRetryTimer = null;
      }
    };

    const scheduleSnapshotRetry = () => {
      if (disposed || snapshotRetryTimer || snapshotRetryAttempt >= INITIAL_SNAPSHOT_RETRY_DELAYS_MS.length) {
        return;
      }
      const delay = INITIAL_SNAPSHOT_RETRY_DELAYS_MS[snapshotRetryAttempt];
      snapshotRetryAttempt++;
      snapshotRetryTimer = setTimeout(() => {
        snapshotRetryTimer = null;
        loadSnapshot({ retryOnFailure: true });
      }, delay);
    };

    const loadSnapshot = async ({ retryOnFailure }: { retryOnFailure: boolean }) => {
      const [projectData, agentData, participantData] = await Promise.all([
        httpGet<{ projects: KSwarmProject[] }>('/projects'),
        httpGet<{ agents: KSwarmAgent[] }>('/agents'),
        httpGet<{ participants: KSwarmParticipant[] }>('/participants'),
      ]);
      if (disposed) return;

      const projectList = Array.isArray(projectData?.projects) ? projectData.projects : null;
      if (projectList) {
        projectsRef.current = projectList;
        setProjects(projectList);
        setProjectsLoaded(true);
        snapshotRetryAttempt = 0;
        clearSnapshotRetry();
      } else if (retryOnFailure) {
        scheduleSnapshotRetry();
      }

      const agentList = Array.isArray(agentData?.agents) ? agentData.agents : null;
      if (agentList) {
        agentsRef.current = agentList;
        setAgents(agentList);
      }

      const participantList = Array.isArray(participantData?.participants) ? participantData.participants : null;
      if (participantList) {
        participantsRef.current = participantList;
        setParticipants(participantList);
      }
    };

    let subscriptionUncertain = false;
    const applyConnectionStatus = (status?: string) => {
      if (disposed) return;
      const isConnected = status === 'connected' && !subscriptionUncertain;
      const wasConnected = connectedRef.current;
      setConnected(isConnected);
      connectedRef.current = isConnected;
      if (isConnected && !wasConnected) {
        loadSnapshot({ retryOnFailure: true });
      }
    };

    const unsubStatus = api.onKSwarmConnectionStatus?.((payload: unknown) => {
      applyConnectionStatus(readConnectionStatus(payload));
    });
    wsRef.current = unsubStatus || null;

    const unsubEvent = api.onKSwarmWsEvent?.((payload: unknown) => {
      const event = readKSwarmEvent(payload);
      if (event) handleWsMessage(event);
    });
    wsEventRef.current = unsubEvent || null;

    const subscriptionFailed = () => {
      if (disposed) return;
      subscriptionUncertain = true;
      applyConnectionStatus('disconnected');
    };
    try {
      Promise.resolve(api.kswarmStreamSubscribe?.())
        .then((receipt: unknown) => {
          if (receipt && typeof receipt === 'object' && 'ok' in receipt && receipt.ok === false) subscriptionFailed();
        })
        .catch(subscriptionFailed);
    } catch { subscriptionFailed(); }
    Promise.resolve(api.kswarmStreamGetStatus?.())
      .then((payload: unknown) => {
        applyConnectionStatus(readConnectionStatus(payload));
      })
      .catch(() => {});

    loadSnapshot({ retryOnFailure: true });

    pollTimer.current = setInterval(() => {
      if (connectedRef.current) fetchParticipants();
    }, PARTICIPANT_POLL_INTERVAL);

    return () => {
      disposed = true;
      try {
        Promise.resolve(api.kswarmStreamUnsubscribe?.())
          .catch(error => console.warn('[kswarm] stream unsubscribe outcome unknown', error));
      } catch (error) { console.warn('[kswarm] stream unsubscribe outcome unknown', error); }
      wsRef.current?.();
      wsRef.current = null;
      wsEventRef.current?.();
      wsEventRef.current = null;
      if (pollTimer.current) {
        clearInterval(pollTimer.current);
        pollTimer.current = null;
      }
      clearSnapshotRetry();
    };
  }, []);

  // ─── Project Actions ──────────────────────────────────────────

  const fetchProjects = useCallback(async (): Promise<KSwarmProject[]> => {
    const data = await httpGet<{ projects: KSwarmProject[] }>('/projects');
    if (!Array.isArray(data?.projects)) {
      return projectsRef.current;
    }
    const list = data.projects;
    projectsRef.current = list;
    setProjects(list);
    setProjectsLoaded(true);
    return list;
  }, []);

  const getProjectDetail = useCallback(async (projectId: string): Promise<KSwarmProject | null> => {
    return await httpGet<KSwarmProject>(`/projects/${projectId}`);
  }, []);

  const getProjectFullDetail = useCallback(async (projectId: string): Promise<ProjectFullDetail | null> => {
    return await httpGet<ProjectFullDetail>(`/projects/${projectId}`);
  }, []);

  const createProject = useCallback(async (input: CreateKSwarmProjectInput): Promise<KSwarmProject | null> => {
    let principles: PrincipleEntry[] = [];
    try {
      const api = getDesktopApi();
      if (api?.listPrinciples) {
        const loaded = await api.listPrinciples();
        principles = readPrincipleEntries(loaded);
      }
    } catch (e) {
      console.warn('[principles] Failed to load principles for planning guidance, using original requirements', e);
    }
    const guidance = buildCreateProjectPlanningGuidance({
      goal: input.goal,
      requirements: input.requirements || '',
      principles,
    });
    const desktopApi = getDesktopApi();
    const response = desktopApi?.createKSwarmProject
      ? await desktopApi.createKSwarmProject({
        ...input,
        requirements: guidance.visibleRequirements || undefined,
        planningGuidance: guidance.planningGuidance || undefined,
        enableSummary: input.enableSummary ?? true,
        autoStartPlanning: false,
        startPolicy: input.startPolicy ?? 'activate_and_dispatch_after_plan',
      }) as CreateKSwarmProjectResponse | KSwarmProject | null
      : null;
    // Main's semantic API returns the project directly. Older bridges return
    // an envelope; accept both and use canonical values for the bootstrap.
    const result = response && 'project' in response ? response.project : response as KSwarmProject | null;
    if (!result || !result.id) {
      console.error('[createProject] Project create returned no project id', response);
      return null;
    }
    // Because autoStartPlanning:false disables server-side auto planning, the
    // client MUST successfully enqueue the planning bootstrap; a failure here
    // would leave the project stuck in "created" forever, so surface it.
    try {
      const api = getDesktopApi();
      if (api?.kswarmStartProjectPlanning) {
        const enqueueResult = await api.kswarmStartProjectPlanning({
          projectId: result.id,
          projectName: result.name,
          goal: input.goal,
          requirements: input.requirements || '',
          planningGuidance: guidance.planningGuidance || '',
          poAgent: result.poAgent || input.poAgent,
          members: result.members ?? input.members ?? [],
          startPolicy: result.requestedStartPolicy ?? input.startPolicy ?? 'activate_and_dispatch_after_plan',
        });
        if (!enqueueResult?.ok) {
          console.error('[createProject] Planning bootstrap enqueue rejected', enqueueResult);
        }
      } else {
        console.error('[createProject] kswarmStartProjectPlanning API unavailable; project will not plan');
      }
    } catch (e) {
      console.error('[createProject] Failed to enqueue planning bootstrap', e);
    }
    fetchProjects();
    return result;
  }, [fetchProjects]);

  const approveProject = useCallback(async (projectId: string): Promise<boolean> => {
    const result = await httpPost<{ ok: boolean }>(`/projects/${projectId}/approve`);
    if (result?.ok) fetchProjects();
    return !!result?.ok;
  }, [fetchProjects]);

  const updateProjectExecutionMode = useCallback(async (projectId: string, executionMode: KSwarmProjectExecutionMode): Promise<KSwarmProject | null> => {
    const desktopApi = getDesktopApi();
    const result = desktopApi?.updateKSwarmProjectExecutionMode
      ? await desktopApi.updateKSwarmProjectExecutionMode({ projectId, executionMode }) as { ok?: boolean; project?: KSwarmProject } | null
      : null;
    if (result?.ok) fetchProjects();
    return result?.project || null;
  }, [fetchProjects]);

  const retryPlan = useCallback(async (projectId: string) => {
    return httpPost<{ ok: boolean; retried?: boolean; poReassigned?: boolean; poAgent?: string; previousPoAgent?: string; poResolutionReason?: string }>(`/projects/${projectId}/retry-plan`, {});
  }, []);

  const continueProject = useCallback(async (projectId: string, request: ContinueProjectRequest): Promise<ContinueProjectResult | null> => {
    const result = await httpPostJson<ContinueProjectResult>(`/projects/${projectId}/continue`, request);
    if (result?.ok) fetchProjects();
    return result;
  }, [fetchProjects]);

  const closeProject = useCallback(async (projectId: string): Promise<boolean> => {
    const result = await httpPost<{ ok: boolean }>(`/projects/${projectId}/close`);
    if (result?.ok) fetchProjects();
    return !!result?.ok;
  }, [fetchProjects]);

  const deleteProject = useCallback(async (projectId: string): Promise<boolean> => {
    const desktopApi = getDesktopApi();
    const ok = desktopApi?.deleteKSwarmProject
      ? readSemanticOk(await desktopApi.deleteKSwarmProject({ projectId }))
      : false;
    if (ok) fetchProjects();
    return ok;
  }, [fetchProjects]);

  const deliverProject = useCallback(async (projectId: string): Promise<boolean> => {
    const fromAgent = projectsRef.current.find((p) => p.id === projectId)?.poAgent;
    const result = await httpPost<{ ok: boolean }>(`/projects/${projectId}/deliver`, { fromAgent });
    if (result?.ok) fetchProjects();
    return !!result?.ok;
  }, [fetchProjects]);

  const startProjectDiagnoseWorkflow = useCallback(async (projectId: string): Promise<KSwarmWorkflowRun | null> => {
    const result = await httpPost<{ ok: boolean; workflowRun?: KSwarmWorkflowRun }>(`/projects/${projectId}/workflows/project-diagnose`, {
      requestedBy: 'human',
    });
    if (result?.ok) fetchProjects();
    return result?.workflowRun || null;
  }, [fetchProjects]);

  const startProjectAgentReviewSmokeWorkflow = useCallback(async (projectId: string): Promise<KSwarmWorkflowRun | null> => {
    const result = await httpPost<{ ok: boolean; workflowRun?: KSwarmWorkflowRun }>(`/projects/${projectId}/workflows/agent-review-smoke`, {
      requestedBy: 'human',
    });
    if (result?.ok) fetchProjects();
    return result?.workflowRun || null;
  }, [fetchProjects]);

  const createWorkflowProposal = useCallback(async (projectId: string, workflowId: string, options: { taskId?: string } = {}): Promise<KSwarmWorkflowProposal | null> => {
    const result = await httpPost<{ ok: boolean; workflowProposal?: KSwarmWorkflowProposal }>(`/projects/${projectId}/workflows/${workflowId}/proposal`, {
      requestedBy: 'human',
      taskId: options.taskId,
    });
    return result?.ok ? (result.workflowProposal || null) : null;
  }, []);

  const startWorkflowRunFromProposal = useCallback(async (projectId: string, workflowId: string, proposalId: string, options: { taskId?: string } = {}): Promise<KSwarmWorkflowRun | null> => {
    const result = await httpPost<{ ok: boolean; workflowRun?: KSwarmWorkflowRun }>(`/projects/${projectId}/workflows/${workflowId}/runs`, {
      proposalId,
      approvedBy: 'human',
      taskId: options.taskId,
    });
    if (result?.ok) fetchProjects();
    return result?.workflowRun || null;
  }, [fetchProjects]);

  const cancelWorkflowRun = useCallback(async (projectId: string, workflowRunId: string): Promise<KSwarmWorkflowRun | null> => {
    const result = await httpPost<{ ok: boolean; workflowRun?: KSwarmWorkflowRun }>(`/projects/${projectId}/workflows/${workflowRunId}/cancel`, {
      reason: 'human_cancelled',
    });
    if (result?.ok) fetchProjects();
    return result?.workflowRun || null;
  }, [fetchProjects]);

  // ─── Task Actions ─────────────────────────────────────────────

  const humanAddTasks = useCallback(async (projectId: string, tasks: Array<{ title: string; description?: string; assignedAgent?: string }>): Promise<boolean> => {
    const result = await httpPost<{ ok: boolean }>(`/projects/${projectId}/tasks/human`, { tasks });
    return !!result?.ok;
  }, []);

  const createTasks = useCallback(async (projectId: string, tasks: Array<{ title: string; description?: string; phase?: number }>): Promise<boolean> => {
    const result = await httpPost<{ ok: boolean }>(`/projects/${projectId}/tasks`, { tasks });
    return !!result?.ok;
  }, []);

  const dispatchTasks = useCallback(async (projectId: string, fromAgent?: string): Promise<DispatchTasksResult | null> => {
    return await httpPost<DispatchTasksResult>(`/projects/${projectId}/dispatch`, { fromAgent });
  }, []);

  const markTaskDone = useCallback(async (projectId: string, taskId: string, fromAgent?: string): Promise<boolean> => {
    const res = await httpPost<{ ok: boolean }>(`/projects/${projectId}/tasks/${taskId}/done`, { fromAgent });
    return !!res?.ok;
  }, []);

  const cancelTask = useCallback(async (projectId: string, taskId: string): Promise<boolean> => {
    const res = await httpPost<{ ok: boolean }>(`/projects/${projectId}/tasks/${taskId}/cancel`);
    return !!res?.ok;
  }, []);

  const taskFailed = useCallback(async (projectId: string, taskId: string, failureReason?: string, errorMessage?: string) => {
    return await httpPost<{ ok: boolean; retried?: boolean; retryTaskId?: string; attempt?: number; failureReason?: string }>(
      `/projects/${projectId}/tasks/${taskId}/fail`,
      { failureReason, errorMessage },
    );
  }, []);

  // ─── Agent Actions ────────────────────────────────────────────

  const fetchAgents = useCallback(async (): Promise<KSwarmAgent[]> => {
    const data = await httpGet<{ agents: KSwarmAgent[] }>('/agents');
    if (!Array.isArray(data?.agents)) {
      return agentsRef.current;
    }
    const list = data.agents;
    agentsRef.current = list;
    setAgents(list);
    return list;
  }, []);

  const fetchParticipants = useCallback(async (): Promise<KSwarmParticipant[]> => {
    const data = await httpGet<{ participants: KSwarmParticipant[] }>('/participants');
    if (!Array.isArray(data?.participants)) {
      return participantsRef.current;
    }
    const list = data.participants;
    participantsRef.current = list;
    setParticipants(list);
    return list;
  }, []);

  const createAgent = useCallback(async (input: CreateAgentInput): Promise<KSwarmAgent | null> => {
    const desktopApi = getDesktopApi();
    const result = desktopApi?.createKSwarmAgent
      ? readSemanticAgent(await desktopApi.createKSwarmAgent(toSemanticAgentInput(input) as KSwarmAgentSemanticInput))
      : null;
    if (result) fetchAgents();
    return result;
  }, [fetchAgents]);

  const updateAgent = useCallback(async (id: string, input: Partial<CreateAgentInput>): Promise<KSwarmAgent | null> => {
    const desktopApi = getDesktopApi();
    const result = desktopApi?.updateKSwarmAgent
      ? readSemanticAgent(await desktopApi.updateKSwarmAgent({ agentId: id, patch: toSemanticAgentInput(input) }))
      : null;
    if (result) fetchAgents();
    return result;
  }, [fetchAgents]);

  const archiveAgent = useCallback(async (id: string): Promise<boolean> => {
    const desktopApi = getDesktopApi();
    const ok = desktopApi?.archiveKSwarmAgent
      ? readSemanticOk(await desktopApi.archiveKSwarmAgent({ agentId: id }))
      : false;
    if (ok) fetchAgents();
    return ok;
  }, [fetchAgents]);

  const startAgent = useCallback(async (id: string): Promise<boolean> => {
    const desktopApi = getDesktopApi();
    const ok = desktopApi?.startKSwarmAgent
      ? readSemanticOk(await desktopApi.startKSwarmAgent({ agentId: id }))
      : false;
    if (ok) fetchAgents();
    return ok;
  }, [fetchAgents]);

  const stopAgent = useCallback(async (id: string): Promise<boolean> => {
    const desktopApi = getDesktopApi();
    const ok = desktopApi?.stopKSwarmAgent
      ? readSemanticOk(await desktopApi.stopKSwarmAgent({ agentId: id }))
      : false;
    if (ok) fetchAgents();
    return ok;
  }, [fetchAgents]);

  const planProjectTeam = useCallback(async (input: { projectId: string }): Promise<ProjectTeamPlanView> => {
    const desktopApi = getDesktopApi();
    if (!desktopApi?.planProjectTeam) throw new Error('kswarm_team_api_unavailable');
    return desktopApi.planProjectTeam(input);
  }, []);

  const applyProjectTeamPlan = useCallback(async (input: { projectId: string; planId: string; projectRevision: number }): Promise<ProjectTeamOperationView> => {
    const desktopApi = getDesktopApi();
    if (!desktopApi?.applyProjectTeamPlan) throw new Error('kswarm_team_api_unavailable');
    const operation = await desktopApi.applyProjectTeamPlan(input);
    fetchProjects();
    fetchAgents();
    return operation;
  }, [fetchAgents, fetchProjects]);

  const getProjectTeamOperation = useCallback(async (input: { projectId: string }): Promise<ProjectTeamOperationView | null> => {
    const desktopApi = getDesktopApi();
    if (!desktopApi?.getProjectTeamOperation) return null;
    return desktopApi.getProjectTeamOperation(input);
  }, []);

  const probeAgent = useCallback(async (id: string): Promise<AgentProbe | null> => {
    const desktopApi = getDesktopApi();
    return desktopApi?.probeKSwarmAgent
      ? await desktopApi.probeKSwarmAgent({ agentId: id }) as AgentProbe
      : null;
  }, []);

  const fetchLiveness = useCallback(async () => {
    const data = await httpGet<{ liveness: Record<string, { lastSeen: number | null; online: boolean; status: string }> }>('/agents/liveness');
    return data?.liveness || {};
  }, []);

  const pingHeartbeat = useCallback(async (agentId: string): Promise<boolean> => {
    const res = await httpPost<{ ok: boolean }>('/agents/heartbeat', { agentId });
    return !!res?.ok;
  }, []);

  const fetchRuntimes = useCallback(async () => {
    const data = await httpGet<{ runtimes: Array<{ type: string; displayName: string; description: string; detected: boolean; supported?: boolean; path: string | null }> }>('/runtimes');
    return data?.runtimes || [];
  }, []);

  const fetchLlmProviders = useCallback(async () => {
    const data = await httpGet<{ providers: string[] }>('/llm/providers');
    return data?.providers || [];
  }, []);

  return {
    // State
    connected,
    projects,
    projectsLoaded,
    agents,
    participants,
    lastEvent,
    lastEventSeq,
    getLastEvent,
    // Project actions
    fetchProjects,
    getProjectDetail,
    getProjectFullDetail,
    createProject,
    updateProjectExecutionMode,
    approveProject,
    retryPlan,
    continueProject,
    closeProject,
    deleteProject,
    planProjectTeam,
    applyProjectTeamPlan,
    getProjectTeamOperation,
    deliverProject,
    startProjectDiagnoseWorkflow,
    startProjectAgentReviewSmokeWorkflow,
    createWorkflowProposal,
    startWorkflowRunFromProposal,
    cancelWorkflowRun,
    // Task actions
    humanAddTasks,
    createTasks,
    dispatchTasks,
    markTaskDone,
    cancelTask,
    taskFailed,
    // Agent actions
    fetchAgents,
    fetchParticipants,
    createAgent,
    updateAgent,
    archiveAgent,
    startAgent,
    stopAgent,
    probeAgent,
    fetchLiveness,
    pingHeartbeat,
    fetchRuntimes,
    fetchLlmProviders,
  };
}
