import { readChannelViews, readMcpInstallViews } from './channel-mcp-readonly-data.js';
import { captureSkillReadonlyPromise } from './skill-readonly-data.js';
import { types as skillNodeTypes } from 'node:util';
import type {ConnectorsMutationRequest} from '../shared/connectors-ipc-contract.js';
import type { DesktopSkillStats } from '../shared/desktop-diagnostics-ipc-contract.js';
import { captureModelProviderInput } from './model-provider-typed-ipc.js';
import { MODEL_PROVIDER_ID_SCHEMA, SAVE_MODEL_CONFIG_SCHEMA, UPDATE_MODEL_RUNTIME_SCHEMA, SYSTEM_ONE_PATCH_SCHEMA, MANAGED_AGENT_INPUT_SCHEMA, PROVIDER_CONNECTION_INPUT_SCHEMA } from '../shared/model-provider-ipc-contract.js';
import {createNativeWorkflowRestrictionCheckpoint,bindNativeWorkflowRestrictionCheckpoint,assertNativeRegistryCheckpointCurrent,type NativeWorkflowRestrictionCheckpoint} from '../../src/runtime/task-host/workflow-restriction-checkpoint.js';
import { getBuiltinToolIdentity } from '../../src/ai/tools/native-tool-identity.js';
import type { ToolDescriptionMetadata } from '../../src/shared/tool-description-metadata.js';
import { ensureConversationActivityOwner } from '../../src/runtime/conversation-activity/owner-launcher.js';
import { ConversationActivityAttachedService } from '../../src/runtime/conversation-activity/owner-service.js';
import { ConversationActivityAttachedSources } from '../../src/runtime/conversation-activity/owner-source-client.js';
import type { ActivityOwnerConfig } from '../../src/runtime/conversation-activity/owner-runtime.js';
import { formatTaskToolResultResponse } from '../../src/runtime/task-host/tool-result-response.js';
import { resolveKSwarmReviewReadPaths } from './kswarm-review-files.js';
import { ConversationRoomService, createConversationRoomTool } from './conversation-room-service.js';
import { KSwarmExecutionClock, resolveKSwarmWorkerRunMs } from './kswarm-execution-clock.js';
import { findLegacyTaskHistory } from './legacy-task-history.js';
import { getSupportedModelReasoningEfforts } from '../../src/ai/providers/model-reasoning-effort.js';
import { resolveProviderTransport } from '../../src/ai/providers/auth-resolver.js';
import {createBackgroundTaskIdentityController} from './background-task-identity.js';
import { FileGoalNativeJournal } from '../../src/runtime/goal/native-mutation-journal.js';
import type { GoalCreationInput } from '../../src/runtime/goal/types.js';
import { createDesktopGoalShutdownOwner } from './desktop-goal-shutdown-owner.js';
import {getCompoundPublicationOwnerBinding} from '../../src/runtime/sol-pi/compound-managed-lifecycle.js';
import {getTaskHostCompoundFinalPublicationReceipt} from '../../src/runtime/task-host/compound-final-publication-receipt.js';
import { createDesktopProductObservationGroup } from './desktop-observation-group.js';
import {computeSessionHistoryDigest} from '../../src/ai/runtime/session-store/store.js';
import {bindCompoundFinalPublicationConsumer,runCompoundPublicationIteration,hasCompoundFinalPublicationConsumer,publishCompoundFinalPublication} from '../../src/runtime/sol-pi/compound-publication-producer.js';
import { MULTI_AGENT_TOOL_NAMES } from '../../src/ai/tools/multi-agent.js';
import {createDesktopObservationLifecycle} from './desktop-observation-lifecycle.js';
import { consumeDesktopObservationApproval, type ApprovedDesktopObservation } from './desktop-observation-approval.js';
import { createDesktopProductObservationBinding, requireDesktopObservationBinding, takeDesktopSemanticBoundary, recordDesktopSemanticOutcome, type DesktopObservationBinding, type DesktopObservationTaskActivation } from './desktop-observation-owner.js';
import { withObservationExecutionOwner } from '../../src/runtime/sol-pi/observation-execution-scope.js';
import type { ObservationSessionOwner } from '../../src/runtime/sol-pi/observation-session-owner.js';
import { projectDesktopToolResultForModel } from './desktop-tool-result.js';
import { withObservationMetrics, measureToolResult } from '../../src/runtime/trace/observation-metrics.js';
import { createProjectAgentModel, validateProjectAgentModelSelection, type ProjectAgentModel } from './project-agent-model.js';
import {runMonitoredTool} from '../../src/runtime/tool-execution-health.js';
import {createRoomToolRegistry,runRoomWorkspaceExecutor,roomUnsupportedCapabilities,type RoomWorkspaceRunOptions} from './room-workspace-executor.js';
import {assembleRoomWorkspaceContext,resolveRoomWorkspaceContextLimit,type RoomWorkspaceContextSources} from './room-workspace-context.js';
import { CodexTaskBridge, LOCAL_CODEX_MODEL } from './codex-task-bridge.js';
import type { NativeActor } from './codex-native-service.js';
import { accessSync, constants as fsConstants, mkdirSync, readFileSync, writeFileSync, existsSync, readdirSync, renameSync, statSync, realpathSync } from 'node:fs';
import { join, extname, basename, dirname, resolve, relative, isAbsolute, sep } from 'node:path';
import { writeFile as writeFileAsync, readFile as readFileAsync, mkdir as mkdirAsync, mkdtemp, rm as rmAsync } from 'node:fs/promises';
import { homedir, platform } from 'node:os';
import { buildDesktopSystemPrompt, VISUAL_PDF_EXPORT_GUIDANCE } from './desktop-system-prompt.js';
import { spawnSync, execFile } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { parseGoalRequestId, type GoalAttachmentRequest } from '../shared/goal-attachment.js';
import { bumpSkillCatalogVersion, getSkillCatalogVersion } from './skill-catalog-invalidation.js';
import { createAdapter, createAdapterFromBinding } from '../../src/ai/models.js';
import type { ModelInvocationOptions, StreamOptions } from '../../src/ai/runtime/model-capabilities.js';
import { createDesktopPromptCacheAffinity } from '../../src/ai/runtime/prompt-cache-affinity.js';
import { resolveRuntimeModelBinding } from '../../src/ai/providers/control-plane.js';
import { findCatalogModel, getProviderProfile, listProviderProfiles } from '../../src/ai/providers/registry.js';
import {
  isOfficialKimiK3OpenAIEndpoint,
  resolveModelRuntimeOptions,
} from '../../src/ai/providers/model-runtime-options.js';
import { resolveModelHarnessProfile } from '../../src/ai/providers/model-harness-profile.js';
import {
  isStrictKimiK3Adapter,
  projectStrictToolExecutionContext,
} from '../../src/ai/runtime/provider-private-projection.js';
import {
  streamDesktopTaskProviderConversation,
  streamStatelessSideCallProviderConversation,
} from '../../src/ai/runtime/provider-conversation-authorization.js';
import type {
  ModelConfigEntry,
  ModelRuntimeConstraints,
  ModelRuntimeOptions,
  ProtocolId,
  ProviderModelVariant,
} from '../../src/ai/providers/types.js';
import { MaterialRegistry } from '../../src/runtime/task-host/material-registry.js';
import { FileTaskSnapshotStore } from '../../src/runtime/task-host/snapshot-store.js';
import { InProcessTaskRuntimeHost, createTaskSourceWriterPopulation, type TaskRunner, type TaskRunnerInput } from '../../src/runtime/task-host/task-runtime-host.js';
import { loadCustomAgents } from '../../src/ai/agents/loader.js';
import { PermissionManager } from '../../src/ai/permissions/manager.js';
import { DesktopMultiAgentStore } from './desktop-multi-agent-store.js';
import { DesktopMultiAgentService, type DesktopAgentExecutionContext, type DesktopHostDeliveryAuthority } from './desktop-multi-agent-service.js';
import { DesktopMultiAgentApprovalTransport } from './desktop-multi-agent-approval-transport.js';
import { DesktopMultiAgentRuntime } from './desktop-multi-agent-runtime.js';
import { getDesktopDelegationPolicy } from './desktop-delegation-policy.js';
import { streamDesktopTaskRecovery, createDesktopModelPhysicalScope, admitDesktopModelPhysicalRead, closeDesktopModelPhysicalScope, type DesktopModelPhysicalScope, type DesktopTaskRequestPreparer } from './desktop-task-stream.js';
import { DesktopMultiAgentWorktrees } from './desktop-multi-agent-worktrees.js';
import { DesktopOwnedToolRegistry, DesktopToolCatalogBridge } from './desktop-multi-agent-catalog-bridge.js';
import { DesktopMcpCatalogRegistration } from './desktop-mcp-catalog-registration.js';
import { projectRuntimeEventsToDesktopEvents } from '../../src/runtime/task-host/event-projection.js';
import type { ArtifactSummary, DesktopTaskEvent, MaterialRecord, MaterialRole, TaskCreateContext, TaskCreateInput, TaskSnapshot, TaskUnderstanding } from '../../src/runtime/task-host/types.js';
import type { RuntimeEvent } from '../../src/runtime/events.js';
import { diagnoseTraceBundle } from '../../src/runtime/diagnostics/diagnoser.js';
import { diagnoseProjectSnapshot } from '../../src/runtime/diagnostics/project-diagnoser.js';
import type { DiagnosisReport } from '../../src/runtime/diagnostics/types.js';
import { extractMaterialText, MATERIAL_EXTRACTOR_VERSION, type OfficeTextExtractionResult } from '../../src/runtime/materials/text-extractor.js';
import { createOfficeDocumentParser } from './office-document-parser.js';
import {
  buildProjectTraceBundleFromKSwarmDetail,
  buildSessionTraceBundleFromSnapshots,
  loadTaskSnapshotsForSession,
  writeTraceBundleToPath,
} from '../../src/runtime/trace/exporter.js';
import type { Config, Message, MessageBlock, ModelAdapter, StreamChunk, ToolCall, ToolDefinition, ToolExecutionContext } from '../../src/types.js';
import type { DesktopMailboxPort } from '../shared/multi-agent-types.js';
import { DesktopMultiAgentIterationLimitError, captureDesktopMailboxSemanticBoundary } from './desktop-multi-agent-mailbox.js';
import { buildToolList, createToolInputAdmissionGuard, isSuccessfulModelToolResult, ToolRegistry } from '../../src/ai/tools/index.js';
import { createGoalTools } from '../../src/ai/tools/goal.js';
import type { GoalInput } from '../../src/runtime/goal/types.js';
import { createSkillCatalog, parseSlashCommand, formatSkillsContext, findSkillByCommandName, type SkillMeta, type SkillCatalog } from '../../src/ai/skills/loader.js';
import { createSkillTool } from '../../src/ai/skills/tool.js';
import { captureIpcData } from './ipc-data-snapshot.js';
import { SKILL_DEBUG_CONFIG_SCHEMA, KSWARM_CONCURRENCY_CONFIG_SCHEMA } from '../shared/desktop-small-config-ipc-contract.js';
import { getConfigDir, getConfigPath, loadConfig, saveConfig } from '../../src/utils/config.js';
import { resolveSystemOneConfig, setSystemOneConfig } from '../../src/ai/providers/system-one-config.js';
import type { SystemOneConfig } from '../../src/types.js';
import { createIntentDelegationTools } from '../../src/ai/tools/intent-delegation.js';
import { analyzeIntent as analyzeStageIntent } from '../../src/runtime/stage/executor.js';
import { createEmptySessionIntentLedger, cloneSessionIntentLedger, createIntentLedgerRecord, type SessionIntentLedger, type IntentPlanDraft, type IntentLedgerRecord } from '../../src/runtime/intent-delegation/types.js';
import { DELEGATION_TEMPLATES } from '../../src/ai/intent-delegation/templates.js';
import { buildSkillInvocation, createSkillBundleRefsTool, checkBudget, appendTrace } from './skill-runtime.js';
import type { SkillInvocation } from './skill-runtime.js';
import type { Tool } from '../../src/types.js';
import type { TimedActionService } from './timed-action-service.js';
import type { TimedActionTrigger } from './timed-action-types.js';
import { ConnectorsService } from './connectors-service.js';
import { ConnectorsStore } from './connectors-store.js';
import { maybePersistToolResult, buildViewForAPI, shouldAutoCompact, compactConversation, getContextLimit } from './context-manager.js';
import {
  normalizeMcpRuntimeToolResult,
  type McpInvocationOptions,
} from '../../src/ai/mcp/runtime/client.js';
import type { McpToolSchema } from '../../src/ai/mcp/client.js';
import { buildMcpRuntimeTools } from '../../src/ai/mcp/runtime/tools.js';
import {
  callMcpToolWithSignal,
  createMcpClientConnection,
  getMcpConnectionStderrTail,
  resolveMcpCatalogTimeoutMs,
  resolveMcpCallToolTimeoutMs,
  type McpClientConnection,
} from '../../src/platform/mcp/transport.js';
import { classifyMcpStartupError, type McpErrorDetail } from './mcp-error-classifier.js';
import { loadPlugins } from '../../src/platform/plugins/loader.js';
import {
  buildOfficialInstallerExecution,
  getPluginDependencyStatus,
  isDependencyPlatformSupported,
  type ExternalPluginDependency,
  type PluginDependencyStatusOptions,
} from './plugin-dependency-service.js';
import { DependencyTaskOwner, runDependencyProcess } from './dependency-task.js';
import { downloadDependencyAsset, installPrivateCuaRelease, resolveActivePrivateCuaRelease } from './cua-release-install.js';
import { detectNativeWindowsArchitecture, detectWindowsInteractiveDesktop } from './windows-cua-host.js';
import { createWindowsCuaDependency, verifyWindowsCuaReadiness } from './windows-cua-runtime.js';
import { WINDOWS_CUA_ABI_PROFILE } from '../../src/platform/computer-use/windows-cua-profile.js';
import { InvocationToolImages } from './tool-image-channel.js';
import { runCuaMcpReadinessSmoke } from './cua-driver-manager.js';
import { UserMemoryStore } from './user-memory.js';
import { createComputerUseTool, type ComputerUseBackend, type ComputerUseUnavailableError } from '../../src/ai/tools/computer-use.js';
import {
  isComputerUseAutoConnectEligibleApp,
  loadComputerUsePreference,
  saveComputerUsePreference,
  type ComputerUseAppIdentity,
  type ComputerUseFailureCode,
  type ComputerUsePreference,
} from './computer-use-capability-service.js';
import { createNotebookTools } from '../../src/ai/tools/notebook.js';
import { createKbTools } from './kb-tools.js';
import { createKbStoreSqlite } from './kb-store-sqlite.js';
import { createKbRetriever } from './kb-retrieval.js';
import { createSourceExtractor } from './kb-source-extractor.js';
import type { MemoryRecord, MemoryStore } from '../../src/ai/memory/store.js';
import type { KSwarmService, KSwarmUnavailableError } from './kswarm-service.js';
import { JsonKSwarmInitialPlanBootstrapStore, KSwarmInitialPlanBootstrapQueue } from './kswarm-initial-plan-bootstrap.js';
import { extractCreatedAgentId, resolveCreateProjectMembers, sanitizeCreateProjectMembers } from './kswarm-project-tool.js';
import {
  createKSwarmGetDynamicWorkflowStatusTool,
  createKSwarmRunDynamicWorkflowScriptTool,
  isResumableWorkflowRunStatus,
  restoreWorkflowScriptBackgroundJob,
} from './kswarm-dynamic-workflow-script-tool.js';
import { XIAOK_PO_SEED_ID, getPreferredPoAgentId } from '../shared/kswarm-seed-contract.js';
import type { KSwarmTaskHandoff, KSwarmWorkflowNodeHandoff } from './kswarm-runtime-bridge.js';
import type { CollaborationRoomTurnEnvelope } from './collaboration-room-wake-dispatcher.js';
import { parseCollaborationRoomTurnEnvelope } from './collaboration-room-wake-dispatcher.js';
import { registerRoomHistoryCapability, releaseRoomHistoryCapability } from './room-history-capability-registry.js';
import { createGetRoomMessagesPageTool, setRoomHistoryBrokerClient } from './room-history-page-tool.js';
import { createAllHostGateways, type GatewayRuntimeFacade } from './provider-gateways/create-host-gateways.js';
import { reservedProviderSpecs, type ReservedProviderBridge } from './provider-gateways/reserved-provider-specs.js';
import type { PluginComponentSpec } from '../../src/platform/provider-runtime/lifecycle-reconciler.js';
import {
  DesktopGoalCoordinator,
  type DesktopGoalProjection,
  type PreparedGoalTask,
} from './desktop-goal-coordinator.js';
import { SqliteGoalStore } from './goal-store-sqlite.js';
import { DesktopExecutionCoordinator, currentExecutionLane, withExecutionLane } from './desktop-execution-coordinator.js';
import { ConversationProjectService, type ConversationProjectRoomClient } from './conversation-project-service.js';
import { ConversationActivityStore } from '../../src/runtime/conversation-activity/store.js';
import { ConversationActivityService, type ActivityActor, type ConversationActivityApi } from '../../src/runtime/conversation-activity/service.js';
import { ConversationActivitySources, type ProjectActivityPage } from '../../src/runtime/conversation-activity/sources.js';
import { ConversationMcpActivities } from '../../src/runtime/conversation-activity/mcp.js';
import { callMcpToolWithTasks } from '../../src/platform/mcp/tasks.js';
import type { ReportingPreference } from '../../src/runtime/conversation-activity/types.js';
// NOTE: LayeredMemoryStore/resolveLayeredConfig are loaded dynamically
// because they import better-sqlite3 which may not be compatible with the current Electron
// version's native module ABI.
let _LayeredMemoryStoreClass: (typeof import('../../src/ai/memory/layered-store.js'))['LayeredMemoryStore'] | null = null;
let _resolveLayeredConfigFn: (typeof import('../../src/ai/memory/layered-store.js'))['resolveLayeredConfig'] | null = null;
try {
  const mod = await import('../../src/ai/memory/layered-store.js');
  _LayeredMemoryStoreClass = mod.LayeredMemoryStore;
  _resolveLayeredConfigFn = mod.resolveLayeredConfig;
} catch (e) {
  console.warn('[memory] Could not load layered-store module:', (e as Error).message);
}

// ---- Shared memory store (singleton per dataRoot) ----

let _desktopMemoryStore: MemoryStore | null = null;
let _desktopMemoryStoreDataRoot: string | null = null;
let _desktopMemoryStoreBackend: 'layered' | 'fallback' = 'fallback';

type DesktopFallbackMemoryStore = MemoryStore & {
  getStats(): { l0: number; l1: number; l2: number; l3: number; dbSizeBytes: number };
  clearAll(): void;
};

/**
 * Adapt UserMemoryStore (pure-JS, no native deps) to the MemoryStore interface.
 * Used as fallback when better-sqlite3 cannot load in this Electron version.
 */
function createFallbackMemoryStore(dataRoot: string): MemoryStore {
  const memoriesDir = join(dataRoot, 'memories');
  mkdirSync(memoriesDir, { recursive: true });
  const userStore = new UserMemoryStore(memoriesDir);

  const store: DesktopFallbackMemoryStore = {
    async save(record) {
      userStore.save({
        id: record.id,
        content: record.summary || record.title || '',
        tags: record.tags || [],
        createdAt: record.updatedAt,
        source: record.scope || 'global',
        scope: record.scope,
        cwd: record.cwd,
        type: record.type,
        provenance: record.provenance,
      });
    },
    async listRelevant({ cwd, query, typeFilter }) {
      const results = userStore.listRelevant({ cwd, query })
        .filter(memory => !typeFilter || memory.type === typeFilter)
        .slice(0, 20);
      return results.map(m => ({
        id: m.id,
        scope: m.scope ?? 'global',
        cwd: m.cwd,
        title: m.content.slice(0, 80),
        summary: m.content,
        tags: m.tags,
        updatedAt: m.createdAt,
        type: m.type ?? 'user',
        provenance: m.provenance?.kind === 'assistant_candidate'
          ? {
            kind: 'assistant_candidate' as const,
            candidateId: String(m.provenance.candidateId),
            loopRunId: String('loopRunId' in m.provenance ? m.provenance.loopRunId : m.provenance.runId),
            backend: 'fallback' as const,
            evidenceRefs: 'evidenceRefs' in m.provenance && Array.isArray(m.provenance.evidenceRefs)
              ? m.provenance.evidenceRefs as Array<{ kind: string; id: string }>
              : [],
          }
          : undefined,
      }));
    },
    async search(query, limit = 20) {
      const results = query ? userStore.search(query) : userStore.list();
      return results.slice(0, limit).map(m => ({
        id: m.id,
        scope: m.scope ?? 'global',
        cwd: m.cwd,
        title: m.content.slice(0, 80),
        summary: m.content,
        tags: m.tags,
        updatedAt: m.createdAt,
        type: m.type ?? 'user',
      }));
    },
    async delete(id: string, _layer?: number) {
      return userStore.delete(id);
    },
    getStats() {
      const list = userStore.list();
      return { l0: 0, l1: list.length, l2: 0, l3: 0, dbSizeBytes: 0 };
    },
    clearAll() {
      for (const m of userStore.list()) userStore.delete(m.id);
    },
  };
  return store;
}

export function getDesktopMemoryStore(dataRoot: string): MemoryStore {
  if (_desktopMemoryStore && _desktopMemoryStoreDataRoot === dataRoot) {
    return _desktopMemoryStore;
  }

  let store: MemoryStore;

  try {
    if (!_LayeredMemoryStoreClass || !_resolveLayeredConfigFn) {
      throw new Error('layered-store module not available');
    }
    const dbPath = join(dataRoot, 'memory.db');
    const config = _resolveLayeredConfigFn({ dbPath });
    const layeredStore = new _LayeredMemoryStoreClass(config);
    _desktopMemoryStoreBackend = 'layered';

    // Migrate from legacy user-memories.json if present
    const legacyPath = join(dataRoot, 'memories', 'user-memories.json');
    if (existsSync(legacyPath)) {
      try {
        const raw = readFileSync(legacyPath, 'utf-8');
        const entries = JSON.parse(raw) as Array<{
          id: string; content: string; tags: string[]; createdAt?: number;
          scope?: 'global' | 'project'; cwd?: string; type?: 'user' | 'feedback' | 'project' | 'reference';
          provenance?: MemoryRecord['provenance'];
        }>;
        if (Array.isArray(entries)) {
          for (const entry of entries) {
            void layeredStore.save({
              id: entry.id,
              scope: entry.scope ?? 'global',
              cwd: entry.cwd,
              title: (entry.content || '').slice(0, 80),
              summary: entry.content || '',
              tags: entry.tags || [],
              updatedAt: entry.createdAt || Date.now(),
              type: entry.type ?? 'user',
              provenance: entry.provenance,
            });
          }
          for (const entry of entries) {
            const migrated = layeredStore.getById(entry.id);
            if (!migrated || migrated.scope !== (entry.scope ?? 'global') || migrated.cwd !== entry.cwd
              || JSON.stringify(migrated.provenance) !== JSON.stringify(entry.provenance)) {
              throw new Error(`memory migration verification failed: ${entry.id}`);
            }
          }
        }
        // Rename to .migrated to avoid re-import
        renameSync(legacyPath, legacyPath + '.migrated');
      } catch (error) {
        console.warn('[memory] legacy migration failed; source preserved:', (error as Error).message);
        throw error;
      }
    }

    store = layeredStore;
  } catch (err) {
    console.warn('[memory] LayeredMemoryStore unavailable (native module issue), using fallback:', (err as Error).message);
    store = createFallbackMemoryStore(dataRoot);
    _desktopMemoryStoreBackend = 'fallback';
  }

  _desktopMemoryStore = store;
  _desktopMemoryStoreDataRoot = dataRoot;
  return store;
}

export function getDesktopMemoryBackend(dataRoot: string): 'layered' | 'fallback' {
  getDesktopMemoryStore(dataRoot);
  return _desktopMemoryStoreBackend;
}
import { buildPythonServerEnv, normalizePythonServerCommand } from './python-runtime.js';
import { buildManagedXiaokAgentPayload, buildManagedXiaokAgentSemanticPayload } from './managed-xiaok-agent.js';
import { ArtifactWorkspaceStore } from './artifact-workspace-store.js';
import { ArtifactWorkspaceFileManager } from './artifact-workspace-files.js';
import {
  ArtifactWorkspaceService,
  type ArtifactWorkspaceFeatureFlags,
} from './artifact-workspace-service.js';
import {
  createArtifactWorkspaceGenerationFileTools,
  createArtifactWorkspacePluginProducerTool,
  createArtifactWorkspaceTools,
  createArtifactWorkspaceUnavailableProducerTool,
} from './artifact-workspace-tools.js';

// ---- Skill stats types ----

interface SkillExecRecord {
  id: string;
  skillNames: string[];
  taskId: string;
  startTime: number;
  endTime: number;
  durationMs: number;
  status: 'success' | 'error' | 'cancelled';
  inputTokens: number;
  outputTokens: number;
  prompt: string;
  triggerType: 'slash_command' | 'tool_call' | 'auto';
}

export type SkillStats = DesktopSkillStats;

const EXEC_FILE = 'skill-exec.json';
const MAX_EXEC_RECORDS = 500;

async function appendExecRecord(dataRoot: string, record: SkillExecRecord): Promise<void> {
  try {
    const filePath = join(dataRoot, EXEC_FILE);
    let records: SkillExecRecord[] = [];
    try {
      const raw = await readFileAsync(filePath, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) records = parsed;
    } catch { /* file doesn't exist yet */ }
    records.push(record);
    if (records.length > MAX_EXEC_RECORDS) records.splice(0, records.length - MAX_EXEC_RECORDS);
    mkdirSync(dirname(filePath), { recursive: true });
    await writeFileAsync(filePath, JSON.stringify(records));
  } catch (e) { console.warn('[exec-record] append failed:', (e as Error).message) }
}

async function loadExecRecords(dataRoot: string): Promise<SkillExecRecord[]> {
  let raw: unknown;
  try { raw = await captureSkillReadonlyPromise(readFileAsync(join(dataRoot, EXEC_FILE), 'utf-8'), 'diagnostics_projection_unavailable'); }
  catch (error) {
    if (error && typeof error === 'object' && !skillNodeTypes.isProxy(error) && Object.getOwnPropertyDescriptor(error, 'code')?.value === 'ENOENT') return [];
    throw error;
  }
  if (typeof raw !== 'string') throw Error('diagnostics_projection_unavailable');
  const parsed = captureIpcData(JSON.parse(raw), 'diagnostics_projection_unavailable', { preserveDataPrototype: true });
  if (!Array.isArray(parsed)) throw Error('diagnostics_projection_unavailable');
  return parsed as SkillExecRecord[];
}

function aggregateStats(records: SkillExecRecord[]): SkillStats[] {
  const bySkill = new Map<string, { durations: number[]; successes: number; errors: number; calls: number; inputTokens: number; outputTokens: number; firstAt: number; lastAt: number }>();
  for (const r of records) {
    const names = r.skillNames.length > 0 ? r.skillNames : ['unknown'];
    for (const name of names) {
      const entry = bySkill.get(name) ?? { durations: [], successes: 0, errors: 0, calls: 0, inputTokens: 0, outputTokens: 0, firstAt: r.startTime, lastAt: r.endTime };
      entry.calls++;
      if (r.status === 'success') entry.successes++;
      if (r.status === 'error') entry.errors++;
      entry.durations.push(r.durationMs);
      entry.inputTokens += r.inputTokens;
      entry.outputTokens += r.outputTokens;
      if (r.startTime < entry.firstAt) entry.firstAt = r.startTime;
      if (r.endTime > entry.lastAt) entry.lastAt = r.endTime;
      bySkill.set(name, entry);
    }
  }
  return Array.from(bySkill.entries()).map(([skillName, e]) => {
    const sorted = [...e.durations].sort((a, b) => a - b);
    const p95Idx = Math.min(Math.floor(sorted.length * 0.95), sorted.length - 1);
    return {
      skillName,
      totalCalls: e.calls,
      successCount: e.successes,
      errorCount: e.errors,
      avgDurationMs: e.calls > 0 ? Math.round(e.durations.reduce((a, b) => a + b, 0) / e.calls) : 0,
      p95DurationMs: sorted[p95Idx] ?? 0,
      totalInputTokens: e.inputTokens,
      totalOutputTokens: e.outputTokens,
      lastCalledAt: e.lastAt,
      firstCalledAt: e.firstAt,
    };
  });
}

function extractSkillNames(input: Record<string, unknown>): string[] {
  const names: string[] = [];
  if (typeof input.name === 'string' && input.name.trim()) names.push(input.name.trim());
  if (Array.isArray(input.names)) {
    for (const n of input.names) {
      if (typeof n === 'string' && n.trim() && !names.includes(n.trim())) names.push(n.trim());
    }
  }
  return names.length > 0 ? names : ['unknown'];
}

export interface DesktopServicesOptions {
  notifyConversationActivity?: (activity: import('../../src/runtime/conversation-activity/types.js').ConversationActivity,
    watch: import('../../src/runtime/conversation-activity/types.js').WorkWatch) => Promise<'shown' | 'suppressed' | 'failed'>;
  /** Main-owned embedding/profile path; never accepted from renderer or tools. */
  knowledgeDbPath?: string;
  dataRoot: string;
  /** Main-owned working directory, never copied from renderer task input. */
  workspaceRoot?: string;
  /** Desktop main may restore independently authorized historical launch domains. */
  restoreHistoricalLaunchWorkspaces?: boolean;
  now?: () => number;
  runner?: TaskRunner;
  kswarmService: KSwarmService;
  pluginRootDir?: string;
  /** Main-owned bundled resource; only used to upgrade incompatible managed Windows CUA. */
  computerUseBundledPluginDir?: string;
  pluginDependencies?: Array<{ pluginName: string; dependency: ExternalPluginDependency }>;
  pluginDependencyStatusOptions?: PluginDependencyStatusOptions;
  computerUseAppIdentity?: ComputerUseAppIdentity;
  computerUsePreferencePath?: string;
  getComputerUseReadinessTarget?: () => { pid: number; window_id: number } | null;
  artifactWorkspaceFeatureFlags?: Partial<ArtifactWorkspaceFeatureFlags>;
  /**
   * Design v58 §4: the stable provider-runtime identity, created before services
   * exist so static gateways can capture it once for the process lifetime.
   */
  pluginProviderRuntime?: GatewayRuntimeFacade;
  readinessModelProbe?: () => Promise<{ ok: boolean; error?: string }>;
  executionCoordinator?: DesktopExecutionCoordinator;
  /** Main-process-owned managed Python readiness; undefined means still preparing/unavailable. */
  getManagedPythonCommand?: () => string | undefined;
}

const CUA_DRIVER_DEPENDENCY: ExternalPluginDependency = {
  id: 'cua-driver',
  kind: 'macos_app_cli',
  displayName: 'CUA Driver',
  envOverride: 'XIAOK_CUA_DRIVER_CMD',
  binaryCandidates: ['~/.local/bin/cua-driver', '/usr/local/bin/cua-driver', '/opt/homebrew/bin/cua-driver', 'cua-driver'],
  // Design v58 §6.1: 0.19.3 is the first version with a machine-readable
  // `mcp_invocation` and the app-daemon auto-relaunch proxy. Older versions fail
  // closed as dependency-update-required instead of resurrecting `open -n serve`.
  minVersion: '0.19.3',
  install: {
    kind: 'official_installer',
    sourceUrl: 'https://raw.githubusercontent.com/trycua/cua/main/libs/cua-driver/scripts/install.sh',
    sourceAllowlist: ['https://raw.githubusercontent.com/trycua/cua/main/libs/cua-driver/scripts/install.sh'],
    requiresUserConfirmation: true,
  },
  update: {
    kind: 'official_installer',
    sourceUrl: 'https://raw.githubusercontent.com/trycua/cua/main/libs/cua-driver/scripts/install.sh',
    sourceAllowlist: ['https://raw.githubusercontent.com/trycua/cua/main/libs/cua-driver/scripts/install.sh'],
    requiresUserConfirmation: true,
  },
  health: {
    version: ['~/.local/bin/cua-driver', '--version'],
    status: ['~/.local/bin/cua-driver', 'status'],
  },
  mcp: {
    serverName: 'cua-driver',
    command: '~/.local/bin/cua-driver',
    // Let cua-driver proxy through CuaDriver.app so macOS TCC attributes
    // Accessibility and Screen Recording to com.trycua.driver, not xiaok.
    args: ['mcp'],
    requiresUserActivation: true,
  },
};

export function createTimedActionTools(service: TimedActionService, timezone = Intl.DateTimeFormat().resolvedOptions().timeZone): Tool[] {
  return [
    {
      permission: 'safe',
      definition: {
        name: 'reminder_create',
        description: '创建到点通知提醒。只通知用户，不会自动执行 AI 任务；如果用户要小K未来检查/执行/生成，请使用 scheduled_task_create。',
        inputSchema: {
          type: 'object',
          properties: {
            content: { type: 'string', description: '提醒内容' },
            schedule_at: { type: 'number', description: '提醒时间戳（毫秒）' },
            timezone: { type: 'string', description: '时区，默认使用系统时区' },
          },
          required: ['content', 'schedule_at'],
        },
      },
      async execute(input, context) {
        input = captureIpcData(input, 'scheduled_input_invalid');
        const content = String(input.content ?? '').trim();
        const scheduleAt = Number(input.schedule_at ?? 0);
        if (!content || scheduleAt <= 0) {
          return 'Error: content 和 schedule_at 不能为空';
        }
        const tz = String(input.timezone ?? timezone);
        const record = service.createReminder(content, scheduleAt, tz, {requestSource: 'agent', ownerKind: 'agent_task', ownerId: context?.taskId ?? ''});
        return JSON.stringify({
          reminderId: record.reminderId,
          status: record.status,
          content: record.content,
          scheduleAt: record.scheduleAt,
          timezone: record.timezone,
          createdAt: record.createdAt,
          note: 'notification only; will not run AI tasks',
        }, null, 2);
      },
    },
    {
      permission: 'safe',
      definition: {
        name: 'reminder_list',
        description: '列出所有活跃的通知提醒',
        inputSchema: { type: 'object', properties: {} },
      },
      async execute() {
        return JSON.stringify(service.listReminders().map(r => ({
          reminderId: r.reminderId,
          status: r.status,
          content: r.content,
          scheduleAt: r.scheduleAt,
          timezone: r.timezone,
          createdAt: r.createdAt,
        })), null, 2);
      },
    },
    {
      permission: 'safe',
      definition: {
        name: 'reminder_cancel',
        description: '**严禁取消用户、助手或其他 agent 拥有的提醒**。只能取消由当前 agent 创建且仍由其拥有的通知提醒；提醒只通知，不执行 AI 任务。',
        inputSchema: {
          type: 'object',
          properties: {
            reminder_id: { type: 'string', description: '提醒 ID' },
          },
          required: ['reminder_id'],
        },
      },
      async execute(input, context) {
        input = captureIpcData(input, 'scheduled_input_invalid');
        const id = String(input.reminder_id ?? '').trim();
        if (!id) return 'Error: reminder_id 不能为空';
        const ok = service.cancelReminder(id, {requestSource: 'agent', ownerId: context?.taskId});
        return ok ? `已取消提醒 ${id}` : `未找到提醒 ${id}`;
      },
    },
    {
      permission: 'write',
      definition: {
        name: 'scheduled_task_create',
        description: '创建会在未来自动执行 AI 任务的定时任务。适用于“你/小K稍后检查/执行/生成”或“每隔N分钟检查直到完成”；不要用于单纯通知提醒。取消权限独立校验，不能把取消其他 owner 的任务写进 prompt。',
        inputSchema: {
          type: 'object',
          properties: {
            name: { type: 'string', description: '任务名称' },
            prompt: { type: 'string', description: '到期时创建 AI 任务使用的 prompt；只描述业务目标和停止条件，不把取消工具调用写成完成义务' },
            frequency: { type: 'string', enum: ['once', 'interval', 'daily', 'weekdays', 'weekly'] },
            schedule_at: { type: 'number', description: 'once 任务的执行时间戳（毫秒）' },
            interval_minutes: { type: 'number', description: 'interval 任务的分钟间隔，agent 创建时最小 5' },
            hour: { type: 'number', description: 'daily/weekdays/weekly 执行小时 0-23' },
            minute: { type: 'number', description: 'daily/weekdays/weekly 执行分钟 0-59' },
            day_of_week: { type: 'number', description: 'weekly 星期几，0=周日，1=周一' },
            max_runs: { type: 'number', description: '最大运行次数' },
            expires_at: { type: 'number', description: '过期时间戳（毫秒）' },
          },
          required: ['name', 'prompt', 'frequency'],
        },
      },
      async execute(input, context) {
        input = captureIpcData(input, 'scheduled_input_invalid');
        const name = String(input.name ?? '').trim();
        const prompt = String(input.prompt ?? '').trim();
        if (!name || !prompt) return 'Error: name 和 prompt 不能为空';
        let trigger: TimedActionTrigger;
        try {
          trigger = parseScheduledTaskTrigger(input);
        } catch (error) {
          return `Error: ${(error as Error).message}`;
        }
        try {
          const task = service.createScheduledTask({
            name,
            prompt,
            trigger,
            source: 'agent',
            createdByTaskId: context?.taskId,
            policy: {
              maxRuns: input.max_runs === undefined ? undefined : Number(input.max_runs),
              expiresAt: input.expires_at === undefined ? undefined : Number(input.expires_at),
            },
          }, {requestSource: 'agent', ownerId: context?.taskId});
          const action = service.getActions().find(a => a.id === task.id);
          return JSON.stringify({
            ok: true,
            taskId: task.id,
            name: task.name,
            frequency: trigger.kind,
            nextRunAt: task.nextRunAt,
            maxRuns: action?.policy.maxRuns,
            expiresAt: action?.policy.expiresAt,
            note: 'will create AI tasks automatically; cancellation is limited to the current agent-owned interval temporary task and remains service-authorized',
          }, null, 2);
        } catch (error) {
          return `Error: ${(error as Error).message}`;
        }
      },
    },
    {
      permission: 'safe',
      definition: {
        name: 'scheduled_task_list',
        description: '列出会自动执行 AI 任务的定时任务',
        inputSchema: { type: 'object', properties: {} },
      },
      async execute() {
        return JSON.stringify(service.listScheduledTasks(), null, 2);
      },
    },
    {
      permission: 'write',
      definition: {
        name: 'scheduled_task_cancel',
        description: '**严禁 agent 取消 user-owned 或 assistant-owned 定时任务**。此工具只能请求取消由当前 agent 拥有的 interval 临时任务；service 会按 requestSource 和 ownerId default-deny 校验，权限不匹配时拒绝且不修改任务。',
        inputSchema: {
          type: 'object',
          properties: {
            task_id: { type: 'string', description: 'scheduled_task_create 返回的 taskId' },
            reason: { type: 'string', description: '取消原因' },
          },
          required: ['task_id'],
        },
      },
      async execute(input, context) {
        input = captureIpcData(input, 'scheduled_input_invalid');
        const id = String(input.task_id ?? '').trim();
        if (!id) return 'Error: task_id 不能为空';
        const target = service.listScheduledTasks().find(t => t.id === id);
        if (target && target.source === 'user') {
          return `Error: 不允许取消用户创建的定时任务 ${id}（"${target.name}"）。这类任务只能由用户在界面上取消。`;
        }
        const ok = service.cancelScheduledTask(id, String(input.reason ?? '').trim() || undefined, {
          requestSource: 'agent',
          ownerId: context?.taskId,
        });
        return ok ? `已取消自动任务 ${id}` : `未找到自动任务 ${id}`;
      },
    },
  ];
}

export function createRoomTimedActionTools(service:TimedActionService, scope:{roomId:string;logicalAgentId:string;bindingId:string;generation:number}):Tool[] {
  const ownerId=JSON.stringify([scope.roomId,scope.logicalAgentId]);
  const ownActions=()=>service.getActions().filter(action=>action.executor.kind==='agent_task'&&action.executor.roomTarget?.roomId===scope.roomId&&action.executor.roomTarget.logicalAgentId===scope.logicalAgentId&&action.ownerId===ownerId);
  return createTimedActionTools(service).filter(tool=>tool.definition.name.startsWith('scheduled_task_')).map(tool=>({...tool,
    definition:{...tool.definition,description:tool.definition.description+' Only the current collaboration room and current agent are in scope. Due tasks return to this room. Never manage other rooms or user-owned tasks.'},
    async execute(input){
      input = captureIpcData(input, 'scheduled_input_invalid');
      if(tool.definition.name==='scheduled_task_list')return JSON.stringify(ownActions());
      if(tool.definition.name==='scheduled_task_cancel'){
        const id=String(input.task_id??'');
        if(!ownActions().some(action=>action.id===id))return 'Error: room_schedule_forbidden';
        return JSON.stringify({ok:service.cancelScheduledTask(id,String(input.reason??''),{requestSource:'agent',ownerId})});
      }
      try {
        const name=String(input.name??'').trim(),prompt=String(input.prompt??'').trim();
        if(!name||!prompt)throw new Error('name and prompt required');
        const task=service.createRoomScheduledTask({name,prompt,trigger:parseScheduledTaskTrigger(input),policy:{maxRuns:input.max_runs===undefined?undefined:Number(input.max_runs),expiresAt:input.expires_at===undefined?undefined:Number(input.expires_at)}},scope,{requestSource:'agent',ownerId});
        return JSON.stringify({ok:true,taskId:task.id,nextRunAt:task.nextRunAt,roomId:scope.roomId});
      }catch(error){return `Error: ${error instanceof Error?error.message:String(error)}`;}
    }}));
}
function parseScheduledTaskTrigger(input: Record<string, unknown>): TimedActionTrigger {
  const frequency = String(input.frequency ?? '').trim();
  if (frequency === 'once') {
    const at = Number(input.schedule_at ?? 0);
    if (!Number.isFinite(at) || at <= 0) throw new Error('schedule_at 必须是有效时间戳');
    return { kind: 'once', at };
  }
  if (frequency === 'interval') {
    const intervalMinutes = Number(input.interval_minutes ?? 0);
    if (!Number.isFinite(intervalMinutes) || intervalMinutes <= 0) throw new Error('interval_minutes 必须大于 0');
    return { kind: 'interval', intervalMinutes };
  }
  if (frequency === 'daily' || frequency === 'weekdays') {
    return {
      kind: frequency,
      hour: Number(input.hour ?? 9),
      minute: Number(input.minute ?? 0),
    };
  }
  if (frequency === 'weekly') {
    return {
      kind: 'weekly',
      dayOfWeek: Number(input.day_of_week ?? 1),
      hour: Number(input.hour ?? 9),
      minute: Number(input.minute ?? 0),
    };
  }
  throw new Error('frequency 必须是 once、interval、daily、weekdays 或 weekly');
}

export interface DesktopModelProviderView {
  id: string;
  label: string;
  type: 'first_party' | 'custom';
  protocol: ProtocolId;
  baseUrl?: string;
  apiKeyConfigured: boolean;
}

export interface DesktopModelEntryView {
  projectAgentSelectable?: boolean;
  id: string;
  provider: string;
  model: string;
  label: string;
  capabilities?: string[];
  runtimeOptions?: ModelRuntimeOptions;
  runtimeConstraints?: ModelRuntimeConstraints;
  isDefault: boolean;
}

export interface DesktopProviderProfileView {
  id: string;
  label: string;
  protocol: ProtocolId;
  baseUrl?: string;
  defaultModelId: string;
  defaultModel: string;
  defaultModelLabel: string;
  capabilities?: string[];
  availableModels?: DesktopAvailableModelView[];
}

export interface DesktopAvailableModelView {
  modelId: string;
  model: string;
  label: string;
  capabilities?: string[];
  runtimeOptions?: ModelRuntimeOptions;
  runtimeConstraints?: ModelRuntimeConstraints;
}

export interface DesktopModelConfigSnapshot {
  configuredDefaultModelId?: string;
  configPath: string;
  defaultProvider: string;
  defaultModelId: string;
  providers: DesktopModelProviderView[];
  models: DesktopModelEntryView[];
  providerProfiles: DesktopProviderProfileView[];
}

export interface DesktopSaveModelConfigInput {
  providerId: string;
  modelId?: string | null;
  modelName?: string | null;
  label?: string | null;
  apiKey?: string | null;
  baseUrl?: string | null;
  protocol?: ProtocolId | null;
}

export interface DesktopUpdateModelRuntimeOptionsInput {
  modelId: string;
  runtimeOptions: ModelRuntimeOptions;
}

export interface DesktopSystemOneConfigSnapshot {
  configured: boolean;
  keySource: 'config' | 'env' | 'none';
  keyEnvVar: string | null;
  baseUrl: string;
  model: string;
  apiKeyMasked: string | null;
}

export interface DesktopSaveSystemOneConfigInput {
  apiKey?: string;
  baseUrl?: string;
  model?: string;
}

/**
 * 展示用掩码：与 CLI `doctor` 的 maskApiKey 同形。明文 Key 永不离开主进程，
 * renderer 只拿得到掩码后的字符串。
 */
function maskSystemOneKey(key: string): string {
  if (key.length <= 8) return '••••••••';
  return `${key.slice(0, 4)}${'•'.repeat(Math.min(key.length - 8, 12))}${key.slice(-4)}`;
}

function systemOneSnapshot(config: Pick<Config, 'systemOne'>): DesktopSystemOneConfigSnapshot {
  const resolved = resolveSystemOneConfig(config);
  return {
    configured: resolved.configured,
    keySource: resolved.keySource,
    keyEnvVar: resolved.keyEnvVar,
    baseUrl: resolved.baseUrl,
    model: resolved.model,
    apiKeyMasked: resolved.apiKey ? maskSystemOneKey(resolved.apiKey) : null,
  };
}

/**
 * `undefined` = 不变更，空串 = 清除该字段（与 `setSystemOneConfig` 语义一致）。
 * 只接受这三个已知字段，renderer 无法借这个入口写 providers/models。
 */
function sanitizeSystemOnePatch(input: DesktopSaveSystemOneConfigInput | undefined): SystemOneConfig {
  const patch: SystemOneConfig = {};
  for (const field of ['apiKey', 'baseUrl', 'model'] as const) {
    const value = input?.[field];
    if (value === undefined) continue;
    if (typeof value !== 'string') throw new Error(`systemOne.${field} 必须是字符串`);
    patch[field] = value;
  }
  return patch;
}

export function createDesktopServices(options: DesktopServicesOptions) {
  let roomTimedActions:TimedActionService|undefined;
  const getManagedPythonCommand = options.getManagedPythonCommand;
  const officeDocumentParser = createOfficeDocumentParser({
    onDiagnostic: diagnostic => console.info('[office-parser]', JSON.stringify(diagnostic)),
  });
  const materialRegistry = new MaterialRegistry({
    workspaceRoot: join(options.dataRoot, 'workspace'),
    maxBytes: 50 * 1024 * 1024,
    now: options.now,
  });
  const snapshotStore = new FileTaskSnapshotStore(join(options.dataRoot, 'tasks'));
  const taskSourcePopulation = createTaskSourceWriterPopulation(snapshotStore);
  const observationTasks = new Map<string, DesktopObservationTaskActivation>();
  let observationAdmissionBusy = false;
  const observationTaskControls = new Map<string, object>();
  const conversationRooms = new ConversationRoomService({ dataRoot: options.dataRoot });
  let activityStore: ConversationActivityStore | undefined;
  let activityService: ConversationActivityApi | undefined;
  let activitySources: ConversationActivitySources | ConversationActivityAttachedSources | undefined;
  let activityMcp: ConversationMcpActivities | undefined;
  const activityMcpConnections = new Set<McpClientConnection>();
  let unsubscribeActivityGroups: (() => void) | undefined;
  let activityAttachment: Promise<void> | undefined;
  let activityRoomClient: ConversationProjectRoomClient | undefined;
  const activityEnabled = !options.runner && process.env.XIAOK_CONVERSATION_ACTIVITY !== '0';
  const conversationProjects = new ConversationProjectService({ dataRoot: options.dataRoot, kswarmService: options.kswarmService,
    ...(activityEnabled ? { activityHooks: {
      prepare: async input => {
        await activityAttachment;
        if (!activityService) throw new Error('activity_unavailable');
        await activityService.prepareAssociation(input, { requestSource: 'user', actorId: `desktop-user:${multiAgentProfileId}` });
      },
      created: async input => {
        if (!activityService || !activitySources) throw new Error('activity_unavailable');
        const identity = await readActivityIdentity(input.projectId);
        if (!identity.ok || !identity.sourceDataEpoch || !identity.roomId || !activityRoomClient) throw new Error('activity_source_unsupported');
        const room = await activityRoomClient.getRoomSnapshot(identity.roomId);
        if (!isRecord(room) || room.ok === false || !isRecord(room.room)) throw new Error('activity_source_forbidden');
        const watchId = `project:${input.operationId}`;
        await activityService.bindWork({ operationId: input.operationId, watchId, source: 'kswarm',
          logicalSourceId: 'kswarm-local', sourceDataEpoch: identity.sourceDataEpoch, workId: input.projectId });
        await activitySources.startWatch(watchId);
        return { activityWatchId: watchId };
      },
    } } : {}) });
  const readActivityProject = async (projectId: string, after: number, signal: AbortSignal): Promise<ProjectActivityPage> => {
    const response = await options.kswarmService.request(`/projects/${encodeURIComponent(projectId)}/activity?after=${after}`, {
      signal, headers: { 'x-kswarm-mutation-token': options.kswarmService.getDesktopMutationToken() },
    });
    if (!response.ok) throw new Error(`activity_source_http_${response.status}`);
    return await response.json() as ProjectActivityPage;
  };
  const readActivityIdentity = async (projectId: string): Promise<{ ok: boolean; sourceDataEpoch?: string; roomId?: string }> => {
    const response = await options.kswarmService.request(`/projects/${encodeURIComponent(projectId)}/activity-identity`, {
      headers: { 'x-kswarm-mutation-token': options.kswarmService.getDesktopMutationToken() },
    });
    if (!response.ok) throw new Error(`activity_source_http_${response.status}`);
    return await response.json();
  };
  const executionCoordinator = options.executionCoordinator ?? new DesktopExecutionCoordinator({ backgroundCapacity: 1, projectControlCapacity: 1, projectWorkerCapacity: 3 });
  const scopedKSwarmHosts = new Set<WeakRef<InProcessTaskRuntimeHost>>();
  const resolveScopedTaskHost = (taskId: string, fallback: InProcessTaskRuntimeHost): InProcessTaskRuntimeHost => {
    for (const reference of scopedKSwarmHosts) {
      const owner = reference.deref();
      if (!owner) scopedKSwarmHosts.delete(reference);
      else if (owner.ownsLiveExecution(taskId)) return owner;
    }
    return fallback;
  };
  const coordinateRunner = (runner: TaskRunner): TaskRunner => input => (
    executionCoordinator.run(input.signal, () => runner(input))
  );
  const goalStore = new SqliteGoalStore(join(options.dataRoot, 'goals', 'goals.sqlite'));
  const goalChangedListeners = new Set<(input: { threadId: string; goal: DesktopGoalProjection }) => void>();
  const goalTaskPreparedListeners = new Set<(input: PreparedGoalTask) => void>();
  const artifactWorkspaceStore = new ArtifactWorkspaceStore({
    dbPath: join(options.dataRoot, 'artifact-workspace', 'workspace.sqlite'),
    now: options.now,
  });
  const artifactWorkspaceFileManager = new ArtifactWorkspaceFileManager({
    managedRoot: join(options.dataRoot, 'artifact-workspace', 'managed'),
  });
  let artifactWorkspaceService: ArtifactWorkspaceService | undefined;
  let goalCoordinator: DesktopGoalCoordinator | undefined;
  const builtinDescriptions = new Map<Tool, ToolDescriptionMetadata>();
  const tools = buildToolList(undefined, undefined, [], builtinDescriptions);
  const registry = new DesktopOwnedToolRegistry({ autoMode: true }, tools, builtinDescriptions);
  const staticGatewayNames = new Set(options.pluginProviderRuntime ? createAllHostGateways(options.pluginProviderRuntime).map(tool => tool.definition.name) : []);
  const multiAgentCwd = resolve(options.workspaceRoot ?? process.cwd());
  const multiAgentProfileId = createHash('sha256').update(resolve(options.dataRoot)).digest('hex');
  const multiAgentWorkspaceId = createHash('sha256').update(multiAgentCwd).digest('hex');
  const codexTasks = new CodexTaskBridge({ dataRoot: options.dataRoot, profileId: `desktop-user:${multiAgentProfileId}`, cwd: multiAgentCwd, materialRegistry, snapshotStore, sourcePopulation: taskSourcePopulation, admitThread: async threadId => {
    await multiAgentReady;
    const revision=multiAgentService?.assertExecutionAdmission(threadId);
    await prepareMultiAgentThread(threadId);
    const revalidate=()=>{multiAgentService?.assertExecutionAdmission(threadId,revision);};
    revalidate(); return revalidate;
  } });
  const modelSnapshot = (config: Config): DesktopModelConfigSnapshot => {
    const snapshot = createModelConfigSnapshot(config);
    snapshot.configuredDefaultModelId = config.defaultModelId;
    snapshot.providers.push({ id: LOCAL_CODEX_MODEL, label: 'Codex', type: 'custom', protocol: 'openai_responses', apiKeyConfigured: false });
    snapshot.models.push({ projectAgentSelectable: false, id: LOCAL_CODEX_MODEL, provider: LOCAL_CODEX_MODEL, model: LOCAL_CODEX_MODEL, label: 'Codex', isDefault: codexTasks.selected() });
    if (codexTasks.selected()) { snapshot.defaultModelId=LOCAL_CODEX_MODEL; snapshot.defaultProvider=LOCAL_CODEX_MODEL; for (const model of snapshot.models) model.isDefault=model.id===LOCAL_CODEX_MODEL; }
    return snapshot;
  };
  // Unknown injected runners and every non-local host remain ordinary.
  const multiAgentStore = options.runner ? undefined : new DesktopMultiAgentStore(join(options.dataRoot, 'multi-agent', 'groups.sqlite'));
  const observationLifecycle=createDesktopObservationLifecycle({tasksRoot:join(options.dataRoot,'tasks'),profileRoot:getConfigDir('observation-profile'),getDeletionState:threadId=>{const thread=multiAgentStore?.getThread(threadId);return thread?.deletionReceipt?{operationId:thread.deletionReceipt.operationId,completed:thread.deleteState==='deleted'&&thread.deletionReceipt.result.state==='completed'}:undefined;}});
  const observationLifecycleReady=observationLifecycle.recover();
  const multiAgentCatalog = multiAgentStore ? new DesktopToolCatalogBridge({ registry, workspaceId: multiAgentWorkspaceId,
    getService: () => multiAgentService }) : undefined;
  const multiAgentWorktrees = multiAgentStore ? new DesktopMultiAgentWorktrees({ store: multiAgentStore }) : undefined;
  let multiAgentRuntime: DesktopMultiAgentRuntime | undefined;
  const multiAgentService = multiAgentStore ? new DesktopMultiAgentService({ store: multiAgentStore, coordinator: executionCoordinator,
    worktrees: multiAgentWorktrees,
    executionDomain: Object.freeze({ profileId: multiAgentProfileId, workspaceId: multiAgentWorkspaceId, cwd: multiAgentCwd,
      actorId: `desktop-user:${multiAgentProfileId}` }),
    ...(options.restoreHistoricalLaunchWorkspaces ? { authorizeHistoricalThreadDomain: (thread: import('./desktop-multi-agent-store.js').MultiAgentThreadBinding): boolean => {
      // Only main-issued, existing bindings can qualify. No IPC/model path can
      // initialize a new workspace grant or override a revoked historical one.
      if (thread.profileId !== multiAgentProfileId || !isAbsolute(thread.cwd)
        || resolve(thread.cwd) !== thread.cwd || createHash('sha256').update(thread.cwd).digest('hex') !== thread.workspaceId) return false;
      const stored = multiAgentStore.getThread(thread.threadId);
      if (!stored || stored.profileId !== thread.profileId || stored.workspaceId !== thread.workspaceId || stored.cwd !== thread.cwd) return false;
      const authorization = multiAgentStore.readWorkspaceAuthorization({ profileId: thread.profileId, workspaceId: thread.workspaceId });
      return authorization?.executionAllowed === true;
    } } : {}),
    onExecutionAuthorizationChanged: snapshot => multiAgentCatalog!.applyExecutionAuthorization(snapshot),
    stopForWorkspaceExecutionRevocation: async () => {
      if (!goalCoordinator) throw new Error('multi_agent_goal_coordinator_unavailable');
      await codexTasks.stopForRevocation();
      return goalCoordinator.stopForWorkspaceExecutionRevocation({ requestSource: 'user' });
    },
    onRecoveredHostTerminal: async input => {
      if (input.snapshot.executionScope?.kind !== 'goal_turn') return;
      if (!goalCoordinator) throw new Error('multi_agent_goal_coordinator_unavailable');
      await goalCoordinator.handleRecoveredHostTerminal(input);
    },
    beforeThreadDeletionCommit:(threadId,operationId)=>observationLifecycle.beforeDelete(threadId,operationId),
    beforeThreadDeletion: async threadId => {
      const deletion = multiAgentStore?.getThread(threadId)?.deletionReceipt;
      if (deletion && activityService) {
        activityService.handleThreadDeletion(threadId, deletion.operationId);
        for (const watch of activityStore?.listWatches() ?? []) if (watch.origin.threadId === threadId) { activitySources?.stopWatch(watch.watchId); activityMcp?.stopWatch(watch.watchId); }
      }
      await codexTasks.stopThread(threadId);
      if (!goalCoordinator) throw new Error('multi_agent_goal_coordinator_unavailable');
      await goalCoordinator.stopForThreadDeletion({ threadId, requestSource: 'user' });
    },
    hasUnboundHistory: async threadId => Boolean(await goalStore.load(threadId)) || await snapshotStore.hasThreadHistory(threadId),
    prepareObservationSession: input => multiAgentRuntime!.prepareObservationSession(input),
    prepareObservationMessage: input => multiAgentRuntime!.prepareObservationMessage(input),
    prepareObservationFollowup: preparation => multiAgentRuntime!.prepareObservationFollowup(preparation),
    createSession: input => multiAgentRuntime!.createSession(input) }) : undefined;
  const multiAgentApprovals = multiAgentService ? new DesktopMultiAgentApprovalTransport({ store: multiAgentStore!, service: multiAgentService }) : undefined;
  if (multiAgentService) multiAgentRuntime = new DesktopMultiAgentRuntime({ service: multiAgentService, worktrees: multiAgentWorktrees, approvals: multiAgentApprovals });
  const initialPlanBootstrapStore = new JsonKSwarmInitialPlanBootstrapStore(options.dataRoot);
  const initialPlanBootstrapQueue = new KSwarmInitialPlanBootstrapQueue(
    initialPlanBootstrapStore,
    // Design R44-06: the producer receives the shutdown signal explicitly. The
    // broker call itself is not yet cancellable, so we fail fast at the job
    // boundary instead of starting work that nobody will await.
    (input, signal) => {
      if (signal.aborted) {
        return Promise.resolve({ ok: false as const, error: 'app_shutdown' });
      }
      return bootstrapKSwarmInitialPlan(input);
    },
    { now: options.now }
  );
  let kbStore: ReturnType<typeof createKbStoreSqlite> | undefined;
  const kswarmCreateProjectToolOptions: KSwarmCreateProjectToolOptions = {
    createRoom: (input, context) => conversationRooms.create(input, {...context, requestSource:'agent'}),
    enqueuePlanBootstrap: input => initialPlanBootstrapQueue.enqueue(input),
    finalizeProjectProposal: (proposal, context) => conversationProjects.isAuthorized(context.taskId)
      ? conversationProjects.create(proposal, { ...context, requestSource: 'agent' })
      : Promise.resolve(undefined),
  };
  registerKSwarmTools(registry, options.kswarmService, kswarmCreateProjectToolOptions);

  // Register KB (knowledge base) tools on the main registry
  try {
    const kbUserData = process.platform === 'win32'
      ? join(process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'), 'xiaok-desktop')
      : join(homedir(), 'Library', 'Application Support', 'xiaok-desktop');
    const kbDbPath = options.knowledgeDbPath ?? join(kbUserData, 'knowledge.db');
    kbStore = createKbStoreSqlite(kbDbPath);
    const kbRetriever = createKbRetriever({ db: (kbStore as any)._db ?? ({} as any), embedFn: () => null });
    const kbSourceExtractor = createSourceExtractor({ officeParser: officeDocumentParser });
    for (const tool of createKbTools(kbStore, kbRetriever, { sourceExtractor: kbSourceExtractor })) {
      registry.registerTool(tool);
    }
  } catch (e) {
    console.error('[KB] tool registration failed:', e);
  }

  initialPlanBootstrapQueue.startRecovery();
  // [2026-05-10] Intent delegation disabled — passive tracking only, no functional value.
  // See docs/2026-05-10-desktop-intent-delegation-removal.md
  // const intentStore = new InMemoryIntentLedgerStore();
  // intentStore.seedEmpty('desktop-session');
  // const intentTools = createIntentDelegationTools({
  //   ledgerStore: intentStore as never,
  //   sessionId: 'desktop-session',
  //   instanceId: 'desktop-instance',
  // });
  // registry.registerTool(intentTools[0]);

  // Track plugin MCP server runtime state for settings UI
  interface PluginMcpServerState {
    name: string;
    pluginName: string;
    toolCount: number;
    connected: boolean;
    enabled: boolean;
    lastError?: string;
    lastErrorDetail?: McpErrorDetail;
  }
  const pluginMcpServers: PluginMcpServerState[] = [];
  const pluginMcpDisposers: Array<{ name: string; pluginName: string; dispose: () => void | Promise<void> }> = [];
  const deferredPythonServerNames = new Set<string>();
  /**
   * Live handles for the reserved renderers, so the provider runtime's
   * ComponentSpecs can reach the same connection the loader just established
   * (design §4.5). Keyed by server name; replaced on every reconnect.
   */
  const reservedServerHandles = new Map<string, {
    listOperations: () => Promise<readonly string[]>;
    call: (name: string, input: Record<string, unknown>, options?: McpInvocationOptions) => Promise<string>;
    close: () => Promise<void>;
  }>();
  const servicesOptions = options;
  const pluginDependencies = options.pluginDependencies ?? [
    { pluginName: 'cua-computer-use', dependency: process.platform === 'win32' ? createWindowsCuaDependency(process.env.LOCALAPPDATA || join(homedir(), 'AppData', 'Local')) : CUA_DRIVER_DEPENDENCY },
  ];
  const pluginRootDir = options.pluginRootDir ?? getConfigDir('plugins');
  const computerUseBundledPluginDir = options.computerUseBundledPluginDir;
  const dependencyTasks = new DependencyTaskOwner();
  const computerUsePreferencePath = options.computerUsePreferencePath ?? join(options.dataRoot, 'computer-use-state.json');
  let computerUsePreference = loadComputerUsePreference(computerUsePreferencePath);
  const computerUseAppIdentity = options.computerUseAppIdentity ?? resolveComputerUseAppIdentity();
  let computerUseBackend: ComputerUseBackend | null = null;
  let computerUseLifecycleEpoch = 0;
  let computerUseActivation: {
    key: string;
    promise: Promise<PluginMcpServerState[]>;
    controller: AbortController;
  } | null = null;
  let computerUseWrapperRegistered = false;
  let windowsNativeArchitecture: Promise<string> | undefined;
  let computerUseObserved = false;
  let shimGeneration = 0;
  let shimGenerationKey = '';
  let computerUseUnavailableError: ComputerUseUnavailableError = !['darwin', 'win32'].includes(process.platform)
    ? {
        code: 'COMPUTER_USE_WRAPPER_NOT_READY',
        message: '当前平台或原生架构尚未支持 Computer Use。',
      }
    : computerUsePreference.lastFailureCode === 'COMPUTER_USE_DISABLED_BY_USER'
      ? buildComputerUseDisabledUnavailableError()
      : buildComputerUseNeedsEnablementError();

  function registerComputerUseWrapper(): void {
    if (computerUseWrapperRegistered) return;
    computerUseWrapperRegistered = true;
    const profile = process.platform === 'win32' ? WINDOWS_CUA_ABI_PROFILE : undefined;
    registry.registerTool(createComputerUseTool({
      abiProfile: profile,
      acquireInvocation: () => {
        const backend = computerUseBackend;
        if (!backend) return null;
        const epoch = computerUseLifecycleEpoch;
        const inner = backend.acquireInvocation?.();
        const key = `${epoch}:${inner?.generation ?? 0}`;
        if (shimGenerationKey !== key) { shimGenerationKey = key; shimGeneration += 1; }
        return { backend: inner?.backend ?? backend, generation: shimGeneration, isCurrent: () => backend === computerUseBackend && epoch === computerUseLifecycleEpoch && (!inner || inner.isCurrent()) };
      },
      getUnavailableError: () => computerUseBackend ? null : computerUseUnavailableError,
      onRecoverableError: (error) => {
        markComputerUseRecoverableFailure(error);
      },
      callToolResult: (name, input, options) => {
        options?.signal?.throwIfAborted();
        if (!computerUseBackend) {
          return Promise.resolve({
            text: computerUseUnavailableError.message,
            images: [],
            isError: true,
            summary: computerUseUnavailableError.code,
          });
        }
        return computerUseBackend.callToolResult(name, input, options);
      },
    }, profile));
  }
  if (process.platform === 'darwin') registerComputerUseWrapper();

  async function dependencyStatusOptions(): Promise<PluginDependencyStatusOptions> {
    if (process.platform !== 'win32') return options.pluginDependencyStatusOptions ?? {};
    windowsNativeArchitecture ??= options.pluginDependencyStatusOptions?.nativeOsArch
      ? Promise.resolve(options.pluginDependencyStatusOptions.nativeOsArch) : detectNativeWindowsArchitecture();
    return { ...options.pluginDependencyStatusOptions, nativeOsArch: await windowsNativeArchitecture };
  }
  async function qualifyComputerUse(): Promise<boolean> {
    const supported = process.platform === 'darwin' || (process.platform === 'win32'
      && process.arch === 'x64' && (await dependencyStatusOptions()).nativeOsArch === 'x64');
    if (supported) registerComputerUseWrapper();
    return supported;
  }

  const findPluginDependency = (pluginName: string, dependencyId: string) =>
    pluginDependencies.find((entry) => entry.pluginName === pluginName && entry.dependency.id === dependencyId);

  const findPluginDependencyForMcpServer = (pluginName: string, serverName: string) =>
    pluginDependencies.find((entry) => entry.pluginName === pluginName && entry.dependency.mcp?.serverName === serverName);

  const isPluginInstalled = (pluginName: string) =>
    existsSync(join(pluginRootDir, pluginName, 'plugin.json'));

  const getDependencyStatusView = async (entry: { pluginName: string; dependency: ExternalPluginDependency }) => {
    const facts = await dependencyStatusOptions();
    let dependency = entry.dependency;
    if (!options.pluginDependencies && process.platform === 'win32' && entry.pluginName === 'cua-computer-use'
      && entry.dependency.id === 'cua-driver' && facts.nativeOsArch === 'x64') {
      dependency = createWindowsCuaDependency(process.env.LOCALAPPDATA || join(homedir(), 'AppData', 'Local'), await resolveActivePrivateCuaRelease(options.dataRoot));
    }
    return { pluginName: entry.pluginName, pluginInstalled: isPluginInstalled(entry.pluginName),
      ...(await getPluginDependencyStatus(dependency, facts)), task: dependencyTasks.get(`${entry.pluginName}:${entry.dependency.id}`) };
  };

  const resolvePluginMcpLaunch = async (
    pluginName: string,
    serverName: string,
    fallbackCommand: string,
    fallbackArgs: string[],
  ): Promise<{ command: string; args: string[] }> => {
    const dependency = findPluginDependencyForMcpServer(pluginName, serverName);
    if (!dependency) return { command: fallbackCommand, args: fallbackArgs };
    const status = await getDependencyStatusView(dependency);
    if (status.state !== 'ready' || !status.resolvedBinary) {
      throw new Error(`Plugin dependency is not ready: ${status.code}`);
    }
    return {
      command: status.resolvedBinary,
      args: dependency.dependency.mcp?.args ?? fallbackArgs,
    };
  };

  async function runDependencyCommand(
    command: string,
    args: string[],
    timeout = 300_000,
  ): Promise<{ success: boolean; output?: string; error?: string }> {
    return runDependencyProcess(command, args, { timeoutMs: timeout });
  }

  async function mutatePluginDependency(input: { pluginName: string; dependencyId: string; confirmed?: boolean; requestSource: 'user' | 'agent' | 'scheduler' }, action: 'install' | 'update') {
    if (input.requestSource !== 'user') return { success: false, error: 'request_source_user_required' };
    const entry = findPluginDependency(input.pluginName, input.dependencyId);
    if (!entry) return { success: false, error: 'plugin_dependency_not_found' };
    if (!isDependencyPlatformSupported(entry.dependency, await dependencyStatusOptions())) return { success: false, error: 'unsupported_platform' };
    const config = action === 'install' ? entry.dependency.install : entry.dependency.update;
    if (!config) return { success: false, error: `plugin_dependency_${action}_not_available` };
    if (config.requiresUserConfirmation && !input.confirmed) return { success: false, error: 'confirmation_required' };
    try {
      return await dependencyTasks.run(`${entry.pluginName}:${entry.dependency.id}`, async signal => {
        let result: { success: boolean; output?: string; error?: string };
        if (config.kind === 'official_release_archive') {
          if (entry.dependency.id !== 'cua-driver' || entry.pluginName !== 'cua-computer-use') throw new Error('release_not_allowed');
          if (action === 'update' && process.env.XIAOK_CUA_DRIVER_CMD?.trim()) throw new Error('external_driver_update_not_allowed');
          await installPrivateCuaRelease(options.dataRoot, signal);
          result = { success: true };
        } else if (config.kind === 'official_installer') {
          if (process.platform !== 'darwin') throw new Error('unsupported_platform');
          if (!config.sourceAllowlist?.includes(config.sourceUrl)) throw new Error('installer_source_not_allowed');
          const installerRoot = join(options.dataRoot, 'runtime', 'plugin-installers');
          await mkdirAsync(installerRoot, { recursive: true });
          const staging = await mkdtemp(join(installerRoot, 'task-'));
          try {
            const bytes = await downloadDependencyAsset(config.sourceUrl, 2 * 1024 * 1024, signal);
            const script = join(staging, 'install.sh');
            await writeFileAsync(script, bytes, { flag: 'wx' });
            signal.throwIfAborted();
            const execution = buildOfficialInstallerExecution({ ...entry.dependency, install: config }, script, { confirmed: Boolean(input.confirmed) });
            result = await runDependencyProcess(execution.command, execution.args, { signal, timeoutMs: 300_000 });
          } finally { await rmAsync(staging, { recursive: true, force: true, maxRetries: 3 }).catch(() => {}); }
        } else {
          const status = await getDependencyStatusView(entry);
          signal.throwIfAborted();
          if (!status.resolvedBinary) throw new Error('plugin_dependency_binary_missing');
          result = await runDependencyProcess(status.resolvedBinary, config.args ?? [], { signal, timeoutMs: 300_000 });
        }
        signal.throwIfAborted();
        if (!result.success) return { success: false, error: result.error };
        return { success: true, status: await getDependencyStatusView(entry) };
      });
    } catch (error) { return { success: false, error: error instanceof Error ? error.message : String(error) }; }
  }

  const persistComputerUsePreference = (): void => {
    try {
      saveComputerUsePreference(computerUsePreferencePath, computerUsePreference);
    } catch {
      // Preference persistence is best-effort; runtime state still drives the current session.
    }
  };

  const recordComputerUseReady = (source: 'user_enable' | 'auto_recovery'): void => {
    const {
      lastFailureCode: _lastFailureCode,
      autoConnectSuspendedReason: _autoConnectSuspendedReason,
      ...preferenceWithoutFailure
    } = computerUsePreference;
    computerUsePreference = {
      ...preferenceWithoutFailure,
      schemaVersion: process.platform === 'win32' ? 2 : (computerUsePreference.schemaVersion ?? 1),
      ...(process.platform === 'win32' ? { platform: 'win32' as const } : {}),
      enabledByUser: source === 'user_enable' ? true : computerUsePreference.enabledByUser,
      autoConnectAfterSuccessfulEnablement: true,
      lastSuccessfulAt: options.now?.() ?? Date.now(),
      ...(computerUseAppIdentity.bundleId ? { lastSuccessfulAppBundleId: computerUseAppIdentity.bundleId } : {}),
      ...(computerUseAppIdentity.appPath ? { lastSuccessfulAppPath: computerUseAppIdentity.appPath } : {}),
      ...(computerUseAppIdentity.teamId ? { lastSuccessfulTeamId: computerUseAppIdentity.teamId } : {}),
      ...(computerUseAppIdentity.appAsarSha256 ? { lastSuccessfulAppAsarSha256: computerUseAppIdentity.appAsarSha256 } : {}),
    };
    persistComputerUsePreference();
  };

  const recordComputerUseFailure = (code: ComputerUseFailureCode): void => {
    const suspendsAutoConnect = code === 'COMPUTER_USE_NEEDS_ACCESSIBILITY'
      || code === 'COMPUTER_USE_NEEDS_SCREEN_RECORDING'
      || code === 'COMPUTER_USE_ATTRIBUTION_MISMATCH'
      || code === 'COMPUTER_USE_PERMISSION_INVALID'
      || code === 'COMPUTER_USE_DRIVER_MISSING'
      || code === 'COMPUTER_USE_PLUGIN_MISSING';
    computerUsePreference = {
      ...computerUsePreference,
      schemaVersion: process.platform === 'win32' ? 2 : (computerUsePreference.schemaVersion ?? 1),
      ...(process.platform === 'win32' ? { platform: 'win32' as const } : {}),
      lastFailureCode: code,
      ...(suspendsAutoConnect ? { autoConnectSuspendedReason: code } : {}),
    };
    persistComputerUsePreference();
  };

  const pendingMcpCloses = new Set<Promise<void>>();
  const disposePluginMcpServers = (predicate: (server: { name: string; pluginName: string }) => boolean = () => true): Promise<void> => {
    for (let index = pluginMcpDisposers.length - 1; index >= 0; index -= 1) {
      const entry = pluginMcpDisposers[index];
      if (!predicate(entry)) continue;
      try {
        const pending = Promise.resolve(entry.dispose()).catch(() => undefined);
        pendingMcpCloses.add(pending);
        void pending.finally(() => pendingMcpCloses.delete(pending));
      } catch {}
      pluginMcpDisposers.splice(index, 1);
    }
    return Promise.all(pendingMcpCloses).then(() => undefined);
  };

  function markComputerUseRecoverableFailure(error: ComputerUseUnavailableError): void {
    computerUseLifecycleEpoch += 1;
    disposePluginMcpServers((server) => server.name === 'cua-driver' && server.pluginName === 'cua-computer-use');
    computerUseBackend = null;
    computerUseUnavailableError = error;
    recordComputerUseFailure(error.code as ComputerUseFailureCode);

    const existing = pluginMcpServers.find((entry) => entry.name === 'cua-driver' && entry.pluginName === 'cua-computer-use');
    if (existing) {
      existing.connected = false;
      existing.enabled = true;
      existing.toolCount = 0;
      existing.lastError = error.message;
      return;
    }

    pluginMcpServers.push({
      name: 'cua-driver',
      pluginName: 'cua-computer-use',
      toolCount: 0,
      connected: false,
      enabled: true,
      lastError: error.message,
    });
  }

  const performReconnectPluginMcpServers = async (
    options: { userInitiated?: boolean; targetServerName?: string; targetPluginName?: string; autoConnectComputerUse?: boolean } = {},
    computerUseActivationEpoch?: number,
    computerUseActivationSignal?: AbortSignal,
  ): Promise<PluginMcpServerState[]> => {
    const computerUseQualified = await qualifyComputerUse();
    if (computerUseActivationEpoch !== undefined && computerUseActivationEpoch !== computerUseLifecycleEpoch) return pluginMcpServers;
    const matchesTarget = (server: { name: string; pluginName: string }) =>
      (!options.targetPluginName || server.pluginName === options.targetPluginName)
      && (!options.targetServerName || server.name === options.targetServerName
        || (options.targetServerName === 'cua-driver' && server.pluginName === 'cua-computer-use'));
    await disposePluginMcpServers(matchesTarget);
    for (let index = pluginMcpServers.length - 1; index >= 0; index -= 1) {
      if (matchesTarget(pluginMcpServers[index])) {
        pluginMcpServers.splice(index, 1);
      }
    }
    if ((!options.targetPluginName || options.targetPluginName === 'cua-computer-use')
      && (!options.targetServerName || options.targetServerName === 'cua-driver')) {
      computerUseBackend = null;
      computerUseUnavailableError = options.userInitiated
        ? { code: 'COMPUTER_USE_MCP_CONNECT_TIMEOUT', message: 'Computer Use 正在连接或连接失败。', userAction: { type: 'reconnect_computer_use', label: '重新连接' } }
        : buildComputerUseNeedsEnablementError();
    }
    if (!options.targetServerName || options.targetServerName === 'slide-renderer') {
      artifactGenerationRegistry.registerTool(createArtifactWorkspaceUnavailableProducerTool({
        name: 'mcp__slide-renderer__render_slide',
        pluginSource: 'kai-slide-creator',
        requestedKind: 'slides',
        properties: {
          brief_json: { type: 'string', description: '符合 bundled slide renderer schema 的 BRIEF.json' },
        },
        required: ['brief_json'],
      }));
    }
    try {
      const plugins = await loadPlugins([pluginRootDir], { desktopCuaBundleDir: process.platform === 'win32' ? computerUseBundledPluginDir : undefined });
      for (const plugin of plugins) {
        if (!plugin.mcpServers?.length) continue;
        for (const server of plugin.mcpServers) {
          if (server.type !== 'stdio') continue;
          if (!matchesTarget({ name: server.name, pluginName: plugin.name })) continue;
          if (plugin.name === 'cua-computer-use' && server.name !== 'cua-driver') {
            computerUseUnavailableError = { code: 'COMPUTER_USE_PLUGIN_INCOMPATIBLE', message: 'CUA 插件身份不匹配，请更新插件后重新启用。' };
            pluginMcpServers.push({ name: server.name, pluginName: plugin.name, toolCount: 0, connected: false, enabled: false, lastError: computerUseUnavailableError.message });
            continue;
          }
          const isCuaServer = plugin.name === 'cua-computer-use' && server.name === 'cua-driver';
          const dependency = findPluginDependencyForMcpServer(plugin.name, server.name);
          const mayConnectUserActivatedServer = options.userInitiated
            || (isCuaServer && options.autoConnectComputerUse === true);
          if (dependency?.dependency.mcp?.requiresUserActivation && !mayConnectUserActivatedServer) {
            if (isCuaServer) {
              computerUseUnavailableError = buildComputerUseNeedsEnablementError();
            }
            pluginMcpServers.push({
              name: server.name,
              pluginName: plugin.name,
              toolCount: 0,
              connected: false,
              enabled: false,
              lastError: '等待用户点击连接以启用 Computer Use',
            });
            continue;
          }
          if (isCuaServer && !computerUseQualified) {
            computerUseUnavailableError = {
              code: 'COMPUTER_USE_WRAPPER_NOT_READY',
              message: '当前平台或原生架构尚未支持 Computer Use。',
            };
            pluginMcpServers.push({
              name: server.name,
              pluginName: plugin.name,
              toolCount: 0,
              connected: false,
              enabled: false,
              lastError: computerUseUnavailableError.message,
            });
            continue;
          }
          let connectionRef: McpClientConnection | null = null;
          let resolvedCommand: string | undefined;
          try {
            if (isCuaServer) computerUseActivationSignal?.throwIfAborted();
            if (isCuaServer && process.platform === 'win32' && !(await detectWindowsInteractiveDesktop(computerUseActivationSignal))) throw new Error('COMPUTER_USE_WINDOWS_SESSION_UNAVAILABLE');
            const launch = await resolvePluginMcpLaunch(plugin.name, server.name, server.command, server.args ?? []);
            // Use managed venv python if available for Python MCP servers
            const isPythonServer = launch.command === 'python3' || launch.command === 'python';
            const isNodeServer = launch.command === 'node' || launch.command === 'nodejs';
            const managedPythonCommand = isPythonServer ? getManagedPythonCommand?.() : undefined;
            if (isPythonServer && getManagedPythonCommand && !managedPythonCommand) {
              deferredPythonServerNames.add(server.name);
              pluginMcpServers.push({
                name: server.name,
                pluginName: plugin.name,
                toolCount: 0,
                connected: false,
                enabled: true,
                lastError: 'managed_python_preparing',
              });
              continue;
            }
            const command = isPythonServer
              ? normalizePythonServerCommand(launch.command, process.platform, managedPythonCommand)
              : isNodeServer
                ? (process.env.XIAOK_NODE_CMD || process.execPath)
                : launch.command;
            resolvedCommand = command;
            // Design v58 §6.1: no Xiaok-owned daemon launch. The official
            // `cua-driver mcp` proxy is the only owner of app-daemon reuse and
            // auto-relaunch, so a second `open -n` owner is removed here.
            const baseEnv = 'env' in server ? (server as { env?: Record<string, string> }).env : undefined;
            const runtimeEnv = isPythonServer
              ? buildPythonServerEnv(baseEnv)
              : isNodeServer && !process.env.XIAOK_NODE_CMD && process.versions.electron
                ? { ...(baseEnv ?? {}), ELECTRON_RUN_AS_NODE: '1' }
                : isCuaServer && process.platform === 'win32'
                  ? { ...(baseEnv ?? {}), CUA_DRIVER_RS_TELEMETRY_ENABLED: 'false', CUA_DRIVER_RS_UPDATE_CHECK: 'false', CUA_DRIVER_TELEMETRY_HOME: join(servicesOptions.dataRoot, 'runtime', 'cua-telemetry') } : baseEnv;
            if (isCuaServer) computerUseActivationSignal?.throwIfAborted();
            const connection = await createMcpClientConnection(server.name, {
              type: 'stdio',
              command,
              args: launch.args,
              env: runtimeEnv,
              timeout: server.timeout,
              protocol: server.protocol,
            }, {
              cwd: plugin.rootDir,
              clientName: 'xiaok-desktop',
              ...(isCuaServer ? { startupSignal: computerUseActivationSignal } : {}),
            });
            connectionRef = connection;
            activityMcpConnections.add(connection); activityMcp?.register(connection);
            const catalogTimeout = server.timeout?.catalog ?? resolveMcpCatalogTimeoutMs();
            const callTimeout = server.timeout?.call ?? resolveMcpCallToolTimeoutMs();
            const schemas = (await connection.client.listTools(
              undefined,
              { timeout: catalogTimeout, ...(isCuaServer ? { signal: computerUseActivationSignal } : {}) },
            )).tools as McpToolSchema[];
            const callToolResult = async (name: string, input: Record<string, unknown>, options?: McpInvocationOptions) => {
              const context = options?.executionContext;
              const observer = context && activityMcp ? await activityMcp.observer(context.taskId, context.toolInvocationId ?? randomUUID(), connection) : undefined;
              const result = await callMcpToolWithTasks(connection,
                { name, arguments: input },
                { timeout: callTimeout, signal: options?.signal, declaration: schemas.find(schema => schema.name === name) as import('@modelcontextprotocol/client').Tool | undefined,
                  observer, detachOnTask: Boolean(observer), ...(options?.onProgress ? { onprogress: options.onProgress } : {}) },
              );
              options?.signal?.throwIfAborted();
              return normalizeMcpRuntimeToolResult(result);
            };
            const callTool = async (name: string, input: Record<string, unknown>, options?: McpInvocationOptions) => {
              const result = await callToolResult(name, input, options);
              options?.signal?.throwIfAborted();
              return result.text;
            };
            let disposeConnectedServer: () => void | Promise<void> = () => connection.dispose();
            if (server.name === 'slide-renderer' || server.name === 'report-renderer') {
              reservedServerHandles.set(server.name, {
                listOperations: async () => schemas.map((schema) => schema.name),
                call: callTool,
                close: async () => { connection.dispose(); },
              });
            }
            let mcpTools: Tool[];
            let toolCount = 0;
            if (isCuaServer) {
              const macosCuaModule = process.platform === 'darwin'
                ? await import('../../src/platform/computer-use/macos-cua-connection.js') : null;
              const initialCuaConnection = macosCuaModule
                ? macosCuaModule.createMacosCuaConnection(macosCuaModule.macosCuaCatalog(schemas), { callToolResult, dispose: () => connection.dispose() })
                : { callToolResult, dispose: () => connection.close() };
              let windowsObserved = false;
              if (process.platform === 'win32') {
                windowsObserved = (await verifyWindowsCuaReadiness({ identity: connection.client.getServerVersion(), schemas, callToolResult, target: servicesOptions.getComputerUseReadinessTarget?.() })).observed;
              } else {
                const readiness = await runCuaMcpReadinessSmoke({ schemas, callToolResult: initialCuaConnection.callToolResult });
                if (!readiness.ready) throw new Error(`CUA MCP readiness failed: ${readiness.code}`);
              }
              if (computerUseActivationEpoch !== computerUseLifecycleEpoch) {
                if (process.platform === 'win32') await connection.close(); else connection.dispose();
                connectionRef = null;
                continue;
              }

              const createReplacementConnection = async () => {
                if (process.platform === 'win32' && !(await detectWindowsInteractiveDesktop())) throw new Error('COMPUTER_USE_WINDOWS_SESSION_UNAVAILABLE');
                if (isCuaServer) computerUseActivationSignal?.throwIfAborted();
                const replacement = await createMcpClientConnection(server.name, {
                  type: 'stdio',
                  command,
                  args: launch.args,
                  env: runtimeEnv,
                  timeout: server.timeout,
                  protocol: server.protocol,
                }, {
                  cwd: plugin.rootDir,
                  clientName: 'xiaok-desktop',
                  startupSignal: computerUseActivationSignal,
                });
                try {
                  const replacementSchemas = (await replacement.client.listTools(
                    undefined,
                    { timeout: catalogTimeout, ...(isCuaServer ? { signal: computerUseActivationSignal } : {}) },
                  )).tools as McpToolSchema[];
                  const replacementCallToolResult = async (name: string, input: Record<string, unknown>, options?: McpInvocationOptions) =>
                    normalizeMcpRuntimeToolResult(await callMcpToolWithSignal(replacement.client,
                      { name, arguments: input },
                      { timeout: callTimeout, signal: options?.signal, ...(options?.onProgress ? { onprogress: options.onProgress } : {}) },
                    ));
                  const checkedReplacement = macosCuaModule
                    ? macosCuaModule.createMacosCuaConnection(macosCuaModule.macosCuaCatalog(replacementSchemas), {
                        callToolResult: replacementCallToolResult, dispose: () => replacement.dispose(),
                      })
                    : { callToolResult: replacementCallToolResult, dispose: () => replacement.close() };
                  if (process.platform === 'win32') {
                    if (!(await detectWindowsInteractiveDesktop())) throw new Error('COMPUTER_USE_WINDOWS_SESSION_UNAVAILABLE');
                    await verifyWindowsCuaReadiness({ identity: replacement.client.getServerVersion(), schemas: replacementSchemas, callToolResult: replacementCallToolResult, target: servicesOptions.getComputerUseReadinessTarget?.() });
                  } else {
                    const replacementReadiness = await runCuaMcpReadinessSmoke({ schemas: replacementSchemas, callToolResult: checkedReplacement.callToolResult });
                    if (!replacementReadiness.ready) throw new Error(`CUA MCP readiness failed: ${replacementReadiness.code}`);
                  }
                  return checkedReplacement;
                } catch (error) {
                  if (process.platform === 'win32') await replacement.close(); else replacement.dispose();
                  throw error;
                }
              };

              const { CuaConnectionManager } = await import('../../src/platform/mcp/cua-connection-manager.js');
              const windowsBackendModule = process.platform === 'win32' ? await import('../../src/platform/computer-use/windows-cua-backend.js') : null;
              const manager = new CuaConnectionManager(createReplacementConnection, {
                ...(windowsBackendModule ? { isReplaySafeCall: windowsBackendModule.isWindowsCuaReplaySafeCall } : {}),
                initialConnection: initialCuaConnection,
              });
              if (computerUseActivationEpoch !== computerUseLifecycleEpoch) {
                await manager.dispose();
                connectionRef = null;
                continue;
              }

              computerUseObserved = process.platform !== 'win32' || windowsObserved;
              computerUseBackend = windowsBackendModule ? windowsBackendModule.createWindowsCuaBackend(manager, {
                onObserved: () => {
                  if (computerUseActivationEpoch !== computerUseLifecycleEpoch) return;
                  computerUseObserved = true;
                  recordComputerUseReady(options.userInitiated ? 'user_enable' : 'auto_recovery');
                },
              }) : { callToolResult: (name, input, options) => manager.callToolResult(name, input, options) };
              disposeConnectedServer = () => manager.dispose();
              connectionRef = null;
              if (computerUseObserved && (options.userInitiated || options.autoConnectComputerUse)) {
                recordComputerUseReady(options.userInitiated ? 'user_enable' : 'auto_recovery');
              }
              mcpTools = [];
              toolCount = 1;
            } else {
              mcpTools = buildMcpRuntimeTools(
                { name: server.name, command: server.command },
                {
                  listTools: () => Promise.resolve(schemas),
                  callTool,
                  dispose: connection.dispose,
                },
                schemas,
              );
              toolCount = mcpTools.length;
            }
            let catalogRegistration: DesktopMcpCatalogRegistration<McpToolSchema> | undefined;
            if (!isCuaServer) {
              catalogRegistration = new DesktopMcpCatalogRegistration({ registry, connection, ownerId: `mcp:${plugin.name}:${server.name}`,
                listSchemas: async () => (await connection.client.listTools(undefined, { timeout: catalogTimeout })).tools as McpToolSchema[],
                buildTools: next => buildMcpRuntimeTools({ name: server.name, command: server.command }, { listTools: async () => next, callTool, dispose: connection.dispose }, next)
                  .filter(tool => !staticGatewayNames.has(tool.definition.name)),
                onChanged: current => { const view = pluginMcpServers.find(item => item.name === server.name && item.pluginName === plugin.name); if (view) view.toolCount = current.length; },
                onDisconnected: () => { const view = pluginMcpServers.find(item => item.name === server.name && item.pluginName === plugin.name); if (view) { view.connected = false; view.toolCount = 0; } },
              });
              try {
                if (!await catalogRegistration.initialize(catalogTimeout)) throw new Error('MCP tool subscription ended during discovery');
              } catch (error) { catalogRegistration.dispose(); throw error; }
            }
            for (const tool of mcpTools) {
              if (
                plugin.name === 'kai-slide-creator'
                && server.name === 'slide-renderer'
                && tool.definition.name === 'mcp__slide-renderer__render_slide'
              ) {
                artifactGenerationRegistry.registerTool(createArtifactWorkspacePluginProducerTool({
                  generationRoot: artifactGenerationRoot,
                  resolveRequestedKind: leaseId => artifactWorkspaceStore.getLease(leaseId)?.requestedKind,
                  tool,
                  requestedKind: 'slides',
                  outputFileName: 'slides.html',
                  pluginSource: 'kai-slide-creator',
                  mimeType: 'application/vnd.xiaok.slides+html',
                }));
              }
            }
            pluginMcpDisposers.push({
              name: server.name,
              pluginName: plugin.name,
              dispose: () => {
                catalogRegistration?.dispose();
                if (isCuaServer) {
                  computerUseBackend = null;
                  computerUseUnavailableError = buildComputerUseNeedsEnablementError();
                }
                return disposeConnectedServer();
              },
            });
            pluginMcpServers.push({
              name: server.name,
              pluginName: plugin.name,
              toolCount,
              connected: true,
              enabled: true,
            });
          } catch (e) {
            const baseMessage = e instanceof Error ? e.message : String(e);
            const stderrTail = connectionRef?.getStderrTail() || getMcpConnectionStderrTail(e);
            if (isCuaServer && process.platform === 'win32') await connectionRef?.close(); else connectionRef?.dispose();
            const combinedDetail = stderrTail ? `${baseMessage}\n${stderrTail}` : baseMessage;
            const errorDetail = classifyMcpStartupError(combinedDetail, resolvedCommand);
            if (isCuaServer) {
              if (computerUseActivationEpoch !== computerUseLifecycleEpoch) {
                continue;
              }
              computerUseBackend = null;
              computerUseUnavailableError = mapComputerUseStartupError(e);
              if (options.userInitiated || options.autoConnectComputerUse) {
                recordComputerUseFailure(computerUseUnavailableError.code as ComputerUseFailureCode);
              }
            }
            // MCP server failed to start/connect — record as disconnected
            pluginMcpServers.push({
              name: server.name,
              pluginName: plugin.name,
              toolCount: 0,
              connected: false,
              enabled: true,
              lastError: baseMessage,
              lastErrorDetail: errorDetail,
            });
          }
        }
      }
    } catch (e) {
      // Plugin loading failed — non-fatal
    }
    return pluginMcpServers;
  };

  const reconnectPluginMcpServers = (
    options: { userInitiated?: boolean; targetServerName?: string; targetPluginName?: string; autoConnectComputerUse?: boolean } = {},
  ): Promise<PluginMcpServerState[]> => {
    const includesComputerUse = (!options.targetPluginName || options.targetPluginName === 'cua-computer-use')
      && (!options.targetServerName || options.targetServerName === 'cua-driver');
    if (!includesComputerUse) return performReconnectPluginMcpServers(options);

    const key = JSON.stringify({
      targetServerName: options.targetServerName ?? '*',
      targetPluginName: options.targetPluginName ?? '*',
      userInitiated: options.userInitiated === true,
      autoConnectComputerUse: options.autoConnectComputerUse === true,
    });
    if (computerUseActivation?.key === key) return computerUseActivation.promise;

    computerUseActivation?.controller.abort();
    const controller = new AbortController();
    const epoch = ++computerUseLifecycleEpoch;
    const promise = performReconnectPluginMcpServers(options, epoch, controller.signal);
    computerUseActivation = { key, promise, controller };
    void promise.finally(() => {
      if (computerUseActivation?.promise === promise) computerUseActivation = null;
    }).catch(() => {});
    return promise;
  };

  const getComputerUseCapabilityStatus = (): { state: string; mcpConnected: boolean; wrapperReady: boolean; lastError?: string } => {
    const server = pluginMcpServers.find((entry) => entry.name === 'cua-driver' && entry.pluginName === 'cua-computer-use');
    if (computerUseUnavailableError.code === 'COMPUTER_USE_DISABLED_BY_USER') {
      return {
        state: 'disabled_by_user',
        mcpConnected: false,
        wrapperReady: computerUseWrapperRegistered,
        lastError: computerUseUnavailableError.message,
      };
    }
    if (computerUseBackend && server?.connected) {
      return { state: computerUseObserved ? 'ready' : 'connected_no_target', mcpConnected: true, wrapperReady: true };
    }
    if (server?.enabled === false || computerUseUnavailableError.code === 'COMPUTER_USE_NEEDS_ENABLEMENT') {
      return {
        state: 'not_enabled',
        mcpConnected: false,
        wrapperReady: computerUseWrapperRegistered,
        lastError: computerUseUnavailableError.message,
      };
    }
    return {
      state: 'failed',
      mcpConnected: false,
      wrapperReady: computerUseWrapperRegistered,
      lastError: computerUseUnavailableError.message || server?.lastError,
    };
  };

  const artifactGenerationRoot = join(options.dataRoot, 'artifact-workspace', 'generation');
  mkdirSync(artifactGenerationRoot, { recursive: true });
  const artifactGenerationTools = createArtifactWorkspaceGenerationFileTools(
    artifactGenerationRoot,
    leaseId => artifactWorkspaceStore.getLease(leaseId)?.requestedKind,
  );
  const artifactGenerationRegistry = new ToolRegistry({ autoMode: true }, artifactGenerationTools);
  artifactGenerationRegistry.registerTool(createArtifactWorkspacePluginProducerTool({
    generationRoot: artifactGenerationRoot,
    resolveRequestedKind: leaseId => artifactWorkspaceStore.getLease(leaseId)?.requestedKind,
    tool: createReportArtifactTool(),
    requestedKind: 'html',
    outputFileName: 'report.html',
    pluginSource: 'kai-report-creator',
    mimeType: 'text/html',
  }));
  artifactGenerationRegistry.registerTool(createArtifactWorkspaceUnavailableProducerTool({
    name: 'mcp__slide-renderer__render_slide',
    pluginSource: 'kai-slide-creator',
    requestedKind: 'slides',
    properties: {
      brief_json: { type: 'string', description: '符合 bundled slide renderer schema 的 BRIEF.json' },
    },
    required: ['brief_json'],
  }));
  const defaultDesktopRunner = createDesktopModelRunnerWithRegistry(
    registry,
    tools,
    options.dataRoot,
    options.kswarmService,
    materialRegistry,
    kswarmCreateProjectToolOptions,
    {
      observationTasks,
      observationGroupHost: { getHost: () => host, observationStore: snapshotStore.observations },
      officeToMarkdown: input => officeDocumentParser.parse(input),
      ...(options.pluginProviderRuntime ? { pluginProviderRuntime: options.pluginProviderRuntime } : {}),
      ...(multiAgentRuntime ? { multiAgent: { runtime: multiAgentRuntime, service: multiAgentService!, catalog: multiAgentCatalog!, workspaceId: multiAgentWorkspaceId, cwd: multiAgentCwd } } : {}),
    },
  );
  const restrictedArtifactRunner = createDesktopModelRunnerWithRegistry(
    artifactGenerationRegistry,
    artifactGenerationTools,
    options.dataRoot,
    options.kswarmService,
    materialRegistry,
    kswarmCreateProjectToolOptions,
    {
      restrictedArtifactGeneration: true,
      officeToMarkdown: input => officeDocumentParser.parse(input),
    },
  );
  const localChatDescriptor = Object.freeze({ kind: 'localChat' as const, multiAgent: Boolean(multiAgentRuntime), invoke: defaultDesktopRunner });
  const localGoalDescriptor = Object.freeze({ kind: 'localGoal' as const, multiAgent: Boolean(multiAgentRuntime), invoke: defaultDesktopRunner });
  const ordinaryRunner = coordinateRunner(options.runner ?? (input => input.executionScope?.kind === 'artifact_workspace_generation'
    ? restrictedArtifactRunner(input) : defaultDesktopRunner(input)));
  let hostDeliveryAuthority: DesktopHostDeliveryAuthority | undefined;
  const host = taskSourcePopulation.createHost({
    materialRegistry,
    groupObservationSource: multiAgentService,
    runner: input => {
      const prepared = multiAgentStore?.getRootBinding(input.taskId);
      if (!prepared) return ordinaryRunner(input);
      const descriptor = input.executionScope?.kind === 'goal_turn' ? localGoalDescriptor : localChatDescriptor;
      if (!descriptor.multiAgent || input.executionScope && input.executionScope.kind !== 'goal_turn') return Promise.reject(new Error('unsupported multi-agent runner'));
      return multiAgentService!.runRoot(input, context => descriptor.invoke(input, context));
    },
    authorizePreparation: multiAgentService ? (taskId, marker) => multiAgentService.assertHostPreparation(taskId, marker) : undefined,
    assertTaskAdmission: snapshot => multiAgentService?.assertHostAdmission(snapshot),
    decideCancellation: (snapshot, reason) => multiAgentService?.decideHostCancellation(snapshot, reason) ?? Promise.resolve({ hostAbortAllowed: true }),
    getExecutionPolicy: snapshot => ({ deliveryRepair: multiAgentStore?.getRootBinding(snapshot.taskId) ? 'explicit' : 'automatic' }),
    onDeliveryReport: async report => {
      if (!multiAgentService || !hostDeliveryAuthority) throw new Error('multi_agent_host_delivery_owner_unavailable');
      return multiAgentService.recordHostDelivery({ requestSource: 'scheduler', authority: hostDeliveryAuthority, report });
    },
    authorizeDeliveryRecovery: input => {
      if (!multiAgentService) throw new Error('multi_agent_unsupported_runner');
      multiAgentService.assertDeliveryRecovery(input);
    },
    now: options.now,
    aheGuards: { artifactEvidence: true, recoveryContinuity: true },
    // Use timestamp + random suffix to ensure unique taskId across app restarts.
    createTaskId: () => `task_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    onPersistedEvent: async input => {
      if (input.event.type === 'task_terminal' && multiAgentService && hostDeliveryAuthority) {
        try { await multiAgentService.reconcileActivityRuns({ requestSource: 'scheduler', authority: hostDeliveryAuthority, taskId: input.taskId }); }
        catch (error) { console.warn('[conversation-activity] run reconciliation failed:', error instanceof Error ? error.message : 'activity_run_pending'); }
      }
      if (artifactWorkspaceService) {
        try {
          await artifactWorkspaceService.handlePersistedTaskEvent(input);
        } catch (error) {
          console.warn('[artifact-workspace] task event projection failed:', error instanceof Error ? error.message : String(error));
        }
      }
      if (goalCoordinator) {
        try {
          await goalCoordinator.handlePersistedTaskEvent(input);
        } catch (error) {
          console.warn('[goal] task event settlement failed:', error instanceof Error ? error.message : String(error));
        }
      }
    },
  });

  const prepareMultiAgentThread = async (threadId: string): Promise<void> => {
    await multiAgentReady;
    await multiAgentService?.registerThreadWithOwnership({ threadId, profileId: multiAgentProfileId, workspaceId: multiAgentWorkspaceId, cwd: multiAgentCwd }, 'user');
  };
  const prepareActivityViewerThread = async (threadId: string, actor: ActivityActor): Promise<void> => {
    if (actor?.requestSource !== 'user' || actor.actorId !== `desktop-user:${multiAgentProfileId}`) throw new Error('activity_actor_forbidden');
    await multiAgentReady;
    // Reuse the same trusted user identity admission as the Agents read API.
    // Existing historical bindings are validated by activity service, never rebound.
    if (!multiAgentStore?.getThread(threadId)) await prepareMultiAgentThread(threadId);
  };
  const localTaskHost = {
    prepareTask: async (input: TaskCreateInput) => {
      let prepared: Awaited<ReturnType<typeof host.prepareTask>>;
      if (multiAgentService && (!input.executionScope || input.executionScope.kind === 'goal_turn')) {
        await multiAgentReady;
        const threadId = input.context?.threadId ?? `local_${randomUUID()}`;
        await prepareMultiAgentThread(threadId);
        prepared = await multiAgentService.prepareRoot(host, threadId, input);
      } else {
        prepared = await host.prepareTask(input);
      }
      if (currentExecutionLane() === 'foreground') {
        await conversationProjects.bindPreparedTask({ ...input, taskId: prepared.taskId }, { requestSource: 'user' });
        conversationRooms.bindPreparedTask({ ...input, taskId: prepared.taskId }, { requestSource: 'user' });
      }
      return prepared;
    },
    prepareReservedTask: async (input:TaskCreateInput,reservation:import('../../src/runtime/task-host/task-runtime-host.js').TaskIdentityReservation)=>{
      await multiAgentReady;const threadId=input.context?.threadId;if(!threadId)throw Error('background_fresh_thread_required');
      await prepareMultiAgentThread(threadId);return multiAgentService!.prepareRoot(host,threadId,input,reservation);
    },
    startTask: host.startTask.bind(host), cancelTask: host.cancelTask.bind(host),
  };
  goalCoordinator = new DesktopGoalCoordinator({
    store: goalStore,
    nativeJournal: new FileGoalNativeJournal(join(options.dataRoot, 'goals')),
    taskHost: localTaskHost,
    multiAgent: multiAgentService,
    prepareThread: prepareMultiAgentThread,
    authorizeRecoveredDelivery: input => {
      if (!multiAgentService) throw new Error('multi_agent_unsupported_runner');
      multiAgentService.assertDeliveryRecovery(input);
    },
    instanceId: `desktop_${randomUUID()}`,
    now: options.now,
    publishGoalChanged: input => {
      for (const listener of goalChangedListeners) listener(input);
    },
    publishGoalTaskPrepared: input => {
      for (const listener of goalTaskPreparedListeners) listener(input);
    },
  });
  const goalShutdownBase = createDesktopGoalShutdownOwner(goalCoordinator, goalStore);
  // Goal construction only installs its owner; recovery can now await its real
  // receipt before the same ready Promise opens any local task admission.
  const multiAgentReady = multiAgentService?.initialize(host) ?? Promise.resolve();
  const installActivityGroupSubscription = () => {
    if (!multiAgentStore || unsubscribeActivityGroups) return;
    unsubscribeActivityGroups = multiAgentStore.subscribe(event => {
        const group = multiAgentStore.requireGroup(event.groupId);
        void (async () => {
          await activityAttachment;
          for (const run of multiAgentStore.getActivityRuns(event.groupId)) {
            const members = multiAgentStore.getActivityMembers(run.runId);
            if (!members.some(member => member.agentId !== `root_${event.groupId}`)) continue;
            const operationId = `agent-run:${run.runId}`;
            if (activityStore!.getWatch(operationId)) continue;
            await activityService!.prepareAssociation({ threadId: group.threadId, operationId, creationIdempotencyKey: operationId }, { requestSource: 'user', actorId: `desktop-user:${multiAgentProfileId}` });
            await activityService!.bindWork({ operationId, watchId: operationId, source: 'agent_group', logicalSourceId: 'agent-group-local', sourceDataEpoch: event.groupId, workId: event.groupId, runId: run.runId });
          }
          await activitySources!.refreshGroup(event.groupId, true);
        })().catch(error => console.warn('[conversation-activity] agent event failed:', error instanceof Error ? error.message : 'activity_group_unavailable'));
      });
  };
  if (activityEnabled && multiAgentStore) {
    try {
      activityStore = new ConversationActivityStore(join(options.dataRoot, 'conversation-activity.sqlite'), { now: options.now });
      activityService = new ConversationActivityService({ store: activityStore, profileId: multiAgentProfileId,
        notify: options.notifyConversationActivity,
        actorId: `desktop-user:${multiAgentProfileId}`, getThread: threadId => { const thread = multiAgentStore.getThread(threadId); return thread ? {
          profileId: thread.profileId, threadId: thread.threadId, workspaceId: thread.workspaceId, deleteState: thread.deleteState ?? 'none',
        } : null; },
        canObserveWork: async watch => {
          if (watch.source === 'task_host') {
            const snapshot = (await resolveScopedTaskHost(watch.workId, host).recoverTask(watch.workId)).snapshot;
            return snapshot.context?.threadId === (watch.actualExecutionThreadId ?? watch.origin.threadId);
          }
          if (watch.source === 'agent_group') return multiAgentStore.requireGroup(watch.workId).threadId === watch.origin.threadId;
          if (watch.source === 'mcp') return activityMcp?.canObserve(watch) ?? false;
          if (watch.source === 'kswarm') {
            if (!activityRoomClient) return false;
            // Fetch only routing identity before Room authorization. A project
            // detail response can contain private summaries and artifact paths.
            const identity = await readActivityIdentity(watch.workId);
            const roomId = identity.roomId;
            if (!identity.ok || identity.sourceDataEpoch !== watch.sourceDataEpoch) return false;
            if (!roomId) return false;
            const snapshot = await activityRoomClient.getRoomSnapshot(roomId);
            return isRecord(snapshot) && snapshot.ok !== false && isRecord(snapshot.room);
          }
          return false;
        }, onError: error => console.warn('[conversation-activity]', error instanceof Error ? error.message : 'activity_delivery_failed'),
      });
      activitySources = new ConversationActivitySources({ store: activityStore, service: activityService,
        taskHost: taskId => resolveScopedTaskHost(taskId, host), readProject: readActivityProject,
        readGroup: (groupId, after) => multiAgentStore.readEvents(groupId, after),
        groupMembers: runId => multiAgentStore.getActivityMembers(runId),
        onError: error => console.warn('[conversation-activity-source]', error instanceof Error ? error.message : 'activity_source_failed') });
      activityMcp = new ConversationMcpActivities({ store: activityStore, service: activityService, actorId: `desktop-user:${multiAgentProfileId}`,
        originThread: async taskId => {
          const parent = activityStore!.listWatches().find(watch => watch.source === 'task_host' && watch.workId === taskId);
          if (parent) return parent.origin.threadId;
          const snapshot = await host.inspectTask(taskId);
          return snapshot?.context?.threadId ?? null;
        }, onError: error => console.warn('[conversation-activity-mcp]', error instanceof Error ? error.message : 'activity_mcp_unavailable') });
      for (const connection of activityMcpConnections) activityMcp.register(connection);
      installActivityGroupSubscription();
      activityService.start();
    } catch (error) {
      activityService?.dispose(); activityStore?.close(); activityService = undefined; activityStore = undefined;
      console.warn('[conversation-activity] unavailable:', error instanceof Error ? error.message : 'initialization_failed');
    }
  }

  let multiAgentStartupReady = !multiAgentService;
  if (multiAgentService) hostDeliveryAuthority = multiAgentService.bindHostDeliveryOwner(host);
  // Keep initialization failure observable by every admission path, without an
  // unhandled rejection when the window has not submitted its first task yet.
    void multiAgentReady.then(() => {
      multiAgentStartupReady = true;
      if (multiAgentService && hostDeliveryAuthority) void multiAgentService.reconcileActivityRuns({ requestSource: 'scheduler', authority: hostDeliveryAuthority }).catch(error => console.warn('[conversation-activity] recovery pending:', error instanceof Error ? error.message : 'activity_run_pending'));
    }, () => {});
  // Ready callers must enter Goal synchronously so its original permission
  // revision is captured before any queued revoke/regrant can run.
  const afterLocalRecovery = <T>(action: () => Promise<T>): Promise<T> => (
    multiAgentStartupReady ? action() : multiAgentReady.then(action)
  );
  // The local host already creates this ID for unthreaded Chat. Capture it at
  // the public admission boundary so Goal can fence the same request across IO.
  const localChatContext = (context?: TaskCreateContext): TaskCreateContext | undefined => (
    multiAgentService ? { ...context, threadId: context?.threadId || `local_${randomUUID()}` } : context
  );
  const backgroundTaskIdentity=createBackgroundTaskIdentityController({host,assertAdmission:()=>goalCoordinator.assertBackgroundAdmission(),captureAdmission:()=>goalCoordinator.captureBackgroundAdmission(),
    create:(input,reservation,guard)=>withExecutionLane('background',()=>afterLocalRecovery(()=>goalCoordinator.admitReservedBackgroundTask(input,reservation,guard)))});
  const originalGoalStop=goalShutdownBase.ingress.stopAccepting.bind(goalShutdownBase.ingress);
  const stopBackgroundAndGoal=()=>{backgroundTaskIdentity.close();originalGoalStop();};
  const goalShutdown=Object.freeze({...goalShutdownBase,ingress:Object.freeze({...goalShutdownBase.ingress,stopAccepting:stopBackgroundAndGoal,abortAllActive:stopBackgroundAndGoal})});
  const unsubscribeMultiAgentGoal = multiAgentStore?.subscribe(event => {
    if (!['status', 'result', 'message_consumed'].includes(event.kind)) return;
    const threadId = multiAgentStore.requireGroup(event.groupId).threadId;
    // Same durable source as the Agents panel; no renderer/Goal polling owner.
    void goalCoordinator!.getGoal(threadId).then(goal => {
      if (goal) for (const listener of goalChangedListeners) listener({ threadId, goal });
    }).catch(error => console.warn('[goal] child projection failed:', error instanceof Error ? error.message : String(error)));
  });
  for (const tool of createGoalTools(goalCoordinator.createRegistryGoalToolHost())) {
    registry.registerTool(tool);
  }

  const workspaceService = new ArtifactWorkspaceService({
    store: artifactWorkspaceStore,
    snapshotStore,
    taskHost: host,
    fileManager: artifactWorkspaceFileManager,
    workspaceRoot: artifactGenerationRoot,
    generationRoot: artifactGenerationRoot,
    allowedRoots: [
      options.dataRoot,
      process.cwd(),
      join(homedir(), '.kswarm', 'projects'),
      join(homedir(), '.xiaok', 'tasks'),
    ],
    featureFlags: {
      artifactWorkspaceRevisionUi:
        options.artifactWorkspaceFeatureFlags?.artifactWorkspaceRevisionUi
        ?? process.env.XIAOK_ARTIFACT_WORKSPACE_REVISION_UI === '1',
      artifactSpatialWorkspace:
        options.artifactWorkspaceFeatureFlags?.artifactSpatialWorkspace
        ?? process.env.XIAOK_ARTIFACT_SPATIAL_WORKSPACE === '1',
    },
    now: options.now,
  });
  artifactWorkspaceService = workspaceService;
  for (const tool of createArtifactWorkspaceTools(workspaceService)) {
    artifactGenerationRegistry.registerTool(tool);
  }

  const resolveProjectAgentModel = async (participantId?: string) => {
    const response = await requestKSwarmJson(options.kswarmService, '/agents');
    const agents = isRecord(response) && Array.isArray(response.agents) ? response.agents : [];
    const agent = agents.find((entry: any) => entry.id === (participantId || 'xiaok-worker'));
    const modelId = agent?.runtimeType === 'xiaok' && typeof agent.desktopModelId === 'string' ? agent.desktopModelId : null;
    return createProjectAgentModel({ modelId, loadConfig });
  };

  type KSwarmScopedTaskOptions = { workflowRestrictionCheckpoint?: NativeWorkflowRestrictionCheckpoint; nativeReadonlyOnly?: boolean; readOnlyPaths?: string[]; control?: boolean; projectWorker?: boolean; signal?: AbortSignal; onStarted?: () => void | Promise<void> };
  const createKSwarmTaskHost = async (workspaceRoot: string, participantId?: string, taskOptions: KSwarmScopedTaskOptions = {}) => {
    taskSourcePopulation.assertAccepting();
    const execution = { clock: undefined as KSwarmExecutionClock | undefined };
    const scopedDescriptions = new Map<Tool, ToolDescriptionMetadata>();
    const builtScopedTools = buildToolList(undefined, { cwd: workspaceRoot, readOnlyPaths: taskOptions.readOnlyPaths }, [], scopedDescriptions);
    const scopedTools = taskOptions.nativeReadonlyOnly
      ? builtScopedTools.filter(tool => getBuiltinToolIdentity(tool) === 'readonly') : builtScopedTools;
    const scopedRegistry = new ToolRegistry({ autoMode: true, nativeReadonlyOnly: taskOptions.nativeReadonlyOnly }, scopedTools, scopedDescriptions);
    if(taskOptions.workflowRestrictionCheckpoint)bindNativeWorkflowRestrictionCheckpoint(scopedRegistry,taskOptions.workflowRestrictionCheckpoint);
    const scopedHost = taskSourcePopulation.createHost({
      // This scoped owner is bounded by the KSwarm queue/run clocks.
      taskIdleTimeoutMs: 0,
      materialRegistry,
      runner: input => {
        const signal = taskOptions.signal ? AbortSignal.any([input.signal, taskOptions.signal]) : input.signal;
        return withExecutionLane(taskOptions.control && executionCoordinator.hasLaneCapacity('project_control') ? 'project_control' : taskOptions.projectWorker && executionCoordinator.hasLaneCapacity('project_worker') ? 'project_worker' : 'background', () => coordinateRunner(async runInput => {
        const freshGate = () => { runInput.signal.throwIfAborted(); taskOptions.signal?.throwIfAborted(); taskSourcePopulation.assertAccepting(); };
        freshGate();
        execution.clock = new KSwarmExecutionClock(10 * 60 * 1000);
        execution.clock.start();
        freshGate();
        await taskOptions.onStarted?.();
        await assertNativeRegistryCheckpointCurrent(scopedRegistry);
        freshGate();
        return (options.runner ?? createDesktopModelRunnerWithRegistry(
        scopedRegistry,
        scopedTools,
        options.dataRoot,
        options.kswarmService,
        materialRegistry,
        kswarmCreateProjectToolOptions,
        {
          cwd:workspaceRoot,
          nativeReadonlyOnly: taskOptions.nativeReadonlyOnly,
          getProjectModel: () => resolveProjectAgentModel(participantId),
          officeToMarkdown: input => officeDocumentParser.parse(input),
          // Each KSwarm scoped registry gets the same main-owned runtime, so the
          // report/slide gateways are reachable there too (design §6.2/§6.3).
          ...(options.pluginProviderRuntime ? { pluginProviderRuntime: options.pluginProviderRuntime } : {}),
        },
      ))(runInput);
      })({ ...input, signal }));
      },
      now: options.now,
      aheGuards: { artifactEvidence: false, recoveryContinuity: true },
      createTaskId: () => `task_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    });
    try {
      kswarmTextExecutionClocks.set(scopedHost, execution);
      scopedKSwarmHosts.add(new WeakRef(scopedHost));
      return scopedHost;
    } catch (error) {
      try { await taskSourcePopulation.retireHost(scopedHost); }
      catch (retirementError) { throw new AggregateError([error, retirementError], 'kswarm_task_source_retirement_unconfirmed'); }
      throw error;
    }
  };

  const withKSwarmTaskHost = async <T>(workspaceRoot: string, participantId: string | undefined,
    work: (host: InProcessTaskRuntimeHost) => Promise<T>, taskOptions: KSwarmScopedTaskOptions = {}): Promise<T> => {
    const taskHost = await createKSwarmTaskHost(workspaceRoot, participantId, taskOptions);
    let originalFailure: { error: unknown } | undefined;
    let settledBodyResult!: T;
    let settledBodyFailure: {
        error: unknown;
    } | undefined;
    try {
        try {
            {
                settledBodyResult = await work(taskHost);
            }
        }
        catch (error) {
            originalFailure = { error };
            throw error;
        }
    }
    catch (error) {
        settledBodyFailure = { error };
    }
    {
        try {
            await taskSourcePopulation.retireHost(taskHost);
        }
        catch (error) {
            if (originalFailure)
                throw new AggregateError([originalFailure.error, error], 'kswarm_task_source_retirement_unconfirmed');
            throw error;
        }
    }
    if (settledBodyFailure)
        throw settledBodyFailure.error;
    return settledBodyResult;
  };

  const createCollaborationRoomTaskRunner = () => {
    const roomDescriptions = new Map<Tool, ToolDescriptionMetadata>();
    const roomTools=buildToolList(undefined, undefined, [], roomDescriptions);
    const roomRegistry=createRoomToolRegistry({mode:'discussion',tools:roomTools,metadata:roomDescriptions});
    connectorsService.bindTools(roomRegistry);
    return {registry:roomRegistry,runner:options.runner ?? createDesktopModelRunnerWithRegistry(roomRegistry,roomTools,options.dataRoot,options.kswarmService,materialRegistry,{}, {roomDiscussion:true})};
  };

  async function runCollaborationRoomAgentTask(envelope: CollaborationRoomTurnEnvelope, claimToken: string, workspace?:RoomWorkspaceRunOptions,discussionSignal?:AbortSignal): Promise<{ text: string }> {
    // design §6.2：consumer boundary runtime schema 校验。contextWindow
    // 缺失、sequence 不连续、或 message 边界/total/isComplete 不一致时
    // 拒绝执行，不退回"默认完整"——防止一个绕过 buildRoomContextWindow 的
    // 手写 producer 静默注入一个看似完整、实则残缺的上下文。
    const parsed = parseCollaborationRoomTurnEnvelope(envelope);
    if (!parsed.ok) {
      if(workspace)await workspace.port.release(workspace.context,{executorInstanceId:workspace.context.executorInstanceId,kind:'resources-disposed',verified:true});
      throw new Error(`collaboration_room_envelope_invalid: ${parsed.error}`);
    }
    if(workspace&&(workspace.context.roomId!==envelope.roomId||workspace.context.logicalAgentId!==envelope.logicalAgentId||JSON.stringify(workspace.context.contextScope)!==JSON.stringify(envelope.contextScope))){await workspace.port.release(workspace.context,{executorInstanceId:workspace.context.executorInstanceId,kind:'resources-disposed',verified:true});throw new Error('workspace_execution_context_mismatch');}
    const transcript = envelope.messages.map(message => {
      const sender = message.sender && typeof message.sender === 'object'
        ? ((message.sender as { kind?: string; logicalAgentId?: string; userId?: string }).logicalAgentId
          || (message.sender as { userId?: string }).userId
          || (message.sender as { kind?: string }).kind
          || 'unknown')
        : 'unknown';
      return `[${sender}] ${message.text || `[${message.kind}]`}`;
    }).join('\n');
    const prompt = [
      '你正在一个独立的 Xiaok 协作空间中回复用户。',
      `协作空间：${envelope.roomTitle} (${envelope.roomId})`,
      `你的逻辑智能体身份：${envelope.logicalAgentId}`,
      `上下文范围：${JSON.stringify(envelope.contextScope)}`,
      '只使用下方当前协作空间的消息作为上下文。严禁推测、读取或引用私聊、其他协作空间或未显式选择的项目。',
      // design §6.3：缺席断言规则。isComplete=false 时明确禁止"从未发言"
      // "没发生"类断言；只能表述"截至 sequence N 的当前快照未见"。
      envelope.contextWindow.isComplete
        ? `当前上下文窗口完整：覆盖 sequence ${envelope.contextWindow.fromSequence} 到 ${envelope.contextWindow.toSequence}（共 ${envelope.contextWindow.totalMessages} 条消息中的全部）。`
        : `注意：当前上下文窗口不完整，只覆盖 sequence ${envelope.contextWindow.fromSequence} 到 ${envelope.contextWindow.toSequence}（该协作空间共有 ${envelope.contextWindow.totalMessages} 条消息，本次只看到其中一部分）。严禁断言"某人从未发言""某事没发生"这类需要完整历史才能确认的结论；如需这类结论，只能表述为"截至 sequence ${envelope.contextWindow.toSequence} 的当前快照未见"。`,
      workspace ? `工作目录：${workspace.context.effectiveCwd}。文件工具限定当前工作目录；技能参考文件使用 skillFetchAssets，目录内图片和文档使用 read_workspace_material。${workspace.context.localCommandsAllowed ? '本机命令已授权，可调用已安装 CLI 及其登录配置；先读取 CLI --help 或 skills 文档，不猜参数，不要求用户提供凭据。' : '本机命令尚未开启；需要运行 CLI 时，说明可在本空间的工作区设置开启“允许本机命令执行”。不要推荐用 CUA、launchd 或手工复制命令绕过授权。'} 周期任务使用 scheduled_task_create，未来执行回到当前空间。未支持能力：${roomUnsupportedCapabilities(workspace.context).join(', ')}；不得尝试绕过。` : '当前为无文件执行权的讨论模式，不能读取或修改工作目录、运行命令或读取私人笔记。',
      '',
      transcript,
    ].join('\n');
    const materials: Array<{ materialId: string; role?: MaterialRole }> = [];
    for (const filePath of envelope.attachmentPaths ?? []) {
      try {
        const record = await materialRegistry.importMaterial({
          taskId: `room-material-${envelope.roomMessageId}`,
          sourcePath: filePath,
          role: 'customer_material',
          roleSource: 'user',
        });
        materials.push({ materialId: record.materialId, role: record.role });
      } catch {
        // A missing attachment is represented by the persisted message metadata;
        // other valid materials still reach the agent.
      }
    }
    let registeredTaskId: string | null = null;
    const registeredTaskIds=new Set<string>();
    try {
      if(workspace) {
        let modelBinding:Promise<ReturnType<typeof resolveRuntimeModelBinding>>|undefined;
        const getModelBinding=()=>modelBinding??=loadConfig().then(config=>resolveRuntimeModelBinding(config));
        return await runRoomWorkspaceExecutor({...workspace,prompt,
        materials:materials.map(item=>materialRegistry.get(item.materialId)).filter((item):item is MaterialRecord=>Boolean(item)),
        onTaskCreated:taskId=>{registeredTaskIds.add(taskId);registerRoomHistoryCapability(taskId,{roomId:envelope.roomId,claimToken});},
        createRunner:input=>{ connectorsService.bindTools(input.registry); if(roomTimedActions&&input.context.contextScope.kind==='room_only')for(const tool of createRoomTimedActionTools(roomTimedActions,input.context))input.registry.registerTool(tool); return options.runner??createDesktopModelRunnerWithRegistry(input.registry,input.tools,options.dataRoot,options.kswarmService,materialRegistry,{},
          {cwd:input.cwd,roomExecution:{context:input.context,getModelBinding,authorize:input.authorize,takePendingInput:input.takePendingInput}}); },
      });
      }
      const discussion=createCollaborationRoomTaskRunner();
      registeredTaskId=`room_turn_${randomUUID()}`;
      registerRoomHistoryCapability(registeredTaskId,{roomId:envelope.roomId,claimToken});
      let text='';
      try {
        await discussion.runner({taskId:registeredTaskId,sessionId:registeredTaskId,prompt,
          materials:materials.map(item=>materialRegistry.get(item.materialId)).filter((item):item is MaterialRecord=>Boolean(item)),
          understanding:{goal:prompt,deliverable:'room response',taskType:'unknown',audience:'room members',inputs:[],missingInfo:[],assumptions:[],riskLevel:'low',suggestedPlan:[],nextAction:'execute'},
          signal:discussionSignal??new AbortController().signal,history:[],permissionMode:'auto',emitUsage:async()=>{},
          emitRuntimeEvent:async event=>{if(event.type==='receipt_emitted')text=event.note;},
        });
        return {text:text.trim()};
      } finally {await discussion.registry.drain();discussion.registry.dispose();}
    } finally {
      // design §6.2 RoomHistoryReadCapability：任务结束（无论成功/失败/
      // 异常）后立即释放绑定，防止 taskId 被复用或绑定残留导致陈旧
      // capability 被误用。
      if (registeredTaskId) releaseRoomHistoryCapability(registeredTaskId);
      for(const taskId of registeredTaskIds)releaseRoomHistoryCapability(taskId);
    }
  }

  const connectorsService = new ConnectorsService({
    store: new ConnectorsStore({ dataRoot: options.dataRoot }),
    toolRegistry: registry,
  });

  async function runKSwarmHandoffTask({ handoff, targetParticipantId, signal, onExecutionStarted }: { handoff: KSwarmTaskHandoff; targetParticipantId?: string; signal?: AbortSignal; onExecutionStarted?: () => void | Promise<void> }) {
    if(handoff.workspaceContext||handoff.project.requiredProtocol==='room_workspace_v1')throw new Error('workspace_runtime_protocol_required');
    const throwIfAborted = () => {
      taskSourcePopulation.assertAccepting();
      if (signal?.aborted) {
        throw new DOMException('agent aborted', 'AbortError');
      }
    };

    throwIfAborted();
    const baseArtifactsDir = handoff.project.artifactsDir || (handoff.project.workFolder ? join(handoff.project.workFolder, 'artifacts') : '');
    const workspaceRoot = handoff.project.workFolder || (baseArtifactsDir ? dirname(baseArtifactsDir) : process.cwd());
    const runDirectory = createHash('sha256').update(JSON.stringify([handoff.project.id, handoff.task.id, handoff.runId])).digest('hex').slice(0, 32);
    const artifactsDir = baseArtifactsDir && executionCoordinator.hasLaneCapacity('project_worker')
      ? join(baseArtifactsDir, 'run-' + runDirectory) : baseArtifactsDir;
    if (artifactsDir) mkdirSync(artifactsDir, { recursive: true });
    const clock = new KSwarmExecutionClock(resolveKSwarmWorkerRunMs(handoff.task));
    let executionStarted = false;
    const queueDeadline = Date.now() + 60 * 60 * 1000;
    return withKSwarmTaskHost(workspaceRoot, targetParticipantId, async taskHost => {
    const runStartedAt = Date.now();
    const requiresArtifactEvidence = shouldRequireKSwarmArtifactEvidence(handoff.task);
    const requiredOutputsText = formatKSwarmRequiredOutputs(handoff.task.requiredOutputs);
    const prompt = [
      'KSwarm 项目任务执行。',
      `执行者：${targetParticipantId || 'xiaok-worker'}`,
      `项目：${handoff.project.name}`,
      `目标：${handoff.project.goal}`,
      handoff.project.requirements ? `要求：${handoff.project.requirements}` : '',
      artifactsDir ? `产物目录：${artifactsDir}` : '',
      baseArtifactsDir && artifactsDir !== baseArtifactsDir ? `已有项目资料目录（只读参考，当前产物写入上面的产物目录）：${baseArtifactsDir}` : '',
      `任务：${handoff.task.title}`,
      handoff.task.brief ? `任务说明：${handoff.task.brief}` : '',
      handoff.task.acceptanceCriteria ? `验收标准：${handoff.task.acceptanceCriteria}` : '',
      requiredOutputsText ? `必须产出：${requiredOutputsText}` : '',
      handoff.task.evidenceContract ? `外部来源证据要求：${JSON.stringify(handoff.task.evidenceContract)}` : '',
      handoff.task.repairInstruction ? `修复反馈：${handoff.task.repairInstruction}` : '',
      requiresArtifactEvidence ? '本任务必须写入至少一个完整产物文件到产物目录；不要只在摘要里描述文件，最终交接必须能看到文件路径。' : '',
      VISUAL_PDF_EXPORT_GUIDANCE,
      requiresArtifactEvidence
        ? '不要调用项目推进或修复工具来代替本次任务执行；请直接完成当前任务，把产物文件写入上面的产物目录，使用文件路径作为交接依据，并返回 result manifest。'
        : '不要调用项目推进或修复工具来代替本次任务执行；请直接完成当前任务，并返回 result manifest。如果任务没有要求生成文件，artifacts 可以为空数组，但 summary 必须说明完成了哪些要求。',
    ].filter(Boolean).join('\n');
    let createdTaskId: string | undefined;
    let cancellationRequested = false;
    let cancellation: Promise<void> | undefined;
    let bodyFailure: { error: unknown } | undefined;
    const cancelCreatedTask = () => {
      cancellationRequested = true;
      if (createdTaskId && !cancellation) {
        cancellation = taskHost.cancelTask(createdTaskId);
        // The finally block observes the original failure after physical settle.
        void cancellation.catch(() => {});
      }
    };
    signal?.addEventListener('abort', cancelCreatedTask, { once: true });
    const runPreparedTask = async () => {
      throwIfAborted();
      const created = await taskHost.prepareTask({ prompt, materials: [] });
      createdTaskId = created.taskId;
      if (cancellationRequested || signal?.aborted) cancelCreatedTask();
      throwIfAborted();
      await taskHost.startTask(created.taskId);
      throwIfAborted();
      while (executionStarted ? !clock.expired() : Date.now() < queueDeadline) {
        throwIfAborted();
        const current = await taskHost.inspectTask(created.taskId);
        if (!current) throw Error('desktop_task_snapshot_missing');
        const recovered = { snapshot: current };
        throwIfAborted();
        if (recovered.snapshot.status === 'completed') {
          const resultEvent = [...recovered.snapshot.events].reverse().find(event => event.type === 'result');
          const artifactEvents = recovered.snapshot.events.filter(event => event.type === 'artifact_recorded');
          const eventArtifacts = artifactEvents.map(event => ({
            path: (event as any).filePath || (event as any).path,
            kind: inferKSwarmArtifactKind((event as any).kind, (event as any).label),
            label: (event as any).label,
          })).filter(artifact => artifact.path);
          const discoveredArtifacts = discoverKSwarmArtifactsFromDirectory({
            artifactsDir,
            runStartedAt,
            knownPaths: eventArtifacts.map(artifact => artifact.path),
          });
          const artifacts = [...eventArtifacts, ...discoveredArtifacts];
          if (artifacts.length === 0 && requiresArtifactEvidence) {
            throw new Error('artifact_evidence_missing');
          }
          return {
            summary: resultEvent?.type === 'result' ? resultEvent.result.summary : 'completed',
            artifacts,
            provenance: {
              runtimeSource: 'desktop-agent-runtime',
              producingAgent: targetParticipantId || 'xiaok-worker',
              desktopTaskId: created.taskId,
            },
          };
        }
        if (recovered.snapshot.status === 'failed' || recovered.snapshot.status === 'cancelled') {
          throw new Error(`desktop_task_${recovered.snapshot.status}: ${getKSwarmRuntimeTaskFailureReason(recovered.snapshot) || 'unknown_runtime_failure'}`);
        }
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      await taskHost.cancelTask(created.taskId);
      throw new Error('desktop_task_timeout');
    };
    let result!: Awaited<ReturnType<typeof runPreparedTask>>;
    try { result = await runPreparedTask(); }
    catch (error) { bodyFailure = { error }; }
    signal?.removeEventListener('abort', cancelCreatedTask);
    if (cancellation) {
      try { await cancellation; }
      catch (error) {
        if (bodyFailure) throw new AggregateError([bodyFailure.error, error], 'kswarm_handoff_cancellation_unconfirmed');
        throw error;
      }
    }
    if (bodyFailure) throw bodyFailure.error;
    return result;
    }, { projectWorker: true, signal, onStarted: async () => {
      throwIfAborted();
      executionStarted = true;
      clock.start();
      await onExecutionStarted?.();
      throwIfAborted();
    } });
  }

  async function runWorkspaceProjectTask({handoff,workspace,targetParticipantId}:{handoff:KSwarmTaskHandoff;workspace:RoomWorkspaceRunOptions;targetParticipantId?:string}) {
    const context=workspace.context;
    if(context.contextScope.kind!=='project'||context.contextScope.projectId!==handoff.project.id||context.taskId!==handoff.task.id||context.runId!==handoff.runId||handoff.workspaceContext?.claimId!==context.claimId||handoff.project.workFolder!==context.effectiveCwd||(targetParticipantId&&targetParticipantId!==context.logicalAgentId)){
      // No registry/model/resource exists yet; report the actual pre-start
      // evidence so the runtime can release this rejected admission.
      await workspace.port.release(context,{executorInstanceId:context.executorInstanceId,kind:'resources-disposed',verified:true});
      throw new Error('workspace_project_handoff_mismatch');
    }
    const manifests=new Map<string,{summary:string;artifacts:Array<{path:string;label?:string;kind?:string}>}>();
    let binding:Promise<ReturnType<typeof resolveRuntimeModelBinding>>|undefined;
    const getProjectModel = () => resolveProjectAgentModel(targetParticipantId || context.logicalAgentId);
    const getModelBinding=()=>binding??=getProjectModel().then(model=>model.binding);
    const prompt=[`KSwarm project task ${handoff.task.id}`,`Project: ${handoff.project.name}`,`Goal: ${handoff.project.goal}`,`Task: ${handoff.task.title}`,handoff.task.brief??'',handoff.task.acceptanceCriteria??'',`Required outputs: ${JSON.stringify(handoff.task.requiredOutputs??[])}`,`Write deliverables to the administrator-selected artifacts directory: ${handoff.project.artifactsDir}. No directory name implies acceptance. Report actual output references, not success claims.`].join('\n');
    const result=await runRoomWorkspaceExecutor({...workspace,prompt,port:{...workspace.port,
      async submitManifest(current,manifest){
        manifests.set(current.claimId,manifest);
        if(current.claimId===context.claimId){
          const artifacts=[...new Map([...manifests.values()].flatMap(m=>m.artifacts).map(a=>[resolve(context.effectiveCwd,a.path),{...a,path:resolve(context.effectiveCwd,a.path)}])).values()];
          if(shouldRequireKSwarmArtifactEvidence(handoff.task)&&!artifacts.length)throw new Error('artifact_evidence_missing');
          await workspace.port.submitManifest(current,{summary:manifest.summary,artifacts});
        }
      },
    },createRunner:input=>{ connectorsService.bindTools(input.registry); if(roomTimedActions&&input.context.contextScope.kind==='room_only')for(const tool of createRoomTimedActionTools(roomTimedActions,input.context))input.registry.registerTool(tool); return options.runner??createDesktopModelRunnerWithRegistry(input.registry,input.tools,options.dataRoot,options.kswarmService,materialRegistry,{},
      {cwd:input.cwd,getProjectModel,roomExecution:{context:input.context,getModelBinding,authorize:input.authorize,takePendingInput:input.takePendingInput}}); },
    });
    return {summary:result.text,artifacts:[...manifests.values()].flatMap(m=>m.artifacts)};
  }

  async function runKSwarmReadinessProbe({ targetParticipantId }: { targetParticipantId?: string } = {}) {
    const participantId = targetParticipantId || XIAOK_PO_SEED_ID;
    const base = {
      runtimeSource: 'desktop-agent-runtime',
      participantId,
      capabilities: [
        'planning',
        'research',
        'analysis',
        'source_research',
        'writing',
        'report_generation',
      ],
      outputCapabilities: ['markdown', 'html', 'report_html', 'text', 'json', 'csv'],
    };

    try {
      const readinessConfig = await loadConfig();
      if (!Object.keys(readinessConfig.models ?? {}).length) return { ...base, ok: false as const, reason: 'model_config_missing' };
      if (options.readinessModelProbe) {
        const result = await options.readinessModelProbe();
        if (!result.ok) throw new Error(result.error || 'provider_connection_failed');
      } else {
        const projectModel = await resolveProjectAgentModel(participantId);
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(new DOMException('agent readiness model timeout', 'TimeoutError')), 30_000);
        let sawProtocolResponse = false;
        try {
          for await (const chunk of projectModel.stream({
            deadline: Date.now() + 30_000,
            messages: [{ role: 'user', content: [{ type: 'text', text: 'ping' }] }],
            tools: [],
            systemPrompt: 'Reply with "ok" to verify the current Desktop model connection. Do not use tools.',
            options: { signal: controller.signal },
            invocationId: `inv_${randomUUID()}`,
          })) {
            if (chunk.type !== 'usage') sawProtocolResponse = true;
          }
          if (controller.signal.aborted) throw controller.signal.reason;
          if (!sawProtocolResponse) throw new Error('provider_connection_empty_stream');
        } finally {
          clearTimeout(timeout);
        }
      }

      const toolNames = new Set(registry.getToolDefinitions().map(tool => tool.name));
      for (const requiredTool of ['create_project', 'inspect_project', 'continue_project', 'repair_project_task_from_file']) {
        if (!toolNames.has(requiredTool)) {
          return { ...base, ok: false as const, reason: 'kswarm_tools_unavailable' };
        }
      }

      mkdirSync(join(options.dataRoot, 'runtime-health'), { recursive: true });
      return { ...base, ok: true as const };
    } catch (error) {
      return {
        ...base,
        ok: false as const,
        reason: error instanceof Error ? error.message : String(error),
      };
    }
  }

  async function runKSwarmWorkflowNode({ handoff, targetParticipantId }: { handoff: KSwarmWorkflowNodeHandoff; targetParticipantId?: string }) {
    const { getKSwarmWorkflowReadPort } = await import('./kswarm-service.js');
    const restriction=await createNativeWorkflowRestrictionCheckpoint(await getKSwarmWorkflowReadPort(options.kswarmService),{projectId:handoff.projectId,workflowRunId:handoff.workflowRunId,workflowId:handoff.workflowId,nodeId:handoff.nodeId,nodeKind:handoff.nodeKind,attempt:handoff.attempt,handoffId:handoff.handoffId,participantId:targetParticipantId||'xiaok-worker',...(handoff.project?.workFolder?{admittedRoot:handoff.project.workFolder}:{})});
    if(handoff.project?.id&&handoff.project.id!==handoff.projectId)throw Error('workflow_project_binding_mismatch');
    const workspaceRoot = restriction.root;
    const artifactsDir = join(workspaceRoot, 'artifacts');
    const taskDeliverableNode = isKSwarmTaskDeliverableWorkflowNode(handoff);
    const projectDeliverableNode = isKSwarmProjectDeliverableWorkflowNode(handoff);
    const deliverableNode = taskDeliverableNode || projectDeliverableNode;
    if (artifactsDir) mkdirSync(artifactsDir, { recursive: true });
    return withKSwarmTaskHost(workspaceRoot, targetParticipantId, async taskHost => {
    const runStartedAt = Date.now();
    const prompt = buildKSwarmWorkflowNodePrompt(handoff, targetParticipantId || 'xiaok-worker', { artifactsDir });
    const runtimeResult = await runKSwarmRuntimeTextTask(taskHost, prompt, {
      artifactsDir,
      runStartedAt,
    });
    const { summary, artifacts } = runtimeResult;
    let parsed: Record<string, unknown>;
    try {
      parsed = parseKSwarmRuntimeStructuredJson(runtimeResult);
    } catch {
      console.warn('[kswarm-workflow-node] structured JSON extraction failed, fallback applied', {
        nodeKind: handoff.nodeKind,
        rawPreview: summary.slice(0, 200),
      });
      if (handoff.nodeKind === 'review') {
        // Review nodes must not default to 'blocked' on parse failure — that
        // permanently blocks the workflow. Use 'needs_rework' so the orchestrator
        // can retry or escalate, and capture the raw output as the reason.
        parsed = {
          reviewDecision: {
            status: 'needs_rework',
            reason: summary.slice(0, 2000) || 'Reviewer output was not structured JSON.',
          },
        };
      } else {
        parsed = {};
      }
    }

    if (handoff.nodeKind === 'review') {
      const rawDecision = isRecord(parsed.reviewDecision) ? parsed.reviewDecision : parsed;
      const reviewDecision = normalizeKSwarmWorkflowReviewDecision(rawDecision);
      const output = normalizeKSwarmWorkflowNodeOutput(isRecord(parsed.output) ? parsed.output : {}, summary);
      return { output, reviewDecision };
    }

    const output = normalizeKSwarmWorkflowNodeOutput(isRecord(parsed.output) ? parsed.output : parsed, summary);
    const mergedArtifacts = mergeKSwarmArtifacts(output.artifacts, artifacts, { artifactsDir });
    if (deliverableNode) {
      if (mergedArtifacts.length === 0) {
        throw new Error('workflow_artifact_evidence_missing');
      }
      return {
        output: {
          ...output,
          artifacts: mergedArtifacts,
          ...(artifactsDir ? { workFolder: workspaceRoot, workspacePath: workspaceRoot } : {}),
          evidenceRefs: mergeKSwarmEvidenceRefs(output.evidenceRefs, mergedArtifacts, { artifactsDir }),
        },
        reviewDecision: null,
      };
    }

    return {
      output: {
        ...output,
        ...(mergedArtifacts.length > 0 ? {
          artifacts: mergedArtifacts,
          evidenceRefs: mergeKSwarmEvidenceRefs(output.evidenceRefs, mergedArtifacts, { artifactsDir }),
          ...(artifactsDir ? { workFolder: workspaceRoot, workspacePath: workspaceRoot } : {}),
        } : {}),
      },
      reviewDecision: null,
    };
    }, {workflowRestrictionCheckpoint:restriction.checkpoint,...(handoff.nodeKind==='review'?{control:true}:{}),nativeReadonlyOnly:restriction.readonly});
  }

  async function runKSwarmAssignPo({ payload, targetParticipantId, startAfterPlanning }: { payload: Record<string, unknown>; targetParticipantId?: string; startAfterPlanning?: boolean }) {
    try {
      const projectId = readString(payload.projectId) || readString(payload.taskId);
      if (!projectId) return { ok: false as const, error: 'project_id_missing' };
      const fromAgent = targetParticipantId || readString(payload.poAgent) || XIAOK_PO_SEED_ID;
      const members = readStringArray(payload.members);
      const fallbackWorkerId = members[0] || 'xiaok-worker';
      const prompt = buildKSwarmAssignPoPrompt(payload, fallbackWorkerId);
      const runtimeResult = await withKSwarmTaskHost(process.cwd(), fromAgent, taskHost => runKSwarmRuntimeTextTask(taskHost, prompt), { control: true });
      const parsed = parseKSwarmRuntimeStructuredJson(runtimeResult);
      const plan = normalizeKSwarmPlan(isRecord(parsed.plan) ? parsed.plan : parsed, fallbackWorkerId, {
        userGoal: readString(payload.goal),
        userRequirements: readString(payload.requirements),
        planningGuidance: readString(payload.planningGuidance),
      });
      const tasks = buildKSwarmTasksFromPlan(plan);

      // Phase 1: submit plan. `plan_already_exists` is non-fatal on retry —
      // the plan is durable, but tasks/dispatch may still be missing, so we
      // must continue rather than short-circuit a half-bootstrapped project.
      try {
        await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}/plan`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ plan, fromAgent }),
        });
      } catch (planError) {
        const message = planError instanceof Error ? planError.message : String(planError);
        if (message !== 'plan_already_exists') {
          return { ok: false as const, error: message, phase: 'plan' as const };
        }
      }

      // Phase 2: create tasks. Server `addTasksChecked` skips already-existing
      // task ids, so re-running this phase is idempotent.
      if (tasks.length > 0) {
        try {
          await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}/tasks`, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ tasks, fromAgent }),
          });
        } catch (tasksError) {
          return {
            ok: false as const,
            error: tasksError instanceof Error ? tasksError.message : String(tasksError),
            phase: 'tasks' as const,
          };
        }
      }
      if (startAfterPlanning) {
        // Broker planning used to stop after persisting the board. Read the
        // canonical user policy, then enter the same activation gate as the
        // durable bootstrap queue; never infer permission from model output.
        const detail = await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}`);
        if (!isRecord(detail)) throw new Error('project_policy_unavailable');
        const project = isRecord(detail.project) ? detail.project : detail;
        const policy = readString(project.requestedStartPolicy);
        if (project.poAgent !== fromAgent) throw new Error('project_po_mismatch');
        if (policy === 'auto_activate_after_plan' || policy === 'activate_and_dispatch_after_plan') {
          await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}/activate-and-start`, withKSwarmDesktopMutationToken(options.kswarmService, {
            method: 'POST', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ fromAgent, startPolicy: policy,
              idempotencyKey: `initial-plan-bootstrap:${projectId}:${policy}` }),
          }));
        }
      }
      return { ok: true as const };
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : String(error) };
    }
  }

  async function bootstrapKSwarmInitialPlan(input: KSwarmInitialPlanBootstrapInput) {
    const result = await runKSwarmAssignPo({
      targetParticipantId: input.poAgent,
      payload: {
        projectId: input.projectId,
        projectName: input.projectName,
        name: input.projectName,
        goal: input.goal,
        requirements: input.requirements,
        planningGuidance: input.planningGuidance,
        poAgent: input.poAgent,
        members: input.members,
      },
    });
    if (!result.ok) {
      return result;
    }
    // Phase 3: activate and start through the KSwarm lifecycle gate. Calling
    // `/dispatch` directly leaves dialogue-created projects stuck before
    // approval, so the retryable queue must own activation + dispatch together.
    try {
      await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(input.projectId)}/activate-and-start`, withKSwarmDesktopMutationToken(options.kswarmService, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          fromAgent: input.poAgent,
          startPolicy: input.startPolicy || 'activate_and_dispatch_after_plan',
          idempotencyKey: `initial-plan-bootstrap:${input.projectId}:${input.startPolicy || 'activate_and_dispatch_after_plan'}`,
        }),
      }));
    } catch (dispatchError) {
      return {
        ok: false as const,
        error: dispatchError instanceof Error ? dispatchError.message : String(dispatchError),
        phase: 'activate_and_start' as const,
      };
    }
    return { ok: true as const };
  }

  const pendingKSwarmReviews = new Map<string, ReturnType<typeof executeKSwarmReviewSubmission>>();
  function runKSwarmReviewSubmission(input: Parameters<typeof executeKSwarmReviewSubmission>[0]) {
    const result = isRecord(input.payload.result) ? input.payload.result : {};
    const key = JSON.stringify([input.payload.projectId, input.payload.taskId, input.payload.runId ?? result.runId ?? result.provenance ?? result]);
    const pending = pendingKSwarmReviews.get(key);
    if (pending) return pending;
    const work = executeKSwarmReviewSubmission(input).finally(() => pendingKSwarmReviews.delete(key));
    pendingKSwarmReviews.set(key, work);
    return work;
  }

  async function executeKSwarmReviewSubmission({ payload, targetParticipantId }: { payload: Record<string, unknown>; targetParticipantId?: string }) {
    try {
      const projectId = readString(payload.projectId);
      const taskId = readString(payload.taskId);
      if (!projectId || !taskId) return { ok: false as const, error: 'project_or_task_id_missing' };
      const fromAgent = targetParticipantId || readString(payload.poAgent) || XIAOK_PO_SEED_ID;
      const reviewPrompt = buildKSwarmReviewPrompt(payload);
      const detail = await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}`);
      const readOnlyPaths = resolveKSwarmReviewReadPaths(payload, detail);
      const runtimeResult = await withKSwarmTaskHost(process.cwd(), fromAgent, taskHost => runKSwarmRuntimeTextTask(taskHost, reviewPrompt), { control: true, nativeReadonlyOnly: true, readOnlyPaths });
      const parsed = parseKSwarmRuntimeStructuredJson(runtimeResult);
      const review = normalizeKSwarmReview(isRecord(parsed.review) ? parsed.review : parsed);

      await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}/tasks/${encodeURIComponent(taskId)}/review`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ review, fromAgent }),
      });

      if (review.passed) {
        const detail = await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}`);
        if (shouldSynthesizeKSwarmProject(detail)) {
          const synthesisPrompt = buildKSwarmSynthesisPrompt(detail);
          const synthesis = (await withKSwarmTaskHost(process.cwd(), fromAgent, taskHost => runKSwarmRuntimeTextTask(taskHost, synthesisPrompt), { control: true })).summary;
          await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}/synthesize`, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ synthesis, fromAgent }),
          });
        }
      }
      return { ok: true as const };
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : String(error) };
    }
  }

  async function runKSwarmPlanApproved({ payload, targetParticipantId }: { payload: Record<string, unknown>; targetParticipantId?: string }) {
    try {
      const projectId = readString(payload.projectId) || readString(payload.taskId);
      if (!projectId) return { ok: false as const, error: 'project_id_missing' };
      const fromAgent = targetParticipantId || readString(payload.poAgent) || XIAOK_PO_SEED_ID;
      await requestKSwarmJson(options.kswarmService, `/projects/${encodeURIComponent(projectId)}/dispatch`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ fromAgent }),
      });
      return { ok: true as const };
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : String(error) };
    }
  }

  const runArtifactWorkspaceUserMutation = async <T>(
    action: string,
    input: Parameters<ArtifactWorkspaceService['recordPublicMutationFailure']>[0],
    operation: () => Promise<T>,
  ): Promise<T> => {
    try {
      const result = await operation();
      if (action !== 'save_viewport') {
        workspaceService.notifyIdentityChanged({
          conversationId: String(input.conversationId),
          workspaceRootId: String(input.workspaceRootId ?? ''),
        });
      }
      return result;
    } catch (error) {
      workspaceService.recordPublicMutationFailure(input, action, error);
      throw error;
    }
  };

  const historicalWorkflowArtifactRecovery = new Map<string, Promise<TaskSnapshot>>();
  const workflowStatusTool = createKSwarmGetDynamicWorkflowStatusTool(options.kswarmService);
  const recoverTaskWithWorkflowArtifacts = async (taskId: string): Promise<{ snapshot: TaskSnapshot }> => {
    let pending = historicalWorkflowArtifactRecovery.get(taskId);
    if (!pending) {
      pending = (async () => {
        const recovered = await resolveScopedTaskHost(taskId, host).recoverTask(taskId);
        recovered.snapshot = conversationProjects.restoreCreationCard(recovered.snapshot);
        const lookup = findHistoricalWorkflowStatusLookup(recovered.snapshot);
        return lookup
          ? recoverHistoricalWorkflowStatusArtifacts({
              snapshot: recovered.snapshot,
              lookup,
              statusTool: workflowStatusTool,
            })
          : recovered.snapshot;
      })();
      historicalWorkflowArtifactRecovery.set(taskId, pending);
    }
    try {
      return { snapshot: await pending };
    } finally {
      if (historicalWorkflowArtifactRecovery.get(taskId) === pending) {
        historicalWorkflowArtifactRecovery.delete(taskId);
      }
    }
  };

  let materialInstancesClosing: Promise<void> | undefined;
  function closeMaterialRegistryAndArtifactFileManagerInstances(): Promise<void> {
    if (materialInstancesClosing) return materialInstancesClosing;
    let resolve!: () => void, reject!: (error: unknown) => void;
    materialInstancesClosing = new Promise<void>((done, fail) => { resolve = done; reject = fail; });
    const closings: Promise<void>[] = [];
    for (const instance of [materialRegistry, artifactWorkspaceFileManager]) {
      try { closings.push(instance.sealAndDrainInstanceMutations()); } catch (error) { closings.push(Promise.reject(error)); }
    }
    void Promise.allSettled(closings).then(results => {
      const errors = results.flatMap(result => result.status === 'rejected' ? [result.reason] : []);
      if (errors.length) reject(new AggregateError(errors, 'material_instances_close_unconfirmed')); else resolve();
    });
    return materialInstancesClosing;
  }

  const authorizeLocalTaskActor = async (taskId: string, actor: NativeActor): Promise<void> => {
    if (actor?.requestSource !== 'user' || actor.actorId !== `desktop-user:${multiAgentProfileId}`) throw new Error('task_actor_forbidden');
    if (!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,255}$/.test(taskId)) throw new Error('invalid_task_id');
    await multiAgentReady;
    const snapshot = await snapshotStore.recoverTask(taskId);
    const threadId = snapshot?.context?.threadId;
    const thread = threadId ? multiAgentStore?.getThread(threadId) : null;
    if (thread && (thread.profileId !== multiAgentProfileId || (thread.deleteState ?? 'none') !== 'none')) throw new Error('task_scope_forbidden');
  };

  return {
    multiAgent: multiAgentService ? { service: multiAgentService, ready: multiAgentReady, profileId: multiAgentProfileId, workspaceId: multiAgentWorkspaceId, cwd: multiAgentCwd } : null,
    goalShutdown,
    // Main-only Task metadata close. Group/native effects require their own drain.
    closeTaskSourceWritersForMigration: taskSourcePopulation.close,
    closeMaterialRegistryAndArtifactFileManagerInstances,
    sealAndDrainArtifactWorkspaceServiceInstance: () => artifactWorkspaceService.sealAndDrainInstanceMutations(),
    async disposeMultiAgent(): Promise<void> {
      goalShutdown.ingress.stopAccepting();
      activityMcp?.dispose();
      unsubscribeActivityGroups?.(); activitySources?.dispose(); activityService?.dispose(); activityStore?.close();
      await codexTasks.dispose();
      unsubscribeMultiAgentGoal?.();
      await multiAgentApprovals?.dispose();
      await multiAgentService?.dispose(); multiAgentCatalog?.dispose();
      // A never-settled owner still needs its journal until process exit.
      if (executionCoordinator.snapshot().active === 0 && !multiAgentService?.runtimeStatus().blocked) multiAgentStore?.close();
    },
    parseOfficeDocument(input: { absolutePath: string; maxOutputChars: number; signal?: AbortSignal }) {
      return officeDocumentParser.parse(input);
    },
    registerTimedActionService(service: TimedActionService) {
      roomTimedActions=service;
      for (const tool of createTimedActionTools(service)) {
        registry.registerTool(tool);
      }
    },
    getConnectorsConfig(request?: ConnectorsMutationRequest) {
      return connectorsService.getConfig(request);
    },
    async setConnectorsConfig(input: unknown, request?: ConnectorsMutationRequest) {
      return connectorsService.setConfig(input, request);
    },
    listConnectorRuntimes() {
      return connectorsService.listProviders();
    },
    async testConnectorProvider(kind: 'search' | 'fetch', request?: ConnectorsMutationRequest) {
      return connectorsService.testProvider(kind, request);
    },
    registerChannelTools() {
      const channelTools: Tool[] = [
        {
          permission: 'safe',
          definition: {
            name: 'channel_list',
            description: '列出所有配置的消息通道（云之家、Discord、飞书等）。当用户想知道有哪些通道可用时使用。',
            inputSchema: { type: 'object', properties: {} },
          },
          async execute() {
            const config = await loadConfig();
            const raw = config as unknown as Record<string, unknown>;
            const channels = (raw.channels ?? {}) as Record<string, unknown>;
            const list = Object.entries(channels).map(([key, ch]) => {
              const c = ch as { name?: string; sendMsgUrl?: string; webhookUrl?: string; enabled?: boolean };
              return {
                id: key,
                name: c.name || key,
                webhookUrl: c.webhookUrl || c.sendMsgUrl,
                enabled: c.enabled !== false,
              };
            });
            return JSON.stringify(list, null, 2);
          },
        },
        {
          permission: 'safe',
          definition: {
            name: 'channel_send',
            description: '向指定通道发送消息。当用户说"发消息到云之家"、"通知团队"、"发送到飞书"等时使用此工具。',
            inputSchema: {
              type: 'object',
              properties: {
                channel_id: { type: 'string', description: '通道 ID（如 yunzhijia、discord、feishu）' },
                message: { type: 'string', description: '要发送的消息内容' },
              },
              required: ['channel_id', 'message'],
            },
          },
          async execute(input) {
            const channelId = String(input.channel_id ?? '').trim();
            const message = String(input.message ?? '').trim();
            if (!channelId || !message) {
              return 'Error: channel_id 和 message 不能为空';
            }

            const config = await loadConfig();
            const raw = config as unknown as Record<string, unknown>;
            const channels = (raw.channels ?? {}) as Record<string, unknown>;
            const ch = channels[channelId] as { sendMsgUrl?: string; webhookUrl?: string } | undefined;
            const url = ch?.sendMsgUrl || ch?.webhookUrl;
            if (!url) {
              return `Error: 通道 ${channelId} 未配置 webhook URL`;
            }

            try {
              const start = Date.now();
              const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ msgtype: 'text', text: { content: message } }),
              });
              const latencyMs = Date.now() - start;
              if (!response.ok) {
                return `Error: 发送失败，HTTP ${response.status}`;
              }
              return JSON.stringify({ success: true, latencyMs, channelId, messageLength: message.length }, null, 2);
            } catch (e) {
              return `Error: 发送失败 - ${(e as Error).message}`;
            }
          },
        },
      ];
      for (const tool of channelTools) {
        registry.registerTool(tool);
      }
    },
    registerSkillTools() {
      const skillTools: Tool[] = [
        {
          permission: 'safe',
          definition: {
            name: 'skill_install',
            description: '安装一个技能。当用户说"安装XX技能"、"添加XX功能"、"帮我安装 clawhub 上的技能"时使用此工具。',
            inputSchema: {
              type: 'object',
              properties: {
                skill_name: { type: 'string', description: '技能名称（clawhub 上的 slug）' },
              },
              required: ['skill_name'],
            },
          },
          async execute(input) {
            const skillName = String(input.skill_name ?? '').trim();
            if (!skillName) return 'Error: skill_name 不能为空';

            const result = spawnSync('clawhub', ['install', skillName], {
              encoding: 'utf-8',
              timeout: 60000,
              cwd: process.cwd(),
            });
            if (result.error) {
              return `Error: 执行失败 - ${result.error.message}`;
            }
            if (result.status !== 0) {
              const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
              return `Error: ${stderr.slice(0, 500)}`;
            }
            bumpSkillCatalogVersion();
            return JSON.stringify({ success: true, skillName, message: `技能 ${skillName} 已安装` }, null, 2);
          },
        },
        {
          permission: 'safe',
          definition: {
            name: 'skill_uninstall',
            description: '卸载一个技能。当用户说"卸载XX技能"、"删除XX功能"时使用此工具。',
            inputSchema: {
              type: 'object',
              properties: {
                skill_name: { type: 'string', description: '技能名称' },
              },
              required: ['skill_name'],
            },
          },
          async execute(input) {
            const skillName = String(input.skill_name ?? '').trim();
            if (!skillName) return 'Error: skill_name 不能为空';

            const result = spawnSync('clawhub', ['uninstall', skillName], {
              encoding: 'utf-8',
              timeout: 30000,
              cwd: process.cwd(),
            });
            if (result.error) {
              return `Error: 执行失败 - ${result.error.message}`;
            }
            if (result.status !== 0) {
              const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
              return `Error: ${stderr.slice(0, 500)}`;
            }
            bumpSkillCatalogVersion();
            return JSON.stringify({ success: true, skillName, message: `技能 ${skillName} 已卸载` }, null, 2);
          },
        },
        {
          permission: 'safe',
          definition: {
            name: 'skill_list',
            description: '列出已安装的技能。当用户问"有哪些技能"、"我安装了什么技能"时使用。',
            inputSchema: { type: 'object', properties: {} },
          },
          async execute() {
            const catalog = createSkillCatalog(undefined, process.cwd());
            const skills = await catalog.reload();
            return JSON.stringify(skills.map(s => ({
              name: s.name,
              aliases: s.aliases ?? [],
              description: s.description,
              source: s.source,
              tier: s.tier,
            })), null, 2);
          },
        },
      ];
      for (const tool of skillTools) {
        registry.registerTool(tool);
      }
    },
    /**
     * Design v58 §9.3: the single idempotent entry point that starts the provider
     * runtime after the compatibility deployment and the MCP connections exist.
     * `start()` is single-flight inside the facade, so calling this twice is safe.
     */
    async startPluginProviderRuntime(): Promise<{ started: boolean; reason?: string }> {
      const runtime = options.pluginProviderRuntime as
        | (GatewayRuntimeFacade & { start?: (specs: PluginComponentSpec[]) => Promise<void> })
        | undefined;
      if (!runtime?.start) return { started: false, reason: 'no_provider_runtime' };
      const bridge: ReservedProviderBridge = {
        listOperations: async (server) => reservedServerHandles.get(server)?.listOperations() ?? [],
        call: async (server, request, signal) => {
          signal?.throwIfAborted();
          const handle = reservedServerHandles.get(server);
          if (!handle) throw new Error(`provider_unavailable: ${server} has no live connection`);
          const result = await handle.call(request.operation, request.input, { signal });
          signal?.throwIfAborted();
          return result;
        },
        close: async (server) => { await reservedServerHandles.get(server)?.close(); },
      };
      await runtime.start(reservedProviderSpecs(bridge, {
        slide: pluginMcpServers.find((s) => s.name === 'slide-renderer')?.pluginName ?? 'kai-slide-creator',
        report: pluginMcpServers.find((s) => s.name === 'report-renderer')?.pluginName ?? 'kai-report-creator',
      }));
      return { started: true };
    },
    async registerMcpTools(): Promise<{ dispose: () => Promise<void> }> {
      const autoConnectDecision = isComputerUseAutoConnectEligibleApp(computerUsePreference, computerUseAppIdentity);
      await reconnectPluginMcpServers({
        userInitiated: false,
        autoConnectComputerUse: autoConnectDecision.eligible,
      });
      return {
        dispose: () => {
          computerUseLifecycleEpoch += 1;
          computerUseActivation?.controller.abort();
          dependencyTasks.cancelAll();
          return disposePluginMcpServers();
        },
      };
    },
    async registerDeferredPythonMcpTools(): Promise<PluginMcpServerState[]> {
      const names = [...deferredPythonServerNames];
      deferredPythonServerNames.clear();
      for (const targetServerName of names) {
        await reconnectPluginMcpServers({ userInitiated: false, targetServerName });
      }
      return pluginMcpServers;
    },
    markDeferredPythonMcpToolsUnavailable(): void {
      for (let index = 0; index < pluginMcpServers.length; index += 1) {
        const server = pluginMcpServers[index];
        if (!deferredPythonServerNames.has(server.name)) continue;
        pluginMcpServers[index] = {
          ...server,
          connected: false,
          lastError: 'managed_python_unavailable',
        };
      }
      deferredPythonServerNames.clear();
    },
    listPluginMcpServers(): PluginMcpServerState[] {
      return pluginMcpServers;
    },
    /**
     * Design v58 §7.2: the blanket restart is gone. It reconnected *every* server
     * with `userInitiated: true`, which bypassed the CUA persisted preference and
     * could re-enable a component the user had disabled. Retry is now scoped to one
     * component and never writes desired state.
     */
    async retryPluginComponent(
      input: { componentId: string; requestSource: 'user' },
    ): Promise<PluginMcpServerState[]> {
      if (input.requestSource !== 'user') {
        throw new Error('retryPluginComponent requires requestSource "user"');
      }
      const target = pluginMcpServers.find((server) => server.name === input.componentId);
      if (!target) return pluginMcpServers;
      // A disabled CUA component must not be activated by a retry.
      if (target.pluginName === 'cua-computer-use' && !computerUsePreference.enabledByUser) {
        return pluginMcpServers;
      }
      return reconnectPluginMcpServers({ userInitiated: true, targetServerName: input.componentId, targetPluginName: target.pluginName });
    },
    async enableComputerUse(input: { requestSource: 'user' | 'agent' | 'scheduler' }): Promise<{ state: string; mcpConnected: boolean; wrapperReady: boolean; lastError?: string }> {
      if (input?.requestSource !== 'user') throw new Error('request_source_user_required');
      if (computerUsePreference.readOnlyUnknownSchema) throw new Error('computer_use_preference_schema_unsupported');
      if (process.platform === 'win32') {
        computerUsePreference = { ...computerUsePreference, schemaVersion: 2, platform: 'win32', enabledByUser: true, autoConnectAfterSuccessfulEnablement: true };
        persistComputerUsePreference();
      }
      await reconnectPluginMcpServers({ userInitiated: true, targetServerName: 'cua-driver', targetPluginName: 'cua-computer-use' });
      return getComputerUseCapabilityStatus();
    },
    async reconnectComputerUse(input: { requestSource: 'user' | 'agent' | 'scheduler' }): Promise<{ state: string; mcpConnected: boolean; wrapperReady: boolean; lastError?: string }> {
      if (input?.requestSource !== 'user') throw new Error('request_source_user_required');
      if (!computerUsePreference.enabledByUser || computerUsePreference.readOnlyUnknownSchema) return getComputerUseCapabilityStatus();
      await reconnectPluginMcpServers({ userInitiated: true, targetServerName: 'cua-driver', targetPluginName: 'cua-computer-use' });
      return getComputerUseCapabilityStatus();
    },
    async disableComputerUse(input: { requestSource: 'user' | 'agent' | 'scheduler' }): Promise<{ state: string; mcpConnected: boolean; wrapperReady: boolean; lastError?: string }> {
      if (input?.requestSource !== 'user') throw new Error('request_source_user_required');
      computerUseLifecycleEpoch += 1;
      computerUseActivation?.controller.abort();
      dependencyTasks.cancel('cua-computer-use:cua-driver');
      const closed = disposePluginMcpServers((server) => server.pluginName === 'cua-computer-use');
      for (let index = pluginMcpServers.length - 1; index >= 0; index -= 1) {
        if (pluginMcpServers[index].pluginName === 'cua-computer-use') pluginMcpServers.splice(index, 1);
      }
      computerUseBackend = null;
      computerUseUnavailableError = buildComputerUseDisabledUnavailableError();
      computerUsePreference = {
        ...computerUsePreference,
        schemaVersion: process.platform === 'win32' ? 2 : (computerUsePreference.schemaVersion ?? 1),
      ...(process.platform === 'win32' ? { platform: 'win32' as const } : {}),
        enabledByUser: false,
        autoConnectAfterSuccessfulEnablement: false,
        lastFailureCode: 'COMPUTER_USE_DISABLED_BY_USER',
        autoConnectSuspendedReason: 'COMPUTER_USE_DISABLED_BY_USER',
      };
      persistComputerUsePreference();
      await closed;
      return getComputerUseCapabilityStatus();
    },
    getComputerUseCapabilityStatus(): { state: string; mcpConnected: boolean; wrapperReady: boolean; lastError?: string } {
      return getComputerUseCapabilityStatus();
    },
    async installPlugin(name: string): Promise<{ success: boolean; error?: string }> {
      const pluginName = name.trim();
      if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(pluginName)) {
        return { success: false, error: 'invalid_plugin_name' };
      }
      return new Promise((resolve) => {
        execFile('xiaok', ['plugin', 'install', pluginName], { timeout: 120_000 }, (error, stdout, stderr) => {
          if (error) {
            resolve({ success: false, error: stderr || error.message });
            return;
          }
          resolve({ success: true });
        });
      });
    },
    async listAvailablePlugins(): Promise<Array<{ name: string; display_name: string; description: string; version: string; installed: boolean }>> {
      try {
        const res = await fetch('https://raw.githubusercontent.com/kaisersong/kai-xiaok-plugins/main/registry.json');
        if (!res.ok) return [];
        const data = await res.json() as { plugins: Array<{ name: string; display_name: string; description: string; version: string }> };
        return (data.plugins || []).map(p => ({
          ...p,
          installed: existsSync(join(pluginRootDir, p.name, 'plugin.json')),
        }));
      } catch {
        return [];
      }
    },
    async listPluginDependencyStatuses() {
      return Promise.all(pluginDependencies.map(getDependencyStatusView));
    },
    async installPluginDependency(input: { pluginName: string; dependencyId: string; confirmed?: boolean; requestSource: 'user' | 'agent' | 'scheduler' }) {
      return mutatePluginDependency(input, 'install');
    },
    async updatePluginDependency(input: { pluginName: string; dependencyId: string; confirmed?: boolean; requestSource: 'user' | 'agent' | 'scheduler' }) {
      return mutatePluginDependency(input, 'update');
    },
    async cancelPluginDependencyTask(input: { pluginName: string; dependencyId: string; requestSource: 'user' | 'agent' | 'scheduler' }) {
      if (input?.requestSource !== 'user') throw new Error('request_source_user_required');
      return { cancelling: dependencyTasks.cancel(`${input.pluginName}:${input.dependencyId}`) };
    },
    async diagnosePluginDependency(input: { pluginName: string; dependencyId: string }): Promise<{ success: boolean; output?: string; status?: unknown; error?: string }> {
      const entry = findPluginDependency(input.pluginName, input.dependencyId);
      if (!entry) return { success: false, error: 'plugin_dependency_not_found' };
      if (!isDependencyPlatformSupported(entry.dependency, await dependencyStatusOptions())) return { success: false, error: 'unsupported_platform' };
      const status = await getDependencyStatusView(entry);
      if (!status.resolvedBinary) return { success: false, error: 'plugin_dependency_binary_missing' };
      const doctor = entry.dependency.health?.doctor;
      if (!doctor) return { success: false, error: 'plugin_dependency_diagnose_not_available' };
      const [, ...args] = doctor;
      const result = await runDependencyCommand(status.resolvedBinary, args, 120_000);
      if (!result.success) return { success: false, error: result.error };
      return { success: true, output: result.output, status: await getDependencyStatusView(entry) };
    },
    async importMaterial(input: { taskId: string; filePath: string; role: MaterialRole }) {
      mkdirSync(options.dataRoot, { recursive: true });
      const record = await materialRegistry.importMaterial({
        taskId: input.taskId,
        sourcePath: input.filePath,
        role: input.role,
        roleSource: 'user',
      });
      return materialRegistry.toView(record);
    },
    async listSkills() {
      let incomplete = false;
      const catalog = createSkillCatalog(undefined, process.cwd(), { onDiscoveryIssue: () => { incomplete = true; } });
      const skills = await captureSkillReadonlyPromise(catalog.reload(), 'skill_list_projection_unavailable');
      if (incomplete || !Array.isArray(skills)) throw Error('skill_list_projection_unavailable');
      return skills.map(s => ({
        name: s.name,
        aliases: s.aliases ?? [],
        description: s.description,
        source: s.source,
        tier: s.tier,
      }));
    },
    async installSkill(skillName: string): Promise<{ success: boolean; message: string }> {
      const result = spawnSync('clawhub', ['install', skillName], {
        encoding: 'utf-8',
        timeout: 60000,
        cwd: process.cwd(),
      });
      if (result.error) {
        return { success: false, message: `执行失败: ${result.error.message}` };
      }
      if (result.status !== 0) {
        const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
        return { success: false, message: stderr.slice(0, 500) };
      }
      bumpSkillCatalogVersion();
      return { success: true, message: `技能 ${skillName} 已安装` };
    },
    async uninstallSkill(skillName: string): Promise<{ success: boolean; message: string }> {
      const result = spawnSync('clawhub', ['uninstall', skillName], {
        encoding: 'utf-8',
        timeout: 30000,
        cwd: process.cwd(),
      });
      if (result.error) {
        return { success: false, message: `执行失败: ${result.error.message}` };
      }
      if (result.status !== 0) {
        const stderr = result.stderr?.trim() || result.stdout?.trim() || '未知错误';
        return { success: false, message: stderr.slice(0, 500) };
      }
      bumpSkillCatalogVersion();
      return { success: true, message: `技能 ${skillName} 已卸载` };
    },
    async createTaskWithFiles(input: {
      prompt: string;
      filePaths: string[];
      context?: TaskCreateContext;
    }, nativeActor?: NativeActor): Promise<{ taskId: string; understanding?: TaskUnderstanding }> {
      const nativeSelected=codexTasks.selected();
      if(nativeSelected) codexTasks.authorize(nativeActor);
      return afterLocalRecovery(async () => {
        const context = nativeSelected ? input.context : localChatContext(input.context);
        const permissionRevision = !nativeSelected && context?.threadId ? multiAgentService?.assertExecutionAdmission(context.threadId) : undefined;
        mkdirSync(options.dataRoot, { recursive: true });
        const taskId = `task_${Date.now().toString(36)}`;
        const materials: Array<{ materialId: string; role?: MaterialRole }> = [];
        for (const filePath of input.filePaths) {
          try {
            const record = await materialRegistry.importMaterial({
              taskId,
              sourcePath: filePath,
              role: 'customer_material',
              roleSource: 'user',
            });
            materials.push({ materialId: record.materialId, role: record.role });
          } catch (e) {
          }
          // Import failures keep their original skip behavior, but neither a
          // success nor a failure may advance an old submission after revoke.
          if (!nativeSelected && context?.threadId) multiAgentService?.assertExecutionAdmission(context.threadId, permissionRevision);
        }
        if (!nativeSelected && context?.threadId) multiAgentService?.assertExecutionAdmission(context.threadId, permissionRevision);
        return nativeSelected ? codexTasks.create({ prompt: input.prompt, materials, context },nativeActor)
          : conversationRooms.withUserRequest({prompt:input.prompt},{requestSource:'user'},()=>conversationProjects.withUserRequest({ prompt: input.prompt, threadId: context?.threadId }, { requestSource: 'user' },
            () => goalCoordinator.admitUserTask({ prompt: input.prompt, materials, context })));
      });
    },
    async getModelConfig() {
      return modelSnapshot(await loadConfig());
    },
    async saveModelConfig(input: DesktopSaveModelConfigInput, nativeActor?: NativeActor, requestSource?: 'user' | 'agent' | 'scheduler') {
      if (requestSource !== 'user') throw new Error('model_config_user_required');
      input = captureModelProviderInput(input, SAVE_MODEL_CONFIG_SCHEMA);
      if(input.modelId===LOCAL_CODEX_MODEL){
        if(nativeActor?.requestSource!=='user'||nativeActor.actorId!==`desktop-user:${multiAgentProfileId}`)throw new Error('native_access_denied');
        codexTasks.select(true);return modelSnapshot(await loadConfig());
      }
      const config = await loadConfig();
      const providerId = normalizeProviderId(input.providerId);
      const existingModel = input.modelId ? config.models[input.modelId] : undefined;
      const hasProviderPatch = input.apiKey !== undefined || input.baseUrl !== undefined || input.protocol !== undefined;
      if (!existingModel || !config.providers[existingModel.provider] || hasProviderPatch) {
        ensureProvider(config, providerId, input);
      }

      if (input.modelId && config.models[input.modelId]) {
        config.defaultModelId = input.modelId;
        config.defaultProvider = config.models[input.modelId].provider;
      } else if (input.modelName?.trim()) {
        const modelName = input.modelName.trim();
        const modelId = `${providerId}-${sanitizeModelIdPart(modelName)}`;
        const catalogModel = findApplicableCatalogModel(config, providerId, modelId, modelName);
        config.models[modelId] = {
          provider: providerId,
          model: modelName,
          label: input.label?.trim() || modelName,
          capabilities: cloneStrings(
            catalogModel?.capabilities ?? getProviderProfile(providerId)?.defaultModel.capabilities,
          ),
          ...(catalogModel?.runtimeOptions
            ? { runtimeOptions: cloneRuntimeOptions(catalogModel.runtimeOptions) }
            : {}),
        };
        config.defaultProvider = providerId;
        config.defaultModelId = modelId;
      } else {
        const modelId = ensureDefaultModel(config, providerId);
        config.defaultProvider = providerId;
        config.defaultModelId = modelId;
      }

      const selectedModel = config.models[config.defaultModelId];
      if (selectedModel) {
        const metadata = resolveDesktopModelRuntimeMetadata(config, config.defaultModelId, selectedModel);
        const effort = metadata.runtimeOptions?.reasoningEffort;
        if (effort) selectedModel.runtimeOptions = { ...selectedModel.runtimeOptions, reasoningEffort: effort };
        else if (selectedModel.runtimeOptions) {
          const { reasoningEffort: _effort, ...otherOptions } = selectedModel.runtimeOptions;
          selectedModel.runtimeOptions = otherOptions;
        }
      }
      await saveConfig(config);
      codexTasks.select(false);return modelSnapshot(config);
    },
    async updateModelRuntimeOptions(input: DesktopUpdateModelRuntimeOptionsInput, requestSource?: 'user' | 'agent' | 'scheduler') {
      if (requestSource !== 'user') throw new Error('model_config_user_required');
      input = captureModelProviderInput(input, UPDATE_MODEL_RUNTIME_SCHEMA);
      const config = await loadConfig();
      const model = config.models[input.modelId];
      if (!model) {
        throw new Error(`Model not found: ${input.modelId}`);
      }

      const provider = config.providers[model.provider];
      const catalogModel = findApplicableCatalogModel(
        config,
        model.provider,
        input.modelId,
        model.model,
      );
      if (
        provider?.protocol !== 'openai_legacy'
        || !getSupportedModelReasoningEfforts({ providerId: model.provider, providerType: provider.type, protocol: provider.protocol, wireModel: model.model, baseUrl: resolveProviderTransport(config, model.provider).baseUrl }).length
      ) {
        throw new Error('Runtime options can only be updated for a catalog-supported model such as Kimi K3.');
      }
      if (!input.runtimeOptions || typeof input.runtimeOptions !== 'object') {
        throw new Error('runtimeOptions are required.');
      }

      const runtimeOptions = { ...model.runtimeOptions, ...sanitizeDesktopModelRuntimeOptions(input.runtimeOptions) };

      resolveModelRuntimeOptions({
        protocol: provider.protocol,
        baseUrl: resolveProviderTransport(config, model.provider).baseUrl,
        wireModel: model.model,
        catalogOptions: catalogModel?.runtimeOptions,
        catalogConstraints: catalogModel?.runtimeConstraints,
        configuredOptions: runtimeOptions,
        reasoningEfforts: getSupportedModelReasoningEfforts({ providerId: model.provider, providerType: provider.type, protocol: provider.protocol, wireModel: model.model, baseUrl: resolveProviderTransport(config, model.provider).baseUrl }),
      });

      model.runtimeOptions = runtimeOptions;
      await saveConfig(config);
      return createModelConfigSnapshot(config);
    },
    async getSystemOneConfig(): Promise<DesktopSystemOneConfigSnapshot> {
      return systemOneSnapshot(await loadConfig());
    },
    async saveSystemOneConfig(input: DesktopSaveSystemOneConfigInput | undefined, requestSource?: 'user' | 'agent' | 'scheduler'): Promise<DesktopSystemOneConfigSnapshot> {
      if (requestSource !== 'user') throw new Error('model_config_user_required');
      input = captureModelProviderInput(input, SYSTEM_ONE_PATCH_SCHEMA.optional());
      const config = await loadConfig();
      setSystemOneConfig(config, sanitizeSystemOnePatch(input));
      await saveConfig(config);
      return systemOneSnapshot(config);
    },
    async createManagedXiaokAgent(input: {
      id?: string;
      name: string;
      description?: string;
      roles?: string[];
      capabilities?: string[];
      instructions?: string;
      maxConcurrentTasks?: number;
      desktopModelId?: string | null;
    }, context?: { requestSource: 'user' | 'agent' | 'scheduler' }) {
      if (context?.requestSource !== 'user') throw new Error('model_config_user_required');
      input = captureModelProviderInput(input, MANAGED_AGENT_INPUT_SCHEMA);
      const config = await loadConfig();
      if (input.desktopModelId !== undefined) validateProjectAgentModelSelection(input.desktopModelId, 'xiaok', config, context?.requestSource);
      const payload = buildManagedXiaokAgentPayload(input, config);
      const semanticPayload = buildManagedXiaokAgentSemanticPayload(payload);
      return requestKSwarmJson(options.kswarmService, '/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-kswarm-mutation-token': options.kswarmService.getDesktopMutationToken() },
        body: JSON.stringify(semanticPayload),
      });
    },
    async getSkillDebugConfig() {
      const config = await loadConfig();
      return { enabled: config.skillDebug ?? false };
    },
    async saveSkillDebugConfig(input: { enabled: boolean }, requestSource: 'user' | 'agent' | 'scheduler') {
      if (requestSource !== 'user') throw new Error('desktop_config_request_source_forbidden');
      const captured = captureIpcData(input, 'desktop_config_input_invalid');
      if (!SKILL_DEBUG_CONFIG_SCHEMA.safeParse(captured).success) throw new Error('desktop_config_input_invalid');
      const config = await loadConfig();
      config.skillDebug = captured.enabled;
      await saveConfig(config);
      return { enabled: config.skillDebug };
    },
    async getKswarmConfig() {
      const config = await loadConfig();
      return { maxConcurrentTasks: config.kswarm?.maxConcurrentTasks ?? 3 };
    },
    async saveKswarmConfig(input: { maxConcurrentTasks: number }, requestSource: 'user' | 'agent' | 'scheduler') {
      if (requestSource !== 'user') throw new Error('desktop_config_request_source_forbidden');
      const captured = captureIpcData(input, 'desktop_config_input_invalid');
      if (!KSWARM_CONCURRENCY_CONFIG_SCHEMA.safeParse(captured).success) throw new Error('desktop_config_input_invalid');
      const config = await loadConfig();
      const clamped = Math.max(1, Math.min(10, Math.round(captured.maxConcurrentTasks)));
      config.kswarm = { ...(config.kswarm || {}), maxConcurrentTasks: clamped };
      await saveConfig(config);
      return { maxConcurrentTasks: clamped };
    },
    async getSkillStats(): Promise<SkillStats[]> {
      const records = await loadExecRecords(options.dataRoot);
      return aggregateStats(records);
    },
    async testProviderConnection(input: { providerId: string; modelId?: string }, requestSource?: 'user' | 'agent' | 'scheduler'): Promise<{ success: boolean; latencyMs?: number; error?: string }> {
      if (requestSource !== 'user') throw new Error('model_config_user_required');
      input = captureModelProviderInput(input, PROVIDER_CONNECTION_INPUT_SCHEMA);
      const config = await loadConfig();
      const providerId = normalizeProviderId(input.providerId);
      const provider = config.providers[providerId];
      if (!provider?.apiKey) {
        return { success: false, error: 'API key not configured' };
      }
      try {
        const modelId = resolveProviderConnectionModelId(config, providerId, input.modelId);
        if (!modelId) {
          throw new Error(`No configured model found for provider ${providerId}`);
        }
        const binding = resolveRuntimeModelBinding(config, modelId);
        if (binding.providerId !== providerId) {
          throw new Error(`Model ${binding.modelId} does not belong to provider ${providerId}`);
        }
        const adapter = createAdapterFromBinding(binding);
        const start = Date.now();
        const testMessages: Message[] = [{ role: 'user', content: [{ type: 'text', text: 'ping' }] }];
        const systemPrompt = 'Reply with "ok" to verify connection.';
        const controller = new AbortController();
        const timeout = setTimeout(() => {
          controller.abort(new DOMException('provider connection timeout', 'TimeoutError'));
        }, 30_000);
        let sawProtocolResponse = false;
        try {
          for await (const chunk of streamStatelessSideCallProviderConversation({
            adapter,
            messages: testMessages,
            tools: [],
            systemPrompt,
            options: { signal: controller.signal },
            invocationId: `inv_${randomUUID()}`,
          })) {
            if (chunk.type === 'usage') {
              continue;
            }
            sawProtocolResponse = true;
          }
          if (controller.signal.aborted) {
            throw controller.signal.reason;
          }
          if (!sawProtocolResponse) {
            throw new Error('provider_connection_empty_stream');
          }
        } finally {
          clearTimeout(timeout);
        }
        return { success: true, latencyMs: Date.now() - start };
      } catch (e) {
        return { success: false, error: (e as Error).message };
      }
    },
    async listAvailableModelsForProvider(providerId: string) {
      const profile = getProviderProfile(providerId);
      if (profile?.availableModels) {
        return profile.availableModels.map(m => ({
          modelId: m.modelId,
          model: m.model,
          label: m.label,
          capabilities: cloneStrings(m.capabilities),
          ...(m.runtimeOptions ? { runtimeOptions: cloneRuntimeOptions(m.runtimeOptions) } : {}),
          ...(m.runtimeConstraints
            ? { runtimeConstraints: cloneRuntimeConstraints(m.runtimeConstraints) }
            : {}),
        }));
      }
      return [];
    },
    async deleteProvider(providerId: string, context?: { requestSource: 'user' | 'agent' | 'scheduler' }): Promise<void> {
      if (context?.requestSource !== 'user') throw new Error('model_config_user_required');
      providerId = captureModelProviderInput(providerId, MODEL_PROVIDER_ID_SCHEMA);
      const config = await loadConfig();
      delete config.providers[providerId];
      for (const [modelId, model] of Object.entries(config.models)) {
        if (model.provider === providerId) delete config.models[modelId];
      }
      repairModelConfigDefault(config);
      await saveConfig(config);
    },
    async deleteModel(modelId: string, context?: { requestSource: 'user' | 'agent' | 'scheduler' }): Promise<void> {
      if (context?.requestSource !== 'user') throw new Error('model_config_user_required');
      modelId = captureModelProviderInput(modelId, MODEL_PROVIDER_ID_SCHEMA);
      const config = await loadConfig();
      delete config.models[modelId];
      repairModelConfigDefault(config);
      await saveConfig(config);
    },
    /** Main-private entry requires one consumed native-confirmation capability. */
    async createObservationTask(input: Pick<TaskCreateInput, 'prompt' | 'materials' | 'permissionMode'> & {threadId?:string},
      authority: {requestSource:'user';approval:ApprovedDesktopObservation;onPrompt: import('../../src/ai/tools/index.js').RegistryOptions['onPrompt'];authorizeValidationMaterials?:Parameters<typeof import('../../src/runtime/sol-pi/product-validation-backend.js').createProductValidationBackend>[0]['authorize']}): Promise<{taskId:string;control:object}> {
      if (authority?.requestSource !== 'user') throw new Error('observation_user_required');
      const policy = consumeDesktopObservationApproval(authority.approval);
      if (observationAdmissionBusy) throw new Error('SOL_PI_DESKTOP_PROFILE_BUSY');
      observationAdmissionBusy = true;
      try {
        for(const [previousTaskId,entry]of observationTasks){
          if(entry.live)throw new Error('SOL_PI_DESKTOP_PROFILE_BUSY');
          if(!entry.consumed){const previous=await snapshotStore.recoverTask(previousTaskId);if(previous&&!['completed','failed','cancelled'].includes(previous.status))throw new Error('SOL_PI_DESKTOP_PROFILE_BUSY');entry.consumed=true;}
        }
        await observationLifecycleReady;await multiAgentReady;
        const threadId=input.threadId??`local_${randomUUID()}`;
        await multiAgentService?.registerThreadWithOwnership({threadId,profileId:multiAgentProfileId,workspaceId:multiAgentWorkspaceId,cwd:multiAgentCwd},'user');
        const revision=multiAgentService?.assertExecutionAdmission(threadId);
        const taskInput={ prompt: input.prompt, materials: input.materials, permissionMode: input.permissionMode ?? 'default',context:{threadId} };
        const children=(await import('../../src/runtime/sol-pi/product-bootstrap.js')).describeProductObservationPolicy(policy).ordinaryChildren;
        if(children&&!multiAgentService)throw Error('SOL_PI_DESKTOP_GROUP_RUNTIME_REQUIRED');
        const prepared = children ? await multiAgentService!.prepareRoot(host,threadId,taskInput) : await host.prepareTask(taskInput);
        multiAgentService?.assertExecutionAdmission(threadId,revision);
        observationTasks.set(prepared.taskId, { policy, onPrompt: authority.onPrompt, authorizeValidationMaterials:authority.authorizeValidationMaterials, consumed: false,
          profileRoot: getConfigDir('observation-profile'), environmentRoot: join(homedir(), '.cache','xiaok','sol-pi','deepseek-recipe-0.1.1') });
        try { const control=Object.freeze(Object.create(null)); observationTaskControls.set(prepared.taskId,control); await host.startTask(prepared.taskId); return {taskId:prepared.taskId,control}; }
        catch (error) { observationTasks.delete(prepared.taskId); observationTaskControls.delete(prepared.taskId); throw error; }
      } finally { observationAdmissionBusy = false; }
    },
    observationTaskDiagnostics(taskId:string) {const entry=observationTasks.get(taskId);return entry?.live?.diagnostics()??entry?.diagnostics;},
    async observationTaskStatus(taskId: string) {
      const entry = observationTasks.get(taskId);
      if(!entry){const snapshot=await snapshotStore.recoverTask(taskId);return snapshot?.protectedObservationClosure||snapshot?.executionProtected?'restore-blocked':'unavailable';}
      if(entry.revoked)return 'revoked';
      if(entry.live)return entry.live.getMode();
      const snapshot=await snapshotStore.recoverTask(taskId);return snapshot&&['completed','failed','cancelled'].includes(snapshot.status)?'closed':'starting';
    },
    stopObservationTask(taskId: string, context: {requestSource:'user';control:object}) { if(context?.requestSource!=='user'||observationTaskControls.get(taskId)!==context.control)throw new Error('observation_task_owner_required'); const live = observationTasks.get(taskId)?.live; if (!live) throw new Error('SOL_PI_DESKTOP_OBSERVATION_NOT_ACTIVE'); live.stopNewCapture(); },
    async revokeObservationTask(taskId: string, context: {requestSource:'user';control:object}) { if(context?.requestSource!=='user'||observationTaskControls.get(taskId)!==context.control)throw new Error('observation_task_owner_required'); const entry=observationTasks.get(taskId); if(!entry)throw new Error('SOL_PI_DESKTOP_OBSERVATION_NOT_ACTIVE'); entry.consumed=true; entry.revoked=true; entry.live?.revoke(); await host.cancelTask(taskId, 'observation_permission_revoked'); },
    createTask: (input: Parameters<typeof host.createTask>[0], nativeActor?: NativeActor) => {
      if(codexTasks.selected()) return codexTasks.create(input,nativeActor);
      return conversationRooms.withUserRequest({prompt:input.prompt,permissionMode:input.permissionMode},{requestSource:'user'},()=>conversationProjects.withUserRequest({ prompt: input.prompt, permissionMode: input.permissionMode, threadId: input.context?.threadId }, { requestSource: 'user' },
        () => afterLocalRecovery(() => goalCoordinator.admitUserTask(multiAgentService ? { ...input, context: localChatContext(input.context) } : input))));
    },
    /** Main-only binding; never exposed through preload or a model tool. */
    bindConversationRoomCreator: (creator: (input:Record<string,unknown>,context:{requestSource:'user';signal?:AbortSignal})=>Promise<unknown>) => conversationRooms.bindCreator(creator),
    bindConversationProjectRoomClient: (client: ConversationProjectRoomClient) => {
      activityRoomClient = client; conversationProjects.bindRoomClient(client);
      void multiAgentReady.then(async () => { await conversationProjects.recoverActivityBindings(); for (const watch of activityStore?.listWatches() ?? []) await activitySources?.startWatch(watch.watchId); }).catch(error => console.warn('[conversation-activity] restore failed:', error));
    },
    async attachConversationActivityOwner(sourceConfig: Pick<ActivityOwnerConfig, 'kswarm' | 'managedSources'>) {
      if (!activityEnabled || !multiAgentStore) return;
      if (activityAttachment) return activityAttachment;
      activityAttachment = (async () => {
        await multiAgentReady;
        // Stop all in-process writers and source owners before acquiring the
        // daemon lock. Native executors keep their original ownership.
        activityMcp?.dispose(); activitySources?.dispose(); activityService?.dispose(); activityStore?.close();
        activityStore = undefined;
        const client = await ensureConversationActivityOwner({ schemaVersion: 1, dataRoot: options.dataRoot,
          profileId: multiAgentProfileId, actorId: `desktop-user:${multiAgentProfileId}`,
          identity: { kind: 'desktop', path: join(options.dataRoot, 'multi-agent', 'groups.sqlite') }, ...sourceConfig });
        options.kswarmService.bindActivityOwner?.(client);
        activityStore = new ConversationActivityStore(join(options.dataRoot, 'conversation-activity.sqlite'), { readOnly: true });
        activityService = new ConversationActivityAttachedService(client, `desktop-user:${multiAgentProfileId}`);
        activitySources = new ConversationActivityAttachedSources(client);
        activityMcp = new ConversationMcpActivities({ store: activityStore, service: activityService, actorId: `desktop-user:${multiAgentProfileId}`,
          externalObserver: connection => connection.activityEndpoint?.config.type !== 'stdio',
          endpointReady: async connection => {
            const endpoint = connection.activityEndpoint;
            if (!endpoint || !connection.tasks) throw new Error('activity_mcp_endpoint_unverified');
            await client.request('mcpRegister', { endpointId: connection.tasks.endpointId, name: endpoint.name,
              ...(endpoint.config.type !== 'stdio' ? { config: endpoint.config, ...(endpoint.cwd ? { cwd: endpoint.cwd } : {}) } : {}) });
          },
          originThread: async taskId => {
            const parent = activityStore!.listWatches().find(watch => watch.source === 'task_host' && watch.workId === taskId);
            return parent?.origin.threadId ?? (await host.inspectTask(taskId))?.context?.threadId ?? null;
          }, onError: error => console.warn('[conversation-activity-mcp]', error instanceof Error ? error.message : 'activity_mcp_unavailable') });
        for (const connection of activityMcpConnections) activityMcp.register(connection);
        installActivityGroupSubscription();
      })();
      return activityAttachment;
    },
    conversationActivity: activityEnabled && multiAgentStore ? {
      mcpInputs: async (watchId: string, actor: ActivityActor) => { await activityService!.getWork(watchId, actor); if (!activityMcp) throw new Error('activity_mcp_unavailable'); return activityService instanceof ConversationActivityAttachedService && ![...activityMcpConnections].some(connection => connection.tasks?.endpointId === activityStore?.getWatch(watchId)?.logicalSourceId && connection.activityEndpoint?.config.type === 'stdio') ? activityService.client.request('mcpInputs', { watchId }) : activityMcp.inputs(watchId, actor); },
      mcpAnswer: async (watchId: string, input: Parameters<ConversationMcpActivities['answerInput']>[1], actor: ActivityActor) => { await activityAttachment; await activityService!.getWork(watchId, actor); if (!activityMcp) throw new Error('activity_mcp_unavailable'); return activityService instanceof ConversationActivityAttachedService && ![...activityMcpConnections].some(connection => connection.tasks?.endpointId === activityStore?.getWatch(watchId)?.logicalSourceId && connection.activityEndpoint?.config.type === 'stdio') ? activityService.client.request<void>('mcpAnswer', { watchId, input }) : activityMcp.answerInput(watchId, input, actor); },
      mcpCancel: async (watchId: string, actor: ActivityActor) => { await activityAttachment; await activityService!.getWork(watchId, actor); if (!activityMcp) throw new Error('activity_mcp_unavailable'); return activityService instanceof ConversationActivityAttachedService && ![...activityMcpConnections].some(connection => connection.tasks?.endpointId === activityStore?.getWatch(watchId)?.logicalSourceId && connection.activityEndpoint?.config.type === 'stdio') ? activityService.client.request<{ requested: true }>('mcpCancel', { watchId }) : activityMcp.cancel(watchId, actor); },
      unread: (actor: ActivityActor) => activityService!.unreadThreads(actor),
      read: (threadId: string, through: number, actor: ActivityActor) => activityService!.markRead(threadId, through, actor),
      overview: (actor: ActivityActor, callback: Parameters<ConversationActivityService['subscribeOverview']>[1]) => activityService!.subscribeOverview(actor, callback),
      getWork: (watchId: string, actor: ActivityActor) => activityService!.getWork(watchId, actor),
      list: async (threadId: string, actor: ActivityActor, page?: { afterLocalSeq?: number; limit?: number }) => { await activityAttachment; await prepareActivityViewerThread(threadId, actor); return activityService!.listActivities(threadId, actor, page); },
      subscribe: async (threadId: string, actor: ActivityActor, callback: Parameters<ConversationActivityService['subscribe']>[2]) => { await activityAttachment; await prepareActivityViewerThread(threadId, actor); return activityService!.subscribe(threadId, actor, callback); },
      reporting: (watchId: string, preference: ReportingPreference, revision: number, actor: ActivityActor) => activityService!.updateReporting(watchId, preference, revision, actor),
      stop: async (watchId: string, revision: number, actor: ActivityActor) => { const result = await activityService!.stopWatch(watchId, revision, actor); activitySources?.stopWatch(watchId); activityMcp?.stopWatch(watchId); return result; },
      projectChanged: (projectId: string) => activitySources!.refreshProject(projectId, true),
      projectConnectionChanged: (status: 'connected' | 'disconnected' | 'reconnecting') => activitySources!.projectConnectionChanged(status),
    } : null,
    /** Main-only scheduler/loop entry. A fresh thread cannot attach to an armed user Goal. */
    // Main composition only; never exported through preload or an agent tool.
    captureLoopPublicationAdmission: () => goalCoordinator.captureBackgroundAdmission(),
    reserveBackgroundTask:backgroundTaskIdentity.reserve,
    createReservedBackgroundTask:backgroundTaskIdentity.create,
    discardReservedBackgroundTask:backgroundTaskIdentity.discard,
    createBackgroundTask: (input: Pick<TaskCreateInput, 'prompt' | 'materials' | 'permissionMode' | 'watchdogMs' | 'maxToolLoopIterations'> & {
      scheduledOrigin?: { actionId: string; runId: string; createdByTaskId?: string };
    }) => withExecutionLane('background', () => afterLocalRecovery(async () => {
      const origin = input.scheduledOrigin;
      const creator = origin?.createdByTaskId ? await snapshotStore.recoverTask(origin.createdByTaskId) : null;
      const threadId = creator?.context?.threadId;
      const binding = threadId ? multiAgentStore?.getThread(threadId) : null;
      const operationId = origin ? `scheduled:${origin.actionId}:${origin.runId}` : undefined;
      if (activityService && operationId && threadId && binding?.profileId === multiAgentProfileId && (binding.deleteState ?? 'none') === 'none') {
        await activityService.prepareAssociation({ threadId, operationId, creationIdempotencyKey: operationId },
          { requestSource: 'user', actorId: `desktop-user:${multiAgentProfileId}` });
      }
      const task = await goalCoordinator.admitUserTask({
        prompt: input.prompt, materials: input.materials, permissionMode: input.permissionMode,
        watchdogMs: input.watchdogMs, maxToolLoopIterations: input.maxToolLoopIterations,
        context: localChatContext(),
      });
      if (activityService && activitySources && activityStore?.getAssociation(operationId ?? '')) {
        const snapshot = await snapshotStore.recoverTask(task.taskId);
        if (snapshot) {
          const watchId = `task:${task.taskId}`;
          await activityService.bindWork({ operationId: operationId!, watchId, source: 'task_host', logicalSourceId: 'task-host-local',
            sourceDataEpoch: snapshot.sessionId, workId: task.taskId, runId: origin!.runId, actualExecutionThreadId: snapshot.context?.threadId });
          await activitySources.startWatch(watchId);
        }
      }
      return task;
    })),
    getGoal: (threadId: string) => goalCoordinator.getGoal(threadId),
    getGoalNativeMutation: (threadId: string) => goalCoordinator.getGoalNativeMutation(threadId),
    recoverGoalNativeMutation: (input: { threadId: string; requestSource: 'user' | 'agent' | 'scheduler' }) => {
      if (input.requestSource !== 'user') throw Error('goal_native_mutation_source');
      return afterLocalRecovery(() => goalCoordinator.recoverGoalNativeMutation(input));
    },
    continueGoalNativeMutation: (input: { threadId: string; requestSource: 'user' | 'agent' | 'scheduler'; requestId?: string }) => {
      if (input.requestSource !== 'user') throw Error('goal_native_mutation_source');
      return afterLocalRecovery(() => goalCoordinator.continueGoalNativeMutation(input));
    },
    cancelGoalNativeMutation: (input: { threadId: string; requestSource: 'user' | 'agent' | 'scheduler' }) => {
      if (input.requestSource !== 'user') throw Error('goal_native_mutation_source');
      return afterLocalRecovery(() => goalCoordinator.cancelGoalNativeMutation(input));
    },
    createGoal: (input: { threadId: string } & GoalCreationInput & GoalAttachmentRequest) => {
      const requestId = parseGoalRequestId(input.requestId);
      return afterLocalRecovery(() => goalCoordinator.createGoal({ ...input, requestId }));
    },
    pauseGoal: (threadId: string) => goalCoordinator.pauseGoal({ threadId }),
    resumeGoal: (input: { threadId: string; turnLimit?: number } & GoalAttachmentRequest) => {
      const requestId = parseGoalRequestId(input.requestId);
      return afterLocalRecovery(() => goalCoordinator.resumeGoal({ ...input, requestId }));
    },
    recoverGoalPublication: (input: { threadId: string; requestSource: 'user' | 'agent' | 'scheduler' }) => {
      if (input.requestSource !== 'user') throw Error('goal_publication_source');
      return afterLocalRecovery(() => goalCoordinator.recoverGoalPublication({ threadId: input.threadId, requestSource: 'user' }));
    },
    continueGoalPublication: (input: { threadId: string; requestSource: 'user' | 'agent' | 'scheduler' }) => {
      if (input.requestSource !== 'user') throw Error('goal_publication_source');
      return afterLocalRecovery(() => goalCoordinator.continueGoalPublication({ threadId: input.threadId, requestSource: 'user' }));
    },
    cancelGoal: (threadId: string) => goalCoordinator.cancelGoal({ threadId }),
    replaceGoal: (input: { threadId: string } & GoalCreationInput & GoalAttachmentRequest) => {
      const requestId = parseGoalRequestId(input.requestId);
      return afterLocalRecovery(() => goalCoordinator.replaceGoal({ ...input, requestId }));
    },
    ackGoalTaskAttached: (input: { threadId: string; attachmentId: string }) => (
      afterLocalRecovery(() => goalCoordinator.ackGoalTaskAttached(input))
    ),
    setGoalUserQueuePending: (input: { threadId: string; pending: boolean }) => (
      goalCoordinator.setUserQueuePending(input)
    ),
    subscribeGoalChanged(listener: (input: { threadId: string; goal: DesktopGoalProjection }) => void) {
      goalChangedListeners.add(listener);
      return () => goalChangedListeners.delete(listener);
    },
    subscribeGoalTaskPrepared(listener: (input: PreparedGoalTask) => void) {
      goalTaskPreparedListeners.add(listener);
      return () => goalTaskPreparedListeners.delete(listener);
    },
    runKSwarmHandoffTask,
    runWorkspaceProjectTask,
    runCollaborationRoomAgentTask,
    runKSwarmWorkflowNode,
    runKSwarmReadinessProbe,
    runKSwarmAssignPo,
    runKSwarmReviewSubmission,
    runKSwarmPlanApproved,
    authorizeTaskRead: authorizeLocalTaskActor,
    subscribeTask: (taskId:string,sinceIndex?:{ sinceIndex?: number; signal?: AbortSignal }) => (codexTasks.owns(taskId)?codexTasks.host:resolveScopedTaskHost(taskId, host)).subscribeTask(taskId,sinceIndex),
    answerQuestion: async (input: Parameters<typeof host.answerQuestion>[0], nativeActor?:NativeActor) => {
      if (codexTasks.owns(input.taskId)) return codexTasks.answer(input, nativeActor);
      if (nativeActor) await authorizeLocalTaskActor(input.taskId, nativeActor);
      return resolveScopedTaskHost(input.taskId, host).answerQuestion(input);
    },
    cancelTask: async (taskId:string, reasonOrActor?:string|NativeActor) => {
      if (codexTasks.owns(taskId)) return codexTasks.cancel(taskId, typeof reasonOrActor === 'string' ? undefined : reasonOrActor);
      if (reasonOrActor && typeof reasonOrActor !== 'string') await authorizeLocalTaskActor(taskId, reasonOrActor);
      return resolveScopedTaskHost(taskId, host).cancelTask(taskId, typeof reasonOrActor === 'string' ? reasonOrActor : undefined);
    },
    async getActiveTask(): Promise<{ taskId: string } | null> {
      for (const ref of await host.getActiveTasks()) {
        if (!codexTasks.owns(ref.taskId) && resolveScopedTaskHost(ref.taskId, host) !== host) continue;
        const snapshot = (await (codexTasks.owns(ref.taskId)?codexTasks.host:resolveScopedTaskHost(ref.taskId, host)).recoverTask(ref.taskId)).snapshot;
        if (snapshot.executionScope?.kind === 'goal_turn') {
          const binding = goalStore.getTaskBinding(ref.taskId);
          if (snapshot.executionScope.origin === 'continuation' || binding?.attachedAt === null) continue;
        }
        return ref;
      }
      return null;
    },
    async recoverTask(taskId: string, legacyPrompt?: string): Promise<{ snapshot: TaskSnapshot; recoveredFromTaskId?: string }> {
      try { return await (codexTasks.owns(taskId) ? codexTasks.host.recoverTask(taskId) : recoverTaskWithWorkflowArtifacts(taskId)); }
      catch (error) {
        // Only a physically missing legacy task may use this read-only fallback.
        // Existing-but-unreadable/protected tasks retain their original error.
        if (!legacyPrompt || existsSync(join(options.dataRoot, 'tasks', 'snapshots', `${taskId}.json`))) throw error;
        const snapshot = await findLegacyTaskHistory({ root: join(options.dataRoot, 'tasks'), prompt: legacyPrompt,
          read: id => snapshotStore.recoverTask(id) });
        if (!snapshot) throw error;
        return { snapshot, recoveredFromTaskId: snapshot.taskId };
      }
    },
    async recoverStaleTasks(): Promise<void> {
      await multiAgentReady;
      const active = await host.getActiveTasks();
      for (const ref of active) {
        try {
          const snapshot = await snapshotStore.recoverTask(ref.taskId);
          if (snapshot?.executionScope?.kind === 'artifact_workspace_generation') {
            // Workspace reconciliation owns these tasks. The generic stale-task
            // path would collapse recoverable generation state into failure.
            continue;
          }
          await (codexTasks.owns(ref.taskId)?codexTasks.host:resolveScopedTaskHost(ref.taskId, host)).recoverTask(ref.taskId);
        } catch {
          // Per-task recovery failure must not block desktop startup.
        }
      }
      try {
        await recoverInterruptedScriptWorkflows(options.kswarmService);
      } catch {
        // Dynamic workflow recovery is best-effort; never block desktop startup.
      }
    },
    async openArtifact(_artifactId: string): Promise<void> {
      // Artifact opening stays behind the semantic API even before rich preview exists.
    },

    subscribeArtifactWorkspaceChanges(listener: Parameters<ArtifactWorkspaceService['subscribeChanges']>[0]) {
      return workspaceService.subscribeChanges(listener);
    },

    async getArtifactWorkspaceSnapshot(input: Record<string, unknown>, viewKey = 'primary') {
      const identity = input as unknown as Parameters<ArtifactWorkspaceService['getArtifactWorkspaceSnapshot']>[0];
      const selected = input.selectedArtifact;
      if (selected && typeof selected === 'object' && !Array.isArray(selected)) {
        const artifact = selected as Record<string, unknown>;
        if (typeof artifact.sourceTaskId === 'string' && typeof artifact.artifactId === 'string') {
          await workspaceService.recordEligibleArtifactOpened({
            conversationId: identity.conversationId,
            workspaceRootId: identity.workspaceRootId,
            sourceTaskId: artifact.sourceTaskId,
            artifactId: artifact.artifactId,
          });
        }
      }
      return workspaceService.getArtifactWorkspaceSnapshot({ ...identity, viewKey });
    },
    async closeArtifactWorkspace(input: Record<string, unknown>, viewKey = 'primary') {
      const identity = input as unknown as Parameters<ArtifactWorkspaceService['closeArtifactWorkspace']>[0];
      return { closed: workspaceService.closeArtifactWorkspace({ ...identity, viewKey }) };
    },
    closeArtifactWorkspaceViewKey(viewKey: string) {
      return workspaceService.closeArtifactWorkspaceViewKey(viewKey);
    },
    async readArtifactWorkspaceVersionPreview(input: Record<string, unknown>) {
      return workspaceService.readArtifactWorkspaceVersionPreview(
        input as unknown as Parameters<ArtifactWorkspaceService['readArtifactWorkspaceVersionPreview']>[0],
      );
    },
    async exportArtifactWorkspaceVersion(input: Record<string, unknown>) {
      return workspaceService.exportArtifactWorkspaceVersion(
        input as unknown as Parameters<ArtifactWorkspaceService['exportArtifactWorkspaceVersion']>[0],
      );
    },
    async createArtifactPlaceholder(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['createArtifactPlaceholder']>[0];
      await runArtifactWorkspaceUserMutation('create_placeholder', mutation, () => workspaceService.createArtifactPlaceholder(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async submitArtifactGeneration(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['submitArtifactGeneration']>[0];
      await runArtifactWorkspaceUserMutation('submit_generation', mutation, () => workspaceService.submitArtifactGeneration(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async cancelArtifactGeneration(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['cancelArtifactGeneration']>[0];
      await runArtifactWorkspaceUserMutation('cancel_generation', mutation, () => workspaceService.cancelArtifactGeneration(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({
        conversationId: String(input.conversationId),
        workspaceRootId: String(input.workspaceRootId),
        viewKey,
      });
    },
    async retryArtifactGeneration(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['retryArtifactGeneration']>[0];
      await runArtifactWorkspaceUserMutation('retry_generation', mutation, () => workspaceService.retryArtifactGeneration(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async preferArtifactVersion(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['preferArtifactVersion']>[0];
      await runArtifactWorkspaceUserMutation('prefer_version', mutation, () => workspaceService.preferArtifactVersion(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async removeArtifactWorkspaceNode(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['removeArtifactWorkspaceNode']>[0];
      await runArtifactWorkspaceUserMutation('remove_node', mutation, () => workspaceService.removeArtifactWorkspaceNode(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async updateArtifactWorkspaceLayout(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['updateArtifactWorkspaceLayout']>[0];
      await runArtifactWorkspaceUserMutation('update_layout', mutation, () => workspaceService.updateArtifactWorkspaceLayout(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async saveArtifactWorkspaceViewport(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user', viewKey } as unknown as Parameters<ArtifactWorkspaceService['saveArtifactWorkspaceViewport']>[0];
      await runArtifactWorkspaceUserMutation('save_viewport', mutation, () => workspaceService.saveArtifactWorkspaceViewport(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async createArtifactWorkspaceCollection(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['createArtifactWorkspaceCollection']>[0];
      await runArtifactWorkspaceUserMutation('create_collection', mutation, () => workspaceService.createArtifactWorkspaceCollection(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async createArtifactWorkspaceNote(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['createArtifactWorkspaceNote']>[0];
      await runArtifactWorkspaceUserMutation('create_note', mutation, () => workspaceService.createArtifactWorkspaceNote(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async updateArtifactWorkspaceNote(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['updateArtifactWorkspaceNote']>[0];
      await runArtifactWorkspaceUserMutation('update_note', mutation, () => workspaceService.updateArtifactWorkspaceNote(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async createArtifactWorkspaceRelation(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['createArtifactWorkspaceRelation']>[0];
      await runArtifactWorkspaceUserMutation('create_relation', mutation, () => workspaceService.createArtifactWorkspaceRelation(mutation));
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async setArtifactCollectionMembership(input: Record<string, unknown>, viewKey = 'primary') {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['setArtifactCollectionMembership']>[0];
      await runArtifactWorkspaceUserMutation(
        input.included === false ? 'remove_collection_member' : 'add_collection_member',
        mutation,
        () => workspaceService.setArtifactCollectionMembership(mutation),
      );
      return workspaceService.getArtifactWorkspaceSnapshot({ ...mutation, viewKey });
    },
    async recordArtifactWorkspaceEvent(input: Record<string, unknown>) {
      const mutation = { ...input, requestSource: 'user' } as unknown as Parameters<ArtifactWorkspaceService['recordArtifactWorkspaceEvent']>[0];
      return { recorded: workspaceService.recordArtifactWorkspaceEvent(mutation) };
    },
    async reconcileArtifactWorkspace(): Promise<void> {
      await workspaceService.reconcileStartup();
      workspaceService.cleanup();
    },

    // ---- Channel API (shared config.json) ----
    async listChannels(): Promise<Array<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }>> {
      return readChannelViews();
    },
    async testChannel(channelId: string): Promise<{ success: boolean; latencyMs?: number; error?: string }> {
      const config = await loadConfig();
      const channels = (config as unknown as Record<string, unknown>).channels ?? {};
      const ch = (channels as Record<string, unknown>)[channelId] as { sendMsgUrl?: string; webhookUrl?: string } | undefined;
      const url = ch?.sendMsgUrl || ch?.webhookUrl;
      if (!url) {
        return { success: false, error: '未配置 webhook URL' };
      }
      try {
        const start = Date.now();
        // Send a test ping message
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ msgtype: 'text', text: { content: 'xiaok 测试连接 ✅' } }),
        });
        const latencyMs = Date.now() - start;
        if (!response.ok) {
          return { success: false, latencyMs, error: `HTTP ${response.status}` };
        }
        return { success: true, latencyMs };
      } catch (e) {
        return { success: false, error: (e as Error).message };
      }
    },
    async createChannel(input: { type: string; name: string; webhookUrl?: string }): Promise<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }> {
      const config = await loadConfig();
      const raw = config as unknown as Record<string, unknown>;
      if (!raw.channels) raw.channels = {};
      (raw.channels as Record<string, unknown>)[input.type] = {
        name: input.name,
        sendMsgUrl: input.webhookUrl || '',
        inboundMode: 'webhook',
        enabled: true,
      };
      await saveConfig(config);
      return {
        id: input.type,
        type: input.type,
        name: input.name,
        webhookUrl: input.webhookUrl,
        enabled: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
    },
    async updateChannel(id: string, input: { type?: string; name?: string; webhookUrl?: string; enabled?: boolean }): Promise<{ id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number }> {
      const config = await loadConfig();
      const raw = config as unknown as Record<string, unknown>;
      const channels = (raw.channels as Record<string, unknown>) || {};
      const ch = channels[id] as Record<string, unknown> | undefined;
      if (!ch) throw new Error('Channel not found');
      if (input.name !== undefined) ch.name = input.name;
      if (input.webhookUrl !== undefined) ch.sendMsgUrl = input.webhookUrl;
      if (input.enabled !== undefined) ch.enabled = input.enabled;
      await saveConfig(config);
      return {
        id, type: id, name: (ch.name as string) || id,
        webhookUrl: ch.sendMsgUrl as string | undefined,
        enabled: ch.enabled !== false, createdAt: 0, updatedAt: Date.now(),
      };
    },
    async deleteChannel(id: string) {
      const config = await loadConfig();
      const raw = config as unknown as Record<string, unknown>;
      const channels = raw.channels as Record<string, unknown> | undefined;
      if (channels) delete channels[id];
      await saveConfig(config);
    },

    // ---- MCP API ----
    async listMCPInstalls(): Promise<Array<{ id: string; name: string; source: string; command: string; args?: string[]; enabled: boolean; createdAt: number }>> {
      return readMcpInstallViews(options.dataRoot);
    },
    async createMCPInstall(input: { name: string; source: 'npm' | 'github' | 'local'; command: string; args?: string[] }) {
      const path = join(options.dataRoot, 'mcp-installs.json');
      const installs = await loadJsonFile<MCPRecord[]>(path, []);
      const record: MCPRecord = {
        id: crypto.randomUUID(),
        name: input.name,
        source: input.source,
        command: input.command,
        args: input.args,
        enabled: true,
        createdAt: Date.now(),
      };
      installs.push(record);
      await saveJsonFile(path, installs);
      return toMCPView(record);
    },
    async updateMCPInstall(id: string, input: { name?: string; source?: 'npm' | 'github' | 'local'; command?: string; enabled?: boolean }) {
      const path = join(options.dataRoot, 'mcp-installs.json');
      const installs = await loadJsonFile<MCPRecord[]>(path, []);
      const idx = installs.findIndex(c => c.id === id);
      if (idx < 0) throw new Error('MCP install not found');
      if (input.name !== undefined) installs[idx].name = input.name;
      if (input.source !== undefined) installs[idx].source = input.source;
      if (input.command !== undefined) installs[idx].command = input.command;
      if (input.enabled !== undefined) installs[idx].enabled = input.enabled;
      await saveJsonFile(path, installs);
      return toMCPView(installs[idx]);
    },
    async deleteMCPInstall(id: string) {
      const path = join(options.dataRoot, 'mcp-installs.json');
      const installs = await loadJsonFile<MCPRecord[]>(path, []);
      await saveJsonFile(path, installs.filter(c => c.id !== id));
    },

    async exportTraceBundle(input: { kind: 'session' | 'project' | 'task'; id: string }): Promise<{ ok: boolean; path?: string; error?: string }> {
      try {
        const bundle = input.kind === 'project'
          ? buildProjectTraceBundleFromKSwarmDetail(await fetchKSwarmProjectFullDetail(options.kswarmService, input.id), { projectId: input.id })
          : await buildDesktopSessionTraceBundle({ kind: input.kind, id: input.id }, options.dataRoot, snapshotStore);
        const path = writeTraceBundleToPath({
          bundle,
          outputPath: join(options.dataRoot, 'traces', `${input.kind}_${sanitizeFilePart(input.id)}_${Date.now()}.json`),
          force: true,
        });
        return { ok: true, path };
      } catch (error) {
        return { ok: false, error: (error as Error).message };
      }
    },

    async diagnose(input: { kind: 'session' | 'project' | 'task'; id: string }): Promise<DiagnosisReport> {
      if (input.kind === 'project') {
        const detail = await fetchKSwarmProjectFullDetail(options.kswarmService, input.id);
        return diagnoseProjectSnapshot(detail as never);
      }
      const bundle = await buildDesktopSessionTraceBundle({ kind: input.kind, id: input.id }, options.dataRoot, snapshotStore);
      return diagnoseTraceBundle(bundle);
    },

    // Test helpers for AI runner tool registration
    getToolDefinitions() {
      return registry.getToolDefinitions();
    },
    async executeTool(name: string, input: Record<string, unknown>) {
      return registry.executeTool(name, input);
    },
    getDataRoot() {
      return options.dataRoot;
    },
    getKnowledgeBaseStore() {
      if (!kbStore) throw new Error('knowledge_base_unavailable');
      return kbStore;
    },
    startProjectPlanning(input: KSwarmInitialPlanBootstrapInput) {
      return initialPlanBootstrapQueue.enqueue(input);
    },
  };
}

function buildComputerUseNeedsEnablementError(): ComputerUseUnavailableError {
  return {
    code: 'COMPUTER_USE_NEEDS_ENABLEMENT',
    message: 'Computer Use 尚未启用。',
    userAction: { type: 'enable_computer_use', label: '启用 Computer Use' },
  };
}

function buildComputerUseDisabledUnavailableError(): ComputerUseUnavailableError {
  return {
    code: 'COMPUTER_USE_DISABLED_BY_USER',
    message: 'Computer Use 已被用户禁用。',
  };
}

function mapComputerUseStartupError(error: unknown): ComputerUseUnavailableError {
  const message = error instanceof Error ? error.message : String(error);
  if (process.platform === 'win32') {
    const code = message.includes('SESSION_UNAVAILABLE') ? 'COMPUTER_USE_WINDOWS_SESSION_UNAVAILABLE'
      : /IDENTITY_MISMATCH|ABI_MISMATCH|OBSERVATION_INVALID|TARGET_MISMATCH/.test(message) ? 'COMPUTER_USE_WINDOWS_ABI_MISMATCH'
      : /binary_missing|dependency.*not.ready/.test(message) ? 'COMPUTER_USE_DRIVER_MISSING' : 'COMPUTER_USE_MCP_CONNECT_TIMEOUT';
    return { code, message: code === 'COMPUTER_USE_WINDOWS_SESSION_UNAVAILABLE'
      ? '当前 Windows 会话没有可操作桌面，请登录并解锁桌面后重新连接。'
      : code === 'COMPUTER_USE_WINDOWS_ABI_MISMATCH' ? 'CUA Driver 版本或接口不匹配，请安装兼容版本后重新连接。' : message,
      userAction: { type: 'reconnect_computer_use', label: '重新连接' } };
  }
  if (message.includes('permission_accessibility_missing')) {
    return {
      code: 'COMPUTER_USE_NEEDS_ACCESSIBILITY',
      message: 'CUA Driver 缺少辅助功能权限。',
      userAction: { type: 'open_system_settings', label: '打开系统设置' },
    };
  }
  if (message.includes('permission_screen_missing')) {
    return {
      code: 'COMPUTER_USE_NEEDS_SCREEN_RECORDING',
      message: 'CUA Driver 缺少屏幕录制权限。',
      userAction: { type: 'open_system_settings', label: '打开系统设置' },
    };
  }
  if (message.includes('mcp_content_unsupported')) {
    return {
      code: 'COMPUTER_USE_PERMISSION_INVALID',
      message: 'Computer Use 权限看似已授权，但未返回可用屏幕内容。',
      userAction: { type: 'open_system_settings', label: '重新设置权限' },
    };
  }
  return {
    code: 'COMPUTER_USE_MCP_CONNECT_TIMEOUT',
    message: message || 'Computer Use 连接失败。',
    userAction: { type: 'reconnect_computer_use', label: '重新连接' },
  };
}

function resolveComputerUseAppIdentity(): ComputerUseAppIdentity {
  const appPath = resolveMacAppBundlePath(process.execPath);
  const teamId = appPath ? resolveCodeSignatureTeamId(appPath) : undefined;
  const appAsarSha256 = appPath && !teamId ? resolveAppAsarSha256(appPath) : undefined;
  return {
    isPackaged: process.env.NODE_ENV !== 'development' && Boolean(appPath),
    ...(appPath ? { appPath } : {}),
    ...(process.env.XIAOK_DESKTOP_BUNDLE_ID ? { bundleId: process.env.XIAOK_DESKTOP_BUNDLE_ID } : {}),
    ...(teamId ? { teamId } : {}),
    ...(appAsarSha256 ? { appAsarSha256 } : {}),
    ...(process.env.XIAOK_DESKTOP_DEV_SERVER ? { devServerUrl: process.env.XIAOK_DESKTOP_DEV_SERVER } : {}),
    ...(process.env.NODE_ENV ? { nodeEnv: process.env.NODE_ENV } : {}),
  };
}

export function resolveAppAsarSha256(appPath: string): string | undefined {
  const electronProcess = process as NodeJS.Process & { noAsar?: boolean };
  const previousNoAsar = electronProcess.noAsar;
  try {
    electronProcess.noAsar = true;
    const appAsarPath = join(appPath, 'Contents', 'Resources', 'app.asar');
    if (!existsSync(appAsarPath)) return undefined;
    return createHash('sha256').update(readFileSync(appAsarPath)).digest('hex');
  } catch {
    return undefined;
  } finally {
    electronProcess.noAsar = previousNoAsar;
  }
}

function resolveMacAppBundlePath(executablePath: string): string | undefined {
  const marker = '.app/Contents/MacOS/';
  const index = executablePath.indexOf(marker);
  if (index === -1) return undefined;
  return executablePath.slice(0, index + '.app'.length);
}

function resolveCodeSignatureTeamId(appPath: string): string | undefined {
  if (process.platform !== 'darwin') return undefined;
  try {
    const result = spawnSync('/usr/bin/codesign', ['-dv', '--verbose=4', appPath], {
      encoding: 'utf8',
      timeout: 1_000,
    });
    const output = `${result.stdout ?? ''}\n${result.stderr ?? ''}`;
    return /TeamIdentifier=([A-Z0-9]+)/.exec(output)?.[1];
  } catch {
    return undefined;
  }
}

function formatKSwarmRequiredOutputs(outputs: KSwarmTaskHandoff['task']['requiredOutputs']): string {
  if (!Array.isArray(outputs)) return '';
  const normalized: string[] = [];
  for (const output of outputs) {
    const raw = typeof output === 'string'
      ? output
      : output?.type || output?.format || output?.kind || output?.mimeType || '';
    const value = String(raw || '').trim();
    if (value && !normalized.includes(value)) normalized.push(value);
  }
  return normalized.join(', ');
}

function inferKSwarmArtifactKind(kind: string, label: string): string {
  const normalized = String(kind || '').toLowerCase();
  const lowerLabel = String(label || '').toLowerCase();
  if ((normalized === 'text' || normalized === 'other') && lowerLabel.endsWith('.md')) return 'markdown';
  return normalized || 'file';
}

function shouldRequireKSwarmArtifactEvidence(task: KSwarmTaskHandoff['task']): boolean {
  if ((task.requiredOutputs ?? []).length > 0) return true;
  if (task.evidenceContract && task.evidenceContract.required === true) return true;
  return false;
}

function discoverKSwarmArtifactsFromDirectory(input: {
  artifactsDir: string;
  runStartedAt: number;
  knownPaths: string[];
}): Array<{ path: string; kind: string; label: string }> {
  const { artifactsDir, runStartedAt, knownPaths } = input;
  if (!artifactsDir || !existsSync(artifactsDir)) return [];
  const known = new Set(knownPaths.map(item => String(item || '')));
  const minMtime = runStartedAt - 5_000;
  const discovered: Array<{ path: string; kind: string; label: string }> = [];
  for (const entry of readdirSync(artifactsDir, { withFileTypes: true })) {
    if (!entry.isFile() || entry.name.startsWith('.')) continue;
    if (isKSwarmSystemArtifactFilename(entry.name)) continue;
    const filePath = join(artifactsDir, entry.name);
    if (known.has(filePath)) continue;
    let stat;
    try {
      stat = statSync(filePath);
    } catch {
      continue;
    }
    if (stat.mtimeMs < minMtime) continue;
    discovered.push({
      path: filePath,
      kind: inferKSwarmArtifactKind(kindFromFilename(entry.name), entry.name),
      label: entry.name,
    });
  }
  return discovered.sort((left, right) => left.label.localeCompare(right.label));
}

function isKSwarmSystemArtifactFilename(filename: string): boolean {
  return filename === 'plan-v1.md' || filename === 'synthesis.md';
}

function kindFromFilename(filename: string): string {
  const extension = extname(filename).toLowerCase();
  if (extension === '.md' || extension === '.markdown') return 'markdown';
  if (extension === '.html' || extension === '.htm') return 'html';
  if (extension === '.json') return 'json';
  if (extension === '.pptx') return 'pptx';
  if (extension === '.pdf') return 'pdf';
  return 'file';
}

const kswarmTextExecutionClocks = new WeakMap<InProcessTaskRuntimeHost, { clock?: KSwarmExecutionClock }>();

async function runKSwarmRuntimeTextTask(
  host: InProcessTaskRuntimeHost,
  prompt: string,
  options: {
    artifactsDir?: string;
    runStartedAt?: number;
    materials?: Array<{ materialId: string; role?: MaterialRole }>;
    // design §6.2 RoomHistoryReadCapability：可选钩子，在 host.createTask
    // 成功产出真实 taskId 后立即调用（不等到任务完成）。通用签名，不专属
    // Room——其它调用方可以忽略它；Room 任务用它在 agent 真正开始执行前
    // 注册 per-task 的历史补取能力绑定，任务结束后在 finally 里释放。
    onTaskCreated?: (taskId: string) => void;
  } = {},
): Promise<{ taskId: string; summary: string; structuredOutput?: Record<string, unknown>; artifacts: Array<{ path: string; kind: string; label?: string }> }> {
  const runStartedAt = options.runStartedAt || Date.now();
  const maxAttempts = 2;
  let lastFailure: string | null = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    let retry = false;
    const execution = kswarmTextExecutionClocks.get(host);
    if (execution) execution.clock = undefined;
    const created = await host.createTask({ prompt, materials: options.materials ?? [] });
    options.onTaskCreated?.(created.taskId);
    const deadline = Date.now() + 10 * 60 * 1000;
    const queueDeadline = Date.now() + 60 * 60 * 1000;
    while (execution
      ? (execution.clock ? !execution.clock.expired() : Date.now() < queueDeadline)
      : Date.now() < deadline) {
      const current = await host.inspectTask(created.taskId);
      if (!current) throw Error('desktop_task_snapshot_missing');
      const recovered = { snapshot: current };
      if (recovered.snapshot.status === 'completed') {
        const artifactEvents = recovered.snapshot.events.filter(event => event.type === 'artifact_recorded');
        const eventArtifacts = artifactEvents.map(event => ({
          path: (event as any).filePath || (event as any).path,
          kind: inferKSwarmArtifactKind((event as any).kind, (event as any).label),
          label: (event as any).label,
        })).filter(artifact => artifact.path);
        const discoveredArtifacts = discoverKSwarmArtifactsFromDirectory({
          artifactsDir: options.artifactsDir || '',
          runStartedAt,
          knownPaths: eventArtifacts.map(artifact => artifact.path),
        });
        return {
          taskId: created.taskId,
          summary: recovered.snapshot.result?.summary || '',
          structuredOutput: isRecord(recovered.snapshot.result?.structuredOutput) ? recovered.snapshot.result.structuredOutput : undefined,
          artifacts: [...eventArtifacts, ...discoveredArtifacts],
        };
      }
      if (recovered.snapshot.status === 'failed' || recovered.snapshot.status === 'cancelled') {
        lastFailure = getKSwarmRuntimeTaskFailureReason(recovered.snapshot) || `desktop_task_${recovered.snapshot.status}`;
        if (
          recovered.snapshot.status === 'failed'
          && attempt < maxAttempts
          && isRetryableKSwarmRuntimeTaskFailure(lastFailure)
        ) {
          await new Promise(resolve => setTimeout(resolve, 750));
          retry = true;
          break;
        }
        throw new Error(`desktop_task_${recovered.snapshot.status}: ${lastFailure}`);
      }
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    if (retry) continue;
    await host.cancelTask(created.taskId);
    throw new Error('desktop_task_timeout');
  }
  throw new Error(lastFailure ? `desktop_task_failed: ${lastFailure}` : 'desktop_task_timeout');
}

function parseKSwarmRuntimeStructuredJson(result: { summary: string; structuredOutput?: Record<string, unknown> }): Record<string, unknown> {
  return result.structuredOutput ?? extractKSwarmJsonObject(result.summary);
}

function getKSwarmRuntimeTaskFailureReason(snapshot: { salvage?: { reason?: unknown }; events?: Array<unknown> }): string {
  const salvageReason = typeof snapshot.salvage?.reason === 'string' ? snapshot.salvage.reason.trim() : '';
  if (salvageReason) return salvageReason;
  for (const event of [...(snapshot.events || [])].reverse()) {
    if (!isRecord(event)) continue;
    if (event.type === 'error' && typeof event.message === 'string' && event.message.trim()) {
      return event.message.trim();
    }
  }
  return '';
}

function isRetryableKSwarmRuntimeTaskFailure(reason: string): boolean {
  return /Premature close|ERR_STREAM_PREMATURE_CLOSE|ECONNRESET|ETIMEDOUT|EPIPE|socket hang up|fetch failed|terminated/i.test(reason);
}

function formatUpstreamOutputsSection(upstreamOutputs: Record<string, { nodeId?: string; nodeTitle?: string; summary?: string; artifactPaths?: string[]; _truncated?: boolean; [key: string]: unknown }> | undefined): string {
  if (!upstreamOutputs || typeof upstreamOutputs !== 'object') return '';
  const entries = Object.values(upstreamOutputs);
  if (entries.length === 0) return '';

  const lines = ['', '## 上游节点产出（参考信息）', ''];
  for (const entry of entries) {
    const title = entry.nodeTitle || entry.nodeId || '未知节点';
    lines.push(`### ${title}`);
    if (entry.summary) lines.push(`- 摘要：${entry.summary}`);
    if (Array.isArray(entry.artifactPaths) && entry.artifactPaths.length > 0) {
      lines.push(`- 产物文件：${entry.artifactPaths.join(', ')}`);
    }
    if (entry._truncated) lines.push('- （部分信息被截断，如需完整内容请读取产物文件）');
    const extraKeys = Object.keys(entry).filter(k => !['nodeId', 'nodeTitle', 'summary', 'artifactPaths', '_truncated'].includes(k));
    for (const k of extraKeys.slice(0, 5)) {
      try {
        const v = JSON.stringify(entry[k]);
        if (v && v.length < 200) lines.push(`- ${k}：${v}`);
      } catch { /* skip */ }
    }
    lines.push('');
  }
  lines.push('如需完整内容，请使用 Read 工具读取上述文件路径。');
  return lines.join('\n');
}

function buildKSwarmWorkflowNodePrompt(handoff: KSwarmWorkflowNodeHandoff, participantId: string, options: { artifactsDir?: string } = {}): string {
  const project = handoff.project || { id: handoff.projectId };
  const inputWithoutUpstream = handoff.input ? (() => {
    const { upstreamOutputs: _u, ...rest } = handoff.input as Record<string, unknown>;
    return Object.keys(rest).length > 0 ? rest : null;
  })() : null;
  const upstreamSection = formatUpstreamOutputsSection((handoff.input as Record<string, unknown>)?.upstreamOutputs as Record<string, { nodeId?: string; nodeTitle?: string; summary?: string; artifactPaths?: string[]; _truncated?: boolean }> | undefined);
  const base = [
    'KSwarm 动态工作流节点执行。',
    `执行者：${participantId}`,
    `工作流：${handoff.workflowId}`,
    `真实 workflow run ID：${handoff.workflowRunId}`,
    `节点：${handoff.nodeTitle} (${handoff.nodeId})`,
    `项目：${project.name || project.id}`,
    project.goal ? `目标：${project.goal}` : '',
    project.workFolder ? `工作区：${project.workFolder}` : '',
    inputWithoutUpstream ? `节点输入：${JSON.stringify(inputWithoutUpstream)}` : '',
  ].filter(Boolean);

  if (handoff.nodeKind === 'review') {
    return [
      ...base,
      '你是 reviewer / adversarial agent。请审查 worker 输出是否足够可靠、是否存在明显遗漏、是否包含可复核交付物证据、是否能支撑下一步行动。',
      '如果节点输入包含 sourceTask，则 sourceTask 是唯一验收范围；项目 plan、plan-v1 或其他任务只能作为背景证据，不能要求源任务以外的任务先完成。',
      `如果交付物需要 workflow run ID，必须检查它是否使用真实 workflow run ID：${handoff.workflowRunId}；不能接受自行推导或占位 ID。`,
      upstreamSection,
      '只返回一个 JSON 对象，不要返回 Markdown 包裹：',
      '{"reviewDecision":{"status":"passed|needs_rework|blocked","reason":"一句明确原因","evidenceRefs":["可选证据引用"]},"output":{"summary":"复核摘要"}}',
      'status 只能是 passed、needs_rework、blocked。reason 不能为空。',
    ].filter(Boolean).join('\n');
  }

  if (isKSwarmTaskDeliverableWorkflowNode(handoff)) {
    return [
      ...base,
      options.artifactsDir ? `产物目录：${options.artifactsDir}` : '',
      '你是 worker agent。请执行节点输入中的 sourceTask，产出当前任务的最终交付物，而不是只写诊断或计划。',
      `真实 workflow run ID 是 ${handoff.workflowRunId}；如果正文需要 workflow run ID，只能使用这个值，不要自行推导、缩写或伪造。`,
      'sourceTask 是唯一工作范围；项目 plan、plan-v1 或 taskSnapshot 中的其他任务只能作为背景，不是本节点必须完成的额外任务。',
      '必须逐条满足 sourceTask.description、sourceTask.acceptanceCriteria 和 sourceTask.requiredOutputs；如果验收标准要求项目 ID、任务 ID、workflow run ID 或 artifact 路径，正文中必须明确写出这些值。',
      '必须把完整、可复核的交付物文件写入产物目录；推荐 markdown 文件，文件名使用英文小写和连字符。',
      '如果 sourceTask 要求 HTML 报告、report renderer 或 kai-report-creator，必须先生成完整 .report.md IR 内容，再调用 render_report_artifact 输出 .html；不要读取 ~/.xiaok/plugins 插件内部文件，不要手写 HTML。',
      VISUAL_PDF_EXPORT_GUIDANCE,
      upstreamSection,
      'JSON 输出只放 manifest，不要把完整正文塞进 JSON。',
      '只返回一个 JSON 对象，不要返回 Markdown 包裹：',
      '{"output":{"summary":"交付物摘要，说明文件内容和完成范围","artifacts":[{"path":"绝对路径或相对产物路径","kind":"markdown","label":"文件名"}],"workFolder":"项目工作区路径","evidenceRefs":["artifact:文件路径"]}}',
      '如果不能生成可读文件，status 不能假装完成；请在 summary 说明阻塞原因。',
    ].filter(Boolean).join('\n');
  }

  if (isKSwarmProjectDeliverableWorkflowNode(handoff)) {
    return [
      ...base,
      options.artifactsDir ? `产物目录：${options.artifactsDir}` : '',
      '你是 worker agent。请执行整个项目，产出最终项目交付物，而不是只写诊断、计划或单个任务结果。',
      `真实 workflow run ID 是 ${handoff.workflowRunId}；如果正文需要 workflow run ID，只能使用这个值，不要自行推导、缩写或伪造。`,
      '项目目标、项目要求、计划和 taskSnapshot 共同构成本节点的工作范围；请覆盖所有尚未完成但属于项目目标的任务。',
      '必须生成完整、可读、可复核的最终项目交付物文件，并写入产物目录；推荐 markdown 文件，文件名使用英文小写和连字符。',
      '如果项目要求 HTML 报告、report renderer 或 kai-report-creator，必须先生成完整 .report.md IR 内容，再调用 render_report_artifact 输出 .html；不要读取 ~/.xiaok/plugins 插件内部文件，不要手写 HTML。',
      VISUAL_PDF_EXPORT_GUIDANCE,
      upstreamSection,
      'JSON 输出只放 manifest，不要把完整正文塞进 JSON。',
      '只返回一个 JSON 对象，不要返回 Markdown 包裹：',
      '{"output":{"summary":"项目交付物摘要，说明覆盖范围和文件内容","artifacts":[{"path":"绝对路径或相对产物路径","kind":"markdown","label":"文件名"}],"workFolder":"项目工作区路径","evidenceRefs":["artifact:文件路径"]}}',
      '如果不能生成可读文件，status 不能假装完成；请在 summary 说明阻塞原因。',
    ].filter(Boolean).join('\n');
  }

  return [
    ...base,
    options.artifactsDir ? `产物目录：${options.artifactsDir}` : '',
    '你是 worker agent。请执行节点输入中的 prompt，而不是诊断项目状态或只复述计划。',
    '节点输入里的 prompt 是当前 workflow 节点的唯一工作指令；项目状态和计划只能作为背景。',
    '如果 prompt 要求生成报告、分析、代码或其他交付物，必须把完整、可复核的文件写入产物目录；推荐文件名使用英文小写和连字符。',
    '如果 prompt 要求 HTML 报告、report renderer 或 kai-report-creator，必须先生成完整 .report.md IR 内容，再调用 render_report_artifact 输出 .html；不要读取 ~/.xiaok/plugins 插件内部文件，不要手写 HTML。',
    VISUAL_PDF_EXPORT_GUIDANCE,
    `真实 workflow run ID 是 ${handoff.workflowRunId}；如果正文需要 workflow run ID，只能使用这个值，不要自行推导、缩写或伪造。`,
    upstreamSection,
    'JSON 输出只放 manifest，不要把完整正文塞进 JSON。',
    '只返回一个 JSON 对象，不要返回 Markdown 包裹：',
    '{"output":{"summary":"节点执行摘要","artifacts":[{"path":"绝对路径或相对产物路径","kind":"markdown","label":"文件名"}],"evidenceRefs":["artifact:文件路径"]}}',
    '如果本节点确实不需要生成文件，artifacts 可以为空数组，但 summary 必须说明完成了 prompt 的哪些要求。',
  ].filter(Boolean).join('\n');
}

function isKSwarmTaskDeliverableWorkflowNode(handoff: KSwarmWorkflowNodeHandoff): boolean {
  return handoff.workflowId === 'po-generated-task-workflow' && handoff.nodeId === 'worker-produce-deliverable';
}

function isKSwarmProjectDeliverableWorkflowNode(handoff: KSwarmWorkflowNodeHandoff): boolean {
  return handoff.workflowId === 'po-generated-project-workflow' && handoff.nodeId === 'worker-produce-project-deliverable';
}

function mergeKSwarmArtifacts(
  rawArtifacts: unknown,
  discoveredArtifacts: Array<{ path: string; kind: string; label?: string }> = [],
  options: { artifactsDir?: string } = {},
) {
  const merged = new Map<string, { path: string; kind: string; label?: string }>();
  const add = (artifact: unknown) => {
    if (!isRecord(artifact)) return;
    const rawPath = readString(artifact.path) || readString(artifact.relativePath) || readString(artifact.filename);
    const normalizedPath = normalizeKSwarmArtifactManifestPath(rawPath, options);
    if (!normalizedPath) return;
    merged.set(normalizedPath, {
      path: normalizedPath,
      kind: inferKSwarmArtifactKind(readString(artifact.kind) || readString(artifact.type), readString(artifact.label) || readString(artifact.filename) || normalizedPath),
      label: readString(artifact.label) || readString(artifact.filename) || basename(normalizedPath),
    });
  };
  if (Array.isArray(rawArtifacts)) {
    for (const artifact of rawArtifacts) add(artifact);
  }
  for (const artifact of discoveredArtifacts) add(artifact);
  return [...merged.values()];
}

function normalizeKSwarmArtifactManifestPath(rawPath: string, options: { artifactsDir?: string } = {}): string {
  const value = readString(rawPath);
  if (!value) return '';
  const withoutQuery = value.split(/[?#]/, 1)[0] || value;
  const artifactsDir = readString(options.artifactsDir);
  if (artifactsDir && isAbsolute(withoutQuery)) {
    const relativeToArtifacts = relative(resolve(artifactsDir), resolve(withoutQuery)).replace(/\\/g, '/');
    if (relativeToArtifacts && !relativeToArtifacts.startsWith('..') && !isAbsolute(relativeToArtifacts)) {
      return `artifacts/${relativeToArtifacts}`;
    }
  }
  const normalized = withoutQuery.replace(/\\/g, '/').replace(/\/+$/, '');
  if (!normalized) return '';
  if (normalized.startsWith('artifacts/')) return `artifacts/${basename(normalized)}`;
  if (normalized.includes('/artifacts/')) return `artifacts/${basename(normalized)}`;
  return `artifacts/${basename(normalized)}`;
}

function mergeKSwarmEvidenceRefs(rawEvidenceRefs: unknown, artifacts: Array<{ path: string }>, options: { artifactsDir?: string } = {}) {
  const refs = new Set(readStringArray(rawEvidenceRefs).map(ref => normalizeKSwarmEvidenceRef(ref, options)));
  for (const artifact of artifacts) {
    if (artifact.path) refs.add(`artifact:${artifact.path}`);
  }
  return [...refs];
}

function normalizeKSwarmEvidenceRef(ref: string, options: { artifactsDir?: string } = {}): string {
  const value = readString(ref);
  if (!value.startsWith('artifact:')) return value;
  const artifactPath = normalizeKSwarmArtifactManifestPath(value.slice('artifact:'.length), options);
  return artifactPath ? `artifact:${artifactPath}` : value;
}

function buildKSwarmAssignPoPrompt(payload: Record<string, unknown>, fallbackWorkerId: string): string {
  const members = readStringArray(payload.members);
  return [
    'KSwarm PO 规划任务。',
    `项目 ID：${readString(payload.projectId) || readString(payload.taskId)}`,
    `项目名称：${readString(payload.projectName) || readString(payload.name) || '未命名项目'}`,
    `用户目标：${readString(payload.goal)}`,
    readString(payload.requirements) ? `用户要求：${readString(payload.requirements)}` : '',
    readString(payload.planningGuidance) ? `规划补充：${readString(payload.planningGuidance)}` : '',
    `可分配 Worker：${members.length > 0 ? members.join(', ') : fallbackWorkerId}`,
    '不要改写用户目标或用户要求；细化内容只放入 plan 的 phases/items。',
    '用户没有明确指定数量时，不要为本月/近期/最新类信息收集任务编造固定条数门槛；验收标准应要求尽可能完整覆盖已公开信息，并在公开信息不足时说明搜索范围、已找到条目和信息缺口，不得凑数。',
    '请只输出一个 JSON object，不要 Markdown，不要解释。',
    'JSON schema: {"analysis":"string","successCriteria":["string"],"phases":[{"id":"phase-1","name":"string","items":[{"id":"item-1","title":"string","brief":"string","assignedAgent":"string","dependencies":[],"acceptanceCriteria":"string","requiredOutputs":["markdown"]}]}]}',
  ].filter(Boolean).join('\n');
}

function buildKSwarmReviewPrompt(payload: Record<string, unknown>): string {
  return [
    'KSwarm PO 验收任务提交。',
    `项目 ID：${readString(payload.projectId)}`,
    `任务 ID：${readString(payload.taskId)}`,
    readString(payload.fromWorker) ? `提交 Worker：${readString(payload.fromWorker)}` : '',
    '任务结果 JSON：',
    JSON.stringify(payload.result ?? {}, null, 2),
    '请基于任务结果和产物证据做标准门禁验收。不要因为是小K帮忙推进就绕过门禁。',
    '请只输出一个 JSON object，不要 Markdown，不要解释。',
    'JSON schema: {"passed":true,"feedback":"string","failureClass":null,"planRevisionNeeded":false}',
  ].filter(Boolean).join('\n');
}

function buildKSwarmSynthesisPrompt(detail: unknown): string {
  const record = isRecord(detail) ? detail : {};
  const project = isRecord(record.project) ? record.project : {};
  const tasks = Array.isArray(record.tasks) ? record.tasks : [];
  return [
    'KSwarm 项目收尾。',
    '项目所有任务已经完成，请写项目小结。',
    `项目名称：${readString(project.name)}`,
    `项目目标：${readString(project.goal)}`,
    '任务状态 JSON：',
    JSON.stringify(tasks.map(task => {
      const taskRecord = isRecord(task) ? task : {};
      return {
        id: readString(taskRecord.id),
        title: readString(taskRecord.title),
        status: readString(taskRecord.status),
        result: taskRecord.result ?? null,
      };
    }), null, 2),
    '输出 Markdown。内容只写正式项目小结，不要出现修订说明、评审回应、第二轮、【新增】、修订版等内部过程字样。',
  ].join('\n');
}

function extractKSwarmJsonObject(text: string): Record<string, unknown> {
  const trimmed = String(text || '').trim();
  if (!trimmed) throw new Error('structured_json_missing');
  try {
    const parsed = JSON.parse(trimmed);
    if (isRecord(parsed)) return parsed;
  } catch {
    // Fall through to fenced / embedded JSON extraction.
  }
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced?.[1]) {
    try {
      const parsed = JSON.parse(fenced[1]);
      if (isRecord(parsed)) return parsed;
    } catch {
      // Fall through to embedded JSON extraction.
    }
  }
  const embedded = trimmed.match(/\{[\s\S]*\}/);
  if (embedded?.[0]) {
    try {
      const parsed = JSON.parse(embedded[0]);
      if (isRecord(parsed)) return parsed;
    } catch {
      // Fall through to the structured_json_missing failure below.
    }
  }
  throw new Error('structured_json_missing');
}

function normalizeKSwarmPlan(
  rawPlan: Record<string, unknown>,
  fallbackWorkerId: string,
  context: { userGoal?: string; userRequirements?: string; planningGuidance?: string } = {},
) {
  const phasesInput = Array.isArray(rawPlan.phases) ? rawPlan.phases : [];
  const phases = phasesInput.map((phase, phaseIndex) => {
    const phaseRecord = isRecord(phase) ? phase : {};
    const phaseId = readString(phaseRecord.id) || `phase-${phaseIndex + 1}`;
    const itemsInput = Array.isArray(phaseRecord.items) ? phaseRecord.items : [];
    const items = itemsInput.map((item, itemIndex) => {
      const itemRecord = isRecord(item) ? item : {};
      const itemId = readString(itemRecord.id) || `item-${phaseIndex + 1}.${itemIndex + 1}`;
      return {
        id: itemId,
        title: readString(itemRecord.title) || `任务 ${phaseIndex + 1}.${itemIndex + 1}`,
        brief: readString(itemRecord.brief),
        rationale: readString(itemRecord.rationale),
        assignedAgent: readString(itemRecord.assignedAgent) || fallbackWorkerId,
        dependencies: readStringArray(itemRecord.dependencies),
        acceptanceCriteria: softenGeneratedTemporalQuantityCriteria(readString(itemRecord.acceptanceCriteria), context),
        requiredOutputs: readStringArray(itemRecord.requiredOutputs),
        status: readString(itemRecord.status) || 'pending',
      };
    });
    return {
      id: phaseId,
      name: readString(phaseRecord.name) || `阶段 ${phaseIndex + 1}`,
      items,
    };
  }).filter(phase => phase.items.length > 0);

  if (phases.length === 0) {
    phases.push({
      id: 'phase-1',
      name: '交付',
      items: [{
        id: 'item-1',
        title: '完成项目交付',
        brief: '根据用户目标和要求完成交付。',
        rationale: '默认执行项',
        assignedAgent: fallbackWorkerId,
        dependencies: [],
        acceptanceCriteria: '交付内容满足用户目标和要求。',
        requiredOutputs: [],
        status: 'pending',
      }],
    });
  }

  return {
    analysis: readString(rawPlan.analysis),
    successCriteria: readStringArray(rawPlan.successCriteria),
    phases,
  };
}

function softenGeneratedTemporalQuantityCriteria(
  acceptanceCriteria: string,
  context: { userGoal?: string; userRequirements?: string; planningGuidance?: string } = {},
) {
  const text = String(acceptanceCriteria || '').trim();
  if (!text) return text;
  const userText = [context.userGoal, context.userRequirements, context.planningGuidance].filter(Boolean).join('\n');
  if (userExplicitlyRequestedItemCount(userText)) return text;
  if (!hasGeneratedHardItemCount(text)) return text;
  if (!hasCurrentPeriodResearchContext(text)) return text;

  const softened = text.replace(
    /(包含|列出|整理)?\s*(至少|不少于|不低于)\s*[0-9一二三四五六七八九十百]+\s*条\s*([^，。；;,.]*)/gu,
    '尽可能完整覆盖已公开的本期相关动态',
  );
  const suffix = '若公开信息不足，应明确列出已找到条目、搜索范围、来源和信息缺口，不得编造或用弱相关内容凑数。';
  return softened.includes('不得编造或用弱相关内容凑数') ? softened : `${softened}${softened.endsWith('。') ? '' : '。'}${suffix}`;
}

function userExplicitlyRequestedItemCount(text: string) {
  return /(至少|不少于|不低于|超过|不少过|约|大约)?\s*[0-9一二三四五六七八九十百]+\s*条/u.test(String(text || ''));
}

function hasGeneratedHardItemCount(text: string) {
  return /(至少|不少于|不低于)\s*[0-9一二三四五六七八九十百]+\s*条/u.test(text);
}

function hasCurrentPeriodResearchContext(text: string) {
  return /(本月|当月|本周|当周|近期|最新|截至|当前|过去|近[一二三四五六七八九十0-9]+[天周月]|产品动态|产品特性|公开信息|来源链接)/u.test(text);
}

function buildKSwarmTasksFromPlan(plan: ReturnType<typeof normalizeKSwarmPlan>) {
  return plan.phases.flatMap(phase => phase.items.map(item => ({
    id: item.id,
    title: item.title,
    brief: item.brief,
    rationale: item.rationale,
    assignedAgent: item.assignedAgent,
    dependencies: item.dependencies,
    phaseId: phase.id,
    planItemId: item.id,
    acceptanceCriteria: item.acceptanceCriteria,
    requiredOutputs: item.requiredOutputs,
  })));
}

function normalizeKSwarmReview(rawReview: Record<string, unknown>) {
  return {
    passed: rawReview.passed === true,
    feedback: readString(rawReview.feedback) || (rawReview.passed === true ? '验收通过。' : '验收未通过。'),
    failureClass: rawReview.failureClass === null ? null : (readString(rawReview.failureClass) || null),
    planRevisionNeeded: rawReview.planRevisionNeeded === true,
  };
}

function normalizeKSwarmWorkflowNodeOutput(rawOutput: Record<string, unknown>, fallbackSummary: string): Record<string, unknown> & { summary: string } {
  return {
    ...rawOutput,
    summary: readString(rawOutput.summary) || fallbackSummary || 'workflow node completed',
  };
}

function normalizeKSwarmWorkflowReviewDecision(rawDecision: Record<string, unknown>) {
  const status = readString(rawDecision.status);
  const normalizedStatus = ['passed', 'needs_rework', 'blocked'].includes(status) ? status : 'blocked';
  return {
    status: normalizedStatus,
    reason: readString(rawDecision.reason) || 'Reviewer did not provide a valid reason.',
    evidenceRefs: readStringArray(rawDecision.evidenceRefs),
  };
}

function shouldSynthesizeKSwarmProject(detail: unknown): boolean {
  const record = isRecord(detail) ? detail : {};
  const project = isRecord(record.project) ? record.project : {};
  if (readString(project.status) === 'delivered' || readString(project.status) === 'closed') return false;
  const tasks = Array.isArray(record.tasks) ? record.tasks : [];
  return tasks.length > 0 && tasks.every(task => {
    const status = isRecord(task) ? readString(task.status) : '';
    return status === 'done' || status === 'cancelled';
  });
}

async function requestKSwarmJson(kswarmService: KSwarmService, path: string, init?: RequestInit): Promise<unknown> {
  if (!kswarmService) throw new Error('kswarm_service_missing');
  const response = await kswarmService.request(path, init);
  let body: unknown = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  if (!response.ok) {
    throw new Error(`kswarm_http_${response.status}`);
  }
  if (isRecord(body) && body.ok === false) {
    throw new Error(readString(body.error) || 'kswarm_request_failed');
  }
  return body;
}

function withKSwarmDesktopMutationToken(kswarmService: KSwarmService, init: RequestInit): RequestInit {
  const token = kswarmService.getDesktopMutationToken();
  if (!token) return init;
  const headers = new Headers(init.headers || {});
  headers.set('x-kswarm-mutation-token', token);
  return { ...init, headers };
}

export async function recoverInterruptedScriptWorkflows(kswarmService: KSwarmService): Promise<void> {
  if (!kswarmService) return;
  let projects: Record<string, unknown>[] = [];
  try {
    const payload = await requestKSwarmJson(kswarmService, '/projects');
    const list = isRecord(payload) ? payload.projects : null;
    if (!Array.isArray(list)) return;
    projects = list.filter(isRecord);
  } catch {
    // kswarm not ready / unavailable — skip silently, do not block startup.
    return;
  }

  // Global cap (across all projects) to avoid flooding the runtime during cold boot.
  const maxRestarts = 3;
  let restarted = 0;
  for (const project of projects) {
    if (restarted >= maxRestarts) break;
    const projectId = readString(project.id);
    if (!projectId) continue;
    let runs: Record<string, unknown>[] = [];
    try {
      const payload = await requestKSwarmJson(kswarmService, `/projects/${encodeURIComponent(projectId)}/workflows`);
      const list = isRecord(payload) ? payload.workflowRuns : null;
      runs = Array.isArray(list) ? list.filter(isRecord) : [];
    } catch {
      continue;
    }
    for (const run of runs) {
      if (restarted >= maxRestarts) break;
      if (readString(run.source) !== 'script_generated') continue;
      if (!isResumableWorkflowRunStatus(run)) continue;
      const scriptSource = readString(run.scriptSource);
      if (!scriptSource) continue;
      try {
        const result = restoreWorkflowScriptBackgroundJob({
          kswarmService,
          projectId,
          workflowRunId: readString(run.id),
          scriptSource,
          scriptHash: readString(run.scriptHash) || null,
          assignedAgent: readString(run.assignedAgent) || undefined,
        });
        if (result.restored) restarted += 1;
      } catch {
        // Per-run restore failure must not abort the rest of the scan.
      }
    }
  }
}

// Single-run direct resume powering the renderer's one-click "继续推进" for
// dynamic (script_generated) workflows. Unlike the conversational path, this
// rebuilds the desktop background job directly. All failures return a reason
// code; nothing is thrown back to the renderer.
export async function resumeOneScriptWorkflow(
  kswarmService: KSwarmService,
  projectId: string,
  workflowRunId: string,
): Promise<{ restored: boolean; reason?: string; jobId?: string }> {
  if (!kswarmService) return { restored: false, reason: 'kswarm_unavailable' };
  if (!readString(projectId) || !readString(workflowRunId)) {
    return { restored: false, reason: 'invalid_input' };
  }
  let run: Record<string, unknown> | null = null;
  try {
    const payload = await requestKSwarmJson(
      kswarmService,
      `/projects/${encodeURIComponent(projectId)}/workflows/${encodeURIComponent(workflowRunId)}`,
    );
    if (isRecord(payload)) {
      run = isRecord(payload.workflowRun) ? payload.workflowRun : payload;
    }
  } catch {
    return { restored: false, reason: 'kswarm_unavailable' };
  }
  if (!run) return { restored: false, reason: 'not_found' };
  if (readString(run.source) !== 'script_generated') {
    return { restored: false, reason: 'not_script_workflow' };
  }
  if (!isResumableWorkflowRunStatus(run)) {
    return { restored: false, reason: 'not_resumable' };
  }
  const scriptSource = readString(run.scriptSource);
  if (!scriptSource) return { restored: false, reason: 'no_script_source' };
  try {
    return restoreWorkflowScriptBackgroundJob({
      kswarmService,
      projectId,
      workflowRunId: readString(run.id) || workflowRunId,
      scriptSource,
      scriptHash: readString(run.scriptHash) || null,
      assignedAgent: readString(run.assignedAgent) || undefined,
    });
  } catch {
    return { restored: false, reason: 'restore_failed' };
  }
}

function readString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

export function resolveToolOutputArtifactPath(
  toolInput: unknown,
  result: string,
  options: ToolOutputArtifactPathOptions = {},
): string | null {
  return resolveToolOutputArtifactPathWithOptions(toolInput, result, options);
}

export function resolveWriteToolArtifactPath(toolName: string, toolInput: unknown): string | null {
  if (!isToolName(toolName, 'write') || !isRecord(toolInput)) return null;
  return readString(toolInput.file_path) || null;
}

interface ToolOutputArtifactPathOptions {
  toolName?: string;
  toolStartedAt?: number;
}

function resolveToolOutputArtifactPathWithOptions(
  toolInput: unknown,
  result: string,
  options: ToolOutputArtifactPathOptions = {},
): string | null {
  try {
    const parsed = JSON.parse(result) as unknown;
    if (isRecord(parsed)) {
      const explicitlyFailed = parsed.success === false || parsed.ok === false;
      if (explicitlyFailed) return null;

      const returnedPath = readString(parsed.output_path);
      if (returnedPath) return returnedPath;

      const succeeded = parsed.success === true || parsed.ok === true;
      if (succeeded && isRecord(toolInput)) {
        const inputPath = readString(toolInput.output_path);
        if (inputPath) return inputPath;
      }
    }
  } catch {
    // Non-JSON tool output is handled below for bash.
  }

  return resolveBashOutputArtifactPath(toolInput, result, options);
}

function isToolName(toolName: string | undefined, expected: string): boolean {
  return typeof toolName === 'string' && toolName.trim().toLowerCase() === expected;
}

export function attachRuntimeToolRequestScope(toolName: string | undefined, input: unknown, sessionId: string): Record<string, unknown> {
  const toolInput = isRecord(input) ? input : {};
  if (!isToolName(toolName, 'create_project')) return toolInput;
  const normalizedSessionId = typeof sessionId === 'string' ? sessionId.trim() : '';
  if (!normalizedSessionId) return toolInput;
  return {
    ...toolInput,
    _xiaokRequestScope: `task-session:${normalizedSessionId}`,
  };
}

function resolveBashOutputArtifactPath(
  toolInput: unknown,
  result: string,
  options: ToolOutputArtifactPathOptions,
): string | null {
  if (!isToolName(options.toolName, 'bash')) return null;
  if (!result.trim() || result.trimStart().startsWith('Error')) return null;

  const command = isRecord(toolInput) ? readString(toolInput.command) : '';
  const candidates = rankArtifactPathCandidates([
    ...extractArtifactPathCandidates(result),
    ...extractArtifactPathCandidates(command),
  ]);
  for (const candidate of candidates) {
    if (isFreshExistingArtifactPath(candidate, options.toolStartedAt)) {
      return candidate;
    }
  }
  return null;
}

function rankArtifactPathCandidates(paths: string[]): string[] {
  const seen = new Set<string>();
  return paths
    .map((path, index) => ({ path, index, score: scoreArtifactPath(path) }))
    .filter(item => {
      if (!item.path || seen.has(item.path)) return false;
      seen.add(item.path);
      return true;
    })
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map(item => item.path);
}

function scoreArtifactPath(path: string): number {
  let score = 0;
  if (!/(^|\/)(tmp|private\/tmp|var\/folders)\//.test(path)) score += 10;
  if (/\.(?:pdf|pptx|docx|xlsx)$/iu.test(path)) score += 5;
  return score;
}

function extractArtifactPathCandidates(text: string): string[] {
  if (!text) return [];
  const candidates: string[] = [];
  const pathPatterns = [
    /(?:file:\/\/)?(\/[^\s"'`<>|]+?\.(?:pdf|html|md|markdown|pptx|docx|xlsx|csv|json|txt|png|jpg|jpeg|webp|svg))(?:\b|$)/giu,
    /([A-Za-z]:\\[^\s"'`<>|]+?\.(?:pdf|html|md|markdown|pptx|docx|xlsx|csv|json|txt|png|jpg|jpeg|webp|svg))(?:\b|$)/giu,
  ];
  for (const pattern of pathPatterns) {
    for (const match of text.matchAll(pattern)) {
      const path = normalizeArtifactPathCandidate(match[1]);
      if (path) candidates.push(path);
    }
  }
  return candidates;
}

function normalizeArtifactPathCandidate(path: string): string {
  return path.trim().replace(/[),.;，。]+$/u, '');
}

function isFreshExistingArtifactPath(filePath: string, toolStartedAt?: number): boolean {
  try {
    if (!existsSync(filePath)) return false;
    const stat = statSync(filePath);
    if (!stat.isFile()) return false;
    if (typeof toolStartedAt === 'number' && stat.mtimeMs < toolStartedAt - 2_000) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function readStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map(item => readString(item)).filter(Boolean);
}

async function buildDesktopSessionTraceBundle(
  input: { kind: 'session' | 'task'; id: string },
  dataRoot: string,
  snapshotStore: FileTaskSnapshotStore,
) {
  if (input.kind === 'task') {
    const snapshot = await requireTaskSnapshot(snapshotStore, input.id);
    return buildSessionTraceBundleFromSnapshots([snapshot], { sessionId: snapshot.sessionId, dataRoot });
  }
  const snapshots = loadTaskSnapshotsForSession({ dataRoot, sessionId: input.id });
  if (snapshots.length === 0) {
    throw new Error(`no snapshots found for session: ${input.id}`);
  }
  return buildSessionTraceBundleFromSnapshots(snapshots, { sessionId: input.id, dataRoot });
}

async function requireTaskSnapshot(snapshotStore: FileTaskSnapshotStore, taskId: string): Promise<TaskSnapshot> {
  const snapshot = await snapshotStore.recoverTask(taskId);
  if (!snapshot) throw new Error(`task snapshot not found: ${taskId}`);
  return snapshot;
}

async function fetchKSwarmProjectFullDetail(kswarmService: KSwarmService, projectId: string): Promise<unknown> {
  const response = await kswarmService.request(`/projects/${projectId}/full`);
  if (!response.ok) {
    throw new Error(`kswarm project detail request failed: HTTP ${response.status}`);
  }
  return response.json();
}

function sanitizeFilePart(value: string): string {
  return value.replace(/[^a-zA-Z0-9_.-]+/g, '_');
}

// ---- Channel types ----

interface ChannelRecord {
  id: string;
  type: 'yunzhijia' | 'discord' | 'feishu' | 'qq' | 'qqbot' | 'weixin' | 'telegram';
  name: string;
  webhookUrl?: string;
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

function toChannelView(c: ChannelRecord): { id: string; type: string; name: string; webhookUrl?: string; enabled: boolean; createdAt: number; updatedAt: number } {
  return { id: c.id, type: c.type, name: c.name, webhookUrl: c.webhookUrl, enabled: c.enabled, createdAt: c.createdAt, updatedAt: c.updatedAt };
}

// ---- MCP types ----

interface MCPRecord {
  id: string;
  name: string;
  source: 'npm' | 'github' | 'local';
  command: string;
  args?: string[];
  enabled: boolean;
  createdAt: number;
}

function toMCPView(r: MCPRecord): { id: string; name: string; source: string; command: string; args?: string[]; enabled: boolean; createdAt: number } {
  return { id: r.id, name: r.name, source: r.source, command: r.command, args: r.args, enabled: r.enabled, createdAt: r.createdAt };
}

// ---- File helpers ----

async function loadJsonFile<T>(path: string, defaultVal: T): Promise<T> {
  try { return JSON.parse(readFileSync(path, 'utf-8')) as T } catch { return defaultVal; }
}

async function saveJsonFile(path: string, data: unknown): Promise<void> {
  mkdirSync(join(path, '..'), { recursive: true });
  writeFileSync(path, JSON.stringify(data, null, 2));
}

// File helpers only

function normalizeProviderId(value: string): string {
  const providerId = value.trim().toLowerCase();
  if (providerId === 'claude') return 'anthropic';
  if (providerId === 'custom') return 'custom-default';
  return providerId || 'anthropic';
}

function sanitizeModelIdPart(value: string): string {
  return value.trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'model';
}

function resolveProviderConnectionModelId(
  config: Config,
  providerId: string,
  requestedModelId?: string,
): string | undefined {
  if (requestedModelId) return requestedModelId;

  const providerDefaultModelId = getProviderProfile(providerId)?.defaultModel.modelId;
  if (
    providerDefaultModelId
    && config.models[providerDefaultModelId]?.provider === providerId
  ) {
    return providerDefaultModelId;
  }

  return Object.entries(config.models)
    .find(([, model]) => model.provider === providerId)?.[0];
}

function ensureProvider(config: Config, providerId: string, input: DesktopSaveModelConfigInput): void {
  const profile = getProviderProfile(providerId);
  const existing = config.providers[providerId];
  const baseUrl = input.baseUrl?.trim();
  const apiKey = input.apiKey?.trim();

  if (profile) {
    config.providers[providerId] = {
      type: 'first_party',
      protocol: input.protocol ?? existing?.protocol ?? profile.protocol,
      baseUrl: baseUrl || existing?.baseUrl || profile.baseUrl,
      apiKey: apiKey || existing?.apiKey,
      headers: existing?.headers ?? profile.defaultHeaders,
    };
    return;
  }

  const customBaseUrl = baseUrl || existing?.baseUrl;
  if (!customBaseUrl) {
    throw new Error('Custom provider requires a base URL.');
  }
  config.providers[providerId] = {
    type: 'custom',
    protocol: input.protocol ?? existing?.protocol ?? 'openai_legacy',
    baseUrl: customBaseUrl,
    apiKey: apiKey || existing?.apiKey,
    headers: existing?.headers,
  };
}

function ensureDefaultModel(config: Config, providerId: string): string {
  const profile = getProviderProfile(providerId);
  if (profile) {
    const modelId = profile.defaultModel.modelId;
    const catalogModel = findApplicableCatalogModel(
      config,
      providerId,
      modelId,
      profile.defaultModel.model,
    );
    config.models[modelId] = config.models[modelId] ?? {
      provider: providerId,
      model: profile.defaultModel.model,
      label: profile.defaultModel.label,
      capabilities: cloneStrings(profile.defaultModel.capabilities),
      ...(catalogModel?.runtimeOptions
        ? { runtimeOptions: cloneRuntimeOptions(catalogModel.runtimeOptions) }
        : {}),
    };
    return modelId;
  }

  const existingModel = Object.entries(config.models).find(([, model]) => model.provider === providerId);
  if (existingModel) {
    return existingModel[0];
  }

  const modelId = `${providerId}-default`;
  config.models[modelId] = {
    provider: providerId,
    model: 'default',
    label: `${providerId} Default`,
  };
  return modelId;
}

function repairModelConfigDefault(config: Config): void {
  const current = config.models[config.defaultModelId];
  if (current && config.providers[current.provider]) {
    config.defaultProvider = current.provider;
    return;
  }
  const remaining = Object.entries(config.models).filter(([, model]) => config.providers[model.provider]);
  const next = remaining.find(([, model]) => model.provider === config.defaultProvider) ?? remaining[0];
  config.defaultModelId = next?.[0] ?? '';
  config.defaultProvider = next?.[1].provider
    ?? (config.providers[config.defaultProvider] ? config.defaultProvider : Object.keys(config.providers)[0] ?? '');
}

function createModelConfigSnapshot(config: Config): DesktopModelConfigSnapshot {
  return {
    configPath: getConfigPath(),
    defaultProvider: config.defaultProvider,
    defaultModelId: config.defaultModelId,
    providers: Object.entries(config.providers).map(([id, provider]) => ({
      id,
      label: getProviderProfile(id)?.label ?? id,
      type: provider.type,
      protocol: provider.protocol,
      baseUrl: provider.baseUrl,
      apiKeyConfigured: Boolean(provider.apiKey),
    })),
    models: Object.entries(config.models).map(([id, model]) => {
      const runtimeMetadata = resolveDesktopModelRuntimeMetadata(config, id, model);
      return {
        id,
        provider: model.provider,
        model: model.model,
        label: model.label,
        capabilities: cloneStrings(model.capabilities),
        ...(runtimeMetadata.runtimeOptions
          ? { runtimeOptions: cloneRuntimeOptions(runtimeMetadata.runtimeOptions) }
          : {}),
        ...(runtimeMetadata.runtimeConstraints
          ? { runtimeConstraints: cloneRuntimeConstraints(runtimeMetadata.runtimeConstraints) }
          : {}),
        isDefault: id === config.defaultModelId,
      };
    }),
    providerProfiles: listProviderProfiles().map((profile) => ({
      id: profile.id,
      label: profile.label,
      protocol: profile.protocol,
      baseUrl: profile.baseUrl,
      defaultModelId: profile.defaultModel.modelId,
      defaultModel: profile.defaultModel.model,
      defaultModelLabel: profile.defaultModel.label,
      capabilities: cloneStrings(profile.defaultModel.capabilities),
      availableModels: profile.availableModels?.map(m => ({
        modelId: m.modelId,
        model: m.model,
        label: m.label,
        capabilities: cloneStrings(m.capabilities),
        ...(m.runtimeOptions ? { runtimeOptions: cloneRuntimeOptions(m.runtimeOptions) } : {}),
        ...(m.runtimeConstraints
          ? { runtimeConstraints: cloneRuntimeConstraints(m.runtimeConstraints) }
          : {}),
      })),
    })),
  };
}

function cloneStrings(values?: string[]): string[] | undefined {
  return values ? [...values] : undefined;
}

function cloneRuntimeOptions(options: ModelRuntimeOptions): ModelRuntimeOptions {
  return { ...options };
}

function sanitizeDesktopModelRuntimeOptions(input: unknown): ModelRuntimeOptions {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('runtimeOptions must be an object.');
  }
  const prototype = Object.getPrototypeOf(input);
  if (prototype !== Object.prototype && prototype !== null) {
    throw new Error('runtimeOptions must be a plain object.');
  }

  const raw = input as Record<string, unknown>;
  const supportedKeys = new Set(['contextLimit', 'reasoningEffort']);
  const unsupportedKeys = Object.keys(raw).filter(key => !supportedKeys.has(key));
  if (unsupportedKeys.length > 0) {
    throw new Error(`Unsupported runtimeOptions fields: ${unsupportedKeys.join(', ')}`);
  }

  return {
    ...(raw.contextLimit !== undefined
      ? { contextLimit: raw.contextLimit as number }
      : {}),
    ...(raw.reasoningEffort !== undefined
      ? { reasoningEffort: raw.reasoningEffort as ModelRuntimeOptions['reasoningEffort'] }
      : {}),
  };
}

function cloneRuntimeConstraints(constraints: ModelRuntimeConstraints): ModelRuntimeConstraints {
  return {
    ...constraints,
    ...(constraints.reasoningEfforts
      ? { reasoningEfforts: [...constraints.reasoningEfforts] }
      : {}),
  };
}

function findApplicableCatalogModel(
  config: Config,
  providerId: string,
  modelId: string,
  wireModel: string,
): ProviderModelVariant | undefined {
  // 与 control-plane.resolveRuntimeModelBinding 保持同一条规则：getProviderProfile
  // 只按 id 查表，所以 id 与官方撞名的 custom provider 不得继承 catalog 元数据。
  if (config.providers[providerId]?.type !== 'first_party') return undefined;

  const catalogModel = findCatalogModel(getProviderProfile(providerId), modelId, wireModel);
  if (!catalogModel) return undefined;

  if (
    providerId === 'kimi'
    && (catalogModel.model === 'k3' || catalogModel.model === 'k3-256k')
  ) {
    const provider = config.providers[providerId];
    if (
      provider?.protocol !== 'openai_legacy'
      || !isOfficialKimiK3OpenAIEndpoint(resolveProviderTransport(config, providerId).baseUrl)
    ) {
      return undefined;
    }
  }
  return catalogModel;
}

function resolveDesktopModelRuntimeMetadata(
  config: Config,
  modelId: string,
  model: ModelConfigEntry,
): { runtimeOptions?: ModelRuntimeOptions; runtimeConstraints?: ModelRuntimeConstraints } {
  const provider = config.providers[model.provider];
  if (!provider) {
    if (model.provider === 'kimi') return {};
    return model.runtimeOptions
      ? { runtimeOptions: cloneRuntimeOptions(model.runtimeOptions) }
      : {};
  }

  const transport = resolveProviderTransport(config, model.provider);
  const catalogModel = findApplicableCatalogModel(config, model.provider, modelId, model.model);
  const acceptsConfiguredRuntimeOptions = model.provider !== 'kimi' || (
    (model.model === 'k3' || model.model === 'k3-256k')
    && provider.protocol === 'openai_legacy'
    && isOfficialKimiK3OpenAIEndpoint(transport.baseUrl)
  );
  const configuredRuntimeOptions = acceptsConfiguredRuntimeOptions
    ? model.runtimeOptions
    : undefined;
  return resolveModelRuntimeOptions({
    protocol: provider.protocol,
    baseUrl: transport.baseUrl,
    wireModel: model.model,
    catalogOptions: catalogModel?.runtimeOptions,
    catalogConstraints: catalogModel?.runtimeConstraints,
    configuredOptions: configuredRuntimeOptions,
    reasoningEfforts: getSupportedModelReasoningEfforts({ providerId: model.provider, providerType: provider.type, protocol: provider.protocol, wireModel: model.model, baseUrl: transport.baseUrl }),
  });
}

// Simplified in-memory intent ledger store for Desktop
class InMemoryIntentLedgerStore {
  private ledgers = new Map<string, SessionIntentLedger>();

  seedEmpty(sessionId: string): void {
    if (this.ledgers.has(sessionId)) return;
    this.ledgers.set(sessionId, createEmptySessionIntentLedger(sessionId));
  }

  async load(sessionId: string): Promise<SessionIntentLedger | null> {
    return this.ledgers.get(sessionId) ?? null;
  }

  async appendIntent(sessionId: string, plan: IntentPlanDraft): Promise<SessionIntentLedger> {
    const intent = createIntentLedgerRecord(plan);
    const ledger: SessionIntentLedger = {
      sessionId,
      instanceId: 'desktop-instance',
      activeIntentId: intent.intentId,
      intents: [intent],
      latestPlan: intent,
      breadcrumbs: [],
      receipt: null,
      salvage: null,
      ownership: { state: 'owned', ownerInstanceId: 'desktop-instance', updatedAt: Date.now() },
      updatedAt: Date.now(),
    };
    this.ledgers.set(sessionId, ledger);
    return cloneSessionIntentLedger(ledger);
  }

  async updateIntent(sessionId: string, intentId: string, patch: Record<string, unknown>): Promise<SessionIntentLedger> {
    const ledger = this.ledgers.get(sessionId);
    if (!ledger) throw new Error(`session not found: ${sessionId}`);
    const intent = ledger.intents.find(i => i.intentId === intentId);
    if (!intent) throw new Error(`intent not found: ${intentId}`);
    Object.assign(intent, patch, { updatedAt: Date.now() });
    ledger.updatedAt = Date.now();
    return cloneSessionIntentLedger(ledger);
  }

  async recordBreadcrumb(sessionId: string, input: { intentId: string; stepId: string; status: string; message: string }): Promise<SessionIntentLedger> {
    const ledger = this.ledgers.get(sessionId);
    if (!ledger) throw new Error(`session not found: ${sessionId}`);
    ledger.breadcrumbs.push({
      intentId: input.intentId,
      stepId: input.stepId,
      status: input.status as 'running' | 'blocked' | 'completed' | 'failed',
      message: input.message,
      createdAt: Date.now(),
    });
    ledger.updatedAt = Date.now();
    return cloneSessionIntentLedger(ledger);
  }

  async recordReceipt(sessionId: string, input: { intentId: string; stepId: string; note: string }): Promise<SessionIntentLedger> {
    const ledger = this.ledgers.get(sessionId);
    if (!ledger) throw new Error(`session not found: ${sessionId}`);
    ledger.receipt = { ...input, createdAt: Date.now() };
    ledger.updatedAt = Date.now();
    return cloneSessionIntentLedger(ledger);
  }

  async recordSalvage(sessionId: string, input: { intentId: string; summary: string[]; reason?: string }): Promise<SessionIntentLedger> {
    const ledger = this.ledgers.get(sessionId);
    if (!ledger) throw new Error(`session not found: ${sessionId}`);
    ledger.salvage = { ...input, createdAt: Date.now() };
    ledger.updatedAt = Date.now();
    return cloneSessionIntentLedger(ledger);
  }

  async saveDispatchedIntent(sessionId: string, intent: IntentLedgerRecord): Promise<SessionIntentLedger> {
    const ledger = this.ledgers.get(sessionId);
    if (!ledger) throw new Error(`session not found: ${sessionId}`);
    const idx = ledger.intents.findIndex(i => i.intentId === intent.intentId);
    if (idx >= 0) ledger.intents[idx] = intent;
    ledger.updatedAt = Date.now();
    return cloneSessionIntentLedger(ledger);
  }
}


const BASE_SYSTEM_PROMPT = buildDesktopSystemPrompt();

/** Convert tool name to user-friendly label for TaskPanel auto-progress */
function toolNameToLabel(name: string, input?: Record<string, unknown>): string {
  // MCP tools: extract server and action from mcp__server__action pattern
  const mcpMatch = name.match(/^mcp__([^_]+(?:-[^_]+)*)__(.+)$/);
  if (mcpMatch) {
    const action = mcpMatch[2].replace(/_/g, ' ');
    return action.charAt(0).toUpperCase() + action.slice(1);
  }
  // Built-in tools
  switch (name) {
    case 'Write': {
      const fp = input?.file_path as string | undefined;
      const fname = fp ? basename(fp) : '';
      return fname ? `写入 ${fname}` : '写入文件';
    }
    case 'Read': {
      const fp = input?.file_path as string | undefined;
      const fname = fp ? basename(fp) : '';
      return fname ? `读取 ${fname}` : '读取文件';
    }
    case 'read_material': return '读取附件';
    case 'Edit': return '编辑文件';
    case 'bash': return '执行命令';
    case 'Glob': return '搜索文件';
    case 'Grep': return '搜索内容';
    case 'reminder_create': return '创建提醒';
    case 'reminder_list': return '查看提醒';
    case 'channel_send': return '发送消息';
    case 'notebook_write': return '写入记忆';
    case 'notebook_read': return '读取记忆';
    default: return name.replace(/_/g, ' ');
  }
}

/**
 * Collect plugin skill directories as extraRoots for skill catalog.
 * Scans each plugin under ~/.xiaok/plugins for a skills subdirectory.
 */
function getPluginSkillRoots(): string[] {
  const pluginsDir = getConfigDir('plugins');
  if (!existsSync(pluginsDir)) return [];
  const roots: string[] = [];
  try {
    for (const pluginName of readdirSync(pluginsDir)) {
      const skillsDir = join(pluginsDir, pluginName, 'skills');
      if (existsSync(skillsDir)) roots.push(skillsDir);
    }
  } catch { /* ignore */ }
  return roots;
}

export function createReportArtifactTool(): Tool {
  return {
    permission: 'write',
    definition: {
      name: 'render_report_artifact',
      description: [
        '将 .report.md IR 内容渲染为 HTML 报告 artifact。',
        '用于 KSwarm / dynamic workflow 的最终报告节点。',
        '不要读取插件内部文件，不要手写 HTML；把完整 IR 放入 ir_content，并把 output_path 指向项目 artifacts 目录下的 .html 文件。',
      ].join('\n'),
      inputSchema: {
        type: 'object',
        properties: {
          ir_content: { type: 'string', description: '完整 .report.md IR 内容，包含 frontmatter 和 ::: component blocks' },
          output_path: { type: 'string', description: 'HTML 输出文件路径，必须是 .html 或 .htm' },
          theme: { type: 'string', description: '可选主题名，例如 corporate-blue' },
        },
        required: ['ir_content', 'output_path'],
      },
    },
    async execute(input, context) {
      context?.signal?.throwIfAborted();
      const record = input as Record<string, unknown>;
      const irContent = readString(record.ir_content);
      const outputPath = resolve(readString(record.output_path));
      const theme = readString(record.theme) || undefined;
      if (!irContent.trim()) return JSON.stringify({ success: false, error: 'ir_content_required' });
      if (!outputPath) return JSON.stringify({ success: false, error: 'output_path_required' });
      if (!['.html', '.htm'].includes(extname(outputPath).toLowerCase())) {
        return JSON.stringify({ success: false, error: 'output_path_must_be_html', output_path: outputPath });
      }
      if (!isAllowedReportArtifactOutputPath(outputPath)) {
        return JSON.stringify({ success: false, error: 'output_path_outside_allowed_roots', output_path: outputPath });
      }

      const pluginDir = join(getConfigDir('plugins'), 'kai-report-creator');
      const serverBundlePath = join(
        pluginDir,
        'mcp-servers',
        'report-renderer',
        'dist',
        'server.bundle.js',
      );
      const rendererPath = join(
        getConfigDir('plugins'),
        'kai-report-creator',
        'mcp-servers',
        'report-renderer',
        'dist',
        'renderer',
        'html-builder.js',
      );
      if (!existsSync(serverBundlePath)) {
        return JSON.stringify({
          success: false,
          error: 'report_renderer_not_installed',
          server_path: serverBundlePath,
          renderer_path: rendererPath,
        });
      }

      try {
        const result = await renderReportArtifactViaBundledMcp({
          pluginDir,
          serverBundlePath,
          irContent,
          outputPath,
          theme,
          signal: context?.signal,
        });
        context?.signal?.throwIfAborted();
        const outputExists = existsSync(outputPath);
        const success = outputExists && (result.success !== false || isReportRendererStructurallyValid(result.validation));
        if (success && isRecord(result.validation) && result.validation.l3_passed === false) {
          console.warn('[report-renderer] L3 quality check failed (KPI placeholders detected)', {
            warnings: Array.isArray(result.validation.l3_warnings) ? result.validation.l3_warnings : [],
          });
        }
        return JSON.stringify({
          ...result,
          success,
          output_path: outputPath,
          stats: result.stats ?? null,
          validation: result.validation ?? null,
          warnings: Array.isArray(result.warnings) ? result.warnings : [],
        });
      } catch (error) {
        context?.signal?.throwIfAborted();
        return JSON.stringify({
          success: false,
          output_path: outputPath,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    },
  };
}

export function createReportProgressTool(): Tool {
  return {
    permission: 'safe',
    definition: {
      name: 'report_progress',
      description: '向用户报告任务计划和进度。在开始非trivial任务时调用此工具上报计划，每完成一步更新状态。简单问答不要调用。',
      inputSchema: {
        type: 'object',
        properties: {
          steps: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string', description: '步骤稳定标识，如 step-1' },
                label: { type: 'string', description: '面向用户的步骤描述，使用自然语言' },
                status: { type: 'string', enum: ['planned', 'running', 'completed', 'blocked', 'failed'] },
              },
              required: ['id', 'label', 'status'],
            },
          },
        },
        required: ['steps'],
      },
    },
    async execute(input) {
      const { steps } = input as { steps: unknown };
      if (!Array.isArray(steps)) {
        return JSON.stringify({ ok: false, error: 'steps must be an array' });
      }
      const validStatuses = new Set(['planned', 'running', 'completed', 'blocked', 'failed']);
      const validated: Array<{ id: string; label: string; status: string }> = [];
      for (const s of steps) {
        if (!s || !s.id || !s.label) continue;
        validated.push({
          id: String(s.id),
          label: String(s.label),
          status: validStatuses.has(s.status) ? s.status : 'planned',
        });
      }
      const allCompleted = validated.length > 0 && validated.every(s => s.status === 'completed');
      return JSON.stringify({ ok: true, displayed_steps: validated.length, _validated: validated,
        ...(allCompleted ? { completionReminder: '所有步骤已标记完成。请回顾用户原始请求，确认是否所有要求的交付物都已生成。如果有遗漏，请追加新步骤继续执行，不要结束任务。' } : {}),
      });
    },
  };
}

async function renderReportArtifactViaBundledMcp({
  pluginDir,
  serverBundlePath,
  irContent,
  outputPath,
  theme,
  signal,
}: {
  pluginDir: string;
  serverBundlePath: string;
  irContent: string;
  outputPath: string;
  theme?: string;
  signal?: AbortSignal;
}): Promise<Record<string, unknown>> {
  signal?.throwIfAborted();
  mkdirSync(dirname(outputPath), { recursive: true });
  const command = process.env.XIAOK_NODE_CMD || process.execPath;
  const runtimeEnv = !process.env.XIAOK_NODE_CMD && process.versions.electron
    ? { ELECTRON_RUN_AS_NODE: '1' }
    : undefined;
  const connection = await createMcpClientConnection('report-renderer', {
    type: 'stdio',
    command,
    args: [serverBundlePath],
    env: runtimeEnv,
    protocol: { mode: 'modern', version: '2026-07-28' },
    timeout: { startup: 30_000, call: 30_000 },
  }, {
    cwd: pluginDir,
    clientName: 'xiaok-desktop-report-renderer',
    startupSignal: signal,
  });
  try {
    // A connection which completes startup late still belongs to this finally.
    signal?.throwIfAborted();
    const result = await callMcpToolWithSignal(connection.client,
      {
        name: 'render_report',
        arguments: {
          ir_content: irContent,
          output_path: outputPath,
          ...(theme ? { theme } : {}),
        },
      },
      { timeout: 30_000, signal },
    );
    signal?.throwIfAborted();
    const raw = normalizeMcpRuntimeToolResult(result).text;
    try {
      const parsed = JSON.parse(raw) as unknown;
      if (isRecord(parsed)) return parsed;
    } catch {
      // Handled below as an invalid renderer response.
    }
    return {
      success: false,
      error: 'report_renderer_response_invalid',
      response: raw.slice(0, 2000),
    };
  } finally {
    connection.dispose();
  }
}

function isReportRendererStructurallyValid(validation: unknown): boolean {
  if (!isRecord(validation)) return false;
  const l0 = validation.l0_passed ?? validation.l0;
  const l1 = validation.l1_passed ?? validation.l1;
  const l2 = validation.l2_passed ?? validation.l2;
  return l0 === true && l1 === true && l2 === true;
}

function isAllowedReportArtifactOutputPath(outputPath: string): boolean {
  const allowedRoots = [
    process.cwd(),
    dirname(getConfigDir()),
    join(homedir(), '.kswarm', 'projects'),
  ].map(root => resolve(root));
  return allowedRoots.some(root => {
    const rel = relative(root, outputPath);
    return rel === '' || (!!rel && !rel.startsWith('..') && !isAbsolute(rel));
  });
}

const DEFAULT_READ_MATERIAL_MAX_CHARS = 50_000;

export const READ_MATERIAL_TOOL_DEFINITION: ToolDefinition = {
  name: 'read_material',
  description: '读取用户通过附件上传的材料。必须使用 materialId，不要用本地路径、glob 或 shell 脚本查找附件。若正文不可提取，也会返回文件名、类型、大小等元数据。',
  inputSchema: {
    type: 'object',
    properties: {
      materialId: { type: 'string', description: '当前用户消息中列出的附件 materialId，例如 mat_0001' },
      maxChars: { type: 'number', description: '可选，返回内容的最大字符数，默认 50000' },
    },
    required: ['materialId'],
  },
};

const IMAGE_MIME_TYPES = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);

export function buildMaterialManifestForPrompt(materials: MaterialRecord[]): string {
  if (materials.length === 0) return '';
  const lines = [
    '',
    '',
    '## 用户上传的文件',
    '',
    '以下文件已导入任务材料库。如果用户只问文件名、格式、大小等元数据，请直接根据清单回答；需要读取正文时，请调用 read_material，并传入对应 materialId。不要用 glob、read、bash 或脚本重新查找附件。',
    '',
  ];
  for (const material of materials) {
    const ext = extname(material.originalName || material.workspacePath).toLowerCase() || 'unknown';
    const status = material.parseStatus || 'pending';
    const summary = material.parseSummary ? `, ${material.parseSummary}` : '';
    const isImage = IMAGE_MIME_TYPES.has(material.mimeType);
    const imageNote = isImage ? '；已作为多模态图像输入直接传递给模型，无需调用 read_material' : '';
    lines.push(`- materialId: ${material.materialId}; 文件: ${material.originalName}; 格式: ${ext}; MIME: ${material.mimeType}; 大小: ${material.sizeBytes} bytes (${formatMaterialSize(material.sizeBytes)}); 状态: ${status}${summary}${imageNote}`);
  }
  return lines.join('\n');
}

export function buildImageBlocksForMaterials(materials: MaterialRecord[]): Extract<MessageBlock, { type: 'image' }>[] {
  const blocks: Extract<MessageBlock, { type: 'image' }>[] = [];
  for (const material of materials) {
    if (!IMAGE_MIME_TYPES.has(material.mimeType)) continue;
    try {
      const data = readFileSync(material.workspacePath).toString('base64');
      blocks.push({
        type: 'image',
        source: {
          type: 'base64',
          media_type: material.mimeType as 'image/png' | 'image/jpeg' | 'image/gif' | 'image/webp',
          data,
        },
      });
    } catch {
      // If the file can't be read, skip it silently — it will still appear in the text manifest
    }
  }
  return blocks;
}

export async function executeReadMaterialForDesktop(
  input: Record<string, unknown>,
  options: {
    taskId: string;
    materials: MaterialRecord[];
    materialRegistry?: MaterialRegistry;
    maxChars?: number;
    pdfToText?: (bytes: Uint8Array) => Promise<string>;
    officeToMarkdown?: (input: { absolutePath: string; maxOutputChars: number; signal?: AbortSignal }) => Promise<OfficeTextExtractionResult>;
    signal?: AbortSignal;
  },
): Promise<{ ok: boolean; result: string }> {
  const materialId = typeof input.materialId === 'string' ? input.materialId.trim() : '';
  const maxChars = normalizeReadMaterialLimit(input.maxChars, options.maxChars);
  if (!materialId) {
    return createReadMaterialResult(false, {
      ok: false,
      error: 'invalid_input',
      message: 'read_material 需要 materialId。',
    });
  }

  const material = options.materials.find((item) => item.materialId === materialId);
  if (!material) {
    return createReadMaterialResult(false, {
      ok: false,
      error: 'material_not_attached',
      materialId,
      message: '该 materialId 不属于当前任务，无法读取。',
    });
  }
  if (!options.materialRegistry) {
    return createReadMaterialResult(false, {
      ok: false,
      error: 'material_tool_unavailable',
      materialId,
      originalName: material.originalName,
      mimeType: material.mimeType,
      sizeBytes: material.sizeBytes,
      message: '当前运行器没有可用的材料注册表，无法读取附件。',
    });
  }

  if (
    material.extractedTextPath
    && material.extractorVersion === MATERIAL_EXTRACTOR_VERSION
    && material.sourceFingerprint === material.sha256
    && existsSync(material.extractedTextPath)
  ) {
    const cached = truncateMaterialText(readFileSync(material.extractedTextPath, 'utf8'), maxChars);
    return createReadMaterialResult(true, {
      ok: true,
      ...buildReadMaterialMetadata(material),
      parseStatus: 'parsed',
      cached: true,
      content: cached,
    });
  }

  const extraction = await extractMaterialText({
    workspacePath: material.workspacePath,
    mimeType: material.mimeType,
    maxChars: 2_000_000,
    pdfToText: options.pdfToText,
    officeToMarkdown: options.officeToMarkdown,
    signal: options.signal,
  });
  if (extraction.parseStatus === 'parsed' && extraction.text) {
    await options.materialRegistry.updateMaterialExtraction(material.materialId, {
      extractorVersion: MATERIAL_EXTRACTOR_VERSION,
      parseStatus: 'parsed',
      parseSummary: extraction.parseSummary,
      extractionEngine: extraction.engine,
      extractionEngineVersion: extraction.engineVersion,
      extractionTruncated: extraction.truncated,
      sourceFingerprint: material.sha256,
    }, extraction.text);
    return createReadMaterialResult(true, {
      ok: true,
      ...buildReadMaterialMetadata(material),
      parseStatus: 'parsed',
      parseSummary: extraction.parseSummary,
      content: truncateMaterialText(extraction.text, maxChars),
    });
  }

  await options.materialRegistry.updateMaterialExtraction(material.materialId, {
    parseStatus: extraction.parseStatus,
    parseSummary: extraction.parseSummary,
    errorMessage: extraction.errorMessage,
    extractionEngine: extraction.engine,
    extractionEngineVersion: extraction.engineVersion,
    extractionTruncated: extraction.truncated,
    sourceFingerprint: material.sha256,
    extractionErrorCode: extraction.errorCode,
  });
  if (extraction.parseStatus === 'unsupported') {
    return createReadMaterialResult(true, {
      ok: true,
      ...buildReadMaterialMetadata(material),
      parseStatus: 'unsupported',
      parseSummary: extraction.parseSummary,
      contentAvailable: false,
      message: extraction.errorMessage ?? '该附件格式暂不支持直接提取正文；文件名、类型、大小等元数据仍可用于回答元数据问题。',
    });
  }
  return createReadMaterialResult(false, {
    ok: false,
    error: 'material_read_failed',
    ...buildReadMaterialMetadata(material),
    parseStatus: extraction.parseStatus,
    contentAvailable: false,
    message: extraction.errorMessage ?? '附件读取失败。',
  });
}

async function executeDesktopTaskTool(
  toolCall: ToolCall,
  options: {
    registry: ToolRegistry;
    taskId: string;
    materials: MaterialRecord[];
    materialRegistry?: MaterialRegistry;
    context: ToolExecutionContext;
    scoped?: boolean;
    officeToMarkdown?: (input: { absolutePath: string; maxOutputChars: number; signal?: AbortSignal }) => Promise<OfficeTextExtractionResult>;
  },
): Promise<{ ok: boolean; result: string }> {
  if (toolCall.name === 'read_material' && !options.scoped && !options.registry.isNativeReadonlyOnly) {
    return runMonitoredTool({name:toolCall.name,context:options.context,run: context => executeReadMaterialForDesktop(toolCall.input, {
      taskId: options.taskId,
      materials: options.materials,
      materialRegistry: options.materialRegistry,
      pdfToText: async (bytes) => {
        const { extractPdfText } = await import('./pdf-text.js');
        return extractPdfText(bytes);
      },
      officeToMarkdown: options.officeToMarkdown,
      signal: context?.signal,
    })});
  }
  const context: ToolExecutionContext = { ...options.context,
    assertToolInputApprovalAdmission: createToolInputAdmissionGuard(toolCall.input),
  };
  if (Object.isFrozen(options.context)) Object.freeze(context);
  const result = await options.registry.executeTool(toolCall.name, toolCall.input, context);
  return { ok: isSuccessfulModelToolResult(result), result };
}

function normalizeReadMaterialLimit(inputLimit: unknown, fallback?: number): number {
  const raw = typeof inputLimit === 'number' && Number.isFinite(inputLimit)
    ? inputLimit
    : fallback ?? DEFAULT_READ_MATERIAL_MAX_CHARS;
  return Math.max(1_000, Math.min(100_000, Math.floor(raw)));
}

function truncateMaterialText(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text;
  return `${text.slice(0, maxChars)}\n...[截断，原文件 ${text.length} 字符]`;
}

function buildReadMaterialMetadata(material: MaterialRecord): Record<string, unknown> {
  return {
    materialId: material.materialId,
    originalName: material.originalName,
    mimeType: material.mimeType,
    sizeBytes: material.sizeBytes,
  };
}

function formatMaterialSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return `${bytes} B`;
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let value = bytes / 1024;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  const digits = value < 10 ? 2 : 1;
  return `${value.toFixed(digits)} ${units[unitIndex]}`;
}

function createReadMaterialResult(ok: boolean, payload: Record<string, unknown>): { ok: boolean; result: string } {
  return { ok, result: JSON.stringify(payload, null, 2) };
}

import { resolveDesktopToolLoopBudget, resolveDesktopRunDeadline } from './tool-loop-budget.js';

function throwIfAborted(signal: AbortSignal): void {
  if (!signal.aborted) return;
  const reason = signal.reason instanceof Error
    ? signal.reason.message
    : typeof signal.reason === 'string'
      ? signal.reason
      : '';
  if (reason === 'task_watchdog_timeout') {
    throw new Error('任务执行超时，已自动终止。');
  }
  if (reason === 'loop_poll_timeout') {
    throw new Error('任务运行时间过长，已自动停止。');
  }
  // user_cancelled and any unknown/missing reason fall back to the prior wire
  // message so existing catch blocks (and renderer copy) keep working.
  throw new Error('task cancelled');
}

const DESKTOP_MODEL_TOOL_LOOP_FINALIZATION_PROMPT = [
  '工具调用预算已用尽。不要再调用工具。',
  '请基于以上所有工具结果直接给出最终答复。',
  '如果原始任务要求 JSON 或特定 schema，必须严格按原始 schema 输出。',
  '不要输出 Markdown 代码块，除非原始任务明确要求 Markdown 正文。',
].join('\n');

async function streamDesktopToolLoopFinalization(input: {
  modelPhysicalScope?: DesktopModelPhysicalScope;
  prepareRequest?: DesktopTaskRequestPreparer;
  projectModel?: ProjectAgentModel;
  beforeRequest?: () => Promise<void>;
  deadline?: number;
  adapter: Pick<ModelAdapter, 'stream'> & Partial<Pick<ModelAdapter, 'getObservationRequestPreview'|'getModelName'>> & { getCapabilities?(): Partial<import('../../src/ai/runtime/model-capabilities.js').ModelCapabilities> };
  apiMessages: Message[];
  systemPrompt: string;
  streamOptions: StreamOptions;
  signal: AbortSignal;
  sessionId: string;
  turnId: string;
  intentId: string;
  stepId: string;
  emitRuntimeEvent: TaskRunnerInput['emitRuntimeEvent'];
  onUsage?: (chunk: Extract<StreamChunk, { type: 'usage' }>, invocationId: string) => void | Promise<void>;
}): Promise<{ reply: string; assistantBlocks: MessageBlock[] }> {
  const local = !input.modelPhysicalScope;
  const modelPhysicalScope = input.modelPhysicalScope ?? createDesktopModelPhysicalScope();
  let modelBodyFailure: { error: unknown } | undefined;
  const body = async () => {
  const assistantBlocks: MessageBlock[] = [];
  let reply = '';
  let providerInvocationId = `inv_${randomUUID()}`;
  let connectionRecovering = false;
  const request = {
    prepareRequest: input.prepareRequest,
    deadline: input.deadline ?? Infinity,
    onRecovery: async () => {
      assistantBlocks.length = 0;
      connectionRecovering = true;
      await input.emitRuntimeEvent({type:'execution_health',sessionId:input.sessionId,turnId:input.turnId,state:'recovering'});
    },
    onInvocation: (id: string) => { providerInvocationId = id; },
    beforeRequest: input.beforeRequest,
    adapter: input.adapter,
    messages: input.apiMessages,
    tools: [],
    systemPrompt: input.systemPrompt,
    options: input.streamOptions,
    invocationId: providerInvocationId,
  };
  const modelPhysicalRun = admitDesktopModelPhysicalRead(modelPhysicalScope);
    try {
    for await (const chunk of (input.projectModel ? input.projectModel.stream : streamDesktopTaskRecovery)(request, modelPhysicalRun)) {
    if (chunk.type === 'usage') {
      const captured = input.onUsage?.(chunk, providerInvocationId);
      if (captured) await captured;
      continue;
    }
    throwIfAborted(input.signal);
    if (connectionRecovering) {
      connectionRecovering = false;
      await input.emitRuntimeEvent({type:'execution_health',sessionId:input.sessionId,turnId:input.turnId,state:'running'});
    }
    if (chunk.type === 'text') {
      const lastBlock = assistantBlocks[assistantBlocks.length - 1];
      if (lastBlock?.type === 'text') {
        lastBlock.text += chunk.delta;
      } else {
        assistantBlocks.push({ type: 'text', text: chunk.delta });
      }
      reply += chunk.delta;
      await input.emitRuntimeEvent({
        type: 'assistant_delta',
        sessionId: input.sessionId,
        turnId: input.turnId,
        intentId: input.intentId,
        stepId: input.stepId,
        delta: chunk.delta,
      });
    } else if (chunk.type === 'thinking') {
      const lastBlock = assistantBlocks[assistantBlocks.length - 1];
      if (lastBlock?.type === 'thinking') {
        lastBlock.thinking += chunk.delta;
      } else {
        assistantBlocks.push({ type: 'thinking', thinking: chunk.delta });
      }
    } else if (chunk.type === 'tool_use') {
      // Model violated the "no tools" finalization constraint. Ignore the tool
      // call and keep consuming the stream — accumulated text is sufficient.
      continue;
    }
  }
    } finally { modelPhysicalRun.finish(); }
  throwIfAborted(input.signal);
  if (!reply.trim()) {
    throw new Error('desktop_tool_loop_finalization_empty');
  }
  return { reply, assistantBlocks };

  };
  let result: { reply: string; assistantBlocks: MessageBlock[] } | undefined;
  try { result = await body(); } catch (error) { modelBodyFailure = { error }; }
  if (local) try { await closeDesktopModelPhysicalScope(modelPhysicalScope, input.signal.reason); }
  catch (physicalError) {
    if (modelBodyFailure && modelBodyFailure.error !== physicalError) throw new AggregateError([modelBodyFailure.error, physicalError], 'desktop_finalization_business_and_model_cleanup_failed', { cause: modelBodyFailure.error });
    throw physicalError;
  }
  if (modelBodyFailure) throw modelBodyFailure.error;
  return result!;
}

interface ToolLoopStrategies {
  compact: {
    enabled: boolean;
    shouldCompact: (inputTokens: number) => boolean;
    doCompact: (msgs: Message[], streamOptions?: StreamOptions) => Promise<void>;
  };
  buildApiView: (msgs: Message[]) => Message[];
  processToolResult: (result: string, toolName: string, toolUseId: string) => string;
  trackAutoProgress: boolean;
  trackReferenceReads: boolean;
  emitSkillArtifactTrace: boolean;
}

interface ToolLoopContext {
  modelPhysicalScope?: DesktopModelPhysicalScope;
  observationBinding?: DesktopObservationBinding;
  /** Not ready until main-owned protected-history durability is available. */
  observationOwner?: ObservationSessionOwner;
  metricsSurface?: 'desktop' | 'desktop-child';
  beforeManagedTurnSeal?(reply:string):Promise<void>;
  finalizeProjectProposal?: (proposal: Record<string, unknown>) => Promise<Record<string, unknown> | undefined>;
  projectModel?: ProjectAgentModel;
  canResumeSummary?: () => boolean;
  adapter: Pick<ModelAdapter, 'stream'> & Partial<Pick<ModelAdapter, 'getObservationRequestPreview'|'getModelName'>> & { getCapabilities?(): Partial<import('../../src/ai/runtime/model-capabilities.js').ModelCapabilities> };
  systemPrompt: string;
  messages: Message[];
  allToolDefs: ToolDefinition[];
  registry: ToolRegistry;
  invocationOptions?: ModelInvocationOptions;
  signal: AbortSignal;
  taskDeadline: number;
  sessionId: string;
  turnId: string;
  intentId: string;
  stepId: string;
  taskId: string;
  executionScope?: TaskRunnerInput['executionScope'];
  materials: MaterialRecord[];
  materialRegistry?: MaterialRegistry;
  officeToMarkdown?: (input: { absolutePath: string; maxOutputChars: number; signal?: AbortSignal }) => Promise<OfficeTextExtractionResult>;
  emitRuntimeEvent: TaskRunnerInput['emitRuntimeEvent'];
  skillInvocation: SkillInvocation | null;
  skillCatalog: SkillCatalog;
  dataRoot: string;
  /** Per-invocation execution directory; ordinary legacy runners keep dataRoot. */
  cwd?: string;
  taskStartTime: number;
  strategies: ToolLoopStrategies;
  maxIterations?: number;
  onUsage?: (inputTokens: number, outputTokens: number, usageId?: string) => void | Promise<void>;
  mailbox?: DesktopMailboxPort;
  roomExecution?:{authorize:()=>Promise<void>;takePendingInput?:()=>string|undefined;takePendingImages?:()=>MessageBlock[]};
  onActivity?: (activity: { phase: 'model' | 'thinking' | 'tool'; toolName?: string }) => void;
}

interface ArtifactWorkspaceToolAck {
  artifactId: string;
  artifactPath: string;
  title: string;
  kind: string;
  mimeType?: string;
  creator: string;
}

interface KSwarmWorkflowStatusArtifact {
  artifactId: string;
  filePath: string;
  label: string;
  kind: string;
  creator: string;
}

interface HistoricalWorkflowStatusLookup {
  projectId: string;
  workflowRunId: string;
  turnId: string;
}

function isPathInside(rootPath: string, candidatePath: string): boolean {
  const relativePath = relative(rootPath, candidatePath);
  return Boolean(relativePath)
    && relativePath !== '..'
    && !relativePath.startsWith(`..${sep}`)
    && !isAbsolute(relativePath);
}

function resolveKSwarmWorkflowStatusArtifacts(
  toolName: string,
  result: string,
): KSwarmWorkflowStatusArtifact[] {
  if (!isToolName(toolName, 'get_dynamic_workflow_status')) return [];

  let parsed: unknown;
  try {
    parsed = JSON.parse(result);
  } catch {
    return [];
  }
  if (!isRecord(parsed) || parsed.ok !== true) return [];

  const workflowRunId = readString(parsed.workflowRunId);
  const scriptResult = isRecord(parsed.scriptResult) ? parsed.scriptResult : null;
  if (!workflowRunId || !scriptResult || !Array.isArray(scriptResult.artifacts)) return [];

  const workspaceValue = readString(parsed.projectWorkspacePath)
    || readString(scriptResult.workspacePath)
    || readString(scriptResult.workFolder);
  if (!workspaceValue || !isAbsolute(workspaceValue)) return [];

  let workspacePath: string;
  let artifactsPath: string;
  try {
    workspacePath = realpathSync(resolve(workspaceValue));
    artifactsPath = realpathSync(join(workspacePath, 'artifacts'));
    if (!statSync(artifactsPath).isDirectory() || !isPathInside(workspacePath, artifactsPath)) return [];
  } catch {
    return [];
  }

  const creator = readString(scriptResult.producerAgent) || 'kswarm';
  const seen = new Set<string>();
  const artifacts: KSwarmWorkflowStatusArtifact[] = [];

  for (const rawArtifact of scriptResult.artifacts) {
    if (!isRecord(rawArtifact)) continue;
    const rawPath = readString(rawArtifact.path) || readString(rawArtifact.relativePath);
    if (!rawPath || rawPath.includes('\0')) continue;

    try {
      const candidatePath = isAbsolute(rawPath)
        ? resolve(rawPath)
        : resolve(workspacePath, rawPath);
      const filePath = realpathSync(candidatePath);
      if (!isPathInside(artifactsPath, filePath) || !statSync(filePath).isFile()) continue;
      accessSync(filePath, fsConstants.R_OK);
      if (seen.has(filePath)) continue;
      seen.add(filePath);

      const label = readString(rawArtifact.label) || basename(filePath);
      const kind = inferKSwarmArtifactKind(
        readString(rawArtifact.kind) || kindFromFilename(label),
        label,
      );
      const artifactId = `artifact_${createHash('sha256')
        .update(`${workflowRunId}:${filePath}`)
        .digest('hex')
        .slice(0, 20)}`;
      artifacts.push({ artifactId, filePath, label, kind, creator });
    } catch {
      // Each artifact is independently default-denied.
    }
  }

  return artifacts;
}

function findHistoricalWorkflowStatusLookup(snapshot: TaskSnapshot): HistoricalWorkflowStatusLookup | null {
  if (snapshot.status !== 'completed') return null;
  if (snapshot.events.some(event => event.type === 'artifact_recorded')) return null;
  if ((snapshot.result?.artifacts?.length ?? 0) > 0) return null;
  if (snapshot.events.some(event => event.type === 'result' && event.result.artifacts.length > 0)) return null;

  const successfulResults = new Set(
    snapshot.events.flatMap(event => (
      event.type === 'canvas_tool_result'
      && event.ok
      && isToolName(event.toolName, 'get_dynamic_workflow_status')
        ? [event.toolUseId]
        : []
    )),
  );
  for (let index = snapshot.events.length - 1; index >= 0; index -= 1) {
    const event = snapshot.events[index];
    if (
      event.type !== 'canvas_tool_call'
      || !isToolName(event.toolName, 'get_dynamic_workflow_status')
      || !successfulResults.has(event.toolUseId)
      || !isRecord(event.input)
    ) {
      continue;
    }
    const projectId = readString(event.input.projectId);
    const workflowRunId = readString(event.input.workflowRunId);
    if (!projectId || !workflowRunId) continue;
    const canvasMarker = ':canvas:';
    const markerIndex = event.eventId.indexOf(canvasMarker);
    return {
      projectId,
      workflowRunId,
      turnId: markerIndex > 0
        ? event.eventId.slice(0, markerIndex)
        : `recovered-${workflowRunId}`,
    };
  }
  return null;
}

async function recoverHistoricalWorkflowStatusArtifacts(input: {
  snapshot: TaskSnapshot;
  lookup: HistoricalWorkflowStatusLookup;
  statusTool: Tool;
}): Promise<TaskSnapshot> {
  try {
    const result = await withWorkflowArtifactRecoveryTimeout(
      Promise.resolve(input.statusTool.execute({
        projectId: input.lookup.projectId,
        workflowRunId: input.lookup.workflowRunId,
      })),
      3_000,
    );
    const artifacts = resolveKSwarmWorkflowStatusArtifacts('get_dynamic_workflow_status', result);
    if (artifacts.length === 0) return input.snapshot;
    return overlayHistoricalWorkflowArtifacts(input.snapshot, input.lookup.turnId, artifacts);
  } catch {
    return input.snapshot;
  }
}

function withWorkflowArtifactRecoveryTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<T>((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error('workflow_artifact_recovery_timeout')), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}

function overlayHistoricalWorkflowArtifacts(
  snapshot: TaskSnapshot,
  turnId: string,
  artifacts: KSwarmWorkflowStatusArtifact[],
): TaskSnapshot {
  let resultIndex = -1;
  for (let index = snapshot.events.length - 1; index >= 0; index -= 1) {
    if (snapshot.events[index].type === 'result') {
      resultIndex = index;
      break;
    }
  }
  if (resultIndex < 0) return snapshot;

  const runtimeEvents: RuntimeEvent[] = artifacts.map(artifact => ({
    type: 'artifact_recorded',
    sessionId: snapshot.sessionId,
    turnId,
    intentId: 'historical-workflow-artifact-recovery',
    stageId: 'historical-workflow-artifact-recovery',
    artifactId: artifact.artifactId,
    label: artifact.label,
    kind: artifact.kind,
    path: artifact.filePath,
    creator: artifact.creator,
  }));
  const artifactEvents = projectRuntimeEventsToDesktopEvents({
    taskId: snapshot.taskId,
    events: runtimeEvents,
  }).filter((event): event is Extract<DesktopTaskEvent, { type: 'artifact_recorded' }> => (
    event.type === 'artifact_recorded'
  ));
  if (artifactEvents.length === 0) return snapshot;

  const artifactSummaries: ArtifactSummary[] = artifactEvents.map(event => ({
    artifactId: event.artifactId,
    kind: event.kind as ArtifactSummary['kind'],
    title: event.label,
    createdAt: event.turnId,
    previewAvailable: event.previewAvailable,
    filePath: event.filePath,
    creator: event.creator ?? 'kswarm',
    ...(event.mimeType ? { mimeType: event.mimeType } : {}),
  }));
  const resultEvent = snapshot.events[resultIndex];
  if (resultEvent.type !== 'result') return snapshot;
  const recoveredResult = {
    ...resultEvent.result,
    artifacts: [...resultEvent.result.artifacts, ...artifactSummaries],
  };
  return {
    ...snapshot,
    events: [
      ...snapshot.events.slice(0, resultIndex),
      ...artifactEvents,
      { ...resultEvent, result: recoveredResult },
      ...snapshot.events.slice(resultIndex + 1),
    ],
    result: snapshot.result
      ? { ...snapshot.result, artifacts: [...snapshot.result.artifacts, ...artifactSummaries] }
      : recoveredResult,
  };
}

function parseArtifactWorkspaceToolAck(result: string): ArtifactWorkspaceToolAck | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(result);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
  const record = parsed as Record<string, unknown>;
  if (record.ok !== true || record.artifactWorkspaceArtifact !== true) return null;
  const artifactId = typeof record.artifactId === 'string' ? record.artifactId.trim() : '';
  const artifactPath = typeof record.artifactPath === 'string' ? record.artifactPath.trim() : '';
  const kind = typeof record.kind === 'string' ? record.kind.trim() : '';
  if (!artifactId || !artifactPath || !kind) return null;
  const title = typeof record.title === 'string' && record.title.trim()
    ? record.title.trim()
    : basename(artifactPath) || artifactPath;
  return {
    artifactId,
    artifactPath,
    title,
    kind,
    ...(typeof record.mimeType === 'string' && record.mimeType.trim() ? { mimeType: record.mimeType.trim() } : {}),
    creator: typeof record.creator === 'string' && record.creator.trim() ? record.creator.trim() : 'agent',
  };
}

export async function runDesktopToolLoop(ctx: ToolLoopContext): Promise<Awaited<ReturnType<typeof runDesktopToolLoopBody>>> {
  if (ctx.observationOwner || ctx.observationBinding) {
    if (ctx.roomExecution || ctx.executionScope || ctx.projectModel || ctx.strategies?.compact.enabled) throw new Error('SOL_PI_DESKTOP_RESTRICTED_OBSERVATION_NOT_READY');
    if (!ctx.observationBinding) throw new Error('SOL_PI_DESKTOP_DURABLE_OBSERVATION_NOT_READY');
    const binding = requireDesktopObservationBinding(ctx.observationBinding, ctx.taskId, ctx.registry);
    const context=binding.delegated?.context??binding.groupReference?.context;
    if((ctx.mailbox&&ctx.mailbox!==context?.mailbox)||(ctx.metricsSurface==='desktop-child'&&!binding.delegated))throw Error('SOL_PI_DESKTOP_RESTRICTED_OBSERVATION_NOT_READY');
    if (ctx.observationOwner && ctx.observationOwner !== binding.owner) throw new Error('SOL_PI_DESKTOP_OBSERVATION_NOT_READY');
    ctx = { ...ctx, observationOwner: binding.owner };
  }
  const local = !ctx.modelPhysicalScope;
  const modelPhysicalScope = ctx.modelPhysicalScope ?? createDesktopModelPhysicalScope();
  ctx = { ...ctx, modelPhysicalScope };
  let modelBodyFailure: { error: unknown } | undefined;
  let modelResult: Awaited<ReturnType<typeof runDesktopToolLoopBody>> | undefined;
  try { modelResult = await withObservationExecutionOwner(ctx.observationOwner, () =>
    withObservationMetrics(ctx.metricsSurface ?? 'desktop', () => runDesktopToolLoopOwned(ctx))); }
  catch (error) { modelBodyFailure = { error }; }
  if (local) try { await closeDesktopModelPhysicalScope(modelPhysicalScope, ctx.signal.reason); }
  catch (physicalError) {
    if (modelBodyFailure && modelBodyFailure.error !== physicalError) throw new AggregateError([modelBodyFailure.error, physicalError], 'desktop_local_business_and_model_cleanup_failed', { cause: modelBodyFailure.error });
    throw physicalError;
  }
  if (modelBodyFailure) throw modelBodyFailure.error;
  return modelResult!;
}

function observationRequestPreparer(ctx: ToolLoopContext): DesktopTaskRequestPreparer | undefined {
  if (!ctx.observationBinding) return undefined;
  return async input => {
    const binding = requireDesktopObservationBinding(ctx.observationBinding!, ctx.taskId, ctx.registry);
    binding.session.replaceMessages(ctx.messages);
    const prepared = await binding.owner.prepareRequest({ logicalInvocationId: input.invocationId,
      messages: input.messages, tools: input.tools, systemPrompt: input.systemPrompt, options: input.options,
      requestPreview: ctx.adapter.getObservationRequestPreview?.bind(ctx.adapter) });
    ctx.signal.throwIfAborted();
    if(Date.now()>=ctx.taskDeadline)throw new Error('desktop_tool_loop_deadline_exceeded');
    binding.owner.assertSession(binding.session);
    return { ...input, messages: prepared.messages, options: prepared.providerDisclosure
      ? { ...input.options, providerDisclosure: prepared.providerDisclosure } : input.options };
  };
}

async function runDesktopToolLoopOwned(ctx: ToolLoopContext): Promise<Awaited<ReturnType<typeof runDesktopToolLoopBody>>> {
  try {
    return await runDesktopToolLoopBody(ctx);
  } catch (error) {
    const interrupted = ctx.signal.aborted || error instanceof Error && error.name === 'AbortError';
    try {
      await ctx.mailbox?.trySealTurn({ outcome: interrupted ? 'interrupted' : 'failed' });
    } catch (finishError) {
      // The mailbox owner freezes/aborts on persistence failure. Preserve the
      // original AbortError for the host cancellation path, never normalize it.
      if (!interrupted) throw new AggregateError([error, finishError], 'multi_agent_finish_failed');
    }
    if (ctx.mailbox && ctx.signal.aborted) {
      // The legacy ordinary loop wraps cancellation in Error("task cancelled").
      // A managed child must preserve interruption rather than publish failure.
      const reason = ctx.signal.reason;
      if (reason instanceof Error && reason.name === 'AbortError') throw reason;
      throw new DOMException(reason instanceof Error ? reason.message : 'multi-agent turn aborted', 'AbortError');
    }
    throw error;
  }
}

async function prepareDesktopLoopRequest(ctx: ToolLoopContext, streamOptions: StreamOptions, canCompact: boolean, inputTokens: number): Promise<Message[]> {
  throwIfAborted(ctx.signal);
  await ctx.roomExecution?.authorize();
  const roomInput=ctx.roomExecution?.takePendingInput?.();
  if(roomInput)ctx.messages.push({role:'user',content:[{type:'text',text:roomInput}]});
  if (Date.now() > ctx.taskDeadline) throw new Error('desktop_tool_loop_deadline_exceeded');
  if(ctx.observationBinding){
    const binding=requireDesktopObservationBinding(ctx.observationBinding,ctx.taskId,ctx.registry);
    const mailboxBoundary=binding.semanticCompactionOwner && ctx.mailbox
      ? await captureDesktopMailboxSemanticBoundary(ctx.mailbox) : undefined;
    if(binding.semanticCompactionOwner && (!ctx.mailbox || mailboxBoundary) && takeDesktopSemanticBoundary(ctx.observationBinding)){
      if(typeof ctx.adapter.getModelName!=='function')throw Error('SEMANTIC_PROVIDER_NOT_READY');
      binding.session.replaceMessages(ctx.messages);
      const signal=AbortSignal.any([ctx.signal,AbortSignal.timeout(Math.max(1,Math.min(2147483647,ctx.taskDeadline-Date.now())))]);
      let outcome:import('../../src/runtime/sol-pi/semantic-compaction-owner.js').SemanticCompactionOutcome;
      const reservationsBefore=binding.session.exportSnapshot().semanticCompaction?.reservations.length??0;
      try{outcome=await binding.semanticCompactionOwner.tryCompact({invocationId:`${ctx.taskId}:${ctx.turnId}`,
        sourceRevision:binding.session.planCompaction().sourceRevision,adapter:ctx.adapter as ModelAdapter,
        tools:ctx.allToolDefs,systemPrompt:ctx.systemPrompt,signal,assertBoundaryCurrent:mailboxBoundary});}
      catch(error){
        const attempted=(binding.session.exportSnapshot().semanticCompaction?.reservations.length??0)>reservationsBefore;
        if(error instanceof Error && error.message==='semantic_mailbox_changed')outcome={status:'skipped',attempted,reason:'stale_mailbox_boundary',economicAdmission:'not-passed'};
        else {recordDesktopSemanticOutcome(ctx.observationBinding,{status:'failed',attempted,reason:'operation_failed',economicAdmission:'not-passed'});throw error;}
      }
      recordDesktopSemanticOutcome(ctx.observationBinding,outcome);
      signal.throwIfAborted();
      if(outcome.status==='compacted')ctx.messages.splice(0,ctx.messages.length,...binding.session.getMessages());
    }
  }
  if (canCompact && ctx.strategies.compact.enabled && ctx.strategies.compact.shouldCompact(inputTokens)) {
    await ctx.strategies.compact.doCompact(ctx.messages, streamOptions);
  }
  throwIfAborted(ctx.signal);
  const batch = await ctx.mailbox?.drainInput();
  let restore = () => {};
  let confirmed = false;
  try {
    throwIfAborted(ctx.signal);
    if (batch?.messages.length) {
      const block: MessageBlock = { type: 'text', text: `<inter_agent_messages>\n${JSON.stringify(batch.messages.map(message => ({
        messageId: message.messageId, sender: message.sender, kind: message.kind, text: message.preview,
      })))}\n</inter_agent_messages>` };
      const lastIndex = ctx.messages.length - 1;
      const previous = ctx.messages[lastIndex];
      if (previous?.role === 'user') {
        ctx.messages[lastIndex] = { ...previous, content: [block, ...previous.content] };
        restore = () => { ctx.messages[lastIndex] = previous; };
      } else {
        ctx.messages.push({ role: 'user', content: [block] });
        restore = () => { ctx.messages.pop(); };
      }
    }
    // This exact view is the one whose input claim is committed. Do not compact,
    // rebuild or inject input between confirmApplied and the provider request.
    const apiMessages = ctx.strategies.buildApiView(ctx.messages);
    throwIfAborted(ctx.signal);
    if (batch?.claimId) {
      if(ctx.observationBinding){const bound=requireDesktopObservationBinding(ctx.observationBinding,ctx.taskId,ctx.registry);bound.session.replaceMessages(ctx.messages);await bound.owner.publishCurrentHistory?.({strictPrivateProtocol:isStrictKimiK3Adapter(ctx.adapter)});}
      await ctx.mailbox!.confirmApplied(batch.claimId);
      confirmed = true;
    }
    throwIfAborted(ctx.signal);
    return apiMessages;
  } catch (error) {
    if (!confirmed) {
      restore();
      if (batch?.claimId) await ctx.mailbox!.returnClaim(batch.claimId);
    }
    throw error;
  }
}

async function runDesktopToolLoopBody(ctx: ToolLoopContext): Promise<{
  reply: string;
  totalToolCalls: number;
  totalInputTokens: number;
  totalOutputTokens: number;
  referenceReads: number;
  autoSteps: Array<{ id: string; label: string; status: string }>;
  skillNamesDetected: string[];
  skillTriggerType: 'slash_command' | 'tool_call' | 'auto';
  skillInvocation: SkillInvocation | null;
}> {
  const streamOptions: StreamOptions = {
    ...ctx.invocationOptions,
    signal: ctx.signal,
  };
  let reply = '';
  let iteration = 0;
  let totalToolCalls = 0;
  let planEmitted = false;
  const autoSteps: Array<{ id: string; label: string; status: string }> = [];
  let referenceReads = 0;
  let lastRequestInputTokens = 0;
  let toolResultsAwaitingFinalResponse = false;
  let totalInputTokens = 0;
  let totalOutputTokens = 0;
  let { skillInvocation } = ctx;
  let skillNamesDetected: string[] = [];
  let skillTriggerType: 'slash_command' | 'tool_call' | 'auto' = 'auto';
  const budget = resolveDesktopToolLoopBudget(ctx.maxIterations);
  const maxIterations = budget.limit ?? Number.POSITIVE_INFINITY;
  let finishedNormally = false;
  let summaryRecoveryMode = false;

  if (skillInvocation) {
    appendTrace(ctx.dataRoot, {
      ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
      stageId: skillInvocation.stageId, iteration: 1, event: 'model_turn_start',
    });
  }

  while (iteration < maxIterations) {
    const runIteration=async():Promise<boolean>=>{
    throwIfAborted(ctx.signal);
    if (Date.now() > ctx.taskDeadline) throw new Error('任务超时，可能是网络不稳定或模型响应过慢。请检查网络后重试。');
    iteration++;

    if (skillInvocation) {
      const budgetResult = checkBudget(skillInvocation, iteration, totalToolCalls, referenceReads, totalInputTokens, ctx.dataRoot, maxIterations);
      if (!budgetResult.ok) {
        appendTrace(ctx.dataRoot, {
          ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
          stageId: skillInvocation.stageId, iteration, event: 'model_turn_end',
          durationMs: Date.now() - ctx.taskStartTime, details: `stopped: ${budgetResult.reason}`,
        });
        return false;
      }
    }

    if (skillInvocation && iteration > 1) {
      appendTrace(ctx.dataRoot, {
        ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
        stageId: skillInvocation.stageId, iteration, event: 'model_turn_start',
      });
    }

    const assistantBlocks: MessageBlock[] = [];

    await assertNativeRegistryCheckpointCurrent(ctx.registry);
    const apiMessages = await prepareDesktopLoopRequest(ctx, streamOptions, iteration > 1, lastRequestInputTokens);
    lastRequestInputTokens = 0;
    let providerInvocationId = `inv_${randomUUID()}`;
    let connectionRecovering = false;
    const modelPhysicalRun = admitDesktopModelPhysicalRead(ctx.modelPhysicalScope!);
    try {
    for await (const chunk of (ctx.projectModel ? ctx.projectModel.stream : streamDesktopTaskRecovery)({
      adapter: ctx.adapter,
      prepareRequest: observationRequestPreparer(ctx),
      beforeRequest: async()=>{await assertNativeRegistryCheckpointCurrent(ctx.registry);await ctx.roomExecution?.authorize();},
      messages: apiMessages,
      tools: ctx.allToolDefs,
      systemPrompt: ctx.systemPrompt,
      options: streamOptions,
      invocationId: providerInvocationId,
      deadline: ctx.taskDeadline,
      summaryOnly: summaryRecoveryMode,
      canRecover: ctx.canResumeSummary,
      onRecovery: async (notice?: { summaryOnly: boolean }) => {
        summaryRecoveryMode = notice?.summaryOnly ?? true;
        connectionRecovering = true;
        assistantBlocks.length = 0;
        await ctx.emitRuntimeEvent({type:'execution_health',sessionId:ctx.sessionId,turnId:ctx.turnId,state:'recovering'});
      },
      onInvocation: id => { providerInvocationId = id; },
    }, modelPhysicalRun)) {
      if (chunk.type === 'usage') {
        try {
          const inputTkns = chunk.usage?.inputTokens ?? 0;
          lastRequestInputTokens = inputTkns;
          totalInputTokens += inputTkns;
          totalOutputTokens += chunk.usage?.outputTokens ?? 0;
          const captured = ctx.onUsage?.(inputTkns, chunk.usage?.outputTokens ?? 0, providerInvocationId);
          if (captured) await captured;
        } catch (e) { if (ctx.mailbox) throw e; console.warn('[usage] token capture failed:', (e as Error).message) }
        continue;
      }
      throwIfAborted(ctx.signal);
      if (connectionRecovering) {
        connectionRecovering = false;
        await ctx.emitRuntimeEvent({type:'execution_health',sessionId:ctx.sessionId,turnId:ctx.turnId,state:'running'});
      }
      await ctx.emitRuntimeEvent({type:'execution_progress',sessionId:ctx.sessionId,turnId:ctx.turnId});
      ctx.onActivity?.({ phase: chunk.type === 'thinking' ? 'thinking' : chunk.type === 'tool_use' ? 'tool' : 'model',
        ...(chunk.type === 'tool_use' ? { toolName: chunk.name } : {}) });
      if (chunk.type === 'text') {
        const lastBlock = assistantBlocks[assistantBlocks.length - 1];
        if (lastBlock?.type === 'text') {
          lastBlock.text += chunk.delta;
        } else {
          assistantBlocks.push({ type: 'text', text: chunk.delta });
        }
        reply += chunk.delta;
        await ctx.emitRuntimeEvent({ type: 'assistant_delta', sessionId: ctx.sessionId, turnId: ctx.turnId, intentId: ctx.intentId, stepId: ctx.stepId, delta: chunk.delta });
      } else if (chunk.type === 'tool_use') {
        assistantBlocks.push({ type: 'tool_use', id: chunk.id, name: chunk.name, input: chunk.input });
      } else if (chunk.type === 'thinking') {
        const lastBlock = assistantBlocks[assistantBlocks.length - 1];
        if (
          lastBlock?.type === 'thinking'
          && JSON.stringify(lastBlock.reasoningProvenance)
            === JSON.stringify(chunk.reasoningProvenance)
        ) {
          lastBlock.thinking += chunk.delta;
        } else {
          assistantBlocks.push({
            type: 'thinking',
            thinking: chunk.delta,
            ...(chunk.reasoningProvenance
              ? { reasoningProvenance: chunk.reasoningProvenance }
              : {}),
          });
        }
      }
    }
    } finally { modelPhysicalRun.finish(); }
    throwIfAborted(ctx.signal);
    ctx.messages.push({ role: 'assistant', content: assistantBlocks });
    const toolCalls = assistantBlocks.filter((b): b is ToolCall => b.type === 'tool_use');
    if (toolCalls.length === 0) {
      const finalSession=ctx.observationBinding?requireDesktopObservationBinding(ctx.observationBinding,ctx.taskId,ctx.registry).session:undefined;
      const publishFinalHistory=async()=>{
        if(!ctx.observationOwner||!hasCompoundFinalPublicationConsumer(ctx.observationOwner,ctx.turnId))return;
        if(!finalSession)throw Error('SOL_PI_DESKTOP_FINAL_PUBLICATION_BINDING');
        if(JSON.stringify(finalSession.exportSnapshot().messages)!==JSON.stringify(ctx.messages))finalSession.replaceMessages(ctx.messages);
        if(finalSession.getPublishedHistoryBasis()!==computeSessionHistoryDigest(finalSession.exportSnapshot()))await ctx.registry.publishCompoundHistory();
      };
      if (assistantBlocks.some((block) => block.type === 'text' && block.text.trim())) {
        toolResultsAwaitingFinalResponse = false;
      }
      if (ctx.mailbox && !toolResultsAwaitingFinalResponse) {
        await ctx.beforeManagedTurnSeal?.(reply);
        await publishFinalHistory();
        const decision = await ctx.mailbox.trySealTurn({ limitReached: iteration >= maxIterations });
        if (decision.kind === 'continue') return true;
        if (decision.kind === 'limit_reached') throw new DesktopMultiAgentIterationLimitError(reply, maxIterations, iteration, budget.source);
        finishedNormally = true;
      }
      if (!ctx.mailbox && !toolResultsAwaitingFinalResponse) {await publishFinalHistory();finishedNormally = true;}
      if(finishedNormally&&ctx.observationOwner&&hasCompoundFinalPublicationConsumer(ctx.observationOwner,ctx.turnId)){
        await publishCompoundFinalPublication(ctx.observationOwner,ctx.turnId);
      }
      return false;
    }
    const toolResults: MessageBlock[] = [];
    for (const toolCall of toolCalls) {
      throwIfAborted(ctx.signal);
      totalToolCalls++;
      const runtimeToolInput = attachRuntimeToolRequestScope(toolCall.name, toolCall.input, ctx.sessionId);
      const isInternalTool = toolCall.name === 'report_progress' || toolCall.name === 'skill' || toolCall.name === 'skill_bundle_refs' || toolCall.name === 'skill_list';
      if (!isInternalTool && !planEmitted) {
        planEmitted = true;
      }
      await ctx.emitRuntimeEvent({ type: 'pre_tool_use', sessionId: ctx.sessionId, turnId: ctx.turnId, toolName: toolCall.name, toolInput: runtimeToolInput, toolUseId: toolCall.id });

      if (skillInvocation) {
        appendTrace(ctx.dataRoot, {
          ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
          stageId: skillInvocation.stageId, iteration, event: 'tool_start',
          toolName: toolCall.name,
        });
      }

      if (ctx.strategies.trackReferenceReads && isToolName(toolCall.name, 'read')) {
        referenceReads++;
        if (skillInvocation) {
          appendTrace(ctx.dataRoot, {
            ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
            stageId: skillInvocation.stageId, iteration, event: 'tool_end',
            toolName: 'read_reference', details: String((toolCall.input as Record<string, unknown>).file_path || ''),
          });
        }
      }

      if (toolCall.name === 'skill') {
        try {
          const extracted = extractSkillNames(toolCall.input as Record<string, unknown>);
          if (skillNamesDetected.length === 0 || skillTriggerType === 'auto') {
            skillNamesDetected = extracted;
            if (skillTriggerType === 'auto') skillTriggerType = 'tool_call';
            if (!skillInvocation) {
              skillInvocation = buildSkillInvocation(extracted[0], ctx.skillCatalog, ctx.sessionId);
              if (skillInvocation) {
                appendTrace(ctx.dataRoot, {
                  ts: Date.now(), taskId: ctx.sessionId, skillName: extracted[0],
                  event: 'skill_invoked', details: 'tool_call',
                });
              }
            }
          }
        } catch { /* non-critical */ }
      }
      const toolStartedAt = Date.now();
      if (ctx.observationBinding) requireDesktopObservationBinding(ctx.observationBinding, ctx.taskId, ctx.registry).session.replaceMessages(ctx.messages);
      let observationProjectionFailure: unknown;
      const rawToolContext: ToolExecutionContext = {
        ...(ctx.observationOwner ? {
          observationCollector: ctx.observationOwner.collectorFor(toolCall.id),
          observationProvenance: () => ctx.observationOwner!.getResultProvenance(toolCall.id),
          projectObservationResult: async (nativeResult: string) => {
            const ok = isSuccessfulModelToolResult(nativeResult);
            try { return await ctx.observationOwner!.projectToolResult(toolCall.id, nativeResult); }
            catch (error) { observationProjectionFailure = error; return `${ok ? '' : 'Error: '}[tool execution ${ok ? 'completed' : 'failed'}; observation disclosure blocked]`; }
          },
        } : {}),
        taskId: ctx.taskId,
        toolInvocationId: toolCall.id,
        runtimeFactSink: {
          emit(fact) {
            void ctx.emitRuntimeEvent({
              type: 'tool_execution_fact',
              sessionId: ctx.sessionId,
              turnId: ctx.turnId,
              ...fact,
            });
          },
        },
        executionScope: ctx.executionScope,
        session: {
          sessionId: ctx.sessionId,
          cwd: ctx.cwd ?? ctx.dataRoot,
          createdAt: ctx.taskStartTime,
          updatedAt: Date.now(),
          lineage: [ctx.sessionId],
          messages: ctx.messages.map((message) => ({
            role: message.role,
            content: message.content.map((block) => ({ ...block })),
          })),
          usage: { inputTokens: 0, outputTokens: 0 },
          compactions: [],
          memoryRefs: [],
          approvalRefs: [],
          backgroundJobRefs: [],
        },
        messages: ctx.messages.map((message) => ({
          role: message.role,
          content: message.content.map((block) => ({ ...block })),
        })),
        systemPrompt: ctx.systemPrompt,
        toolDefinitions: ctx.allToolDefs.map((definition) => ({ ...definition })),
        signal: ctx.signal,
      };
      if (ctx.observationBinding) rawToolContext.session = requireDesktopObservationBinding(ctx.observationBinding, ctx.taskId, ctx.registry).session.exportSnapshot();
      const projectedToolContext = isStrictKimiK3Adapter(ctx.adapter)
        ? projectStrictToolExecutionContext(rawToolContext)
        : rawToolContext;
      const modelSupportsImageInput = ctx.adapter.getCapabilities?.().supportsImageInput === true;
      const toolImages = new InvocationToolImages(ctx.signal, modelSupportsImageInput);
      let invoked = false;
      // Internal observer is deliberately added after the strict provider
      // projection, whose allowlist must never accept executable callbacks.
      const toolContext = ctx.mailbox
        ? { ...projectedToolContext, onToolInvocationStarted: () => { invoked = true; } }
        : projectedToolContext;
      const monitoredToolContext:ToolExecutionContext={...toolContext,hostProviderInvocationId:providerInvocationId,
        modelSupportsImageInput,
        emitToolImage: toolImages.emit,
        onExecutionHealth: state => {void ctx.emitRuntimeEvent({type:'execution_health',sessionId:ctx.sessionId,turnId:ctx.turnId,invocationId:toolCall.id,state}).catch(error=>console.warn('[execution-health] status delivery failed',error));},
        executionProgress: {progress:()=>{void ctx.emitRuntimeEvent({type:'execution_progress',sessionId:ctx.sessionId,turnId:ctx.turnId}).catch(error=>console.warn('[execution-health] progress delivery failed',error));},wait:()=>{},resume:()=>{}},
      };
      if(Object.isFrozen(projectedToolContext))Object.freeze(monitoredToolContext);
      let execution: Awaited<ReturnType<typeof executeDesktopTaskTool>>;
      try { execution = await executeDesktopTaskTool({ ...toolCall, input: runtimeToolInput }, {
        registry: ctx.registry,
        taskId: ctx.taskId,
        materials: ctx.materials,
        materialRegistry: ctx.materialRegistry,
        context:monitoredToolContext,
        officeToMarkdown: ctx.officeToMarkdown,
        scoped: Boolean(ctx.mailbox),
      }); } catch (error) { toolImages.finish(false); throw error; }
      let { ok, result } = execution;
      if (ok && isToolName(toolCall.name, 'create_project') && ctx.finalizeProjectProposal) {
        let proposal: Record<string, unknown> | undefined;
        try {
          const parsed = JSON.parse(result);
          if (isRecord(parsed?.proposal) && parsed.proposal.kind === 'project_proposal') proposal = parsed.proposal;
        } catch { /* A failed/non-JSON tool result cannot authorize creation. */ }
        if (proposal) {
          ctx.signal.throwIfAborted();
          await ctx.beforeManagedTurnSeal?.(result);
          ctx.signal.throwIfAborted();
          const finalized = await ctx.finalizeProjectProposal(proposal);
          if (finalized) { result = JSON.stringify(finalized); ok = finalized.ok === true; }
        }
      }
      const invocationImages = toolImages.finish(ok);
      ctx.signal.throwIfAborted();
      if (observationProjectionFailure) throw observationProjectionFailure;
      if (ok) {
        await ctx.emitRuntimeEvent({ type: 'post_tool_use', sessionId: ctx.sessionId, turnId: ctx.turnId, toolName: toolCall.name, toolInput: runtimeToolInput, toolResponse: formatTaskToolResultResponse(toolCall.name, result), toolUseId: toolCall.id });
      } else {
        await ctx.emitRuntimeEvent({ type: 'post_tool_use_failure', sessionId: ctx.sessionId, turnId: ctx.turnId, toolName: toolCall.name, toolInput: runtimeToolInput, toolUseId: toolCall.id, error: result.slice(0, 10000) });
      }
      ctx.signal.throwIfAborted();
      await ctx.emitRuntimeEvent({
        type: 'tool_finished', sessionId: ctx.sessionId, turnId: ctx.turnId,
        invocationId: toolCall.id, toolName: toolCall.name, ok,
        ...(ctx.mailbox ? { invoked } : {}),
      });
      ctx.signal.throwIfAborted();
      if (ctx.strategies.trackAutoProgress && !isInternalTool) {
        const label = toolNameToLabel(toolCall.name, toolCall.input as Record<string, unknown>);
        autoSteps.push({ id: `auto-${totalToolCalls}`, label, status: ok ? 'completed' : 'failed' });
        await ctx.emitRuntimeEvent({ type: 'progress_plan_reported', sessionId: ctx.sessionId, steps: autoSteps });
        ctx.signal.throwIfAborted();
      }

      if (skillInvocation) {
        appendTrace(ctx.dataRoot, {
          ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
          stageId: skillInvocation.stageId, iteration, event: 'tool_end',
          toolName: toolCall.name, outputBytes: result.length,
        });
      }

      const scopedArtifact = ok && ctx.executionScope?.kind === 'artifact_workspace_generation'
        ? parseArtifactWorkspaceToolAck(result)
        : null;
      let artifactEventEmitted = false;
      if (scopedArtifact) {
        artifactEventEmitted = true;
        await ctx.emitRuntimeEvent({ type: 'file_changed', sessionId: ctx.sessionId, filePath: scopedArtifact.artifactPath, event: 'add' });
        ctx.signal.throwIfAborted();
        await ctx.emitRuntimeEvent({
          type: 'artifact_recorded',
          sessionId: ctx.sessionId,
          turnId: ctx.turnId,
          intentId: ctx.intentId,
          stageId: ctx.stepId,
          artifactId: scopedArtifact.artifactId,
          label: scopedArtifact.title,
          kind: scopedArtifact.kind,
          path: scopedArtifact.artifactPath,
          creator: scopedArtifact.creator,
          mimeType: scopedArtifact.mimeType,
        });
        ctx.signal.throwIfAborted();
      }
      const writeArtifactPath = resolveWriteToolArtifactPath(toolCall.name, runtimeToolInput);
      if (ok && !artifactEventEmitted && writeArtifactPath) {
        const filePath = writeArtifactPath;
        await ctx.emitRuntimeEvent({ type: 'file_changed', sessionId: ctx.sessionId, filePath, event: 'add' });
        ctx.signal.throwIfAborted();
        const extMatch = filePath.match(/\.([a-zA-Z0-9]+)$/);
        const kind = extMatch ? extMatch[1].toLowerCase() : 'other';
        const fileName = basename(filePath) || filePath;
        await ctx.emitRuntimeEvent({
          type: 'artifact_recorded',
          sessionId: ctx.sessionId,
          turnId: ctx.turnId,
          intentId: ctx.intentId,
          stageId: ctx.stepId,
          artifactId: `artifact_${toolCall.id}`,
          label: fileName,
          kind,
          path: filePath,
          creator: 'agent',
        });
        ctx.signal.throwIfAborted();
        if (ctx.strategies.emitSkillArtifactTrace && skillInvocation) {
          appendTrace(ctx.dataRoot, {
            ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
            stageId: skillInvocation.stageId, iteration, event: 'tool_end',
            toolName: 'artifact_written', details: filePath,
          });
        }
      }
      const workflowStatusArtifacts = ok && !artifactEventEmitted
        ? resolveKSwarmWorkflowStatusArtifacts(toolCall.name, result)
        : [];
      if (workflowStatusArtifacts.length > 0) {
        artifactEventEmitted = true;
        for (const artifact of workflowStatusArtifacts) {
          await ctx.emitRuntimeEvent({
            type: 'artifact_recorded',
            sessionId: ctx.sessionId,
            turnId: ctx.turnId,
            intentId: ctx.intentId,
            stageId: ctx.stepId,
            artifactId: artifact.artifactId,
            label: artifact.label,
            kind: artifact.kind,
            path: artifact.filePath,
            creator: artifact.creator,
          });
          ctx.signal.throwIfAborted();
        }
      }
      if (
        ok
        && !artifactEventEmitted
        && !isToolName(toolCall.name, 'write')
        && !isToolName(toolCall.name, 'render_ui')
        && !isToolName(toolCall.name, 'get_dynamic_workflow_status')
      ) {
        const filePath = resolveToolOutputArtifactPath(runtimeToolInput, result, { toolName: toolCall.name, toolStartedAt });
        if (filePath) {
          await ctx.emitRuntimeEvent({ type: 'file_changed', sessionId: ctx.sessionId, filePath, event: 'add' });
          ctx.signal.throwIfAborted();
          const extMatch = filePath.match(/\.([a-zA-Z0-9]+)$/);
          const kind = extMatch ? extMatch[1].toLowerCase() : 'other';
          const fileName = basename(filePath) || filePath;
          await ctx.emitRuntimeEvent({
            type: 'artifact_recorded',
            sessionId: ctx.sessionId,
            turnId: ctx.turnId,
            intentId: ctx.intentId,
            stageId: ctx.stepId,
            artifactId: `artifact_${toolCall.id}`,
            label: fileName,
            kind,
            path: filePath,
            creator: 'agent',
          });
          ctx.signal.throwIfAborted();
        }
      }
      if (ok && toolCall.name === 'report_progress') {
        try {
          const parsed = JSON.parse(result);
          if (parsed._validated) {
            await ctx.emitRuntimeEvent({ type: 'progress_plan_reported', sessionId: ctx.sessionId, steps: parsed._validated });
            result = JSON.stringify({ ok: true, displayed_steps: parsed.displayed_steps,
              ...(typeof parsed.completionReminder === 'string' ? { completionReminder: parsed.completionReminder } : {}),
            });
          }
        } catch { ctx.signal.throwIfAborted(); /* Non-cancellation progress parse errors remain non-critical. */ }
      }
      ctx.signal.throwIfAborted();
      const resultContent = ctx.strategies.processToolResult(result, toolCall.name, toolCall.id);
      try { ctx.observationOwner?.finalizeToolResult(toolCall.id, resultContent); } catch { /* Never replay completed tools for optional provenance. */ }
      measureToolResult('history_result', toolCall.id, toolCall.name, resultContent);
      toolResults.push({ type: 'tool_result', tool_use_id: toolCall.id, content: resultContent, is_error: !ok });
      const materialImages=ctx.roomExecution?.takePendingImages?.()??[];
      if(ok)toolResults.push(...invocationImages, ...materialImages);
    }
    ctx.messages.push({ role: 'user', content: toolResults });
    if(ctx.observationBinding)requireDesktopObservationBinding(ctx.observationBinding,ctx.taskId,ctx.registry).session.replaceMessages(ctx.messages);
    await ctx.registry.publishCompoundHistory();
    await ctx.observationOwner?.publishCurrentHistory?.({ strictPrivateProtocol: isStrictKimiK3Adapter(ctx.adapter) });
    toolResultsAwaitingFinalResponse = true;

    if (skillInvocation) {
      appendTrace(ctx.dataRoot, {
        ts: Date.now(), taskId: ctx.sessionId, skillName: skillInvocation.primarySkill,
        stageId: skillInvocation.stageId, iteration, event: 'model_turn_end',
      });
    }
    return true;
    };
    const keepRunning=ctx.observationOwner
      ?await runCompoundPublicationIteration(ctx.observationOwner,ctx.turnId,runIteration,ctx.signal)
      :await runIteration();
    if(!keepRunning)break;
  }

  if (toolResultsAwaitingFinalResponse) {
    ctx.messages.push({
      role: 'user',
      content: [{ type: 'text', text: DESKTOP_MODEL_TOOL_LOOP_FINALIZATION_PROMPT }],
    });
    const finalized = await streamDesktopToolLoopFinalization({
      modelPhysicalScope: ctx.modelPhysicalScope,
      projectModel: ctx.projectModel,
      prepareRequest: observationRequestPreparer(ctx),
      beforeRequest: async()=>{await assertNativeRegistryCheckpointCurrent(ctx.registry);await ctx.roomExecution?.authorize();},
      deadline: ctx.taskDeadline,
      adapter: ctx.adapter,
      apiMessages: await prepareDesktopLoopRequest(ctx, streamOptions, true, lastRequestInputTokens),
      systemPrompt: ctx.systemPrompt,
      streamOptions,
      signal: ctx.signal,
      sessionId: ctx.sessionId,
      turnId: ctx.turnId,
      intentId: ctx.intentId,
      stepId: ctx.stepId,
      emitRuntimeEvent: ctx.emitRuntimeEvent,
      onUsage: async (chunk, invocationId) => {
        try {
          const inputTkns = chunk.usage?.inputTokens ?? 0;
          lastRequestInputTokens = inputTkns;
          totalInputTokens += inputTkns;
          totalOutputTokens += chunk.usage?.outputTokens ?? 0;
          await ctx.onUsage?.(inputTkns, chunk.usage?.outputTokens ?? 0, invocationId);
        } catch (e) { if (ctx.mailbox) throw e; console.warn('[usage] token capture failed:', (e as Error).message) }
      },
    });
    reply += finalized.reply;
    ctx.messages.push({ role: 'assistant', content: finalized.assistantBlocks });
  }

  if (!finishedNormally) {
    const exhausted = iteration >= maxIterations;
    if(!exhausted)await ctx.beforeManagedTurnSeal?.(reply);
    const decision = await ctx.mailbox?.trySealTurn({ outcome: exhausted ? 'failed' : 'completed', limitReached: true });
    if (exhausted || decision?.kind === 'limit_reached') throw new DesktopMultiAgentIterationLimitError(reply, maxIterations, iteration, budget.source);
  }

  return {
    reply,
    totalToolCalls,
    totalInputTokens,
    totalOutputTokens,
    referenceReads,
    autoSteps,
    skillNamesDetected,
    skillTriggerType,
    skillInvocation,
  };
}

const SYNTHESIZED_DESKTOP_HISTORY_PREFIX = 'The following JSON is synthesized Xiaok Desktop task context.\n'
  + 'It is not a raw provider transcript and contains no preserved reasoning.\n';
const SYNTHESIZED_DESKTOP_HISTORY_LIMIT = 40_000;

type DesktopHostHistoryRecord = {
  role: 'user' | 'assistant';
  content: string;
};

function isStrictKimiK3ProfileId(profileId: string | undefined): boolean {
  return profileId === 'kimi-k3-coding-openai'
    || profileId === 'kimi-k3-256k-coding-openai';
}

function resolveDesktopHarnessProfileId(
  binding: ReturnType<typeof resolveRuntimeModelBinding>,
): string | undefined {
  if (binding.protocol !== 'openai_legacy') return undefined;
  return resolveModelHarnessProfile({
    providerId: binding.providerId,
    providerType: binding.providerType,
    protocol: binding.protocol,
    canonicalBaseUrl: binding.baseUrl,
    wireModel: binding.wireModel,
    capabilities: binding.capabilities,
  }).id;
}

function validateStrictDesktopHistory(
  history: readonly DesktopHostHistoryRecord[],
): void {
  if (history.length % 2 !== 0) {
    throw new Error('KIMI_DESKTOP_HISTORY_PAIR_INVALID');
  }
  for (let index = 0; index < history.length; index += 1) {
    const record = history[index] as {
      role?: unknown;
      content?: unknown;
    };
    const expectedRole = index % 2 === 0 ? 'user' : 'assistant';
    if (record.role !== expectedRole || typeof record.content !== 'string') {
      throw new Error('KIMI_DESKTOP_HISTORY_PAIR_INVALID');
    }
  }
}

function buildSynthesizedDesktopHistoryEnvelope(
  history: readonly DesktopHostHistoryRecord[],
): string | undefined {
  validateStrictDesktopHistory(history);
  let firstRecordIndex = 0;
  while (firstRecordIndex < history.length) {
    const records = history.slice(firstRecordIndex).map((record, offset) => ({
      ordinal: firstRecordIndex + offset,
      role: record.role,
      content: record.content,
    }));
    const envelope = SYNTHESIZED_DESKTOP_HISTORY_PREFIX + JSON.stringify({
      kind: 'xiaok.synthesized-task-context',
      version: 1,
      records,
    });
    if (envelope.length <= SYNTHESIZED_DESKTOP_HISTORY_LIMIT) {
      return envelope;
    }
    firstRecordIndex += 2;
  }
  return undefined;
}

export function buildDesktopProviderMessages(
  adapter: ModelAdapter,
  hostHistory: readonly DesktopHostHistoryRecord[],
  currentUserContent: MessageBlock[],
): Message[] {
  const currentUserMessage: Message = {
    role: 'user',
    content: currentUserContent,
  };
  if (!isStrictKimiK3ProfileId(adapter.getHarnessProfileId?.())) {
    return [
      ...hostHistory.map((record): Message => ({
        role: record.role,
        content: [{ type: 'text', text: record.content }],
      })),
      currentUserMessage,
    ];
  }
  const envelope = buildSynthesizedDesktopHistoryEnvelope(hostHistory);
  return envelope
    ? [
        {
          role: 'user',
          content: [{ type: 'text', text: envelope }],
        },
        currentUserMessage,
      ]
    : [currentUserMessage];
}

interface KSwarmInitialPlanBootstrapInput {
  projectId: string;
  projectName: string;
  goal: string;
  requirements: string;
  planningGuidance: string;
  poAgent: string;
  members: string[];
  startPolicy?: KSwarmProjectStartPolicy;
}

type KSwarmProjectStartPolicy = 'plan_only' | 'auto_activate_after_plan' | 'activate_and_dispatch_after_plan';

interface KSwarmCreateProjectToolOptions {
  createRoom?: (input: Record<string,unknown>, context:{taskId:string;signal?:AbortSignal})=>Promise<Record<string,unknown>>;
  enqueuePlanBootstrap?: (input: KSwarmInitialPlanBootstrapInput) => { ok: true; status: 'queued' } | { ok: false; error: string };
  finalizeProjectProposal?: (proposal: Record<string, unknown>, context: { taskId: string; signal: AbortSignal }) => Promise<Record<string, unknown> | undefined>;
}

export function createKSwarmCreateProjectTool(kswarmService: KSwarmService, options: KSwarmCreateProjectToolOptions = {}): Tool {
  return {
    permission: 'safe',
    definition: {
      name: 'create_project',
      description: '根据用户明确的 Xiaok 项目创建要求生成项目定义；工具只能提供定义，工具自身严禁直接创建正式项目。正式用户会话由主进程验证授权后建立真实 Xiaok 项目，默认规划完成后自动激活并派发，不要求用户创建或操作协作空间，无需再次确认或手工点启动。严禁未经用户明确创建授权建立持久项目，严禁伪造身份、绕过主进程或把 proposal 当作已创建项目；只有结果包含真实 projectId 才能报告创建成功，启动状态以 preparation/planningStart 为准。普通写作、分析及会话内 SubAgent 协作不授予创建持久项目的权限。用户明确只要规划/不执行时保留计划范围。',
      inputSchema: {
        type: 'object',
        properties: {
          name: { type: 'string', description: '项目名称，简短明确' },
          goal: { type: 'string', description: '项目目标，描述最终要交付什么' },
          requirements: { type: 'string', description: '补充要求或约束条件（交付物格式、参考资料等）' },
          memberNames: {
            type: 'array',
            items: { type: 'string' },
            description: '用户明确指定的 agent 名称，如 ["claude", "codex"]',
          },
          memberCount: {
            type: 'integer',
            description: '用户期望的智能体总数（不含 PO），未指定则不填',
          },
          workFolder: {
            type: 'string',
            description: '项目工作目录的完整本地路径；仅当用户明确指定工作目录时填写',
          },
          executionMode: {
            type: 'string',
            enum: ['direct', 'workflow', 'auto'],
            description: '项目执行方式。用户明确说 workflow/动态工作流/工作流方式时填 workflow；用户明确说 direct/快速编排时填 direct；不确定时不填或填 auto。',
          },
          startPolicy: {
            type: 'string',
            enum: ['plan_only', 'auto_activate_after_plan', 'activate_and_dispatch_after_plan'],
            description: '计划完成后的启动策略。用户明确只要计划/先不要执行时填 plan_only；只要自动审批但暂不派发时填 auto_activate_after_plan；对话里要求做完、搞定、自动开始、持续推进到结果时填 activate_and_dispatch_after_plan。',
          },
        },
        required: ['name', 'goal'],
      },
    },
    async execute(input) {
      // The tool remains read-only. The host may finalize this definition
      // through main-owned Room-first creation when its real task context
      // holds an explicit user authorization; tool input cannot mint one.
      // Identity fields (requestSource/actor) are transport facts and are
      // dropped from the proposal payload.
      const { name, goal, requirements, memberNames = [], memberCount = 0, workFolder, executionMode, startPolicy, _xiaokRequestScope } = input as {
        name: string; goal: string; requirements?: string;
        memberNames?: string[]; memberCount?: number; workFolder?: string; executionMode?: string; startPolicy?: string;
        _xiaokRequestScope?: string;
      };
      const resolvedWorkFolder = typeof workFolder === 'string' ? workFolder.trim() : '';
      const resolvedExecutionMode = resolveCreateProjectExecutionMode({
        executionMode,
        name,
        goal,
        requirements: requirements || '',
      });
      const resolvedStartPolicy = resolveCreateProjectStartPolicy({
        startPolicy,
        name,
        goal,
        requirements: requirements || '',
      });

      try {
        const agentsRes = await kswarmService.request('/agents');
        if (!agentsRes.ok) return JSON.stringify({ error: 'Cannot fetch agents from kswarm' });
        const { agents } = await agentsRes.json() as { agents: Array<{ id: string; name: string; runtimeType?: string; roles?: string[]; status: string; archivedAt?: number | null }> };

        const poAgent = getPreferredPoAgentId(agents);
        if (!poAgent) return JSON.stringify({ error: 'No agents available. Create an agent in kswarm first.' });

        const resolvedMembers = resolveCreateProjectMembers({
          agents,
          poAgent,
          memberNames,
          memberCount,
        }).members;
        const explicitlyNamedMemberIds = new Set(
          (Array.isArray(memberNames) ? memberNames : [])
            .map(memberName => agents.find(agent => agent.id === memberName || agent.name === memberName)?.id)
            .filter((id): id is string => Boolean(id))
        );
        // proposal-only: no agent auto-creation mutation; report the gap instead
        const memberGap = memberCount > 0 ? Math.max(0, memberCount - resolvedMembers.length) : 0;
        const sanitizedMembers = resolvedMembers.slice(0, 10);

        const planningGuidance = buildCreateProjectPlanningGuidanceForTool({ goal, requirements: requirements || '' });
        const clientRequestKey = buildCreateProjectClientRequestKey({
          requestScope: _xiaokRequestScope,
          name,
          goal,
          requirements: requirements || '',
          members: sanitizedMembers,
          workFolder: resolvedWorkFolder,
        });

        const proposal = {
          kind: 'project_proposal' as const,
          name,
          goal,
          requirements: requirements || '',
          ...(planningGuidance ? { planningGuidance } : {}),
          poAgent,
          members: sanitizedMembers,
          agentSelection: {
            poAgent: { agentId: poAgent, source: 'default_seed' },
            members: sanitizedMembers.map(agentId => ({
              agentId,
              source: explicitlyNamedMemberIds.has(agentId) ? 'explicit_user' : 'default_seed',
            })),
          },
          memberNames,
          memberCount,
          ...(memberGap > 0 ? { memberGap } : {}),
          startPolicy: resolvedStartPolicy,
          ...(resolvedExecutionMode ? { executionMode: resolvedExecutionMode } : {}),
          ...(resolvedWorkFolder ? { workFolder: resolvedWorkFolder } : {}),
          ...(clientRequestKey ? { clientRequestKey } : {}),
          createdAt: new Date().toISOString(),
          note: '当前仅返回未执行的项目定义，尚无正式项目。只有可信用户会话具有明确创建授权时，主进程才会建立真实 Xiaok 项目；严禁声称已创建或指向不存在的提案确认界面。',
        };
        return JSON.stringify({ ok: true, proposal });
      } catch (err) {
        return JSON.stringify({ error: `KSwarm service unavailable: ${(err as Error).message}` });
      }
    },
  };
}

function resolveCreateProjectExecutionMode(input: {
  executionMode?: unknown;
  name: string;
  goal: string;
  requirements: string;
}): 'direct' | 'workflow_preferred' | 'auto' | undefined {
  const explicit = normalizeCreateProjectExecutionMode(input.executionMode);
  if (explicit && explicit !== 'auto') return explicit;
  const inferred = inferCreateProjectExecutionModeFromIntent([
    input.name,
    input.goal,
    input.requirements,
  ].join('\n'));
  return inferred || (explicit === 'auto' ? 'auto' : undefined);
}

function resolveCreateProjectStartPolicy(input: {
  startPolicy?: unknown;
  name: string;
  goal: string;
  requirements: string;
}): KSwarmProjectStartPolicy {
  const explicit = normalizeCreateProjectStartPolicy(input.startPolicy);
  if (explicit) return explicit;
  const text = [input.name, input.goal, input.requirements].join('\n');
  if (/(先不要执行|不要开始执行|暂不执行|只要计划|只出计划|只规划|先出计划|让我审批|等我确认)/i.test(text)) {
    return 'plan_only';
  }
  if (/(先规划|帮我拆计划|先拆解|先建项目)/i.test(text)) {
    return 'auto_activate_after_plan';
  }
  return 'activate_and_dispatch_after_plan';
}

function normalizeCreateProjectStartPolicy(value: unknown): KSwarmProjectStartPolicy | undefined {
  if (typeof value !== 'string') return undefined;
  const normalized = value.trim();
  if (normalized === 'plan_only' || normalized === 'auto_activate_after_plan' || normalized === 'activate_and_dispatch_after_plan') {
    return normalized;
  }
  if (normalized === 'auto_dispatch_after_plan') return 'activate_and_dispatch_after_plan';
  return undefined;
}

function normalizeCreateProjectExecutionMode(value: unknown): 'direct' | 'workflow_preferred' | 'auto' | undefined {
  if (typeof value !== 'string') return undefined;
  const normalized = value.trim().toLowerCase();
  if (normalized === 'workflow' || normalized === 'workflow_preferred') return 'workflow_preferred';
  if (normalized === 'direct') return 'direct';
  if (normalized === 'auto') return 'auto';
  return undefined;
}

function inferCreateProjectExecutionModeFromIntent(text: string): 'direct' | 'workflow_preferred' | undefined {
  if (/(direct|quick|快速编排|直接编排|快速执行|直接执行)/i.test(text)) return 'direct';
  if (/(workflow|dynamic workflow|动态工作流|工作流方式|工作流执行|用工作流|以工作流)/i.test(text)) {
    return 'workflow_preferred';
  }
  return undefined;
}

function buildCreateProjectClientRequestKey(input: {
  requestScope?: unknown;
  name: string;
  goal: string;
  requirements: string;
  members: string[];
  workFolder: string;
}): string | undefined {
  const requestScope = normalizeCreateProjectKeyPart(input.requestScope);
  if (!requestScope) return undefined;
  const payload = {
    requestScope,
    name: normalizeCreateProjectKeyPart(input.name),
    goal: normalizeCreateProjectKeyPart(input.goal),
    requirements: normalizeCreateProjectKeyPart(input.requirements),
    members: [...input.members].map(member => normalizeCreateProjectKeyPart(member)).sort(),
    workFolder: normalizeCreateProjectKeyPart(input.workFolder),
  };
  return `create-project:${createHash('sha256').update(JSON.stringify(payload)).digest('hex')}`;
}

function normalizeCreateProjectKeyPart(value: unknown): string {
  return typeof value === 'string' ? value.trim().replace(/\s+/g, ' ') : '';
}

function buildCreateProjectPlanningGuidanceForTool(input: { goal: string; requirements?: string }): string {
  const text = `${input.goal || ''}\n${input.requirements || ''}`;
  const formatRequests = text
    .replace(/markdown\s*(?:不算(?:交付)?(?:完成)?|不是(?:最终)?交付物|不是(?:最终)?报告)/gi, '')
    .replace(/(?:不要|不接受|不得|严禁|不能(?:只)?(?:用)?|不允许|not\s+|no\s+)\s*(?:普通)?\s*markdown/gi, '');
  const explicitMarkdown = /(\.md\b|\.markdown\b|\bmarkdown\b)/i.test(formatRequests);
  const explicitPptx = /(\.pptx\b|\bpptx\b|\bpowerpoint\b|\bppt\s*(文件|file|deck)?\b)/i.test(text);
  const explicitPdf = /(\.pdf\b|\bpdf\b|PDF文件|pdf文件)/i.test(text);
  const slide = /(幻灯片|演示文稿|slide deck|slides|presentation)/i.test(text);
  const report = /(报告|\breport\b)/i.test(text);
  const analysisReport = !report && isAnalysisReportLikeProject(text);
  if (slide && explicitPptx) {
    return [
      '输出意图：用户明确要求演示文稿/幻灯片交付 PPTX。',
      '不要改写用户目标或项目要求；计划中细化为最终任务生成 PPTX 文件。',
      '前序内容任务可以产出素材或草稿，但最终交付物必须符合用户明确格式。',
    ].join('\n');
  }
  if (slide && !explicitPptx) {
    return [
      '输出意图：用户要演示文稿/幻灯片。',
      '计划中必须安排最终任务使用 slide renderer 生成 HTML deck；不要默认改成 PPTX。',
      '前序内容任务可以产出素材或草稿，但最终交付物必须是 slide renderer HTML。',
      explicitPdf ? VISUAL_PDF_EXPORT_GUIDANCE : '',
    ].filter(Boolean).join('\n');
  }
  if (report && explicitMarkdown) {
    return [
      '输出意图：用户明确要求报告交付 Markdown。',
      '不要改写用户目标或项目要求；计划中细化为最终任务生成 Markdown 报告。',
      '前序研究/写作任务可以产出素材或草稿，但最终交付物必须符合用户明确格式。',
    ].join('\n');
  }
  if ((report || analysisReport) && !explicitMarkdown) {
    return [
      analysisReport
        ? '输出意图：用户要分析/研究类交付物，默认按报告交付；最终任务必须使用 report renderer 生成 HTML 报告。'
        : '输出意图：用户要报告，最终任务必须使用 report renderer 生成 HTML 报告。',
      '不要把用户目标改写为其他交付格式。',
      '前序研究/写作任务可以产出素材或中间 Markdown，但最终交付物必须是 report renderer HTML。',
      explicitPdf ? VISUAL_PDF_EXPORT_GUIDANCE : '',
    ].filter(Boolean).join('\n');
  }
  return '';
}

function isAnalysisReportLikeProject(text: string): boolean {
  const analysis = /(分析|研究|调研|评估|研判|洞察|复盘|\banalysis\b|\bresearch\b|\bassessment\b|\bbrief\b)/i.test(text);
  const deliverableCue = /(高层|管理层|决策|战略|研发|产品|竞品|市场|行业|趋势|动态|情况|内容|汇报|材料|交付|leadership|executive|strategy|market|industry|trend|product|competitive)/i.test(text);
  return analysis && deliverableCue;
}

export function createKSwarmContinueProjectTool(kswarmService: KSwarmService): Tool {
  return {
    permission: 'safe',
    definition: {
      name: 'continue_project',
      description: '诊断并安全推进一个已经卡住的 KSwarm 项目。仅在用户要求小K帮忙推进项目，或当前上下文明确包含卡住项目时调用。该工具不会跳过必需任务，也不会人工放行不合格结果。',
      inputSchema: {
        type: 'object',
        properties: {
          projectId: { type: 'string', description: 'KSwarm 项目 ID，例如 proj-1779090338840' },
          expectedPrimaryTaskId: { type: 'string', description: '当前卡住的主任务 ID，用于防止状态过期' },
          expectedTaskUpdatedAt: {
            oneOf: [{ type: 'number' }, { type: 'string' }],
            description: '卡住任务在诊断时的更新时间，用于防止状态过期',
          },
          idempotencyKey: { type: 'string', description: '本次继续推进操作的幂等键；同一次会话重试时保持一致' },
        },
        required: ['projectId'],
      },
    },
    async execute(input) {
      const projectId = typeof input.projectId === 'string' ? input.projectId.trim() : '';
      if (!projectId) return JSON.stringify({ error: 'projectId is required' });

      const body: Record<string, unknown> = {
        idempotencyKey: typeof input.idempotencyKey === 'string' && input.idempotencyKey.trim()
          ? input.idempotencyKey.trim()
          : `xiaok-chat-${projectId}-${Date.now()}`,
      };
      if (typeof input.expectedPrimaryTaskId === 'string' && input.expectedPrimaryTaskId.trim()) {
        body.expectedPrimaryTaskId = input.expectedPrimaryTaskId.trim();
      }
      if (input.expectedTaskUpdatedAt !== undefined && input.expectedTaskUpdatedAt !== null && input.expectedTaskUpdatedAt !== '') {
        body.expectedTaskUpdatedAt = input.expectedTaskUpdatedAt;
      }

      try {
        const res = await kswarmService.request(`/projects/${encodeURIComponent(projectId)}/continue`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const payload = await res.json().catch(() => ({})) as Record<string, unknown>;
        if (!res.ok) {
          return JSON.stringify({
            ok: false,
            status: res.status,
            error: payload.error || `continue_project_failed_${res.status}`,
            ...payload,
          });
        }
        return JSON.stringify(payload);
      } catch (err) {
        return JSON.stringify({ ok: false, error: `KSwarm service unavailable: ${(err as Error).message}` });
      }
    },
  };
}

const INSPECT_PROJECT_MAX_ARTIFACTS = 3;
const INSPECT_PROJECT_MAX_ARTIFACT_CHARS = 12000;
const INSPECT_PROJECT_READABLE_EXTENSIONS = new Set(['.md', '.txt', '.json', '.csv', '.html', '.htm']);

export function createKSwarmInspectProjectTool(kswarmService: KSwarmService): Tool {
  return {
    permission: 'safe',
    definition: {
      name: 'inspect_project',
      description: '检查 KSwarm 项目状态、卡住任务、项目干预信息和最新可读产物。当用户要求推进/诊断/修复 Swarm 项目，尤其只给项目名时，先调用此工具。',
      inputSchema: {
        type: 'object',
        properties: {
          projectId: { type: 'string', description: 'KSwarm 项目 ID，例如 proj-1779090338840' },
          projectName: { type: 'string', description: 'KSwarm 项目名称。没有 projectId 时用于匹配项目' },
          includeArtifacts: { type: 'boolean', description: '是否读取最新文本产物正文，默认 true' },
        },
      },
    },
    async execute(input) {
      const projectIdInput = typeof input.projectId === 'string' ? input.projectId.trim() : '';
      const projectName = typeof input.projectName === 'string' ? input.projectName.trim() : '';
      const includeArtifacts = input.includeArtifacts !== false;

      if (!projectIdInput && !projectName) {
        return JSON.stringify({ ok: false, error: 'projectId_or_projectName_required' });
      }

      try {
        const resolved = projectIdInput
          ? { ok: true as const, projectId: projectIdInput, match: { mode: 'project_id' } }
          : await resolveKSwarmProjectByName(kswarmService, projectName);
        if (!resolved.ok) return JSON.stringify(resolved);

        const detailRes = await kswarmService.request(`/projects/${encodeURIComponent(resolved.projectId)}`);
        const detail = await detailRes.json().catch(() => ({})) as Record<string, unknown>;
        if (!detailRes.ok) {
          return JSON.stringify({
            ok: false,
            error: detail?.error || `project_detail_failed:${detailRes.status}`,
            status: detailRes.status,
            projectId: resolved.projectId,
          });
        }

        const tasks = Array.isArray(detail.tasks) ? detail.tasks : [];
        const readableArtifacts = includeArtifacts
          ? await readLatestProjectArtifacts(kswarmService, resolved.projectId, detail)
          : [];

        return JSON.stringify({
          ok: true,
          match: resolved.match,
          project: summarizeProject(detail.project),
          artifactWriteDir: inferArtifactWriteDir(detail),
          projectIntervention: detail.projectIntervention || null,
          projectHealth: detail.projectHealth || null,
          dispatchPlan: detail.dispatchPlan || null,
          planProgress: detail.planProgress || null,
          tasks: tasks.map(summarizeKSwarmTask),
          readableArtifacts,
        });
      } catch (err) {
        return JSON.stringify({ ok: false, error: `KSwarm service unavailable: ${(err as Error).message}` });
      }
    },
  };
}

async function resolveKSwarmProjectByName(kswarmService: KSwarmService, projectName: string) {
  const projectsRes = await kswarmService.request('/projects');
  const payload = await projectsRes.json().catch(() => ({})) as { projects?: unknown[]; error?: string };
  if (!projectsRes.ok) {
    return { ok: false as const, error: payload.error || `projects_list_failed:${projectsRes.status}`, status: projectsRes.status };
  }

  const projects = Array.isArray(payload.projects) ? payload.projects.filter(isRecord) : [];
  const wanted = normalizeProjectName(projectName);
  const exact = projects.filter(project => normalizeProjectName(project.name) === wanted);
  const matches = exact.length > 0
    ? exact
    : projects.filter(project => normalizeProjectName(project.name).includes(wanted));
  const sortedMatches = matches.sort(compareProjectUpdatedDesc);

  if (sortedMatches.length === 0) {
    return { ok: false as const, error: 'project_not_found', projectName };
  }
  if (sortedMatches.length > 1) {
    return {
      ok: false as const,
      error: 'ambiguous_project',
      projectName,
      candidates: sortedMatches.map(summarizeProject),
    };
  }

  const selected = sortedMatches[0];
  return {
    ok: true as const,
    projectId: String(selected.id),
    match: { mode: exact.length > 0 ? 'name_exact' : 'name_contains', projectName },
  };
}

function inferArtifactWriteDir(detail: Record<string, unknown>) {
  const workspace = isRecord(detail.workspace) ? detail.workspace : null;
  const project = isRecord(detail.project) ? detail.project : null;
  const workFolder = stringOrUndefined(workspace?.path) || stringOrUndefined(project?.workFolder);
  if (!workFolder) return null;
  return {
    directory: `${workFolder.replace(/\/$/, '')}/artifacts`,
    relativePrefix: 'artifacts/',
    instruction: '把完整修复产物写入这个 artifacts 目录，然后调用 repair_project_task_from_file 提交 artifactPath；不要在 tool 参数里粘贴完整正文。',
  };
}

function normalizeProjectName(value: unknown): string {
  return String(value || '').trim().toLowerCase();
}

function compareProjectUpdatedDesc(left: Record<string, unknown>, right: Record<string, unknown>): number {
  return Number(right.updatedAt || right.createdAt || 0) - Number(left.updatedAt || left.createdAt || 0);
}

function summarizeProject(project: unknown) {
  if (!isRecord(project)) return null;
  return {
    id: stringOrUndefined(project.id),
    name: stringOrUndefined(project.name),
    goal: stringOrUndefined(project.goal),
    status: stringOrUndefined(project.status),
    createdAt: numberOrUndefined(project.createdAt),
    updatedAt: numberOrUndefined(project.updatedAt),
    taskCount: numberOrUndefined(project.taskCount),
    doneCount: numberOrUndefined(project.doneCount),
    stoppedCount: numberOrUndefined(project.stoppedCount),
  };
}

function summarizeKSwarmTask(task: unknown) {
  if (!isRecord(task)) return task;
  const result = isRecord(task.result) ? task.result : null;
  const summary = typeof result?.summary === 'string' ? result.summary : '';
  return {
    id: stringOrUndefined(task.id),
    title: stringOrUndefined(task.title),
    status: stringOrUndefined(task.status),
    assignedAgent: stringOrUndefined(task.assignedAgent),
    dependencies: Array.isArray(task.dependencies) ? task.dependencies : [],
    updatedAt: numberOrUndefined(task.updatedAt),
    startedAt: numberOrUndefined(task.startedAt),
    completedAt: numberOrUndefined(task.completedAt),
    failedAt: numberOrUndefined(task.failedAt),
    attempt: numberOrUndefined(task.attempt),
    maxAttempts: numberOrUndefined(task.maxAttempts),
    qualityFailureCount: numberOrUndefined(task.qualityFailureCount),
    failureReason: stringOrUndefined(task.failureReason),
    blockedReason: stringOrUndefined(task.blockedReason),
    resultSummary: summary ? truncateText(summary, 800).text : undefined,
    artifactCount: collectTaskArtifacts(task).length,
  };
}

async function readLatestProjectArtifacts(kswarmService: KSwarmService, projectId: string, detail: Record<string, unknown>) {
  const artifacts = collectProjectArtifacts(detail)
    .filter(isReadableProjectArtifact)
    .sort(compareArtifactForInspection)
    .slice(0, INSPECT_PROJECT_MAX_ARTIFACTS);

  const results = [];
  for (const artifact of artifacts) {
    const url = typeof artifact.url === 'string' && artifact.url.startsWith(`/projects/${projectId}/artifacts/`)
      ? artifact.url
      : artifact.filename
        ? `/projects/${encodeURIComponent(projectId)}/artifacts/${encodeURIComponent(String(artifact.filename))}`
        : '';
    const base = summarizeArtifact(artifact, url);
    if (!url) {
      results.push({ ...base, readError: 'artifact_url_missing' });
      continue;
    }

    try {
      const res = await kswarmService.request(url);
      const text = await res.text();
      if (!res.ok) {
        results.push({ ...base, readError: `artifact_read_failed:${res.status}` });
        continue;
      }
      const truncated = truncateText(text, INSPECT_PROJECT_MAX_ARTIFACT_CHARS);
      results.push({ ...base, content: truncated.text, truncated: truncated.truncated });
    } catch (err) {
      results.push({ ...base, readError: String((err as Error).message || err) });
    }
  }
  return results;
}

function collectProjectArtifacts(detail: Record<string, unknown>) {
  const collected: Record<string, unknown>[] = [];
  const seen = new Set<string>();
  const add = (artifact: unknown, inspectionPriority = 0) => {
    if (!isRecord(artifact)) return;
    const key = String(artifact.url || artifact.path || artifact.filename || JSON.stringify(artifact));
    if (seen.has(key)) return;
    seen.add(key);
    collected.push({ ...artifact, __inspectionPriority: inspectionPriority });
  };

  const tasks = Array.isArray(detail.tasks) ? detail.tasks.filter(isRecord) : [];
  const interventionTaskIds = getInterventionArtifactTaskIds(detail, tasks);
  for (const task of tasks) {
    const taskId = String(task.id || '');
    if (!interventionTaskIds.has(taskId)) continue;
    for (const artifact of collectTaskArtifacts(task)) add(artifact, 1);
  }

  const workspace = isRecord(detail.workspace) ? detail.workspace : null;
  if (Array.isArray(workspace?.artifacts)) {
    for (const artifact of workspace.artifacts) add(artifact);
  }
  for (const task of tasks) {
    const taskId = String(task.id || '');
    if (interventionTaskIds.has(taskId)) continue;
    for (const artifact of collectTaskArtifacts(task)) add(artifact);
  }
  return collected;
}

function getInterventionArtifactTaskIds(detail: Record<string, unknown>, tasks: Record<string, unknown>[]): Set<string> {
  const ids = new Set<string>();
  const intervention = isRecord(detail.projectIntervention) ? detail.projectIntervention : null;
  const primaryAction = isRecord(intervention?.primaryAction) ? intervention.primaryAction : null;
  const primaryTaskId = stringOrUndefined(intervention?.primaryTaskId) || stringOrUndefined(primaryAction?.taskId);
  if (!primaryTaskId) return ids;

  ids.add(primaryTaskId);
  const taskMap = new Map<string, Record<string, unknown>>();
  for (const task of tasks) {
    const taskId = String(task.id || '');
    if (taskId) taskMap.set(taskId, task);
  }
  const primaryTask = taskMap.get(primaryTaskId);
  const parentTaskId = stringOrUndefined(primaryTask?.parentTaskId);
  if (parentTaskId) ids.add(parentTaskId);

  for (const task of tasks) {
    const taskId = String(task.id || '');
    const taskParentId = stringOrUndefined(task.parentTaskId);
    if (taskParentId === primaryTaskId || (parentTaskId && taskParentId === parentTaskId)) ids.add(taskId);
  }
  return ids;
}

function collectTaskArtifacts(task: unknown): Record<string, unknown>[] {
  if (!isRecord(task)) return [];
  const result = isRecord(task.result) ? task.result : null;
  const fromResult = Array.isArray(result?.artifacts) ? result.artifacts.filter(isRecord) : [];
  const fromTask = Array.isArray(task.artifacts) ? task.artifacts.filter(isRecord) : [];
  return [...fromResult, ...fromTask];
}

function isReadableProjectArtifact(artifact: Record<string, unknown>): boolean {
  const filename = String(artifact.filename || artifact.path || artifact.url || '');
  const mimeType = String(artifact.mimeType || '').toLowerCase();
  const ext = extname(filename).toLowerCase();
  return (
    INSPECT_PROJECT_READABLE_EXTENSIONS.has(ext) ||
    mimeType.startsWith('text/') ||
    mimeType === 'application/json' ||
    mimeType === 'application/csv'
  );
}

function compareArtifactUpdatedDesc(left: Record<string, unknown>, right: Record<string, unknown>): number {
  return Number(right.generatedAt || right.updatedAt || right.createdAt || 0) - Number(left.generatedAt || left.updatedAt || left.createdAt || 0);
}

function compareArtifactForInspection(left: Record<string, unknown>, right: Record<string, unknown>): number {
  const priorityDiff = Number(right.__inspectionPriority || 0) - Number(left.__inspectionPriority || 0);
  if (priorityDiff !== 0) return priorityDiff;
  return compareArtifactUpdatedDesc(left, right);
}

function summarizeArtifact(artifact: Record<string, unknown>, url: string) {
  return {
    filename: stringOrUndefined(artifact.filename),
    url: url || stringOrUndefined(artifact.url),
    mimeType: stringOrUndefined(artifact.mimeType),
    size: numberOrUndefined(artifact.size),
    generatedAt: numberOrUndefined(artifact.generatedAt),
    updatedAt: numberOrUndefined(artifact.updatedAt),
  };
}

function truncateText(text: string, maxChars: number) {
  if (text.length <= maxChars) return { text, truncated: false };
  return { text: `${text.slice(0, maxChars)}\n...[truncated ${text.length - maxChars} chars]`, truncated: true };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function stringOrUndefined(value: unknown): string | undefined {
  return value === undefined || value === null ? undefined : String(value);
}

function numberOrUndefined(value: unknown): number | undefined {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : undefined;
}

export function createKSwarmRepairProjectTaskFromFileTool(kswarmService: KSwarmService): Tool {
  return {
    permission: 'safe',
    definition: {
      name: 'repair_project_task_from_file',
      description: '修复 KSwarm 项目中卡住或失败的任务。必须先把完整产物写入项目 artifacts 文件，再用此工具提交文件路径回审核流；不要传完整正文。',
      inputSchema: {
        type: 'object',
        properties: {
          projectId: { type: 'string', description: 'KSwarm 项目 ID' },
          taskId: { type: 'string', description: '需要修复并提交的任务 ID，通常来自项目干预上下文' },
          expectedTaskUpdatedAt: {
            oneOf: [{ type: 'number' }, { type: 'string' }],
            description: '任务更新时间戳，用于防止覆盖已经变化的任务状态',
          },
          summary: { type: 'string', description: '本次修复提交的简要说明' },
          artifactPath: { type: 'string', description: '已经写入项目 artifacts 目录的产物路径，例如 artifacts/report.md 或 report.md' },
          mimeType: { type: 'string', description: '产物 MIME 类型，默认 text/markdown' },
          idempotencyKey: { type: 'string', description: '可选幂等键；重复调用同一请求时复用' },
        },
        required: ['projectId', 'taskId', 'artifactPath'],
      },
    },
    async execute(input) {
      const projectId = String(input.projectId || '').trim();
      const taskId = String(input.taskId || '').trim();
      const artifactPath = String(input.artifactPath || input.path || input.relativePath || '').trim();
      if (!projectId || !taskId || !artifactPath) {
        return JSON.stringify({ ok: false, error: 'projectId, taskId and artifactPath are required' });
      }

      const body = {
        idempotencyKey: String(input.idempotencyKey || `repair-${projectId}-${taskId}-${Date.now()}`).trim(),
        resolution: 'repair_and_submit',
        fromAgent: 'xiaok',
        expectedPrimaryTaskId: taskId,
        expectedTaskUpdatedAt: input.expectedTaskUpdatedAt ?? undefined,
        summary: typeof input.summary === 'string' && input.summary.trim() ? input.summary.trim() : `Repaired submission for ${taskId}`,
        artifacts: [
          {
            path: artifactPath,
            mimeType: typeof input.mimeType === 'string' && input.mimeType.trim() ? input.mimeType.trim() : 'text/markdown',
          },
        ],
      };

      try {
        const res = await kswarmService.request(`/projects/${encodeURIComponent(projectId)}/intervention/resolve`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const payload = await res.json().catch(() => ({}));
        if (!res.ok) {
          return JSON.stringify({
            ok: false,
            error: payload?.error || `repair_project_task_failed:${res.status}`,
            status: res.status,
            ...payload,
          });
        }
        return JSON.stringify(payload);
      } catch (err) {
        return JSON.stringify({ ok: false, error: `KSwarm service unavailable: ${(err as Error).message}` });
      }
    },
  };
}

export function createKSwarmRepairProjectTaskTool(_kswarmService: KSwarmService): Tool {
  return {
    permission: 'safe',
    definition: {
      name: 'repair_project_task',
      description: '旧兼容工具。不要用它传完整产物正文；请先用 Write 把产物写入 artifacts 文件，然后调用 repair_project_task_from_file。',
      inputSchema: {
        type: 'object',
        properties: {
          projectId: { type: 'string', description: 'KSwarm 项目 ID' },
          taskId: { type: 'string', description: '需要修复并提交的任务 ID' },
          filename: { type: 'string', description: '旧参数，已禁用' },
          content: { type: 'string', description: '旧参数，已禁用；完整产物正文不能通过 tool 参数传递' },
          artifactPath: { type: 'string', description: '请改用 repair_project_task_from_file' },
        },
      },
    },
    async execute() {
      return JSON.stringify({
        ok: false,
        error: 'inline_content_forbidden',
        useTool: 'repair_project_task_from_file',
        message: '请先把完整修复产物写入项目 artifacts 文件，然后调用 repair_project_task_from_file，只传 artifactPath、summary 和 mimeType。',
      });
    },
  };
}
interface ObservationInitializationState {
  service?: DesktopMultiAgentService;
  incarnation?: object;
  firstRootEpoch?: number;
  phase: 'initializing' | 'ready' | 'failed';
  ownerAttempt?: object;
  failure?: { error: unknown };
}
const observationInitializationStates = new WeakMap<DesktopObservationTaskActivation, ObservationInitializationState>();
function noteObservationInitializationReady(activation: DesktopObservationTaskActivation): void {
  const state = observationInitializationStates.get(activation);
  if (state?.phase === 'initializing') state.phase = 'ready';
}

export function createDesktopModelRunnerWithRegistry(
  registry: ToolRegistry,
  tools: Tool[],
  dataRoot: string,
  kswarmService: KSwarmService,
  materialRegistry: MaterialRegistry,
  createProjectToolOptions: KSwarmCreateProjectToolOptions = {},
  runnerOptions: {
    observationTasks?: Map<string, DesktopObservationTaskActivation>;
    observationGroupHost?: { getHost(): InProcessTaskRuntimeHost; observationStore: import('../../src/runtime/task-host/protected-observation-store.js').DesktopTaskObservationStore };
    cwd?:string;
    getProjectModel?: () => Promise<ProjectAgentModel>;
    roomDiscussion?:boolean;
    publishedInstructions?:string;
    roomExecution?:{context:RoomWorkspaceContextSources;getModelBinding?:()=>Promise<ReturnType<typeof resolveRuntimeModelBinding>>;authorize:()=>Promise<void>;takePendingInput?:()=>string|undefined};
    nativeReadonlyOnly?: boolean;
    restrictedArtifactGeneration?: boolean;
    /** Stable provider-runtime identity captured before services exist (§4). */
    pluginProviderRuntime?: GatewayRuntimeFacade;
    multiAgent?: { runtime: DesktopMultiAgentRuntime; service: DesktopMultiAgentService; catalog: DesktopToolCatalogBridge; workspaceId: string; cwd: string };
    officeToMarkdown?: (input: { absolutePath: string; maxOutputChars: number; signal?: AbortSignal }) => Promise<OfficeTextExtractionResult>;
  } = {},
): (input: TaskRunnerInput, rootContext?: DesktopAgentExecutionContext) => Promise<void> {
  const nativeReadonlyOnly = registry.isNativeReadonlyOnly;
  const cwd = runnerOptions.cwd ?? runnerOptions.multiAgent?.cwd ?? process.cwd();
  const pluginSkillRoots = getPluginSkillRoots();
  let skillCatalog = createSkillCatalog(undefined, cwd, { extraRoots: pluginSkillRoots });
  let loadedSkillCatalogVersion = -1;
  let skillToolAdded = false;

  if (!nativeReadonlyOnly && !runnerOptions.restrictedArtifactGeneration) {
    // Register kswarm create_project tool (allows AI to create multi-agent projects from chat)
    registerKSwarmTools(registry, kswarmService, createProjectToolOptions);
    registry.registerTool(createReportArtifactTool());
    registry.registerTool(createReportProgressTool());

    // Design v58 §4.4/§6.2/§6.3: the eight historical `mcp__…` canonical names the
    // bundled report/slide Skills reference are host-owned static gateways, so the
    // names stay reachable while the schema, permission and output-path contract
    // belong to the host instead of the server's tool catalog. Registered once for
    // the process lifetime; each call takes a lease from the committed generation.
    if (runnerOptions.pluginProviderRuntime) {
      for (const gateway of createAllHostGateways(runnerOptions.pluginProviderRuntime)) {
        registry.registerTool(gateway);
      }
    }

    // Register notebook (memory) tools — shared LayeredMemoryStore
    for (const tool of createNotebookTools(getDesktopMemoryStore(dataRoot))) {
      registry.registerTool(tool);
    }

    // design §6.2 RoomHistoryReadCapability：全局仅注册一次，execute 时用
    // ToolExecutionContext.taskId 查 room-history-capability-registry.ts
    // 维护的绑定表——只在协作空间任务执行期间生效，见该模块顶部注释的
    // 完整架构说明。
    registry.registerTool(createGetRoomMessagesPageTool());
  }

  if (runnerOptions.multiAgent && registry instanceof DesktopOwnedToolRegistry) {
    registry.registerOwnedTool({ definition: READ_MATERIAL_TOOL_DEFINITION, permission: 'safe', execute: async () => 'Error: tool_scope_unsupported' }, {
      ownerId: 'desktop-host', slotKey: 'read_material', binding: 'custom', verifiedReadOnly: true,
      bindInvocation: authority => async input => (await executeReadMaterialForDesktop(input, {
        taskId: authority.agentId, materials: authority.materialIds.map(id => materialRegistry.get(id)).filter((item): item is MaterialRecord => Boolean(item)),
        materialRegistry, signal: authority.signal, officeToMarkdown: runnerOptions.officeToMarkdown,
        pdfToText: async bytes => (await import('./pdf-text.js')).extractPdfText(bytes),
      })).result,
    });
  }

  const run = async ({ taskId, sessionId, prompt, materials, signal: hostSignal, deadlineMs, history: hostHistory, persistObservationSnapshot, executionPersistence, registerCompoundFinalPublication, emitRuntimeEvent, emitUsage, maxToolLoopIterations, executionScope, permissionMode }: TaskRunnerInput, rootContext: DesktopAgentExecutionContext | undefined, observationActivation: DesktopObservationTaskActivation | undefined) => {
    const pendingRoomImages:MessageBlock[]=[];
    if(!nativeReadonlyOnly && runnerOptions.roomExecution)registry.registerTool({permission:'safe',definition:{name:'read_workspace_material',description:'Read a document or image downloaded into the current collaboration workspace. Use file_path relative to the workspace. Images are supplied to the model visually; documents return extracted text. Paths outside the workspace are forbidden.',inputSchema:{type:'object',properties:{file_path:{type:'string'},maxChars:{type:'number'}},required:['file_path']}},async execute(input,context){
      const record=await materialRegistry.importMaterial({taskId,sourcePath:String(input.file_path),role:'customer_material',roleSource:'auto'});
      const result=await executeReadMaterialForDesktop({materialId:record.materialId,maxChars:input.maxChars},{taskId,materials:[record],materialRegistry,signal:context?.signal,officeToMarkdown:runnerOptions.officeToMarkdown,pdfToText:async bytes=>(await import('./pdf-text.js')).extractPdfText(bytes)});
      if(result.ok)pendingRoomImages.push(...buildImageBlocksForMaterials([record]));
      return result.result;
    }});
    if (rootContext && !runnerOptions.multiAgent) throw new Error('unsupported multi-agent runner context');
    if (rootContext) runnerOptions.multiAgent!.service.assertInvocation(rootContext.actor);
    const signal = rootContext?.signal ?? hostSignal;
    const turnId = rootContext?.turnId ?? `turn_${Date.now().toString(36)}`;
    const intentId = `intent_${Date.now().toString(36)}`;
    const stepId = `${intentId}:step:reply`;
    const taskStartTime = Date.now();
    const invocationId = `inv_${randomUUID()}`;
    const cacheKey = createDesktopPromptCacheAffinity(sessionId, invocationId);
    const invocationOptions: ModelInvocationOptions | undefined = cacheKey
      ? { cacheKey }
      : undefined;
    let skillNamesDetected: string[] = [];
    let skillTriggerType: 'slash_command' | 'tool_call' | 'auto' = 'auto';
    if (!nativeReadonlyOnly && !runnerOptions.roomDiscussion && !runnerOptions.restrictedArtifactGeneration && loadedSkillCatalogVersion !== getSkillCatalogVersion()) {
      const targetVersion = getSkillCatalogVersion();
      try {
        const skills = await skillCatalog.reload();
        if (skills.length > 0 && !skillToolAdded) {
          const skillTool = createSkillTool(skillCatalog);
          registry.registerTool(skillTool);
          tools.push(skillTool);
          skillToolAdded = true;
        }
        loadedSkillCatalogVersion = targetVersion;
      } catch {
        loadedSkillCatalogVersion = targetVersion;
      }
    }
    const currentSkills = nativeReadonlyOnly || runnerOptions.roomDiscussion || runnerOptions.restrictedArtifactGeneration ? [] : skillCatalog.list();
    const skillsContext = currentSkills.length > 0 ? formatSkillsContext(currentSkills) : '';
    const slashMatch = parseSlashCommand(prompt);
    let effectivePrompt = prompt;
    let skillInvocation: SkillInvocation | null = null;

    if (slashMatch) {
      const skill = findSkillByCommandName(currentSkills, slashMatch.skillName);
      if (skill) {
        skillNamesDetected = [skill.name];
        skillTriggerType = 'slash_command';
        skillInvocation = buildSkillInvocation(skill.name, skillCatalog, sessionId);
        if (skillInvocation) {
          appendTrace(dataRoot, {
            ts: Date.now(), taskId: sessionId, skillName: skill.name,
            event: 'skill_invoked', details: `slash: ${slashMatch.rest || '(no args)'}`,
          });
        }
        // Inject skill content directly — skill execution works best when model has full instructions
        effectivePrompt = slashMatch.rest
          ? `Execute skill "${skill.name}": ${skill.description}\n\nUser input: ${slashMatch.rest}\n\nSkill content:\n${skill.content}`
          : `Execute skill "${skill.name}": ${skill.description}\n\nSkill content:\n${skill.content}`;
      }
    }

    // Register skill_bundle_refs tool for skill executions
    if (!nativeReadonlyOnly && !runnerOptions.restrictedArtifactGeneration) {
      const bundleTool = createSkillBundleRefsTool(skillCatalog);
      registry.registerTool(bundleTool);
    }

    const materialsContext = materials && materials.length > 0
      ? buildMaterialManifestForPrompt(materials)
      : '';


    if (observationActivation && (runnerOptions.roomExecution || executionScope || !persistObservationSnapshot || (!rootContext&&hostHistory.length) || (observationActivation.consumed&&!observationActivation.group) || observationActivation.revoked)) throw new Error('SOL_PI_DESKTOP_OBSERVATION_NOT_READY');
    if (observationActivation) observationActivation.consumed = true;
    const baseConfig = await loadConfig();
    const config = observationActivation ? (await import('../../src/runtime/sol-pi/product-bootstrap.js')).prepareObservationConfig(baseConfig, observationActivation.policy) : baseConfig;
    const projectModel = await runnerOptions.getProjectModel?.();
    const binding = projectModel?.binding ?? await runnerOptions.roomExecution?.getModelBinding?.() ?? resolveRuntimeModelBinding(config);
    const profileId = resolveDesktopHarnessProfileId(binding);
    if (isStrictKimiK3ProfileId(profileId)) {
      validateStrictDesktopHistory(hostHistory);
    }
    const adapter = projectModel?.adapter ?? createAdapterFromBinding(binding);
    const skillDebugEnabled = config.skillDebug ?? false;

    // Stage analysis for debug mode
    if (skillDebugEnabled && currentSkills.length > 0) {
      try {
        const stages = analyzeStageIntent(prompt, currentSkills, cwd);
        const stageSummary = stages.map(s => `  ${s.id}. ${s.title} (${s.skill})`).join('\n');
        const debugText = `[stage:plan] Detected ${stages.length} stages:\n${stageSummary}`;
        await emitRuntimeEvent({ type: 'assistant_delta', sessionId, turnId, intentId, stepId, delta: `${debugText}\n\n` });
      } catch {
        // Stage analysis is optional, don't block execution
      }
    }

    const modelIdentity = `\n\n## 模型信息\n\n你当前运行的模型是: ${adapter.getModelName()}。不要假设自己是其他模型。`;
    let systemPrompt = skillsContext
      ? `${BASE_SYSTEM_PROMPT}${modelIdentity}\n\nAvailable skills:\n${skillsContext}`
      : `${BASE_SYSTEM_PROMPT}${modelIdentity}`;
    if(runnerOptions.roomExecution)systemPrompt+='\nUse standard spawn_agent/send_message/followup_task/wait_agent for collaboration. Root must actively call wait_agent to receive child messages/results; children receive pending messages at model boundaries. Unsupported capabilities: '+roomUnsupportedCapabilities(runnerOptions.roomExecution.context as {localCommandsAllowed?:boolean}).join(', ');
    else if(runnerOptions.publishedInstructions)systemPrompt+=`\n\n## Published Room workspace instructions\n${runnerOptions.publishedInstructions}`;

    let userText = materialsContext
      ? `${effectivePrompt}${materialsContext}`
      : effectivePrompt;
    let scopedRegistry: ReturnType<DesktopMultiAgentRuntime['bindRoot']> | undefined;
    let observedGroup=observationActivation?.group;
    const bindRootScope=async()=>{ if (rootContext) {
      const multi = runnerOptions.multiAgent!;
      multi.service.assertInvocation(rootContext.actor, rootContext);
      multi.catalog.authorizeRoot(rootContext);
      systemPrompt += `\n\n${getDesktopDelegationPolicy()}\n\nChildren share the selected model, have separate history and working directories, and stay within inherited tool policy. Root context: ${JSON.stringify({ groupId: rootContext.groupId, agentId: rootContext.agentId, cwd: rootContext.cwd })}`;
      const agents = await loadCustomAgents(undefined, rootContext.cwd);
      scopedRegistry = multi.runtime.bindRoot(rootContext, { adapter, systemPrompt, catalog: multi.catalog.catalog,
        policy: multi.catalog.catalog.snapshotPolicy(), workspaceId: multi.workspaceId, materialIds: materials.map(item => item.materialId),
        registryOptions: {
          autoMode: (permissionMode ?? 'auto') === 'auto', permissionManager: new PermissionManager({ mode: permissionMode ?? 'auto' }),
        }, materials, materialRegistry, skillCatalog, dataRoot, agents, emitRuntimeEvent, maxIterations: maxToolLoopIterations, ...(observedGroup?{observation:observedGroup}:{}),
      });
    } };
    let observed: Awaited<ReturnType<typeof createDesktopProductObservationBinding>> | undefined;
    if (observationActivation && !rootContext) {
      if (projectModel) throw new Error('SOL_PI_DESKTOP_OBSERVATION_NOT_READY');
      observed = await createDesktopProductObservationBinding({ taskId, cwd, policy: observationActivation.policy,
        sourceRegistry: registry, profileRoot: observationActivation.profileRoot, environmentRoot: observationActivation.environmentRoot,
        credentialSecrets: Object.values(config.providers ?? {}).flatMap(provider => typeof provider.apiKey === 'string' && provider.apiKey ? [provider.apiKey] : []),
        permissionMode: permissionMode ?? 'default', onPrompt: observationActivation.onPrompt, authorizeValidationMaterials:observationActivation.authorizeValidationMaterials, persist: persistObservationSnapshot!, executionPersistence });
      observationActivation.live = observed;
      noteObservationInitializationReady(observationActivation);
    }
    if(observationActivation&&rootContext&&!observedGroup){
      if(!runnerOptions.observationGroupHost||projectModel)throw Error('SOL_PI_DESKTOP_GROUP_RUNTIME_REQUIRED');
      observedGroup=await createDesktopProductObservationGroup({service:runnerOptions.multiAgent!.service,host:runnerOptions.observationGroupHost.getHost(),observationStore:runnerOptions.observationGroupHost.observationStore,context:rootContext,
        taskId,cwd,policy:observationActivation.policy,sourceRegistry:registry,profileRoot:observationActivation.profileRoot,environmentRoot:observationActivation.environmentRoot,
        credentialSecrets:Object.values(config.providers??{}).flatMap(provider=>typeof provider.apiKey==='string'&&provider.apiKey?[provider.apiKey]:[]),permissionMode:permissionMode??'default',onPrompt:observationActivation.onPrompt,authorizeValidationMaterials:observationActivation.authorizeValidationMaterials});
      observationActivation.group=observedGroup;observationActivation.live=observedGroup;
      noteObservationInitializationReady(observationActivation);
    }
    if(!observedGroup)await bindRootScope();
    const invocationRegistry = observed?.registry ?? scopedRegistry?.registry ?? registry;
    let allToolDefs: ToolDefinition[];
    let messages: Message[];
    try {
    allToolDefs = !rootContext && materials && materials.length > 0
      ? [...invocationRegistry.getToolDefinitions(), READ_MATERIAL_TOOL_DEFINITION]
      : invocationRegistry.getToolDefinitions();
    const imageBlocks = materials && materials.length > 0 ? buildImageBlocksForMaterials(materials) : [];
    if(runnerOptions.roomExecution){
      const assembled=assembleRoomWorkspaceContext({baseSystemPrompt:systemPrompt,context:runnerOptions.roomExecution.context,taskPrompt:userText,
        history:hostHistory.map(item=>({role:item.role,content:[{type:'text',text:item.content}]})),tools:allToolDefs,currentImageBlocks:imageBlocks,
        contextLimit:resolveRoomWorkspaceContextLimit(binding),
        // Use only the actual adapter's declared request reservation. Other
        // providers choose their own output cap; zero here is unknown, not a
        // claim of exact tokenizer accounting or guaranteed total-window fit.
        outputTokenReserve:adapter.getOutputTokenReserve?.() ?? 0,
      });
      systemPrompt=assembled.systemPrompt;userText=assembled.userPrompt;
    }
    const userContent: MessageBlock[] = [
      { type: 'text', text: userText },
      ...imageBlocks,
    ];
    messages = buildDesktopProviderMessages(adapter, observedGroup?[]:hostHistory, userContent);
    } catch(error) {try{await observed?.dispose();}finally{if(observationActivation&&!observedGroup)observationActivation.live=undefined;}throw error;}

    const modelPhysicalScope = rootContext
      ? runnerOptions.multiAgent!.service.captureRootModelPhysicalScope(rootContext) : createDesktopModelPhysicalScope();
    const pendingUsageWrites: Promise<void>[] = [];
    let modelBodyFailure: { error: unknown } | undefined;
    let loopResult!: Awaited<ReturnType<typeof runDesktopToolLoop>>;
    try {
      const runLoop=(loopBinding=observed?.binding,loopRegistry=invocationRegistry,loopMessages=messages,loopSignal=signal,beforeManagedTurnSeal?:()=>Promise<void>)=>runDesktopToolLoop({
      modelPhysicalScope,
      beforeManagedTurnSeal,
      observationBinding: loopBinding,
      adapter,
      projectModel,
      systemPrompt,
      messages:loopMessages,
      allToolDefs:observedGroup?loopRegistry.getToolDefinitions():allToolDefs,
      registry: loopRegistry,
      finalizeProjectProposal: createProjectToolOptions.finalizeProjectProposal
        ? proposal => createProjectToolOptions.finalizeProjectProposal!(proposal, { taskId, signal })
        : undefined,
      invocationOptions,
      signal:loopSignal,
      taskDeadline: resolveDesktopRunDeadline(rootContext?.effectiveDeadline, deadlineMs),
      cwd: rootContext?.cwd ?? runnerOptions.cwd,
      roomExecution:runnerOptions.roomExecution?{...runnerOptions.roomExecution,takePendingImages:()=>pendingRoomImages.splice(0)}:undefined,
      mailbox: rootContext?.mailbox,
      canResumeSummary: rootContext ? () => runnerOptions.multiAgent!.service.canResumeSummary(rootContext) : undefined,
      onActivity: rootContext ? activity => { void runnerOptions.multiAgent!.service.recordActivity(rootContext, activity).catch(() => {}); } : undefined,
      sessionId,
      turnId,
      intentId,
      stepId,
      taskId,
      executionScope,
      materials,
      materialRegistry,
      officeToMarkdown: runnerOptions.officeToMarkdown,
      emitRuntimeEvent: async event => {
        if (rootContext && (event.type === 'assistant_delta' || event.type === 'artifact_recorded')) await runnerOptions.multiAgent!.service.recordRuntimeEvent(rootContext, event);
        await emitRuntimeEvent(event);
      },
      skillInvocation,
      skillCatalog,
      dataRoot,
      taskStartTime,
      maxIterations: maxToolLoopIterations,
      onUsage: async (inputTokens, outputTokens, usageId) => {
        if (rootContext) await runnerOptions.multiAgent!.service.recordUsage(rootContext, { usageId: usageId!, inputTokens, outputTokens });
        pendingUsageWrites.push(emitUsage({ inputTokens, outputTokens }));
      },
      strategies: {
        compact: {
          enabled: false,
          shouldCompact: () => false,
          doCompact: async (_messages, _streamOptions) => {},
        },
        buildApiView: (msgs) => msgs,
        processToolResult: projectDesktopToolResultForModel,
        trackAutoProgress: false,
        trackReferenceReads: false,
        emitSkillArtifactTrace: false,
      },
      });
      if(observedGroup)await bindRootScope();
      const observedExtraTools=observedGroup?MULTI_AGENT_TOOL_NAMES.flatMap(name=>{const tool=scopedRegistry!.registry.getRegisteredTool(name);return tool?[tool]:[];}):[];
      loopResult=observedGroup?await observedGroup.runRootTurn(rootContext!,permissionMode??'default',signal,async turn=>{
        if(registerCompoundFinalPublication){
          const actualBinding=requireDesktopObservationBinding(turn.binding,taskId,turn.registry);
          if(getCompoundPublicationOwnerBinding(actualBinding.owner))bindCompoundFinalPublicationConsumer(actualBinding.owner,turnId,{
            register:registerCompoundFinalPublication,
            inspectReceipt:getTaskHostCompoundFinalPublicationReceipt,
          });
        }
        observedGroup!.session.replaceMessages([...observedGroup!.session.getMessages(),...messages]);
        const nativeMessages=observedGroup!.session.getMessages();
        return runLoop(turn.binding,turn.registry,nativeMessages,turn.signal,async()=>{observedGroup!.session.replaceMessages(nativeMessages);await turn.publishHistory();});
      },observedExtraTools):await runLoop();
    } catch (error) {
      modelBodyFailure = { error };
      await Promise.allSettled(pendingUsageWrites);
    }
    try { await closeDesktopModelPhysicalScope(modelPhysicalScope, signal.reason); }
    catch (physicalError) {
      if (modelBodyFailure && modelBodyFailure.error !== physicalError) throw new AggregateError([modelBodyFailure.error, physicalError], 'desktop_model_business_and_physical_cleanup_failed', { cause: modelBodyFailure.error });
      throw physicalError;
    }
    {
      scopedRegistry?.dispose();
      try { if(observed&&observationActivation)observationActivation.diagnostics=observed.diagnostics(); }
      finally { try { await observed?.dispose(); } finally { if(observationActivation&&!observedGroup)observationActivation.live=undefined; } }
    }
    if (modelBodyFailure) throw modelBodyFailure.error;
    await Promise.all(pendingUsageWrites);

    const { reply, totalToolCalls, totalInputTokens, totalOutputTokens, referenceReads } = loopResult;
    skillNamesDetected = loopResult.skillNamesDetected.length > 0 ? loopResult.skillNamesDetected : skillNamesDetected;
    skillTriggerType = loopResult.skillTriggerType !== 'auto' ? loopResult.skillTriggerType : skillTriggerType;
    skillInvocation = loopResult.skillInvocation ?? skillInvocation;

    await emitRuntimeEvent({ type: 'receipt_emitted', sessionId, turnId, intentId, stepId, note: reply.trim() || '模型没有返回内容。' });
    if (skillNamesDetected.length > 0) {
      try {
        await appendExecRecord(dataRoot, {
          id: `exec_${taskStartTime.toString(36)}`,
          skillNames: skillNamesDetected,
          taskId: sessionId,
          startTime: taskStartTime,
          endTime: Date.now(),
          durationMs: Date.now() - taskStartTime,
          status: 'success',
          inputTokens: totalInputTokens,
          outputTokens: totalOutputTokens,
          prompt: prompt.slice(0, 80),
          triggerType: skillTriggerType,
        });
      } catch { /* stats recording failure is non-critical */ }
    }
    if (skillInvocation) {
      appendTrace(dataRoot, {
        ts: Date.now(), taskId: sessionId, skillName: skillInvocation.primarySkill,
        stageId: skillInvocation.stageId, event: 'stage_end',
        durationMs: Date.now() - taskStartTime,
        details: `tool_calls=${totalToolCalls} refs_read=${referenceReads} tokens=${totalInputTokens}`,
      });
    }
  };
  return async (input, rootContext) => {
    const service = runnerOptions.multiAgent?.service;
    const scope = rootContext && runnerOptions.observationTasks?.size
      ? service?.captureObservationInitializationScope(rootContext) : undefined;
    const activation = runnerOptions.observationTasks?.get(input.taskId)
      ?? (rootContext ? [...(runnerOptions.observationTasks?.values() ?? [])].reverse().filter(entry => {
        const binding = observationInitializationStates.get(entry);
        if (binding) return Boolean(scope && binding.service === service && binding.incarnation === scope.incarnation);
        return entry.group?.groupId === rootContext.groupId;
      }).sort((a, b) => (observationInitializationStates.get(b)?.firstRootEpoch ?? -1)
        - (observationInitializationStates.get(a)?.firstRootEpoch ?? -1))[0] : undefined);
    if (!activation) return run(input, rootContext, undefined);
    let state = observationInitializationStates.get(activation);
    if (state && (state.service !== service || state.incarnation !== scope?.incarnation
      || (scope && scope.rootEpoch < state.firstRootEpoch!))) throw Error('SOL_PI_DESKTOP_OBSERVATION_NOT_READY');
    if (state?.failure) throw state.failure.error;
    if (state?.phase === 'initializing') throw Error('SOL_PI_DESKTOP_OBSERVATION_NOT_READY');
    if (!state) {
      state = { service, incarnation: scope?.incarnation, firstRootEpoch: scope?.rootEpoch,
        phase: activation.group || activation.live ? 'ready' : 'initializing' };
      observationInitializationStates.set(activation, state);
    }
    const ownerAttempt = state.phase === 'initializing' ? Object.freeze(Object.create(null)) : undefined;
    if (ownerAttempt) state.ownerAttempt = ownerAttempt;
    try { await run(input, rootContext, activation); }
    catch (error) {
      if (ownerAttempt && state.ownerAttempt === ownerAttempt && state.phase === 'initializing') {
        state.failure = { error }; state.phase = 'failed';
        if (scope && service) {
          try { service.retainFailedObservationInitializationScope(scope); }
          catch (retentionError) {
            state.failure = { error: new AggregateError([error, retentionError], 'SOL_PI_DESKTOP_OBSERVATION_SCOPE_FAILED') };
            throw state.failure.error;
          }
        }
      }
      throw error;
    } finally { if (ownerAttempt && state.ownerAttempt === ownerAttempt) state.ownerAttempt = undefined; }
  };
}

function registerKSwarmTools(
  registry: ToolRegistry,
  kswarmService: KSwarmService,
  createProjectToolOptions: KSwarmCreateProjectToolOptions = {},
): void {
  if (createProjectToolOptions.createRoom) registry.registerTool(createConversationRoomTool(createProjectToolOptions.createRoom));
  registry.registerTool(createKSwarmCreateProjectTool(kswarmService, createProjectToolOptions));
  registry.registerTool(createKSwarmInspectProjectTool(kswarmService));
  registry.registerTool(createKSwarmContinueProjectTool(kswarmService));
  registry.registerTool(createKSwarmRunDynamicWorkflowScriptTool(kswarmService));
  registry.registerTool(createKSwarmGetDynamicWorkflowStatusTool(kswarmService));
  registry.registerTool(createKSwarmRepairProjectTaskFromFileTool(kswarmService));
  registry.registerTool(createKSwarmRepairProjectTaskTool(kswarmService));
}
